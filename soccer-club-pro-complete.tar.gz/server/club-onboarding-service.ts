import { db } from './db';
import { clubs, clubUsers, clubSubscriptions, clubModules, modules } from '@shared/schema';
import { eq, and } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { sendOnboardingEmail } from './onecom-email';

export class ClubOnboardingService {
  
  // Step 1: Club Registration (Public Form)
  async registerClub(registrationData: {
    clubName: string;
    fullName: string;
    adminFirstName: string;
    adminLastName: string;
    adminEmail: string;
    phone?: string;
    address?: string;
    website?: string;
    selectedModules: string[]; // Array of module IDs
  }) {
    console.log(`🏟️ Starting club registration for: ${registrationData.clubName}`);
    
    // Check if club already exists
    const existingClub = await db.select()
      .from(clubs)
      .where(eq(clubs.email, registrationData.adminEmail));
    
    if (existingClub.length > 0) {
      throw new Error('Een club met dit email adres bestaat al. Neem contact op voor ondersteuning.');
    }

    // Calculate total monthly cost
    const selectedModulesList = await db.select()
      .from(modules)
      .where(modules.id.in ? modules.id.in(registrationData.selectedModules) : eq(modules.id, registrationData.selectedModules[0]));
    
    const totalMonthlyCost = selectedModulesList.reduce((sum, module) => 
      sum + parseFloat(module.price), 0
    );

    // Create club with pending status
    const [newClub] = await db.insert(clubs).values({
      name: registrationData.clubName,
      fullName: registrationData.fullName,
      email: registrationData.adminEmail,
      phone: registrationData.phone,
      address: registrationData.address,
      website: registrationData.website,
      status: 'pending_payment', // Will be activated after payment
      subscription: 'trial', // Start with trial
      createdAt: new Date()
    }).returning();

    console.log(`✅ Club ${newClub.id} created: ${registrationData.clubName}`);

    // Generate activation token
    const activationToken = crypto.randomBytes(32).toString('hex');
    
    // Store pending registration
    const pendingRegistration = {
      clubId: newClub.id,
      activationToken,
      adminData: {
        firstName: registrationData.adminFirstName,
        lastName: registrationData.adminLastName,
        email: registrationData.adminEmail
      },
      selectedModules: registrationData.selectedModules,
      totalMonthlyCost,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
    };

    // TODO: Store in pending_registrations table
    console.log('📝 Pending registration created:', pendingRegistration);

    return {
      clubId: newClub.id,
      activationToken,
      totalMonthlyCost,
      paymentUrl: `/payment/club/${newClub.id}?token=${activationToken}`,
      message: 'Club geregistreerd. Ga naar de betaallink om je modules te activeren.'
    };
  }

  // Step 2: Payment Processing (Stripe Integration)
  async processPayment(clubId: number, activationToken: string, paymentData: {
    stripePaymentIntentId: string;
    paidAmount: number;
    currency: string;
  }) {
    console.log(`💳 Processing payment for club ${clubId}`);
    
    // Verify payment with Stripe
    // TODO: Actual Stripe verification here
    const paymentVerified = true; // Simulated for now

    if (!paymentVerified) {
      throw new Error('Betaling kon niet geverifieerd worden. Probeer opnieuw.');
    }

    // Activate club
    await db.update(clubs)
      .set({
        status: 'active',
        subscription: 'paid',
        updatedAt: new Date()
      })
      .where(eq(clubs.id, clubId));

    console.log(`✅ Club ${clubId} payment verified and activated`);

    // Proceed with full onboarding
    return await this.completeOnboarding(clubId, activationToken);
  }

  // Step 3: Complete Automatic Onboarding
  async completeOnboarding(clubId: number, activationToken: string) {
    console.log(`🚀 Completing onboarding for club ${clubId}`);
    
    // Get club info
    const [club] = await db.select().from(clubs).where(eq(clubs.id, clubId));
    if (!club) {
      throw new Error('Club niet gevonden');
    }

    // TODO: Get pending registration data (from activationToken)
    const pendingData = {
      adminData: {
        firstName: 'Admin',
        lastName: 'User',
        email: club.email
      },
      selectedModules: ['core', 'player_management', 'training_planning']
    };

    // 1. Create admin user with random password
    const tempPassword = this.generateTempPassword();
    const adminUser = await this.createClubAdmin(club, pendingData.adminData, tempPassword);

    // 2. Enable selected modules
    await this.enableClubModules(clubId, pendingData.selectedModules);

    // 3. Create subscription record
    await this.createSubscriptionRecord(clubId, pendingData.selectedModules);

    // 4. Send welcome email with login instructions
    await this.sendWelcomeEmail(club, adminUser, tempPassword);

    // 5. Create initial data setup (optional)
    await this.createInitialData(clubId);

    console.log(`✅ Onboarding completed for ${club.name}`);

    return {
      success: true,
      clubId: club.id,
      clubName: club.name,
      adminUserId: adminUser.id,
      loginUrl: `https://${club.name.toLowerCase().replace(/\s+/g, '')}.soccerclubpro.com`,
      message: 'Onboarding voltooid! Check je email voor inloggegevens.'
    };
  }

  // Create club administrator
  private async createClubAdmin(club: any, adminData: any, tempPassword: string) {
    const hashedPassword = await bcrypt.hash(tempPassword, 12);
    const userId = Math.floor(Math.random() * 90000) + 10000;

    const [adminUser] = await db.insert(clubUsers).values({
      id: userId.toString(),
      clubId: club.id,
      clubName: club.name,
      userName: `${adminData.firstName.toLowerCase()}.${adminData.lastName.toLowerCase()}`,
      userType: 'admin',
      firstName: adminData.firstName,
      lastName: adminData.lastName,
      email: adminData.email,
      hashedPassword,
      permissions: ['full_access', 'user_management', 'module_management', 'billing'],
      isActive: true,
      emailVerified: false
    }).returning();

    console.log(`👤 Admin user ${adminUser.id} created for ${club.name}`);
    return adminUser;
  }

  // Enable modules for new club
  private async enableClubModules(clubId: number, moduleIds: string[]) {
    console.log(`⚙️ Enabling ${moduleIds.length} modules for club ${clubId}`);
    
    for (const moduleId of moduleIds) {
      await db.insert(clubModules).values({
        clubId,
        moduleName: moduleId,
        isEnabled: true,
        enabledAt: new Date()
      });
      
      console.log(`✅ Module ${moduleId} enabled for club ${clubId}`);
    }
  }

  // Create subscription record
  private async createSubscriptionRecord(clubId: number, moduleIds: string[]) {
    const subscriptionId = `sub_${clubId}_${Date.now()}`;
    
    await db.insert(clubSubscriptions).values({
      id: subscriptionId,
      clubId,
      status: 'active',
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      createdAt: new Date()
    });

    console.log(`📋 Subscription ${subscriptionId} created for club ${clubId}`);
  }

  // Generate temporary password
  private generateTempPassword(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let password = '';
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  }

  // Send welcome email with login details
  private async sendWelcomeEmail(club: any, adminUser: any, tempPassword: string) {
    const loginUrl = `https://soccerclubpro.com/club/${club.id}/login`;
    
    const emailData = {
      to: adminUser.email,
      subject: `Welkom bij Soccer Club Pro - ${club.name}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #2563eb;">Welkom bij Soccer Club Pro!</h1>
          
          <p>Gefeliciteerd! Je club <strong>${club.name}</strong> is succesvol aangemeld bij Soccer Club Pro.</p>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3>Je inloggegevens:</h3>
            <p><strong>Login URL:</strong> <a href="${loginUrl}">${loginUrl}</a></p>
            <p><strong>Email:</strong> ${adminUser.email}</p>
            <p><strong>Tijdelijk wachtwoord:</strong> <code style="background: #e5e7eb; padding: 4px 8px; border-radius: 4px;">${tempPassword}</code></p>
            <p><strong>Gebruikers ID:</strong> ${adminUser.id}</p>
          </div>
          
          <div style="background: #fef3c7; padding: 15px; border-radius: 8px; border-left: 4px solid #f59e0b;">
            <p><strong>Belangrijk:</strong> Wijzig je wachtwoord na de eerste login voor je veiligheid.</p>
          </div>
          
          <h3>Volgende stappen:</h3>
          <ol>
            <li>Log in met bovenstaande gegevens</li>
            <li>Wijzig je wachtwoord</li>
            <li>Voeg je teams en spelers toe</li>
            <li>Verken de beschikbare modules</li>
            <li>Gebruik de chat assistant voor hulp</li>
          </ol>
          
          <p>Heb je vragen? De virtuele assistant in de applicatie helpt je bij alle modules en functies.</p>
          
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #e5e7eb;">
          <p style="color: #6b7280; font-size: 14px;">
            Soccer Club Pro Team<br>
            <a href="mailto:info@soccerclubpro.com">info@soccerclubpro.com</a>
          </p>
        </div>
      `
    };

    await sendOnboardingEmail(emailData);
    console.log(`📧 Welcome email sent to ${adminUser.email}`);
  }

  // Create initial data for new club
  private async createInitialData(clubId: number) {
    // Create default team categories
    const defaultCategories = ['U8', 'U10', 'U12', 'U14', 'U16', 'U18', 'Senioren'];
    
    // TODO: Create default teams, basic settings, etc.
    console.log(`🏗️ Initial data structure created for club ${clubId}`);
  }

  // Get club onboarding status
  async getOnboardingStatus(clubId: number) {
    const [club] = await db.select().from(clubs).where(eq(clubs.id, clubId));
    
    if (!club) {
      return { status: 'not_found' };
    }

    const modules = await db.select()
      .from(clubModules)
      .where(and(eq(clubModules.clubId, clubId), eq(clubModules.isEnabled, true)));

    const users = await db.select()
      .from(clubUsers)
      .where(eq(clubUsers.clubId, clubId));

    return {
      status: club.status,
      clubName: club.name,
      modulesEnabled: modules.length,
      usersCreated: users.length,
      isComplete: club.status === 'active' && modules.length > 0 && users.length > 0
    };
  }
}