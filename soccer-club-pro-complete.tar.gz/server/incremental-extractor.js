import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

class IncrementalVideoExtractor {
  constructor() {
    this.videoPath = '../uploads/match-videos/match-video-1750870860329-999699725.mp4';
    this.outputDir = '../uploads/extracted-frames/match-video-1750870860329-999699725';
    this.targetFrames = 3180; // 106 minutes * 60 seconds * 0.5 FPS
    this.batchSize = 300; // Extract 300 frames per batch (10 minutes)
    this.isRunning = false;
  }

  getCurrentFrameCount() {
    try {
      const files = fs.readdirSync(this.outputDir).filter(f => f.startsWith('frame_') && f.endsWith('.jpg'));
      return files.length;
    } catch (error) {
      return 0;
    }
  }

  async extractBatch(startFrame, endFrame) {
    return new Promise((resolve, reject) => {
      const startTime = 540 + (startFrame * 2); // 9 minutes + frame offset in seconds
      const duration = (endFrame - startFrame + 1) * 2; // duration in seconds
      
      const startTimeFormatted = this.secondsToTime(startTime);
      const durationFormatted = this.secondsToTime(duration);
      
      console.log(`Extracting frames ${startFrame}-${endFrame} from ${startTimeFormatted} for ${durationFormatted}`);
      
      const ffmpeg = spawn('ffmpeg', [
        '-y',
        '-ss', startTimeFormatted,
        '-i', this.videoPath,
        '-t', durationFormatted,
        '-vf', 'fps=0.5',
        '-q:v', '3',
        '-start_number', (startFrame + 1).toString(),
        `${this.outputDir}/frame_%04d.jpg`
      ]);

      ffmpeg.on('close', (code) => {
        if (code === 0) {
          resolve();
        } else {
          reject(new Error(`FFmpeg exited with code ${code}`));
        }
      });

      ffmpeg.on('error', reject);
    });
  }

  secondsToTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }

  async extractToCompletion() {
    if (this.isRunning) {
      console.log('Extraction already running');
      return;
    }

    this.isRunning = true;
    console.log('Starting incremental video extraction to 100% completion...');

    try {
      let currentFrames = this.getCurrentFrameCount();
      console.log(`Starting with ${currentFrames} frames`);

      while (currentFrames < this.targetFrames) {
        const startFrame = currentFrames;
        const endFrame = Math.min(currentFrames + this.batchSize - 1, this.targetFrames - 1);
        
        console.log(`Batch: ${startFrame} to ${endFrame} (${((currentFrames / this.targetFrames) * 100).toFixed(1)}% complete)`);
        
        await this.extractBatch(startFrame, endFrame);
        
        // Verify frames were extracted
        const newFrameCount = this.getCurrentFrameCount();
        if (newFrameCount <= currentFrames) {
          console.log('No new frames extracted, retrying batch...');
          continue;
        }
        
        currentFrames = newFrameCount;
        console.log(`Progress: ${currentFrames}/${this.targetFrames} frames (${((currentFrames / this.targetFrames) * 100).toFixed(1)}%)`);
        
        // Brief pause between batches
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      console.log(`Extraction completed! Total frames: ${currentFrames}`);
      
    } catch (error) {
      console.error('Extraction error:', error);
    } finally {
      this.isRunning = false;
    }
  }

  getProgress() {
    const current = this.getCurrentFrameCount();
    return {
      currentFrames: current,
      targetFrames: this.targetFrames,
      percentage: (current / this.targetFrames) * 100,
      isComplete: current >= this.targetFrames,
      isRunning: this.isRunning
    };
  }
}

export default IncrementalVideoExtractor;