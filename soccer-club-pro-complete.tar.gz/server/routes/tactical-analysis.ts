import { Router } from "express";
import { db } from "../db";
import { sql } from "drizzle-orm";

const router = Router();

// Get tactical analysis data for a specific match
router.get('/:matchId', async (req, res) => {
  try {
    const { matchId } = req.params;
    
    const players = await db.execute(sql`
      SELECT * FROM tactical_analysis_data 
      WHERE match_id = ${matchId}
      ORDER BY team, player_name
    `);
    
    res.json({ players: players.rows });
  } catch (error) {
    console.error('Failed to fetch tactical analysis:', error);
    res.status(500).json({ error: 'Failed to fetch tactical analysis' });
  }
});

// Get team tactical analysis for a specific match
router.get('/team/:matchId', async (req, res) => {
  try {
    const { matchId } = req.params;
    
    const teams = await db.execute(sql`
      SELECT * FROM team_tactical_analysis 
      WHERE match_id = ${matchId}
      ORDER BY team
    `);
    
    res.json({ teams: teams.rows });
  } catch (error) {
    console.error('Failed to fetch team tactical analysis:', error);
    res.status(500).json({ error: 'Failed to fetch team tactical analysis' });
  }
});

export default router;