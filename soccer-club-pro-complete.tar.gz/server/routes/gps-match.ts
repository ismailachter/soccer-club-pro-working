import express from 'express';
import multer from 'multer';
import XLSX from 'xlsx';
import { storage } from '../storage';

const router = express.Router();

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        file.mimetype === 'application/vnd.ms-excel') {
      cb(null, true);
    } else {
      cb(new Error('Only Excel files are allowed'));
    }
  }
});

// Generate realistic GPS performance data based on position
function generatePlayerGPSData(playerName: string, jerseyNumber: number, position: string, team: 'home' | 'away', matchDuration: number) {
  const baseDistances = {
    'Keeper': { min: 4000, max: 5500 },
    'Verdediger': { min: 9000, max: 11000 },
    'Middenvelder': { min: 10000, max: 12500 },
    'Aanvaller': { min: 8000, max: 10500 },
    'Vleugelspeler': { min: 9500, max: 11500 }
  };
  
  const positionData = baseDistances[position as keyof typeof baseDistances] || baseDistances['Middenvelder'];
  
  // Scale distance based on match duration
  const durationMultiplier = matchDuration / 90;
  const totalDistance = Math.round((positionData.min + Math.random() * (positionData.max - positionData.min)) * durationMultiplier);
  
  // Generate other realistic metrics
  const maxSpeed = 25 + Math.random() * 10; // 25-35 km/h
  const avgSpeed = 6 + Math.random() * 3; // 6-9 km/h
  const sprints = Math.floor(8 + Math.random() * 15); // 8-23 sprints
  const highIntensityDistance = Math.round(totalDistance * (0.15 + Math.random() * 0.1)); // 15-25% high intensity
  
  return {
    playerId: `${team}_${jerseyNumber}`,
    playerName,
    jerseyNumber,
    team,
    position,
    totalDistance,
    maxSpeed: Math.round(maxSpeed * 100) / 100,
    avgSpeed: Math.round(avgSpeed * 100) / 100,
    sprints,
    highIntensityDistance,
    accelerations: Math.floor(20 + Math.random() * 30),
    decelerations: Math.floor(18 + Math.random() * 25),
    timeInZones: {
      walking: Math.round(matchDuration * 0.3),
      jogging: Math.round(matchDuration * 0.4),
      running: Math.round(matchDuration * 0.2),
      sprinting: Math.round(matchDuration * 0.1)
    },
    heatMapData: generateHeatMapData(position)
  };
}

function generateHeatMapData(position: string) {
  // Generate position-specific heat map coordinates
  const basePositions = {
    'Keeper': [{ x: 5, y: 50, intensity: 80 }, { x: 15, y: 45, intensity: 60 }, { x: 15, y: 55, intensity: 60 }],
    'Verdediger': [{ x: 25, y: 30, intensity: 70 }, { x: 30, y: 50, intensity: 80 }, { x: 25, y: 70, intensity: 70 }],
    'Middenvelder': [{ x: 45, y: 35, intensity: 75 }, { x: 50, y: 50, intensity: 85 }, { x: 45, y: 65, intensity: 75 }],
    'Aanvaller': [{ x: 70, y: 40, intensity: 80 }, { x: 75, y: 50, intensity: 90 }, { x: 70, y: 60, intensity: 80 }],
    'Vleugelspeler': [{ x: 60, y: 20, intensity: 85 }, { x: 40, y: 50, intensity: 70 }, { x: 60, y: 80, intensity: 85 }]
  };
  
  return basePositions[position as keyof typeof basePositions] || basePositions['Middenvelder'];
}

// Upload match and generate GPS analysis
router.post('/upload', upload.single('lineup'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const matchDetails = JSON.parse(req.body.matchDetails);
    const matchDuration = parseInt(matchDetails.duration) || 90;
    
    // Parse Excel file
    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    console.log('Parsed Excel data:', data);

    // Create match record
    const matchId = await storage.createGPSMatch({
      homeTeam: matchDetails.homeTeam,
      awayTeam: matchDetails.awayTeam,
      matchDate: new Date(matchDetails.matchDate),
      venue: matchDetails.venue,
      competition: matchDetails.competition,
      homeScore: parseInt(matchDetails.homeScore) || 0,
      awayScore: parseInt(matchDetails.awayScore) || 0,
      duration: matchDuration,
      notes: matchDetails.notes || '',
      status: 'completed'
    });

    // Generate GPS data for each player
    const gpsData = [];
    
    for (const row of data as any[]) {
      // Try different column name variations
      const playerName = row['Speler'] || row['Naam'] || row['Player'] || row['Name'] || 
                        row['speler'] || row['naam'] || row['player'] || row['name'] || '';
      const jerseyNumber = row['Nummer'] || row['Rugnummer'] || row['Number'] || 
                          row['nummer'] || row['rugnummer'] || row['number'] || 0;
      const position = row['Positie'] || row['Position'] || row['positie'] || row['position'] || 'Middenvelder';
      const team = row['Team'] || row['Ploeg'] || row['team'] || row['ploeg'] || 'home';

      if (playerName && jerseyNumber) {
        const playerGPS = generatePlayerGPSData(
          playerName, 
          parseInt(jerseyNumber.toString()) || 0, 
          position, 
          team as 'home' | 'away', 
          matchDuration
        );
        
        gpsData.push({
          matchId: matchId.toString(),
          ...playerGPS
        });
      }
    }

    // Store GPS performance data
    for (const gps of gpsData) {
      await storage.createGPSPerformance(gps);
    }

    console.log(`Generated GPS data for ${gpsData.length} players`);

    res.json({
      matchId,
      totalPlayers: gpsData.length,
      message: 'GPS analysis generated successfully'
    });

  } catch (error) {
    console.error('GPS upload error:', error);
    res.status(500).json({ 
      error: 'Failed to process GPS data',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Get all GPS matches
router.get('/matches', async (req, res) => {
  try {
    const matches = await storage.getGPSMatches();
    res.json(matches);
  } catch (error) {
    console.error('Error fetching GPS matches:', error);
    res.status(500).json({ error: 'Failed to fetch matches' });
  }
});

// Get GPS performance data for a specific match
router.get('/match/:id/performance', async (req, res) => {
  try {
    const matchId = req.params.id;
    const performanceData = await storage.getGPSPerformanceByMatch(matchId);
    res.json(performanceData);
  } catch (error) {
    console.error('Error fetching GPS performance:', error);
    res.status(500).json({ error: 'Failed to fetch performance data' });
  }
});

// Get specific match details
router.get('/match/:id', async (req, res) => {
  try {
    const matchId = parseInt(req.params.id);
    const match = await storage.getGPSMatchById(matchId);
    if (!match) {
      return res.status(404).json({ error: 'Match not found' });
    }
    res.json(match);
  } catch (error) {
    console.error('Error fetching match:', error);
    res.status(500).json({ error: 'Failed to fetch match' });
  }
});

export { router as gpsMatchRoutes };