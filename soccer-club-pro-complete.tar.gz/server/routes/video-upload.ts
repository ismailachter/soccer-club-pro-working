import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { z } from 'zod';

const router = Router();

// Create uploads directory if it doesn't exist
const videoUploadsDir = path.join(process.cwd(), 'uploads', 'videos');
if (!fs.existsSync(videoUploadsDir)) {
  fs.mkdirSync(videoUploadsDir, { recursive: true });
}

// Configure multer for video uploads
const videoStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, videoUploadsDir);
  },
  filename: (req, file, cb) => {
    // Generate unique filename with timestamp
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, `video-${uniqueSuffix}${ext}`);
  }
});

// Video file filter
const videoFileFilter = (req: any, file: any, cb: any) => {
  // Allowed video formats
  const allowedMimeTypes = [
    'video/mp4',
    'video/quicktime',
    'video/x-msvideo', // .avi
    'video/webm',
    'video/x-ms-wmv'
  ];

  if (allowedMimeTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Only video files (MP4, MOV, AVI, WebM, WMV) are allowed'), false);
  }
};

const videoUpload = multer({
  storage: videoStorage,
  fileFilter: videoFileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit for videos
  }
});

// Video upload validation schema
const videoUploadSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  teamId: z.string().transform(Number),
  analysisType: z.enum(['full_match', 'tactical_analysis', 'player_performance', 'training_session']),
  season: z.string().min(1, 'Season is required'),
  opponent: z.string().optional(),
  matchResult: z.string().optional()
});

// Upload video endpoint
router.post('/upload', videoUpload.single('video'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No video file provided' });
    }

    // Validate request body
    const validationResult = videoUploadSchema.safeParse(req.body);
    if (!validationResult.success) {
      // Clean up uploaded file if validation fails
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: validationResult.error.issues 
      });
    }

    const data = validationResult.data;

    // Get video file info
    const videoInfo = {
      title: data.title,
      description: data.description || '',
      videoPath: req.file.path,
      originalName: req.file.originalname,
      fileSize: req.file.size,
      mimeType: req.file.mimetype,
      teamId: data.teamId,
      analysisType: data.analysisType,
      season: data.season,
      opponent: data.opponent,
      matchResult: data.matchResult,
      uploadedAt: new Date().toISOString()
    };

    // Here you would typically save to database
    // For now, return the video info
    res.json({
      success: true,
      message: 'Video uploaded successfully',
      video: videoInfo,
      fileInfo: {
        size: formatFileSize(req.file.size),
        duration: 'Processing...', // Would be calculated by video processing
        resolution: 'Processing...' // Would be extracted by video processing
      }
    });

  } catch (error) {
    console.error('Video upload error:', error);
    
    // Clean up file if there was an error
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }

    res.status(500).json({ 
      error: 'Video upload failed', 
      message: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// Get video info endpoint
router.get('/:filename', (req, res) => {
  const filename = req.params.filename;
  const videoPath = path.join(videoUploadsDir, filename);

  if (!fs.existsSync(videoPath)) {
    return res.status(404).json({ error: 'Video not found' });
  }

  const stats = fs.statSync(videoPath);
  
  res.json({
    filename,
    size: formatFileSize(stats.size),
    uploadDate: stats.birthtime,
    lastModified: stats.mtime
  });
});

// Stream video endpoint
router.get('/stream/:filename', (req, res) => {
  const filename = req.params.filename;
  const videoPath = path.join(videoUploadsDir, filename);

  if (!fs.existsSync(videoPath)) {
    return res.status(404).json({ error: 'Video not found' });
  }

  const stat = fs.statSync(videoPath);
  const fileSize = stat.size;
  const range = req.headers.range;

  if (range) {
    // Support for video streaming with range requests
    const parts = range.replace(/bytes=/, "").split("-");
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunksize = (end - start) + 1;
    const file = fs.createReadStream(videoPath, { start, end });
    const head = {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(206, head);
    file.pipe(res);
  } else {
    const head = {
      'Content-Length': fileSize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(200, head);
    fs.createReadStream(videoPath).pipe(res);
  }
});

// Delete video endpoint
router.delete('/:filename', (req, res) => {
  const filename = req.params.filename;
  const videoPath = path.join(videoUploadsDir, filename);

  if (!fs.existsSync(videoPath)) {
    return res.status(404).json({ error: 'Video not found' });
  }

  try {
    fs.unlinkSync(videoPath);
    res.json({ success: true, message: 'Video deleted successfully' });
  } catch (error) {
    console.error('Error deleting video:', error);
    res.status(500).json({ error: 'Failed to delete video' });
  }
});

// Utility function to format file size
function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export default router;