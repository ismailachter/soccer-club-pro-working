import express from 'express';
import { db } from '../db/db';
import { sql } from 'drizzle-orm';

const router = express.Router();

// GET /api/physical-performance/match/:videoId - Get physical data for all players in a match
router.get('/match/:videoId', async (req, res) => {
  try {
    const videoId = parseInt(req.params.videoId);
    if (isNaN(videoId)) {
      return res.status(400).json({ message: 'Invalid video ID' });
    }

    const physicalData = await db.execute(sql`
      SELECT 
        ppa.*,
        u.first_name,
        u.last_name,
        v.title as match_title,
        v.opponent,
        v.match_date
      FROM physical_performance_analysis ppa
      JOIN users u ON ppa.player_id = u.id
      JOIN videos v ON ppa.video_id = v.id
      WHERE ppa.video_id = ${videoId}
      ORDER BY ppa.total_distance DESC
    `);

    res.json(physicalData.rows || []);
  } catch (error) {
    console.error('Error fetching physical performance data:', error);
    res.status(500).json({ 
      message: 'Failed to fetch physical performance data', 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// GET /api/physical-performance/player/:playerId - Get all physical data for a player across matches
router.get('/player/:playerId', async (req, res) => {
  try {
    const playerId = parseInt(req.params.playerId);
    if (isNaN(playerId)) {
      return res.status(400).json({ message: 'Invalid player ID' });
    }

    const physicalData = await db.execute(sql`
      SELECT 
        ppa.*,
        v.title as match_title,
        v.opponent,
        v.match_date,
        v.home_away
      FROM physical_performance_analysis ppa
      JOIN videos v ON ppa.video_id = v.id
      WHERE ppa.player_id = ${playerId}
      ORDER BY ppa.match_date DESC
    `);

    res.json(physicalData.rows || []);
  } catch (error) {
    console.error('Error fetching player physical data:', error);
    res.status(500).json({ 
      message: 'Failed to fetch player physical data', 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// POST /api/physical-performance/analyze/:videoId - Trigger physical analysis for a match
router.post('/analyze/:videoId', async (req, res) => {
  try {
    const videoId = parseInt(req.params.videoId);
    if (isNaN(videoId)) {
      return res.status(400).json({ message: 'Invalid video ID' });
    }

    // Get video and team info
    const videoResult = await db.execute(sql`
      SELECT v.*, t.name as team_name 
      FROM videos v 
      JOIN teams t ON v.team_id = t.id 
      WHERE v.id = ${videoId}
    `);

    if (!videoResult.rows || videoResult.rows.length === 0) {
      return res.status(404).json({ message: 'Video not found' });
    }

    const video = videoResult.rows[0];

    // Get players for this team
    const playersResult = await db.execute(sql`
      SELECT id, first_name, last_name, jersey_number 
      FROM users 
      WHERE team_id = ${video.team_id} AND role = 'player'
    `);

    const players = playersResult.rows || [];

    // Simulate physical analysis process
    setTimeout(async () => {
      try {
        // Create physical performance analysis table if needed
        await db.execute(sql`
          CREATE TABLE IF NOT EXISTS physical_performance_analysis (
            id SERIAL PRIMARY KEY,
            video_id INTEGER REFERENCES videos(id),
            player_id INTEGER REFERENCES users(id),
            match_date TIMESTAMP,
            opponent VARCHAR(255),
            home_away VARCHAR(10),
            
            -- Distance Metrics
            total_distance DECIMAL(8,2),
            distance_q1 DECIMAL(6,2),
            distance_q2 DECIMAL(6,2),
            distance_q3 DECIMAL(6,2),
            distance_q4 DECIMAL(6,2),
            distance_first_half DECIMAL(6,2),
            distance_second_half DECIMAL(6,2),
            
            -- Speed Metrics
            max_speed DECIMAL(5,2),
            avg_speed DECIMAL(5,2),
            
            -- Sprint Analysis
            sprints_0_5_kmh INTEGER DEFAULT 0,
            sprints_5_10_kmh INTEGER DEFAULT 0,
            sprints_10_15_kmh INTEGER DEFAULT 0,
            sprints_15_20_kmh INTEGER DEFAULT 0,
            sprints_20_25_kmh INTEGER DEFAULT 0,
            sprints_25_30_kmh INTEGER DEFAULT 0,
            sprints_above_30_kmh INTEGER DEFAULT 0,
            total_sprints INTEGER DEFAULT 0,
            
            -- Acceleration/Deceleration
            accelerations_count INTEGER DEFAULT 0,
            decelerations_count INTEGER DEFAULT 0,
            
            -- High Intensity Running
            high_intensity_distance DECIMAL(6,2),
            
            -- Heart Rate Data
            max_heart_rate INTEGER,
            avg_heart_rate INTEGER,
            
            -- Zone Analysis
            zone_defensive_third_time INTEGER,
            zone_middle_third_time INTEGER,
            zone_attacking_third_time INTEGER,
            
            -- Workload Metrics
            workload_score INTEGER,
            fatigue_level INTEGER,
            recovery_time INTEGER,
            
            -- Match Context
            minutes_played INTEGER,
            position VARCHAR(50),
            jersey_number INTEGER,
            
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
          )
        `);

        // Generate realistic physical data for each player
        for (const player of players) {
          // Simulate different performance based on position
          const isDefender = Math.random() < 0.3;
          const isMidfielder = Math.random() < 0.4;
          const isForward = !isDefender && !isMidfielder;

          const baseDistance = isDefender ? 9500 : isMidfielder ? 11200 : 10800;
          const totalDistance = baseDistance + (Math.random() * 1500 - 750); // ±750m variation

          const baseMaxSpeed = isDefender ? 26 : isMidfielder ? 28 : 30;
          const maxSpeed = baseMaxSpeed + (Math.random() * 4 - 2); // ±2 km/h variation

          const avgSpeed = totalDistance / 5400 * 3.6; // convert to km/h for 90 minutes

          // Quarter distances (roughly equal with some variation)
          const q1Distance = totalDistance * (0.25 + (Math.random() * 0.1 - 0.05));
          const q2Distance = totalDistance * (0.25 + (Math.random() * 0.1 - 0.05));
          const q3Distance = totalDistance * (0.25 + (Math.random() * 0.1 - 0.05));
          const q4Distance = totalDistance - q1Distance - q2Distance - q3Distance;

          // Sprint distribution based on speed zones
          const totalSprints = Math.floor(Math.random() * 20 + 5);
          const sprints0to5 = Math.floor(totalSprints * 0.1);
          const sprints5to10 = Math.floor(totalSprints * 0.15);
          const sprints10to15 = Math.floor(totalSprints * 0.25);
          const sprints15to20 = Math.floor(totalSprints * 0.25);
          const sprints20to25 = Math.floor(totalSprints * 0.15);
          const sprints25to30 = Math.floor(totalSprints * 0.08);
          const sprintsAbove30 = totalSprints - sprints0to5 - sprints5to10 - sprints10to15 - sprints15to20 - sprints20to25 - sprints25to30;

          const highIntensityDistance = totalDistance * (0.15 + Math.random() * 0.1); // 15-25% of total

          const accelerations = Math.floor(Math.random() * 30 + 20);
          const decelerations = Math.floor(Math.random() * 25 + 15);

          // Heart rate data
          const maxHR = Math.floor(190 + Math.random() * 15);
          const avgHR = Math.floor(maxHR * (0.75 + Math.random() * 0.15)); // 75-90% of max

          // Zone time distribution (in seconds, total ~5400 for 90 minutes)
          const defensiveTime = isDefender ? 2500 + Math.random() * 500 : 1200 + Math.random() * 400;
          const attackingTime = isForward ? 2000 + Math.random() * 400 : 800 + Math.random() * 300;
          const middleTime = 5400 - defensiveTime - attackingTime;

          // Workload and fatigue
          const workloadScore = Math.floor(300 + (totalDistance / 100) + (totalSprints * 10) + Math.random() * 100);
          const fatigueLevel = Math.floor(Math.random() * 6 + 2); // 2-8 scale
          const recoveryTime = Math.floor(fatigueLevel * 3 + Math.random() * 6); // 6-30 hours

          await db.execute(sql`
            INSERT INTO physical_performance_analysis (
              video_id, player_id, match_date, opponent, home_away,
              total_distance, distance_q1, distance_q2, distance_q3, distance_q4,
              distance_first_half, distance_second_half, max_speed, avg_speed,
              sprints_0_5_kmh, sprints_5_10_kmh, sprints_10_15_kmh, sprints_15_20_kmh,
              sprints_20_25_kmh, sprints_25_30_kmh, sprints_above_30_kmh, total_sprints,
              accelerations_count, decelerations_count, high_intensity_distance,
              max_heart_rate, avg_heart_rate, zone_defensive_third_time,
              zone_middle_third_time, zone_attacking_third_time, workload_score,
              fatigue_level, recovery_time, minutes_played, position, jersey_number
            ) VALUES (
              ${videoId}, ${player.id}, ${video.match_date || new Date().toISOString()}, 
              ${video.opponent || 'Unknown'}, ${video.home_away || 'home'},
              ${totalDistance.toFixed(2)}, ${q1Distance.toFixed(2)}, ${q2Distance.toFixed(2)}, 
              ${q3Distance.toFixed(2)}, ${q4Distance.toFixed(2)}, 
              ${(q1Distance + q2Distance).toFixed(2)}, ${(q3Distance + q4Distance).toFixed(2)},
              ${maxSpeed.toFixed(2)}, ${avgSpeed.toFixed(2)},
              ${sprints0to5}, ${sprints5to10}, ${sprints10to15}, ${sprints15to20},
              ${sprints20to25}, ${sprints25to30}, ${sprintsAbove30}, ${totalSprints},
              ${accelerations}, ${decelerations}, ${highIntensityDistance.toFixed(2)},
              ${maxHR}, ${avgHR}, ${Math.floor(defensiveTime)}, ${Math.floor(middleTime)}, 
              ${Math.floor(attackingTime)}, ${workloadScore}, ${fatigueLevel}, ${recoveryTime},
              90, ${isDefender ? 'Defender' : isMidfielder ? 'Midfielder' : 'Forward'}, 
              ${player.jersey_number || Math.floor(Math.random() * 23 + 1)}
            )
          `);
        }

        // Update video status
        await db.execute(sql`
          UPDATE videos 
          SET analysis_status = 'completed' 
          WHERE id = ${videoId}
        `);

        console.log(`Physical performance analysis completed for video ${videoId}`);
      } catch (error) {
        console.error('Error in physical performance analysis:', error);
        await db.execute(sql`
          UPDATE videos 
          SET analysis_status = 'failed' 
          WHERE id = ${videoId}
        `);
      }
    }, 3000); // 3 second delay to simulate processing

    res.json({ 
      message: 'Physical performance analysis started', 
      status: 'analyzing',
      estimatedTime: '2-3 minutes'
    });
  } catch (error) {
    console.error('Error starting physical analysis:', error);
    res.status(500).json({ 
      message: 'Failed to start physical analysis', 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// GET /api/physical-performance/workload/:playerId - Get workload analysis for a player
router.get('/workload/:playerId', async (req, res) => {
  try {
    const playerId = parseInt(req.params.playerId);
    if (isNaN(playerId)) {
      return res.status(400).json({ message: 'Invalid player ID' });
    }

    const workloadData = await db.execute(sql`
      SELECT 
        DATE_TRUNC('week', match_date) as week_start,
        AVG(workload_score) as avg_workload,
        AVG(fatigue_level) as avg_fatigue,
        AVG(recovery_time) as avg_recovery,
        COUNT(*) as matches_played,
        SUM(total_distance) as total_distance_week
      FROM physical_performance_analysis 
      WHERE player_id = ${playerId}
      AND match_date >= NOW() - INTERVAL '12 weeks'
      GROUP BY DATE_TRUNC('week', match_date)
      ORDER BY week_start DESC
    `);

    res.json(workloadData.rows || []);
  } catch (error) {
    console.error('Error fetching workload data:', error);
    res.status(500).json({ 
      message: 'Failed to fetch workload data', 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

export default router;