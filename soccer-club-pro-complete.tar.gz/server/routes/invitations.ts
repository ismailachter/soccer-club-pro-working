import type { Express } from "express";
import bcrypt from "bcryptjs";
import { storage } from "../storage";
import { sendInvitationEmail } from "../email-service";

export function registerInvitationRoutes(app: Express) {
  // Send invitation
  app.post("/api/invitations/send", async (req, res) => {
    try {
      const { email, firstName, lastName, role, message } = req.body;

      // Validate required fields
      if (!email || !firstName || !lastName || !role) {
        return res.status(400).json({ 
          error: "Email, firstName, lastName, and role are required" 
        });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ 
          error: "Er bestaat al een gebruiker met dit email adres" 
        });
      }

      // Generate temporary password
      const tempPassword = Math.random().toString(36).slice(-12) + "!";
      const hashedPassword = await bcrypt.hash(tempPassword, 10);

      // Create user with pending status
      const newUser = await storage.createUser({
        email,
        firstName,
        lastName,
        role: role as any,
        password: hashedPassword,
        isActive: false, // User must activate account
      });

      // Send invitation email
      try {
        await sendInvitationEmail({
          to: email,
          firstName,
          lastName,
          role,
          tempPassword,
          customMessage: message,
          loginUrl: `${req.protocol}://${req.get('host')}`
        });

        res.json({
          success: true,
          message: "Uitnodiging succesvol verzonden",
          userId: newUser.id
        });
      } catch (emailError) {
        console.error("Email sending failed:", emailError);
        
        // Delete the created user if email fails
        await storage.deleteUser(newUser.id);
        
        res.status(500).json({
          error: "Uitnodiging kon niet worden verzonden via email"
        });
      }
    } catch (error) {
      console.error("Invitation error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  // Activate invited user account
  app.post("/api/invitations/activate", async (req, res) => {
    try {
      const { email, tempPassword, newPassword } = req.body;

      if (!email || !tempPassword || !newPassword) {
        return res.status(400).json({ 
          error: "Email, temporary password, and new password are required" 
        });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).json({ error: "Gebruiker niet gevonden" });
      }

      // Verify temporary password
      const isValidTemp = await bcrypt.compare(tempPassword, user.password);
      if (!isValidTemp) {
        return res.status(400).json({ error: "Ongeldig tijdelijk wachtwoord" });
      }

      // Hash new password and activate account
      const hashedNewPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(user.id, {
        password: hashedNewPassword,
        isActive: true
      });

      res.json({
        success: true,
        message: "Account succesvol geactiveerd"
      });
    } catch (error) {
      console.error("Activation error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });
}