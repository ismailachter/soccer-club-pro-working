import nodemailer from 'nodemailer';

export async function sendOneComEmail(email: string, name: string) {
  const transporter = nodemailer.createTransport({
    host: 'send.one.com',
    port: 465,
    secure: true,
    auth: {
      user: 'info@soccerclubpro.com',
      pass: process.env.ONECOM_EMAIL_PASSWORD || 'Qunoot136!'
    },
    tls: {
      rejectUnauthorized: false
    }
  });

  // Verify connection
  await transporter.verify();
  console.log('✅ One.com SMTP verified successfully');

  const result = await transporter.sendMail({
    from: 'Soccer Club Pro <info@soccerclubpro.com>',
    to: email,
    cc: 'ismail.achter@gmail.com',
    subject: 'Soccer Club Pro - Professional Account Invitation',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 2px solid #1a365d;">
        <div style="background: linear-gradient(135deg, #1a365d 0%, #2c5282 100%); color: white; padding: 30px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px; font-weight: bold;">Soccer Club Pro</h1>
          <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;">Professional Club Management Platform</p>
        </div>
        
        <div style="padding: 40px; background: white;">
          <h2 style="color: #1a365d; margin: 0 0 20px 0; font-size: 22px;">Welcome to Soccer Club Pro, ${name}!</h2>
          
          <p style="color: #4a5568; line-height: 1.6; margin: 0 0 20px 0;">
            You've been invited to join our professional soccer club management platform. Experience comprehensive team management, training planning, and player development tools.
          </p>
          
          <div style="background: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #1a365d; margin: 0 0 15px 0; font-size: 18px;">Platform Features:</h3>
            <ul style="color: #4a5568; margin: 0; padding-left: 20px;">
              <li>Complete IADATABANK training methodology (203 elements)</li>
              <li>Professional year planning and calendar management</li>
              <li>Player database and scouting system</li>
              <li>Team management and match scheduling</li>
              <li>Professional PDF exports and reporting</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="https://soccerclubpro.com" 
               style="background: linear-gradient(135deg, #1a365d 0%, #2c5282 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block; font-size: 16px;">
              Access Soccer Club Pro Platform
            </a>
          </div>
          
          <p style="color: #718096; font-size: 14px; margin: 20px 0 0 0;">
            Your account has been created with read-only access. Contact your administrator for additional permissions.
          </p>
        </div>
        
        <div style="background: #1a365d; color: white; padding: 20px; text-align: center;">
          <p style="margin: 0; font-size: 14px;">
            Soccer Club Pro - Professional Club Management<br>
            <a href="https://soccerclubpro.com" style="color: #90cdf4; text-decoration: none;">soccerclubpro.com</a> | 
            <span style="color: #90cdf4;">#teamworkmakesthedreamwork</span>
          </p>
        </div>
      </div>
    `
  });

  return result;
}