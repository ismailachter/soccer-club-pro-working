import { db } from './db';
import { chatSessions } from '@shared/schema';
import { eq, and } from 'drizzle-orm';

export class ChatAssistantService {
  
  // Generate 8-character session ID
  private async generateSessionId(): Promise<string> {
    let attempts = 0;
    while (attempts < 100) {
      const id = Math.random().toString(36).substring(2, 10).toUpperCase();
      const existing = await db.select().from(chatSessions).where(eq(chatSessions.id, id));
      if (existing.length === 0) return id;
      attempts++;
    }
    throw new Error('Unable to generate unique session ID');
  }

  // Start new chat session
  async startChatSession(clubId: number, userId?: string, sessionType: string = 'general', moduleContext?: string) {
    const sessionId = await this.generateSessionId();
    
    const welcomeMessage = this.getWelcomeMessage(sessionType, moduleContext);
    
    const [session] = await db.insert(chatSessions).values({
      id: sessionId,
      clubId,
      userId,
      sessionType,
      moduleContext,
      messages: [welcomeMessage],
      status: 'active'
    }).returning();

    console.log(`💬 Chat session ${sessionId} started for club ${clubId}, type: ${sessionType}`);
    return session;
  }

  // Add message to chat session
  async addMessage(sessionId: string, sender: 'user' | 'assistant', message: string) {
    const [session] = await db.select().from(chatSessions).where(eq(chatSessions.id, sessionId));
    
    if (!session) {
      throw new Error('Chat session not found');
    }

    const newMessage = {
      sender,
      message,
      timestamp: new Date().toISOString()
    };

    const updatedMessages = [...(session.messages || []), newMessage];
    
    await db.update(chatSessions)
      .set({ 
        messages: updatedMessages,
        status: 'active'
      })
      .where(eq(chatSessions.id, sessionId));

    // Generate assistant response if user message
    if (sender === 'user') {
      const response = await this.generateResponse(message, session.sessionType, session.moduleContext);
      await this.addMessage(sessionId, 'assistant', response);
    }

    return newMessage;
  }

  // Generate contextual welcome messages
  private getWelcomeMessage(sessionType: string, moduleContext?: string) {
    const welcomeMessages = {
      onboarding: {
        sender: 'assistant' as const,
        message: "Welkom bij Soccer Club Pro! Ik ben hier om je te helpen met de eerste stappen. Wat wil je als eerste instellen?",
        timestamp: new Date().toISOString()
      },
      module_help: {
        sender: 'assistant' as const,
        message: `Hallo! Ik help je graag met de ${moduleContext} module. Wat voor hulp heb je nodig?`,
        timestamp: new Date().toISOString()
      },
      inscription_help: {
        sender: 'assistant' as const,
        message: "Hallo! Ik help je graag met de inscriptie database. Wil je nieuwe gebruikers aanmaken, inscripties beheren, of iets anders?",
        timestamp: new Date().toISOString()
      },
      general: {
        sender: 'assistant' as const,
        message: "Hallo! Ik ben je Soccer Club Pro assistent. Hoe kan ik je vandaag helpen?",
        timestamp: new Date().toISOString()
      }
    };

    return welcomeMessages[sessionType as keyof typeof welcomeMessages] || welcomeMessages.general;
  }

  // Generate intelligent responses based on context
  private async generateResponse(userMessage: string, sessionType: string, moduleContext?: string): Promise<string> {
    const message = userMessage.toLowerCase();
    
    // Context-aware responses
    if (sessionType === 'onboarding') {
      return this.getOnboardingResponse(message);
    }
    
    if (sessionType === 'module_help') {
      return this.getModuleHelpResponse(message, moduleContext);
    }
    
    if (sessionType === 'inscription_help') {
      return this.getInscriptionHelpResponse(message);
    }

    return this.getGeneralResponse(message);
  }

  private getOnboardingResponse(message: string): string {
    if (message.includes('team') || message.includes('ploeg')) {
      return "Perfect! Om te beginnen met teams, ga naar 'Teams' in het menu. Daar kun je nieuwe teams aanmaken, spelers toewijzen en trainingsschema's opstellen. Wil je dat ik je stap voor stap door dit proces leid?";
    }
    
    if (message.includes('speler') || message.includes('player')) {
      return "Geweldig! Voor spelersbeheer ga je naar 'Spelers Database'. Hier kun je spelers toevoegen, gegevens bijwerken en teams toewijzen. Zal ik je laten zien hoe je je eerste spelers toevoegt?";
    }
    
    if (message.includes('training') || message.includes('oefening')) {
      return "Mooi! Voor trainingen heb je toegang tot onze IADATABANK met 196+ professionele oefeningen. Ga naar 'Training & Planning' om te beginnen. Wil je hulp bij het maken van je eerste trainingsplanning?";
    }
    
    return "Ik kan je helpen met teams instellen, spelers toevoegen, trainingen plannen, of andere functionaliteiten. Wat interesseert je het meest om mee te beginnen?";
  }

  private getModuleHelpResponse(message: string, moduleContext?: string): string {
    const moduleResponses = {
      player_management: {
        'toevoegen': "Om spelers toe te voegen, klik op 'Nieuwe Speler' in de Spelers Database. Vul de basisgegevens in zoals naam, leeftijd, positie en contactinfo. Wil je dat ik je door de specifieke velden leid?",
        'scout': "In de Scout Database kun je potentiële spelers bijhouden. Voeg notities toe over hun prestaties, contactgegevens van ouders, en follow-up data. Heb je specifieke vragen over het scout proces?",
        'default': "Ik kan je helpen met spelers toevoegen, teams toewijzen, scout database beheren, of exports maken. Wat wil je doen?"
      },
      training_planning: {
        'iadatabank': "De IADATABANK bevat 196 professionele oefeningen verdeeld over 4 categorieën: BASICS, TEAMTACTISCH, FYSIEK en MENTAAL. Elk element heeft gedetailleerde uitleg en doelstellingen. Welke categorie interesseert je?",
        'planning': "Voor jaarplanning kun je trainingen inplannen over het hele seizoen. Kies thema's uit de IADATABANK en plan ze op specifieke data. Wil je hulp bij het opstellen van een planning?",
        'pdf': "Je kunt professionele PDF kalenders exporteren van je jaarplanning. Deze bevatten alle training details, tijden en thema's. Zal ik je laten zien hoe dat werkt?",
        'default': "Ik help je graag met de IADATABANK, jaarplanning, training sessies maken, of PDF exports. Waar wil je mee beginnen?"
      }
    };

    const moduleKey = moduleContext as keyof typeof moduleResponses;
    const responses = moduleResponses[moduleKey];
    
    if (responses) {
      for (const [keyword, response] of Object.entries(responses)) {
        if (keyword !== 'default' && message.includes(keyword)) {
          return response;
        }
      }
      return responses.default;
    }

    return `Ik help je graag met de ${moduleContext} module. Kun je me vertellen wat je specifiek wilt doen?`;
  }

  private getInscriptionHelpResponse(message: string): string {
    if (message.includes('gebruiker') || message.includes('user') || message.includes('account')) {
      return "Om nieuwe gebruikers aan te maken, gebruik je het User Management systeem. Elke gebruiker krijgt een uniek 5-cijferig ID, kan verschillende rollen hebben (admin, coach, parent, player), en heeft volledige wachtwoord functies. Wil je dat ik je door het proces leid?";
    }
    
    if (message.includes('wachtwoord') || message.includes('password') || message.includes('vergeten')) {
      return "Voor wachtwoord beheer hebben we een complete reset functie. Gebruikers kunnen zelf een reset aanvragen via hun email, krijgen een beveiligde token, en kunnen dan een nieuw wachtwoord instellen. Wil je weten hoe je dit instelt?";
    }
    
    if (message.includes('inscriptie') || message.includes('registration')) {
      return "De inscriptie database houdt alle aanmeldingen bij met 5-cijferige ID's, volledige speler- en oudergegevens, medical info, en payment status. Je kunt inscripties goedkeuren, afwijzen, of bijwerken. Wat wil je specifiek doen?";
    }
    
    return "Ik kan je helpen met gebruikers aanmaken, wachtwoord beheer, inscripties verwerken, of gebruikersrechten instellen. Waar heb je hulp bij nodig?";
  }

  private getGeneralResponse(message: string): string {
    if (message.includes('export') || message.includes('download')) {
      return "Voor exports hebben we verschillende opties: gratis Excel export van je eigen spelers, en premium exports (PDF, PowerPoint, ICS) voor betalende klanten. VVC Brasschaat heeft gratis toegang tot alles. Welk type export heb je nodig?";
    }
    
    if (message.includes('help') || message.includes('hulp')) {
      return "Ik kan je helpen met alle aspecten van Soccer Club Pro: teams beheren, spelers toevoegen, trainingen plannen, inscripties verwerken, en veel meer. Vertel me waar je aan werkt!";
    }
    
    if (message.includes('module') || message.includes('subscription')) {
      return "Soccer Club Pro heeft 9 modules beschikbaar, van basis club management tot geavanceerde analytics. VVC Brasschaat heeft gratis toegang als pilootproject. Andere clubs kunnen modules huren. Wil je meer weten over specifieke modules?";
    }
    
    return "Bedankt voor je vraag! Ik doe mijn best om je te helpen. Kun je me wat meer details geven over wat je wilt doen in Soccer Club Pro?";
  }

  // Complete chat session
  async completeSession(sessionId: string, rating?: number, feedback?: string) {
    await db.update(chatSessions)
      .set({
        status: 'completed',
        completedAt: new Date(),
        satisfactionRating: rating,
        feedback
      })
      .where(eq(chatSessions.id, sessionId));

    console.log(`✅ Chat session ${sessionId} completed with rating: ${rating}`);
  }

  // Get session history
  async getSessionHistory(clubId: number, userId?: string) {
    let query = db.select().from(chatSessions).where(eq(chatSessions.clubId, clubId));
    
    if (userId) {
      query = query.where(and(eq(chatSessions.clubId, clubId), eq(chatSessions.userId, userId)));
    }
    
    return await query;
  }
}