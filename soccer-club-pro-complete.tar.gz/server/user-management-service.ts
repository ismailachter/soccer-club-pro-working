import { db } from './db';
import { clubUsers, passwordResets, clubs } from '@shared/schema';
import { eq, and, gt } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';

export class UserManagementService {
  
  // Generate 5-digit unique user ID
  private async generateUserId(): Promise<string> {
    let attempts = 0;
    const maxAttempts = 100;
    
    while (attempts < maxAttempts) {
      const id = Math.floor(Math.random() * 90000) + 10000;
      const idString = id.toString();
      
      const existing = await db.select()
        .from(clubUsers)
        .where(eq(clubUsers.id, idString));
      
      if (existing.length === 0) {
        return idString;
      }
      
      attempts++;
    }
    
    throw new Error('Unable to generate unique user ID');
  }

  // Create new club user
  async createClubUser(userData: {
    clubId: number;
    userName: string;
    userType: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    phone?: string;
    permissions?: string[];
  }) {
    // Get club name
    const [club] = await db.select()
      .from(clubs)
      .where(eq(clubs.id, userData.clubId));
    
    if (!club) {
      throw new Error('Club not found');
    }

    // Check if email already exists
    const existingUser = await db.select()
      .from(clubUsers)
      .where(eq(clubUsers.email, userData.email));
    
    if (existingUser.length > 0) {
      throw new Error('Email already registered');
    }

    // Generate unique ID and hash password
    const userId = await this.generateUserId();
    const hashedPassword = await bcrypt.hash(userData.password, 12);
    
    // Create user
    const [user] = await db.insert(clubUsers).values({
      id: userId,
      clubId: userData.clubId,
      clubName: club.name,
      userName: userData.userName,
      userType: userData.userType,
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      hashedPassword,
      phone: userData.phone,
      permissions: userData.permissions || [],
      isActive: true,
      emailVerified: false
    }).returning();

    console.log(`✅ User ${userId} (${userData.email}) created for ${club.name}`);
    return { ...user, hashedPassword: undefined }; // Don't return password
  }

  // Authenticate user login
  async authenticateUser(email: string, password: string) {
    const [user] = await db.select()
      .from(clubUsers)
      .where(and(
        eq(clubUsers.email, email),
        eq(clubUsers.isActive, true)
      ));
    
    if (!user) {
      throw new Error('Invalid credentials');
    }

    const isValidPassword = await bcrypt.compare(password, user.hashedPassword);
    if (!isValidPassword) {
      throw new Error('Invalid credentials');
    }

    // Update last login
    await db.update(clubUsers)
      .set({ lastLogin: new Date() })
      .where(eq(clubUsers.id, user.id));

    console.log(`✅ User ${user.id} (${email}) authenticated`);
    return { ...user, hashedPassword: undefined };
  }

  // Change user password
  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const [user] = await db.select()
      .from(clubUsers)
      .where(eq(clubUsers.id, userId));
    
    if (!user) {
      throw new Error('User not found');
    }

    const isValidPassword = await bcrypt.compare(currentPassword, user.hashedPassword);
    if (!isValidPassword) {
      throw new Error('Current password is incorrect');
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 12);
    
    await db.update(clubUsers)
      .set({ 
        hashedPassword: hashedNewPassword,
        updatedAt: new Date()
      })
      .where(eq(clubUsers.id, userId));

    console.log(`✅ Password changed for user ${userId}`);
  }

  // Request password reset
  async requestPasswordReset(email: string) {
    const [user] = await db.select()
      .from(clubUsers)
      .where(eq(clubUsers.email, email));
    
    if (!user) {
      throw new Error('User not found');
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 3600000); // 1 hour

    // Save reset token
    await db.insert(passwordResets).values({
      userId: user.id,
      token: resetToken,
      expiresAt
    });

    // Update user with reset token
    await db.update(clubUsers)
      .set({
        resetToken,
        resetTokenExpiry: expiresAt,
        updatedAt: new Date()
      })
      .where(eq(clubUsers.id, user.id));

    console.log(`✅ Password reset requested for ${email}`);
    return { resetToken, user: { ...user, hashedPassword: undefined } };
  }

  // Reset password with token
  async resetPassword(token: string, newPassword: string) {
    const [user] = await db.select()
      .from(clubUsers)
      .where(and(
        eq(clubUsers.resetToken, token),
        gt(clubUsers.resetTokenExpiry, new Date())
      ));
    
    if (!user) {
      throw new Error('Invalid or expired reset token');
    }

    const hashedPassword = await bcrypt.hash(newPassword, 12);
    
    await db.update(clubUsers)
      .set({
        hashedPassword,
        resetToken: null,
        resetTokenExpiry: null,
        updatedAt: new Date()
      })
      .where(eq(clubUsers.id, user.id));

    // Mark reset token as used
    await db.update(passwordResets)
      .set({ usedAt: new Date() })
      .where(eq(passwordResets.token, token));

    console.log(`✅ Password reset completed for user ${user.id}`);
  }

  // Get all users for club
  async getClubUsers(clubId: number, filters?: {
    userType?: string;
    isActive?: boolean;
    search?: string;
  }) {
    let query = db.select({
      id: clubUsers.id,
      clubId: clubUsers.clubId,
      clubName: clubUsers.clubName,
      userName: clubUsers.userName,
      userType: clubUsers.userType,
      firstName: clubUsers.firstName,
      lastName: clubUsers.lastName,
      email: clubUsers.email,
      phone: clubUsers.phone,
      lastLogin: clubUsers.lastLogin,
      isActive: clubUsers.isActive,
      emailVerified: clubUsers.emailVerified,
      permissions: clubUsers.permissions,
      createdAt: clubUsers.createdAt
    }).from(clubUsers)
      .where(eq(clubUsers.clubId, clubId));

    const users = await query;
    return users;
  }

  // Update user details
  async updateUser(userId: string, updateData: {
    userName?: string;
    firstName?: string;
    lastName?: string;
    phone?: string;
    userType?: string;
    permissions?: string[];
    isActive?: boolean;
  }) {
    const [updated] = await db.update(clubUsers)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(clubUsers.id, userId))
      .returning();

    console.log(`✅ User ${userId} updated`);
    return { ...updated, hashedPassword: undefined };
  }

  // Deactivate user
  async deactivateUser(userId: string) {
    await db.update(clubUsers)
      .set({
        isActive: false,
        updatedAt: new Date()
      })
      .where(eq(clubUsers.id, userId));

    console.log(`❌ User ${userId} deactivated`);
  }

  // Get user by ID
  async getUserById(userId: string) {
    const [user] = await db.select({
      id: clubUsers.id,
      clubId: clubUsers.clubId,
      clubName: clubUsers.clubName,
      userName: clubUsers.userName,
      userType: clubUsers.userType,
      firstName: clubUsers.firstName,
      lastName: clubUsers.lastName,
      email: clubUsers.email,
      phone: clubUsers.phone,
      lastLogin: clubUsers.lastLogin,
      isActive: clubUsers.isActive,
      emailVerified: clubUsers.emailVerified,
      permissions: clubUsers.permissions,
      createdAt: clubUsers.createdAt
    }).from(clubUsers)
      .where(eq(clubUsers.id, userId));
    
    return user;
  }

  // User statistics for club
  async getUserStats(clubId: number) {
    const users = await this.getClubUsers(clubId);
    
    const stats = {
      total: users.length,
      active: users.filter(u => u.isActive).length,
      inactive: users.filter(u => !u.isActive).length,
      byType: {} as Record<string, number>,
      verified: users.filter(u => u.emailVerified).length,
      recentLogins: users.filter(u => 
        u.lastLogin && 
        new Date(u.lastLogin) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      ).length
    };

    // Group by user type
    users.forEach(user => {
      const type = user.userType || 'Unassigned';
      stats.byType[type] = (stats.byType[type] || 0) + 1;
    });

    return stats;
  }
}