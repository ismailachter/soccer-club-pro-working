import { db } from './db';
import { clubModules, clubUsers } from '@shared/schema';
import { eq, and } from 'drizzle-orm';

export class SecurityService {
  
  // VVC Brasschaat special access (pilot project)
  private readonly VVC_CLUB_ID = 1;
  
  // Protected operations that cost money for non-VVC clubs
  private readonly PREMIUM_OPERATIONS = {
    PDF_EXPORT: 'pdf_export',
    EXCEL_EXPORT: 'excel_export', 
    ICS_EXPORT: 'ics_export',
    POWERPOINT_EXPORT: 'powerpoint_export',
    BACKUP_DOWNLOAD: 'backup_download',
    JSON_EXPORT: 'json_export',
    API_ACCESS: 'api_access',
    AI_GENERATION: 'ai_generation',
    BULK_OPERATIONS: 'bulk_operations'
  };

  // Forbidden operations for all clubs except VVC
  private readonly FORBIDDEN_OPERATIONS = [
    'source_code_access',
    'database_schema_export',
    'application_download',
    'api_key_access',
    'system_backup',
    'code_extraction',
    'reverse_engineering'
  ];

  // Free operations for all clubs
  private readonly FREE_OPERATIONS = [
    'player_excel_export', // Only own players
    'basic_dashboard_view',
    'user_management',
    'profile_update'
  ];

  // Check if club has access to premium operation
  async hasAccessToPremiumOperation(clubId: number, operation: string): Promise<boolean> {
    // VVC Brasschaat gets everything free (pilot project)
    if (clubId === this.VVC_CLUB_ID) {
      console.log(`✅ VVC Brasschaat - FREE access to ${operation}`);
      return true;
    }

    // Check if it's a forbidden operation
    if (this.FORBIDDEN_OPERATIONS.includes(operation)) {
      console.log(`❌ FORBIDDEN: ${operation} blocked for club ${clubId}`);
      return false;
    }

    // Check if it's a free operation
    if (this.FREE_OPERATIONS.includes(operation)) {
      console.log(`✅ FREE operation: ${operation} allowed for club ${clubId}`);
      return true;
    }

    // Premium operations require payment
    if (Object.values(this.PREMIUM_OPERATIONS).includes(operation)) {
      // Check if club has paid for this feature
      const hasAccess = await this.checkPremiumAccess(clubId, operation);
      if (!hasAccess) {
        console.log(`💰 PREMIUM required: ${operation} needs payment for club ${clubId}`);
        return false;
      }
    }

    return true;
  }

  // Security middleware for API endpoints
  async validateRequest(req: any, operation: string): Promise<{
    allowed: boolean;
    reason?: string;
    requiresPayment?: boolean;
  }> {
    const clubId = req.clubId || 1; // Default to VVC for testing
    const userAgent = req.headers['user-agent'] || '';
    const ip = req.ip || req.connection.remoteAddress;

    // Log security attempt
    console.log(`🔒 Security check: ${operation} for club ${clubId} from IP ${ip}`);

    // Check for suspicious activity
    if (this.detectSuspiciousActivity(userAgent, operation)) {
      console.log(`🚨 SUSPICIOUS ACTIVITY detected: ${operation} from ${userAgent}`);
      return {
        allowed: false,
        reason: 'Suspicious activity detected. Access denied.'
      };
    }

    // Check access permissions
    const hasAccess = await this.hasAccessToPremiumOperation(clubId, operation);
    
    if (!hasAccess) {
      const isPremium = Object.values(this.PREMIUM_OPERATIONS).includes(operation);
      const isForbidden = this.FORBIDDEN_OPERATIONS.includes(operation);
      
      if (isForbidden) {
        return {
          allowed: false,
          reason: 'This operation is not permitted. Contact support for assistance.'
        };
      }
      
      if (isPremium) {
        return {
          allowed: false,
          reason: 'This feature requires a premium subscription.',
          requiresPayment: true
        };
      }
    }

    return { allowed: true };
  }

  // Detect suspicious downloading/extraction attempts
  private detectSuspiciousActivity(userAgent: string, operation: string): boolean {
    const suspiciousPatterns = [
      'curl',
      'wget',
      'python-requests',
      'bot',
      'crawler',
      'scraper',
      'postman',
      'insomnia',
      'automated'
    ];

    const suspiciousOperations = [
      'bulk_download',
      'mass_export', 
      'schema_access',
      'source_code',
      'database_dump'
    ];

    // Check user agent for automation tools
    const hasSuspiciousUA = suspiciousPatterns.some(pattern => 
      userAgent.toLowerCase().includes(pattern.toLowerCase())
    );

    // Check operation type
    const hasSuspiciousOp = suspiciousOperations.some(pattern =>
      operation.toLowerCase().includes(pattern.toLowerCase())
    );

    return hasSuspiciousUA || hasSuspiciousOp;
  }

  // Check premium access (placeholder for payment system)
  private async checkPremiumAccess(clubId: number, operation: string): Promise<boolean> {
    // TODO: Integrate with Stripe/payment system
    // For now, only VVC has premium access
    return clubId === this.VVC_CLUB_ID;
  }

  // Watermark exported content
  addSecurityWatermark(content: any, clubId: number, operation: string): any {
    const timestamp = new Date().toISOString();
    const watermark = {
      generated_by: 'Soccer Club Pro',
      club_id: clubId,
      operation: operation,
      timestamp: timestamp,
      license: 'This content is licensed to the specific club and may not be redistributed.',
      warning: 'Unauthorized use, copying, or distribution is prohibited.'
    };

    // Add watermark based on content type
    if (typeof content === 'object') {
      content._soccerclubpro_license = watermark;
    }

    return content;
  }

  // Rate limiting for API calls
  private requestCounts = new Map<string, { count: number; resetTime: number }>();

  checkRateLimit(clubId: number, operation: string): boolean {
    // VVC gets unlimited requests
    if (clubId === this.VVC_CLUB_ID) {
      return true;
    }

    const key = `${clubId}-${operation}`;
    const now = Date.now();
    const windowMs = 60 * 1000; // 1 minute
    const maxRequests = 10; // 10 requests per minute

    let requestData = this.requestCounts.get(key);
    
    if (!requestData || now > requestData.resetTime) {
      requestData = { count: 1, resetTime: now + windowMs };
      this.requestCounts.set(key, requestData);
      return true;
    }

    if (requestData.count >= maxRequests) {
      console.log(`🚫 RATE LIMIT exceeded for club ${clubId}, operation ${operation}`);
      return false;
    }

    requestData.count++;
    return true;
  }

  // Log security events
  async logSecurityEvent(clubId: number, userId: string, operation: string, status: 'allowed' | 'denied', reason?: string) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      clubId,
      userId,
      operation,
      status,
      reason,
      ip: 'unknown' // Would get from request
    };

    console.log(`🔒 SECURITY LOG:`, logEntry);
    
    // TODO: Store in security_logs table for audit trail
  }

  // Generate secure download token (expires quickly)
  generateSecureDownloadToken(clubId: number, operation: string): string {
    const payload = {
      clubId,
      operation,
      expires: Date.now() + (5 * 60 * 1000) // 5 minutes
    };
    
    return Buffer.from(JSON.stringify(payload)).toString('base64');
  }

  // Validate download token
  validateDownloadToken(token: string): { valid: boolean; clubId?: number; operation?: string } {
    try {
      const payload = JSON.parse(Buffer.from(token, 'base64').toString());
      
      if (Date.now() > payload.expires) {
        return { valid: false };
      }
      
      return {
        valid: true,
        clubId: payload.clubId,
        operation: payload.operation
      };
    } catch {
      return { valid: false };
    }
  }
}