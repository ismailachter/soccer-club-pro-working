import { db } from './db';
import fs from 'fs';
import path from 'path';

interface PlayerSeasonStats {
  playerId: number;
  playerName: string;
  position: string;
  matchesPlayed: number;
  
  // BASICS Cumulative
  basics: {
    ballControl: { total: number; average: number; matches: number[] };
    passing: { total: number; average: number; matches: number[] };
    receiving: { total: number; average: number; matches: number[] };
    dribbling: { total: number; average: number; matches: number[] };
    shooting: { total: number; average: number; matches: number[] };
    heading: { total: number; average: number; matches: number[] };
    overallAverage: number;
  };
  
  // TEAMTACTISCH Cumulative
  tactical: {
    positioning: { total: number; average: number; matches: number[] };
    decisionMaking: { total: number; average: number; matches: number[] };
    teamwork: { total: number; average: number; matches: number[] };
    pressing: { total: number; average: number; matches: number[] };
    defending: { total: number; average: number; matches: number[] };
    attacking: { total: number; average: number; matches: number[] };
    overallAverage: number;
  };
  
  // FYSIEK Cumulative
  physical: {
    totalDistance: { total: number; average: number; matches: number[] };
    avgTopSpeed: { total: number; average: number; matches: number[] };
    totalSprints: { total: number; average: number; matches: number[] };
    totalAccelerations: { total: number; average: number; matches: number[] };
    totalDecelerations: { total: number; average: number; matches: number[] };
    avgIntensity: { total: number; average: number; matches: number[] };
    overallAverage: number;
  };
}

interface TeamSeasonStats {
  teamName: string;
  division: string;
  season: string;
  matchesPlayed: number;
  
  // Team BASICS Average
  teamBasics: {
    ballControl: number;
    passing: number;
    receiving: number;
    dribbling: number;
    shooting: number;
    heading: number;
    overallAverage: number;
  };
  
  // Team TEAMTACTISCH Average
  teamTactical: {
    positioning: number;
    decisionMaking: number;
    teamwork: number;
    pressing: number;
    defending: number;
    attacking: number;
    overallAverage: number;
  };
  
  // Team FYSIEK Average
  teamPhysical: {
    avgDistance: number;
    avgTopSpeed: number;
    avgSprints: number;
    avgAccelerations: number;
    avgDecelerations: number;
    avgIntensity: number;
    overallAverage: number;
  };
  
  playerStats: PlayerSeasonStats[];
}

export class SeasonStatsService {
  
  private loadRealMatchData(): any {
    try {
      const analysisPath = path.join(__dirname, '../uploads/svelta-analysis.json');
      if (fs.existsSync(analysisPath)) {
        const data = fs.readFileSync(analysisPath, 'utf8');
        return JSON.parse(data);
      }
    } catch (error) {
      console.error('Error loading real match data:', error);
    }
    return null;
  }
  
  // Gebruik echte wedstrijddata van Svelta Melsele vs VVC analyse
  private generateSeasonStats(season: string, division: string): TeamSeasonStats {
    const realMatchData = this.loadRealMatchData();
    const players = this.getPlayersForDivision(division);
    const matchesPlayed = division === 'IP' ? 12 : 8;
    
    // Use real VVC player data from Svelta match if available
    const realVVCPlayers = realMatchData?.playerData?.filter(p => p.team === 'VVC Brasschaat A') || [];
    
    const playerStats: PlayerSeasonStats[] = players.map(player => {
      // Find real match data for this player
      const realPlayerData = realVVCPlayers.find(rp => rp.playerName === player.name);
      const playerMatchesPlayed = Math.floor(matchesPlayed * (0.7 + Math.random() * 0.3));
      
      return {
        playerId: player.id,
        playerName: player.name,
        position: player.position,
        matchesPlayed: playerMatchesPlayed,
        
        basics: {
          ballControl: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.basics.ballControl, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          passing: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.basics.passing, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          receiving: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.basics.receiving, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          dribbling: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.basics.dribbling, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          shooting: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.basics.shooting, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          heading: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.basics.heading, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          overallAverage: 0
        },
        
        tactical: {
          positioning: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.tactical.positioning, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          decisionMaking: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.tactical.decisionMaking, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          teamwork: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.tactical.teamwork, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          pressing: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.tactical.pressing, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          defending: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.tactical.defending, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          attacking: realPlayerData ? this.generateSeasonStatFromReal(realPlayerData.tactical.attacking, playerMatchesPlayed) : this.generateStatistic(player.baseSkill + Math.random() * 2),
          overallAverage: 0
        },
        
        physical: {
          totalDistance: realPlayerData ? this.generateSeasonPhysicalFromReal(realPlayerData.physical.distance, playerMatchesPlayed) : this.generatePhysicalStat(8500, 1500, playerMatchesPlayed),
          avgTopSpeed: realPlayerData ? this.generateSeasonPhysicalFromReal(realPlayerData.physical.topSpeed, playerMatchesPlayed) : this.generatePhysicalStat(24, 4, playerMatchesPlayed),
          totalSprints: realPlayerData ? this.generateSeasonPhysicalFromReal(realPlayerData.physical.sprints, playerMatchesPlayed) : this.generatePhysicalStat(15, 8, playerMatchesPlayed),
          totalAccelerations: realPlayerData ? this.generateSeasonPhysicalFromReal(realPlayerData.physical.accelerations, playerMatchesPlayed) : this.generatePhysicalStat(25, 12, playerMatchesPlayed),
          totalDecelerations: realPlayerData ? this.generateSeasonPhysicalFromReal(realPlayerData.physical.decelerations, playerMatchesPlayed) : this.generatePhysicalStat(22, 10, playerMatchesPlayed),
          avgIntensity: realPlayerData ? this.generateSeasonPhysicalFromReal(realPlayerData.physical.intensity, playerMatchesPlayed) : this.generatePhysicalStat(75, 15, playerMatchesPlayed),
          overallAverage: 0
        }
      };
    });

    // Bereken gemiddeldes voor elke speler
    playerStats.forEach(player => {
      player.basics.overallAverage = this.calculateOverallAverage([
        player.basics.ballControl.average,
        player.basics.passing.average,
        player.basics.receiving.average,
        player.basics.dribbling.average,
        player.basics.shooting.average,
        player.basics.heading.average
      ]);
      
      player.tactical.overallAverage = this.calculateOverallAverage([
        player.tactical.positioning.average,
        player.tactical.decisionMaking.average,
        player.tactical.teamwork.average,
        player.tactical.pressing.average,
        player.tactical.defending.average,
        player.tactical.attacking.average
      ]);
      
      player.physical.overallAverage = this.calculateOverallAverage([
        player.physical.totalDistance.average / 1000, // Convert to km for rating
        player.physical.avgTopSpeed.average / 3, // Scale down for 0-10 rating
        player.physical.totalSprints.average / 2,
        player.physical.totalAccelerations.average / 3,
        player.physical.totalDecelerations.average / 3,
        player.physical.avgIntensity.average / 10 // Convert percentage to 0-10
      ]);
    });

    // Bereken team gemiddeldes
    const teamBasics = {
      ballControl: this.calculateTeamAverage(playerStats.map(p => p.basics.ballControl.average)),
      passing: this.calculateTeamAverage(playerStats.map(p => p.basics.passing.average)),
      receiving: this.calculateTeamAverage(playerStats.map(p => p.basics.receiving.average)),
      dribbling: this.calculateTeamAverage(playerStats.map(p => p.basics.dribbling.average)),
      shooting: this.calculateTeamAverage(playerStats.map(p => p.basics.shooting.average)),
      heading: this.calculateTeamAverage(playerStats.map(p => p.basics.heading.average)),
      overallAverage: 0
    };
    teamBasics.overallAverage = this.calculateOverallAverage(Object.values(teamBasics).slice(0, -1));

    const teamTactical = {
      positioning: this.calculateTeamAverage(playerStats.map(p => p.tactical.positioning.average)),
      decisionMaking: this.calculateTeamAverage(playerStats.map(p => p.tactical.decisionMaking.average)),
      teamwork: this.calculateTeamAverage(playerStats.map(p => p.tactical.teamwork.average)),
      pressing: this.calculateTeamAverage(playerStats.map(p => p.tactical.pressing.average)),
      defending: this.calculateTeamAverage(playerStats.map(p => p.tactical.defending.average)),
      attacking: this.calculateTeamAverage(playerStats.map(p => p.tactical.attacking.average)),
      overallAverage: 0
    };
    teamTactical.overallAverage = this.calculateOverallAverage(Object.values(teamTactical).slice(0, -1));

    const teamPhysical = {
      avgDistance: this.calculateTeamAverage(playerStats.map(p => p.physical.totalDistance.average)),
      avgTopSpeed: this.calculateTeamAverage(playerStats.map(p => p.physical.avgTopSpeed.average)),
      avgSprints: this.calculateTeamAverage(playerStats.map(p => p.physical.totalSprints.average)),
      avgAccelerations: this.calculateTeamAverage(playerStats.map(p => p.physical.totalAccelerations.average)),
      avgDecelerations: this.calculateTeamAverage(playerStats.map(p => p.physical.totalDecelerations.average)),
      avgIntensity: this.calculateTeamAverage(playerStats.map(p => p.physical.avgIntensity.average)),
      overallAverage: 0
    };
    teamPhysical.overallAverage = this.calculateOverallAverage([
      teamPhysical.avgDistance / 1000,
      teamPhysical.avgTopSpeed / 3,
      teamPhysical.avgSprints / 2,
      teamPhysical.avgAccelerations / 3,
      teamPhysical.avgDecelerations / 3,
      teamPhysical.avgIntensity / 10
    ]);

    return {
      teamName: `VVC Brasschaat ${division}`,
      division,
      season,
      matchesPlayed,
      teamBasics,
      teamTactical,
      teamPhysical,
      playerStats
    };
  }

  private getPlayersForDivision(division: string) {
    const ipPlayers = [
      { id: 1, name: 'Emma Janssen', position: 'Keeper', baseSkill: 7.5 },
      { id: 2, name: 'Lisa Van Der Berg', position: 'Verdediger', baseSkill: 7.8 },
      { id: 3, name: 'Sarah Willems', position: 'Verdediger', baseSkill: 7.2 },
      { id: 4, name: 'Mieke Peeters', position: 'Verdediger', baseSkill: 7.6 },
      { id: 5, name: 'Nele Verstappen', position: 'Middenvelder', baseSkill: 8.2 },
      { id: 6, name: 'Katrien Claes', position: 'Middenvelder', baseSkill: 7.9 },
      { id: 7, name: 'Jolien Vermeulen', position: 'Middenvelder', baseSkill: 7.4 },
      { id: 8, name: 'Anouk Hendrickx', position: 'Middenvelder', baseSkill: 8.1 },
      { id: 9, name: 'Femke Lemmens', position: 'Aanvaller', baseSkill: 8.3 },
      { id: 10, name: 'Lotte Vandeputte', position: 'Aanvaller', baseSkill: 7.7 },
      { id: 11, name: 'Senna Goossens', position: 'Aanvaller', baseSkill: 8.0 },
      { id: 12, name: 'Amber Verhulst', position: 'Verdediger', baseSkill: 7.3 },
      { id: 13, name: 'Tessa Martens', position: 'Middenvelder', baseSkill: 7.8 },
      { id: 14, name: 'Lien Coppens', position: 'Aanvaller', baseSkill: 7.9 },
      { id: 15, name: 'Jona Mertens', position: 'Keeper', baseSkill: 7.1 }
    ];

    const beloftenPlayers = [
      { id: 16, name: 'Lynn Vanhove', position: 'Keeper', baseSkill: 6.8 },
      { id: 17, name: 'Fien Lenaerts', position: 'Verdediger', baseSkill: 6.9 },
      { id: 18, name: 'Lore Jacobs', position: 'Verdediger', baseSkill: 6.7 },
      { id: 19, name: 'Demi Wauters', position: 'Middenvelder', baseSkill: 7.1 },
      { id: 20, name: 'Britt Wouters', position: 'Middenvelder', baseSkill: 6.8 },
      { id: 21, name: 'Lara Desmet', position: 'Aanvaller', baseSkill: 7.2 },
      { id: 22, name: 'Eline Vanhees', position: 'Aanvaller', baseSkill: 6.9 },
      { id: 23, name: 'Noa Swinnen', position: 'Verdediger', baseSkill: 6.6 },
      { id: 24, name: 'Fleur Bamps', position: 'Middenvelder', baseSkill: 7.0 },
      { id: 25, name: 'Roos Thijs', position: 'Aanvaller', baseSkill: 6.8 }
    ];

    const u20Players = [
      { id: 26, name: 'Jade Winters', position: 'Keeper', baseSkill: 6.2 },
      { id: 27, name: 'Lotte Verstraeten', position: 'Verdediger', baseSkill: 6.4 },
      { id: 28, name: 'Kato Smets', position: 'Verdediger', baseSkill: 6.1 },
      { id: 29, name: 'Yana Geerts', position: 'Middenvelder', baseSkill: 6.8 },
      { id: 30, name: 'Noor Anthonis', position: 'Middenvelder', baseSkill: 6.5 },
      { id: 31, name: 'Zara Willems', position: 'Aanvaller', baseSkill: 6.9 },
      { id: 32, name: 'Lisa Dams', position: 'Aanvaller', baseSkill: 6.3 },
      { id: 33, name: 'Mila Brands', position: 'Verdediger', baseSkill: 6.0 },
      { id: 34, name: 'Lien Storms', position: 'Middenvelder', baseSkill: 6.6 },
      { id: 35, name: 'Eva Goris', position: 'Aanvaller', baseSkill: 6.4 }
    ];

    switch (division) {
      case 'IP':
        return ipPlayers;
      case 'Beloften':
        return beloftenPlayers;
      case 'U20':
        return u20Players;
      default:
        return ipPlayers;
    }
  }

  private generateStatistic(baseValue: number): { total: number; average: number; matches: number[] } {
    const matches: number[] = [];
    const numMatches = 8 + Math.floor(Math.random() * 5); // 8-12 wedstrijden
    
    for (let i = 0; i < numMatches; i++) {
      const variation = (Math.random() - 0.5) * 2; // -1 tot +1 variatie
      const matchValue = Math.max(0, Math.min(10, baseValue + variation));
      matches.push(Math.round(matchValue * 10) / 10);
    }
    
    const total = matches.reduce((sum, val) => sum + val, 0);
    const average = total / matches.length;
    
    return { total, average, matches };
  }

  private generatePhysicalStat(baseValue: number, variation: number, matchesPlayed: number): { total: number; average: number; matches: number[] } {
    const matches: number[] = [];
    
    for (let i = 0; i < matchesPlayed; i++) {
      const matchValue = baseValue + (Math.random() - 0.5) * variation;
      matches.push(Math.round(matchValue));
    }
    
    const total = matches.reduce((sum, val) => sum + val, 0);
    const average = total / matches.length;
    
    return { total, average, matches };
  }

  private calculateOverallAverage(values: number[]): number {
    const sum = values.reduce((acc, val) => acc + val, 0);
    return Math.round((sum / values.length) * 10) / 10;
  }

  private calculateTeamAverage(values: number[]): number {
    const sum = values.reduce((acc, val) => acc + val, 0);
    return Math.round((sum / values.length) * 10) / 10;
  }

  private generateSeasonStatFromReal(realValue: number, matchesPlayed: number): { total: number; average: number; matches: number[] } {
    const matches: number[] = [];
    
    for (let i = 0; i < matchesPlayed; i++) {
      // Use real value as baseline with small variations for other matches
      const variation = (Math.random() - 0.5) * 1.0; // ±0.5 variation
      const matchValue = Math.max(0, Math.min(10, realValue + variation));
      matches.push(Math.round(matchValue * 10) / 10);
    }
    
    const total = matches.reduce((sum, val) => sum + val, 0);
    const average = total / matches.length;
    
    return { total, average, matches };
  }

  private generateSeasonPhysicalFromReal(realValue: number, matchesPlayed: number): { total: number; average: number; matches: number[] } {
    const matches: number[] = [];
    
    for (let i = 0; i < matchesPlayed; i++) {
      // Use real value as baseline with realistic match variations
      const variation = realValue * 0.1 * (Math.random() - 0.5); // ±5% variation
      const matchValue = Math.round(realValue + variation);
      matches.push(matchValue);
    }
    
    const total = matches.reduce((sum, val) => sum + val, 0);
    const average = total / matches.length;
    
    return { total, average, matches };
  }

  async getSeasonStats(season: string, division: string): Promise<TeamSeasonStats> {
    // Voor nu genereren we data, later kunnen we dit uit de database halen
    return this.generateSeasonStats(season, division);
  }

  async getSeasonComparison(playerId: number, seasons: string[]): Promise<any> {
    // Vergelijk prestaties tussen seizoenen
    const comparisons = seasons.map(season => {
      const stats = this.generateSeasonStats(season, 'IP');
      const player = stats.playerStats.find(p => p.playerId === playerId);
      return {
        season,
        basics: player?.basics.overallAverage || 0,
        tactical: player?.tactical.overallAverage || 0,
        physical: player?.physical.overallAverage || 0
      };
    });
    
    return comparisons;
  }

  async getTopPerformers(season: string, division: string, category: 'basics' | 'tactical' | 'physical'): Promise<any[]> {
    const stats = await this.getSeasonStats(season, division);
    
    return stats.playerStats
      .sort((a, b) => b[category].overallAverage - a[category].overallAverage)
      .slice(0, 5)
      .map(player => ({
        playerName: player.playerName,
        position: player.position,
        average: player[category].overallAverage,
        matchesPlayed: player.matchesPlayed
      }));
  }
}

export const seasonStatsService = new SeasonStatsService();