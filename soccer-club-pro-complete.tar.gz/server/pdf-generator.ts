import { jsPDF } from 'jspdf';
import * as fs from 'fs';
import * as path from 'path';

// Modern PDF generation with club branding

// Function to convert hex color to RGB
function hexToRgb(hex: string): [number, number, number] {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? [
    parseInt(result[1], 16),
    parseInt(result[2], 16),
    parseInt(result[3], 16)
  ] : [74, 144, 226]; // Default blue if parse fails
}

interface PlanData {
  name: string;
  teamName?: string;
  primaryColor?: string;
  secondaryColor?: string;
}

interface Period {
  name: string;
  startDate?: string;
  endDate?: string;
  themes?: string[];
}

interface Session {
  date: string;
  themes?: string[];
  duration?: number;
  location?: string;
  notes?: string;
}

function addWatermarkLogo(doc: jsPDF) {
  try {
    // Try to load the new grey watermark logo
    const logoPath = path.join(process.cwd(), 'uploads', 'club-logos-organized', 'grey-watermark-logo.png');
    if (fs.existsSync(logoPath)) {
      const logoData = fs.readFileSync(logoPath, 'base64');
      // Add large watermark centered like in your drawing
      const logoSize = 140; // Large watermark like in your example
      const logoX = (297 - logoSize) / 2; // Center horizontally
      const logoY = (210 - logoSize) / 2 + 10; // Center vertically, behind calendar
      
      // Set light grey transparency for watermark effect
      doc.setGState(doc.GState({ opacity: 0.20 })); // 20% visible watermark
      doc.addImage(logoData, 'PNG', logoX, logoY, logoSize, logoSize);
      doc.setGState(doc.GState({ opacity: 1.0 })); // Reset to full opacity
      
      console.log('Compact grey VVC watermark logo added successfully');
    } else {
      console.log('Logo file not found at:', logoPath);
      // Fallback text watermark
      doc.setFontSize(80);
      doc.setTextColor(240, 240, 240);
      doc.text('VVC', 148.5, 115, { align: 'center' });
      doc.setFontSize(18);
      doc.text('BRASSCHAAT', 148.5, 135, { align: 'center' });
    }
  } catch (error) {
    console.log('Could not add watermark logo:', error);
    // Simple fallback - add subtle VVC text watermark
    doc.setFontSize(80);
    doc.setTextColor(240, 240, 240);
    doc.text('VVC', 148.5, 115, { align: 'center' });
    doc.setFontSize(18);
    doc.text('BRASSCHAAT', 148.5, 135, { align: 'center' });
  }
}

function createCoverPage(doc: jsPDF, planData: PlanData): void {
  // Use club colors - primary color for background
  const primaryRgb = hexToRgb(planData.primaryColor || '#232e5d');
  doc.setFillColor(primaryRgb[0], primaryRgb[1], primaryRgb[2]); 
  doc.rect(0, 0, 297, 210, 'F');
  

  
  // Club logo centered higher up
  const centerX = 148.5;
  const centerY = 70;
  
  try {
    const logoPath = path.join(process.cwd(), 'uploads', 'club-logos-organized', 'primary-logo.png');
    if (fs.existsSync(logoPath)) {
      const logoData = fs.readFileSync(logoPath, 'base64');
      const logoSize = 70; // Bigger like in image
      doc.addImage(logoData, 'PNG', centerX - logoSize/2, centerY - logoSize/2, logoSize, logoSize);
    }
  } catch (error) {
    console.log('Could not add cover logo:', error);
  }
  
  // JAARPLAN in white below logo - 2 lijnen omlaag
  doc.setFontSize(42);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('JAARPLAN', centerX, centerY + 55, { align: 'center' });
  
  // Team name (ploeg) clearly visible below JAARPLAN - 2 lijnen omlaag
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text(planData.name || 'Team Planning', centerX, centerY + 75, { align: 'center' });
  
  // Slogan under team name
  doc.setFontSize(12);
  doc.setFont('helvetica', 'italic');
  doc.text('"#teamworkmakesthedreamwork"', centerX, centerY + 90, { align: 'center' });
  
  // Seizoen below slogan - 2 lijnen omlaag
  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text('Seizoen 2025-2026', centerX, centerY + 105, { align: 'center' });
  

  

  
  // Small POWERED BY in bottom right corner exactly like image
  doc.setFontSize(7);
  doc.setTextColor(150, 150, 180);
  doc.text('POWERED BY SOCCER CLUB PRO', 297 - 10, 200, { align: 'right' });
  doc.text(`Gegenereerd op ${new Date().toLocaleDateString('nl-NL', { day: '2-digit', month: '2-digit', year: 'numeric' })}`, 297 - 10, 207, { align: 'right' });
}

function createMonthlyCalendarGrid(doc: jsPDF, month: string, sessions: Session[], startY: number, planData: PlanData): number {
  const monthDate = new Date(month + '-01');
  const monthName = monthDate.toLocaleDateString('nl-NL', { year: 'numeric', month: 'long' });
  
  // Professional blue header exactly like photo
  doc.setFillColor(49, 64, 107); // Dark blue like photo
  doc.rect(0, 0, 297, 25, 'F');
  
  // Team name and month in header
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(`${planData.name} - Maandplanning ${monthName}`, 15, 17);
  
  // POWERED BY on right
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('POWERED BY SOCCER CLUB PRO', 280, 17, { align: 'right' });
  
  // Calendar starts higher, closer to header
  let yPos = 26;
  
  // Days of week header exactly like example (80% schaal)
  const weekDays = ['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'];
  doc.setFillColor(180, 180, 180);
  doc.rect(18, yPos, 260, 15, 'F'); // Breder over hele pagina
  
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  
  for (let i = 0; i < 7; i++) {
    const x = 18 + (i * 260/7) + (260/14); // Breder over hele pagina
    doc.text(weekDays[i], x, yPos + 10, { align: 'center' });
  }
  
  yPos += 15;
  
  // Calendar grid exactly like example - big cells
  const daysInMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0).getDate();
  const firstDayOfWeek = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1).getDay();
  const adjustedFirstDay = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1; // Maandag = 0
  
  let currentDay = 1;
  const cellWidth = 260 / 7; // Breder over hele pagina
  const cellHeight = 32; // Aangepaste hoogte zodat alles past
  
  for (let week = 0; week < 6; week++) {
    for (let day = 0; day < 7; day++) {
      const cellX = 18 + (day * cellWidth); // Breder over hele pagina
      const cellY = yPos + (week * cellHeight);
      
      // Draw cell border
      doc.setDrawColor(0, 0, 0);
      doc.setLineWidth(0.3);
      doc.rect(cellX, cellY, cellWidth, cellHeight);
      
      if (week === 0 && day < adjustedFirstDay) {
        // Empty cells before month starts
        continue;
      }
      
      if (currentDay > daysInMonth) {
        // Month has ended
        break;
      }
      
      // Check if there are sessions on this day
      const currentDate = `${month}-${currentDay.toString().padStart(2, '0')}`;
      const daySessions = sessions.filter(s => s.date === currentDate);
      
      // Cell background color based on session type
      if (daySessions.length > 0) {
        // Yellow background for training days (like in example)
        doc.setFillColor(255, 255, 153); // Light yellow
        doc.rect(cellX + 0.5, cellY + 0.5, cellWidth - 1, cellHeight - 1, 'F');
      }
      
      // Day number
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text(currentDay.toString(), cellX + 2, cellY + 8);
      
      // Full session details with all training information
      if (daySessions.length > 0) {
        let textY = cellY + 12;
        
        daySessions.forEach((session, idx) => {
          if (textY > cellY + cellHeight - 3) return; // Don't overflow cell
          
          // Determine if it's a match or training based on themes/notes
          const isMatch = session.themes?.some(theme => 
            theme.toLowerCase().includes('wedstrijd') || 
            theme.toLowerCase().includes('match')
          ) || (session.notes && session.notes.toLowerCase().includes('wedstrijd'));
          
          // Session type label with more detail
          doc.setTextColor(0, 0, 0);
          doc.setFontSize(6);
          doc.setFont('helvetica', 'bold');
          
          // Check for special session types in notes
          const isOefenwedstrijd = session.notes && session.notes.toLowerCase().includes('oefenwedstrijd');
          const isFriendly = session.notes && (session.notes.toLowerCase().includes('vriendschappelijk') || session.notes.toLowerCase().includes('friendly'));
          
          if (isOefenwedstrijd) {
            doc.text('Oefenwedstrijd', cellX + 1, textY);
          } else if (isFriendly) {
            doc.text('Vriendschappelijk', cellX + 1, textY);
          } else {
            doc.text(isMatch ? 'Wedstrijd' : 'Training', cellX + 1, textY);
          }
          textY += 4;
          
          // Time details like in photo (20:00 - 21:30)
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(6);
          
          // Extract start time from notes or session data
          let timeText = '';
          if ((session as any).startTime) {
            // Calculate end time based on duration
            const startHour = parseInt((session as any).startTime.split(':')[0]);
            const startMin = parseInt((session as any).startTime.split(':')[1]);
            const duration = session.duration || 90;
            const endHour = Math.floor((startHour * 60 + startMin + duration) / 60);
            const endMin = (startHour * 60 + startMin + duration) % 60;
            timeText = `${(session as any).startTime} - ${endHour.toString().padStart(2, '0')}:${endMin.toString().padStart(2, '0')}`;
          } else if (session.notes) {
            const timeMatch = session.notes.match(/(\d{1,2}:\d{2})/g);
            if (timeMatch && timeMatch.length >= 2) {
              timeText = `${timeMatch[0]} - ${timeMatch[1]}`;
            } else if (timeMatch && timeMatch.length === 1) {
              timeText = timeMatch[0];
            }
          }
          
          if (timeText) {
            doc.text(timeText, cellX + 1, textY);
            textY += 4;
          }
          
          // Location details if available
          if (session.location && textY <= cellY + cellHeight - 6) {
            doc.setFontSize(5);
            doc.text(session.location, cellX + 1, textY);
            textY += 3;
          }
          
          // Opponent details for matches (from notes)
          if (session.notes && textY <= cellY + cellHeight - 6) {
            const opponentMatch = session.notes.match(/(?:tegen|vs|tegen\s+)([A-Za-z\s]+)/i);
            if (opponentMatch) {
              doc.setFontSize(5);
              doc.text(`Tegen: ${opponentMatch[1].trim()}`, cellX + 1, textY);
              textY += 3;
            }
          }
          
          // Training themes (IADATABANK elements)
          if (session.themes && session.themes.length > 0 && textY <= cellY + cellHeight - 6) {
            doc.setFontSize(5);
            const themeText = session.themes.slice(0, 2).join(', '); // Max 2 themes to fit
            if (themeText.length > 20) {
              doc.text(themeText.substring(0, 17) + '...', cellX + 1, textY);
            } else {
              doc.text(themeText, cellX + 1, textY);
            }
          }
          const duration = session.duration || 90;
          
          // Extract start time from notes or use defaults based on session type
          const timeMatch = session.notes && session.notes.match(/(\d{1,2}):(\d{2})/);
          let startTime;
          
          if (timeMatch) {
            startTime = `${timeMatch[1]}:${timeMatch[2]}`;
          } else if (isOefenwedstrijd) {
            startTime = '18:00'; // Oefenwedstrijden meestal eerder
          } else if (isMatch) {
            startTime = '16:00'; // Wedstrijden vaak 's middags
          } else {
            startTime = '20:00'; // Training standaard 's avonds
          }
          
          // Calculate end time
          const [startHour, startMin] = startTime.split(':').map(Number);
          const totalMinutes = startHour * 60 + startMin + duration;
          const endHour = Math.floor(totalMinutes / 60);
          const endMin = totalMinutes % 60;
          const endTime = `${endHour.toString().padStart(2, '0')}:${endMin.toString().padStart(2, '0')}`;
          
          doc.text(`${startTime} - ${endTime}`, cellX + 1, textY);
          textY += 4;
          
          // Extract opponent from notes if it's a match or oefenwedstrijd
          if (isMatch || isOefenwedstrijd) {
            const opponentMatch = session.notes && session.notes.match(/(?:tegen|vs\.?|uit tegen)\s+([A-Za-z\s]+)/i);
            if (opponentMatch) {
              doc.setFontSize(5);
              doc.setFont('helvetica', 'italic');
              doc.text(`tegen ${opponentMatch[1].trim()}`, cellX + 1, textY);
              textY += 3;
            }
          }
          
          // Location information if available
          if (session.location) {
            doc.setFontSize(5);
            doc.setFont('helvetica', 'normal');
            doc.text(session.location, cellX + 1, textY);
            textY += 3;
          }
          
          // Main themes in caps with more detail
          if (session.themes && session.themes.length > 0) {
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(6);
            session.themes.slice(0, 4).forEach((theme, themeIdx) => {
              if (textY <= cellY + cellHeight - 6) {
                // Enhanced color coding for IADATABANK theme types
                if (theme.toLowerCase().includes('fysiek') || theme.toLowerCase().includes('conditie') || theme.includes('FYSIEK_')) {
                  doc.setTextColor(180, 20, 20); // Red for physical themes
                } else if (theme.toLowerCase().includes('techniek') || theme.toLowerCase().includes('basics') || theme.includes('BASICS_')) {
                  doc.setTextColor(20, 120, 20); // Green for technical/basics themes
                } else if (theme.toLowerCase().includes('tactiek') || theme.toLowerCase().includes('opbouw') || theme.includes('TEAMTACTISCH_')) {
                  doc.setTextColor(20, 20, 150); // Blue for tactical themes
                } else if (theme.toLowerCase().includes('mentaal') || theme.includes('MENTAAL_')) {
                  doc.setTextColor(120, 20, 120); // Purple for mental themes
                } else {
                  doc.setTextColor(60, 60, 60); // Dark grey for other themes
                }
                
                // Clean theme names for better readability
                let themeText = theme.replace('BASICS_', '').replace('TEAMTACTISCH_', '').replace('FYSIEK_', '').replace('MENTAAL_', '');
                themeText = themeText.replace(/_/g, ' ').toUpperCase();
                const shortTheme = themeText.length > 14 ? themeText.substring(0, 14) + '...' : themeText;
                doc.text(shortTheme, cellX + 1, textY);
                textY += 2.5; // Tighter spacing for more content
              }
            });
            doc.setTextColor(0, 0, 0); // Reset color
          }
          
          // Location if available
          if (session.location) {
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(5);
            const locationText = session.location.length > 12 ? session.location.substring(0, 12) : session.location;
            doc.text(locationText, cellX + 1, textY);
            textY += 3;
          }
          
          // Enhanced varia information with better formatting
          if (session.notes) {
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(5);
            
            // Extract specific details from notes
            const notes = session.notes.toLowerCase();
            
            // Check for specific match/training types
            if (notes.includes('oefenwedstrijd')) {
              doc.setTextColor(180, 20, 20); // Red for friendly matches
              doc.setFont('helvetica', 'bold');
              doc.text('OEFENWEDSTRIJD', cellX + 1, textY);
              textY += 3;
            }
            
            // Extract opponent information
            const opponentMatch = session.notes.match(/(?:tegen|vs\.?|uit tegen)\s+([A-Za-z\s]+)/i);
            if (opponentMatch) {
              doc.setTextColor(20, 20, 150); // Blue for opponent
              doc.setFont('helvetica', 'italic');
              doc.text(`vs ${opponentMatch[1].trim()}`, cellX + 1, textY);
              textY += 3;
            }
            
            // Extract venue/location details
            const venueMatch = session.notes.match(/(?:locatie|veld|terrein|thuis|uit)\s*:?\s*([A-Za-z0-9\s#]+)/i);
            if (venueMatch) {
              doc.setTextColor(120, 60, 20); // Brown for venue
              doc.setFont('helvetica', 'normal');
              doc.text(venueMatch[1].trim(), cellX + 1, textY);
              textY += 3;
            }
            
            // Add any remaining notes that don't match patterns
            const remainingNotes = session.notes
              .replace(/(?:tegen|vs\.?|uit tegen)\s+[A-Za-z\s]+/i, '')
              .replace(/(?:locatie|veld|terrein|thuis|uit)\s*:?\s*[A-Za-z0-9\s#]+/i, '')
              .replace(/oefenwedstrijd/i, '')
              .trim();
              
            if (remainingNotes && textY <= cellY + cellHeight - 6) {
              doc.setTextColor(80, 80, 80); // Grey for other notes
              doc.setFont('helvetica', 'italic');
              const shortNotes = remainingNotes.length > 20 ? remainingNotes.substring(0, 20) + '...' : remainingNotes;
              doc.text(shortNotes, cellX + 1, textY);
              textY += 3;
            }
          }
          
          // If match, add special styling
          if (isMatch) {
            // Add match-specific details
            doc.setTextColor(44, 82, 130); // Blue for matches instead of red
            doc.setFontSize(5);
            doc.setFont('helvetica', 'bold');
            if (textY <= cellY + cellHeight - 3) {
              doc.text('VS TEGENSTANDER', cellX + 1, textY);
              textY += 3;
            }
          }
          
          // Team assignment if multiple teams
          if (session.themes?.includes('Team')) {
            doc.setTextColor(44, 82, 130); // Blue for team info
            doc.setFontSize(5);
            doc.setFont('helvetica', 'normal');
            if (textY <= cellY + cellHeight - 3) {
              doc.text('Team', cellX + 1, textY);
            }
          }
        });
      }
      
      currentDay++;
    }
    
    if (currentDay > daysInMonth) break;
  }
  
  // No footer text in calendar
  
  return yPos + (6 * cellHeight) + 10;
}

function createMonthlySessionsList(doc: jsPDF, month: string, sessions: Session[], startY: number): number {
  // Skip sessions list to ensure calendar fits on one page
  return startY;
}

export function generateYearPlanPDF(planData: PlanData, periods: Period[], sessions: Session[]): ArrayBuffer {
  const doc = new jsPDF({
    orientation: 'l',
    unit: 'mm', 
    format: 'a4',
    compress: true // Enable PDF compression
  });
  
  // VVC Brasschaat brand colors - blue theme like in examples
  const primaryColor = [44, 82, 130]; // VVC blue
  const secondaryColor = [255, 255, 255]; // wit
  
  // Group sessions by month
  const sessionsByMonth: { [key: string]: Session[] } = {};
  sessions.forEach(session => {
    const monthKey = session.date.substring(0, 7); // YYYY-MM
    if (!sessionsByMonth[monthKey]) {
      sessionsByMonth[monthKey] = [];
    }
    sessionsByMonth[monthKey].push(session);
  });
  
  // Add cover page first (no watermark on cover)
  createCoverPage(doc, planData);
  
  // Sort months chronologically
  const sortedMonths = Object.keys(sessionsByMonth).sort();
  
  sortedMonths.forEach((month, monthIndex) => {
    // Always add new page after cover page
    doc.addPage();
    
    // Add watermark logo only on calendar pages (not cover page)
    addWatermarkLogo(doc);
    
    // Page header - very small like in photo
    const primaryRgb = hexToRgb(planData.primaryColor || '#232e5d');
    doc.setFillColor(primaryRgb[0], primaryRgb[1], primaryRgb[2]);
    doc.rect(0, 0, 297, 15, 'F'); // Much smaller header
    
    // Title in small header
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    const monthDate = new Date(month + '-01');
    const monthName = monthDate.toLocaleDateString('nl-NL', { year: 'numeric', month: 'long' });
    doc.text(`Dames Provinciaal - Maandplanning ${monthName}`, 20, 10);
    
    // Hashtag right side like in photo
    doc.setFontSize(8);
    doc.setFont('helvetica', 'italic');
    doc.text('"#teamworkmakesthedreamwork"', 277, 10, { align: 'right' });
    
    let yPosition = 25;
    
    // Monthly calendar grid
    yPosition = createMonthlyCalendarGrid(doc, month, sessionsByMonth[month], yPosition, planData);
    
    // Monthly sessions list
    yPosition = createMonthlySessionsList(doc, month, sessionsByMonth[month], yPosition);
    
    // Page footer - much smaller like in photo
    const footerPrimaryRgb = hexToRgb(planData.primaryColor || '#232e5d');
    doc.setFillColor(footerPrimaryRgb[0], footerPrimaryRgb[1], footerPrimaryRgb[2]);
    doc.rect(0, 200, 297, 10, 'F'); // Much smaller footer
    
    doc.setTextColor(255, 255, 255); // White text on colored background
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.text(`Gegenereerd op ${new Date().toLocaleDateString('nl-NL', { day: '2-digit', month: '2-digit', year: 'numeric' })}`, 20, 206);
    doc.text(`Pagina ${monthIndex + 2} van ${sortedMonths.length + 1}`, 148.5, 206, { align: 'center' });
    doc.text('VVC Brasschaat - Voetbalclub', 277, 206, { align: 'right' });
  });
  
  return doc.output('arraybuffer');
}