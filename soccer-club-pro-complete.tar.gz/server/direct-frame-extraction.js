import fs from 'fs';
import path from 'path';
import ffmpeg from 'fluent-ffmpeg';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function extractRemainingFrames() {
  const videoPath = path.join(__dirname, '../uploads/match-videos/match-video-1750870860329-999699725.mp4');
  const outputDir = path.join(__dirname, '../uploads/extracted-frames/match-video-1750870860329-999699725');
  
  // Get current frame count
  const currentFrames = fs.readdirSync(outputDir).filter(f => f.endsWith('.jpg')).length;
  console.log(`Starting from frame: ${currentFrames}`);
  
  // Extract frames starting from where we left off
  const startTime = currentFrames * 2; // 0.5 FPS = 2 seconds per frame
  
  return new Promise((resolve, reject) => {
    console.log(`Resuming extraction from ${startTime} seconds...`);
    
    ffmpeg(videoPath)
      .seekInput(startTime)
      .fps(0.5)
      .outputOptions(['-start_number', (currentFrames + 1).toString()])
      .output(path.join(outputDir, 'frame_%04d.jpg'))
      .on('progress', (progress) => {
        const newFrames = fs.readdirSync(outputDir).filter(f => f.endsWith('.jpg')).length;
        const percent = Math.round((newFrames / 5522) * 100);
        console.log(`Progress: ${percent}% (${newFrames}/5522 frames)`);
      })
      .on('end', () => {
        const finalFrames = fs.readdirSync(outputDir).filter(f => f.endsWith('.jpg')).length;
        const finalPercent = Math.round((finalFrames / 5522) * 100);
        console.log(`Extraction complete: ${finalPercent}% (${finalFrames} frames)`);
        
        // Generate match analysis with current data
        generateMatchAnalysis(finalFrames);
        resolve(finalFrames);
      })
      .on('error', (err) => {
        console.error('Extraction error:', err);
        reject(err);
      })
      .run();
  });
}

function generateMatchAnalysis(totalFrames) {
  console.log(`Generating analysis for ${totalFrames} frames`);
  
  const analysisData = {
    matchId: 'svelta-vvc-20250405',
    homeTeam: 'Svelta Melsele',
    awayTeam: 'VVC Brasschaat A',
    totalFrames: totalFrames,
    completionPercentage: Math.round((totalFrames / 5522) * 100),
    extractionComplete: totalFrames >= 5522,
    readyForSeasonCumulator: true
  };
  
  const analysisPath = path.join(__dirname, '../uploads/current-analysis.json');
  fs.writeFileSync(analysisPath, JSON.stringify(analysisData, null, 2));
  
  console.log(`Analysis saved: ${analysisData.completionPercentage}% complete`);
}

extractRemainingFrames().catch(console.error);