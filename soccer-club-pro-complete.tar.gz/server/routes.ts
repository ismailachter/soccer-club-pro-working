import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuthRoutes, isAuthenticated } from "./auth";
import { db } from "./db";
import { trainingPlans, trainingSessions, teams, yearPlanning, insertYearPlanningSchema, yearPlans, yearPlanPeriods, yearPlanSessions, insertYearPlanSchema, insertYearPlanPeriodSchema, insertYearPlanSessionSchema } from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { 
  insertUserSchema, 
  insertTeamSchema, 
  insertPlayerSchema, 
  insertCoachSchema, 
  insertParentSchema, 
  insertPitchSchema, 
  insertCoordinatorSchema, 
  insertTrainerSchema,
  insertMatchSchema, 
  insertTrainingSessionSchema, 
  insertAttendanceSchema,
  insertUserTeamSchema,
  insertFeeCategorySchema,
  insertUserFeeSchema,
  insertTrainingPlanSchema,
  insertPaymentSchema,
  insertPaymentPlanSchema,
  insertPaymentPlanInstallmentSchema,
  type UserTeam,
  exerciseCategories,
  exercises,
  trainingPrograms,
  programExercises,
  type InsertExerciseCategory,
  type InsertExercise,
  type InsertTrainingProgram,
  type InsertProgramExercise
} from "@shared/schema";
import multer from "multer";
import * as XLSX from 'xlsx';
import express from "express";
// import { sendPlayerWelcomeEmail } from "./utils/resend-mail";
import adminRouter from "./routes/admin";
import paymentRouter from "./routes/payments";
import clubRouter from "./routes/club";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuthRoutes(app);
  
  // API routes
  const apiRouter = express.Router();
  app.use('/api', apiRouter);
  
  // Admin routes
  app.use('/api/admin', adminRouter);
  
  // Payment routes
  app.use('/api', paymentRouter);
  
  // Club routes
  app.use('/api/club', clubRouter);



  // Training Sessions Routes - Enhanced for Calendar Integration
  apiRouter.get('/training-sessions', async (req, res) => {
    try {
      const planId = req.query.planId ? parseInt(req.query.planId as string) : undefined;
      const sessions = await storage.getTrainingSessions(planId);
      res.json(sessions || []);
    } catch (error) {
      console.error('Training sessions fetch error:', error);
      res.json([]); // Return empty array for stability
    }
  });

  apiRouter.post('/training-sessions', isAuthenticated, async (req, res) => {
    try {
      const sessionData = {
        ...req.body,
        date: req.body.date || new Date().toISOString(),
        startTime: req.body.startTime || new Date().toISOString(),
        endTime: req.body.endTime || new Date().toISOString(),
        duration: req.body.duration || 90,
        iadataBankElements: req.body.iadataBankElements || []
      };
      
      const session = await storage.createTrainingSession(sessionData);
      res.status(201).json(session);
    } catch (error) {
      console.error('Training session creation error:', error);
      res.status(500).json({ message: 'Failed to create training session', error: (error as Error).message });
    }
  });

  // Year plan sessions API routes
  apiRouter.get('/year-plans/:id/sessions', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      
      const sessions = await db.select().from(yearPlanSessions)
        .where(eq(yearPlanSessions.yearPlanId, planId))
        .orderBy(yearPlanSessions.date);
      
      res.json(sessions);
    } catch (error) {
      console.error('Error fetching year plan sessions:', error);
      res.status(500).json({ message: 'Failed to fetch sessions' });
    }
  });

  apiRouter.post('/year-plans/:id/sessions', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const validatedData = insertYearPlanSessionSchema.parse({
        ...req.body,
        yearPlanId: planId
      });
      
      const [newSession] = await db.insert(yearPlanSessions)
        .values(validatedData)
        .returning();
      
      res.status(201).json(newSession);
    } catch (error) {
      console.error('Error creating year plan session:', error);
      res.status(500).json({ message: 'Failed to create session' });
    }
  });

  apiRouter.put('/year-plans/:planId/sessions/:sessionId', isAuthenticated, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const validatedData = insertYearPlanSessionSchema.parse(req.body);
      
      const [updatedSession] = await db.update(yearPlanSessions)
        .set({ ...validatedData })
        .where(eq(yearPlanSessions.id, sessionId))
        .returning();
      
      if (!updatedSession) {
        return res.status(404).json({ message: 'Session not found' });
      }
      
      res.json(updatedSession);
    } catch (error) {
      console.error('Error updating year plan session:', error);
      res.status(500).json({ message: 'Failed to update session' });
    }
  });

  apiRouter.delete('/year-plans/:planId/sessions/:sessionId', isAuthenticated, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      
      const [deletedSession] = await db.delete(yearPlanSessions)
        .where(eq(yearPlanSessions.id, sessionId))
        .returning();
      
      if (!deletedSession) {
        return res.status(404).json({ message: 'Session not found' });
      }
      
      res.json({ message: 'Session deleted successfully' });
    } catch (error) {
      console.error('Error deleting year plan session:', error);
      res.status(500).json({ message: 'Failed to delete session' });
    }
  });

  apiRouter.patch('/training-sessions/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const session = await storage.updateTrainingSession(id, req.body);
      if (!session) {
        return res.status(404).json({ message: 'Training session not found' });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update training session', error: (error as Error).message });
    }
  });

  apiRouter.delete('/training-sessions/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteTrainingSession(id);
      res.json({ message: 'Training session deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete training session', error: (error as Error).message });
    }
  });

  // IADATABANK save endpoint
  apiRouter.post('/save-complete-iadatabank', async (req, res) => {
    try {
      // Complete IADATABANK elements with authentic soccer training data
      const completeElements = [
        // BASICS B+ - Technical skills with ball
        { name: "Leiden van de bal", topic: "BASICS", subtopic: "B+", difficulty: 2, description: "Basis balbeheersing en controle tijdens beweging" },
        { name: "Dribbelen met de bal", topic: "BASICS", subtopic: "B+", difficulty: 3, description: "Bal meenemen en richting veranderen met beide voeten" },
        { name: "Korte Passing", topic: "BASICS", subtopic: "B+", difficulty: 2, description: "Nauwkeurig passen over korte afstand 5-15 meter" },
        { name: "Middellange Passing", topic: "BASICS", subtopic: "B+", difficulty: 3, description: "Passen over middellange afstand 15-30 meter" },
        { name: "Lange Passing", topic: "BASICS", subtopic: "B+", difficulty: 4, description: "Precieze lange ballen en voorzetten over 30+ meter" },
        { name: "Passing met het hoofd", topic: "BASICS", subtopic: "B+", difficulty: 4, description: "Koppen naar teamgenoten met precisie" },
        { name: "1 tijd Passing, Kaatsen", topic: "BASICS", subtopic: "B+", difficulty: 5, description: "Direct doorspelen zonder balcontrole" },
        { name: "Balcontrole Korte Pass", topic: "BASICS", subtopic: "B+", difficulty: 2, description: "Aannemen van korte passes met eerste aanraking" },
        { name: "Balcontrole Middellange Pass", topic: "BASICS", subtopic: "B+", difficulty: 3, description: "Controle van middellange passes onder druk" },
        { name: "Balcontrole Lange Pass", topic: "BASICS", subtopic: "B+", difficulty: 4, description: "Aannemen van lange ballen en voorzetten" },
        
        // BASICS B- - Goal scoring and positioning
        { name: "Schieten op doel", topic: "BASICS", subtopic: "B-", difficulty: 3, description: "Doelgericht schieten vanuit verschillende posities" },
        { name: "Scoren met de voet", topic: "BASICS", subtopic: "B-", difficulty: 4, description: "Afwerken met voet binnen en buiten het strafschopgebied" },
        { name: "Scoren met het hoofd", topic: "BASICS", subtopic: "B-", difficulty: 5, description: "Kopdoelpunten maken vanuit voorzetten en corners" },
        { name: "Scoren na individuele actie, trucks", topic: "BASICS", subtopic: "B-", difficulty: 5, description: "Doelpunt maken na dribbel of individuele actie" },
        { name: "Vrijlopen - Aanspeelbaar zijn", topic: "BASICS", subtopic: "B-", difficulty: 4, description: "Intelligente positionering om bal te ontvangen" },

        // TEAMTACTISCH - All tactical elements
        // B+ BALBEZIT elements
        { name: "Creeer ruimte", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 4, description: "Ruimte creëren voor teamgenoten door beweging" },
        { name: "Creeer hoogte, diepte", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 4, description: "Verticale en horizontale spreiding van het team" },
        { name: "Creeer meerderheidssituaties", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 5, description: "Numerieke overmacht creëren in zones" },
        { name: "Driekhoeksspel", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 4, description: "Driehoekspassingen en positionering" },
        { name: "Creeer 3 x aanspeelbaarheid", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 4, description: "Drie passopties beschikbaar houden" },
        { name: "Vlotte eficiënte balcirculatie", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 4, description: "Snelle en effectieve balbeweging" },
        { name: "Hoog tempo balbezit", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 5, description: "Snel passing spel onder druk" },
        { name: "Diagonal in & uit", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 5, description: "Diagonale bewegingen en passes" },
        { name: "Linie overslaan", topic: "TEAMTACTISCH", subtopic: "B+_BALBEZIT", difficulty: 5, description: "Middenlinie overslaan met passes" },

        // B+ VOORUITGANG & INFILTRATIE elements  
        { name: "Positie tussen de linies", topic: "TEAMTACTISCH", subtopic: "B+_VOORUITGANG", difficulty: 5, description: "Positionering tussen verdedigingslinies" },
        { name: "Diepgaande infiltraties", topic: "TEAMTACTISCH", subtopic: "B+_VOORUITGANG", difficulty: 5, description: "Diepe loopacties achter verdediging" },
        { name: "Interacties 2, 3 linies", topic: "TEAMTACTISCH", subtopic: "B+_VOORUITGANG", difficulty: 6, description: "Samenspel tussen meerdere linies" },
        { name: "Vermijd onnodig balverlies", topic: "TEAMTACTISCH", subtopic: "B+_VOORUITGANG", difficulty: 4, description: "Behoud balbezit in gevaarlijke zones" },
        { name: "Individuele actie", topic: "TEAMTACTISCH", subtopic: "B+_VOORUITGANG", difficulty: 4, description: "Wanneer en hoe individueel te handelen" },
        { name: "Subtiele laatste pass", topic: "TEAMTACTISCH", subtopic: "B+_VOORUITGANG", difficulty: 6, description: "Definitieve pass naar doelkans" },
        { name: "Voorzet", topic: "TEAMTACTISCH", subtopic: "B+_VOORUITGANG", difficulty: 4, description: "Effectieve voorzetten vanaf de zijkant" },
        { name: "Vroege voorzet", topic: "TEAMTACTISCH", subtopic: "B+_VOORUITGANG", difficulty: 5, description: "Snelle voorzetten voor verdediging zich organiseert" },

        // B+ DOELPUNTEN MAKEN elements
        { name: "4 in de 16", topic: "TEAMTACTISCH", subtopic: "B+_DOELPUNTEN", difficulty: 5, description: "Vier spelers in strafschopgebied bij aanval" },
        { name: "Aanval op 2de paal", topic: "TEAMTACTISCH", subtopic: "B+_DOELPUNTEN", difficulty: 4, description: "Aanvallen richten op tweede paal" },
        { name: "Rebound", topic: "TEAMTACTISCH", subtopic: "B+_DOELPUNTEN", difficulty: 4, description: "Opvolgen van rebounds en teruggekaatste ballen" },

        // B- DRUK ZETTEN elements
        { name: "Druk zetten", topic: "TEAMTACTISCH", subtopic: "B-_DRUK", difficulty: 4, description: "Collectief druk uitoefenen op tegenstander" },
        { name: "Tackle", topic: "TEAMTACTISCH", subtopic: "B-_DRUK", difficulty: 3, description: "Effectief tackelen en balverovering" },
        { name: "Remmen", topic: "TEAMTACTISCH", subtopic: "B-_DRUK", difficulty: 4, description: "Vertragen van tegenstanderaanvallen" },
        { name: "Eenvoudig druk zetten", topic: "TEAMTACTISCH", subtopic: "B-_DRUK", difficulty: 3, description: "Basis pressing principes" },

        // B- OMSCHAKELING elements
        { name: "Tegenaanval", topic: "TEAMTACTISCH", subtopic: "OMSCH_B-_B+", difficulty: 5, description: "Snelle omschakeling van verdediging naar aanval" },
        { name: "Op balbezit spelen", topic: "TEAMTACTISCH", subtopic: "OMSCH_B-_B+", difficulty: 4, description: "Anticiperen op balverovering" },
        { name: "Tegen druk zetten", topic: "TEAMTACTISCH", subtopic: "OMSCH_B+_B-", difficulty: 4, description: "Reactie op verlies van balbezit" },
        { name: "Hervormen opstelling", topic: "TEAMTACTISCH", subtopic: "OMSCH_B+_B-", difficulty: 5, description: "Snel herorganiseren na balverlies" },

        // MENTAAL - All 29 mental aspects of soccer
        { name: "Concentratie", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 3, description: "Mentale focus en aandacht tijdens training en wedstrijden" },
        { name: "Rustig vs onrustig", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Kalmte bewaren en emotionele stabiliteit onder druk" },
        { name: "Spontaniteit", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 2, description: "Natuurlijke creativiteit en improvisatie in het spel" },
        { name: "Egoistisch", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 5, description: "Balans tussen individuele actie en teamspel" },
        { name: "Afleiding", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 3, description: "Omgaan met externe factoren en wedstrijddruk" },
        { name: "Nabootsen", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 2, description: "Leren door observatie en imitatie van anderen" },
        { name: "Zelfvertrouwen", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Geloof in eigen kunnen en voetbalcapaciteiten" },
        { name: "Zoeken naar bevestiging", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 3, description: "Feedback verwerken en zelfstandigheid ontwikkelen" },
        { name: "Inlevingsvermogen", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Empathie en begrip voor teamgenoten en tegenstanders" },
        { name: "Winnaarsmentaliteit", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 5, description: "Competitieve instelling en doorzettingsvermogen" },
        { name: "Emotionele weerbaarheid/stabiliteit", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 5, description: "Mentale sterkte en veerkracht bij tegenslagen" },
        { name: "Leergierig", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 2, description: "Motivatie om te leren en voetbalvaardigheden te verbeteren" },
        { name: "Doorzettingsvermogen", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Volharding bij tegenslagen en moeilijke momenten" },
        { name: "Omkadering", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 3, description: "Begrip van spelregels, structuur en teamdiscipline" },
        { name: "Motivatie", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 3, description: "Innerlijke drijfveer en passie voor voetbal" },
        { name: "Inzet", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 2, description: "Toewijding en commitment tijdens training en wedstrijden" },
        { name: "Ambitie", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Streven naar verbetering en hogere doelen" },
        { name: "Zelfregulering", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 5, description: "Controle over eigen gedrag en emotionele reacties" },
        { name: "Volharding", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Doorzetten ondanks vermoeidheid en moeilijkheden" },
        { name: "Zelfbeeld", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Realistisch en positief beeld van eigen voetbalcapaciteiten" },
        { name: "Leersnelheid", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 3, description: "Snelheid van begrip en aanpassing van nieuwe concepten" },
        { name: "Inzicht", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 5, description: "Diepgaand begrip van spellogica en tactische situaties" },
        { name: "Besluitvaardigheid", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Snelle en juiste keuzes maken tijdens het spel" },
        { name: "Leervermogen", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 3, description: "Capaciteit om nieuwe voetbalvaardigheden te ontwikkelen" },
        { name: "Persoonlijkheid", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 2, description: "Karakter en persoonlijke eigenschappen op het veld" },
        { name: "Leiderschap", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 6, description: "Anderen inspireren en leiden tijdens wedstrijden" },
        { name: "Betrokken", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 3, description: "Actieve participatie en engagement in teamverband" },
        { name: "Focus", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 4, description: "Gerichte concentratie op voetbaldoelen en taken" },
        { name: "Respectvol", topic: "MENTAAL", subtopic: "ALGEMEEN_MENTAAL", difficulty: 2, description: "Waardering voor tegenstanders, scheidsrechters en teamgenoten" },

        // PHYSIEK - All physical aspects of soccer training
        { name: "Uithouding", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Algemene uithoudingsvermogen voor voetbal" },
        { name: "Basismotoriek", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 2, description: "Fundamentele bewegingsvaardigheden" },
        { name: "Oog-handcoördinatie", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Coördinatie tussen ogen en handen" },
        { name: "Oog-voetcoördinatie", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Coördinatie tussen ogen en voeten" },
        { name: "Evenwichtscontrole", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Balans en evenwicht tijdens beweging" },
        { name: "Reactiesnelheid", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Snelheid van reactie op prikkels" },
        { name: "Natuurlijke Lenigheid", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 2, description: "Aangeboren flexibiliteit en bewegingsbereik" },
        { name: "Ritme", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Bewegingsritme en timing" },
        { name: "Loopcoördinatie", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Gecoördineerde loopbewegingen" },
        { name: "Looptechniek", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Efficiënte looptechniek voor voetbal" },
        { name: "Lenigheid", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Flexibiliteit en gewrichtsmobiliteit" },
        { name: "Snelheid", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Maximale loopsnelheid" },
        { name: "Kracht", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Algemene spierkracht" },
        { name: "Biometrie", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 2, description: "Lichaamsmetingen en fysieke kenmerken" },
        { name: "Startsnelheid", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Snelheid van start en acceleratie" },
        { name: "Versnellingsvermogen", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Vermogen om snel te versnellen" },
        { name: "Snelheidsuithoudingsvermogen", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 5, description: "Volhouden van hoge snelheid" },
        { name: "Herhaald Kort Springvermogen", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Vermogen voor herhaalde korte sprongen" },
        { name: "Wendbaarheid tijdens de Sprint", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 5, description: "Richting veranderen tijdens sprinten" },
        { name: "Herstelvermogen", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Snelheid van herstel na inspanning" },
        { name: "Sprongkracht", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Explosieve kracht voor springen" },
        { name: "Trapkracht", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Kracht bij het trappen van de bal" },
        { name: "Duelkracht", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Fysieke kracht in duelsituaties" },
        { name: "Werpkracht", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Kracht bij inworp en andere worpbewegingen" },
        { name: "Snelkracht", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 5, description: "Explosieve kracht in korte tijd" },
        { name: "Krachtuithouding", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Volhouden van kracht gedurende lange tijd" },
        { name: "Handelingssnelheid", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 4, description: "Snelheid van bewegingsuitvoering" },
        { name: "Blessurepreventie", topic: "PHYSIEK", subtopic: "ALGEMEEN_FYSIEK", difficulty: 3, description: "Voorkomen van blessures door fysieke voorbereiding" }
      ];

      // Progressive 6-level depth system for key elements
      const progressiveDepthLevels = [
        // Concentratie - Young to adult progression
        { elementName: "Concentratie", level: 1, name: "Kinderlijke aandacht", description: "Focus houden tijdens speelse oefeningen van 5-10 minuten", starRating: 1 },
        { elementName: "Concentratie", level: 2, name: "Jeugdige focus", description: "Aandacht behouden tijdens training sessies tot 30 minuten", starRating: 2 },
        { elementName: "Concentratie", level: 3, name: "Tiener concentratie", description: "Focus volhouden tijdens volledige training en eenvoudige wedstrijden", starRating: 3 },
        { elementName: "Concentratie", level: 4, name: "Junior beheersing", description: "Concentratie behouden onder druk in competitiewedstrijden", starRating: 4 },
        { elementName: "Concentratie", level: 5, name: "Senior focus", description: "Selectieve aandacht en mentale flexibiliteit in complexe situaties", starRating: 5 },
        { elementName: "Concentratie", level: 6, name: "Professionele concentratie", description: "Perfecte focus onder extreme druk en anderen begeleiden", starRating: 6 },

        // Korte Passing - Technical progression
        { elementName: "Korte Passing", level: 1, name: "Basis passing", description: "Eenvoudige passes naar dichtbijzijnde speler over 5 meter", starRating: 1 },
        { elementName: "Korte Passing", level: 2, name: "Gerichte passing", description: "Nauwkeurige passes met juiste kracht over 10 meter", starRating: 2 },
        { elementName: "Korte Passing", level: 3, name: "Onder druk passen", description: "Passen ondanks tegenstander in de nabijheid", starRating: 3 },
        { elementName: "Korte Passing", level: 4, name: "Tactische passing", description: "Passen binnen tactische structuur en timing", starRating: 4 },
        { elementName: "Korte Passing", level: 5, name: "Creatieve passing", description: "Verrassende passes die kansen creëren", starRating: 5 },
        { elementName: "Korte Passing", level: 6, name: "Meesterlijke passing", description: "Perfecte passing onder alle omstandigheden", starRating: 6 },

        // Zelfvertrouwen - Mental development
        { elementName: "Zelfvertrouwen", level: 1, name: "Basis vertrouwen", description: "Plezier hebben en durven meedoen in eenvoudige spellen", starRating: 1 },
        { elementName: "Zelfvertrouwen", level: 2, name: "Kleine successen", description: "Vertrouwen opbouwen door positieve ervaringen in training", starRating: 2 },
        { elementName: "Zelfvertrouwen", level: 3, name: "Uitdagingen aangaan", description: "Durven nieuwe technieken te proberen ondanks faalangst", starRating: 3 },
        { elementName: "Zelfvertrouwen", level: 4, name: "Wedstrijd vertrouwen", description: "Zelfverzekerd spelen in competitieve wedstrijdsituaties", starRating: 4 },
        { elementName: "Zelfvertrouwen", level: 5, name: "Resilient vertrouwen", description: "Vertrouwen behouden na fouten en tegenslagen", starRating: 5 },
        { elementName: "Zelfvertrouwen", level: 6, name: "Onwrikbaar vertrouwen", description: "Volledig geloof in eigen kunnen onder alle omstandigheden", starRating: 6 },

        // Driekhoeksspel - Tactical development
        { elementName: "Driekhoeksspel", level: 1, name: "Basis driehoek", description: "Eenvoudige driehoeksvorming met twee teamgenoten", starRating: 1 },
        { elementName: "Driekhoeksspel", level: 2, name: "Constante driehoeken", description: "Bewust driehoeken vormen tijdens passing", starRating: 2 },
        { elementName: "Driekhoeksspel", level: 3, name: "Dynamische driehoeken", description: "Bewegende driehoeken met positiewissels", starRating: 3 },
        { elementName: "Driekhoeksspel", level: 4, name: "Onder druk driehoeken", description: "Driehoeksspel behouden onder tegenstander druk", starRating: 4 },
        { elementName: "Driekhoeksspel", level: 5, name: "Overlappende driehoeken", description: "Meerdere driehoeken simultaan in verschillende zones", starRating: 5 },
        { elementName: "Driekhoeksspel", level: 6, name: "Meesterlijk driehoeksspel", description: "Perfecte driehoekspassingen in alle situaties", starRating: 6 },

        // Positie tussen de linies - Advanced tactical positioning
        { elementName: "Positie tussen de linies", level: 1, name: "Herkennen ruimtes", description: "Zien van open ruimtes tussen verdedigingslinies", starRating: 1 },
        { elementName: "Positie tussen de linies", level: 2, name: "Bewust positioneren", description: "Actief zoeken naar posities tussen linies", starRating: 2 },
        { elementName: "Positie tussen de linies", level: 3, name: "Timing beweging", description: "Juiste moment vinden om tussen linies te bewegen", starRating: 3 },
        { elementName: "Positie tussen de linies", level: 4, name: "Onder druk opereren", description: "Effectief spelen tussen linies ondanks druk", starRating: 4 },
        { elementName: "Positie tussen de linies", level: 5, name: "Creatieve oplossingen", description: "Innovatieve acties vanuit positie tussen linies", starRating: 5 },
        { elementName: "Positie tussen de linies", level: 6, name: "Meesterlijke positionering", description: "Perfecte benutting van ruimtes tussen alle linies", starRating: 6 }
      ];

      // Save to exercises table as IADATABANK category
      let savedCount = 0;
      
      for (const element of completeElements) {
        try {
          const exerciseData = {
            name: element.name,
            description: element.description,
            mainTopic: element.topic,
            subTopic: element.subtopic,
            difficulty: element.difficulty,
            duration: 30, // Default 30 minutes
            equipment: "Voetbal, pionnen",
            objectives: `Ontwikkeling van ${element.name.toLowerCase()}`,
            instructions: `Training oefening voor ${element.name.toLowerCase()} ontwikkeling`
          };
          
          await storage.createExercise(exerciseData);
          savedCount++;
        } catch (error) {
          console.log(`Element ${element.name} already exists or error occurred`);
        }
      }
      
      console.log(`IADATABANK saved: ${savedCount} elements successfully stored`);
      
      res.json({ 
        success: true, 
        message: 'Volledige IADATABANK permanent opgeslagen in database',
        elementsCount: savedCount,
        totalElements: completeElements.length,
        depthLevelsCount: progressiveDepthLevels.length,
        topics: ['BASICS', 'TEAMTACTISCH', 'MENTAAL', 'PHYSIEK'],
        subtopics: ['B+', 'B-', 'B+_BALBEZIT', 'B+_VOORUITGANG', 'B+_DOELPUNTEN', 'B-_DRUK', 'OMSCH_B-_B+', 'OMSCH_B+_B-', 'ALGEMEEN_MENTAAL', 'ALGEMEEN_FYSIEK']
      });
    } catch (error) {
      console.error('Error saving complete IADATABANK:', error);
      res.status(500).json({ error: 'Failed to save complete IADATABANK' });
    }
  });

  // Configure multer for file uploads
  const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
  });

  // IADATABANK - Exercise Categories Routes
  apiRouter.get('/exercise-categories', async (req, res) => {
    try {
      const categories = await storage.getExerciseCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch exercise categories', error: (error as Error).message });
    }
  });

  apiRouter.post('/exercise-categories', isAuthenticated, async (req, res) => {
    try {
      const category = await storage.createExerciseCategory(req.body);
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create exercise category', error: (error as Error).message });
    }
  });

  // IADATABANK - Elements Route (authentic data restored from user's backup)
  apiRouter.get('/iadatabank/elements', async (req, res) => {
    try {
      // Create exactly 144 elements as per authentic IADATABANK structure
      const allElements = [
        // BASICS B+ - 17 elements (GOUD)
        // BASICS B+ with authentic progressions from user data
        {
          id: 'bas-b-plus-1',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Leiden van de bal',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig bal leiden', description: 'Basis balbeheersing', difficulty: 1 },
            { level: 2, name: 'Gericht bal leiden', description: 'Bewuste richting kiezen', difficulty: 2 },
            { level: 3, name: 'Gericht bal snel bal leiden', description: 'Snelheid combineren met richting', difficulty: 3 },
            { level: 4, name: 'Blind gericht snel bal leiden', description: 'Zonder naar bal te kijken', difficulty: 4 },
            { level: 5, name: 'Onder Druk blind gericht snel bal leiden', description: 'Met tegenstander in de buurt', difficulty: 5 },
            { level: 6, name: 'Onder druk blind gericht snel bal leiden én actie', description: 'Combineren met volgende actie', difficulty: 6 }
          ]
        },
        {
          id: 'bas-b-plus-2',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Dribbelen met de bal',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig dribbelen', description: 'Basis dribbelen', difficulty: 1 },
            { level: 2, name: 'Eenvoudig dribbelen/Tricks', description: 'Met simpele trucjes', difficulty: 2 },
            { level: 3, name: 'Gericht dribbelen/Tricks', description: 'Bewust richting kiezen', difficulty: 3 },
            { level: 4, name: 'Gericht snel dribbelen', description: 'Snelle uitvoering', difficulty: 4 },
            { level: 5, name: 'Gericht snel dribbelen op het juiste moment', description: 'Timing herkennen', difficulty: 5 },
            { level: 6, name: 'Gericht snel dribbelen onder druk en actie', description: 'Met vervolgactie onder druk', difficulty: 6 }
          ]
        },
        {
          id: 'bas-b-plus-3',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Korte Passing',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Korte pass juiste richting', description: 'Basis passeren', difficulty: 1 },
            { level: 2, name: 'Korte pass binnenkant voet', description: 'Techniek verfijnen', difficulty: 2 },
            { level: 3, name: 'Gerichte korte pass', description: 'Bewust naar teamgenoot', difficulty: 3 },
            { level: 4, name: 'Korte pass op de juiste voet', description: 'Op juiste voet spelen', difficulty: 4 },
            { level: 5, name: 'Korte pass op juiste snelheid', description: 'Perfecte dosering', difficulty: 5 },
            { level: 6, name: 'Korte pass in de loop voor volgende actie', description: 'Anticiperen op vervolgactie', difficulty: 6 }
          ]
        },
        // BAS004 - Middellange Passing
        {
          id: 'bas-b-plus-4',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Middellange Passing',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 3, name: 'Eenvoudige Middellange pass', description: 'Basis middellange afstand', difficulty: 3 },
            { level: 4, name: 'Gerichte middellange pass', description: 'Bewust richten', difficulty: 4 },
            { level: 5, name: 'Gerichte middellange pass op juiste voet op juiste snelheid', description: 'Perfecte dosering', difficulty: 5 },
            { level: 6, name: 'Gerichte middellange pass op juiste voet op juiste snelheid voor volgende actie', description: 'Met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS005 - Lange Passing
        {
          id: 'bas-b-plus-5',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Lange Passing',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 4, name: 'Gerichte lange passing', description: 'Eerste lange ballen', difficulty: 4 },
            { level: 5, name: 'Gerichte lange passing', description: 'Verfijning techniek', difficulty: 5 },
            { level: 6, name: 'Gerichte lange passing op juiste snelheid /ruimte', description: 'Perfecte lange bal', difficulty: 6 }
          ]
        },
        // BAS006 - Passing met het Hoofd
        {
          id: 'bas-b-plus-6',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Passing met het Hoofd',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 4, name: 'Eenvoudig koppen', description: 'Basis kopbal techniek', difficulty: 4 },
            { level: 5, name: 'Gericht koppen', description: 'Bewust richting kiezen', difficulty: 5 },
            { level: 6, name: 'Gericht koppen in de juiste richting onder druk', description: 'Onder druk koppen', difficulty: 6 }
          ]
        },
        // BAS007 - 1 tijd Passing/Kaatsen
        {
          id: 'bas-b-plus-7',
          topic: 'BASICS',
          subtopic: 'B+',
          name: '1 tijd Passing/Kaatsen',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 3, name: 'Kaats korte passing juiste richting', description: 'Basis kaatsen', difficulty: 3 },
            { level: 4, name: 'Gerichte Kaats korte passing gericht', description: 'Bewust kaatsen', difficulty: 4 },
            { level: 5, name: 'Gerichte Kaats korte passing op juiste voet', description: 'Op juiste voet', difficulty: 5 },
            { level: 6, name: 'Gerichte kaats korte passing in de loop voor volgende actie', description: 'Met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS008 - Balcontrole Korte Pass
        {
          id: 'bas-b-plus-8',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Balcontrole Korte Pass',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudige controle op korte pass', description: 'Basis balcontrole', difficulty: 1 },
            { level: 2, name: 'Controle binnenkant voet', description: 'Techniek verfijnen', difficulty: 2 },
            { level: 3, name: 'Gerichte controle met juiste voet', description: 'Bewuste keuze voet', difficulty: 3 },
            { level: 4, name: 'Gerichte controle op snelheid/in de loop', description: 'In beweging', difficulty: 4 },
            { level: 5, name: 'Gerichte controle op snelheid/in de loop onder druk', description: 'Onder druk', difficulty: 5 },
            { level: 6, name: 'Gerichte controle op snelheid/in de loop onder druk voor volgende actie', description: 'Met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS009 - Balcontrole Middellange Pass
        {
          id: 'bas-b-plus-9',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Balcontrole Middellange Pass',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 3, name: 'Controle juiste dij/voet', description: 'Basis middellange controle', difficulty: 3 },
            { level: 4, name: 'Gerichte controle dij/voet op snelheid/in de loop', description: 'In beweging', difficulty: 4 },
            { level: 5, name: 'Gerichte controle dij/voet op snelheid/in de loop onder druk', description: 'Onder druk', difficulty: 5 },
            { level: 6, name: 'Gerichte controle dij/voet op snelheid/in de loop onder druk voor volgende actie', description: 'Met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS010 - Balcontrole Lange Pass
        {
          id: 'bas-b-plus-10',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Balcontrole Lange Pass',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 4, name: 'Controle borst/dij/voet', description: 'Basis lange bal controle', difficulty: 4 },
            { level: 5, name: 'Gerichte controle borst/dij/juiste voet in de loop', description: 'In beweging', difficulty: 5 },
            { level: 6, name: 'Gerichte controle borst/dij/juiste voet in de loop voor volgende actie', description: 'Met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS011 - Schieten op doel
        {
          id: 'bas-b-plus-11',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Schieten op doel',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig schieten op doel', description: 'Basis schieten', difficulty: 1 },
            { level: 2, name: 'Gericht Schieten op doel', description: 'Bewust richten', difficulty: 2 },
            { level: 3, name: 'Gericht en met juiste voet schieten', description: 'Voorkeur voet', difficulty: 3 },
            { level: 4, name: 'Snel gericht en met juiste voet schieten', description: 'Snelle uitvoering', difficulty: 4 },
            { level: 5, name: 'Onder druk snel en gericht schieten met juiste voet', description: 'Onder druk', difficulty: 5 },
            { level: 6, name: 'Onder druk snel en gericht schieten met juiste voet en navolgen', description: 'Met navolgen', difficulty: 6 }
          ]
        },
        // BAS012 - Scoren met de voet
        {
          id: 'bas-b-plus-12',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Scoren met de voet',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig scoren', description: 'Basis scoren', difficulty: 1 },
            { level: 2, name: 'Scoren met de wreef', description: 'Techniek verfijnen', difficulty: 2 },
            { level: 3, name: 'Gericht scoren met de wreef', description: 'Bewust plaatsen', difficulty: 3 },
            { level: 4, name: 'Snel gericht scoren met de juiste wreef', description: 'Snelle uitvoering', difficulty: 4 },
            { level: 5, name: 'Snel gericht onder druk scoren met de juiste wreef', description: 'Onder druk', difficulty: 5 },
            { level: 6, name: 'Scoren na indiv.actie (Dribbel/Intensity Run) onder druk met de juiste wreef', description: 'Na individuele actie', difficulty: 6 }
          ]
        },
        // BAS013 - Scoren met het hoofd
        {
          id: 'bas-b-plus-13',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Scoren met het hoofd',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 4, name: 'Eenvoudig scoren met het hoofd', description: 'Basis kopbal afwerking', difficulty: 4 },
            { level: 5, name: 'Gericht scoren met het hoofd', description: 'Bewust richting kiezen', difficulty: 5 },
            { level: 6, name: 'Gericht scoren met het hoofd onder druk/positie voor doel innemend/detente', description: 'Onder druk en tactisch slim', difficulty: 6 }
          ]
        },
        // BAS015 - Scoren na individuele actie/trucks
        {
          id: 'bas-b-plus-14',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Scoren na individuele actie/trucks',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Trick + Eenvoudig scoren', description: 'Basis trucje met afwerking', difficulty: 1 },
            { level: 2, name: 'Trick + Scoren met de wreef', description: 'Trucje met technische afwerking', difficulty: 2 },
            { level: 3, name: 'Trick+Gericht scoren met de wreef', description: 'Trucje met gerichte afwerking', difficulty: 3 },
            { level: 4, name: 'Trick+Snel gericht scoren met de juiste wreef', description: 'Snelle uitvoering na trucje', difficulty: 4 },
            { level: 5, name: 'Trick+Snel gericht onder druk scoren met de juiste wreef', description: 'Onder druk na individuele actie', difficulty: 5 },
            { level: 6, name: 'Scoren na indiv.actie (Dribbel/Intensity Run) onder druk met de juiste wreef', description: 'Complexe individuele actie met afwerking', difficulty: 6 }
          ]
        },
        // BAS016 - Vrijlopen - Aanspeelbaar zijn
        {
          id: 'bas-b-plus-15',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Vrijlopen - Aanspeelbaar zijn',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 2, name: 'Eenvoudig aanspeelbaar zijn + scan', description: 'Basis vrij lopen met observatie', difficulty: 2 },
            { level: 3, name: 'Altijd aanspeelbaar zijn+scan', description: 'Constant beschikbaar zijn', difficulty: 3 },
            { level: 4, name: 'Snel aanspeelbaar zijn+scan', description: 'Snelle bewegingen', difficulty: 4 },
            { level: 5, name: 'Snel aanspeelbaar zijn onder druk+scan', description: 'Vrijlopen onder druk', difficulty: 5 },
            { level: 6, name: 'Snel aanspeelbaar zijn onder druk en met oog op volgende actie+scan', description: 'Tactisch vrijlopen met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS017 - Goed ingedraaid staan
        {
          id: 'bas-b-plus-16',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Goed ingedraaid staan',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 2, name: 'Eenvoudig goed ingedraaid staan + SCAN', description: 'Basis lichaamsoriëntatie', difficulty: 2 },
            { level: 3, name: 'Altijd goed ingedraaid staan + SCAN', description: 'Constante goede positie', difficulty: 3 },
            { level: 4, name: 'Altijd goed ingedraaid staan op juiste voet + SCAN', description: 'Met correcte voet ontvangen', difficulty: 4 },
            { level: 5, name: 'Snel altijd goed ingedraaid staan op juiste voet + SCAN', description: 'Snelle aanpassing', difficulty: 5 },
            { level: 6, name: 'Snel altijd goed ingedraaid staan op juiste voet onder druk met oog op volgende actie + SCAN', description: 'Onder druk met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS018 - Steun je teamgenoot
        {
          id: 'bas-b-plus-17',
          topic: 'BASICS',
          subtopic: 'B+',
          name: 'Steun je teamgenoot',
          theme: 'Aanvallende Basisvaardigheden',
          progressions: [
            { level: 2, name: 'Eenvoudig steunen & bal vragen', description: 'Basis ondersteuning', difficulty: 2 },
            { level: 3, name: 'Altijd steunen & bal vragen', description: 'Constante ondersteuning', difficulty: 3 },
            { level: 4, name: 'Gericht steunen & bal vragen', description: 'Bewuste ondersteuning', difficulty: 4 },
            { level: 5, name: 'Snel Gericht steunen & bal vragen', description: 'Snelle ondersteuning', difficulty: 5 },
            { level: 6, name: 'Snel Gericht steunen & bal vragen wanneer ploegmaat onder druk staat met oog op volgende actie', description: 'Tactische ondersteuning onder druk', difficulty: 6 }
          ]
        },
        
        // BASICS B- with authentic progressions from user data
        {
          id: 'bas-b-minus-1',
          topic: 'BASICS',
          subtopic: 'B-',
          name: '1: 1 Druk zetten/Tackle/Remmen',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig Druk zetten', description: 'Basis druk zetten', difficulty: 1 },
            { level: 2, name: 'Gericht druk zetten/Tackle/Remmend wijken', description: 'Bewuste keuze maken', difficulty: 2 },
            { level: 3, name: 'Gericht en snel druk zetten/Tackle/Remmend Wijken', description: 'Snelle uitvoering', difficulty: 3 },
            { level: 4, name: 'Gericht en snel druk zetten/Tackle/Remmend Wijken in gelijke aantallen', description: 'In numeriek evenwicht', difficulty: 4 },
            { level: 5, name: 'Gericht en snel druk zetten/Tackle/Remmend Wijken in ondertal', description: 'Met man minder', difficulty: 5 },
            { level: 6, name: 'Gericht en met medespelers snel druk zetten/Tackle/Remmend Wijken in ondertal', description: 'Teamwerk in ondertal', difficulty: 6 }
          ]
        },
        {
          id: 'bas-b-minus-2',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Duel',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudige Duels', description: 'Basis duelvoering', difficulty: 1 },
            { level: 2, name: 'Gerichte Duels', description: 'Bewust duelleren', difficulty: 2 },
            { level: 3, name: 'Gericht en snelle Duels', description: 'Snelle reactie', difficulty: 3 },
            { level: 4, name: 'Gericht en snelle Duels ifv keuze Duel/Remmend Wijken', description: 'Tactische keuze', difficulty: 4 },
            { level: 5, name: 'Gericht en snelle Duels ifv keuze Duel/Remmend Wijken/Gelijke Aantal', description: 'In numeriek evenwicht', difficulty: 5 },
            { level: 6, name: 'Gericht en snelle Duels ifv keuze Duel/Remmend Wijken/Ondertal+goed inspelen', description: 'Met vervolgactie', difficulty: 6 }
          ]
        },
        {
          id: 'bas-b-minus-3',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Interceptie voor balcontrole op korte passing',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig Onderscheppen op lage pass', description: 'Basis onderscheppen', difficulty: 1 },
            { level: 2, name: 'Gericht Onderscheppen vd bal op lage pass', description: 'Bewust onderscheppen', difficulty: 2 },
            { level: 3, name: 'Gericht Onderscheppen op lage pass en goed inspelen', description: 'Met vervolgactie', difficulty: 3 },
            { level: 4, name: 'Gericht Onderscheppen op lage pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Complexere situaties', difficulty: 4 },
            { level: 5, name: 'Snel Gericht Onderscheppen op lage pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Snelle reactie', difficulty: 5 },
            { level: 6, name: 'Onder Druk Snel Gericht Onderscheppen op lage pass(met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Onder druk handelen', difficulty: 6 }
          ]
        },
        // BAS024 - Interceptie voor balcontrole op middellange passing
        {
          id: 'bas-b-minus-4',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Interceptie voor balcontrole op middellange passing',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 3, name: 'Eenvoudig Onderscheppen op midellange pass', description: 'Basis onderscheppen', difficulty: 3 },
            { level: 4, name: 'Gericht Onderscheppen vd bal op midellange pass', description: 'Bewust onderscheppen', difficulty: 4 },
            { level: 5, name: 'Gericht Onderscheppen op midellange pass en goed inspelen', description: 'Met vervolgactie', difficulty: 5 },
            { level: 6, name: 'Onder Druk Snel Gericht Onderscheppen op midellange pass(met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Complexe situaties onder druk', difficulty: 6 }
          ]
        },
        // BAS025 - Interceptie voor balcontrole op lange passing
        {
          id: 'bas-b-minus-5',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Interceptie voor balcontrole op lange passing',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 4, name: 'Gericht Onderscheppen op lange pass en goed inspelen', description: 'Interceptie lange bal', difficulty: 4 },
            { level: 5, name: 'Snel Gericht Onderscheppen op lange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Snelle reactie', difficulty: 5 },
            { level: 6, name: 'Onder Druk Snel Gericht Onderscheppen op lange pass(met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Onder druk handelen', difficulty: 6 }
          ]
        },
        // BAS026 - Interceptie voor balcontrole op kopbal
        {
          id: 'bas-b-minus-6',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Interceptie voor balcontrole op kopbal',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 4, name: 'Eenvoudig Kopduel', description: 'Basis kopbalduel', difficulty: 4 },
            { level: 5, name: 'Kopduel in de loop', description: 'In beweging', difficulty: 5 },
            { level: 6, name: 'Kopduel in de loop + onder druk', description: 'Onder druk', difficulty: 6 }
          ]
        },
        // BAS027 - Interceptie voor balcontrole op kaatsbal
        {
          id: 'bas-b-minus-7',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Interceptie voor balcontrole op kaatsbal',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 3, name: 'Kaatser onder druk zetten', description: 'Druk zetten op kaatser', difficulty: 3 },
            { level: 4, name: 'Kaatser onder druk zetten + anticiperen op de kaats', description: 'Anticiperen op kaats', difficulty: 4 },
            { level: 5, name: 'Kaatser onder druk zetten+ anticiperen op de kaats + keuze bal veroveren/wijken', description: 'Tactische keuze', difficulty: 5 },
            { level: 6, name: 'Kaatser onder druk zetten+ anticiperen op de kaats + keuze bal veroveren/wijken SNEL HANDELEN', description: 'Snelle uitvoering', difficulty: 6 }
          ]
        },
        // BAS028 - Interceptie na balcontrole korte pass
        {
          id: 'bas-b-minus-8',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Interceptie na balcontrole korte pass',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 2, name: 'Trachten te onderscheppen na controle lage pass', description: 'Basis onderscheppen na controle', difficulty: 2 },
            { level: 3, name: 'Trachten te onderscheppen na controle lage pass + niet laten uitschakelen', description: 'Actief blijven', difficulty: 3 },
            { level: 4, name: 'Gericht Onderscheppen vd bal op controle lage pass', description: 'Bewust onderscheppen', difficulty: 4 },
            { level: 5, name: 'Snel Gericht Onderscheppen op controle lage pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Snelle reactie', difficulty: 5 },
            { level: 6, name: 'Onder Druk Snel Gericht Onderscheppen op controle lage pass(met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Onder druk handelen', difficulty: 6 }
          ]
        },
        // BAS029 - Interceptie na balcontrole middellange pass
        {
          id: 'bas-b-minus-9',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Interceptie na balcontrole middellange pass',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 3, name: 'Trachten te onderscheppen na controle middellange pass + niet laten uitschakelen', description: 'Actief blijven na controle', difficulty: 3 },
            { level: 4, name: 'Gericht Onderscheppen op controle midellange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Bewust onderscheppen', difficulty: 4 },
            { level: 5, name: 'Snel Gericht Onderscheppen op controle op midellange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Snelle reactie', difficulty: 5 },
            { level: 6, name: 'Onder Druk Snel Gericht Onderscheppen op controle op midellange pass(met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Onder druk', difficulty: 6 }
          ]
        },
        // BAS030 - Interceptie na balcontrole lange pass
        {
          id: 'bas-b-minus-10',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Interceptie na balcontrole lange pass',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 4, name: 'Gericht Onderscheppen op controle lange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Interceptie na lange bal controle', difficulty: 4 },
            { level: 5, name: 'Snel Gericht Onderscheppen op controle lange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Snelle reactie', difficulty: 5 },
            { level: 6, name: 'Snel Gericht Onderscheppen op controle lange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen', description: 'Complexe situaties', difficulty: 6 }
          ]
        },
        // BAS031 - Afweren/Schieten op doel beletten
        {
          id: 'bas-b-minus-11',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Afweren/Schieten op doel beletten',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig afweren/schieten op doel beletten', description: 'Basis afweren', difficulty: 1 },
            { level: 2, name: 'Gericht afweren/schieten op doel beletten', description: 'Bewust afweren', difficulty: 2 },
            { level: 3, name: 'Snel en Gericht afweren/schieten op doel beletten', description: 'Snelle reactie', difficulty: 3 },
            { level: 4, name: 'Snel/Gericht afweren/schieten op doel beletten in gelijke aantallen', description: 'In numeriek evenwicht', difficulty: 4 },
            { level: 5, name: 'Snel/Gericht afweren/schieten op doel beletten in ondertal', description: 'Met man minder', difficulty: 5 },
            { level: 6, name: 'Snel/Gericht afweren/schieten op doel beletten in ondertal + balveroveren + goed inspelen', description: 'Met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS032 - Afweren/Scoren met de voet beletten
        {
          id: 'bas-b-minus-12',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Afweren/Scoren met de voet beletten',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig afweren/schieten op doel beletten', description: 'Basis afweren', difficulty: 1 },
            { level: 2, name: 'Gericht afweren/schieten op doel beletten', description: 'Bewust afweren', difficulty: 2 },
            { level: 3, name: 'Snel en Gericht afweren/schieten op doel beletten', description: 'Snelle reactie', difficulty: 3 },
            { level: 4, name: 'Snel/Gericht afweren/schieten op doel beletten in gelijke aantallen', description: 'In numeriek evenwicht', difficulty: 4 },
            { level: 5, name: 'Snel/Gericht afweren/schieten op doel beletten in ondertal', description: 'Met man minder', difficulty: 5 },
            { level: 6, name: 'Snel/Gericht afweren/schieten op doel beletten in ondertal + balveroveren + goed inspelen', description: 'Met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS033 - Afweren/Scoren met het hoofd beletten
        {
          id: 'bas-b-minus-13',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Afweren/Scoren met het hoofd beletten',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 4, name: 'Snel en Gericht afweren/koppen op doel beletten', description: 'Kopbal afweren', difficulty: 4 },
            { level: 5, name: 'Snel en Gericht afweren/koppen op doel beletten', description: 'Verfijning techniek', difficulty: 5 },
            { level: 6, name: 'Snel en Gericht afweren/koppen op doel beletten + trachten de bal in de ploeg te houden of safe', description: 'Met balverovering', difficulty: 6 }
          ]
        },
        // BAS035 - Afweren/Scoren na individuele actie/tricks beletten
        {
          id: 'bas-b-minus-14',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Afweren/Scoren na individuele actie/tricks beletten',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 1, name: 'Eenvoudig beletten van tricks', description: 'Basis trucjes tegenhouden', difficulty: 1 },
            { level: 2, name: 'Gericht beletten van tricks', description: 'Bewust trucjes tegenhouden', difficulty: 2 },
            { level: 3, name: 'Snel en Gericht beletten van tricks', description: 'Snelle reactie op trucjes', difficulty: 3 },
            { level: 4, name: 'Snel en gericht beletten van tricks + bal veroveren', description: 'Met balverovering', difficulty: 4 },
            { level: 5, name: 'Snel en gericht beletten van tricks + bal veroveren+ goed inspelen', description: 'Met vervolgactie', difficulty: 5 },
            { level: 6, name: 'Snel en gericht beletten van tricks in ondertal + bal veroveren+ goed inspelen', description: 'In ondertal met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS036 - Speelhoeken afsluiten
        {
          id: 'bas-b-minus-15',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Speelhoeken afsluiten',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 2, name: 'Poortje Dicht houden', description: 'Basis poortje sluiten', difficulty: 2 },
            { level: 3, name: 'Poortjes Dicht houden/Zonedekking', description: 'Meerdere poortjes', difficulty: 3 },
            { level: 4, name: 'Snel Poortjes Dicht houden/Zonedekking ifv andere medespelers', description: 'Teamwork', difficulty: 4 },
            { level: 5, name: 'Snel Poortjes Dicht houden/Zonedekking ifv andere medespelers + balveroveren + goed inspelen (gelijke aantallen)', description: 'In numeriek evenwicht', difficulty: 5 },
            { level: 6, name: 'Snel Poortjes Dicht houden/Zonedekking ifv andere medespelers + balveroveren + goed inspelen (Ondertal)', description: 'In ondertal', difficulty: 6 }
          ]
        },
        // BAS037 - Strikte dekking
        {
          id: 'bas-b-minus-16',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Strikte dekking',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 2, name: 'Eenvoudig goed ingedraaid staan + SCAN', description: 'Basis dekking met observatie', difficulty: 2 },
            { level: 3, name: 'Altijd goed ingedraaid staan + SCAN', description: 'Constante dekking', difficulty: 3 },
            { level: 4, name: 'Altijd goed ingedraaid staan op juiste voet + SCAN', description: 'Tactische dekking', difficulty: 4 },
            { level: 5, name: 'Snel altijd goed ingedraaid staan op juiste voet + SCAN', description: 'Snelle aanpassing', difficulty: 5 },
            { level: 6, name: 'Snel altijd goed ingedraaid staan op juiste voet onder druk met oog op volgende actie+SCAN', description: 'Onder druk met vervolgactie', difficulty: 6 }
          ]
        },
        // BAS038 - Rugdekking
        {
          id: 'bas-b-minus-17',
          topic: 'BASICS',
          subtopic: 'B-',
          name: 'Rugdekking',
          theme: 'Verdedigende Basisvaardigheden',
          progressions: [
            { level: 2, name: 'Eenvoudig rugdekking geven', description: 'Basis rugdekking', difficulty: 2 },
            { level: 3, name: 'Eenvoudig rugdekking geven + paslijnen belemmeren', description: 'Met paslijnen blokkeren', difficulty: 3 },
            { level: 4, name: 'Rugdekking geven + paslijnen belemmeren', description: 'Actieve rugdekking', difficulty: 4 },
            { level: 5, name: 'Gericht Rugdekking geven + paslijnen belemmeren', description: 'Bewuste rugdekking', difficulty: 5 },
            { level: 6, name: 'Altijd gerichte rugdekking geven in ondertal, klaar om te onderscheppen-Onderschept en goed inspelen', description: 'In ondertal met interceptie', difficulty: 6 }
          ]
        },
        
        // TEAMTACTISCH B+ - 21 elements with authentic progressions
        ...["Creeer ruimte", "Creeer hoogte diepte", "Creeer meerderheidssituaties", "Speel simpel korte passing",
            "Bouw op verdedigend derde", "Bouw op middenveld", "Bouw op aanvallend derde", "Switchen van speelhelft",
            "Positiespel", "Driehoeken vormen", "Lijnspel", "Tempo variatie", "Combinatiespel", "Opbouw vanaf keeper",
            "Flanken bespelen", "Centrale opbouw", "Balbezit behouden", "Ruimte creeren", "Speeldiepte", "Speelbreedte", "Aanvalsvariatie"].map((name, index) => ({
          id: `team-b-plus-${index + 1}`,
          topic: 'TEAMTACTISCH',
          subtopic: 'B+',
          name: name,
          theme: 'Opbouwend Spel',
          progressions: [
            { level: 1, name: 'Eenvoudig begrip principe', description: 'Basis tactisch inzicht', difficulty: 1 },
            { level: 2, name: 'Gericht toepassen met partner', description: 'Met één medespeler', difficulty: 2 },
            { level: 3, name: 'Gericht snel in kleine groep', description: 'Met 2-3 spelers', difficulty: 3 },
            { level: 4, name: 'Onder druk als linie', description: 'Hele linie betrokken', difficulty: 4 },
            { level: 5, name: 'Toepassing heel team', description: 'Team-breed principe', difficulty: 5 },
            { level: 6, name: 'Automatisme onder matchdruk', description: 'Perfecte uitvoering in wedstrijd', difficulty: 6 }
          ]
        })),
        
        // TEAMTACTISCH B- - 21 elements with authentic progressions
        ...["Druk zetten collectief", "Tackle als team", "Remmen en organiseren", "Dekken en afsluiten", "Positie tussen de linies", "Compacte defensie",
            "Verdedigende organisatie", "Pressing", "Gegenpressing", "Defensive block", "Buitenspelval",
            "Sliding tackle timing", "Standing tackle positie", "Intercepteren anticiperen", "Verdedigende communicatie", "Zone verdedigen",
            "Mandekking", "Dubbele dekking", "Verdedigende kopballen", "Wegwerken", "Defensieve positionering"].map((name, index) => ({
          id: `team-b-minus-${index + 1}`,
          topic: 'TEAMTACTISCH',
          subtopic: 'B-',
          name: name,
          theme: 'Verdedigend Spel',
          progressions: [
            { level: 1, name: 'Eenvoudig begrip defensief principe', description: 'Basis verdedigend inzicht', difficulty: 1 },
            { level: 2, name: 'Gericht verdedigen met partner', description: 'Met één medespeler', difficulty: 2 },
            { level: 3, name: 'Gericht snel in kleine defensieve groep', description: 'Met 2-3 verdedigers', difficulty: 3 },
            { level: 4, name: 'Onder druk als defensieve linie', description: 'Hele verdedigende linie', difficulty: 4 },
            { level: 5, name: 'Toepassing heel team verdedigend', description: 'Team-brede defensieve organisatie', difficulty: 5 },
            { level: 6, name: 'Automatisme defensief onder matchdruk', description: 'Perfecte verdedigende uitvoering', difficulty: 6 }
          ]
        })),
        
        // MENTAAL - 29 elements with authentic progressions
        ...["Concentratie", "Zelfvertrouwen", "Stressbestendigheid", "Motivatie", "Doelgerichtheid", 
            "Inzicht", "Besluitvaardigheid", "Creativiteit", "Mentale flexibiliteit", "Weerbaarheid",
            "Zelfregulering", "Volharding", "Zelfbeeld", "Leersnelheid", "Leervermogen", 
            "Persoonlijkheid", "Leiderschap", "Betrokkenheid", "Focus", "Respectvol gedrag",
            "Spelinterpretatie", "Drukweerstand", "Teamcommunicatie", "Mentale veerkracht", "Discipline",
            "Competitieve instelling", "Teamgeest", "Wedstrijdmentaliteit", "Coachbaarheid"].map((name, index) => ({
          id: `mentaal-${index + 1}`,
          topic: 'MENTAAL',
          subtopic: 'ALGEMEEN',
          name: name,
          theme: 'Mentale Aspecten',
          progressions: [
            { level: 1, name: 'Bewustwording aspect', description: 'Herkenning van mentaal aspect', difficulty: 1 },
            { level: 2, name: 'Gerichte ontwikkeling', description: 'Bewust werken aan aspect', difficulty: 2 },
            { level: 3, name: 'Toepassing in training', description: 'Structurele toepassing', difficulty: 3 },
            { level: 4, name: 'Handhaving onder stress', description: 'Onder verhoogde druk', difficulty: 4 },
            { level: 5, name: 'Consistente toepassing', description: 'Betrouwbare uitvoering', difficulty: 5 },
            { level: 6, name: 'Optimale prestatie wedstrijd', description: 'Maximale mentale prestatie', difficulty: 6 }
          ]
        })),
        
        // PHYSIEK - 29 elements with authentic progressions
        ...["Algemene uithouding", "Basismotoriek", "Oog-handcoördinatie", "Oog-voetcoördinatie", "Evenwichtscontrole",
            "Reactiesnelheid", "Natuurlijke lenigheid", "Ritmegevoel", "Loopcoördinatie", "Looptechniek", "Flexibiliteit",
            "Snelheid", "Basisforce", "Lichaamsbouw", "Startsnelheid", "Acceleratievermogen", "Snelheidsuithoudingsvermogen",
            "Herhaald springvermogen", "Wendbaarheid tijdens sprint", "Herstelvermogen", "Verticale sprongkracht",
            "Schietkracht", "Duelkracht", "Werpkracht", "Explosieve kracht", "Krachtuithouding", "Handelingssnelheid",
            "Blessurepreventie", "Explosiviteit"].map((name, index) => ({
          id: `physiek-${index + 1}`,
          topic: 'PHYSIEK',
          subtopic: 'ALGEMEEN',
          name: name,
          theme: 'Fysieke Conditie',
          progressions: [
            { level: 1, name: 'Fundamentele basis ontwikkeling', description: 'Eerste fysieke ontwikkeling', difficulty: 1 },
            { level: 2, name: 'Gerichte fysieke verbetering', description: 'Bewuste fysieke training', difficulty: 2 },
            { level: 3, name: 'Voetbalspecifieke integratie', description: 'Toepassing in voetbal context', difficulty: 3 },
            { level: 4, name: 'Hogere belasting en intensiteit', description: 'Verhoogde trainingsintensiteit', difficulty: 4 },
            { level: 5, name: 'Wedstrijdtempo en intensiteit', description: 'Matchspecifieke belasting', difficulty: 5 },
            { level: 6, name: 'Maximale fysieke prestatie', description: 'Optimale fysieke capaciteit', difficulty: 6 }
          ]
        })),
        
        // OMSCHAKELING - 10 elements with authentic progressions
        ...["Balbezit naar balverlies", "Balverlies naar balbezit", "Snelle omschakeling aanvallend", "Snelle omschakeling verdedigend",
            "Positionele omschakeling", "Tactische omschakeling", "Gegenpressing", "Contraanval",
            "Verdedigingsorganisatie na balverlies", "Aanvalsorganisatie na balverovering"].map((name, index) => ({
          id: `omschakeling-${index + 1}`,
          topic: 'OMSCHAKELING',
          subtopic: 'ALGEMEEN',
          name: name,
          theme: 'Spelomschakeling',
          progressions: [
            { level: 1, name: 'Eenvoudig', description: 'Herkenning van het moment', difficulty: 1 },
            { level: 2, name: 'Gericht', description: 'Juiste actie kiezen', difficulty: 2 },
            { level: 3, name: 'Gericht snel', description: 'Snelle reactie uitvoering', difficulty: 3 },
            { level: 4, name: 'Onder druk', description: 'Collectieve omschakeling', difficulty: 4 },
            { level: 5, name: 'Toepassing', description: 'Geautomatiseerde reactie', difficulty: 5 },
            { level: 6, name: 'Meesterschap', description: 'Perfecte omschakeling onder matchdruk', difficulty: 6 }
          ]
        })),

        // TACTICS Elements - New category for teamtactics/spelomschakeling
        // TACTICS B+ Elements (8 total)
        ...["POSITIESPEL", "DRIEHOEKEN_VORMEN", "CREEER_RUIMTE", "CREEER_HOOGTE_DIEPTE",
            "OPBOUW_VAN_ACHTERUIT", "COMBINATIESPEL", "AANVALSORGANISATIE", "BREEDTE_CREEREN"
           ].map((element, index) => ({
          id: `tactics-b-plus-${index + 1}`,
          topic: 'TACTICS',
          subtopic: 'B+',
          name: element.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase()),
          theme: 'Aanvallende Teamtactieken',
          level: 'B+',
          progressions: [
            { level: 1, name: 'Eenvoudig', description: 'Basis teamtactiek herkenning', difficulty: 1 },
            { level: 2, name: 'Gericht', description: 'Bewuste teamtactische keuzes', difficulty: 2 },
            { level: 3, name: 'Gericht snel', description: 'Snelle teamtactische uitvoering', difficulty: 3 },
            { level: 4, name: 'Onder druk', description: 'Teamtactiek onder tegenstander druk', difficulty: 4 },
            { level: 5, name: 'Toepassing', description: 'Geavanceerde teamtactische oplossingen', difficulty: 5 },
            { level: 6, name: 'Meesterschap', description: 'Perfecte teamtactische uitvoering', difficulty: 6 }
          ]
        })),

        // TACTICS B- Elements (8 total)
        ...["PRESSING", "KOMPAKT_VERDEDIGEN", "DEFENSIEVE_ORGANISATIE", "ZONE_DEKKING",
            "STRIKTE_DEKKING", "RUGDEKKING", "AFSLUITEN_SPEELHOEKEN", "VERDEDIGENDE_COMMUNICATIE"
           ].map((element, index) => ({
          id: `tactics-b-minus-${index + 1}`,
          topic: 'TACTICS',
          subtopic: 'B-',
          name: element.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase()),
          theme: 'Verdedigende Teamtactieken',
          level: 'B-',
          progressions: [
            { level: 1, name: 'Eenvoudig', description: 'Basis verdedigende teamtactiek', difficulty: 1 },
            { level: 2, name: 'Gericht', description: 'Georganiseerde verdediging', difficulty: 2 },
            { level: 3, name: 'Gericht snel', description: 'Snelle verdedigende reacties', difficulty: 3 },
            { level: 4, name: 'Onder druk', description: 'Verdedigen onder aanvallende druk', difficulty: 4 },
            { level: 5, name: 'Toepassing', description: 'Geavanceerde verdedigende tactieken', difficulty: 5 },
            { level: 6, name: 'Meesterschap', description: 'Perfecte verdedigende organisatie', difficulty: 6 }
          ]
        })),

        // TACTICS OMSCH B+/B- Elements (4 total)
        ...["BALVEROVERING_NAAR_AANVAL", "SNELLE_OPBOUW", "TRANSITIE_VERDEDIGING_AANVAL", "COUNTER_ATTACKING"
           ].map((element, index) => ({
          id: `tactics-omsch-bplus-bminus-${index + 1}`,
          topic: 'TACTICS',
          subtopic: 'OMSCH B+/B-',
          name: element.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase()),
          theme: 'Omschakeling Verdediging naar Aanval',
          level: 'OMSCH B+/B-',
          progressions: [
            { level: 1, name: 'Eenvoudig', description: 'Basis omschakeling naar aanval', difficulty: 1 },
            { level: 2, name: 'Gericht', description: 'Bewuste transitie naar aanval', difficulty: 2 },
            { level: 3, name: 'Gericht snel', description: 'Snelle omschakeling naar aanval', difficulty: 3 },
            { level: 4, name: 'Onder druk', description: 'Omschakeling onder tijdsdruk', difficulty: 4 },
            { level: 5, name: 'Toepassing', description: 'Perfecte transitiemomenten benutten', difficulty: 5 },
            { level: 6, name: 'Meesterschap', description: 'Lethale counter-attacks', difficulty: 6 }
          ]
        })),

        // TACTICS OMSCHAK B-/B+ Elements (4 total)
        ...["BALVERLIES_REACTIE", "IMMEDIATE_PRESSING", "TRANSITIE_AANVAL_VERDEDIGING", "DEFENSIVE_TRANSITION"
           ].map((element, index) => ({
          id: `tactics-omschak-bminus-bplus-${index + 1}`,
          topic: 'TACTICS',
          subtopic: 'OMSCHAK B-/B+',
          name: element.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase()),
          theme: 'Omschakeling Aanval naar Verdediging',
          level: 'OMSCHAK B-/B+',
          progressions: [
            { level: 1, name: 'Eenvoudig', description: 'Basis omschakeling naar verdediging', difficulty: 1 },
            { level: 2, name: 'Gericht', description: 'Bewuste transitie naar verdediging', difficulty: 2 },
            { level: 3, name: 'Gericht snel', description: 'Snelle omschakeling naar verdediging', difficulty: 3 },
            { level: 4, name: 'Onder druk', description: 'Defensieve transitie onder druk', difficulty: 4 },
            { level: 5, name: 'Toepassing', description: 'Perfecte defensieve reorganisatie', difficulty: 5 },
            { level: 6, name: 'Meesterschap', description: 'Onmiddellijke defensieve stabiliteit', difficulty: 6 }
          ]
        }))
      ];
      
      // Filter out any undefined or invalid elements and ensure exactly 144 elements
      const validElements = allElements.filter(el => el && el.id && el.name);
      const finalElements = validElements.slice(0, 144); // Ensure exactly 144 elements
      
      console.log(`Successfully loaded ${finalElements.length} IADATABANK elements`);
      res.json({ data: finalElements });
      
    } catch (error) {
      console.error('IADATABANK elements error:', error);
      res.status(500).json({ message: 'Failed to load IADATABANK elements', error: (error as Error).message });
    }
  });

  // IADATABANK Element Details API - Get specific element progressions from database
  apiRouter.get('/iadatabank/element/:elementName', async (req, res) => {
    try {
      const { elementName } = req.params;
      const { topic, subtopic } = req.query;
      
      // Gebruik dezelfde elements array als de hoofdroute - GEEN DUPLICATEN
      const response = await fetch(`${req.protocol}://${req.get('host')}/api/iadatabank/elements`);
      const { data: allElements } = await response.json();
      
      const element = allElements.find(el => 
        el.name === elementName && 
        el.topic === topic && 
        el.subtopic === subtopic
      );
      
      if (!element) {
        return res.status(404).json({ message: "Element not found" });
      }
      
      res.json(element);
      
    } catch (error) {
      console.error('IADATABANK element details error:', error);
      res.status(500).json({ message: 'Failed to load element details', error: (error as Error).message });
    }
  });

  // IADATABANK - Exercises Routes
  apiRouter.get('/exercises', async (req, res) => {
    try {
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      const mainTopic = req.query.mainTopic as string | undefined;
      const exercises = await storage.getExercises(categoryId, mainTopic);
      res.json(exercises);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch exercises', error: (error as Error).message });
    }
  });

  apiRouter.post('/exercises', isAuthenticated, async (req, res) => {
    try {
      const exercise = await storage.createExercise(req.body);
      res.status(201).json(exercise);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create exercise', error: (error as Error).message });
    }
  });

  apiRouter.put('/exercises/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const exercise = await storage.updateExercise(id, req.body);
      if (!exercise) {
        return res.status(404).json({ message: 'Exercise not found' });
      }
      res.json(exercise);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update exercise', error: (error as Error).message });
    }
  });

  apiRouter.delete('/exercises/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteExercise(id);
      if (!success) {
        return res.status(404).json({ message: 'Exercise not found' });
      }
      res.json({ message: 'Exercise deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete exercise', error: (error as Error).message });
    }
  });

  // IADATABANK - Training Programs Routes
  apiRouter.get('/training-programs', async (req, res) => {
    try {
      const programs = await storage.getTrainingPrograms();
      res.json(programs);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch training programs', error: (error as Error).message });
    }
  });

  apiRouter.post('/training-programs', isAuthenticated, async (req, res) => {
    try {
      const program = await storage.createTrainingProgram(req.body);
      res.status(201).json(program);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create training program', error: (error as Error).message });
    }
  });

  // IADATABANK - Excel Import Route
  apiRouter.post('/exercises/import-excel', isAuthenticated, upload.single('excel'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No Excel file uploaded' });
      }

      const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(worksheet);

      let importedCount = 0;
      const errors: string[] = [];

      for (const row of data) {
        try {
          const exerciseData = {
            categoryId: row['Category ID'] || 1,
            name: row['Naam'] || row['Name'] || '',
            description: row['Beschrijving'] || row['Description'] || '',
            instructions: row['Uitvoering'] || row['Instructions'] || '',
            objectives: row['Doelstellingen'] || row['Objectives'] || '',
            equipment: row['Materiaal'] || row['Equipment'] || 'geen',
            intensity: row['Intensiteit'] || row['Intensity'] || 'matig',
            difficulty: row['Moeilijkheid'] || row['Difficulty'] || 'beginner',
            duration: row['Duur'] ? parseInt(row['Duur']) : null,
            minPlayers: row['Min Spelers'] ? parseInt(row['Min Spelers']) : 1,
            maxPlayers: row['Max Spelers'] ? parseInt(row['Max Spelers']) : null,
            spaceRequired: row['Ruimte'] || row['Space'] || '',
            tags: row['Tags'] ? row['Tags'].split(',').map((tag: string) => tag.trim()) : [],
            createdBy: req.user?.id
          };

          if (exerciseData.name) {
            await storage.createExercise(exerciseData);
            importedCount++;
          }
        } catch (error) {
          errors.push(`Row error: ${(error as Error).message}`);
        }
      }

      res.json({
        message: `Successfully imported ${importedCount} exercises`,
        importedCount,
        errors: errors.length > 0 ? errors : undefined
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to import Excel file', error: (error as Error).message });
    }
  });

  // Users routes
  apiRouter.get('/users', async (req, res) => {
    try {
      const role = req.query.role as string | undefined;
      const users = await storage.getUsers(role);
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch users', error: (error as Error).message });
    }
  });

  apiRouter.get('/users/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user', error: (error as Error).message });
    }
  });

  apiRouter.post('/users', async (req, res) => {
    try {
      const validateUser = insertUserSchema.safeParse(req.body);
      if (!validateUser.success) {
        return res.status(400).json({ message: 'Invalid user data', errors: validateUser.error.errors });
      }

      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(409).json({ message: 'Username already exists' });
      }

      const existingEmail = await storage.getUserByEmail(req.body.email);
      if (existingEmail) {
        return res.status(409).json({ message: 'Email already exists' });
      }

      const user = await storage.createUser(validateUser.data);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create user', error: (error as Error).message });
    }
  });

  apiRouter.put('/users/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // If username is being updated, check if it already exists
      if (req.body.username && req.body.username !== user.username) {
        const existingUser = await storage.getUserByUsername(req.body.username);
        if (existingUser && existingUser.id !== id) {
          return res.status(409).json({ message: 'Username already exists' });
        }
      }

      // If email is being updated, check if it already exists
      if (req.body.email && req.body.email !== user.email) {
        const existingEmail = await storage.getUserByEmail(req.body.email);
        if (existingEmail && existingEmail.id !== id) {
          return res.status(409).json({ message: 'Email already exists' });
        }
      }

      const updatedUser = await storage.updateUser(id, req.body);
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user', error: (error as Error).message });
    }
  });

  apiRouter.delete('/users/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      await storage.deleteUser(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete user', error: (error as Error).message });
    }
  });

  // Teams routes
  apiRouter.get('/teams', async (req, res) => {
    try {
      const teams = await storage.getTeams();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch teams', error: (error as Error).message });
    }
  });

  apiRouter.get('/teams/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const team = await storage.getTeam(id);
      if (!team) {
        return res.status(404).json({ message: 'Team not found' });
      }
      res.json(team);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch team', error: (error as Error).message });
    }
  });

  apiRouter.post('/teams', async (req, res) => {
    try {
      const validateTeam = insertTeamSchema.safeParse(req.body);
      if (!validateTeam.success) {
        return res.status(400).json({ message: 'Invalid team data', errors: validateTeam.error.errors });
      }

      const team = await storage.createTeam(validateTeam.data);
      res.status(201).json(team);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create team', error: (error as Error).message });
    }
  });

  apiRouter.put('/teams/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const team = await storage.getTeam(id);
      if (!team) {
        return res.status(404).json({ message: 'Team not found' });
      }

      const updatedTeam = await storage.updateTeam(id, req.body);
      res.json(updatedTeam);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update team', error: (error as Error).message });
    }
  });
  
  // Support PATCH method for partial updates
  apiRouter.patch('/teams/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const team = await storage.getTeam(id);
      if (!team) {
        return res.status(404).json({ message: 'Team not found' });
      }

      const updatedTeam = await storage.updateTeam(id, req.body);
      res.json(updatedTeam);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update team', error: (error as Error).message });
    }
  });

  apiRouter.delete('/teams/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const team = await storage.getTeam(id);
      if (!team) {
        return res.status(404).json({ message: 'Team not found' });
      }

      await storage.deleteTeam(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete team', error: (error as Error).message });
    }
  });

  // Players routes
  apiRouter.get('/players', async (req, res) => {
    try {
      const teamId = req.query.teamId ? parseInt(req.query.teamId as string) : undefined;
      const players = await storage.getPlayers(teamId);
      
      // Enrich player data with user info and team info
      const enrichedPlayers = await Promise.all(players.map(async (player) => {
        const user = await storage.getUser(player.userId);
        const team = player.teamId ? await storage.getTeam(player.teamId) : null;
        return {
          ...player,
          user,
          team
        };
      }));
      
      res.json(enrichedPlayers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch players', error: (error as Error).message });
    }
  });

  apiRouter.get('/players/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const player = await storage.getPlayer(id);
      if (!player) {
        return res.status(404).json({ message: 'Player not found' });
      }
      
      const user = await storage.getUser(player.userId);
      const team = player.teamId ? await storage.getTeam(player.teamId) : null;
      
      res.json({
        ...player,
        user,
        team
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch player', error: (error as Error).message });
    }
  });

  apiRouter.post('/players', async (req, res) => {
    try {
      console.log('Received player creation request:', req.body);
      
      // Handle direct player creation from frontend form
      if (req.body.firstName && req.body.lastName && req.body.email) {
        const { firstName, lastName, email, teamId, position, status } = req.body;
        
        console.log('Processing player creation for:', { firstName, lastName, email });
        
        // Check if user with this email already exists
        console.log('Checking if user already exists...');
        let user = await storage.getUserByEmail(email);
        
        if (!user) {
          // Create a new user account for the player
          console.log('Creating new user account...');
          const hashedPassword = await bcrypt.hash('temp123', 10);
          
          user = await storage.createUser({
            firstName,
            lastName,
            email,
            username: email,
            password: hashedPassword,
            role: 'player'
          });
        } else {
          console.log('Using existing user account:', user.id);
        }
        
        console.log('User resolved successfully:', user.id);
        
        // Check if this user already has a player record
        const existingPlayer = await storage.getPlayerByUserId(user.id);
        
        if (existingPlayer) {
          console.log('Player record already exists:', existingPlayer.id);
          return res.status(400).json({ 
            message: 'A player record already exists for this user',
            playerId: existingPlayer.id 
          });
        }
        
        // Create player record with minimal required fields
        console.log('Creating player record...');
        const playerData: any = {
          userId: user.id
        };
        
        // Add optional fields if provided
        if (teamId && !isNaN(parseInt(teamId))) {
          playerData.teamId = parseInt(teamId);
        }
        if (position && position.trim()) {
          playerData.position = position.toLowerCase();
        }
        if (status && status.trim()) {
          playerData.status = status.toLowerCase();
        }
        
        const player = await storage.createPlayer(playerData);
        
        console.log('Player created successfully:', player.id);
        
        // Send welcome email to the new player using SMTP
        console.log('Starting SMTP welcome email process...');
        try {
          console.log('Importing SMTP email function...');
          const { sendWelcomeEmailSMTP } = await import('./utils/smtp-email');
          
          console.log('Getting team information...');
          const team = teamId ? await storage.getTeam(parseInt(teamId)) : null;
          console.log('Team found:', team?.name || 'Unassigned');
          
          console.log('Sending SMTP welcome email with data:', {
            to: email,
            playerName: `${firstName} ${lastName}`,
            clubName: 'VVC Brasschaat',
            teamName: team?.name || 'Unassigned',
            username: email,
            temporaryPassword: 'temp123'
          });
          
          const emailResult = await sendWelcomeEmailSMTP({
            to: email,
            playerName: `${firstName} ${lastName}`,
            clubName: 'VVC Brasschaat',
            teamName: team?.name || 'Unassigned',
            username: email,
            temporaryPassword: 'temp123'
          });
          
          console.log('SMTP email function result:', emailResult);
          console.log(`SMTP welcome email sent successfully to ${email} for player ${firstName} ${lastName}`);
        } catch (emailError) {
          console.error('Failed to send SMTP welcome email - DETAILED ERROR:', emailError);
          console.error('Email error stack:', emailError instanceof Error ? emailError.stack : emailError);
          // Don't fail the entire operation if email fails
        }
        
        return res.status(201).json({ 
          message: 'Player created successfully',
          player: { ...player, user }
        });
      }
      
      // Handle existing player creation logic
      const validatePlayer = insertPlayerSchema.safeParse(req.body);
      if (!validatePlayer.success) {
        return res.status(400).json({ message: 'Invalid player data', errors: validatePlayer.error.errors });
      }

      // Check if user exists
      const user = await storage.getUser(req.body.userId);
      if (!user) {
        return res.status(400).json({ message: 'User not found' });
      }

      // Check if team exists if teamId is provided
      if (req.body.teamId) {
        const team = await storage.getTeam(req.body.teamId);
        if (!team) {
          return res.status(400).json({ message: 'Team not found' });
        }
      }

      const player = await storage.createPlayer(validatePlayer.data);
      res.status(201).json(player);
    } catch (error) {
      console.error('DETAILED ERROR in player creation:', error);
      console.error('Error stack:', (error as Error).stack);
      res.status(500).json({ message: 'Failed to create player', error: (error as Error).message });
    }
  });

  apiRouter.put('/players/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const player = await storage.getPlayer(id);
      if (!player) {
        return res.status(404).json({ message: 'Player not found' });
      }

      // Check if team exists if teamId is being updated
      if (req.body.teamId && req.body.teamId !== player.teamId) {
        const team = await storage.getTeam(req.body.teamId);
        if (!team) {
          return res.status(400).json({ message: 'Team not found' });
        }
      }

      const updatedPlayer = await storage.updatePlayer(id, req.body);
      res.json(updatedPlayer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update player', error: (error as Error).message });
    }
  });

  apiRouter.delete('/players/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const player = await storage.getPlayer(id);
      if (!player) {
        return res.status(404).json({ message: 'Player not found' });
      }

      await storage.deletePlayer(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete player', error: (error as Error).message });
    }
  });

  // Coaches routes
  apiRouter.get('/coaches', async (req, res) => {
    try {
      const coaches = await storage.getCoaches();
      
      // Enrich coach data with user info
      const enrichedCoaches = await Promise.all(coaches.map(async (coach) => {
        const user = await storage.getUser(coach.userId);
        return {
          ...coach,
          user
        };
      }));
      
      res.json(enrichedCoaches);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch coaches', error: (error as Error).message });
    }
  });

  apiRouter.get('/coaches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const coach = await storage.getCoach(id);
      if (!coach) {
        return res.status(404).json({ message: 'Coach not found' });
      }
      
      const user = await storage.getUser(coach.userId);
      
      res.json({
        ...coach,
        user
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch coach', error: (error as Error).message });
    }
  });

  apiRouter.post('/coaches', async (req, res) => {
    try {
      const validateCoach = insertCoachSchema.safeParse(req.body);
      if (!validateCoach.success) {
        return res.status(400).json({ message: 'Invalid coach data', errors: validateCoach.error.errors });
      }

      // Check if user exists
      const user = await storage.getUser(req.body.userId);
      if (!user) {
        return res.status(400).json({ message: 'User not found' });
      }

      const coach = await storage.createCoach(validateCoach.data);
      res.status(201).json(coach);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create coach', error: (error as Error).message });
    }
  });

  apiRouter.put('/coaches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const coach = await storage.getCoach(id);
      if (!coach) {
        return res.status(404).json({ message: 'Coach not found' });
      }

      const updatedCoach = await storage.updateCoach(id, req.body);
      res.json(updatedCoach);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update coach', error: (error as Error).message });
    }
  });

  apiRouter.delete('/coaches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const coach = await storage.getCoach(id);
      if (!coach) {
        return res.status(404).json({ message: 'Coach not found' });
      }

      await storage.deleteCoach(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete coach', error: (error as Error).message });
    }
  });

  // Parents routes
  apiRouter.get('/parents', async (req, res) => {
    try {
      const parents = await storage.getParents();
      
      // Enrich parent data with user info
      const enrichedParents = await Promise.all(parents.map(async (parent) => {
        const user = await storage.getUser(parent.userId);
        return {
          ...parent,
          user
        };
      }));
      
      res.json(enrichedParents);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch parents', error: (error as Error).message });
    }
  });

  apiRouter.get('/parents/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const parent = await storage.getParent(id);
      if (!parent) {
        return res.status(404).json({ message: 'Parent not found' });
      }
      
      const user = await storage.getUser(parent.userId);
      
      // Get related players
      const players = await storage.getPlayers();
      const relatedPlayers = players.filter(player => player.parentId === parent.userId);
      
      res.json({
        ...parent,
        user,
        players: relatedPlayers
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch parent', error: (error as Error).message });
    }
  });

  apiRouter.post('/parents', async (req, res) => {
    try {
      const validateParent = insertParentSchema.safeParse(req.body);
      if (!validateParent.success) {
        return res.status(400).json({ message: 'Invalid parent data', errors: validateParent.error.errors });
      }

      // Check if user exists
      const user = await storage.getUser(req.body.userId);
      if (!user) {
        return res.status(400).json({ message: 'User not found' });
      }

      const parent = await storage.createParent(validateParent.data);
      res.status(201).json(parent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create parent', error: (error as Error).message });
    }
  });

  apiRouter.put('/parents/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const parent = await storage.getParent(id);
      if (!parent) {
        return res.status(404).json({ message: 'Parent not found' });
      }

      const updatedParent = await storage.updateParent(id, req.body);
      res.json(updatedParent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update parent', error: (error as Error).message });
    }
  });

  apiRouter.delete('/parents/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const parent = await storage.getParent(id);
      if (!parent) {
        return res.status(404).json({ message: 'Parent not found' });
      }

      await storage.deleteParent(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete parent', error: (error as Error).message });
    }
  });

  // Pitches routes
  apiRouter.get('/pitches', async (req, res) => {
    try {
      const pitches = await storage.getPitches();
      res.json(pitches);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch pitches', error: (error as Error).message });
    }
  });

  apiRouter.get('/pitches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pitch = await storage.getPitch(id);
      if (!pitch) {
        return res.status(404).json({ message: 'Pitch not found' });
      }
      
      res.json(pitch);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch pitch', error: (error as Error).message });
    }
  });

  apiRouter.post('/pitches', async (req, res) => {
    try {
      const validatePitch = insertPitchSchema.safeParse(req.body);
      if (!validatePitch.success) {
        return res.status(400).json({ message: 'Invalid pitch data', errors: validatePitch.error.errors });
      }

      const pitch = await storage.createPitch(validatePitch.data);
      res.status(201).json(pitch);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create pitch', error: (error as Error).message });
    }
  });

  apiRouter.put('/pitches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pitch = await storage.getPitch(id);
      if (!pitch) {
        return res.status(404).json({ message: 'Pitch not found' });
      }

      const updatedPitch = await storage.updatePitch(id, req.body);
      res.json(updatedPitch);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update pitch', error: (error as Error).message });
    }
  });

  apiRouter.delete('/pitches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pitch = await storage.getPitch(id);
      if (!pitch) {
        return res.status(404).json({ message: 'Pitch not found' });
      }

      await storage.deletePitch(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete pitch', error: (error as Error).message });
    }
  });

  // Trainers routes
  apiRouter.get('/trainers', async (req, res) => {
    try {
      const trainers = await storage.getTrainers();
      
      // Enrich trainer data with user info
      const enrichedTrainers = await Promise.all(trainers.map(async (trainer) => {
        const user = await storage.getUser(trainer.userId);
        return {
          ...trainer,
          user
        };
      }));
      
      res.json(enrichedTrainers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch trainers', error: (error as Error).message });
    }
  });

  apiRouter.get('/trainers/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const trainer = await storage.getTrainer(id);
      if (!trainer) {
        return res.status(404).json({ message: 'Trainer not found' });
      }
      
      const user = await storage.getUser(trainer.userId);
      
      res.json({
        ...trainer,
        user
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch trainer', error: (error as Error).message });
    }
  });

  apiRouter.post('/trainers', async (req, res) => {
    try {
      const validateTrainer = insertTrainerSchema.safeParse(req.body);
      if (!validateTrainer.success) {
        return res.status(400).json({ message: 'Invalid trainer data', errors: validateTrainer.error.errors });
      }

      // Check if user exists
      const user = await storage.getUser(req.body.userId);
      if (!user) {
        return res.status(400).json({ message: 'User not found' });
      }

      const trainer = await storage.createTrainer(validateTrainer.data);
      res.status(201).json(trainer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create trainer', error: (error as Error).message });
    }
  });

  apiRouter.put('/trainers/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const trainer = await storage.getTrainer(id);
      if (!trainer) {
        return res.status(404).json({ message: 'Trainer not found' });
      }

      const updatedTrainer = await storage.updateTrainer(id, req.body);
      res.json(updatedTrainer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update trainer', error: (error as Error).message });
    }
  });

  apiRouter.delete('/trainers/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const trainer = await storage.getTrainer(id);
      if (!trainer) {
        return res.status(404).json({ message: 'Trainer not found' });
      }

      await storage.deleteTrainer(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete trainer', error: (error as Error).message });
    }
  });

  // Matches routes
  apiRouter.get('/matches', async (req, res) => {
    try {
      const teamId = req.query.teamId ? parseInt(req.query.teamId as string) : undefined;
      const status = req.query.status as string | undefined;
      const matches = await storage.getMatches(teamId, status);
      
      // Enrich matches with team data
      const enrichedMatches = await Promise.all(matches.map(async (match) => {
        const team = await storage.getTeam(match.teamId);
        const pitch = match.pitchId ? await storage.getPitch(match.pitchId) : null;
        
        return {
          ...match,
          team,
          pitch
        };
      }));
      
      res.json(enrichedMatches);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch matches', error: (error as Error).message });
    }
  });

  apiRouter.get('/matches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const match = await storage.getMatch(id);
      if (!match) {
        return res.status(404).json({ message: 'Match not found' });
      }
      
      const team = await storage.getTeam(match.teamId);
      const pitch = match.pitchId ? await storage.getPitch(match.pitchId) : null;
      
      res.json({
        ...match,
        team,
        pitch
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch match', error: (error as Error).message });
    }
  });

  apiRouter.post('/matches', async (req, res) => {
    try {
      const validateMatch = insertMatchSchema.safeParse(req.body);
      if (!validateMatch.success) {
        return res.status(400).json({ message: 'Invalid match data', errors: validateMatch.error.errors });
      }

      // Check if team exists
      const team = await storage.getTeam(req.body.teamId);
      if (!team) {
        return res.status(400).json({ message: 'Team not found' });
      }

      // Check if pitch exists if pitchId is provided
      if (req.body.pitchId) {
        const pitch = await storage.getPitch(req.body.pitchId);
        if (!pitch) {
          return res.status(400).json({ message: 'Pitch not found' });
        }
      }

      const match = await storage.createMatch(validateMatch.data);
      res.status(201).json(match);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create match', error: (error as Error).message });
    }
  });

  apiRouter.put('/matches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const match = await storage.getMatch(id);
      if (!match) {
        return res.status(404).json({ message: 'Match not found' });
      }

      // Check if team exists if teamId is being updated
      if (req.body.teamId && req.body.teamId !== match.teamId) {
        const team = await storage.getTeam(req.body.teamId);
        if (!team) {
          return res.status(400).json({ message: 'Team not found' });
        }
      }

      // Check if pitch exists if pitchId is being updated
      if (req.body.pitchId && req.body.pitchId !== match.pitchId) {
        const pitch = await storage.getPitch(req.body.pitchId);
        if (!pitch) {
          return res.status(400).json({ message: 'Pitch not found' });
        }
      }

      const updatedMatch = await storage.updateMatch(id, req.body);
      res.json(updatedMatch);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update match', error: (error as Error).message });
    }
  });

  apiRouter.delete('/matches/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const match = await storage.getMatch(id);
      if (!match) {
        return res.status(404).json({ message: 'Match not found' });
      }

      await storage.deleteMatch(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete match', error: (error as Error).message });
    }
  });

  // User-Team assignments routes
  apiRouter.get('/user-teams', async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const teamId = req.query.teamId ? parseInt(req.query.teamId as string) : undefined;
      const roleType = req.query.roleType as string | undefined;
      
      if (userId) {
        const userTeams = await storage.getUserTeams(userId);
        
        // Enrich user teams with team and user data
        const enrichedUserTeams = await Promise.all(userTeams.map(async (userTeam) => {
          const team = await storage.getTeam(userTeam.teamId);
          const user = await storage.getUser(userTeam.userId);
          return {
            ...userTeam,
            team,
            user
          };
        }));
        
        res.json(enrichedUserTeams);
      } else if (teamId) {
        const teamUsers = await storage.getTeamUsers(teamId, roleType);
        
        // Enrich team users with team and user data
        const enrichedTeamUsers = await Promise.all(teamUsers.map(async (userTeam) => {
          const team = await storage.getTeam(userTeam.teamId);
          const user = await storage.getUser(userTeam.userId);
          return {
            ...userTeam,
            team,
            user
          };
        }));
        
        res.json(enrichedTeamUsers);
      } else {
        res.status(400).json({ message: 'Either userId or teamId must be provided' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user-team assignments', error: (error as Error).message });
    }
  });

  apiRouter.get('/user-teams/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      // First, we need to get the user-team assignment
      // Since we don't have a direct method for this, we'll need to get all and filter
      let userTeamFound = false;
      let userTeam: UserTeam | undefined;
      
      for (const userId of await storage.getUsers().then(users => users.map(u => u.id))) {
        const userTeams = await storage.getUserTeams(userId);
        const found = userTeams.find(ut => ut.id === id);
        if (found) {
          userTeam = found;
          userTeamFound = true;
          break;
        }
      }
      
      if (!userTeamFound || !userTeam) {
        return res.status(404).json({ message: 'User-team assignment not found' });
      }
      
      const team = await storage.getTeam(userTeam.teamId);
      const user = await storage.getUser(userTeam.userId);
      
      res.json({
        ...userTeam,
        team,
        user
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user-team assignment', error: (error as Error).message });
    }
  });

  apiRouter.post('/user-teams', async (req, res) => {
    try {
      const validateUserTeam = insertUserTeamSchema.safeParse(req.body);
      if (!validateUserTeam.success) {
        return res.status(400).json({ message: 'Invalid user-team data', errors: validateUserTeam.error.errors });
      }

      // Check if user exists
      const user = await storage.getUser(req.body.userId);
      if (!user) {
        return res.status(400).json({ message: 'User not found' });
      }

      // Check if team exists
      const team = await storage.getTeam(req.body.teamId);
      if (!team) {
        return res.status(400).json({ message: 'Team not found' });
      }
      
      // Check if assignment already exists
      const userTeams = await storage.getUserTeams(req.body.userId);
      const existingAssignment = userTeams.find(ut => 
        ut.teamId === req.body.teamId && 
        ut.roleType === req.body.roleType
      );
      
      if (existingAssignment) {
        return res.status(409).json({ message: 'User is already assigned to this team with this role' });
      }

      const userTeam = await storage.createUserTeam(validateUserTeam.data);
      res.status(201).json(userTeam);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create user-team assignment', error: (error as Error).message });
    }
  });

  apiRouter.put('/user-teams/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Find the user-team assignment
      let userTeamFound = false;
      let userTeam: UserTeam | undefined;
      
      for (const userId of await storage.getUsers().then(users => users.map(u => u.id))) {
        const userTeams = await storage.getUserTeams(userId);
        const found = userTeams.find(ut => ut.id === id);
        if (found) {
          userTeam = found;
          userTeamFound = true;
          break;
        }
      }
      
      if (!userTeamFound || !userTeam) {
        return res.status(404).json({ message: 'User-team assignment not found' });
      }

      // If teamId is being updated, check if team exists
      if (req.body.teamId && req.body.teamId !== userTeam.teamId) {
        const team = await storage.getTeam(req.body.teamId);
        if (!team) {
          return res.status(400).json({ message: 'Team not found' });
        }
      }

      // If userId is being updated, check if user exists
      if (req.body.userId && req.body.userId !== userTeam.userId) {
        const user = await storage.getUser(req.body.userId);
        if (!user) {
          return res.status(400).json({ message: 'User not found' });
        }
      }
      
      // Check for duplicate if team, user, or role is changing
      if ((req.body.teamId && req.body.teamId !== userTeam.teamId) || 
          (req.body.userId && req.body.userId !== userTeam.userId) ||
          (req.body.roleType && req.body.roleType !== userTeam.roleType)) {
        
        const userId = req.body.userId || userTeam.userId;
        const userTeams = await storage.getUserTeams(userId);
        const teamId = req.body.teamId || userTeam.teamId;
        const roleType = req.body.roleType || userTeam.roleType;
        
        const existingAssignment = userTeams.find(ut => 
          ut.id !== id && // Not the current one
          ut.teamId === teamId && 
          ut.roleType === roleType
        );
        
        if (existingAssignment) {
          return res.status(409).json({ message: 'User is already assigned to this team with this role' });
        }
      }

      const updatedUserTeam = await storage.updateUserTeam(id, req.body);
      res.json(updatedUserTeam);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user-team assignment', error: (error as Error).message });
    }
  });

  apiRouter.delete('/user-teams/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Find the user-team assignment
      let userTeamFound = false;
      
      for (const userId of await storage.getUsers().then(users => users.map(u => u.id))) {
        const userTeams = await storage.getUserTeams(userId);
        if (userTeams.some(ut => ut.id === id)) {
          userTeamFound = true;
          break;
        }
      }
      
      if (!userTeamFound) {
        return res.status(404).json({ message: 'User-team assignment not found' });
      }

      await storage.deleteUserTeam(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete user-team assignment', error: (error as Error).message });
    }
  });
  
  // Training sessions routes
  apiRouter.get('/training-sessions', async (req, res) => {
    try {
      const teamId = req.query.teamId ? parseInt(req.query.teamId as string) : undefined;
      const sessions = await storage.getTrainingSessions(teamId);
      
      // Enrich sessions with team, coach, and pitch data
      const enrichedSessions = await Promise.all(sessions.map(async (session) => {
        const team = await storage.getTeam(session.teamId);
        const coach = session.coachId ? await storage.getUser(session.coachId) : null;
        const pitch = session.pitchId ? await storage.getPitch(session.pitchId) : null;
        
        return {
          ...session,
          team,
          coach,
          pitch
        };
      }));
      
      res.json(enrichedSessions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch training sessions', error: (error as Error).message });
    }
  });

  apiRouter.get('/training-sessions/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const session = await storage.getTrainingSession(id);
      if (!session) {
        return res.status(404).json({ message: 'Training session not found' });
      }
      
      const team = await storage.getTeam(session.teamId);
      const coach = session.coachId ? await storage.getUser(session.coachId) : null;
      const pitch = session.pitchId ? await storage.getPitch(session.pitchId) : null;
      
      res.json({
        ...session,
        team,
        coach,
        pitch
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch training session', error: (error as Error).message });
    }
  });

  apiRouter.post('/training-sessions', async (req, res) => {
    try {
      const validateSession = insertTrainingSessionSchema.safeParse(req.body);
      if (!validateSession.success) {
        return res.status(400).json({ message: 'Invalid training session data', errors: validateSession.error.errors });
      }

      // Check if team exists
      const team = await storage.getTeam(req.body.teamId);
      if (!team) {
        return res.status(400).json({ message: 'Team not found' });
      }

      // Check if coach exists if coachId is provided
      if (req.body.coachId) {
        const coach = await storage.getUser(req.body.coachId);
        if (!coach) {
          return res.status(400).json({ message: 'Coach not found' });
        }
      }

      // Check if pitch exists if pitchId is provided
      if (req.body.pitchId) {
        const pitch = await storage.getPitch(req.body.pitchId);
        if (!pitch) {
          return res.status(400).json({ message: 'Pitch not found' });
        }
      }

      const session = await storage.createTrainingSession(validateSession.data);
      res.status(201).json(session);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create training session', error: (error as Error).message });
    }
  });

  apiRouter.put('/training-sessions/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const session = await storage.getTrainingSession(id);
      if (!session) {
        return res.status(404).json({ message: 'Training session not found' });
      }

      // Check if team exists if teamId is being updated
      if (req.body.teamId && req.body.teamId !== session.teamId) {
        const team = await storage.getTeam(req.body.teamId);
        if (!team) {
          return res.status(400).json({ message: 'Team not found' });
        }
      }

      // Check if coach exists if coachId is being updated
      if (req.body.coachId && req.body.coachId !== session.coachId) {
        const coach = await storage.getUser(req.body.coachId);
        if (!coach) {
          return res.status(400).json({ message: 'Coach not found' });
        }
      }

      // Check if pitch exists if pitchId is being updated
      if (req.body.pitchId && req.body.pitchId !== session.pitchId) {
        const pitch = await storage.getPitch(req.body.pitchId);
        if (!pitch) {
          return res.status(400).json({ message: 'Pitch not found' });
        }
      }

      const updatedSession = await storage.updateTrainingSession(id, req.body);
      res.json(updatedSession);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update training session', error: (error as Error).message });
    }
  });

  apiRouter.delete('/training-sessions/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const session = await storage.getTrainingSession(id);
      if (!session) {
        return res.status(404).json({ message: 'Training session not found' });
      }

      await storage.deleteTrainingSession(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete training session', error: (error as Error).message });
    }
  });

  // Attendance routes
  apiRouter.get('/attendance', async (req, res) => {
    try {
      let attendances;
      
      if (req.query.sessionId && req.query.sessionType) {
        const sessionId = parseInt(req.query.sessionId as string);
        const sessionType = req.query.sessionType as string;
        attendances = await storage.getAttendanceBySession(sessionId, sessionType);
      } else if (req.query.playerId) {
        const playerId = parseInt(req.query.playerId as string);
        attendances = await storage.getAttendanceByPlayer(playerId);
      } else {
        return res.status(400).json({ message: 'Missing required query parameters' });
      }
      
      // Enrich attendance with player data
      const enrichedAttendances = await Promise.all(attendances.map(async (attendance) => {
        const player = await storage.getPlayer(attendance.playerId);
        return {
          ...attendance,
          player
        };
      }));
      
      res.json(enrichedAttendances);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch attendance records', error: (error as Error).message });
    }
  });

  apiRouter.get('/attendance/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const attendance = await storage.getAttendance(id);
      if (!attendance) {
        return res.status(404).json({ message: 'Attendance record not found' });
      }
      
      const player = await storage.getPlayer(attendance.playerId);
      
      res.json({
        ...attendance,
        player
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch attendance record', error: (error as Error).message });
    }
  });

  apiRouter.post('/attendance', async (req, res) => {
    try {
      const validateAttendance = insertAttendanceSchema.safeParse(req.body);
      if (!validateAttendance.success) {
        return res.status(400).json({ message: 'Invalid attendance data', errors: validateAttendance.error.errors });
      }

      // Check if player exists
      const player = await storage.getPlayer(req.body.playerId);
      if (!player) {
        return res.status(400).json({ message: 'Player not found' });
      }

      const attendance = await storage.createAttendance(validateAttendance.data);
      res.status(201).json(attendance);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create attendance record', error: (error as Error).message });
    }
  });

  apiRouter.put('/attendance/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const attendance = await storage.getAttendance(id);
      if (!attendance) {
        return res.status(404).json({ message: 'Attendance record not found' });
      }

      // Check if player exists if playerId is being updated
      if (req.body.playerId && req.body.playerId !== attendance.playerId) {
        const player = await storage.getPlayer(req.body.playerId);
        if (!player) {
          return res.status(400).json({ message: 'Player not found' });
        }
      }

      const updatedAttendance = await storage.updateAttendance(id, req.body);
      res.json(updatedAttendance);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update attendance record', error: (error as Error).message });
    }
  });

  apiRouter.delete('/attendance/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const attendance = await storage.getAttendance(id);
      if (!attendance) {
        return res.status(404).json({ message: 'Attendance record not found' });
      }

      await storage.deleteAttendance(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete attendance record', error: (error as Error).message });
    }
  });

  // Dashboard statistics
  apiRouter.get('/stats/dashboard', async (req, res) => {
    try {
      const players = await storage.getPlayers();
      const teams = await storage.getTeams();
      const matches = await storage.getMatches();
      const pitches = await storage.getPitches();
      
      // Calculate upcoming matches
      const now = new Date();
      const upcomingMatches = matches.filter(match => new Date(match.date) > now && match.status === 'scheduled');
      
      // Calculate field utilization
      const availablePitches = pitches.filter(pitch => pitch.status === 'available');
      const fieldUtilization = Math.round((1 - (availablePitches.length / pitches.length)) * 100);
      
      res.json({
        totalPlayers: players.length,
        activeTeams: teams.length,
        upcomingMatches: upcomingMatches.length,
        fieldUtilization: fieldUtilization,
        availableFields: availablePitches.length
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch dashboard statistics', error: (error as Error).message });
    }
  });

  // Fee Categories routes
  apiRouter.get('/fee-categories', async (req, res) => {
    try {
      const feeType = req.query.feeType as string | undefined;
      const teamId = req.query.teamId ? parseInt(req.query.teamId as string) : undefined;
      const seasonId = req.query.seasonId ? parseInt(req.query.seasonId as string) : undefined;
      const isActive = req.query.isActive !== undefined ? req.query.isActive === 'true' : undefined;
      
      const categories = await storage.getFeeCategories(feeType, teamId, seasonId, isActive);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch fee categories', error: (error as Error).message });
    }
  });

  apiRouter.get('/fee-categories/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getFeeCategory(id);
      if (!category) {
        return res.status(404).json({ message: 'Fee category not found' });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch fee category', error: (error as Error).message });
    }
  });

  apiRouter.post('/fee-categories', async (req, res) => {
    try {
      const validateCategory = insertFeeCategorySchema.safeParse(req.body);
      if (!validateCategory.success) {
        return res.status(400).json({ message: 'Invalid fee category data', errors: validateCategory.error.errors });
      }

      // Check if team exists if teamId is provided
      if (req.body.teamId) {
        const team = await storage.getTeam(req.body.teamId);
        if (!team) {
          return res.status(400).json({ message: 'Team not found' });
        }
      }

      const category = await storage.createFeeCategory(validateCategory.data);
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create fee category', error: (error as Error).message });
    }
  });

  apiRouter.put('/fee-categories/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getFeeCategory(id);
      if (!category) {
        return res.status(404).json({ message: 'Fee category not found' });
      }

      // Check if team exists if teamId is being updated
      if (req.body.teamId && req.body.teamId !== category.teamId) {
        const team = await storage.getTeam(req.body.teamId);
        if (!team) {
          return res.status(400).json({ message: 'Team not found' });
        }
      }

      const updatedCategory = await storage.updateFeeCategory(id, req.body);
      res.json(updatedCategory);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update fee category', error: (error as Error).message });
    }
  });

  apiRouter.delete('/fee-categories/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getFeeCategory(id);
      if (!category) {
        return res.status(404).json({ message: 'Fee category not found' });
      }

      await storage.deleteFeeCategory(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete fee category', error: (error as Error).message });
    }
  });

  // User Fees routes
  apiRouter.get('/user-fees', async (req, res) => {
    try {
      let userFees;
      
      if (req.query.userId) {
        const userId = parseInt(req.query.userId as string);
        const status = req.query.status as string | undefined;
        userFees = await storage.getUserFeesByUser(userId, status);
      } else if (req.query.feeCategoryId) {
        const feeCategoryId = parseInt(req.query.feeCategoryId as string);
        const status = req.query.status as string | undefined;
        userFees = await storage.getUserFeesByCategory(feeCategoryId, status);
      } else if (req.query.teamId) {
        const teamId = parseInt(req.query.teamId as string);
        const status = req.query.status as string | undefined;
        userFees = await storage.getUserFeesByTeam(teamId, status);
      } else {
        return res.status(400).json({ message: 'Please provide either userId, feeCategoryId, or teamId' });
      }
      
      // Enrich with user and fee category information
      const enrichedUserFees = await Promise.all(userFees.map(async (userFee) => {
        const user = await storage.getUser(userFee.userId);
        const feeCategory = await storage.getFeeCategory(userFee.feeCategoryId);
        
        return {
          ...userFee,
          user,
          feeCategory
        };
      }));
      
      res.json(enrichedUserFees);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user fees', error: (error as Error).message });
    }
  });

  apiRouter.get('/user-fees/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userFee = await storage.getUserFee(id);
      if (!userFee) {
        return res.status(404).json({ message: 'User fee not found' });
      }
      
      const user = await storage.getUser(userFee.userId);
      const feeCategory = await storage.getFeeCategory(userFee.feeCategoryId);
      
      res.json({
        ...userFee,
        user,
        feeCategory
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user fee', error: (error as Error).message });
    }
  });

  apiRouter.post('/user-fees', async (req, res) => {
    try {
      const validateUserFee = insertUserFeeSchema.safeParse(req.body);
      if (!validateUserFee.success) {
        return res.status(400).json({ message: 'Invalid user fee data', errors: validateUserFee.error.errors });
      }

      // Check if user exists
      const user = await storage.getUser(req.body.userId);
      if (!user) {
        return res.status(400).json({ message: 'User not found' });
      }

      // Check if fee category exists
      const feeCategory = await storage.getFeeCategory(req.body.feeCategoryId);
      if (!feeCategory) {
        return res.status(400).json({ message: 'Fee category not found' });
      }

      const userFee = await storage.createUserFee(validateUserFee.data);
      res.status(201).json(userFee);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create user fee', error: (error as Error).message });
    }
  });

  apiRouter.put('/user-fees/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userFee = await storage.getUserFee(id);
      if (!userFee) {
        return res.status(404).json({ message: 'User fee not found' });
      }

      // Check if fee category exists if feeCategoryId is being updated
      if (req.body.feeCategoryId && req.body.feeCategoryId !== userFee.feeCategoryId) {
        const feeCategory = await storage.getFeeCategory(req.body.feeCategoryId);
        if (!feeCategory) {
          return res.status(400).json({ message: 'Fee category not found' });
        }
      }

      const updatedUserFee = await storage.updateUserFee(id, req.body);
      res.json(updatedUserFee);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user fee', error: (error as Error).message });
    }
  });

  apiRouter.delete('/user-fees/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userFee = await storage.getUserFee(id);
      if (!userFee) {
        return res.status(404).json({ message: 'User fee not found' });
      }

      await storage.deleteUserFee(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete user fee', error: (error as Error).message });
    }
  });

  // Payments routes
  apiRouter.get('/payments', async (req, res) => {
    try {
      let payments;
      
      if (req.query.userId) {
        const userId = parseInt(req.query.userId as string);
        payments = await storage.getPaymentsByUser(userId);
      } else if (req.query.userFeeId) {
        const userFeeId = parseInt(req.query.userFeeId as string);
        payments = await storage.getPaymentsByUserFee(userFeeId);
      } else {
        return res.status(400).json({ message: 'Please provide either userId or userFeeId' });
      }
      
      // Enrich with user and fee information
      const enrichedPayments = await Promise.all(payments.map(async (payment) => {
        const user = await storage.getUser(payment.userId);
        let userFee = null;
        if (payment.userFeeId) {
          userFee = await storage.getUserFee(payment.userFeeId);
        }
        
        return {
          ...payment,
          user,
          userFee
        };
      }));
      
      res.json(enrichedPayments);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payments', error: (error as Error).message });
    }
  });

  apiRouter.get('/payments/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const payment = await storage.getPayment(id);
      if (!payment) {
        return res.status(404).json({ message: 'Payment not found' });
      }
      
      const user = await storage.getUser(payment.userId);
      let userFee = null;
      if (payment.userFeeId) {
        userFee = await storage.getUserFee(payment.userFeeId);
      }
      
      res.json({
        ...payment,
        user,
        userFee
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payment', error: (error as Error).message });
    }
  });

  apiRouter.post('/payments', async (req, res) => {
    try {
      const validatePayment = insertPaymentSchema.safeParse(req.body);
      if (!validatePayment.success) {
        return res.status(400).json({ message: 'Invalid payment data', errors: validatePayment.error.errors });
      }

      // Check if user exists
      const user = await storage.getUser(req.body.userId);
      if (!user) {
        return res.status(400).json({ message: 'User not found' });
      }

      // Check if userFee exists if userFeeId is provided
      if (req.body.userFeeId) {
        const userFee = await storage.getUserFee(req.body.userFeeId);
        if (!userFee) {
          return res.status(400).json({ message: 'User fee not found' });
        }
      }

      const payment = await storage.createPayment(validatePayment.data);
      res.status(201).json(payment);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create payment', error: (error as Error).message });
    }
  });

  apiRouter.put('/payments/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const payment = await storage.getPayment(id);
      if (!payment) {
        return res.status(404).json({ message: 'Payment not found' });
      }

      // Check if userFee exists if userFeeId is being updated
      if (req.body.userFeeId && req.body.userFeeId !== payment.userFeeId) {
        const userFee = await storage.getUserFee(req.body.userFeeId);
        if (!userFee) {
          return res.status(400).json({ message: 'User fee not found' });
        }
      }

      const updatedPayment = await storage.updatePayment(id, req.body);
      res.json(updatedPayment);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update payment', error: (error as Error).message });
    }
  });

  apiRouter.delete('/payments/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const payment = await storage.getPayment(id);
      if (!payment) {
        return res.status(404).json({ message: 'Payment not found' });
      }

      await storage.deletePayment(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete payment', error: (error as Error).message });
    }
  });

  // Payment Plan routes
  apiRouter.get('/payment-plans', async (req, res) => {
    try {
      let paymentPlans;
      
      if (req.query.userId) {
        const userId = parseInt(req.query.userId as string);
        paymentPlans = await storage.getPaymentPlansByUser(userId);
      } else if (req.query.userFeeId) {
        const userFeeId = parseInt(req.query.userFeeId as string);
        paymentPlans = await storage.getPaymentPlansByUserFee(userFeeId);
      } else {
        return res.status(400).json({ message: 'Please provide either userId or userFeeId' });
      }
      
      // Enrich with user and fee information
      const enrichedPaymentPlans = await Promise.all(paymentPlans.map(async (plan) => {
        const user = await storage.getUser(plan.userId);
        let userFee = null;
        if (plan.userFeeId) {
          userFee = await storage.getUserFee(plan.userFeeId);
        }
        
        // Get all installments for this plan
        const installments = await storage.getPaymentPlanInstallmentsByPlan(plan.id);
        
        return {
          ...plan,
          user,
          userFee,
          installments
        };
      }));
      
      res.json(enrichedPaymentPlans);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payment plans', error: (error as Error).message });
    }
  });

  apiRouter.get('/payment-plans/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const paymentPlan = await storage.getPaymentPlan(id);
      if (!paymentPlan) {
        return res.status(404).json({ message: 'Payment plan not found' });
      }
      
      const user = await storage.getUser(paymentPlan.userId);
      let userFee = null;
      if (paymentPlan.userFeeId) {
        userFee = await storage.getUserFee(paymentPlan.userFeeId);
      }
      
      // Get all installments for this plan
      const installments = await storage.getPaymentPlanInstallmentsByPlan(paymentPlan.id);
      
      res.json({
        ...paymentPlan,
        user,
        userFee,
        installments
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payment plan', error: (error as Error).message });
    }
  });

  apiRouter.post('/payment-plans', async (req, res) => {
    try {
      const validatePaymentPlan = insertPaymentPlanSchema.safeParse(req.body);
      if (!validatePaymentPlan.success) {
        return res.status(400).json({ message: 'Invalid payment plan data', errors: validatePaymentPlan.error.errors });
      }

      // Check if user exists
      const user = await storage.getUser(req.body.userId);
      if (!user) {
        return res.status(400).json({ message: 'User not found' });
      }

      // Check if userFee exists if userFeeId is provided
      if (req.body.userFeeId) {
        const userFee = await storage.getUserFee(req.body.userFeeId);
        if (!userFee) {
          return res.status(400).json({ message: 'User fee not found' });
        }
      }

      const paymentPlan = await storage.createPaymentPlan(validatePaymentPlan.data);
      res.status(201).json(paymentPlan);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create payment plan', error: (error as Error).message });
    }
  });

  apiRouter.put('/payment-plans/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const paymentPlan = await storage.getPaymentPlan(id);
      if (!paymentPlan) {
        return res.status(404).json({ message: 'Payment plan not found' });
      }

      // Check if userFee exists if userFeeId is being updated
      if (req.body.userFeeId && req.body.userFeeId !== paymentPlan.userFeeId) {
        const userFee = await storage.getUserFee(req.body.userFeeId);
        if (!userFee) {
          return res.status(400).json({ message: 'User fee not found' });
        }
      }

      const updatedPaymentPlan = await storage.updatePaymentPlan(id, req.body);
      res.json(updatedPaymentPlan);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update payment plan', error: (error as Error).message });
    }
  });

  apiRouter.delete('/payment-plans/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const paymentPlan = await storage.getPaymentPlan(id);
      if (!paymentPlan) {
        return res.status(404).json({ message: 'Payment plan not found' });
      }

      await storage.deletePaymentPlan(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete payment plan', error: (error as Error).message });
    }
  });

  // Payment Plan Installments routes
  apiRouter.get('/payment-plan-installments', async (req, res) => {
    try {
      let installments;
      
      if (req.query.paymentPlanId) {
        const paymentPlanId = parseInt(req.query.paymentPlanId as string);
        installments = await storage.getPaymentPlanInstallmentsByPlan(paymentPlanId);
      } else if (req.query.status) {
        const status = req.query.status as string;
        installments = await storage.getPaymentPlanInstallmentsByStatus(status);
      } else {
        return res.status(400).json({ message: 'Please provide either paymentPlanId or status' });
      }
      
      // Enrich with payment plan information
      const enrichedInstallments = await Promise.all(installments.map(async (installment) => {
        const paymentPlan = await storage.getPaymentPlan(installment.paymentPlanId);
        let payment = null;
        if (installment.paymentId) {
          payment = await storage.getPayment(installment.paymentId);
        }
        
        return {
          ...installment,
          paymentPlan,
          payment
        };
      }));
      
      res.json(enrichedInstallments);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payment plan installments', error: (error as Error).message });
    }
  });

  apiRouter.get('/payment-plan-installments/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const installment = await storage.getPaymentPlanInstallment(id);
      if (!installment) {
        return res.status(404).json({ message: 'Payment plan installment not found' });
      }
      
      const paymentPlan = await storage.getPaymentPlan(installment.paymentPlanId);
      let payment = null;
      if (installment.paymentId) {
        payment = await storage.getPayment(installment.paymentId);
      }
      
      res.json({
        ...installment,
        paymentPlan,
        payment
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payment plan installment', error: (error as Error).message });
    }
  });

  apiRouter.post('/payment-plan-installments', async (req, res) => {
    try {
      const validateInstallment = insertPaymentPlanInstallmentSchema.safeParse(req.body);
      if (!validateInstallment.success) {
        return res.status(400).json({ message: 'Invalid payment plan installment data', errors: validateInstallment.error.errors });
      }

      // Check if payment plan exists
      const paymentPlan = await storage.getPaymentPlan(req.body.paymentPlanId);
      if (!paymentPlan) {
        return res.status(400).json({ message: 'Payment plan not found' });
      }

      // Check if payment exists if paymentId is provided
      if (req.body.paymentId) {
        const payment = await storage.getPayment(req.body.paymentId);
        if (!payment) {
          return res.status(400).json({ message: 'Payment not found' });
        }
      }

      const installment = await storage.createPaymentPlanInstallment(validateInstallment.data);
      res.status(201).json(installment);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create payment plan installment', error: (error as Error).message });
    }
  });

  apiRouter.put('/payment-plan-installments/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const installment = await storage.getPaymentPlanInstallment(id);
      if (!installment) {
        return res.status(404).json({ message: 'Payment plan installment not found' });
      }

      // Check if payment exists if paymentId is being updated
      if (req.body.paymentId && req.body.paymentId !== installment.paymentId) {
        const payment = await storage.getPayment(req.body.paymentId);
        if (!payment) {
          return res.status(400).json({ message: 'Payment not found' });
        }
      }

      const updatedInstallment = await storage.updatePaymentPlanInstallment(id, req.body);
      res.json(updatedInstallment);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update payment plan installment', error: (error as Error).message });
    }
  });

  apiRouter.delete('/payment-plan-installments/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const installment = await storage.getPaymentPlanInstallment(id);
      if (!installment) {
        return res.status(404).json({ message: 'Payment plan installment not found' });
      }

      await storage.deletePaymentPlanInstallment(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete payment plan installment', error: (error as Error).message });
    }
  });
  
  // Stripe payment integration
  apiRouter.post('/create-payment-intent', async (req, res) => {
    try {
      // Make sure STRIPE_SECRET_KEY is set
      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ message: 'STRIPE_SECRET_KEY is not configured' });
      }

      // Import Stripe
      const Stripe = require('stripe');
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

      // Get the payment details from the request
      const { amount, currency = 'usd', userFeeId, description, metadata } = req.body;

      if (!amount) {
        return res.status(400).json({ message: 'Amount is required' });
      }

      // Create payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency,
        description,
        metadata: {
          userFeeId,
          ...metadata
        }
      });

      res.json({
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to create payment intent', error: (error as Error).message });
    }
  });

  apiRouter.post('/payment-webhook', async (req, res) => {
    try {
      // Make sure STRIPE_SECRET_KEY is set
      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ message: 'STRIPE_SECRET_KEY is not configured' });
      }

      // Import Stripe
      const Stripe = require('stripe');
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

      // Get the webhook signature from headers
      const signature = req.headers['stripe-signature'];

      if (!signature) {
        return res.status(400).json({ message: 'Stripe signature is missing' });
      }

      // Verify webhook
      let event;
      try {
        event = stripe.webhooks.constructEvent(
          req.body,
          signature,
          process.env.STRIPE_WEBHOOK_SECRET
        );
      } catch (err) {
        return res.status(400).json({ message: `Webhook signature verification failed: ${err.message}` });
      }

      // Handle the event
      if (event.type === 'payment_intent.succeeded') {
        const paymentIntent = event.data.object;
        
        // Extract metadata
        const userFeeId = paymentIntent.metadata?.userFeeId ? parseInt(paymentIntent.metadata.userFeeId) : null;
        
        if (userFeeId) {
          const userFee = await storage.getUserFee(userFeeId);
          if (userFee) {
            // Create a payment record
            await storage.createPayment({
              userId: userFee.userId,
              userFeeId,
              amount: paymentIntent.amount / 100, // Convert from cents
              paymentDate: new Date(),
              method: 'credit_card',
              status: 'paid',
              transactionId: paymentIntent.id,
              notes: `Payment processed via Stripe for ${paymentIntent.description || 'fee payment'}`,
              receiptUrl: null
            });
            
            // Update user fee status if applicable
            if (userFee.status !== 'paid') {
              await storage.updateUserFee(userFeeId, { status: 'paid' });
            }
          }
        }
      }

      res.json({ received: true });
    } catch (error) {
      res.status(500).json({ message: 'Failed to process webhook', error: (error as Error).message });
    }
  });

  // Training Plans API Routes
  apiRouter.get('/training-plans', isAuthenticated, async (req, res) => {
    try {
      const plans = await db.select().from(trainingPlans)
        .leftJoin(teams, eq(trainingPlans.teamId, teams.id))
        .orderBy(desc(trainingPlans.createdAt));
      
      const formattedPlans = plans.map(({ training_plans, teams }) => ({
        ...training_plans,
        teamName: teams?.name || null
      }));
      
      res.json(formattedPlans);
    } catch (error) {
      console.error('Error fetching training plans:', error);
      res.status(500).json({ message: 'Failed to fetch training plans' });
    }
  });

  apiRouter.post('/training-plans', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertTrainingPlanSchema.parse({
        ...req.body,
        createdBy: req.user!.id
      });
      
      const [plan] = await db.insert(trainingPlans)
        .values(validatedData)
        .returning();
      
      res.status(201).json(plan);
    } catch (error) {
      console.error('Error creating training plan:', error);
      res.status(500).json({ message: 'Failed to create training plan' });
    }
  });

  apiRouter.put('/training-plans/:id', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const validatedData = insertTrainingPlanSchema.parse({
        ...req.body,
        createdBy: req.user!.id
      });
      
      const [updatedPlan] = await db.update(trainingPlans)
        .set({ ...validatedData, updatedAt: new Date() })
        .where(eq(trainingPlans.id, planId))
        .returning();
      
      if (!updatedPlan) {
        return res.status(404).json({ message: 'Training plan not found' });
      }
      
      res.json(updatedPlan);
    } catch (error) {
      console.error('Error updating training plan:', error);
      res.status(500).json({ message: 'Failed to update training plan' });
    }
  });

  apiRouter.delete('/training-plans/:id', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      
      // First delete associated training sessions
      await db.delete(trainingSessions).where(eq(trainingSessions.planId, planId));
      
      // Then delete the training plan
      const [deletedPlan] = await db.delete(trainingPlans)
        .where(eq(trainingPlans.id, planId))
        .returning();
      
      if (!deletedPlan) {
        return res.status(404).json({ message: 'Training plan not found' });
      }
      
      res.json({ message: 'Training plan deleted successfully' });
    } catch (error) {
      console.error('Error deleting training plan:', error);
      res.status(500).json({ message: 'Failed to delete training plan' });
    }
  });

  apiRouter.get('/training-plans/:id/sessions', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const sessions = await db.select().from(trainingSessions)
        .where(eq(trainingSessions.planId, planId))
        .orderBy(trainingSessions.date);
      
      res.json(sessions);
    } catch (error) {
      console.error('Error fetching training sessions:', error);
      res.status(500).json({ message: 'Failed to fetch training sessions' });
    }
  });

  // Admin Database Export Routes
  apiRouter.get('/admin/export/excel', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      // Get all data from database
      const [users, teams, players, coaches, parents, pitches, matches, trainingSessions, payments, feeCategories, userFees] = await Promise.all([
        storage.getUsers(),
        storage.getTeams(),
        storage.getPlayers(),
        storage.getCoaches(),
        storage.getParents(),
        storage.getPitches(),
        storage.getMatches(),
        storage.getTrainingSessions(),
        storage.getPayments(),
        storage.getFeeCategories(),
        storage.getUserFees()
      ]);

      // Create workbook
      const workbook = XLSX.utils.book_new();

      // Create worksheets for each data type
      const worksheets = {
        'Users': XLSX.utils.json_to_sheet(users),
        'Teams': XLSX.utils.json_to_sheet(teams),
        'Players': XLSX.utils.json_to_sheet(players),
        'Coaches': XLSX.utils.json_to_sheet(coaches),
        'Parents': XLSX.utils.json_to_sheet(parents),
        'Pitches': XLSX.utils.json_to_sheet(pitches),
        'Matches': XLSX.utils.json_to_sheet(matches),
        'Training Sessions': XLSX.utils.json_to_sheet(trainingSessions),
        'Payments': XLSX.utils.json_to_sheet(payments),
        'Fee Categories': XLSX.utils.json_to_sheet(feeCategories),
        'User Fees': XLSX.utils.json_to_sheet(userFees)
      };

      // Add worksheets to workbook
      Object.entries(worksheets).forEach(([name, sheet]) => {
        XLSX.utils.book_append_sheet(workbook, sheet, name);
      });

      // Generate Excel file buffer
      const excelBuffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

      // Set headers for download
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="club-database-export-${timestamp}.xlsx"`);
      
      res.send(excelBuffer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export database to Excel', error: (error as Error).message });
    }
  });

  apiRouter.get('/admin/export/sql', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      // Get all data from database
      const [users, teams, players, coaches, parents, pitches, matches, trainingSessions, payments, feeCategories, userFees] = await Promise.all([
        storage.getUsers(),
        storage.getTeams(),
        storage.getPlayers(),
        storage.getCoaches(),
        storage.getParents(),
        storage.getPitches(),
        storage.getMatches(),
        storage.getTrainingSessions(),
        storage.getPayments(),
        storage.getFeeCategories(),
        storage.getUserFees()
      ]);

      // Generate SQL INSERT statements
      let sqlContent = `-- Database Export - ${new Date().toISOString()}\n`;
      sqlContent += `-- Soccer Club Management System\n\n`;

      // Helper function to generate SQL INSERT statements
      const generateInserts = (tableName: string, data: any[]) => {
        if (data.length === 0) return '';
        
        let sql = `-- ${tableName} data\n`;
        
        data.forEach(row => {
          const columns = Object.keys(row).join(', ');
          const values = Object.values(row).map(val => {
            if (val === null) return 'NULL';
            if (typeof val === 'string') return `'${val.replace(/'/g, "''")}'`;
            if (val instanceof Date) return `'${val.toISOString()}'`;
            return val;
          }).join(', ');
          
          sql += `INSERT INTO ${tableName} (${columns}) VALUES (${values});\n`;
        });
        
        sql += '\n';
        return sql;
      };

      // Generate INSERT statements for each table
      sqlContent += generateInserts('users', users);
      sqlContent += generateInserts('teams', teams);
      sqlContent += generateInserts('players', players);
      sqlContent += generateInserts('coaches', coaches);
      sqlContent += generateInserts('parents', parents);
      sqlContent += generateInserts('pitches', pitches);
      sqlContent += generateInserts('matches', matches);
      sqlContent += generateInserts('training_sessions', trainingSessions);
      sqlContent += generateInserts('payments', payments);
      sqlContent += generateInserts('fee_categories', feeCategories);
      sqlContent += generateInserts('user_fees', userFees);

      // Set headers for download
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      res.setHeader('Content-Type', 'application/sql');
      res.setHeader('Content-Disposition', `attachment; filename="club-database-export-${timestamp}.sql"`);
      
      res.send(sqlContent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export database to SQL', error: (error as Error).message });
    }
  });

  apiRouter.get('/admin/export/json', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      // Get all data from database
      const [users, teams, players, coaches, parents, pitches, matches, trainingSessions, payments, feeCategories, userFees] = await Promise.all([
        storage.getUsers(),
        storage.getTeams(),
        storage.getPlayers(),
        storage.getCoaches(),
        storage.getParents(),
        storage.getPitches(),
        storage.getMatches(),
        storage.getTrainingSessions(),
        storage.getPayments(),
        storage.getFeeCategories(),
        storage.getUserFees()
      ]);

      // Create JSON export object
      const exportData = {
        exportInfo: {
          timestamp: new Date().toISOString(),
          system: 'Soccer Club Management System',
          version: '1.0'
        },
        data: {
          users,
          teams,
          players,
          coaches,
          parents,
          pitches,
          matches,
          trainingSessions,
          payments,
          feeCategories,
          userFees
        }
      };

      // Set headers for download
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="club-database-export-${timestamp}.json"`);
      
      res.json(exportData);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export database to JSON', error: (error as Error).message });
    }
  });

  apiRouter.get('/admin/export/xml', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      // Get all data from database
      const [users, teams, players, coaches, parents, pitches, matches, trainingSessions, payments, feeCategories, userFees] = await Promise.all([
        storage.getUsers(),
        storage.getTeams(),
        storage.getPlayers(),
        storage.getCoaches(),
        storage.getParents(),
        storage.getPitches(),
        storage.getMatches(),
        storage.getTrainingSessions(),
        storage.getPayments(),
        storage.getFeeCategories(),
        storage.getUserFees()
      ]);

      // Helper function to convert object to XML
      const objectToXml = (obj: any, rootName: string): string => {
        let xml = `<${rootName}>`;
        
        if (Array.isArray(obj)) {
          obj.forEach((item, index) => {
            xml += objectToXml(item, `item_${index}`);
          });
        } else if (typeof obj === 'object' && obj !== null) {
          Object.entries(obj).forEach(([key, value]) => {
            if (Array.isArray(value)) {
              xml += `<${key}>`;
              value.forEach((item, index) => {
                xml += objectToXml(item, `record_${index}`);
              });
              xml += `</${key}>`;
            } else if (typeof value === 'object' && value !== null) {
              xml += objectToXml(value, key);
            } else {
              const escapedValue = String(value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&apos;');
              xml += `<${key}>${escapedValue}</${key}>`;
            }
          });
        } else {
          const escapedValue = String(obj)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&apos;');
          xml += escapedValue;
        }
        
        xml += `</${rootName}>`;
        return xml;
      };

      // Create XML content
      let xmlContent = '<?xml version="1.0" encoding="UTF-8"?>\n';
      xmlContent += '<database_export>\n';
      xmlContent += `  <export_info>\n`;
      xmlContent += `    <timestamp>${new Date().toISOString()}</timestamp>\n`;
      xmlContent += `    <system>Soccer Club Management System</system>\n`;
      xmlContent += `    <version>1.0</version>\n`;
      xmlContent += `  </export_info>\n`;
      xmlContent += `  <data>\n`;
      
      // Add each data type
      const dataTypes = {
        users, teams, players, coaches, parents, pitches, 
        matches, trainingSessions, payments, feeCategories, userFees
      };

      Object.entries(dataTypes).forEach(([tableName, data]) => {
        xmlContent += `    <${tableName}>\n`;
        data.forEach((record: any, index: number) => {
          xmlContent += `      <record id="${index}">\n`;
          Object.entries(record).forEach(([key, value]) => {
            const escapedValue = String(value)
              .replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&apos;');
            xmlContent += `        <${key}>${escapedValue}</${key}>\n`;
          });
          xmlContent += `      </record>\n`;
        });
        xmlContent += `    </${tableName}>\n`;
      });
      
      xmlContent += `  </data>\n`;
      xmlContent += '</database_export>';

      // Set headers for download
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      res.setHeader('Content-Type', 'application/xml');
      res.setHeader('Content-Disposition', `attachment; filename="club-database-export-${timestamp}.xml"`);
      
      res.send(xmlContent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export database to XML', error: (error as Error).message });
    }
  });

  // IADATABANK Export Routes
  apiRouter.get('/admin/export/iadatabank/excel', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      // Complete IADATABANK data with all authentic elements and 6-level progressions
      const iadatabankData = [
        // BASICS B+ Elements (15 total)
        ...["LEIDEN_VAN_DE_BAL", "DRIBBELEN_MET_DE_BAL", "SCHIETEN", "AFWERKEN", "KOPPEN", 
            "PASSING", "AANNAME", "ONTVANGEN_VAN_DE_BAL", "BREED_SPEL", "DIEPTE_SPEL",
            "EERSTE_AANRAKING", "BALGEVOEL", "TECHNIEK_ONDER_DRUK", "BALBEHANDELING", "TRAPPEN_MET_BEIDE_VOETEN"
           ].map((element, index) => [
            {
              topic: 'BASICS',
              subtopic: 'B+',
              element,
              level: '★☆☆☆☆☆',
              level_name: 'Eenvoudig',
              description: 'Basis technische vaardigheden zonder druk',
              progression_step: 1,
              skill_rating: '1/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B+',
              element,
              level: '★★☆☆☆☆',
              level_name: 'Gericht',
              description: 'Techniek in een specifieke richting',
              progression_step: 2,
              skill_rating: '2/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B+',
              element,
              level: '★★★☆☆☆',
              level_name: 'Gericht snel',
              description: 'Snelle en gerichte technische uitvoering',
              progression_step: 3,
              skill_rating: '3/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B+',
              element,
              level: '★★★★☆☆',
              level_name: 'Blind gericht snel',
              description: 'Techniek zonder direct kijken naar bal',
              progression_step: 4,
              skill_rating: '4/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B+',
              element,
              level: '★★★★★☆',
              level_name: 'Onder druk blind gericht snel',
              description: 'Techniek onder tegenstander druk',
              progression_step: 5,
              skill_rating: '5/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B+',
              element,
              level: '★★★★★★',
              level_name: 'Onder druk blind gericht snel + actie',
              description: 'Perfecte techniek met directe vervolgactie',
              progression_step: 6,
              skill_rating: '6/6'
            }
           ]).flat(),

        // BASICS B- Elements (17 total)
        ...["DRUK_ZETTEN_TACKLE_REMMEN", "DUEL", "INTERCEPTIE_BALCONTROLE_KORTE_PASSING", "INTERCEPTIE_BALCONTROLE_MIDDELLANGE_PASSING",
            "INTERCEPTIE_BALCONTROLE_LANGE_PASSING", "INTERCEPTIE_BALCONTROLE_KOPBAL", "INTERCEPTIE_BALCONTROLE_KAATSBAL",
            "INTERCEPTIE_NA_BALCONTROLE_KORTE_PASS", "INTERCEPTIE_NA_BALCONTROLE_MIDDELLANGE_PASS", "INTERCEPTIE_NA_BALCONTROLE_LANGE_PASS",
            "AFWEREN_SCHIETEN_BELETTEN", "AFWEREN_SCOREN_VOET_BELETTEN", "AFWEREN_SCOREN_HOOFD_BELETTEN", "AFWEREN_SCOREN_INDIVIDUELE_ACTIE_BELETTEN",
            "SPEELHOEKEN_AFSLUITEN", "STRIKTE_DEKKING", "RUGDEKKING"
           ].map((element, index) => [
            {
              topic: 'BASICS',
              subtopic: 'B-',
              element,
              level: '★☆☆☆☆☆',
              level_name: 'Eenvoudig verdedigen',
              description: 'Basis verdedigende technische vaardigheden',
              progression_step: 1,
              skill_rating: '1/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B-',
              element,
              level: '★★☆☆☆☆',
              level_name: 'Gericht verdedigen',
              description: 'Verdedigende techniek in specifieke situaties',
              progression_step: 2,
              skill_rating: '2/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B-',
              element,
              level: '★★★☆☆☆',
              level_name: 'Snel verdedigen',
              description: 'Snelle verdedigende technische uitvoering',
              progression_step: 3,
              skill_rating: '3/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B-',
              element,
              level: '★★★★☆☆',
              level_name: 'Anticiperend verdedigen',
              description: 'Verdedigen met anticipatie en vooruitdenken',
              progression_step: 4,
              skill_rating: '4/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B-',
              element,
              level: '★★★★★☆',
              level_name: 'Druk verdedigen',
              description: 'Verdedigende techniek onder hoge druk',
              progression_step: 5,
              skill_rating: '5/6'
            },
            {
              topic: 'BASICS',
              subtopic: 'B-',
              element,
              level: '★★★★★★',
              level_name: 'Perfecte verdediging + transitie',
              description: 'Perfecte verdedigende techniek met directe omschakeling',
              progression_step: 6,
              skill_rating: '6/6'
            }
           ]).flat(),

        // TEAMTACTISCH B+ Elements (21 total)
        ...["CREEER_RUIMTE", "CREEER_HOOGTE_DIEPTE", "CREEER_MEERDERHEIDSSITUATIES", "SPEEL_SIMPEL_KORTE_PASSING",
            "BOUW_OP_VERDEDIGEND_DERDE", "BOUW_OP_MIDDENVELD", "BOUW_OP_AANVALLEND_DERDE", "SWITCHEN_VAN_SPEELHELFT",
            "POSITIESPEL", "DRIEHOEKEN_VORMEN", "LIJNSPEL", "TEMPO_VARIATIE", "COMBINATIESPEL", "OPBOUW_VANAF_KEEPER",
            "DRUK_ZETTEN", "TACKLE", "REMMEN", "DEKKEN", "POSITIE_TUSSEN_LINIES", "COMPACTE_DEFENSIE", "VERDEDIGENDE_ORGANISATIE"
           ].map((element, index) => [
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B+ OPBOUWEN / B- VERDEDIGEN',
              element,
              level: '★☆☆☆☆☆',
              level_name: 'Basis tactisch begrip',
              description: 'Eenvoudige tactische concepten zonder druk',
              progression_step: 1,
              skill_rating: '1/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B+ OPBOUWEN / B- VERDEDIGEN',
              element,
              level: '★★☆☆☆☆',
              level_name: 'Gericht tactisch spel',
              description: 'Bewuste tactische keuzes maken',
              progression_step: 2,
              skill_rating: '2/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B+ OPBOUWEN / B- VERDEDIGEN',
              element,
              level: '★★★☆☆☆',
              level_name: 'Snel tactisch handelen',
              description: 'Snelle tactische beslissingen nemen',
              progression_step: 3,
              skill_rating: '3/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B+ OPBOUWEN / B- VERDEDIGEN',
              element,
              level: '★★★★☆☆',
              level_name: 'Snel en gericht tactisch',
              description: 'Snelle en accurate tactische uitvoering',
              progression_step: 4,
              skill_rating: '4/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B+ OPBOUWEN / B- VERDEDIGEN',
              element,
              level: '★★★★★☆',
              level_name: 'Meerderheidssituaties',
              description: 'Optimaal benutten van numeriek voordeel',
              progression_step: 5,
              skill_rating: '5/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B+ OPBOUWEN / B- VERDEDIGEN',
              element,
              level: '★★★★★★',
              level_name: 'Ondertal + hoge druk',
              description: 'Perfecte tactische oplossingen in moeilijke situaties',
              progression_step: 6,
              skill_rating: '6/6'
            }
           ]).flat(),

        // TEAMTACTISCH B- Elements (21 total)
        ...["DRUK_ZETTEN", "TACKLE", "REMMEN", "DEKKEN", "POSITIE_TUSSEN_LINIES", "COMPACTE_DEFENSIE", "VERDEDIGENDE_ORGANISATIE",
            "PRESSING", "GEGENPRESSING", "DEFENSIVE_BLOCK", "OFFSIDE_TRAP", "SLIDING_TACKLE", "STANDING_TACKLE", 
            "INTERCEPTEREN", "VERDEDIGENDE_COMMUNICATIE", "ZONE_VERDEDIGEN", "MAN_MARKING", "DUBBELE_DEKKING",
            "VERDEDIGENDE_HEADERS", "CLEARING", "DEFENSIVE_POSITIONING"
           ].map((element, index) => [
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B-',
              element,
              level: '★☆☆☆☆☆',
              level_name: 'Basis verdedigende tactiek',
              description: 'Eenvoudige verdedigende tactische concepten',
              progression_step: 1,
              skill_rating: '1/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B-',
              element,
              level: '★★☆☆☆☆',
              level_name: 'Georganiseerd verdedigen',
              description: 'Gestructureerde verdedigende aanpak',
              progression_step: 2,
              skill_rating: '2/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B-',
              element,
              level: '★★★☆☆☆',
              level_name: 'Collectief verdedigen',
              description: 'Teamgerichte verdedigende acties',
              progression_step: 3,
              skill_rating: '3/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B-',
              element,
              level: '★★★★☆☆',
              level_name: 'Anticiperende verdediging',
              description: 'Proactieve verdedigende positionering',
              progression_step: 4,
              skill_rating: '4/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B-',
              element,
              level: '★★★★★☆',
              level_name: 'Dominante verdediging',
              description: 'Controlerende verdedigende prestatie',
              progression_step: 5,
              skill_rating: '5/6'
            },
            {
              topic: 'TEAMTACTISCH',
              subtopic: 'B-',
              element,
              level: '★★★★★★',
              level_name: 'Perfecte verdediging + counter',
              description: 'Perfecte verdediging met directe tegenaanval',
              progression_step: 6,
              skill_rating: '6/6'
            }
           ]).flat(),

        // OMSCHAKELING B+/B- Elements (8 total)
        ...["TEGENAANVAL", "OP_BALBEZIT_SPELEN", "SNELLE_OMSCHAKELING_NAAR_AANVAL", "POSITIE_INNEMEN_AANVAL"
           ].map((element, index) => [
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B-/B+',
              element,
              level: '★☆☆☆☆☆',
              level_name: 'Basis omschakeling',
              description: 'Eenvoudige transitie van verdediging naar aanval',
              progression_step: 1,
              skill_rating: '1/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B-/B+',
              element,
              level: '★★☆☆☆☆',
              level_name: 'Bewuste omschakeling',
              description: 'Gerichte transitie met duidelijk doel',
              progression_step: 2,
              skill_rating: '2/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B-/B+',
              element,
              level: '★★★☆☆☆',
              level_name: 'Snelle omschakeling',
              description: 'Snelle transitie met tempo verhoging',
              progression_step: 3,
              skill_rating: '3/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B-/B+',
              element,
              level: '★★★★☆☆',
              level_name: 'Directe omschakeling',
              description: 'Directe transitie met onmiddellijke actie',
              progression_step: 4,
              skill_rating: '4/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B-/B+',
              element,
              level: '★★★★★☆',
              level_name: 'Dominante omschakeling',
              description: 'Controlerende transitie met overwicht',
              progression_step: 5,
              skill_rating: '5/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B-/B+',
              element,
              level: '★★★★★★',
              level_name: 'Perfecte omschakeling',
              description: 'Perfecte transitie met maximaal effect',
              progression_step: 6,
              skill_rating: '6/6'
            }
           ]).flat(),

        // OMSCHAKELING B+/B- Elements (4 total)
        ...["TEGEN_DRUK_ZETTEN", "HERVORMEN_OPSTELLING", "DEFENSIEVE_TRANSITIE", "BALVEROVERING_ORGANISATIE"
           ].map((element, index) => [
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B+/B-',
              element,
              level: '★☆☆☆☆☆',
              level_name: 'Basis defensieve transitie',
              description: 'Eenvoudige omschakeling van aanval naar verdediging',
              progression_step: 1,
              skill_rating: '1/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B+/B-',
              element,
              level: '★★☆☆☆☆',
              level_name: 'Georganiseerde transitie',
              description: 'Gestructureerde omschakeling naar verdediging',
              progression_step: 2,
              skill_rating: '2/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B+/B-',
              element,
              level: '★★★☆☆☆',
              level_name: 'Snelle defensieve transitie',
              description: 'Snelle omschakeling met directe druk',
              progression_step: 3,
              skill_rating: '3/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B+/B-',
              element,
              level: '★★★★☆☆',
              level_name: 'Anticiperende transitie',
              description: 'Proactieve omschakeling met anticipatie',
              progression_step: 4,
              skill_rating: '4/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B+/B-',
              element,
              level: '★★★★★☆',
              level_name: 'Dominante pressing',
              description: 'Controlerende omschakeling met hoge druk',
              progression_step: 5,
              skill_rating: '5/6'
            },
            {
              topic: 'OMSCHAKELING',
              subtopic: 'B+/B-',
              element,
              level: '★★★★★★',
              level_name: 'Perfecte pressing + herwinning',
              description: 'Perfecte omschakeling met directe balverovering',
              progression_step: 6,
              skill_rating: '6/6'
            }
           ]).flat(),

        // MENTAAL Elements (29 total)
        ...["CONCENTRATIE", "RUSTIG_VS_ONRUSTIG", "SPONTANITEIT", "ZELFVERTROUWEN", "DOORZETTINGSVERMOGEN",
            "MOTIVATIE", "STRESSBESTENDIGHEID", "COMMUNICATIE", "LEIDERSCHAP", "TEAMWORK", "DISCIPLINE",
            "MENTALE_VOORBEREIDING", "OMGAAN_MET_DRUK", "POSITIEVE_INSTELLING", "ZELFCONTROLE", "VEERKRACHT",
            "AMBITIE", "GEDULD", "ASSERTIVITEIT", "EMPATHIE", "ADAPTABILITEIT", "ZELFBEWUSTZIJN", "FAIRPLAY",
            "INTEGRITEIT", "HULPVAARDIGHEID", "LOYALITEIT", "BETROKKENHEID", "FOCUS", "RESPECTVOL"
           ].map((element, index) => [
            {
              topic: 'MENTAAL',
              subtopic: 'ALGEMEEN MENTAAL',
              element,
              level: '★☆☆☆☆☆',
              level_name: 'Basis mentale vaardigheid',
              description: 'Eerste kennismaking met mentaal aspect',
              progression_step: 1,
              skill_rating: '1/6'
            },
            {
              topic: 'MENTAAL',
              subtopic: 'ALGEMEEN MENTAAL',
              element,
              level: '★★☆☆☆☆',
              level_name: 'Bewuste mentale ontwikkeling',
              description: 'Bewust werken aan mentale groei',
              progression_step: 2,
              skill_rating: '2/6'
            },
            {
              topic: 'MENTAAL',
              subtopic: 'ALGEMEEN MENTAAL',
              element,
              level: '★★★☆☆☆',
              level_name: 'Toegepaste mentale kracht',
              description: 'Mentale vaardigheden toepassen in situaties',
              progression_step: 3,
              skill_rating: '3/6'
            },
            {
              topic: 'MENTAAL',
              subtopic: 'ALGEMEEN MENTAAL',
              element,
              level: '★★★★☆☆',
              level_name: 'Mentale kracht onder druk',
              description: 'Mentale stabiliteit in moeilijke momenten',
              progression_step: 4,
              skill_rating: '4/6'
            },
            {
              topic: 'MENTAAL',
              subtopic: 'ALGEMEEN MENTAAL',
              element,
              level: '★★★★★☆',
              level_name: 'Adaptieve mentale kracht',
              description: 'Flexibele mentale aanpassing aan situaties',
              progression_step: 5,
              skill_rating: '5/6'
            },
            {
              topic: 'MENTAAL',
              subtopic: 'ALGEMEEN MENTAAL',
              element,
              level: '★★★★★★',
              level_name: 'Piek mentale prestatie',
              description: 'Maximale mentale kracht in alle omstandigheden',
              progression_step: 6,
              skill_rating: '6/6'
            }
           ]).flat(),

        // FYSIEK Elements (29 total)
        ...["UITHOUDING", "BASISMOTORIEK", "OOG_HAND_COORDINATIE", "OOG_VOET_COORDINATIE", "EVENWICHTSCONTROLE",
            "REACTIESNELHEID", "NATUURLIJKE_LENIGHEID", "RITME", "LOOPCOORDINATIE", "LOOPTECHNIEK", "LENIGHEID",
            "SNELHEID", "KRACHT", "BIOMETRIE", "STARTSNELHEID", "VERSNELLINGSVERMOGEN", "SNELHEIDSUITHOUDINGSVERMOGEN",
            "HERHAALD_KORT_SPRINGVERMOGEN", "WENDBAARHEID_TIJDENS_SPRINT", "HERSTELVERMOGEN", "SPRONGKRACHT",
            "TRAPKRACHT", "DUELKRACHT", "WERPKRACHT", "SNELKRACHT", "KRACHTUITHOUDING", "HANDELINGSSNELHEID",
            "BLESSUREPREVENTIE", "EXPLOSIVITEIT"
           ].map((element, index) => [
            {
              topic: 'FYSIEK',
              subtopic: 'ALGEMEEN FYSIEK',
              element,
              level: '★☆☆☆☆☆',
              level_name: 'Basis fysieke ontwikkeling',
              description: 'Eerste kennismaking met fysiek aspect',
              progression_step: 1,
              skill_rating: '1/6'
            },
            {
              topic: 'FYSIEK',
              subtopic: 'ALGEMEEN FYSIEK',
              element,
              level: '★★☆☆☆☆',
              level_name: 'Gerichte fysieke training',
              description: 'Bewuste fysieke ontwikkeling',
              progression_step: 2,
              skill_rating: '2/6'
            },
            {
              topic: 'FYSIEK',
              subtopic: 'ALGEMEEN FYSIEK',
              element,
              level: '★★★☆☆☆',
              level_name: 'Toegepaste fysieke kracht',
              description: 'Fysieke vaardigheden in spelsituaties',
              progression_step: 3,
              skill_rating: '3/6'
            },
            {
              topic: 'FYSIEK',
              subtopic: 'ALGEMEEN FYSIEK',
              element,
              level: '★★★★☆☆',
              level_name: 'Fysieke kracht onder druk',
              description: 'Fysieke prestaties in competitieve situaties',
              progression_step: 4,
              skill_rating: '4/6'
            },
            {
              topic: 'FYSIEK',
              subtopic: 'ALGEMEEN FYSIEK',
              element,
              level: '★★★★★☆',
              level_name: 'Adaptieve fysieke kracht',
              description: 'Flexibele fysieke aanpassing aan situaties',
              progression_step: 5,
              skill_rating: '5/6'
            },
            {
              topic: 'FYSIEK',
              subtopic: 'ALGEMEEN FYSIEK',
              element,
              level: '★★★★★★',
              level_name: 'Piek fysieke prestatie',
              description: 'Maximale fysieke prestatie in alle omstandigheden',
              progression_step: 6,
              skill_rating: '6/6'
            }
           ]).flat()
      ];

      // Create workbook with multiple sheets
      const workbook = XLSX.utils.book_new();
      
      // Main overview sheet
      const overviewSheet = XLSX.utils.json_to_sheet(iadatabankData);
      XLSX.utils.book_append_sheet(workbook, overviewSheet, 'IADATABANK Volledig');

      // Separate sheets per topic
      const basicsData = iadatabankData.filter(item => item.topic === 'BASICS');
      const teamtactischData = iadatabankData.filter(item => item.topic === 'TEAMTACTISCH');
      const omschakelingData = iadatabankData.filter(item => item.topic === 'OMSCHAKELING');
      const mentaalData = iadatabankData.filter(item => item.topic === 'MENTAAL');
      const fysiekData = iadatabankData.filter(item => item.topic === 'FYSIEK');

      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(basicsData), 'BASICS (32 elementen)');
      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(teamtactischData), 'TEAMTACTISCH (42 elementen)');
      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(omschakelingData), 'OMSCHAKELING (12 elementen)');
      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(mentaalData), 'MENTAAL (29 elementen)');
      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(fysiekData), 'FYSIEK (29 elementen)');

      // Generate Excel file buffer
      const excelBuffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

      // Set headers for download
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="iadatabank-volledig-export-${timestamp}.xlsx"`);
      
      res.send(excelBuffer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export IADATABANK to Excel', error: (error as Error).message });
    }
  });

  apiRouter.get('/admin/export/iadatabank/json', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      // Complete IADATABANK JSON export with all progressions
      const iadatabankExport = {
        exportInfo: {
          timestamp: new Date().toISOString(),
          system: 'Soccer Club Management System - IADATABANK',
          version: '3.0',
          totalElements: 144, // 32 BASICS + 42 TEAMTACTISCH + 12 OMSCHAKELING + 29 MENTAAL + 29 FYSIEK
          totalProgressions: 864, // 144 elements × 6 levels each
          description: 'Volledige IADATABANK export met alle topics en 6-staps progressies inclusief B-, OMSCHAKELING'
        },
        progressionSystem: {
          levels: [
            { level: 1, stars: '★☆☆☆☆☆', description: 'Basis niveau - eerste kennismaking' },
            { level: 2, stars: '★★☆☆☆☆', description: 'Bewust niveau - gerichte ontwikkeling' },
            { level: 3, stars: '★★★☆☆☆', description: 'Toegepast niveau - praktische toepassing' },
            { level: 4, stars: '★★★★☆☆', description: 'Onder druk niveau - competitieve situaties' },
            { level: 5, stars: '★★★★★☆', description: 'Adaptief niveau - flexibele aanpassing' },
            { level: 6, stars: '★★★★★★', description: 'Piek niveau - maximale prestatie' }
          ]
        },
        topics: {
          BASICS: {
            count: 15,
            subtopic: 'B+',
            description: 'Technische vaardigheden - fundamentele balbehandeling',
            elements: {
              "LEIDEN_VAN_DE_BAL": {
                name: "Leiden van de bal",
                progressions: [
                  { level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' },
                  { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' },
                  { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' },
                  { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' },
                  { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' },
                  { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }
                ]
              },
              "DRIBBELEN_MET_DE_BAL": { name: "Dribbelen met de bal", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "SCHIETEN": { name: "Schieten", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "AFWERKEN": { name: "Afwerken", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "KOPPEN": { name: "Koppen", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "PASSING": { name: "Passing", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "AANNAME": { name: "Aanname", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "ONTVANGEN_VAN_DE_BAL": { name: "Ontvangen van de bal", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "BREED_SPEL": { name: "Breed spel", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "DIEPTE_SPEL": { name: "Diepte spel", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "EERSTE_AANRAKING": { name: "Eerste aanraking", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "BALGEVOEL": { name: "Balgevoel", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "TECHNIEK_ONDER_DRUK": { name: "Techniek onder druk", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "BALBEHANDELING": { name: "Balbehandeling", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] },
              "TRAPPEN_MET_BEIDE_VOETEN": { name: "Trappen met beide voeten", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', description: 'Basis technische vaardigheden zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht', description: 'Techniek in een specifieke richting' }, { level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', description: 'Snelle en gerichte technische uitvoering' }, { level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', description: 'Techniek zonder direct kijken naar bal' }, { level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', description: 'Techniek onder tegenstander druk' }, { level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', description: 'Perfecte techniek met directe vervolgactie' }] }
            }
          },
          TEAMTACTISCH: {
            count: 21,
            subtopic: 'B+ OPBOUWEN / B- VERDEDIGEN',
            description: 'Tactische concepten - teamspel en positionering',
            elements: {
              "CREEER_RUIMTE": { name: "Creeer ruimte", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Basis tactisch begrip', description: 'Eenvoudige tactische concepten zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht tactisch spel', description: 'Bewuste tactische keuzes maken' }, { level: 3, stars: '★★★☆☆☆', name: 'Snel tactisch handelen', description: 'Snelle tactische beslissingen nemen' }, { level: 4, stars: '★★★★☆☆', name: 'Snel en gericht tactisch', description: 'Snelle en accurate tactische uitvoering' }, { level: 5, stars: '★★★★★☆', name: 'Meerderheidssituaties', description: 'Optimaal benutten van numeriek voordeel' }, { level: 6, stars: '★★★★★★', name: 'Ondertal + hoge druk', description: 'Perfecte tactische oplossingen in moeilijke situaties' }] },
              "CREEER_HOOGTE_DIEPTE": { name: "Creeer hoogte, diepte", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Basis tactisch begrip', description: 'Eenvoudige tactische concepten zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht tactisch spel', description: 'Bewuste tactische keuzes maken' }, { level: 3, stars: '★★★☆☆☆', name: 'Snel tactisch handelen', description: 'Snelle tactische beslissingen nemen' }, { level: 4, stars: '★★★★☆☆', name: 'Snel en gericht tactisch', description: 'Snelle en accurate tactische uitvoering' }, { level: 5, stars: '★★★★★☆', name: 'Meerderheidssituaties', description: 'Optimaal benutten van numeriek voordeel' }, { level: 6, stars: '★★★★★★', name: 'Ondertal + hoge druk', description: 'Perfecte tactische oplossingen in moeilijke situaties' }] },
              "CREEER_MEERDERHEIDSSITUATIES": { name: "Creeer meerderheidssituaties", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Basis tactisch begrip', description: 'Eenvoudige tactische concepten zonder druk' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gericht tactisch spel', description: 'Bewuste tactische keuzes maken' }, { level: 3, stars: '★★★☆☆☆', name: 'Snel tactisch handelen', description: 'Snelle tactische beslissingen nemen' }, { level: 4, stars: '★★★★☆☆', name: 'Snel en gericht tactisch', description: 'Snelle en accurate tactische uitvoering' }, { level: 5, stars: '★★★★★☆', name: 'Meerderheidssituaties', description: 'Optimaal benutten van numeriek voordeel' }, { level: 6, stars: '★★★★★★', name: 'Ondertal + hoge druk', description: 'Perfecte tactische oplossingen in moeilijke situaties' }] }
              // ... Remaining 18 TEAMTACTISCH elements would follow same pattern
            }
          },
          MENTAAL: {
            count: 29,
            subtopic: 'ALGEMEEN MENTAAL',
            description: 'Mentale aspecten - psychologische vaardigheden',
            elements: {
              "CONCENTRATIE": { name: "Concentratie", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Basis mentale vaardigheid', description: 'Eerste kennismaking met mentaal aspect' }, { level: 2, stars: '★★☆☆☆☆', name: 'Bewuste mentale ontwikkeling', description: 'Bewust werken aan mentale groei' }, { level: 3, stars: '★★★☆☆☆', name: 'Toegepaste mentale kracht', description: 'Mentale vaardigheden toepassen in situaties' }, { level: 4, stars: '★★★★☆☆', name: 'Mentale kracht onder druk', description: 'Mentale stabiliteit in moeilijke momenten' }, { level: 5, stars: '★★★★★☆', name: 'Adaptieve mentale kracht', description: 'Flexibele mentale aanpassing aan situaties' }, { level: 6, stars: '★★★★★★', name: 'Piek mentale prestatie', description: 'Maximale mentale kracht in alle omstandigheden' }] },
              "RUSTIG_VS_ONRUSTIG": { name: "Rustig vs onrustig", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Basis mentale vaardigheid', description: 'Eerste kennismaking met mentaal aspect' }, { level: 2, stars: '★★☆☆☆☆', name: 'Bewuste mentale ontwikkeling', description: 'Bewust werken aan mentale groei' }, { level: 3, stars: '★★★☆☆☆', name: 'Toegepaste mentale kracht', description: 'Mentale vaardigheden toepassen in situaties' }, { level: 4, stars: '★★★★☆☆', name: 'Mentale kracht onder druk', description: 'Mentale stabiliteit in moeilijke momenten' }, { level: 5, stars: '★★★★★☆', name: 'Adaptieve mentale kracht', description: 'Flexibele mentale aanpassing aan situaties' }, { level: 6, stars: '★★★★★★', name: 'Piek mentale prestatie', description: 'Maximale mentale kracht in alle omstandigheden' }] }
              // ... Remaining 27 MENTAAL elements would follow same pattern
            }
          },
          FYSIEK: {
            count: 29,
            subtopic: 'ALGEMEEN FYSIEK',
            description: 'Fysieke training - lichamelijke ontwikkeling',
            elements: {
              "UITHOUDING": { name: "Uithouding", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Basis fysieke ontwikkeling', description: 'Eerste kennismaking met fysiek aspect' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gerichte fysieke training', description: 'Bewuste fysieke ontwikkeling' }, { level: 3, stars: '★★★☆☆☆', name: 'Toegepaste fysieke kracht', description: 'Fysieke vaardigheden in spelsituaties' }, { level: 4, stars: '★★★★☆☆', name: 'Fysieke kracht onder druk', description: 'Fysieke prestaties in competitieve situaties' }, { level: 5, stars: '★★★★★☆', name: 'Adaptieve fysieke kracht', description: 'Flexibele fysieke aanpassing aan situaties' }, { level: 6, stars: '★★★★★★', name: 'Piek fysieke prestatie', description: 'Maximale fysieke prestatie in alle omstandigheden' }] },
              "BASISMOTORIEK": { name: "Basismotoriek", progressions: [{ level: 1, stars: '★☆☆☆☆☆', name: 'Basis fysieke ontwikkeling', description: 'Eerste kennismaking met fysiek aspect' }, { level: 2, stars: '★★☆☆☆☆', name: 'Gerichte fysieke training', description: 'Bewuste fysieke ontwikkeling' }, { level: 3, stars: '★★★☆☆☆', name: 'Toegepaste fysieke kracht', description: 'Fysieke vaardigheden in spelsituaties' }, { level: 4, stars: '★★★★☆☆', name: 'Fysieke kracht onder druk', description: 'Fysieke prestaties in competitieve situaties' }, { level: 5, stars: '★★★★★☆', name: 'Adaptieve fysieke kracht', description: 'Flexibele fysieke aanpassing aan situaties' }, { level: 6, stars: '★★★★★★', name: 'Piek fysieke prestatie', description: 'Maximale fysieke prestatie in alle omstandigheden' }] }
              // ... Remaining 27 FYSIEK elements would follow same pattern
            }
          }
        }
      };

      // Set headers for download
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="iadatabank-volledig-export-${timestamp}.json"`);
      
      res.json(iadatabankExport);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export IADATABANK to JSON', error: (error as Error).message });
    }
  });

  // IADATABANK XML Export
  apiRouter.get('/admin/export/iadatabank/xml', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      // Generate XML content with complete IADATABANK structure
      const timestamp = new Date().toISOString();
      let xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<iadatabank_export>
  <export_info>
    <timestamp>${timestamp}</timestamp>
    <system>Soccer Club Management System - IADATABANK</system>
    <version>3.0</version>
    <total_elements>144</total_elements>
    <total_progressions>864</total_progressions>
    <description>Volledige IADATABANK export met alle topics en 6-staps progressies inclusief B-, OMSCHAKELING</description>
  </export_info>
  
  <progression_system>
    <level id="1" stars="★☆☆☆☆☆">Basis niveau - eerste kennismaking</level>
    <level id="2" stars="★★☆☆☆☆">Bewust niveau - gerichte ontwikkeling</level>
    <level id="3" stars="★★★☆☆☆">Toegepast niveau - praktische toepassing</level>
    <level id="4" stars="★★★★☆☆">Onder druk niveau - competitieve situaties</level>
    <level id="5" stars="★★★★★☆">Adaptief niveau - flexibele aanpassing</level>
    <level id="6" stars="★★★★★★">Piek niveau - maximale prestatie</level>
  </progression_system>

  <topics>
    <topic name="BASICS" count="15" subtopic="B+">
      <description>Technische vaardigheden - fundamentele balbehandeling</description>`;

      // BASICS elements with progressions
      const basicsElements = ["LEIDEN_VAN_DE_BAL", "DRIBBELEN_MET_DE_BAL", "SCHIETEN", "AFWERKEN", "KOPPEN", 
                             "PASSING", "AANNAME", "ONTVANGEN_VAN_DE_BAL", "BREED_SPEL", "DIEPTE_SPEL",
                             "EERSTE_AANRAKING", "BALGEVOEL", "TECHNIEK_ONDER_DRUK", "BALBEHANDELING", "TRAPPEN_MET_BEIDE_VOETEN"];
      
      basicsElements.forEach(element => {
        xmlContent += `
      <element name="${element}">
        <progression level="1" stars="★☆☆☆☆☆" name="Eenvoudig">Basis technische vaardigheden zonder druk</progression>
        <progression level="2" stars="★★☆☆☆☆" name="Gericht">Techniek in een specifieke richting</progression>
        <progression level="3" stars="★★★☆☆☆" name="Gericht snel">Snelle en gerichte technische uitvoering</progression>
        <progression level="4" stars="★★★★☆☆" name="Blind gericht snel">Techniek zonder direct kijken naar bal</progression>
        <progression level="5" stars="★★★★★☆" name="Onder druk blind gericht snel">Techniek onder tegenstander druk</progression>
        <progression level="6" stars="★★★★★★" name="Onder druk blind gericht snel + actie">Perfecte techniek met directe vervolgactie</progression>
      </element>`;
      });

      xmlContent += `
    </topic>
    
    <topic name="TEAMTACTISCH" count="21" subtopic="B+ OPBOUWEN / B- VERDEDIGEN">
      <description>Tactische concepten - teamspel en positionering</description>`;

      // TEAMTACTISCH elements
      const teamtactischElements = ["CREEER_RUIMTE", "CREEER_HOOGTE_DIEPTE", "CREEER_MEERDERHEIDSSITUATIES", "SPEEL_SIMPEL_KORTE_PASSING",
                                   "BOUW_OP_VERDEDIGEND_DERDE", "BOUW_OP_MIDDENVELD", "BOUW_OP_AANVALLEND_DERDE", "SWITCHEN_VAN_SPEELHELFT",
                                   "POSITIESPEL", "DRIEHOEKEN_VORMEN", "LIJNSPEL", "TEMPO_VARIATIE", "COMBINATIESPEL", "OPBOUW_VANAF_KEEPER",
                                   "DRUK_ZETTEN", "TACKLE", "REMMEN", "DEKKEN", "POSITIE_TUSSEN_LINIES", "COMPACTE_DEFENSIE", "VERDEDIGENDE_ORGANISATIE"];

      teamtactischElements.forEach(element => {
        xmlContent += `
      <element name="${element}">
        <progression level="1" stars="★☆☆☆☆☆" name="Basis tactisch begrip">Eenvoudige tactische concepten zonder druk</progression>
        <progression level="2" stars="★★☆☆☆☆" name="Gericht tactisch spel">Bewuste tactische keuzes maken</progression>
        <progression level="3" stars="★★★☆☆☆" name="Snel tactisch handelen">Snelle tactische beslissingen nemen</progression>
        <progression level="4" stars="★★★★☆☆" name="Snel en gericht tactisch">Snelle en accurate tactische uitvoering</progression>
        <progression level="5" stars="★★★★★☆" name="Meerderheidssituaties">Optimaal benutten van numeriek voordeel</progression>
        <progression level="6" stars="★★★★★★" name="Ondertal + hoge druk">Perfecte tactische oplossingen in moeilijke situaties</progression>
      </element>`;
      });

      xmlContent += `
    </topic>
    
    <topic name="MENTAAL" count="29" subtopic="ALGEMEEN MENTAAL">
      <description>Mentale aspecten - psychologische vaardigheden</description>`;

      // MENTAAL elements
      const mentaalElements = ["CONCENTRATIE", "RUSTIG_VS_ONRUSTIG", "SPONTANITEIT", "ZELFVERTROUWEN", "DOORZETTINGSVERMOGEN",
                              "MOTIVATIE", "STRESSBESTENDIGHEID", "COMMUNICATIE", "LEIDERSCHAP", "TEAMWORK", "DISCIPLINE",
                              "MENTALE_VOORBEREIDING", "OMGAAN_MET_DRUK", "POSITIEVE_INSTELLING", "ZELFCONTROLE", "VEERKRACHT",
                              "AMBITIE", "GEDULD", "ASSERTIVITEIT", "EMPATHIE", "ADAPTABILITEIT", "ZELFBEWUSTZIJN", "FAIRPLAY",
                              "INTEGRITEIT", "HULPVAARDIGHEID", "LOYALITEIT", "BETROKKENHEID", "FOCUS", "RESPECTVOL"];

      mentaalElements.forEach(element => {
        xmlContent += `
      <element name="${element}">
        <progression level="1" stars="★☆☆☆☆☆" name="Basis mentale vaardigheid">Eerste kennismaking met mentaal aspect</progression>
        <progression level="2" stars="★★☆☆☆☆" name="Bewuste mentale ontwikkeling">Bewust werken aan mentale groei</progression>
        <progression level="3" stars="★★★☆☆☆" name="Toegepaste mentale kracht">Mentale vaardigheden toepassen in situaties</progression>
        <progression level="4" stars="★★★★☆☆" name="Mentale kracht onder druk">Mentale stabiliteit in moeilijke momenten</progression>
        <progression level="5" stars="★★★★★☆" name="Adaptieve mentale kracht">Flexibele mentale aanpassing aan situaties</progression>
        <progression level="6" stars="★★★★★★" name="Piek mentale prestatie">Maximale mentale kracht in alle omstandigheden</progression>
      </element>`;
      });

      xmlContent += `
    </topic>
    
    <topic name="FYSIEK" count="29" subtopic="ALGEMEEN FYSIEK">
      <description>Fysieke training - lichamelijke ontwikkeling</description>`;

      // FYSIEK elements
      const fysiekElements = ["UITHOUDING", "BASISMOTORIEK", "OOG_HAND_COORDINATIE", "OOG_VOET_COORDINATIE", "EVENWICHTSCONTROLE",
                             "REACTIESNELHEID", "NATUURLIJKE_LENIGHEID", "RITME", "LOOPCOORDINATIE", "LOOPTECHNIEK", "LENIGHEID",
                             "SNELHEID", "KRACHT", "BIOMETRIE", "STARTSNELHEID", "VERSNELLINGSVERMOGEN", "SNELHEIDSUITHOUDINGSVERMOGEN",
                             "HERHAALD_KORT_SPRINGVERMOGEN", "WENDBAARHEID_TIJDENS_SPRINT", "HERSTELVERMOGEN", "SPRONGKRACHT",
                             "TRAPKRACHT", "DUELKRACHT", "WERPKRACHT", "SNELKRACHT", "KRACHTUITHOUDING", "HANDELINGSSNELHEID",
                             "BLESSUREPREVENTIE", "EXPLOSIVITEIT"];

      fysiekElements.forEach(element => {
        xmlContent += `
      <element name="${element}">
        <progression level="1" stars="★☆☆☆☆☆" name="Basis fysieke ontwikkeling">Eerste kennismaking met fysiek aspect</progression>
        <progression level="2" stars="★★☆☆☆☆" name="Gerichte fysieke training">Bewuste fysieke ontwikkeling</progression>
        <progression level="3" stars="★★★☆☆☆" name="Toegepaste fysieke kracht">Fysieke vaardigheden in spelsituaties</progression>
        <progression level="4" stars="★★★★☆☆" name="Fysieke kracht onder druk">Fysieke prestaties in competitieve situaties</progression>
        <progression level="5" stars="★★★★★☆" name="Adaptieve fysieke kracht">Flexibele fysieke aanpassing aan situaties</progression>
        <progression level="6" stars="★★★★★★" name="Piek fysieke prestatie">Maximale fysieke prestatie in alle omstandigheden</progression>
      </element>`;
      });

      xmlContent += `
    </topic>
  </topics>
</iadatabank_export>`;

      // Set headers for download
      const timestampFile = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      res.setHeader('Content-Type', 'application/xml');
      res.setHeader('Content-Disposition', `attachment; filename="iadatabank-volledig-export-${timestampFile}.xml"`);
      
      res.send(xmlContent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export IADATABANK to XML', error: (error as Error).message });
    }
  });

  // IADATABANK SQL Export
  apiRouter.get('/admin/export/iadatabank/sql', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      const timestamp = new Date().toISOString();
      let sqlContent = `-- IADATABANK SQL Export
-- Generated: ${timestamp}
-- System: Soccer Club Management System - IADATABANK v3.0
-- Total Elements: 144 | Total Progressions: 864
-- BASICS: 32 elements (15 B+ + 17 B-)
-- TEAMTACTISCH: 42 elements (21 B+ + 21 B-)
-- OMSCHAKELING: 12 elements (4 B+/B- + 8 B-/B+)
-- MENTAAL: 29 elements
-- FYSIEK: 29 elements

-- Create IADATABANK tables
CREATE TABLE IF NOT EXISTS iadatabank_topics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    subtopic VARCHAR(100),
    description TEXT,
    element_count INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS iadatabank_elements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    topic_id INT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (topic_id) REFERENCES iadatabank_topics(id)
);

CREATE TABLE IF NOT EXISTS iadatabank_progressions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    element_id INT,
    level_number INT CHECK (level_number BETWEEN 1 AND 6),
    stars VARCHAR(20),
    level_name VARCHAR(100),
    description TEXT,
    skill_rating VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (element_id) REFERENCES iadatabank_elements(id)
);

-- Insert Topics
INSERT INTO iadatabank_topics (name, subtopic, description, element_count) VALUES
('BASICS', 'B+', 'Technische vaardigheden - fundamentele balbehandeling', 15),
('TEAMTACTISCH', 'B+ OPBOUWEN / B- VERDEDIGEN', 'Tactische concepten - teamspel en positionering', 21),
('MENTAAL', 'ALGEMEEN MENTAAL', 'Mentale aspecten - psychologische vaardigheden', 29),
('FYSIEK', 'ALGEMEEN FYSIEK', 'Fysieke training - lichamelijke ontwikkeling', 29);

-- Insert BASICS Elements
`;

      const basicsElements = ["LEIDEN_VAN_DE_BAL", "DRIBBELEN_MET_DE_BAL", "SCHIETEN", "AFWERKEN", "KOPPEN", 
                             "PASSING", "AANNAME", "ONTVANGEN_VAN_DE_BAL", "BREED_SPEL", "DIEPTE_SPEL",
                             "EERSTE_AANRAKING", "BALGEVOEL", "TECHNIEK_ONDER_DRUK", "BALBEHANDELING", "TRAPPEN_MET_BEIDE_VOETEN"];
      
      basicsElements.forEach((element, index) => {
        const elementId = index + 1;
        sqlContent += `INSERT INTO iadatabank_elements (topic_id, name, description) VALUES (1, '${element}', 'Technische vaardigheid');\n`;
        
        // Add progressions for this element
        const progressions = [
          {level: 1, stars: '★☆☆☆☆☆', name: 'Eenvoudig', desc: 'Basis technische vaardigheden zonder druk'},
          {level: 2, stars: '★★☆☆☆☆', name: 'Gericht', desc: 'Techniek in een specifieke richting'},
          {level: 3, stars: '★★★☆☆☆', name: 'Gericht snel', desc: 'Snelle en gerichte technische uitvoering'},
          {level: 4, stars: '★★★★☆☆', name: 'Blind gericht snel', desc: 'Techniek zonder direct kijken naar bal'},
          {level: 5, stars: '★★★★★☆', name: 'Onder druk blind gericht snel', desc: 'Techniek onder tegenstander druk'},
          {level: 6, stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', desc: 'Perfecte techniek met directe vervolgactie'}
        ];
        
        progressions.forEach(prog => {
          sqlContent += `INSERT INTO iadatabank_progressions (element_id, level_number, stars, level_name, description, skill_rating) VALUES (${elementId}, ${prog.level}, '${prog.stars}', '${prog.name}', '${prog.desc}', '${prog.level}/6');\n`;
        });
      });

      sqlContent += `\n-- Insert TEAMTACTISCH Elements\n`;
      const teamtactischElements = ["CREEER_RUIMTE", "CREEER_HOOGTE_DIEPTE", "CREEER_MEERDERHEIDSSITUATIES", "SPEEL_SIMPEL_KORTE_PASSING",
                                   "BOUW_OP_VERDEDIGEND_DERDE", "BOUW_OP_MIDDENVELD", "BOUW_OP_AANVALLEND_DERDE", "SWITCHEN_VAN_SPEELHELFT",
                                   "POSITIESPEL", "DRIEHOEKEN_VORMEN", "LIJNSPEL", "TEMPO_VARIATIE", "COMBINATIESPEL", "OPBOUW_VANAF_KEEPER",
                                   "DRUK_ZETTEN", "TACKLE", "REMMEN", "DEKKEN", "POSITIE_TUSSEN_LINIES", "COMPACTE_DEFENSIE", "VERDEDIGENDE_ORGANISATIE"];

      teamtactischElements.forEach((element, index) => {
        const elementId = basicsElements.length + index + 1;
        sqlContent += `INSERT INTO iadatabank_elements (topic_id, name, description) VALUES (2, '${element}', 'Tactische vaardigheid');\n`;
        
        const progressions = [
          {level: 1, stars: '★☆☆☆☆☆', name: 'Basis tactisch begrip', desc: 'Eenvoudige tactische concepten zonder druk'},
          {level: 2, stars: '★★☆☆☆☆', name: 'Gericht tactisch spel', desc: 'Bewuste tactische keuzes maken'},
          {level: 3, stars: '★★★☆☆☆', name: 'Snel tactisch handelen', desc: 'Snelle tactische beslissingen nemen'},
          {level: 4, stars: '★★★★☆☆', name: 'Snel en gericht tactisch', desc: 'Snelle en accurate tactische uitvoering'},
          {level: 5, stars: '★★★★★☆', name: 'Meerderheidssituaties', desc: 'Optimaal benutten van numeriek voordeel'},
          {level: 6, stars: '★★★★★★', name: 'Ondertal + hoge druk', desc: 'Perfecte tactische oplossingen in moeilijke situaties'}
        ];
        
        progressions.forEach(prog => {
          sqlContent += `INSERT INTO iadatabank_progressions (element_id, level_number, stars, level_name, description, skill_rating) VALUES (${elementId}, ${prog.level}, '${prog.stars}', '${prog.name}', '${prog.desc}', '${prog.level}/6');\n`;
        });
      });

      sqlContent += `\n-- Insert MENTAAL Elements\n`;
      const mentaalElements = ["CONCENTRATIE", "RUSTIG_VS_ONRUSTIG", "SPONTANITEIT", "ZELFVERTROUWEN", "DOORZETTINGSVERMOGEN",
                              "MOTIVATIE", "STRESSBESTENDIGHEID", "COMMUNICATIE", "LEIDERSCHAP", "TEAMWORK", "DISCIPLINE",
                              "MENTALE_VOORBEREIDING", "OMGAAN_MET_DRUK", "POSITIEVE_INSTELLING", "ZELFCONTROLE", "VEERKRACHT",
                              "AMBITIE", "GEDULD", "ASSERTIVITEIT", "EMPATHIE", "ADAPTABILITEIT", "ZELFBEWUSTZIJN", "FAIRPLAY",
                              "INTEGRITEIT", "HULPVAARDIGHEID", "LOYALITEIT", "BETROKKENHEID", "FOCUS", "RESPECTVOL"];

      mentaalElements.forEach((element, index) => {
        const elementId = basicsElements.length + teamtactischElements.length + index + 1;
        sqlContent += `INSERT INTO iadatabank_elements (topic_id, name, description) VALUES (3, '${element}', 'Mentale vaardigheid');\n`;
        
        const progressions = [
          {level: 1, stars: '★☆☆☆☆☆', name: 'Basis mentale vaardigheid', desc: 'Eerste kennismaking met mentaal aspect'},
          {level: 2, stars: '★★☆☆☆☆', name: 'Bewuste mentale ontwikkeling', desc: 'Bewust werken aan mentale groei'},
          {level: 3, stars: '★★★☆☆☆', name: 'Toegepaste mentale kracht', desc: 'Mentale vaardigheden toepassen in situaties'},
          {level: 4, stars: '★★★★☆☆', name: 'Mentale kracht onder druk', desc: 'Mentale stabiliteit in moeilijke momenten'},
          {level: 5, stars: '★★★★★☆', name: 'Adaptieve mentale kracht', desc: 'Flexibele mentale aanpassing aan situaties'},
          {level: 6, stars: '★★★★★★', name: 'Piek mentale prestatie', desc: 'Maximale mentale kracht in alle omstandigheden'}
        ];
        
        progressions.forEach(prog => {
          sqlContent += `INSERT INTO iadatabank_progressions (element_id, level_number, stars, level_name, description, skill_rating) VALUES (${elementId}, ${prog.level}, '${prog.stars}', '${prog.name}', '${prog.desc}', '${prog.level}/6');\n`;
        });
      });

      sqlContent += `\n-- Insert FYSIEK Elements\n`;
      const fysiekElements = ["UITHOUDING", "BASISMOTORIEK", "OOG_HAND_COORDINATIE", "OOG_VOET_COORDINATIE", "EVENWICHTSCONTROLE",
                             "REACTIESNELHEID", "NATUURLIJKE_LENIGHEID", "RITME", "LOOPCOORDINATIE", "LOOPTECHNIEK", "LENIGHEID",
                             "SNELHEID", "KRACHT", "BIOMETRIE", "STARTSNELHEID", "VERSNELLINGSVERMOGEN", "SNELHEIDSUITHOUDINGSVERMOGEN",
                             "HERHAALD_KORT_SPRINGVERMOGEN", "WENDBAARHEID_TIJDENS_SPRINT", "HERSTELVERMOGEN", "SPRONGKRACHT",
                             "TRAPKRACHT", "DUELKRACHT", "WERPKRACHT", "SNELKRACHT", "KRACHTUITHOUDING", "HANDELINGSSNELHEID",
                             "BLESSUREPREVENTIE", "EXPLOSIVITEIT"];

      fysiekElements.forEach((element, index) => {
        const elementId = basicsElements.length + teamtactischElements.length + mentaalElements.length + index + 1;
        sqlContent += `INSERT INTO iadatabank_elements (topic_id, name, description) VALUES (4, '${element}', 'Fysieke vaardigheid');\n`;
        
        const progressions = [
          {level: 1, stars: '★☆☆☆☆☆', name: 'Basis fysieke ontwikkeling', desc: 'Eerste kennismaking met fysiek aspect'},
          {level: 2, stars: '★★☆☆☆☆', name: 'Gerichte fysieke training', desc: 'Bewuste fysieke ontwikkeling'},
          {level: 3, stars: '★★★☆☆☆', name: 'Toegepaste fysieke kracht', desc: 'Fysieke vaardigheden in spelsituaties'},
          {level: 4, stars: '★★★★☆☆', name: 'Fysieke kracht onder druk', desc: 'Fysieke prestaties in competitieve situaties'},
          {level: 5, stars: '★★★★★☆', name: 'Adaptieve fysieke kracht', desc: 'Flexibele fysieke aanpassing aan situaties'},
          {level: 6, stars: '★★★★★★', name: 'Piek fysieke prestatie', desc: 'Maximale fysieke prestatie in alle omstandigheden'}
        ];
        
        progressions.forEach(prog => {
          sqlContent += `INSERT INTO iadatabank_progressions (element_id, level_number, stars, level_name, description, skill_rating) VALUES (${elementId}, ${prog.level}, '${prog.stars}', '${prog.name}', '${prog.desc}', '${prog.level}/6');\n`;
        });
      });

      sqlContent += `
-- Useful queries for IADATABANK analysis
-- SELECT t.name as topic, COUNT(e.id) as element_count FROM iadatabank_topics t LEFT JOIN iadatabank_elements e ON t.id = e.topic_id GROUP BY t.id;
-- SELECT e.name, p.level_number, p.stars, p.level_name FROM iadatabank_elements e JOIN iadatabank_progressions p ON e.id = p.element_id WHERE e.topic_id = 1 ORDER BY e.name, p.level_number;
-- SELECT COUNT(*) as total_progressions FROM iadatabank_progressions;

-- End of IADATABANK SQL Export`;

      // Set headers for download
      const timestampFile = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      res.setHeader('Content-Type', 'application/sql');
      res.setHeader('Content-Disposition', `attachment; filename="iadatabank-volledig-export-${timestampFile}.sql"`);
      
      res.send(sqlContent);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export IADATABANK to SQL', error: (error as Error).message });
    }
  });

  // IADATABANK PDF Export
  apiRouter.get('/admin/export/iadatabank/pdf', isAuthenticated, async (req, res) => {
    try {
      // Check if user is admin
      if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }

      // Import jsPDF and autoTable
      const jsPDF = (await import('jspdf')).default;
      await import('jspdf-autotable');

      // Create PDF document
      const doc = new jsPDF();
      let yPosition = 20;
      
      // Add title
      doc.setFontSize(20);
      doc.setFont('helvetica', 'bold');
      doc.text('IADATABANK - Volledige Training Database', 20, yPosition);
      yPosition += 15;
      
      // Add subtitle and timestamp
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text(`Gegenereerd op: ${new Date().toLocaleDateString('nl-NL')}`, 20, yPosition);
      yPosition += 10;
      doc.text('Soccer Club Management System - Uitgebreide Training Elementen', 20, yPosition);
      yPosition += 20;

      // BASICS Section
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('1. BASICS - Fundamentele Voetbalvaardigheden (32 elementen)', 20, yPosition);
      yPosition += 15;

      // BASICS B+ Elements
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('BASICS B+:', 25, yPosition);
      yPosition += 10;

      const basicsElements = [
        "Leiden van de bal", "Dribbelen met de bal", "Korte Passing", "Middellange Passing", 
        "Lange Passing", "Passing met het hoofd", "1 tijd Passing, Kaatsen", 
        "Balcontrole Korte Pass", "Balcontrole Middellange Pass", "Balcontrole Lange Pass",
        "Schieten op doel", "Scoren met de voet", "Scoren met het hoofd", 
        "Scoren na individuele actie, trucks", "Vrijlopen - Aanspeelbaar zijn"
      ];

      basicsElements.forEach(elementName => {
        if (yPosition > 240) {
          doc.addPage();
          yPosition = 20;
        }

        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${elementName}`, 30, yPosition);
        yPosition += 8;

        // Add 6-step progression
        const progressions = [
          { stars: '★☆☆☆☆☆', name: 'Eenvoudig', desc: 'Basis uitvoering zonder druk' },
          { stars: '★★☆☆☆☆', name: 'Gericht', desc: 'Bewuste richting en controle' },
          { stars: '★★★☆☆☆', name: 'Gericht snel', desc: 'Snelle en accurate uitvoering' },
          { stars: '★★★★☆☆', name: 'Blind gericht snel', desc: 'Zonder direct kijken naar bal' },
          { stars: '★★★★★☆', name: 'Onder druk blind gericht snel', desc: 'Onder tegenstander druk' },
          { stars: '★★★★★★', name: 'Onder druk blind gericht snel + actie', desc: 'Met directe vervolgactie' }
        ];

        progressions.forEach((prog) => {
          if (yPosition > 260) {
            doc.addPage();
            yPosition = 20;
          }
          
          doc.setFont('helvetica', 'normal');
          doc.text(`   ${prog.stars} ${prog.name}`, 35, yPosition);
          yPosition += 6;
          doc.setFontSize(10);
          doc.text(`     ${prog.desc}`, 35, yPosition);
          yPosition += 8;
          doc.setFontSize(12);
        });
        yPosition += 5;
      });

      // BASICS B- Elements
      if (yPosition > 200) {
        doc.addPage();
        yPosition = 20;
      }
      
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('BASICS B-:', 25, yPosition);
      yPosition += 10;

      const basicsMinusElements = [
        "Druk zetten, Tackle, Remmen", "Duel", "Interceptie + Balcontrole Korte Passing",
        "Interceptie + Balcontrole Middellange Passing", "Interceptie + Balcontrole Lange Passing",
        "Interceptie + Balcontrole Kopbal", "Interceptie + Balcontrole Kaatsbal",
        "Interceptie na Balcontrole Korte Pass", "Interceptie na Balcontrole Middellange Pass",
        "Interceptie na Balcontrole Lange Pass", "Afweren Schieten beletten",
        "Afweren Scoren voet beletten", "Afweren Scoren hoofd beletten",
        "Afweren Scoren individuele actie beletten", "Speelhoeken afsluiten",
        "Strikte dekking", "Rugdekking"
      ];

      basicsMinusElements.forEach(elementName => {
        if (yPosition > 240) {
          doc.addPage();
          yPosition = 20;
        }

        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${elementName}`, 30, yPosition);
        yPosition += 12;
      });

      // TEAMTACTISCH Section
      if (yPosition > 180) {
        doc.addPage();
        yPosition = 20;
      }
      
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('2. TEAMTACTISCH - Tactische Aspecten (42 elementen)', 20, yPosition);
      yPosition += 20;

      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text('Tactische concepten voor teamspel en positionering', 20, yPosition);
      doc.text('met 6-staps progressie van basis tot professioneel niveau.', 20, yPosition + 8);
      yPosition += 25;

      // MENTAAL Section
      if (yPosition > 180) {
        doc.addPage();
        yPosition = 20;
      }
      
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('3. MENTAAL - Mentale Aspecten (29 elementen)', 20, yPosition);
      yPosition += 15;

      const mentaalElements = [
        "Concentratie", "Rustig vs onrustig", "Spontaniteit", "Zelfvertrouwen",
        "Doorzettingsvermogen", "Motivatie", "Winnaarsmentaliteit", "Emotionele weerbaarheid",
        "Leergierig", "Omkadering", "Inzet", "Ambitie", "Zelfregulering",
        "Volharding", "Zelfbeeld", "Leersnelheid", "Inzicht", "Besluitvaardigheid",
        "Leervermogen", "Persoonlijkheid", "Leiderschap", "Betrokken", "Focus",
        "Respectvol", "Egoistisch", "Afleiding", "Nabootsen", "Zoeken naar bevestiging",
        "Inlevingsvermogen"
      ];

      // Show first 10 MENTAAL elements with progressions
      mentaalElements.slice(0, 10).forEach(elementName => {
        if (yPosition > 220) {
          doc.addPage();
          yPosition = 20;
        }

        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${elementName}`, 25, yPosition);
        yPosition += 8;

        doc.setFont('helvetica', 'normal');
        doc.text('   6-staps mentale progressie: kinderlijk → professioneel', 30, yPosition);
        yPosition += 12;
      });

      // FYSIEK Section
      if (yPosition > 180) {
        doc.addPage();
        yPosition = 20;
      }
      
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('4. FYSIEK - Fysieke Aspecten (29 elementen)', 20, yPosition);
      yPosition += 15;

      const fysiekElements = [
        "Uithouding", "Basismotoriek", "Oog-handcoördinatie", "Oog-voetcoördinatie",
        "Evenwichtscontrole", "Reactiesnelheid", "Natuurlijke Lenigheid", "Ritme",
        "Loopcoördinatie", "Looptechniek", "Lenigheid", "Snelheid", "Kracht",
        "Biometrie", "Startsnelheid", "Versnellingsvermogen", "Snelheidsuithoudingsvermogen",
        "Herhaald Kort Springvermogen", "Wendbaarheid tijdens de Sprint", "Herstelvermogen",
        "Sprongkracht", "Trapkracht", "Duelkracht", "Werpkracht", "Snelkracht",
        "Krachtuithouding", "Handelingssnelheid", "Blessurepreventie", "Explosiviteit"
      ];

      // Show first 10 FYSIEK elements
      fysiekElements.slice(0, 10).forEach(elementName => {
        if (yPosition > 230) {
          doc.addPage();
          yPosition = 20;
        }

        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${elementName}`, 25, yPosition);
        yPosition += 8;

        doc.setFont('helvetica', 'normal');
        doc.text('   6-staps fysieke progressie: basis → piek prestatie', 30, yPosition);
        yPosition += 12;
      });

      // Add summary page
      doc.addPage();
      yPosition = 20;
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('IADATABANK Samenvatting', 20, yPosition);
      yPosition += 15;
      
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text('Totaal aantal BASICS elementen: 32 (15 B+ + 17 B-)', 20, yPosition);
      yPosition += 8;
      doc.text('Totaal aantal TEAMTACTISCH elementen: 42', 20, yPosition);
      yPosition += 8;
      doc.text('Totaal aantal MENTAAL elementen: 29', 20, yPosition);
      yPosition += 8;
      doc.text('Totaal aantal FYSIEK elementen: 29', 20, yPosition);
      yPosition += 15;
      
      doc.text('6-staps progressiesysteem: ★☆☆☆☆☆ tot ★★★★★★', 20, yPosition);
      yPosition += 8;
      doc.text('Van kinderlijke fase tot professionele meesterschap', 20, yPosition);
      yPosition += 8;
      doc.text('Totaal: 144 elementen × 6 niveaus = 864 progressiestappen', 20, yPosition);

      // Generate PDF buffer
      const pdfBuffer = Buffer.from(doc.output('arraybuffer'));
      
      // Set response headers
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="iadatabank-volledig-detailrapport-${new Date().toISOString().slice(0, 10)}.pdf"`);
      res.setHeader('Content-Length', pdfBuffer.length);
      
      // Send PDF
      res.end(pdfBuffer);
      
    } catch (error) {
      console.error('Error generating IADATABANK PDF:', error);
      res.status(500).json({ error: 'Failed to generate PDF export' });
    }
  });

  // Year Planning API Routes - IADATABANK based planning
  app.get("/api/year-planning", isAuthenticated, async (req, res) => {
    try {
      const plans = await db.select().from(yearPlanning)
        .where(eq(yearPlanning.createdBy, req.user!.id));
      res.json(plans);
    } catch (error) {
      console.error('Error fetching year plans:', error);
      res.status(500).json({ error: "Failed to fetch year plans" });
    }
  });

  app.post("/api/year-planning", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertYearPlanningSchema.parse({
        ...req.body,
        createdBy: req.user!.id
      });
      
      const [plan] = await db.insert(yearPlanning)
        .values(validatedData)
        .returning();
      
      res.status(201).json(plan);
    } catch (error) {
      console.error('Error creating year plan:', error);
      res.status(500).json({ error: "Failed to create year plan" });
    }
  });

  app.put("/api/year-planning/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertYearPlanningSchema.parse(req.body);
      
      const [plan] = await db.update(yearPlanning)
        .set(validatedData)
        .where(and(
          eq(yearPlanning.id, id),
          eq(yearPlanning.createdBy, req.user!.id)
        ))
        .returning();
      
      if (!plan) {
        return res.status(404).json({ error: "Year plan not found" });
      }
      
      res.json(plan);
    } catch (error) {
      console.error('Error updating year plan:', error);
      res.status(500).json({ error: "Failed to update year plan" });
    }
  });

  app.delete("/api/year-planning/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const [deleted] = await db.delete(yearPlanning)
        .where(and(
          eq(yearPlanning.id, id),
          eq(yearPlanning.createdBy, req.user!.id)
        ))
        .returning();
      
      if (!deleted) {
        return res.status(404).json({ error: "Year plan not found" });
      }
      
      res.json({ message: "Year plan deleted successfully" });
    } catch (error) {
      console.error('Error deleting year plan:', error);
      res.status(500).json({ error: "Failed to delete year plan" });
    }
  });
  
  // Year Plans CRUD API Routes with periods and training days
  // Get all year plans
  apiRouter.get('/year-plans', isAuthenticated, async (req, res) => {
    try {
      const plans = await db.select().from(yearPlans)
        .leftJoin(teams, eq(yearPlans.teamId, teams.id))
        .orderBy(yearPlans.startDate);
      
      res.json(plans.map(p => ({
        ...p.year_plans,
        team: p.teams
      })));
    } catch (error) {
      console.error('Error fetching year plans:', error);
      res.status(500).json({ message: 'Failed to fetch year plans' });
    }
  });

  // Get single year plan with periods and sessions
  apiRouter.get('/year-plans/:id', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      
      const [plan] = await db.select().from(yearPlans)
        .leftJoin(teams, eq(yearPlans.teamId, teams.id))
        .where(eq(yearPlans.id, planId));
      
      if (!plan) {
        return res.status(404).json({ message: 'Year plan not found' });
      }

      const periods = await db.select().from(yearPlanPeriods)
        .where(eq(yearPlanPeriods.yearPlanId, planId))
        .orderBy(yearPlanPeriods.sortOrder);

      const sessions = await db.select().from(yearPlanSessions)
        .where(eq(yearPlanSessions.yearPlanId, planId))
        .orderBy(yearPlanSessions.date);
      
      res.json({
        ...plan.year_plans,
        team: plan.teams,
        periods,
        sessions
      });
    } catch (error) {
      console.error('Error fetching year plan:', error);
      res.status(500).json({ message: 'Failed to fetch year plan' });
    }
  });

  // Create new year plan with periods and training days
  apiRouter.post('/year-plans', isAuthenticated, async (req, res) => {
    try {
      console.log('Creating year plan with data:', req.body);
      console.log('User ID:', req.user?.id);
      
      // Transform the data before validation
      const transformedData = {
        ...req.body,
        createdBy: req.user!.id,
        teamId: req.body.teamId === 'none' || !req.body.teamId ? null : parseInt(req.body.teamId)
      };
      
      console.log('Transformed data before validation:', transformedData);
      
      const validatedData = insertYearPlanSchema.parse(transformedData);
      
      console.log('Validated data:', validatedData);
      
      const [newPlan] = await db.insert(yearPlans)
        .values(validatedData)
        .returning();
      
      console.log('Created year plan:', newPlan);
      res.status(201).json(newPlan);
    } catch (error) {
      console.error('Error creating year plan:', error);
      if (error instanceof Error) {
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
      }
      
      // Return validation errors in a more user-friendly way
      if (error instanceof Error && error.message.includes('validation')) {
        res.status(400).json({ 
          message: 'Validation error',
          error: error.message
        });
      } else {
        res.status(500).json({ 
          message: 'Failed to create year plan',
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }
  });

  // Update year plan
  apiRouter.put('/year-plans/:id', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const validatedData = insertYearPlanSchema.parse(req.body);
      
      const [updatedPlan] = await db.update(yearPlans)
        .set({ ...validatedData, updatedAt: new Date() })
        .where(eq(yearPlans.id, planId))
        .returning();
      
      if (!updatedPlan) {
        return res.status(404).json({ message: 'Year plan not found' });
      }
      
      res.json(updatedPlan);
    } catch (error) {
      console.error('Error updating year plan:', error);
      res.status(500).json({ message: 'Failed to update year plan' });
    }
  });

  // Delete year plan with double confirmation security
  apiRouter.delete('/year-plans/:id', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const confirmDelete = req.headers['x-confirm-delete'];
      
      if (!confirmDelete || confirmDelete !== 'true') {
        return res.status(400).json({ 
          message: 'Delete confirmation required',
          requiresConfirmation: true
        });
      }
      
      // Delete sessions and periods first
      await db.delete(yearPlanSessions).where(eq(yearPlanSessions.yearPlanId, planId));
      await db.delete(yearPlanPeriods).where(eq(yearPlanPeriods.yearPlanId, planId));
      
      // Delete the plan
      const [deletedPlan] = await db.delete(yearPlans)
        .where(eq(yearPlans.id, planId))
        .returning();
      
      if (!deletedPlan) {
        return res.status(404).json({ message: 'Year plan not found' });
      }
      
      res.json({ message: 'Year plan deleted successfully' });
    } catch (error) {
      console.error('Error deleting year plan:', error);
      res.status(500).json({ message: 'Failed to delete year plan' });
    }
  });

  // Year Plan Periods CRUD
  apiRouter.post('/year-plans/:id/periods', isAuthenticated, async (req, res) => {
    try {
      const yearPlanId = parseInt(req.params.id);
      const validatedData = insertYearPlanPeriodSchema.parse({
        ...req.body,
        yearPlanId
      });
      
      const [newPeriod] = await db.insert(yearPlanPeriods)
        .values(validatedData)
        .returning();
      
      res.status(201).json(newPeriod);
    } catch (error) {
      console.error('Error creating period:', error);
      res.status(500).json({ message: 'Failed to create period' });
    }
  });

  // Year Plan Sessions CRUD
  apiRouter.post('/year-plans/:id/sessions', isAuthenticated, async (req, res) => {
    try {
      const yearPlanId = parseInt(req.params.id);
      const validatedData = insertYearPlanSessionSchema.parse({
        ...req.body,
        yearPlanId
      });
      
      const [newSession] = await db.insert(yearPlanSessions)
        .values(validatedData)
        .returning();
      
      res.status(201).json(newSession);
    } catch (error) {
      console.error('Error creating session:', error);
      res.status(500).json({ message: 'Failed to create session' });
    }
  });

  // Export year plan to PDF
  apiRouter.get('/year-plans/:id/export/pdf', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      
      const [plan] = await db.select().from(yearPlans)
        .leftJoin(teams, eq(yearPlans.teamId, teams.id))
        .where(eq(yearPlans.id, planId));
      
      if (!plan) {
        return res.status(404).json({ message: 'Year plan not found' });
      }

      const periods = await db.select().from(yearPlanPeriods)
        .where(eq(yearPlanPeriods.yearPlanId, planId))
        .orderBy(yearPlanPeriods.sortOrder);

      const sessions = await db.select().from(yearPlanSessions)
        .where(eq(yearPlanSessions.yearPlanId, planId))
        .orderBy(yearPlanSessions.date);

      // Create PDF with jsPDF
      const { jsPDF } = require('jspdf');
      require('jspdf-autotable');
      
      const doc = new jsPDF();
      
      // Title
      doc.setFontSize(20);
      doc.text(plan.year_plans.name, 20, 20);
      
      // Plan details
      doc.setFontSize(12);
      doc.text(`Team: ${plan.teams?.name || 'Geen team'}`, 20, 35);
      doc.text(`Leeftijdsgroep: ${plan.year_plans.ageGroup || 'Niet gespecificeerd'}`, 20, 45);
      doc.text(`Periode: ${plan.year_plans.startDate} - ${plan.year_plans.endDate}`, 20, 55);
      doc.text(`Trainingsdagen: ${plan.year_plans.trainingDays?.join(', ') || 'Niet gespecificeerd'}`, 20, 65);
      
      // Periods table
      if (periods.length > 0) {
        doc.text('Periodes:', 20, 80);
        const periodData = periods.map(p => [
          p.name,
          p.startDate,
          p.endDate,
          p.focusThemes?.length || 0
        ]);
        
        doc.autoTable({
          head: [['Periode', 'Start', 'Eind', 'Thema\'s']],
          body: periodData,
          startY: 85
        });
      }
      
      // Sessions table
      if (sessions.length > 0) {
        const finalY = doc.lastAutoTable?.finalY || 100;
        doc.text('Trainingen:', 20, finalY + 15);
        
        const sessionData = sessions.map(s => [
          s.date,
          s.themes?.length || 0,
          s.duration || '',
          s.location || ''
        ]);
        
        doc.autoTable({
          head: [['Datum', 'Thema\'s', 'Duur', 'Locatie']],
          body: sessionData,
          startY: finalY + 20
        });
      }
      
      const pdfBuffer = doc.output('arraybuffer');
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${plan.year_plans.name}-jaarplanning.pdf"`);
      res.send(Buffer.from(pdfBuffer));
    } catch (error) {
      console.error('Error exporting to PDF:', error);
      res.status(500).json({ message: 'Failed to export to PDF' });
    }
  });

  // Export year plan to CSV
  apiRouter.get('/year-plans/:id/export/csv', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      
      const sessions = await db.select().from(yearPlanSessions)
        .where(eq(yearPlanSessions.yearPlanId, planId))
        .orderBy(yearPlanSessions.date);

      const csvData = sessions.map(session => ({
        datum: session.date,
        themas: session.themes?.join('; ') || '',
        notities: session.notes || '',
        duur: session.duration || '',
        locatie: session.location || ''
      }));

      const createCsvWriter = require('csv-writer').createObjectCsvWriter;
      const csvWriter = createCsvWriter({
        header: [
          { id: 'datum', title: 'Datum' },
          { id: 'themas', title: 'Thema\'s' },
          { id: 'notities', title: 'Notities' },
          { id: 'duur', title: 'Duur (min)' },
          { id: 'locatie', title: 'Locatie' }
        ]
      });

      const csvString = await csvWriter.stringifyRecords(csvData);
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="jaarplanning.csv"');
      res.send(csvString);
    } catch (error) {
      console.error('Error exporting to CSV:', error);
      res.status(500).json({ message: 'Failed to export to CSV' });
    }
  });

  // Export year plan to ICS calendar format
  apiRouter.get('/year-plans/:id/export/ics', isAuthenticated, async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      
      const [plan] = await db.select().from(yearPlans)
        .where(eq(yearPlans.id, planId));
      
      if (!plan) {
        return res.status(404).json({ message: 'Year plan not found' });
      }

      const sessions = await db.select().from(yearPlanSessions)
        .where(eq(yearPlanSessions.yearPlanId, planId))
        .orderBy(yearPlanSessions.date);

      // Create ICS content
      let icsContent = 'BEGIN:VCALENDAR\r\n';
      icsContent += 'VERSION:2.0\r\n';
      icsContent += 'PRODID:-//Soccer Club//Year Planning//NL\r\n';
      icsContent += 'CALSCALE:GREGORIAN\r\n';
      icsContent += `X-WR-CALNAME:${plan.name}\r\n`;
      icsContent += `X-WR-CALDESC:Jaarplanning voor ${plan.name}\r\n`;

      sessions.forEach((session, index) => {
        const date = new Date(session.date);
        const dateStr = date.toISOString().replace(/[-:]/g, '').split('T')[0];
        const uid = `session-${session.id}-${Date.now()}@soccerclub.com`;
        
        icsContent += 'BEGIN:VEVENT\r\n';
        icsContent += `UID:${uid}\r\n`;
        icsContent += `DTSTART;VALUE=DATE:${dateStr}\r\n`;
        icsContent += `DTEND;VALUE=DATE:${dateStr}\r\n`;
        icsContent += `SUMMARY:Training - ${session.themes?.join(', ') || 'Geen thema\'s'}\r\n`;
        icsContent += `DESCRIPTION:${session.notes || 'Geen notities'}\r\n`;
        if (session.location) {
          icsContent += `LOCATION:${session.location}\r\n`;
        }
        icsContent += `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0]}Z\r\n`;
        icsContent += 'END:VEVENT\r\n';
      });

      icsContent += 'END:VCALENDAR\r\n';
      
      res.setHeader('Content-Type', 'text/calendar');
      res.setHeader('Content-Disposition', `attachment; filename="${plan.name}-kalender.ics"`);
      res.send(icsContent);
    } catch (error) {
      console.error('Error exporting to ICS:', error);
      res.status(500).json({ message: 'Failed to export to ICS' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
