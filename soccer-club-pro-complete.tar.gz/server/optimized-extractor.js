import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

class OptimizedVideoExtractor {
  constructor() {
    this.videoPath = 'uploads/match-videos/match-video-1750870860329-999699725.mp4';
    this.outputDir = 'uploads/extracted-frames/match-video-1750870860329-999699725';
    this.targetFrames = 3180;
    this.segmentDuration = 900; // 15 minuten per segment
  }

  async extractInSegments() {
    // Maak output directory aan
    if (!fs.existsSync(this.outputDir)) {
      fs.mkdirSync(this.outputDir, { recursive: true });
    }

    console.log('Starting optimized segment extraction for Svelta Melsele vs VVC');
    
    // Extract in 7 segmenten van 15 minuten elk
    const segments = [
      { start: '00:09:00', duration: '00:15:00', startFrame: 1 },
      { start: '00:24:00', duration: '00:15:00', startFrame: 451 },
      { start: '00:39:00', duration: '00:15:00', startFrame: 901 },
      { start: '00:54:00', duration: '00:15:00', startFrame: 1351 },
      { start: '01:09:00', duration: '00:15:00', startFrame: 1801 },
      { start: '01:24:00', duration: '00:15:00', startFrame: 2251 },
      { start: '01:39:00', duration: '00:16:00', startFrame: 2701 }
    ];

    for (const segment of segments) {
      console.log(`Extracting segment: ${segment.start} for ${segment.duration}`);
      await this.extractSegment(segment);
      
      // Check huidige progress
      const currentFrames = this.getCurrentFrameCount();
      const percentage = ((currentFrames / this.targetFrames) * 100).toFixed(1);
      console.log(`Progress: ${currentFrames}/${this.targetFrames} frames (${percentage}%)`);
    }

    const finalFrames = this.getCurrentFrameCount();
    console.log(`Extraction completed: ${finalFrames} total frames`);
    return finalFrames;
  }

  async extractSegment(segment) {
    return new Promise((resolve, reject) => {
      const args = [
        '-y',
        '-i', this.videoPath,
        '-ss', segment.start,
        '-t', segment.duration,
        '-vf', 'fps=0.5',
        '-q:v', '2',
        '-start_number', segment.startFrame.toString(),
        path.join(this.outputDir, 'frame_%04d.jpg')
      ];

      const ffmpeg = spawn('ffmpeg', args);

      ffmpeg.on('close', (code) => {
        if (code === 0) {
          resolve();
        } else {
          reject(new Error(`Segment extraction failed with code ${code}`));
        }
      });

      ffmpeg.on('error', reject);
    });
  }

  getCurrentFrameCount() {
    try {
      if (!fs.existsSync(this.outputDir)) return 0;
      
      const files = fs.readdirSync(this.outputDir)
        .filter(file => file.startsWith('frame_') && file.endsWith('.jpg'));
      return files.length;
    } catch (error) {
      console.error('Error counting frames:', error);
      return 0;
    }
  }
}

// Start extractie direct
const extractor = new OptimizedVideoExtractor();
extractor.extractInSegments()
  .then(frameCount => {
    console.log(`SUCCESS: ${frameCount} frames extracted for complete match analysis`);
    process.exit(0);
  })
  .catch(error => {
    console.error('Extraction failed:', error.message);
    process.exit(1);
  });