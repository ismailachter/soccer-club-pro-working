import nodemailer from 'nodemailer';
import { google } from 'googleapis';

export interface EmailData {
  to: string;
  from: string;
  subject: string;
  text: string;
  html: string;
}

/**
 * Send an email using Gmail API with OAuth2
 * @param emailData Email data including to, from, subject, text, and html
 * @returns Promise resolving to true if email was sent successfully, false otherwise
 */
export const sendEmail = async (emailData: EmailData): Promise<boolean> => {
  try {
    // Configure OAuth2 client
    const oauth2Client = new google.auth.OAuth2(
      process.env.GMAIL_CLIENT_ID,
      process.env.GMAIL_CLIENT_SECRET,
      'https://developers.google.com/oauthplayground'
    );

    oauth2Client.setCredentials({
      refresh_token: process.env.GMAIL_REFRESH_TOKEN
    });

    // Get access token
    const accessToken = await oauth2Client.getAccessToken();
    
    if (!accessToken.token) {
      throw new Error('Failed to get access token from OAuth2');
    }

    // Create Nodemailer transporter using OAuth2
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        type: 'OAuth2',
        user: process.env.GMAIL_USER,
        clientId: process.env.GMAIL_CLIENT_ID,
        clientSecret: process.env.GMAIL_CLIENT_SECRET,
        refreshToken: process.env.GMAIL_REFRESH_TOKEN,
        accessToken: accessToken.token
      }
    });

    // Use from address from environment, explicit from, or default to Gmail account
    const fromAddress = process.env.EMAIL_FROM || emailData.from || `Soccer Club Pro <${process.env.GMAIL_USER}>`;

    console.log(`Attempting to send email to ${emailData.to} using Gmail OAuth2`);
    
    // Send the email
    const info = await transporter.sendMail({
      from: fromAddress,
      to: emailData.to,
      subject: emailData.subject,
      text: emailData.text,
      html: emailData.html,
    });

    console.log(`Email sent successfully to ${emailData.to} [Message ID: ${info.messageId}]`);
    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
};

/**
 * Send an invitation email to a new user
 * @param email Recipient's email
 * @param role User's role
 * @param tempPassword Temporary password
 * @param firstName User's first name
 * @param lastName User's last name
 * @returns Promise resolving to true if email was sent successfully, false otherwise
 */
export const sendInvitationEmail = async (
  email: string,
  role: string,
  tempPassword: string,
  firstName: string,
  lastName: string
): Promise<boolean> => {
  const appName = 'Soccer Club Pro';
  const baseUrl = process.env.BASE_URL || 'https://soccerclub.com';
  
  const subject = `You've been invited to join ${appName}`;
  
  const text = `
Hello ${firstName} ${lastName},

You have been invited to join ${appName} as a ${role}.

To get started, please login with these credentials:
Email: ${email}
Temporary Password: ${tempPassword}

Please change your password after your first login.

Login here: ${baseUrl}/auth

Best regards,
The ${appName} Team
  `;
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4a90e2; color: white; padding: 10px 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    .button { background-color: #4a90e2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0; display: inline-block; }
    .credentials { background-color: #eee; padding: 10px; border-radius: 5px; margin: 15px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${appName}</h1>
    </div>
    <div class="content">
      <p>Hello ${firstName} ${lastName},</p>
      <p>You have been invited to join <strong>${appName}</strong> as a <strong>${role}</strong>.</p>
      <p>To get started, please login with these credentials:</p>
      <div class="credentials">
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Temporary Password:</strong> ${tempPassword}</p>
      </div>
      <p>Please change your password after your first login.</p>
      <div style="text-align: center;">
        <a href="${baseUrl}/auth" class="button">Login to ${appName}</a>
      </div>
    </div>
    <div class="footer">
      <p>This email was sent from ${appName}, a comprehensive soccer club management system.</p>
    </div>
  </div>
</body>
</html>
  `;
  
  const emailData: EmailData = {
    to: email,
    from: process.env.EMAIL_FROM || 'noreply@soccerclub.com',
    subject,
    text,
    html
  };
  
  return sendEmail(emailData);
};

/**
 * Overloaded version of sendInvitationEmail that works with activation tokens
 * This is used by the auth.ts file when importing the function dynamically
 */
export const sendInvitationEmail2 = async (
  email: string,
  role: string,
  firstName: string,
  lastName: string,
  invitationToken: string,
  expiryDate: Date
): Promise<boolean> => {
  const appName = 'Soccer Club Pro';
  const baseUrl = process.env.BASE_URL || 'https://soccerclub.com';
  const inviteLink = `${baseUrl}/auth/activate?token=${invitationToken}`;
  const expiryDateFormatted = expiryDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const subject = `Invitation to join ${appName} as a ${role}`;
  
  const text = `
Hello ${firstName} ${lastName},

You have been invited to join ${appName} as a ${role}.

Please click the link below to activate your account:
${inviteLink}

This invitation will expire on ${expiryDateFormatted}.

Best regards,
${appName} Team
  `;
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4a90e2; color: white; padding: 10px 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    .button { background-color: #4a90e2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0; display: inline-block; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${appName}</h1>
    </div>
    <div class="content">
      <p>Hello ${firstName} ${lastName},</p>
      <p>You have been invited to join <strong>${appName}</strong> as a <strong>${role}</strong>.</p>
      <p>Please click the button below to activate your account:</p>
      <div style="text-align: center;">
        <a href="${inviteLink}" class="button">Activate Account</a>
      </div>
      <p>Or copy and paste this link in your browser:</p>
      <p style="word-break: break-all; color: #4a90e2;">${inviteLink}</p>
      <p><em>This invitation will expire on ${expiryDateFormatted}.</em></p>
    </div>
    <div class="footer">
      <p>This email was sent from ${appName}, a comprehensive soccer club management system.</p>
      <p>If you received this email by mistake, please ignore it.</p>
    </div>
  </div>
</body>
</html>
  `;
  
  const emailData: EmailData = {
    to: email,
    from: process.env.EMAIL_FROM || 'noreply@soccerclub.com',
    subject,
    text,
    html
  };
  
  return sendEmail(emailData);
};

/**
 * Send a password reset email
 * @param email Recipient's email
 * @param resetToken Password reset token
 * @param firstName User's first name
 * @returns Promise resolving to true if email was sent successfully, false otherwise
 */
export const sendPasswordResetEmail = async (
  email: string,
  resetToken: string,
  firstName: string
): Promise<boolean> => {
  const appName = 'Soccer Club Pro';
  const baseUrl = process.env.BASE_URL || 'https://soccerclub.com';
  const resetUrl = `${baseUrl}/auth/reset-password?token=${resetToken}`;
  
  const subject = `${appName} - Password Reset`;
  
  const text = `
Hello ${firstName},

You have requested to reset your password for ${appName}.

Please click the following link to reset your password:
${resetUrl}

This link will expire in 1 hour.

If you did not request a password reset, please ignore this email.

Best regards,
The ${appName} Team
  `;
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4a90e2; color: white; padding: 10px 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    .button { background-color: #4a90e2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0; display: inline-block; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${appName}</h1>
    </div>
    <div class="content">
      <p>Hello ${firstName},</p>
      <p>You have requested to reset your password for <strong>${appName}</strong>.</p>
      <p>Please click the button below to reset your password:</p>
      <div style="text-align: center;">
        <a href="${resetUrl}" class="button">Reset Password</a>
      </div>
      <p>This link will expire in 1 hour.</p>
      <p>If you did not request a password reset, please ignore this email.</p>
    </div>
    <div class="footer">
      <p>This email was sent from ${appName}, a comprehensive soccer club management system.</p>
    </div>
  </div>
</body>
</html>
  `;
  
  const emailData: EmailData = {
    to: email,
    from: process.env.EMAIL_FROM || 'noreply@soccerclub.com',
    subject,
    text,
    html
  };
  
  return sendEmail(emailData);
};