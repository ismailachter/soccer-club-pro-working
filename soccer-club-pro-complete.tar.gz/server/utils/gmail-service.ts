import { google } from 'googleapis';

// Gmail OAuth2 Configuration
const oauth2Client = new google.auth.OAuth2(
  process.env.GMAIL_CLIENT_ID,
  process.env.GMAIL_CLIENT_SECRET,
  'https://developers.google.com/oauthplayground'
);

oauth2Client.setCredentials({
  refresh_token: process.env.GMAIL_REFRESH_TOKEN
});

const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendGmailEmail(options: EmailOptions): Promise<boolean> {
  try {
    const { to, subject, html, text } = options;
    
    // Create email message
    const email = [
      `To: ${to}`,
      `Subject: ${subject}`,
      'Content-Type: text/html; charset=utf-8',
      '',
      html || text || ''
    ].join('\n');

    // Encode email in base64
    const encodedEmail = Buffer.from(email).toString('base64').replace(/\+/g, '-').replace(/\//g, '_');

    // Send email
    const result = await gmail.users.messages.send({
      userId: 'me',
      requestBody: {
        raw: encodedEmail
      }
    });

    console.log('Gmail email sent successfully:', result.data.id);
    return true;
  } catch (error) {
    console.error('Error sending Gmail email:', error);
    return false;
  }
}

export async function sendWelcomeEmailGmail(data: {
  to: string;
  playerName: string;
  clubName: string;
  teamName: string;
  username: string;
  temporaryPassword: string;
}): Promise<boolean> {
  const { to, playerName, clubName, teamName, username, temporaryPassword } = data;

  const subject = `Welcome to ${clubName} - ${teamName}!`;
  
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .welcome-box { background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; margin: 20px 0; }
        .credentials { background: #e8f2ff; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
        .button { display: inline-block; background: #667eea; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 10px 0; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🏆 Welcome to ${clubName}!</h1>
          <p>You've been added to ${teamName}</p>
        </div>
        
        <div class="content">
          <div class="welcome-box">
            <h2>Hello ${playerName}! 👋</h2>
            <p>We're excited to have you join <strong>${teamName}</strong> at <strong>${clubName}</strong>!</p>
            <p>Your player account has been created and you now have access to our club management system.</p>
          </div>

          <div class="credentials">
            <h3>🔐 Your Login Details:</h3>
            <p><strong>Username:</strong> ${username}</p>
            <p><strong>Temporary Password:</strong> ${temporaryPassword}</p>
            <p><em>Please change your password after your first login for security.</em></p>
          </div>

          <p>With your account, you can:</p>
          <ul>
            <li>✅ View your team roster and schedule</li>
            <li>✅ Access training materials and programs</li>
            <li>✅ Stay updated with club announcements</li>
            <li>✅ Track your performance and progress</li>
          </ul>

          <div class="footer">
            <p>This email was sent by ${clubName} Soccer Club Management System</p>
            <p>If you have any questions, please contact your team coordinator.</p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  const text = `
    Welcome to ${clubName} - ${teamName}!
    
    Hello ${playerName}!
    
    We're excited to have you join ${teamName} at ${clubName}!
    Your player account has been created.
    
    Login Details:
    Username: ${username}
    Temporary Password: ${temporaryPassword}
    
    Please change your password after your first login.
    
    Welcome to the team!
    ${clubName}
  `;

  return await sendGmailEmail({ to, subject, html, text });
}