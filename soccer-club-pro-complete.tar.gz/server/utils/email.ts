import { google } from 'googleapis';
import nodemailer from 'nodemailer';

// Gmail OAuth2 configuration
const oAuth2Client = new google.auth.OAuth2(
  process.env.GMAIL_CLIENT_ID,
  process.env.GMAIL_CLIENT_SECRET,
  'https://developers.google.com/oauthplayground'
);

oAuth2Client.setCredentials({
  refresh_token: process.env.GMAIL_REFRESH_TOKEN,
});

/**
 * Sends an email using Gmail OAuth2
 * @param to Recipient email address
 * @param subject Email subject
 * @param text Plain text content
 * @param html HTML content
 * @returns Promise<boolean> - true if email sent successfully
 */
export async function sendEmail(
  to: string,
  subject: string,
  text: string,
  html: string
): Promise<boolean> {
  try {
    // Get a new access token
    const accessToken = await oAuth2Client.getAccessToken();

    // Create a nodemailer transporter with OAuth2
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        type: 'OAuth2',
        user: process.env.GMAIL_USER,
        clientId: process.env.GMAIL_CLIENT_ID,
        clientSecret: process.env.GMAIL_CLIENT_SECRET,
        refreshToken: process.env.GMAIL_REFRESH_TOKEN,
        accessToken: accessToken?.token || '',
      },
    });

    // Send email
    const info = await transporter.sendMail({
      from: `Soccer Club Pro <${process.env.GMAIL_USER}>`,
      to,
      subject,
      text,
      html,
    });

    console.log('Email sent successfully:', info.messageId);
    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
}

/**
 * Sends a user invitation email
 */
export async function sendInvitationEmail(
  email: string,
  role: string,
  firstName: string,
  lastName: string,
  invitationToken: string,
  expiryDate: Date
): Promise<boolean> {
  const inviteLink = `${process.env.APP_URL || 'http://localhost:5000'}/auth/activate?token=${invitationToken}`;
  const expiryDateFormatted = expiryDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const subject = `Invitation to join Soccer Club Pro as a ${role}`;
  
  const text = `
    Hello ${firstName} ${lastName},
    
    You have been invited to join Soccer Club Pro as a ${role}. 
    
    Please click the link below to activate your account:
    ${inviteLink}
    
    This invitation will expire on ${expiryDateFormatted}.
    
    Best regards,
    Soccer Club Pro Team
  `;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #4f46e5; color: white; padding: 20px; text-align: center;">
        <h1 style="margin: 0;">Soccer Club Pro</h1>
      </div>
      <div style="padding: 20px; border: 1px solid #e0e0e0; border-top: none;">
        <p>Hello ${firstName} ${lastName},</p>
        
        <p>You have been invited to join <strong>Soccer Club Pro</strong> as a <strong>${role}</strong>.</p>
        
        <p>Please click the button below to activate your account:</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${inviteLink}" style="background-color: #4f46e5; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Activate Account</a>
        </div>
        
        <p>Or copy and paste this link in your browser:</p>
        <p style="word-break: break-all; color: #4f46e5;">${inviteLink}</p>
        
        <p><em>This invitation will expire on ${expiryDateFormatted}.</em></p>
        
        <p>Best regards,<br>Soccer Club Pro Team</p>
      </div>
      <div style="background-color: #f3f4f6; padding: 15px; text-align: center; font-size: 12px; color: #6b7280;">
        <p>If you received this email by mistake, please ignore it.</p>
      </div>
    </div>
  `;
  
  return sendEmail(email, subject, text, html);
}

/**
 * Sends a password reset email
 */
export async function sendPasswordResetEmail(
  email: string,
  firstName: string,
  lastName: string,
  resetToken: string,
  expiryDate: Date
): Promise<boolean> {
  const resetLink = `${process.env.APP_URL || 'http://localhost:5000'}/auth/reset-password?token=${resetToken}`;
  const expiryDateFormatted = expiryDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const subject = `Reset your Soccer Club Pro password`;
  
  const text = `
    Hello ${firstName} ${lastName},
    
    We received a request to reset your password for your Soccer Club Pro account.
    
    Please click the link below to reset your password:
    ${resetLink}
    
    This link will expire on ${expiryDateFormatted}.
    
    If you did not request a password reset, please ignore this email or contact support.
    
    Best regards,
    Soccer Club Pro Team
  `;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #4f46e5; color: white; padding: 20px; text-align: center;">
        <h1 style="margin: 0;">Soccer Club Pro</h1>
      </div>
      <div style="padding: 20px; border: 1px solid #e0e0e0; border-top: none;">
        <p>Hello ${firstName} ${lastName},</p>
        
        <p>We received a request to reset your password for your <strong>Soccer Club Pro</strong> account.</p>
        
        <p>Please click the button below to reset your password:</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetLink}" style="background-color: #4f46e5; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset Password</a>
        </div>
        
        <p>Or copy and paste this link in your browser:</p>
        <p style="word-break: break-all; color: #4f46e5;">${resetLink}</p>
        
        <p><em>This link will expire on ${expiryDateFormatted}.</em></p>
        
        <p>If you did not request a password reset, please ignore this email or contact support.</p>
        
        <p>Best regards,<br>Soccer Club Pro Team</p>
      </div>
      <div style="background-color: #f3f4f6; padding: 15px; text-align: center; font-size: 12px; color: #6b7280;">
        <p>If you have any questions, please contact our support team.</p>
      </div>
    </div>
  `;
  
  return sendEmail(email, subject, text, html);
}

/**
 * Sends a notification email about a new assignment
 */
export async function sendTeamAssignmentEmail(
  email: string,
  firstName: string,
  lastName: string,
  teamName: string,
  role: string
): Promise<boolean> {
  const loginLink = `${process.env.APP_URL || 'http://localhost:5000'}/auth`;
  
  const subject = `You've been assigned to ${teamName} as a ${role}`;
  
  const text = `
    Hello ${firstName} ${lastName},
    
    You have been assigned to the team "${teamName}" as a ${role}.
    
    Please log in to your Soccer Club Pro account to view more details.
    ${loginLink}
    
    Best regards,
    Soccer Club Pro Team
  `;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #4f46e5; color: white; padding: 20px; text-align: center;">
        <h1 style="margin: 0;">Soccer Club Pro</h1>
      </div>
      <div style="padding: 20px; border: 1px solid #e0e0e0; border-top: none;">
        <p>Hello ${firstName} ${lastName},</p>
        
        <p>You have been assigned to the team <strong>"${teamName}"</strong> as a <strong>${role}</strong>.</p>
        
        <p>Please log in to your Soccer Club Pro account to view more details:</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${loginLink}" style="background-color: #4f46e5; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Log In to Your Account</a>
        </div>
        
        <p>Best regards,<br>Soccer Club Pro Team</p>
      </div>
      <div style="background-color: #f3f4f6; padding: 15px; text-align: center; font-size: 12px; color: #6b7280;">
        <p>If you have any questions, please contact your team administrator.</p>
      </div>
    </div>
  `;
  
  return sendEmail(email, subject, text, html);
}

/**
 * Sends a payment reminder email
 */
export async function sendPaymentReminderEmail(
  email: string,
  firstName: string,
  lastName: string,
  amount: number,
  dueDate: Date,
  feeDescription: string
): Promise<boolean> {
  const paymentLink = `${process.env.APP_URL || 'http://localhost:5000'}/payments`;
  const dueDateFormatted = dueDate.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const formattedAmount = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
  
  const subject = `Payment Reminder: ${feeDescription} due on ${dueDateFormatted}`;
  
  const text = `
    Hello ${firstName} ${lastName},
    
    This is a friendly reminder that your payment of ${formattedAmount} for "${feeDescription}" is due on ${dueDateFormatted}.
    
    Please log in to your Soccer Club Pro account to view and manage your payments.
    ${paymentLink}
    
    Best regards,
    Soccer Club Pro Team
  `;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #4f46e5; color: white; padding: 20px; text-align: center;">
        <h1 style="margin: 0;">Soccer Club Pro</h1>
      </div>
      <div style="padding: 20px; border: 1px solid #e0e0e0; border-top: none;">
        <p>Hello ${firstName} ${lastName},</p>
        
        <p>This is a friendly reminder that your payment of <strong>${formattedAmount}</strong> for "<strong>${feeDescription}</strong>" is due on <strong>${dueDateFormatted}</strong>.</p>
        
        <div style="background-color: #f9fafb; border-left: 4px solid #4f46e5; padding: 15px; margin: 20px 0;">
          <p style="margin: 0; font-weight: bold;">Payment Details:</p>
          <p style="margin: 10px 0 0 0;">Amount: ${formattedAmount}</p>
          <p style="margin: 5px 0 0 0;">Description: ${feeDescription}</p>
          <p style="margin: 5px 0 0 0;">Due Date: ${dueDateFormatted}</p>
        </div>
        
        <p>Please log in to your Soccer Club Pro account to view and manage your payments:</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${paymentLink}" style="background-color: #4f46e5; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">View Payment Details</a>
        </div>
        
        <p>If you have already made this payment, please disregard this reminder.</p>
        
        <p>Best regards,<br>Soccer Club Pro Team</p>
      </div>
      <div style="background-color: #f3f4f6; padding: 15px; text-align: center; font-size: 12px; color: #6b7280;">
        <p>If you have any questions about this payment, please contact our finance department.</p>
      </div>
    </div>
  `;
  
  return sendEmail(email, subject, text, html);
}