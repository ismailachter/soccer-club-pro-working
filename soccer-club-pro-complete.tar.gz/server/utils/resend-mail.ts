import { Resend } from 'resend';

// Initialize Resend with API key
const resend = new Resend(process.env.RESEND_API_KEY);

export interface EmailData {
  to: string;
  from: string;
  subject: string;
  text: string;
  html: string;
}

/**
 * Send an email using Resend
 * @param emailData Email data including to, from, subject, text, and html
 * @returns Promise resolving to true if email was sent successfully, false otherwise
 */
export const sendEmail = async (emailData: EmailData): Promise<boolean> => {
  try {
    // Default sender email if not provided
    const fromAddress = emailData.from || 'Soccer Club Pro <onboarding@resend.dev>';
    
    console.log(`Attempting to send email to ${emailData.to} using Resend`);
    
    // Send the email using Resend
    const { data, error } = await resend.emails.send({
      from: fromAddress,
      to: emailData.to,
      subject: emailData.subject,
      text: emailData.text,
      html: emailData.html,
    });
    
    if (error) {
      console.error('Error sending email with Resend:', error);
      return false;
    }
    
    console.log(`Email sent successfully to ${emailData.to} [ID: ${data?.id}]`);
    return true;
  } catch (error) {
    console.error('Error sending email with Resend:', error);
    return false;
  }
};

/**
 * Send a welcome email to a new player
 * @param options Welcome email options
 */
export const sendWelcomeEmail = async (options: {
  to: string;
  playerName: string;
  clubName: string;
  teamName: string;
  username: string;
  temporaryPassword: string;
}): Promise<boolean> => {
  const { to, playerName, clubName, teamName, username, temporaryPassword } = options;
  
  const subject = `Welcome to ${clubName}! 🏆`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff;">
      <div style="background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); color: white; padding: 30px; text-align: center;">
        <h1 style="margin: 0; font-size: 28px;">Welcome to ${clubName}!</h1>
        <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;">Your soccer journey starts here</p>
      </div>
      
      <div style="padding: 30px;">
        <h2 style="color: #1e40af; margin-bottom: 20px;">Hello ${playerName}! 👋</h2>
        
        <p style="font-size: 16px; line-height: 1.6; color: #374151; margin-bottom: 20px;">
          We're excited to welcome you to our soccer family! You've been successfully registered and assigned to <strong>${teamName}</strong>.
        </p>
        
        <div style="background: #f8fafc; border-left: 4px solid #3b82f6; padding: 20px; margin: 20px 0;">
          <h3 style="color: #1e40af; margin: 0 0 15px 0;">Your Login Details</h3>
          <p style="margin: 5px 0; color: #374151;"><strong>Username:</strong> ${username}</p>
          <p style="margin: 5px 0; color: #374151;"><strong>Temporary Password:</strong> ${temporaryPassword}</p>
          <p style="margin: 15px 0 0 0; font-size: 14px; color: #6b7280;">
            Please change your password after your first login for security.
          </p>
        </div>
        
        <div style="background: #ecfdf5; border: 1px solid #d1fae5; border-radius: 8px; padding: 20px; margin: 20px 0;">
          <h3 style="color: #059669; margin: 0 0 15px 0;">What's Next?</h3>
          <ul style="color: #374151; margin: 0; padding-left: 20px;">
            <li style="margin-bottom: 8px;">Log in to your player dashboard</li>
            <li style="margin-bottom: 8px;">View your team schedule and training sessions</li>
            <li style="margin-bottom: 8px;">Check upcoming matches and events</li>
            <li style="margin-bottom: 8px;">Update your profile information</li>
          </ul>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <p style="color: #374151; margin-bottom: 20px;">Ready to get started?</p>
          <a href="#" style="background: #3b82f6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block;">
            Access Your Dashboard
          </a>
        </div>
        
        <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; margin-top: 30px;">
          <p style="color: #6b7280; font-size: 14px; margin: 0;">
            If you have any questions, feel free to contact your coach or team coordinator.
          </p>
          <p style="color: #6b7280; font-size: 14px; margin: 10px 0 0 0;">
            Welcome to the team! 🎯
          </p>
        </div>
      </div>
    </div>
  `;
  
  const text = `
Welcome to ${clubName}, ${playerName}!

You've been successfully registered and assigned to ${teamName}.

Your Login Details:
Username: ${username}
Temporary Password: ${temporaryPassword}

Please change your password after your first login for security.

What's Next?
- Log in to your player dashboard
- View your team schedule and training sessions
- Check upcoming matches and events  
- Update your profile information

Welcome to the team!
  `;
  
  return await sendEmail({
    to,
    from: `${clubName} <onboarding@resend.dev>`,
    subject,
    text,
    html
  });
};

/**
 * Send an invitation email to a new user
 * @param email Recipient's email
 * @param role User's role
 * @param tempPassword Temporary password
 * @param firstName User's first name
 * @param lastName User's last name
 * @returns Promise resolving to true if email was sent successfully, false otherwise
 */
export const sendInvitationEmail = async (
  email: string,
  role: string,
  tempPassword: string,
  firstName: string,
  lastName: string
): Promise<boolean> => {
  const appName = 'Soccer Club Pro';
  const baseUrl = process.env.BASE_URL || 'https://88037f5d-cc3e-4e7e-bf09-ef96b5a50fca-00-apd6h07vapwx.picard.replit.dev';
  
  const subject = `You've been invited to join ${appName}`;
  
  const text = `
Hello ${firstName} ${lastName},

You have been invited to join ${appName} as a ${role}.

To get started, please login with these credentials:
Email: ${email}
Temporary Password: ${tempPassword}

Please change your password after your first login.

Login here: ${baseUrl}/auth

Best regards,
The ${appName} Team
  `;
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4a90e2; color: white; padding: 10px 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    .button { background-color: #4a90e2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0; display: inline-block; }
    .credentials { background-color: #eee; padding: 10px; border-radius: 5px; margin: 15px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${appName}</h1>
    </div>
    <div class="content">
      <p>Hello ${firstName} ${lastName},</p>
      <p>You have been invited to join <strong>${appName}</strong> as a <strong>${role}</strong>.</p>
      <p>To get started, please login with these credentials:</p>
      <div class="credentials">
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Temporary Password:</strong> ${tempPassword}</p>
      </div>
      <p>Please change your password after your first login.</p>
      <div style="text-align: center;">
        <a href="${baseUrl}/auth" class="button">Login to ${appName}</a>
      </div>
    </div>
    <div class="footer">
      <p>This email was sent from ${appName}, a comprehensive soccer club management system.</p>
    </div>
  </div>
</body>
</html>
  `;
  
  const emailData: EmailData = {
    to: email,
    from: process.env.EMAIL_FROM || 'onboarding@resend.dev',
    subject,
    text,
    html
  };
  
  return sendEmail(emailData);
};

/**
 * Overloaded version of sendInvitationEmail that works with activation tokens
 * This is used by the auth.ts file when importing the function dynamically
 */
export const sendInvitationEmail2 = async (
  email: string,
  role: string,
  firstName: string,
  lastName: string,
  invitationToken: string,
  expiryDate: Date
): Promise<boolean> => {
  const appName = 'Soccer Club Pro';
  const baseUrl = process.env.BASE_URL || 'https://88037f5d-cc3e-4e7e-bf09-ef96b5a50fca-00-apd6h07vapwx.picard.replit.dev';
  const inviteLink = `${baseUrl}/auth/activate?token=${invitationToken}`;
  const expiryDateFormatted = expiryDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const subject = `Invitation to join ${appName} as a ${role}`;
  
  const text = `
Hello ${firstName} ${lastName},

You have been invited to join ${appName} as a ${role}.

Please click the link below to activate your account:
${inviteLink}

This invitation will expire on ${expiryDateFormatted}.

Best regards,
${appName} Team
  `;
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4a90e2; color: white; padding: 10px 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    .button { background-color: #4a90e2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0; display: inline-block; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${appName}</h1>
    </div>
    <div class="content">
      <p>Hello ${firstName} ${lastName},</p>
      <p>You have been invited to join <strong>${appName}</strong> as a <strong>${role}</strong>.</p>
      <p>Please click the button below to activate your account:</p>
      <div style="text-align: center;">
        <a href="${inviteLink}" class="button">Activate Account</a>
      </div>
      <p>Or copy and paste this link in your browser:</p>
      <p style="word-break: break-all; color: #4a90e2;">${inviteLink}</p>
      <p><em>This invitation will expire on ${expiryDateFormatted}.</em></p>
    </div>
    <div class="footer">
      <p>This email was sent from ${appName}, a comprehensive soccer club management system.</p>
      <p>If you received this email by mistake, please ignore it.</p>
    </div>
  </div>
</body>
</html>
  `;
  
  const emailData: EmailData = {
    to: email,
    from: process.env.EMAIL_FROM || 'onboarding@resend.dev',
    subject,
    text,
    html
  };
  
  return sendEmail(emailData);
};

/**
 * Send a password reset email
 * @param email Recipient's email
 * @param resetToken Password reset token
 * @param firstName User's first name
 * @returns Promise resolving to true if email was sent successfully, false otherwise
 */
export const sendPasswordResetEmail = async (
  email: string,
  resetToken: string,
  firstName: string
): Promise<boolean> => {
  const appName = 'Soccer Club Pro';
  const baseUrl = process.env.BASE_URL || 'https://88037f5d-cc3e-4e7e-bf09-ef96b5a50fca-00-apd6h07vapwx.picard.replit.dev';
  const resetUrl = `${baseUrl}/auth/reset-password?token=${resetToken}`;
  
  const subject = `${appName} - Password Reset`;
  
  const text = `
Hello ${firstName},

You have requested to reset your password for ${appName}.

Please click the following link to reset your password:
${resetUrl}

This link will expire in 1 hour.

If you did not request a password reset, please ignore this email.

Best regards,
The ${appName} Team
  `;
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4a90e2; color: white; padding: 10px 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    .button { background-color: #4a90e2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0; display: inline-block; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${appName}</h1>
    </div>
    <div class="content">
      <p>Hello ${firstName},</p>
      <p>You have requested to reset your password for <strong>${appName}</strong>.</p>
      <p>Please click the button below to reset your password:</p>
      <div style="text-align: center;">
        <a href="${resetUrl}" class="button">Reset Password</a>
      </div>
      <p>This link will expire in 1 hour.</p>
      <p>If you did not request a password reset, please ignore this email.</p>
    </div>
    <div class="footer">
      <p>This email was sent from ${appName}, a comprehensive soccer club management system.</p>
    </div>
  </div>
</body>
</html>
  `;
  
  const emailData: EmailData = {
    to: email,
    from: process.env.EMAIL_FROM || 'onboarding@resend.dev',
    subject,
    text,
    html
  };
  
  return sendEmail(emailData);
};

/**
 * Send a notification email about a new team assignment
 */
export const sendTeamAssignmentEmail = async (
  email: string,
  firstName: string,
  lastName: string,
  teamName: string,
  role: string
): Promise<boolean> => {
  const appName = 'Soccer Club Pro';
  const loginLink = `${process.env.BASE_URL || 'https://88037f5d-cc3e-4e7e-bf09-ef96b5a50fca-00-apd6h07vapwx.picard.replit.dev'}/auth`;
  
  const subject = `You've been assigned to ${teamName} as a ${role}`;
  
  const text = `
Hello ${firstName} ${lastName},

You have been assigned to the team "${teamName}" as a ${role}.

Please log in to your ${appName} account to view more details:
${loginLink}

Best regards,
The ${appName} Team
  `;
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4a90e2; color: white; padding: 10px 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    .button { background-color: #4a90e2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0; display: inline-block; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${appName}</h1>
    </div>
    <div class="content">
      <p>Hello ${firstName} ${lastName},</p>
      <p>You have been assigned to the team <strong>"${teamName}"</strong> as a <strong>${role}</strong>.</p>
      <p>Please log in to your ${appName} account to view more details:</p>
      <div style="text-align: center;">
        <a href="${loginLink}" class="button">Log In to Your Account</a>
      </div>
      <p>Best regards,<br>The ${appName} Team</p>
    </div>
    <div class="footer">
      <p>If you have any questions, please contact your team administrator.</p>
    </div>
  </div>
</body>
</html>
  `;
  
  const emailData: EmailData = {
    to: email,
    from: process.env.EMAIL_FROM || 'onboarding@resend.dev',
    subject,
    text,
    html
  };
  
  return sendEmail(emailData);
};

/**
 * Send a payment reminder email
 */
export const sendPaymentReminderEmail = async (
  email: string,
  firstName: string,
  lastName: string,
  amount: number,
  dueDate: Date,
  feeDescription: string
): Promise<boolean> => {
  const appName = 'Soccer Club Pro';
  const paymentLink = `${process.env.BASE_URL || 'https://88037f5d-cc3e-4e7e-bf09-ef96b5a50fca-00-apd6h07vapwx.picard.replit.dev'}/payments`;
  const dueDateFormatted = dueDate.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const formattedAmount = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
  
  const subject = `Payment Reminder: ${feeDescription} due on ${dueDateFormatted}`;
  
  const text = `
Hello ${firstName} ${lastName},

This is a friendly reminder that your payment of ${formattedAmount} for "${feeDescription}" is due on ${dueDateFormatted}.

Please log in to your ${appName} account to view and manage your payments:
${paymentLink}

Best regards,
The ${appName} Team
  `;
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4a90e2; color: white; padding: 10px 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    .button { background-color: #4a90e2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0; display: inline-block; }
    .details { background-color: #f0f0f0; border-left: 4px solid #4a90e2; padding: 15px; margin: 20px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${appName}</h1>
    </div>
    <div class="content">
      <p>Hello ${firstName} ${lastName},</p>
      <p>This is a friendly reminder that your payment of <strong>${formattedAmount}</strong> for "<strong>${feeDescription}</strong>" is due on <strong>${dueDateFormatted}</strong>.</p>
      <div class="details">
        <p style="margin: 0; font-weight: bold;">Payment Details:</p>
        <p style="margin: 10px 0 0 0;">Amount: ${formattedAmount}</p>
        <p style="margin: 5px 0 0 0;">Description: ${feeDescription}</p>
        <p style="margin: 5px 0 0 0;">Due Date: ${dueDateFormatted}</p>
      </div>
      <p>Please log in to your ${appName} account to view and manage your payments:</p>
      <div style="text-align: center;">
        <a href="${paymentLink}" class="button">View Payment Details</a>
      </div>
      <p>If you have already made this payment, please disregard this reminder.</p>
      <p>Best regards,<br>The ${appName} Team</p>
    </div>
    <div class="footer">
      <p>If you have any questions about this payment, please contact our finance department.</p>
    </div>
  </div>
</body>
</html>
  `;
  
  const emailData: EmailData = {
    to: email,
    from: process.env.EMAIL_FROM || 'onboarding@resend.dev',
    subject,
    text,
    html
  };
  
  return sendEmail(emailData);
};