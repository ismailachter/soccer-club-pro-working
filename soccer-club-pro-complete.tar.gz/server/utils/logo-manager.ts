import { readdir, stat } from 'fs/promises';
import path from 'path';

interface LogoInfo {
  filename: string;
  path: string;
  type: 'primary' | 'secondary' | 'team-specific';
  size: number;
  uploadDate: Date;
  teamAssociation?: string;
}

export class LogoManager {
  private static logoDirectory = 'uploads';
  
  static async getAvailableLogos(): Promise<LogoInfo[]> {
    try {
      const files = await readdir(this.logoDirectory);
      const logoFiles = files.filter(file => 
        file.startsWith('club-logo-') && 
        /\.(jpg|jpeg|png|gif)$/i.test(file)
      );
      
      const logoInfos: LogoInfo[] = [];
      
      for (const file of logoFiles) {
        const fullPath = path.join(this.logoDirectory, file);
        const stats = await stat(fullPath);
        
        // Determine logo type based on filename or creation time
        let type: 'primary' | 'secondary' | 'team-specific' = 'primary';
        let teamAssociation: string | undefined;
        
        // Latest logo is primary, older ones become secondary or team-specific
        if (logoFiles.length > 1) {
          const sortedFiles = logoFiles.sort((a, b) => {
            const timestampA = this.extractTimestamp(a);
            const timestampB = this.extractTimestamp(b);
            return timestampB - timestampA;
          });
          
          if (file === sortedFiles[0]) {
            type = 'primary';
          } else if (file === sortedFiles[1]) {
            type = 'secondary';
            teamAssociation = 'Beloften'; // Second logo for Beloften team
          } else {
            type = 'team-specific';
            teamAssociation = 'MU20'; // Third logo for MU20 team
          }
        }
        
        logoInfos.push({
          filename: file,
          path: fullPath,
          type,
          size: stats.size,
          uploadDate: stats.birthtime,
          teamAssociation
        });
      }
      
      return logoInfos.sort((a, b) => b.uploadDate.getTime() - a.uploadDate.getTime());
    } catch (error) {
      console.error('Error getting available logos:', error);
      return [];
    }
  }
  
  static async getLogoForTeam(ageGroup: string): Promise<string | null> {
    const logos = await this.getAvailableLogos();
    
    if (logos.length === 0) return null;
    
    // Map age groups to logo preferences
    const teamMapping: Record<string, string[]> = {
      'Dames IP': ['primary'],
      'Dames Provinciaal': ['secondary', 'primary'],
      'MU20': ['team-specific', 'secondary', 'primary'],
      'Beloften': ['secondary', 'primary'],
      'U20 InterProvinciaal': ['team-specific', 'secondary', 'primary']
    };
    
    const preferences = teamMapping[ageGroup] || ['primary'];
    
    for (const preference of preferences) {
      const logo = logos.find(l => l.type === preference);
      if (logo) {
        return logo.path;
      }
    }
    
    // Fallback to newest logo
    return logos[0]?.path || null;
  }
  
  static async getPrimaryLogo(): Promise<string | null> {
    const logos = await this.getAvailableLogos();
    const primary = logos.find(l => l.type === 'primary');
    return primary?.path || logos[0]?.path || null;
  }
  
  private static extractTimestamp(filename: string): number {
    const match = filename.match(/club-logo-(\d+)-/);
    return match ? parseInt(match[1]) : 0;
  }
  
  static async organizeLogosForTeams(): Promise<{primary: string | null, secondary: string | null, teamSpecific: string | null}> {
    const logos = await this.getAvailableLogos();
    
    return {
      primary: logos.find(l => l.type === 'primary')?.path || null,
      secondary: logos.find(l => l.type === 'secondary')?.path || null,
      teamSpecific: logos.find(l => l.type === 'team-specific')?.path || null
    };
  }
}