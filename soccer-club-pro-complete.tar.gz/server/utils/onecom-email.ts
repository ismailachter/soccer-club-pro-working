import nodemailer from 'nodemailer';

interface EmailOptions {
  to: string[];
  subject: string;
  html: string;
  text: string;
}

export async function sendOneComEmail(options: EmailOptions) {
  try {
    const transporter = nodemailer.createTransporter({
      host: 'send.one.com',
      port: 465,
      secure: true,
      auth: {
        user: 'info@soccerclubpro.com',
        pass: process.env.ONECOM_EMAIL_PASSWORD || 'Qunoot135!'
      }
    });

    const mailOptions = {
      from: 'info@soccerclubpro.com',
      to: options.to.join(', '),
      cc: 'ismail.achter@gmail.com',
      subject: options.subject,
      html: options.html,
      text: options.text
    };

    const result = await transporter.sendMail(mailOptions);
    console.log('📧 Email sent successfully via One.com SMTP');
    return result;
  } catch (error) {
    console.error('❌ One.com email error:', error);
    throw error;
  }
}