import nodemailer from 'nodemailer';

// One.com SMTP configuration for VVC Brasschaat
const ONECOM_SMTP_CONFIG = {
  host: 'send.one.com',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'info@vvcbrasschaat.be', // Your One.com email
    pass: process.env.ONECOM_PASSWORD || 'your-password-here' // Your One.com email password
  },
  tls: {
    ciphers: 'SSLv3'
  }
};

const transporter = nodemailer.createTransport(ONECOM_SMTP_CONFIG);

interface EmailOptions {
  to: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(options: EmailOptions): Promise<boolean> {
  try {
    await transporter.sendMail({
      from: '"VVC Brasschaat" <info@vvcbrasschaat.be>',
      to: options.to,
      subject: options.subject,
      text: options.text,
      html: options.html
    });
    return true;
  } catch (error) {
    console.error('Email sending failed:', error);
    return false;
  }
}

export async function sendInvitationEmail(
  email: string,
  firstName: string,
  lastName: string,
  role: string,
  invitationToken: string,
  customMessage?: string
): Promise<boolean> {
  const invitationUrl = `${process.env.APP_URL || 'http://localhost:5000'}/activate-account?token=${invitationToken}`;
  
  const roleDisplayMap: Record<string, string> = {
    'admin': 'Administrator',
    'coach': 'Coach',
    'player': 'Speelster',
    'parent': 'Ouder',
    'coordinator': 'Coördinator',
    'trainer': 'Trainer'
  };

  const subject = `Uitnodiging voor VVC Brasschaat - ${roleDisplayMap[role] || role}`;
  
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #232e5d; margin: 0;">VVC Brasschaat</h1>
        <p style="color: #4a90e2; font-size: 18px; margin: 5px 0;">Uitnodiging voor Soccer Club Pro</p>
      </div>
      
      <div style="background: #f8f9fa; padding: 30px; border-radius: 10px; margin-bottom: 30px;">
        <h2 style="color: #232e5d; margin-top: 0;">Hallo ${firstName} ${lastName},</h2>
        
        <p style="color: #333; line-height: 1.6; font-size: 16px;">
          Je bent uitgenodigd om deel te nemen aan het Soccer Club Pro platform van VVC Brasschaat als <strong>${roleDisplayMap[role] || role}</strong>.
        </p>
        
        ${customMessage ? `
          <div style="background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p style="color: #1976d2; margin: 0; font-style: italic;">"${customMessage}"</p>
          </div>
        ` : ''}
        
        <p style="color: #333; line-height: 1.6; font-size: 16px;">
          Om je account te activeren en je wachtwoord in te stellen, klik je op de onderstaande knop:
        </p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${invitationUrl}" 
             style="background: #4a90e2; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-size: 16px; font-weight: bold; display: inline-block;">
            Account Activeren
          </a>
        </div>
        
        <p style="color: #666; font-size: 14px; margin-top: 30px;">
          Als de knop niet werkt, kopieer en plak deze link in je browser:
          <br>
          <a href="${invitationUrl}" style="color: #4a90e2; word-break: break-all;">${invitationUrl}</a>
        </p>
      </div>
      
      <div style="text-align: center; color: #666; font-size: 12px;">
        <p>
          Deze uitnodiging is verstuurd door VVC Brasschaat Soccer Club Pro.<br>
          Voor vragen, contacteer ons via info@vvcbrasschaat.be
        </p>
      </div>
    </div>
  `;

  const textContent = `
Hallo ${firstName} ${lastName},

Je bent uitgenodigd om deel te nemen aan het Soccer Club Pro platform van VVC Brasschaat als ${roleDisplayMap[role] || role}.

${customMessage ? `Persoonlijk bericht: "${customMessage}"\n\n` : ''}

Om je account te activeren en je wachtwoord in te stellen, ga je naar:
${invitationUrl}

Voor vragen, contacteer ons via info@vvcbrasschaat.be

Met vriendelijke groeten,
VVC Brasschaat
  `;

  return await sendEmail({
    to: email,
    subject,
    html: htmlContent,
    text: textContent
  });
}

export async function sendPasswordResetEmail(
  email: string,
  firstName: string,
  resetToken: string
): Promise<boolean> {
  const resetUrl = `${process.env.APP_URL || 'http://localhost:5000'}/reset-password?token=${resetToken}`;
  
  const subject = 'Wachtwoord Reset - VVC Brasschaat';
  
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #232e5d; margin: 0;">VVC Brasschaat</h1>
        <p style="color: #4a90e2; font-size: 18px; margin: 5px 0;">Wachtwoord Reset</p>
      </div>
      
      <div style="background: #f8f9fa; padding: 30px; border-radius: 10px; margin-bottom: 30px;">
        <h2 style="color: #232e5d; margin-top: 0;">Hallo ${firstName},</h2>
        
        <p style="color: #333; line-height: 1.6; font-size: 16px;">
          Je hebt een wachtwoord reset aangevraagd voor je Soccer Club Pro account.
        </p>
        
        <p style="color: #333; line-height: 1.6; font-size: 16px;">
          Klik op de onderstaande knop om een nieuw wachtwoord in te stellen:
        </p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" 
             style="background: #4a90e2; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-size: 16px; font-weight: bold; display: inline-block;">
            Wachtwoord Resetten
          </a>
        </div>
        
        <p style="color: #666; font-size: 14px; margin-top: 30px;">
          Als de knop niet werkt, kopieer en plak deze link in je browser:
          <br>
          <a href="${resetUrl}" style="color: #4a90e2; word-break: break-all;">${resetUrl}</a>
        </p>
        
        <p style="color: #999; font-size: 12px; margin-top: 20px;">
          Deze link is 1 uur geldig. Als je geen wachtwoord reset hebt aangevraagd, negeer dan deze email.
        </p>
      </div>
      
      <div style="text-align: center; color: #666; font-size: 12px;">
        <p>
          Deze email is verstuurd door VVC Brasschaat Soccer Club Pro.<br>
          Voor vragen, contacteer ons via info@vvcbrasschaat.be
        </p>
      </div>
    </div>
  `;

  const textContent = `
Hallo ${firstName},

Je hebt een wachtwoord reset aangevraagd voor je Soccer Club Pro account.

Om een nieuw wachtwoord in te stellen, ga je naar:
${resetUrl}

Deze link is 1 uur geldig. Als je geen wachtwoord reset hebt aangevraagd, negeer dan deze email.

Voor vragen, contacteer ons via info@vvcbrasschaat.be

Met vriendelijke groeten,
VVC Brasschaat
  `;

  return await sendEmail({
    to: email,
    subject,
    html: htmlContent,
    text: textContent
  });
}