import { Request, Response, NextFunction } from 'express';
import { SecurityService } from './security-service';

const securityService = new SecurityService();

// Security middleware factory
export function requireAccess(operation: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Get club ID from request (from auth or default)
      const clubId = (req as any).clubId || 1; // Default to VVC for testing
      
      // Rate limiting check
      if (!securityService.checkRateLimit(clubId, operation)) {
        return res.status(429).json({
          error: 'Too many requests',
          message: 'Rate limit exceeded. Please try again later.'
        });
      }

      // Validate request
      const validation = await securityService.validateRequest(req, operation);
      
      if (!validation.allowed) {
        const statusCode = validation.requiresPayment ? 402 : 403;
        
        await securityService.logSecurityEvent(
          clubId,
          (req as any).userId || 'anonymous',
          operation,
          'denied',
          validation.reason
        );

        return res.status(statusCode).json({
          error: 'Access denied',
          message: validation.reason,
          requiresPayment: validation.requiresPayment,
          upgradeUrl: validation.requiresPayment ? '/subscription' : undefined
        });
      }

      // Log successful access
      await securityService.logSecurityEvent(
        clubId,
        (req as any).userId || 'anonymous',
        operation,
        'allowed'
      );

      next();
    } catch (error) {
      console.error('Security middleware error:', error);
      res.status(500).json({
        error: 'Security check failed',
        message: 'Please try again later.'
      });
    }
  };
}

// Specific middleware for different operations
export const requirePDFExport = requireAccess('pdf_export');
export const requireExcelExport = requireAccess('excel_export');
export const requireICSExport = requireAccess('ics_export');
export const requirePowerPointExport = requireAccess('powerpoint_export');
export const requireBackupDownload = requireAccess('backup_download');
export const requireJSONExport = requireAccess('json_export');
export const requireAPIAccess = requireAccess('api_access');
export const requireAIGeneration = requireAccess('ai_generation');

// Free player export (only own club players)
export const allowFreePlayerExport = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const clubId = (req as any).clubId || 1;
    
    // Add security watermark to response
    const originalSend = res.send;
    res.send = function(data) {
      if (data && typeof data === 'object') {
        data = securityService.addSecurityWatermark(data, clubId, 'player_excel_export');
      }
      return originalSend.call(this, data);
    };

    await securityService.logSecurityEvent(
      clubId,
      (req as any).userId || 'anonymous',
      'player_excel_export',
      'allowed',
      'Free operation'
    );

    next();
  } catch (error) {
    console.error('Free export middleware error:', error);
    res.status(500).json({ error: 'Export failed' });
  }
};

// Anti-piracy middleware
export const antiPiracy = (req: Request, res: Response, next: NextFunction) => {
  const userAgent = req.headers['user-agent'] || '';
  const forbiddenPatterns = [
    'git',
    'svn',
    'wget',
    'curl',
    'python',
    'node',
    'postman',
    'insomnia'
  ];

  const isSuspicious = forbiddenPatterns.some(pattern =>
    userAgent.toLowerCase().includes(pattern)
  );

  if (isSuspicious) {
    console.log(`🚨 BLOCKED suspicious request from: ${userAgent}`);
    return res.status(403).json({
      error: 'Access denied',
      message: 'Automated access is not permitted.'
    });
  }

  next();
};

// Secure download middleware
export const secureDownload = (operation: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    const token = req.query.token as string;
    
    if (!token) {
      return res.status(400).json({
        error: 'Download token required',
        message: 'Please request a valid download token.'
      });
    }

    const validation = securityService.validateDownloadToken(token);
    if (!validation.valid) {
      return res.status(401).json({
        error: 'Invalid or expired token',
        message: 'Please request a new download token.'
      });
    }

    if (validation.operation !== operation) {
      return res.status(403).json({
        error: 'Token mismatch',
        message: 'Token is not valid for this operation.'
      });
    }

    (req as any).clubId = validation.clubId;
    next();
  };
};