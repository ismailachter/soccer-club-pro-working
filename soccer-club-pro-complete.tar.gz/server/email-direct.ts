import nodemailer from 'nodemailer';

export class DirectEmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    // Gmail SMTP with App Password
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: 'ismail.achter@gmail.com',
        pass: process.env.GMAIL_APP_PASSWORD
      }
    });
  }

  async sendTrainingPDF(recipientEmail: string, pdfBuffer: Buffer, trainingTitle: string) {
    try {
      console.log(`Sending email to ${recipientEmail} with PDF attachment`);
      
      const mailOptions = {
        from: 'VVC Brasschaat <ismail.achter@gmail.com>',
        to: recipientEmail,
        subject: `VVC Brasschaat - ${trainingTitle}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #1e40af; color: white; padding: 20px; text-align: center;">
              <h1>VVC BRASSCHAAT</h1>
              <h2>${trainingTitle}</h2>
            </div>
            
            <div style="background: white; padding: 20px; border: 1px solid #ddd;">
              <h3>Complete IP Jaarplan Gereed!</h3>
              <p>Het volledige jaarplan met alle verbeteringen:</p>
              
              <ul>
                <li>Complete thema weergave (geen elementen meer)</li>
                <li>Exacte tijden: 20:00 - 21:45</li>
                <li>VARIA opmerkingen volledig zichtbaar</li>
                <li>Professionele training boxes met nummering</li>
                <li>Chronologische sortering van alle 92 sessies</li>
                <li>PDF grootte: ${Math.round(pdfBuffer.length / 1024)}KB</li>
              </ul>
            </div>
            
            <div style="background: #f8fafc; padding: 15px; text-align: center; font-size: 12px;">
              Soccer Club Pro - VVC Brasschaat<br>
              Passie, Prestatie & Plezier - Samen Sterk!
            </div>
          </div>
        `,
        attachments: [{
          filename: 'VVC-Brasschaat-Dames-IP-Jaarplanning-2025-2026.pdf',
          content: pdfBuffer,
          contentType: 'application/pdf'
        }]
      };

      const result = await this.transporter.sendMail(mailOptions);
      
      console.log('Email sent successfully:', result.messageId);
      return {
        success: true,
        messageId: result.messageId,
        recipient: recipientEmail
      };

    } catch (error: any) {
      console.error('Email sending failed:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async sendInvitationEmail(recipientEmail: string, inviterName: string, clubName: string, role: string, tempPassword: string) {
    try {
      console.log(`Sending invitation email to ${recipientEmail} for role: ${role}`);
      
      const mailOptions = {
        from: 'VVC Brasschaat <ismail.achter@gmail.com>',
        to: recipientEmail,
        subject: `Uitnodiging - ${clubName} Soccer Club Pro`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #1e40af; color: white; padding: 20px; text-align: center;">
              <h1>${clubName}</h1>
              <h2>Soccer Club Pro Uitnodiging</h2>
            </div>
            
            <div style="background: white; padding: 20px; border: 1px solid #ddd;">
              <h3>Welkom bij Soccer Club Pro!</h3>
              <p>Hallo,</p>
              
              <p><strong>${inviterName}</strong> heeft je uitgenodigd om toe te treden tot <strong>${clubName}</strong> in Soccer Club Pro.</p>
              
              <div style="background: #f8fafc; padding: 15px; border-left: 4px solid #1e40af; margin: 20px 0;">
                <h4 style="margin: 0 0 10px 0;">Je account details:</h4>
                <p style="margin: 5px 0;"><strong>Rol:</strong> ${role}</p>
                <p style="margin: 5px 0;"><strong>E-mail:</strong> ${recipientEmail}</p>
                <p style="margin: 5px 0;"><strong>Tijdelijk wachtwoord:</strong> <code style="background: #e5e7eb; padding: 2px 4px; border-radius: 3px;">${tempPassword}</code></p>
              </div>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="https://soccerclubpro.be" style="background: #1e40af; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
                  Login bij Soccer Club Pro
                </a>
              </div>
              
              <h4>Wat kan je doen als ${role}?</h4>
              <ul>
                <li>Toegang tot jaarplanningen en training schema's</li>
                <li>IADATABANK met 200+ training elementen</li>
                <li>Kalender beheer en sessie planning</li>
                <li>Professional PDF exports</li>
                <li>Team communicatie en updates</li>
              </ul>
              
              <p style="color: #666; font-size: 14px; margin-top: 30px;">
                <strong>Belangrijk:</strong> Wijzig je wachtwoord na de eerste login voor veiligheid.
              </p>
            </div>
            
            <div style="background: #f8fafc; padding: 15px; text-align: center; font-size: 12px; color: #666;">
              Soccer Club Pro - ${clubName}<br>
              Passie, Prestatie & Plezier - Samen Sterk!<br>
              <a href="mailto:support@soccerclubpro.be">support@soccerclubpro.be</a>
            </div>
          </div>
        `,
        text: `
Uitnodiging - ${clubName} Soccer Club Pro

Hallo,

${inviterName} heeft je uitgenodigd om toe te treden tot ${clubName} in Soccer Club Pro.

Je account details:
- Rol: ${role}
- E-mail: ${recipientEmail}
- Tijdelijk wachtwoord: ${tempPassword}

Login op: https://soccerclubpro.be

Wijzig je wachtwoord na de eerste login.

Met vriendelijke groet,
${clubName} Team
        `
      };

      const result = await this.transporter.sendMail(mailOptions);
      
      console.log('Invitation email sent successfully:', result.messageId);
      return {
        success: true,
        messageId: result.messageId,
        recipient: recipientEmail
      };

    } catch (error: any) {
      console.error('Invitation email sending failed:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }
}