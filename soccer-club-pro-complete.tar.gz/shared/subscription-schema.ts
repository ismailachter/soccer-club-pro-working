import {
  pgTable,
  text,
  varchar,
  timestamp,
  decimal,
  boolean,
  integer,
  jsonb,
  serial,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Subscription plans and modules
export const subscriptionPlans = pgTable("subscription_plans", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency").default("EUR"),
  billingInterval: varchar("billing_interval").default("month"), // month, year
  features: jsonb("features").$type<string[]>(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Club subscriptions
export const clubSubscriptions = pgTable("club_subscriptions", {
  id: varchar("id").primaryKey(),
  clubId: integer("club_id").notNull(),
  planId: varchar("plan_id").references(() => subscriptionPlans.id),
  status: varchar("status").default("active"), // active, suspended, cancelled
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  stripeCustomerId: varchar("stripe_customer_id"),
  cancelAtPeriodEnd: boolean("cancel_at_period_end").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Module access per club
export const clubModules = pgTable("club_modules", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").notNull(),
  moduleName: varchar("module_name").notNull(),
  isEnabled: boolean("is_enabled").default(true),
  enabledAt: timestamp("enabled_at").defaultNow(),
  disabledAt: timestamp("disabled_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Available modules definition
export const modules = pgTable("modules", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  displayName: varchar("display_name").notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  category: varchar("category"), // core, player, training, team, etc.
  features: jsonb("features").$type<string[]>(),
  dependencies: jsonb("dependencies").$type<string[]>(), // required modules
  isCore: boolean("is_core").default(false),
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Club settings for modules
export const clubSettings = pgTable("club_settings", {
  id: varchar("id").primaryKey(),
  clubId: integer("club_id").notNull(),
  settingKey: varchar("setting_key").notNull(),
  settingValue: jsonb("setting_value"),
  moduleId: varchar("module_id").references(() => modules.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schema types
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = typeof subscriptionPlans.$inferInsert;

export type ClubSubscription = typeof clubSubscriptions.$inferSelect;
export type InsertClubSubscription = typeof clubSubscriptions.$inferInsert;

export type ClubModule = typeof clubModules.$inferSelect;
export type InsertClubModule = typeof clubModules.$inferInsert;

export type Module = typeof modules.$inferSelect;
export type InsertModule = typeof modules.$inferInsert;

export type ClubSetting = typeof clubSettings.$inferSelect;
export type InsertClubSetting = typeof clubSettings.$inferInsert;

// Zod schemas
export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans);
export const insertClubSubscriptionSchema = createInsertSchema(clubSubscriptions);
export const insertClubModuleSchema = createInsertSchema(clubModules);
export const insertModuleSchema = createInsertSchema(modules);
export const insertClubSettingSchema = createInsertSchema(clubSettings);

// Module definitions
export const AVAILABLE_MODULES = {
  CORE: {
    id: "core",
    name: "Core Module",
    price: 29,
    features: ["Dashboard", "Club Info", "User Management", "Email System"],
    isCore: true,
    category: "core"
  },
  PLAYER_MANAGEMENT: {
    id: "player_management", 
    name: "Speler Management",
    price: 19,
    features: ["Players Database", "Scout Database", "Team Assignments"],
    category: "player"
  },
  TRAINING_PLANNING: {
    id: "training_planning",
    name: "Training & Planning", 
    price: 24,
    features: ["IADATABANK", "Jaarplanning", "Training Maker", "PDF Export"],
    category: "training"
  },
  TEAM_MANAGEMENT: {
    id: "team_management",
    name: "Team Management",
    price: 16, 
    features: ["Teams Dashboard", "Team Selection", "Team Scheduling"],
    category: "team"
  },
  MATCH_MANAGEMENT: {
    id: "match_management",
    name: "Wedstrijd Management",
    price: 14,
    features: ["Match Planning", "Results Tracking", "Opponent Database"],
    category: "match"
  },
  FACILITIES: {
    id: "facilities",
    name: "Facilitair",
    price: 12,
    features: ["Pitches Management", "Equipment Tracking"],
    category: "facility"
  },
  FINANCIAL: {
    id: "financial", 
    name: "Financieel",
    price: 18,
    features: ["Payment Management", "Fee Tracking", "Financial Reports"],
    category: "finance"
  },
  COMMUNICATION: {
    id: "communication",
    name: "Communicatie", 
    price: 15,
    features: ["Parent Communication", "Invitations", "Notifications"],
    category: "communication"
  },
  ANALYTICS: {
    id: "analytics",
    name: "Advanced Analytics",
    price: 22,
    features: ["Performance Analytics", "Player Development", "Custom Reports"],
    category: "analytics"
  }
} as const;