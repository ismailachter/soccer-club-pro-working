import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Bell, Menu, Download, Plus, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import Sidebar from "./sidebar";
import { useQuery } from "@tanstack/react-query";
import { LanguageToggle } from "@/components/language-toggle";
import { useAuth } from "@/hooks/use-auth";

const pageNames: Record<string, string> = {
  "/": "",
  "/players": "Players",
  "/teams": "Teams",
  "/matches": "Matches",
  "/training": "Training",
  "/coaches": "Coaches",
  "/pitches": "Pitches",
  "/parents": "Parents",
  "/settings": "Settings",
  "/club-info": "",
};

const Header = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { logoutMutation } = useAuth();
  
  // Special cases for pages that should not show a title (they have their own headers)
  const pageName = (location === "/club-info" || location === "/teams") ? "" : (pageNames[location] || "Page");
  
  // Fetch club info
  const { data: clubInfo } = useQuery({
    queryKey: ['/api/club/info'],
    staleTime: 300000, // 5 minutes
  });
  
  // App name logic - use club name if available
  const appName = clubInfo?.name || "Soccer Club Pro";
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <>
      {/* Mobile header bar */}
      <div className="md:hidden flex items-center justify-between bg-white px-4 py-3 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-muted-foreground">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64">
              <Sidebar />
            </SheetContent>
          </Sheet>
          {/* Logo and app name removed for clean mobile header */}
        </div>
        <div className="flex items-center space-x-3">
          <LanguageToggle />
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <Bell className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-muted-foreground" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
          </Button>
          <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white font-medium">
            JD
          </div>
        </div>
      </div>

      {/* Desktop top navigation bar */}
      <div className="hidden md:flex items-center justify-end py-4">
        {/* Logo and page title removed for clean header */}
        <div className="flex items-center space-x-4">
          <LanguageToggle />
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <Bell className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-muted-foreground" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </>
  );
};

// Function to get the appropriate action button text based on current page
function getActionButtonText(path: string): string {
  switch (path) {
    case '/players':
      return 'Add Player';
    case '/teams':
      return 'Create Team';
    case '/matches':
      return 'Schedule Match';
    case '/training':
      return 'Schedule Training';
    case '/coaches':
      return 'Add Coach';
    case '/pitches':
      return 'Add Pitch';
    case '/parents':
      return 'Add Parent';
    default:
      return 'New Entry';
  }
}

export default Header;
