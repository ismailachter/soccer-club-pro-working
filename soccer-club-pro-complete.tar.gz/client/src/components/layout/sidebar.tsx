import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import {
  Home,
  Users,
  Shield,
  Calendar,
  CheckSquare,
  Map,
  Users as UsersIcon,
  Settings,
  LogOut,
  Award,
  Database,
  UsersRound,
  UserPlus,
  CreditCard,
  Building,
  BookOpen,
  BarChart3,
  User,
  Phone,
  CalendarDays,
  Clipboard,
  PlayCircle,
  Download,
  Target,
  Video
} from "lucide-react";
import type { Club } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useTranslation } from "@/lib/i18n";
import { LanguageToggle } from "@/components/language-toggle";
import { ThemeSelector } from "@/components/theme/theme-selector";

const Sidebar = () => {
  const [location] = useLocation();
  const { user } = useAuth();
  const { t } = useTranslation();
  
  // Fetch club info
  const { data: clubInfo } = useQuery<Club>({
    queryKey: ['/api/club/info'],
    // If the club endpoint fails, we'll show a default name
    placeholderData: { name: "Club Information" } as Club
  });

  // Define navigation items based on user role
  const getNavItems = () => {
    const userRole = user?.role || 'player';
    
    // Player-only navigation
    if (userRole === 'player') {
      return [
        { href: "/player-dashboard", label: t('dashboard'), icon: <User className="mr-3 h-5 w-5" /> },
        { href: "/club-info", label: "Club Information", icon: <Building className="mr-3 h-5 w-5" /> },
        { href: "/settings", label: t('settings'), icon: <Settings className="mr-3 h-5 w-5" /> },
      ];
    }
    
    // Viewer (raadpleeguser) - read-only navigation with download capabilities
    if (userRole === 'viewer') {
      return [
        { href: "/", label: t('dashboard'), icon: <Home className="mr-3 h-5 w-5" /> },
        { href: "/club-info", label: "Club Information", icon: <Building className="mr-3 h-5 w-5" /> },
        { href: "/teams-management", label: t('teams'), icon: <Shield className="mr-3 h-5 w-5" /> },
        { href: "/team-overview", label: "Team Dashboard", icon: <UsersRound className="mr-3 h-5 w-5" /> },
        { href: "/players-database", label: "Spelers Database", icon: <Database className="mr-3 h-5 w-5" /> },
        { href: "/scout-database", label: "Scout Database", icon: <Target className="mr-3 h-5 w-5" /> },
        { href: "/jaarplanning", label: "Jaarplanning", icon: <CalendarDays className="mr-3 h-5 w-5" /> },
        { href: "/iadatabank", label: "IADATABANK", icon: <Database className="mr-3 h-5 w-5" /> },
      ];
    }
    
    // Admin/Coach full navigation
    return [
      { href: "/", label: t('dashboard'), icon: <Home className="mr-3 h-5 w-5" /> },
      { href: "/club-info", label: "Club Information", icon: <Building className="mr-3 h-5 w-5" /> },
      { href: "/teams-management", label: t('teams'), icon: <Shield className="mr-3 h-5 w-5" /> },

      { href: "/team-schedule", label: "Team Weekoverzicht", icon: <CalendarDays className="mr-3 h-5 w-5" /> },
      { href: "/team-overview", label: "Team Dashboard", icon: <UsersRound className="mr-3 h-5 w-5" /> },
      { href: "/team-selection", label: "Selectiemodule", icon: <Target className="mr-3 h-5 w-5" /> },

      { href: "/players-database", label: "Spelers Database", icon: <Database className="mr-3 h-5 w-5" /> },
      { href: "/scout-database", label: "Scout Database", icon: <Target className="mr-3 h-5 w-5" /> },
      { href: "/matches", label: t('matches'), icon: <Calendar className="mr-3 h-5 w-5" /> },
      { href: "/training", label: t('trainings'), icon: <CheckSquare className="mr-3 h-5 w-5" /> },
      { href: "/training-session-maker", label: "Trainingsessie Maker", icon: <Clipboard className="mr-3 h-5 w-5" /> },
      { href: "/modern-training-session-maker", label: "Moderne Sessie Maker", icon: <PlayCircle className="mr-3 h-5 w-5" /> },
      { href: "/training-import", label: "Training Import", icon: <Download className="mr-3 h-5 w-5" /> },
      { href: "/video-upload", label: "Video Upload", icon: <Video className="mr-3 h-5 w-5" /> },
      { href: "/individual-analysis", label: "Individual Analysis", icon: <BarChart3 className="mr-3 h-5 w-5" /> },
      { href: "/season-cumulator", label: "Seizoen Cumulator", icon: <Award className="mr-3 h-5 w-5" /> },
      { href: "/jaarplanning", label: "Jaarplanning", icon: <CalendarDays className="mr-3 h-5 w-5" /> },
      { href: "/iadatabank", label: "IADATABANK", icon: <Database className="mr-3 h-5 w-5" /> },

      { href: "/coaches", label: t('coaches'), icon: <Award className="mr-3 h-5 w-5" /> },
      { href: "/pitches", label: t('pitches'), icon: <Map className="mr-3 h-5 w-5" /> },
      { href: "/parents", label: "Parents", icon: <UsersIcon className="mr-3 h-5 w-5" /> },
      { href: "/team-assignments", label: "Team Assignments", icon: <UserPlus className="mr-3 h-5 w-5" /> },
      { href: "/payments", label: t('payments'), icon: <CreditCard className="mr-3 h-5 w-5" /> },
      { href: "/invitations", label: "Uitnodigingen", icon: <UserPlus className="mr-3 h-5 w-5" /> },
      { href: "/subscription", label: "SaaS Modules", icon: <CreditCard className="mr-3 h-5 w-5" /> },
      { href: "/terms", label: "Algemene Voorwaarden", icon: <Shield className="mr-3 h-5 w-5" /> },
      { href: "/logo-organization", label: "Logo Organisatie", icon: <Award className="mr-3 h-5 w-5" /> },
      { href: "/settings", label: t('settings'), icon: <Settings className="mr-3 h-5 w-5" /> },
      { href: "/admin/database", label: "Database Admin", icon: <Database className="mr-3 h-5 w-5" /> },
    ];
  };

  const navItems = getNavItems();

  return (
    <aside className="flex w-64 flex-col fixed inset-y-0 z-50 bg-sidebar border-r border-sidebar-border">
      <div className="flex items-center justify-center h-16 border-b border-sidebar-border px-4">
        <div className="flex items-center space-x-2">
          {clubInfo?.logo ? (
            <img 
              src={clubInfo.logo} 
              alt="Club Logo" 
              className="h-7 w-7 object-contain rounded-full bg-white"
            />
          ) : (
            <div className="rounded-full bg-primary h-7 w-7 flex items-center justify-center">
              <i className="ri-football-line text-white text-xl"></i>
            </div>
          )}
          <span className="font-bold text-xl text-sidebar-foreground truncate">
            {clubInfo?.name || "Club Management"}
          </span>
        </div>
      </div>

      <div className="flex flex-col flex-1 overflow-y-auto pt-5 pb-4">
        <nav className="flex-1 px-2 space-y-1">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors cursor-pointer",
                  location === item.href
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                )}
              >
                {item.icon}
                {item.label}
              </div>
            </Link>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-sidebar-border space-y-3">
        {/* Language Toggle */}
        <div className="flex justify-center">
          <LanguageToggle />
        </div>
        
        {/* User Profile */}
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white font-medium">
            {user?.username ? user.username.slice(0, 2).toUpperCase() : 'JD'}
          </div>
          <div>
            <div className="font-medium text-sidebar-foreground">{user?.username || 'John Doe'}</div>
            <div className="text-xs text-sidebar-foreground/70">{user?.role || 'Administrator'}</div>
          </div>
          <button className="ml-auto text-sidebar-foreground/70 hover:text-sidebar-foreground">
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
