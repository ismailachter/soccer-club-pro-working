import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDateTime } from "@/lib/utils";
import { Trophy, UserPlus, CalendarClock, Flag } from "lucide-react";

interface ActivityItem {
  id: number;
  type: 'new_player' | 'match_result' | 'training_scheduled' | 'field_maintenance';
  content: string;
  timestamp: string;
  entities?: {
    name: string;
    team?: string;
  }[];
}

interface RecentActivityProps {
  activities: ActivityItem[];
}

export function RecentActivity({ activities }: RecentActivityProps) {
  // Function to get icon by activity type
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'new_player':
        return <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 flex-shrink-0">
          <UserPlus className="h-4 w-4" />
        </div>;
      case 'match_result':
        return <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center text-green-600 flex-shrink-0">
          <Trophy className="h-4 w-4" />
        </div>;
      case 'training_scheduled':
        return <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-600 flex-shrink-0">
          <CalendarClock className="h-4 w-4" />
        </div>;
      case 'field_maintenance':
        return <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 flex-shrink-0">
          <Flag className="h-4 w-4" />
        </div>;
      default:
        return <div className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 flex-shrink-0">
          <CalendarClock className="h-4 w-4" />
        </div>;
    }
  };

  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Recent Activity</h2>
          <Button variant="link" size="sm" className="text-xs text-primary">
            View all
          </Button>
        </div>

        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start">
              {getActivityIcon(activity.type)}
              <div className="ml-3">
                <p className="text-sm text-foreground">
                  {activity.entities?.map((entity, index) => (
                    <span key={index}>
                      <span className="font-medium">{entity.name}</span>
                      {entity.team && <span> {entity.team}</span>}
                      {index < (activity.entities?.length || 0) - 1 ? ' • ' : ' '}
                    </span>
                  ))}
                  {activity.content}
                </p>
                <p className="text-xs text-muted-foreground">
                  {formatDateTime(activity.timestamp, 'PPp')}
                </p>
              </div>
            </div>
          ))}

          {activities.length === 0 && (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">No recent activity</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
