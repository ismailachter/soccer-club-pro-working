import { Card, CardContent } from "@/components/ui/card";
import { cn, getStatusColor } from "@/lib/utils";

interface Field {
  id: number;
  name: string;
  status: 'available' | 'in_use' | 'maintenance';
}

interface FieldStatusProps {
  fields: Field[];
}

export function FieldStatus({ fields }: FieldStatusProps) {
  // Helper function to get readable status text
  const getStatusText = (status: string): string => {
    switch (status) {
      case 'available': return 'Available';
      case 'in_use': return 'In Use';
      case 'maintenance': return 'Maintenance';
      default: return status;
    }
  };

  return (
    <Card>
      <CardContent className="p-5">
        <h2 className="text-lg font-semibold text-foreground mb-4">Field Status</h2>
        
        <div className="space-y-3">
          {fields.map((field) => {
            const statusColor = getStatusColor(field.status);
            const bgColor = field.status === 'available' ? 'bg-green-50 border-green-200' :
                           field.status === 'in_use' ? 'bg-amber-50 border-amber-200' :
                           'bg-red-50 border-red-200';
            
            return (
              <div key={field.id} className={cn("flex items-center justify-between p-2 rounded-md border", bgColor)}>
                <span className="text-sm font-medium text-foreground">{field.name}</span>
                <span className={cn("px-2 py-1 text-xs font-medium rounded-full", statusColor.bg, statusColor.text)}>
                  {getStatusText(field.status)}
                </span>
              </div>
            );
          })}

          {fields.length === 0 && (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">No fields available</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
