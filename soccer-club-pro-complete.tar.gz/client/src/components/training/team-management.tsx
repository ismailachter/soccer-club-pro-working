import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Circle,
  Square,
  Shirt,
  Edit3,
  Users,
  Palette,
  RotateCcw,
  User,
  UserCheck
} from "lucide-react";

interface Player {
  id: string;
  name: string;
  number: number;
  position: { x: number; y: number };
  isActive: boolean;
}

interface Team {
  id: string;
  name: string;
  color: string;
  players: Player[];
}

interface TeamManagementProps {
  onTeamUpdate?: (teams: { teamA: Team; teamB: Team }) => void;
}

const defaultFormations = {
  '4-4-2': [
    // Goalkeeper
    { x: 15, y: 50 },
    // Defense
    { x: 30, y: 20 }, { x: 30, y: 40 }, { x: 30, y: 60 }, { x: 30, y: 80 },
    // Midfield
    { x: 55, y: 25 }, { x: 55, y: 45 }, { x: 55, y: 55 }, { x: 55, y: 75 },
    // Attack
    { x: 75, y: 35 }, { x: 75, y: 65 },
    // Substitutes
    { x: 10, y: 10 }, { x: 10, y: 15 }, { x: 10, y: 20 }, { x: 10, y: 25 }, 
    { x: 10, y: 30 }, { x: 10, y: 35 }, { x: 10, y: 40 }, { x: 10, y: 85 }
  ],
  '4-3-3': [
    // Goalkeeper
    { x: 15, y: 50 },
    // Defense
    { x: 30, y: 20 }, { x: 30, y: 40 }, { x: 30, y: 60 }, { x: 30, y: 80 },
    // Midfield
    { x: 55, y: 30 }, { x: 55, y: 50 }, { x: 55, y: 70 },
    // Attack
    { x: 75, y: 25 }, { x: 75, y: 50 }, { x: 75, y: 75 },
    // Substitutes
    { x: 10, y: 10 }, { x: 10, y: 15 }, { x: 10, y: 20 }, { x: 10, y: 25 }, 
    { x: 10, y: 30 }, { x: 10, y: 35 }, { x: 10, y: 40 }, { x: 10, y: 85 }
  ],
  '3-4-3': [
    // Goalkeeper
    { x: 15, y: 50 },
    // Defense (3 defenders)
    { x: 30, y: 30 }, { x: 30, y: 50 }, { x: 30, y: 70 },
    // Midfield (4 midfielders)
    { x: 55, y: 20 }, { x: 55, y: 40 }, { x: 55, y: 60 }, { x: 55, y: 80 },
    // Attack (3 attackers)
    { x: 75, y: 30 }, { x: 75, y: 50 }, { x: 75, y: 70 },
    // Substitutes
    { x: 10, y: 10 }, { x: 10, y: 15 }, { x: 10, y: 20 }, { x: 10, y: 25 }, 
    { x: 10, y: 30 }, { x: 10, y: 35 }, { x: 10, y: 40 }, { x: 10, y: 85 }
  ],
  '3-5-3': [
    // Goalkeeper
    { x: 15, y: 50 },
    // Defense (3 defenders)
    { x: 30, y: 25 }, { x: 30, y: 50 }, { x: 30, y: 75 },
    // Midfield (5 midfielders)
    { x: 55, y: 15 }, { x: 55, y: 35 }, { x: 55, y: 50 }, { x: 55, y: 65 }, { x: 55, y: 85 },
    // Attack (3 attackers)
    { x: 75, y: 30 }, { x: 75, y: 50 }, { x: 75, y: 70 },
    // Substitutes
    { x: 10, y: 10 }, { x: 10, y: 15 }, { x: 10, y: 20 }, { x: 10, y: 25 }, 
    { x: 10, y: 30 }, { x: 10, y: 35 }, { x: 10, y: 40 }
  ],
  '4-2-3-1': [
    // Goalkeeper
    { x: 15, y: 50 },
    // Defense (4 defenders)
    { x: 30, y: 20 }, { x: 30, y: 40 }, { x: 30, y: 60 }, { x: 30, y: 80 },
    // Defensive Midfield (2 players)
    { x: 45, y: 40 }, { x: 45, y: 60 },
    // Attacking Midfield (3 players)
    { x: 65, y: 25 }, { x: 65, y: 50 }, { x: 65, y: 75 },
    // Striker (1 player)
    { x: 80, y: 50 },
    // Substitutes
    { x: 10, y: 10 }, { x: 10, y: 15 }, { x: 10, y: 20 }, { x: 10, y: 25 }, 
    { x: 10, y: 30 }, { x: 10, y: 35 }, { x: 10, y: 40 }, { x: 10, y: 85 }
  ],
  '4-5-1': [
    // Goalkeeper
    { x: 15, y: 50 },
    // Defense (4 defenders)
    { x: 30, y: 20 }, { x: 30, y: 40 }, { x: 30, y: 60 }, { x: 30, y: 80 },
    // Midfield (5 midfielders)
    { x: 55, y: 15 }, { x: 55, y: 35 }, { x: 55, y: 50 }, { x: 55, y: 65 }, { x: 55, y: 85 },
    // Striker (1 player)
    { x: 75, y: 50 },
    // Substitutes
    { x: 10, y: 10 }, { x: 10, y: 15 }, { x: 10, y: 20 }, { x: 10, y: 25 }, 
    { x: 10, y: 30 }, { x: 10, y: 35 }, { x: 10, y: 40 }, { x: 10, y: 85 }
  ],
  '5-3-2': [
    // Goalkeeper
    { x: 15, y: 50 },
    // Defense (5 defenders)
    { x: 30, y: 15 }, { x: 30, y: 35 }, { x: 30, y: 50 }, { x: 30, y: 65 }, { x: 30, y: 85 },
    // Midfield (3 midfielders)
    { x: 55, y: 30 }, { x: 55, y: 50 }, { x: 55, y: 70 },
    // Attack (2 attackers)
    { x: 75, y: 40 }, { x: 75, y: 60 },
    // Substitutes
    { x: 10, y: 10 }, { x: 10, y: 15 }, { x: 10, y: 20 }, { x: 10, y: 25 }, 
    { x: 10, y: 30 }, { x: 10, y: 35 }, { x: 10, y: 40 }, { x: 10, y: 85 }
  ]
};

const teamColors = [
  { name: 'Rood', value: 'bg-red-500', hex: '#ef4444' },
  { name: 'Blauw', value: 'bg-blue-500', hex: '#3b82f6' },
  { name: 'Groen', value: 'bg-green-500', hex: '#22c55e' },
  { name: 'Geel', value: 'bg-yellow-500', hex: '#eab308' },
  { name: 'Oranje', value: 'bg-orange-500', hex: '#f97316' },
  { name: 'Paars', value: 'bg-purple-500', hex: '#a855f7' },
  { name: 'Roze', value: 'bg-pink-500', hex: '#ec4899' },
  { name: 'Zwart', value: 'bg-gray-900', hex: '#111827', textColor: 'text-white' },
  { name: 'Wit', value: 'bg-white', hex: '#ffffff', textColor: 'text-gray-900', border: 'border-2 border-gray-400' }
];

export const TeamManagement: React.FC<TeamManagementProps> = ({ onTeamUpdate }) => {
  const [displayMode, setDisplayMode] = useState<'shirts' | 'circles' | 'players'>('shirts');
  const [selectedTeam, setSelectedTeam] = useState<'A' | 'B'>('A');
  
  const [teamA, setTeamA] = useState<Team>({
    id: 'team-a',
    name: 'Ploeg A',
    color: 'bg-red-500',
    players: Array.from({ length: 18 }, (_, i) => ({
      id: `a-${i + 1}`,
      name: `Speler ${i + 1}`,
      number: i + 1,
      position: defaultFormations['4-4-2'][i] || { x: 10, y: 10 + (i * 5) },
      isActive: i < 11
    }))
  });

  const [teamB, setTeamB] = useState<Team>({
    id: 'team-b',
    name: 'Ploeg B',
    color: 'bg-blue-500',
    players: Array.from({ length: 18 }, (_, i) => ({
      id: `b-${i + 1}`,
      name: `Speler ${i + 1}`,
      number: i + 1,
      position: { 
        x: 100 - (defaultFormations['4-4-2'][i]?.x || 90), 
        y: defaultFormations['4-4-2'][i]?.y || (10 + (i * 5))
      },
      isActive: i < 11
    }))
  });

  const updateTeamColor = (team: 'A' | 'B', colorClass: string) => {
    if (team === 'A') {
      const updatedTeam = { ...teamA, color: colorClass };
      setTeamA(updatedTeam);
      onTeamUpdate?.({ teamA: updatedTeam, teamB });
    } else {
      const updatedTeam = { ...teamB, color: colorClass };
      setTeamB(updatedTeam);
      onTeamUpdate?.({ teamA, teamB: updatedTeam });
    }
  };

  const updatePlayerName = (team: 'A' | 'B', playerId: string, name: string) => {
    if (team === 'A') {
      const updatedTeam = {
        ...teamA,
        players: teamA.players.map(p => p.id === playerId ? { ...p, name } : p)
      };
      setTeamA(updatedTeam);
      onTeamUpdate?.({ teamA: updatedTeam, teamB });
    } else {
      const updatedTeam = {
        ...teamB,
        players: teamB.players.map(p => p.id === playerId ? { ...p, name } : p)
      };
      setTeamB(updatedTeam);
      onTeamUpdate?.({ teamA, teamB: updatedTeam });
    }
  };

  const applyFormation = (team: 'A' | 'B', formation: '4-4-2' | '4-3-3') => {
    const positions = defaultFormations[formation];
    
    if (team === 'A') {
      const updatedTeam = {
        ...teamA,
        players: teamA.players.map((player, i) => ({
          ...player,
          position: positions[i] || { x: 10, y: 10 + (i * 5) }
        }))
      };
      setTeamA(updatedTeam);
      onTeamUpdate?.({ teamA: updatedTeam, teamB });
    } else {
      const updatedTeam = {
        ...teamB,
        players: teamB.players.map((player, i) => ({
          ...player,
          position: { 
            x: 100 - (positions[i]?.x || 90), 
            y: positions[i]?.y || (10 + (i * 5))
          }
        }))
      };
      setTeamB(updatedTeam);
      onTeamUpdate?.({ teamA, teamB: updatedTeam });
    }
  };

  const PlayerIcon = ({ player, team }: { player: Player; team: Team }) => {
    const teamColorData = teamColors.find(c => c.value === team.color);
    const textColor = teamColorData?.textColor || 'text-white';
    const borderClass = teamColorData?.border || '';
    
    if (displayMode === 'shirts') {
      return (
        <div className={`relative ${team.color} ${borderClass} rounded-lg p-1 border-2 border-white shadow-lg`}>
          <Shirt className={`w-6 h-6 ${textColor}`} />
          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-white rounded-full flex items-center justify-center text-xs font-bold text-black border border-gray-300">
            {player.number}
          </div>
        </div>
      );
    } else if (displayMode === 'circles') {
      return (
        <div className={`relative ${team.color} ${borderClass} rounded-full w-8 h-8 border-2 border-white shadow-lg flex items-center justify-center ${textColor} font-bold text-xs`}>
          {player.number}
        </div>
      );
    } else {
      // Players mode - mannetjes/vrouwtjes
      return (
        <div className={`relative ${team.color} ${borderClass} rounded-full p-1 border-2 border-white shadow-lg`}>
          <User className={`w-6 h-6 ${textColor}`} />
          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center text-xs font-bold text-black border border-gray-300">
            {player.number}
          </div>
        </div>
      );
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[600px]">
      {/* Team Controls */}
      <div className="lg:col-span-1 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Team Beheer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Display Mode */}
            <div className="space-y-2">
              <Label>Weergave</Label>
              <Select value={displayMode} onValueChange={(value: 'shirts' | 'circles' | 'players') => setDisplayMode(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="shirts">
                    <div className="flex items-center gap-2">
                      <Shirt className="w-4 h-4" />
                      Tenues
                    </div>
                  </SelectItem>
                  <SelectItem value="circles">
                    <div className="flex items-center gap-2">
                      <Circle className="w-4 h-4" />
                      Bolletjes
                    </div>
                  </SelectItem>
                  <SelectItem value="players">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Spelers
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            {/* Team Selection */}
            <Tabs value={selectedTeam} onValueChange={(value: string) => setSelectedTeam(value as 'A' | 'B')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="A">Ploeg A</TabsTrigger>
                <TabsTrigger value="B">Ploeg B</TabsTrigger>
              </TabsList>

              <TabsContent value="A" className="space-y-4">
                <div className="space-y-2">
                  <Label>Kleur Ploeg A</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {teamColors.map((color) => (
                      <Button
                        key={color.value}
                        variant="outline"
                        className={`h-8 ${color.value} ${color.border || ''} ${teamA.color === color.value ? 'ring-2 ring-blue-500' : ''}`}
                        onClick={() => updateTeamColor('A', color.value)}
                      >
                        <span className={color.textColor || 'text-white'}>
                          {color.name}
                        </span>
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Formatie</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" size="sm" onClick={() => applyFormation('A', '4-4-2')}>
                      4-4-2
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => applyFormation('A', '4-3-3')}>
                      4-3-3
                    </Button>
                  </div>
                </div>

                <div className="space-y-2 max-h-[200px] overflow-y-auto">
                  <Label>Spelers</Label>
                  {teamA.players.map((player) => (
                    <div key={player.id} className="flex items-center gap-2">
                      <Badge variant={player.isActive ? "default" : "secondary"}>
                        {player.number}
                      </Badge>
                      <Input
                        value={player.name}
                        onChange={(e) => updatePlayerName('A', player.id, e.target.value)}
                        className="text-xs"
                        size={10}
                      />
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="B" className="space-y-4">
                <div className="space-y-2">
                  <Label>Kleur Ploeg B</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {teamColors.map((color) => (
                      <Button
                        key={color.value}
                        variant="outline"
                        className={`h-8 ${color.value} ${color.border || ''} ${teamB.color === color.value ? 'ring-2 ring-blue-500' : ''}`}
                        onClick={() => updateTeamColor('B', color.value)}
                      >
                        <span className={color.textColor || 'text-white'}>
                          {color.name}
                        </span>
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Formatie</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" size="sm" onClick={() => applyFormation('B', '4-4-2')}>
                      4-4-2
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => applyFormation('B', '4-3-3')}>
                      4-3-3
                    </Button>
                  </div>
                </div>

                <div className="space-y-2 max-h-[200px] overflow-y-auto">
                  <Label>Spelers</Label>
                  {teamB.players.map((player) => (
                    <div key={player.id} className="flex items-center gap-2">
                      <Badge variant={player.isActive ? "default" : "secondary"}>
                        {player.number}
                      </Badge>
                      <Input
                        value={player.name}
                        onChange={(e) => updatePlayerName('B', player.id, e.target.value)}
                        className="text-xs"
                        size={10}
                      />
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Football Field with Teams */}
      <div className="lg:col-span-3">
        <Card className="h-full">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Voetbalveld met Teams</CardTitle>
              <div className="flex gap-2">
                <Badge className={teamA.color}>Ploeg A</Badge>
                <Badge className={teamB.color}>Ploeg B</Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="h-[calc(100%-80px)]">
            <div className="relative w-full h-full bg-green-500 rounded-lg border-4 border-white overflow-hidden">
              {/* Field markings */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 300 200">
                {/* Outer boundary */}
                <rect x="10" y="10" width="280" height="180" fill="none" stroke="white" strokeWidth="2"/>
                
                {/* Center circle */}
                <circle cx="150" cy="100" r="30" fill="none" stroke="white" strokeWidth="2"/>
                <circle cx="150" cy="100" r="2" fill="white"/>
                
                {/* Center line */}
                <line x1="150" y1="10" x2="150" y2="190" stroke="white" strokeWidth="2"/>
                
                {/* Goal areas */}
                <rect x="10" y="70" width="20" height="60" fill="none" stroke="white" strokeWidth="2"/>
                <rect x="270" y="70" width="20" height="60" fill="none" stroke="white" strokeWidth="2"/>
                
                {/* Penalty areas */}
                <rect x="10" y="50" width="40" height="100" fill="none" stroke="white" strokeWidth="2"/>
                <rect x="250" y="50" width="40" height="100" fill="none" stroke="white" strokeWidth="2"/>
                
                {/* Goals */}
                <rect x="5" y="85" width="5" height="30" fill="white"/>
                <rect x="290" y="85" width="5" height="30" fill="white"/>
                
                {/* Corner arcs */}
                <path d="M 10 10 Q 20 10 20 20" fill="none" stroke="white" strokeWidth="2"/>
                <path d="M 290 10 Q 280 10 280 20" fill="none" stroke="white" strokeWidth="2"/>
                <path d="M 10 190 Q 20 190 20 180" fill="none" stroke="white" strokeWidth="2"/>
                <path d="M 290 190 Q 280 190 280 180" fill="none" stroke="white" strokeWidth="2"/>
              </svg>

              {/* Team A Players */}
              {teamA.players.filter(p => p.isActive).map((player) => (
                <div
                  key={player.id}
                  className="absolute cursor-pointer group"
                  style={{
                    left: `${player.position.x}%`,
                    top: `${player.position.y}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                >
                  <PlayerIcon player={player} team={teamA} />
                  <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                    {player.name}
                  </div>
                </div>
              ))}

              {/* Team B Players */}
              {teamB.players.filter(p => p.isActive).map((player) => (
                <div
                  key={player.id}
                  className="absolute cursor-pointer group"
                  style={{
                    left: `${player.position.x}%`,
                    top: `${player.position.y}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                >
                  <PlayerIcon player={player} team={teamB} />
                  <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                    {player.name}
                  </div>
                </div>
              ))}

              {/* Team Labels */}
              <div className="absolute top-4 left-4 bg-black bg-opacity-75 text-white px-3 py-1 rounded">
                <div className="text-sm font-semibold">{teamA.name}</div>
              </div>
              <div className="absolute top-4 right-4 bg-black bg-opacity-75 text-white px-3 py-1 rounded">
                <div className="text-sm font-semibold">{teamB.name}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TeamManagement;