import React, { useState, useRef, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Circle,
  Square,
  Triangle,
  Flag,
  Cone,
  Trash2,
  RotateCcw,
  Save,
  Download,
  Upload,
  Minus,
  MoreHorizontal,
  Edit3,
  Eraser
} from "lucide-react";
import { trainingMaterials } from "./modern-training-materials";

interface PlacedItem {
  id: string;
  materialId: string;
  name: string;
  icon: React.ComponentType<any>;
  color: string;
  x: number;
  y: number;
  rotation?: number;
}

interface DrawnLine {
  id: string;
  type: 'running' | 'passing';
  thickness: 'thin' | 'medium' | 'thick';
  points: { x: number; y: number }[];
  color: string;
}

interface TrainingFieldDesignerProps {
  onSave?: (design: { items: PlacedItem[]; lines: DrawnLine[] }) => void;
  initialDesign?: PlacedItem[];
  initialLines?: DrawnLine[];
}

export const TrainingFieldDesigner: React.FC<TrainingFieldDesignerProps> = ({ 
  onSave, 
  initialDesign = [],
  initialLines = []
}) => {
  const [placedItems, setPlacedItems] = useState<PlacedItem[]>(initialDesign);
  const [drawnLines, setDrawnLines] = useState<DrawnLine[]>(initialLines);
  const [selectedCategory, setSelectedCategory] = useState<string>('ballen');
  const [draggedItem, setDraggedItem] = useState<any>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [drawingMode, setDrawingMode] = useState<'materials' | 'running' | 'passing' | 'eraser'>('materials');
  const [lineThickness, setLineThickness] = useState<'thin' | 'medium' | 'thick'>('medium');
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentLine, setCurrentLine] = useState<DrawnLine | null>(null);
  const fieldRef = useRef<HTMLDivElement>(null);

  // Drag and drop handlers
  const handleDragStart = (item: any) => {
    setDraggedItem(item);
    setIsDragging(true);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedItem || !fieldRef.current) return;

    const rect = fieldRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    // Ensure item stays within field bounds
    if (x >= 0 && x <= 100 && y >= 0 && y <= 100) {
      const newItem: PlacedItem = {
        id: `${draggedItem.id}-${Date.now()}`,
        materialId: draggedItem.id,
        name: draggedItem.name,
        icon: draggedItem.icon,
        color: draggedItem.color,
        x,
        y,
        rotation: 0
      };

      setPlacedItems(prev => [...prev, newItem]);
    }

    setDraggedItem(null);
    setIsDragging(false);
  }, [draggedItem]);

  const removeItem = (id: string) => {
    setPlacedItems(prev => prev.filter(item => item.id !== id));
  };

  const clearField = () => {
    setPlacedItems([]);
    setDrawnLines([]);
  };

  const saveDesign = () => {
    if (onSave) {
      onSave({ items: placedItems, lines: drawnLines });
    }
  };

  // Line drawing handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (drawingMode === 'materials') return;
    
    if (!fieldRef.current) return;
    const rect = fieldRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    if (drawingMode === 'eraser') {
      // Remove line or item at click position
      const clickedItem = placedItems.find(item => {
        const distance = Math.sqrt(Math.pow(item.x - x, 2) + Math.pow(item.y - y, 2));
        return distance < 3;
      });
      if (clickedItem) {
        removeItem(clickedItem.id);
        return;
      }
      
      // Remove lines near click
      setDrawnLines(prev => prev.filter(line => {
        return !line.points.some(point => {
          const distance = Math.sqrt(Math.pow(point.x - x, 2) + Math.pow(point.y - y, 2));
          return distance < 5;
        });
      }));
      return;
    }

    // Start drawing line
    setIsDrawing(true);
    const newLine: DrawnLine = {
      id: `line-${Date.now()}`,
      type: drawingMode as 'running' | 'passing',
      thickness: lineThickness,
      points: [{ x, y }],
      color: drawingMode === 'running' ? '#3b82f6' : '#ef4444'
    };
    setCurrentLine(newLine);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDrawing || !currentLine || !fieldRef.current) return;
    
    const rect = fieldRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    setCurrentLine(prev => prev ? {
      ...prev,
      points: [...prev.points, { x, y }]
    } : null);
  };

  const handleMouseUp = () => {
    if (!isDrawing || !currentLine) return;
    
    if (currentLine.points.length > 1) {
      setDrawnLines(prev => [...prev, currentLine]);
    }
    
    setIsDrawing(false);
    setCurrentLine(null);
  };

  const exportDesign = () => {
    const dataStr = JSON.stringify({ items: placedItems, lines: drawnLines }, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'training-design.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  const getLineStyle = (line: DrawnLine) => {
    const strokeWidth = line.thickness === 'thin' ? 2 : line.thickness === 'medium' ? 4 : 6;
    const strokeDasharray = line.type === 'running' ? '8,4' : 'none';
    return { strokeWidth, strokeDasharray, stroke: line.color, fill: 'none' };
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[800px]">
      {/* Material Palette */}
      <div className="lg:col-span-1 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Trainingsmaterialen</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Drawing Mode Selection */}
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-1">
                <Button
                  variant={drawingMode === 'materials' ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDrawingMode('materials')}
                >
                  Materialen
                </Button>
                <Button
                  variant={drawingMode === 'running' ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDrawingMode('running')}
                >
                  <MoreHorizontal className="w-4 h-4 mr-1" />
                  Looplijn
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-1">
                <Button
                  variant={drawingMode === 'passing' ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDrawingMode('passing')}
                >
                  <Minus className="w-4 h-4 mr-1" />
                  Paslijn
                </Button>
                <Button
                  variant={drawingMode === 'eraser' ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDrawingMode('eraser')}
                >
                  <Eraser className="w-4 h-4 mr-1" />
                  Gum
                </Button>
              </div>
            </div>

            {/* Line Thickness */}
            {(drawingMode === 'running' || drawingMode === 'passing') && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Lijndikte</label>
                <div className="grid grid-cols-3 gap-1">
                  <Button
                    variant={lineThickness === 'thin' ? "default" : "outline"}
                    size="sm"
                    onClick={() => setLineThickness('thin')}
                  >
                    Dun
                  </Button>
                  <Button
                    variant={lineThickness === 'medium' ? "default" : "outline"}
                    size="sm"
                    onClick={() => setLineThickness('medium')}
                  >
                    Normaal
                  </Button>
                  <Button
                    variant={lineThickness === 'thick' ? "default" : "outline"}
                    size="sm"
                    onClick={() => setLineThickness('thick')}
                  >
                    Dik
                  </Button>
                </div>
              </div>
            )}

            <Separator />

            {/* Category Tabs - Only show when in materials mode */}
            {drawingMode === 'materials' && (
              <>
                <div className="grid grid-cols-2 gap-1">
                  {Object.keys(trainingMaterials).map((category) => (
                    <Button
                      key={category}
                      variant={selectedCategory === category ? "default" : "outline"}
                      size="sm"
                      className="text-xs capitalize"
                      onClick={() => setSelectedCategory(category)}
                    >
                      {category}
                    </Button>
                  ))}
                </div>
                <Separator />
              </>
            )}

            {/* Material Items - Only show in materials mode */}
            {drawingMode === 'materials' && (
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {trainingMaterials[selectedCategory as keyof typeof trainingMaterials]?.map((item) => {
                  const Icon = item.icon;
                  return (
                    <div
                      key={item.id}
                      draggable
                      onDragStart={() => handleDragStart(item)}
                      className="flex items-center gap-2 p-2 border rounded-lg cursor-grab hover:bg-accent transition-colors"
                    >
                      <div className={`w-8 h-8 rounded-full ${item.color} flex items-center justify-center`}>
                        <Icon className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-sm font-medium truncate">{item.name}</span>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Drawing Instructions */}
            {drawingMode !== 'materials' && (
              <div className="space-y-2 p-3 bg-blue-50 rounded-lg border">
                <h4 className="font-medium text-sm">Tekenmode Instructies</h4>
                <div className="text-xs space-y-1">
                  {drawingMode === 'running' && (
                    <p>• Sleep met de muis om een stippellijn (looplijn) te tekenen</p>
                  )}
                  {drawingMode === 'passing' && (
                    <p>• Sleep met de muis om een volle lijn (paslijn) te tekenen</p>
                  )}
                  {drawingMode === 'eraser' && (
                    <p>• Klik op materialen of lijnen om ze te verwijderen</p>
                  )}
                </div>
              </div>
            )}

            {/* Controls */}
            <Separator />
            <div className="space-y-2">
              <Button onClick={clearField} variant="outline" size="sm" className="w-full">
                <RotateCcw className="w-4 h-4 mr-2" />
                Veld leegmaken
              </Button>
              <Button onClick={saveDesign} size="sm" className="w-full">
                <Save className="w-4 h-4 mr-2" />
                Ontwerp opslaan
              </Button>
              <Button onClick={exportDesign} variant="outline" size="sm" className="w-full">
                <Download className="w-4 h-4 mr-2" />
                Exporteren
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Football Field */}
      <div className="lg:col-span-3">
        <Card className="h-full">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Voetbalveld Designer</CardTitle>
              <div className="flex gap-2">
                <Badge variant="secondary">
                  {placedItems.length} materialen
                </Badge>
                <Badge variant="outline">
                  {drawnLines.length} lijnen
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="h-[calc(100%-80px)]">
            <div
              ref={fieldRef}
              className="relative w-full h-full bg-green-500 rounded-lg border-4 border-white overflow-hidden"
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              style={{ cursor: drawingMode === 'materials' ? 'default' : drawingMode === 'eraser' ? 'crosshair' : 'crosshair' }}
            >
              {/* Field markings */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 300 200">
                {/* Outer boundary */}
                <rect x="10" y="10" width="280" height="180" fill="none" stroke="white" strokeWidth="2"/>
                
                {/* Center circle */}
                <circle cx="150" cy="100" r="30" fill="none" stroke="white" strokeWidth="2"/>
                <circle cx="150" cy="100" r="2" fill="white"/>
                
                {/* Center line */}
                <line x1="150" y1="10" x2="150" y2="190" stroke="white" strokeWidth="2"/>
                
                {/* Goal areas */}
                <rect x="10" y="70" width="20" height="60" fill="none" stroke="white" strokeWidth="2"/>
                <rect x="270" y="70" width="20" height="60" fill="none" stroke="white" strokeWidth="2"/>
                
                {/* Penalty areas */}
                <rect x="10" y="50" width="40" height="100" fill="none" stroke="white" strokeWidth="2"/>
                <rect x="250" y="50" width="40" height="100" fill="none" stroke="white" strokeWidth="2"/>
                
                {/* Goals */}
                <rect x="5" y="85" width="5" height="30" fill="white"/>
                <rect x="290" y="85" width="5" height="30" fill="white"/>
                
                {/* Corner arcs */}
                <path d="M 10 10 Q 20 10 20 20" fill="none" stroke="white" strokeWidth="2"/>
                <path d="M 290 10 Q 280 10 280 20" fill="none" stroke="white" strokeWidth="2"/>
                <path d="M 10 190 Q 20 190 20 180" fill="none" stroke="white" strokeWidth="2"/>
                <path d="M 290 190 Q 280 190 280 180" fill="none" stroke="white" strokeWidth="2"/>

                {/* Drawn Lines */}
                {drawnLines.map((line) => {
                  const pathData = line.points
                    .map((point, index) => `${index === 0 ? 'M' : 'L'} ${(point.x / 100) * 300} ${(point.y / 100) * 200}`)
                    .join(' ');
                  const style = getLineStyle(line);
                  return (
                    <path
                      key={line.id}
                      d={pathData}
                      stroke={style.stroke}
                      strokeWidth={style.strokeWidth}
                      strokeDasharray={style.strokeDasharray}
                      fill={style.fill}
                      opacity={0.8}
                    />
                  );
                })}

                {/* Current drawing line */}
                {currentLine && currentLine.points.length > 0 && (
                  <path
                    d={currentLine.points
                      .map((point, index) => `${index === 0 ? 'M' : 'L'} ${(point.x / 100) * 300} ${(point.y / 100) * 200}`)
                      .join(' ')}
                    stroke={currentLine.color}
                    strokeWidth={getLineStyle(currentLine).strokeWidth}
                    strokeDasharray={getLineStyle(currentLine).strokeDasharray}
                    fill="none"
                    opacity={0.6}
                  />
                )}
              </svg>

              {/* Placed Items */}
              {placedItems.map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.id}
                    className="absolute group"
                    style={{
                      left: `${item.x}%`,
                      top: `${item.y}%`,
                      transform: 'translate(-50%, -50%)'
                    }}
                  >
                    <div className={`w-8 h-8 rounded-full ${item.color} flex items-center justify-center shadow-lg border-2 border-white cursor-pointer transition-transform hover:scale-110`}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    
                    {/* Remove button (appears on hover) */}
                    <button
                      onClick={() => removeItem(item.id)}
                      className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-xs"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                    
                    {/* Label */}
                    <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                      {item.name}
                    </div>
                  </div>
                );
              })}

              {/* Drop hint */}
              {isDragging && (
                <div className="absolute inset-0 bg-blue-500 bg-opacity-20 border-2 border-dashed border-blue-400 flex items-center justify-center">
                  <div className="text-blue-800 font-semibold text-lg">
                    Sleep materiaal hierheen
                  </div>
                </div>
              )}

              {/* Instructions when empty */}
              {placedItems.length === 0 && !isDragging && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white bg-black bg-opacity-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Voetbalveld Designer</h3>
                    <p className="text-sm">Sleep materialen van de linkerzijde naar het veld</p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TrainingFieldDesigner;