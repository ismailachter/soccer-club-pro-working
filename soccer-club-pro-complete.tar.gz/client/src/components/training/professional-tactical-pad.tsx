import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Save,
  FolderOpen,
  Settings,
  Share2,
  Layers,
  Mountain,
  Box,
  GitBranch,
  MousePointer,
  Move,
  Edit3,
  Eraser,
  Circle,
  Square,
  ArrowRight,
  Minus,
  Users,
  RotateCcw,
  Play,
  Pause,
  SkipForward,
  Upload,
  Download
} from "lucide-react";

interface TacticalElement {
  id: string;
  type: 'player' | 'ball' | 'cone' | 'arrow' | 'line' | 'zone' | 'text';
  x: number;
  y: number;
  color: string;
  size: 'small' | 'medium' | 'large';
  label?: string;
  team?: 'home' | 'away';
  points?: { x: number; y: number }[];
  text?: string;
  isDashed?: boolean;
  animationSequence?: number;
  startPosition?: { x: number; y: number };
  endPosition?: { x: number; y: number };
}

interface Formation {
  name: string;
  positions: { x: number; y: number }[];
}

interface Team {
  name: string;
  color: string;
  logo?: string;
  year?: string;
  formation: string;
}

interface FieldDimensions {
  name: string;
  width: number;
  height: number;
  description: string;
  goalWidth: number;
  penaltyAreaWidth: number;
  penaltyAreaHeight: number;
  goalAreaWidth: number;
  goalAreaHeight: number;
  centerCircleRadius: number;
  penaltySpotDistance: number;
}

const formations: Formation[] = [
  {
    name: '4-4-2',
    positions: [
      { x: 8, y: 50 }, // GK
      { x: 25, y: 15 }, { x: 25, y: 35 }, { x: 25, y: 65 }, { x: 25, y: 85 }, // Defense
      { x: 50, y: 20 }, { x: 50, y: 40 }, { x: 50, y: 60 }, { x: 50, y: 80 }, // Midfield
      { x: 75, y: 30 }, { x: 75, y: 70 } // Attack
    ]
  },
  {
    name: '4-3-3',
    positions: [
      { x: 8, y: 50 }, // GK
      { x: 25, y: 15 }, { x: 25, y: 35 }, { x: 25, y: 65 }, { x: 25, y: 85 }, // Defense
      { x: 50, y: 25 }, { x: 50, y: 50 }, { x: 50, y: 75 }, // Midfield
      { x: 75, y: 20 }, { x: 75, y: 50 }, { x: 75, y: 80 } // Attack
    ]
  },
  {
    name: '3-5-2',
    positions: [
      { x: 8, y: 50 }, // GK
      { x: 25, y: 25 }, { x: 25, y: 50 }, { x: 25, y: 75 }, // Defense
      { x: 45, y: 10 }, { x: 45, y: 30 }, { x: 45, y: 50 }, { x: 45, y: 70 }, { x: 45, y: 90 }, // Midfield
      { x: 75, y: 35 }, { x: 75, y: 65 } // Attack
    ]
  },
  {
    name: '4-2-3-1',
    positions: [
      { x: 8, y: 50 }, // GK
      { x: 25, y: 15 }, { x: 25, y: 35 }, { x: 25, y: 65 }, { x: 25, y: 85 }, // Defense
      { x: 45, y: 35 }, { x: 45, y: 65 }, // Defensive Mid
      { x: 65, y: 20 }, { x: 65, y: 50 }, { x: 65, y: 80 }, // Attacking Mid
      { x: 85, y: 50 } // Striker
    ]
  },
  {
    name: '3-4-3',
    positions: [
      { x: 8, y: 50 }, // GK
      { x: 25, y: 25 }, { x: 25, y: 50 }, { x: 25, y: 75 }, // Defense
      { x: 50, y: 15 }, { x: 50, y: 40 }, { x: 50, y: 60 }, { x: 50, y: 85 }, // Midfield
      { x: 75, y: 25 }, { x: 75, y: 50 }, { x: 75, y: 75 } // Attack
    ]
  }
];

const fieldSizes: FieldDimensions[] = [
  {
    name: 'full',
    width: 105,
    height: 68,
    description: 'Volledig veld (105x68m)',
    goalWidth: 7.32,
    penaltyAreaWidth: 16.5,
    penaltyAreaHeight: 40.32,
    goalAreaWidth: 5.5,
    goalAreaHeight: 18.32,
    centerCircleRadius: 9.15,
    penaltySpotDistance: 11
  },
  {
    name: 'half',
    width: 52.5,
    height: 68,
    description: 'Half veld (52.5x68m)',
    goalWidth: 7.32,
    penaltyAreaWidth: 16.5,
    penaltyAreaHeight: 40.32,
    goalAreaWidth: 5.5,
    goalAreaHeight: 18.32,
    centerCircleRadius: 9.15,
    penaltySpotDistance: 11
  },
  {
    name: 'quarter',
    width: 52.5,
    height: 34,
    description: 'Kwart veld (52.5x34m)',
    goalWidth: 5,
    penaltyAreaWidth: 12,
    penaltyAreaHeight: 20,
    goalAreaWidth: 4,
    goalAreaHeight: 12,
    centerCircleRadius: 6,
    penaltySpotDistance: 8
  },
  {
    name: 'small',
    width: 75,
    height: 50,
    description: 'Klein veld (75x50m)',
    goalWidth: 6,
    penaltyAreaWidth: 14,
    penaltyAreaHeight: 30,
    goalAreaWidth: 4.5,
    goalAreaHeight: 15,
    centerCircleRadius: 7,
    penaltySpotDistance: 9
  },
  {
    name: 'mini',
    width: 40,
    height: 30,
    description: 'Mini veld (40x30m)',
    goalWidth: 4,
    penaltyAreaWidth: 8,
    penaltyAreaHeight: 16,
    goalAreaWidth: 3,
    goalAreaHeight: 10,
    centerCircleRadius: 4,
    penaltySpotDistance: 6
  }
];

const tools = [
  { id: 'select', name: 'Selecteren', icon: MousePointer },
  { id: 'move', name: 'Verplaatsen', icon: Move },
  { id: 'player', name: 'Speler', icon: Circle },
  { id: 'ball', name: 'Bal', icon: Circle },
  { id: 'cone', name: 'Pionnetje', icon: Square },
  { id: 'arrow', name: 'Pijl', icon: ArrowRight },
  { id: 'line', name: 'Lijn', icon: Minus },
  { id: 'zone', name: 'Zone', icon: Square },
  { id: 'text', name: 'Tekst', icon: Edit3 },
  { id: 'eraser', name: 'Gum', icon: Eraser }
];

const adjustBrightness = (hex: string, percent: number) => {
  const num = parseInt(hex.replace("#", ""), 16);
  const amt = Math.round(2.55 * percent);
  const R = (num >> 16) + amt;
  const G = (num >> 8 & 0x00FF) + amt;
  const B = (num & 0x0000FF) + amt;
  return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
    (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
    (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
};

export const ProfessionalTacticalPad: React.FC = () => {
  const [elements, setElements] = useState<TacticalElement[]>([]);
  const [selectedTool, setSelectedTool] = useState('select');
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState<{ x: number; y: number }[]>([]);
  const [showTeamDialog, setShowTeamDialog] = useState(false);
  const [showToolsDialog, setShowToolsDialog] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [animationStep, setAnimationStep] = useState(0);
  const [lineThickness, setLineThickness] = useState<'small' | 'medium' | 'large'>('medium');
  const [selectedColor, setSelectedColor] = useState('#ffffff');
  const [isDashed, setIsDashed] = useState(false);
  const [animationSequences, setAnimationSequences] = useState<{[key: number]: TacticalElement[]}>({});
  const [currentSequence, setCurrentSequence] = useState(0);
  const [maxSequences, setMaxSequences] = useState(1);
  const [showAnimationControls, setShowAnimationControls] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [selectedFieldSize, setSelectedFieldSize] = useState('full');
  const [showFieldDialog, setShowFieldDialog] = useState(false);
  const [pitchColor, setPitchColor] = useState('#2d5016');
  const [pitchSide, setPitchSide] = useState('full');
  const [cameraView, setCameraView] = useState('2d');
  
  const fieldRef = useRef<HTMLDivElement>(null);

  const getCurrentFieldSize = () => {
    return fieldSizes.find(field => field.name === selectedFieldSize) || fieldSizes[0];
  };

  const [homeTeam, setHomeTeam] = useState<Team>({
    name: 'YYC',
    color: '#3b82f6',
    year: '1950',
    formation: '4-4-2'
  });

  const [awayTeam, setAwayTeam] = useState<Team>({
    name: 'ACM',
    color: '#f97316',
    year: '1899',
    formation: '4-4-2'
  });

  const handleFieldClick = (e: React.MouseEvent) => {
    if (!fieldRef.current) return;
    
    const rect = fieldRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    if (selectedTool === 'select') {
      const clickedElement = elements.find(el => {
        const distance = Math.sqrt(Math.pow(el.x - x, 2) + Math.pow(el.y - y, 2));
        return distance < 3;
      });
      setSelectedElement(clickedElement?.id || null);
    } else if (selectedTool === 'eraser') {
      const newElements = elements.filter(el => {
        const distance = Math.sqrt(Math.pow(el.x - x, 2) + Math.pow(el.y - y, 2));
        return distance >= 3;
      });
      setElements(newElements);
    } else if (['player', 'ball', 'cone'].includes(selectedTool)) {
      const newElement: TacticalElement = {
        id: `${selectedTool}-${Date.now()}`,
        type: selectedTool as 'player' | 'ball' | 'cone',
        x,
        y,
        color: selectedTool === 'player' ? (x < 50 ? homeTeam.color : awayTeam.color) : '#ffffff',
        size: 'medium',
        team: selectedTool === 'player' ? (x < 50 ? 'home' : 'away') : undefined,
        label: selectedTool === 'player' ? String(elements.filter(el => el.type === 'player' && el.team === (x < 50 ? 'home' : 'away')).length + 1) : undefined
      };
      setElements(prev => [...prev, newElement]);
    } else if (['arrow', 'line'].includes(selectedTool)) {
      if (!isDrawing) {
        setIsDrawing(true);
        setCurrentPath([{ x, y }]);
      } else {
        const newElement: TacticalElement = {
          id: `${selectedTool}-${Date.now()}`,
          type: selectedTool as 'arrow' | 'line',
          x: currentPath[0].x,
          y: currentPath[0].y,
          color: selectedColor,
          size: lineThickness,
          points: [...currentPath, { x, y }]
        };
        setElements(prev => [...prev, newElement]);
        setIsDrawing(false);
        setCurrentPath([]);
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!fieldRef.current || !isDrawing) return;
    
    const rect = fieldRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    setCurrentPath(prev => [...prev.slice(0, -1), { x, y }]);
  };

  const applyFormation = (team: 'home' | 'away', formationName: string) => {
    const formation = formations.find(f => f.name === formationName);
    if (!formation) return;

    // Remove existing players for this team
    const otherTeamPlayers = elements.filter(el => el.type !== 'player' || el.team !== team);
    
    // Create new players with formation positions
    const newPlayers: TacticalElement[] = formation.positions.map((pos, index) => {
      const adjustedX = team === 'away' ? 100 - pos.x : pos.x;
      return {
        id: `player-${team}-${index + 1}`,
        type: 'player',
        x: adjustedX,
        y: pos.y,
        color: team === 'home' ? homeTeam.color : awayTeam.color,
        size: 'medium' as const,
        team,
        label: String(index + 1)
      };
    });

    setElements([...otherTeamPlayers, ...newPlayers]);
  };

  const clearField = () => {
    setElements([]);
    setSelectedElement(null);
  };

  const saveSequence = () => {
    setAnimationSequences(prev => ({
      ...prev,
      [currentSequence]: [...elements]
    }));
  };

  const loadSequence = (sequenceNum: number) => {
    const sequence = animationSequences[sequenceNum];
    if (sequence) {
      setElements(sequence);
      setCurrentSequence(sequenceNum);
    }
  };

  const addNewSequence = () => {
    const newSequenceNum = maxSequences;
    setAnimationSequences(prev => ({
      ...prev,
      [newSequenceNum]: [...elements]
    }));
    setMaxSequences(prev => prev + 1);
    setCurrentSequence(newSequenceNum);
  };

  const playAnimation = () => {
    if (isPlaying) {
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    let sequenceIndex = 0;
    const sequences = Object.keys(animationSequences).map(Number).sort();
    
    const playNext = () => {
      if (sequenceIndex < sequences.length && isPlaying) {
        loadSequence(sequences[sequenceIndex]);
        sequenceIndex++;
        setTimeout(playNext, 2000 / playbackSpeed);
      } else {
        setIsPlaying(false);
      }
    };
    
    playNext();
  };

  const exportAnimation = () => {
    const animation = {
      homeTeam,
      awayTeam,
      sequences: animationSequences,
      metadata: {
        title: "Tactical Animation",
        duration: Object.keys(animationSequences).length * 2,
        speed: playbackSpeed,
        created: new Date().toISOString()
      }
    };
    
    const dataStr = JSON.stringify(animation, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `tactical-animation-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const saveProject = () => {
    exportAnimation();
  };

  const renderElement = (element: TacticalElement) => {
    const isSelected = selectedElement === element.id;
    const sizeMap = { small: 6, medium: 8, large: 12 };
    const size = sizeMap[element.size];

    if (element.type === 'player') {
      return (
        <div
          key={element.id}
          className={`absolute transition-all duration-200 ${isSelected ? 'scale-110 ring-2 ring-white' : ''}`}
          style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            transform: 'translate(-50%, -50%)'
          }}
        >
          <div 
            className="rounded-full border-2 border-white shadow-lg flex items-center justify-center text-white font-bold text-xs cursor-pointer"
            style={{ 
              backgroundColor: element.color, 
              width: `${size * 4}px`, 
              height: `${size * 4}px` 
            }}
          >
            {element.label}
          </div>
        </div>
      );
    }

    if (element.type === 'ball') {
      return (
        <div
          key={element.id}
          className={`absolute transition-all duration-200 ${isSelected ? 'scale-110 ring-2 ring-white' : ''}`}
          style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            transform: 'translate(-50%, -50%)'
          }}
        >
          <div 
            className="rounded-full border-2 border-gray-800 shadow-lg cursor-pointer"
            style={{ 
              backgroundColor: '#ffffff', 
              width: `${size * 3}px`, 
              height: `${size * 3}px`,
              background: 'radial-gradient(circle at 30% 30%, #ffffff, #f0f0f0, #e0e0e0)'
            }}
          />
        </div>
      );
    }

    if (element.type === 'cone') {
      return (
        <div
          key={element.id}
          className={`absolute transition-all duration-200 ${isSelected ? 'scale-110 ring-2 ring-white' : ''}`}
          style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            transform: 'translate(-50%, -50%)'
          }}
        >
          <div 
            className="border-2 border-white shadow-lg cursor-pointer"
            style={{ 
              backgroundColor: '#fbbf24',
              width: `${size * 2}px`, 
              height: `${size * 3}px`,
              clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)'
            }}
          />
        </div>
      );
    }

    return null;
  };

  const renderLines = () => {
    return elements
      .filter(el => el.type === 'arrow' || el.type === 'line')
      .map(element => {
        if (!element.points || element.points.length < 2) return null;
        
        const pathData = element.points
          .map((point, index) => `${index === 0 ? 'M' : 'L'} ${(point.x / 100) * 100} ${(point.y / 100) * 100}`)
          .join(' ');

        return (
          <g key={element.id}>
            <path
              d={pathData}
              stroke={element.color}
              strokeWidth={element.size === 'small' ? 2 : element.size === 'medium' ? 3 : 4}
              fill="none"
              markerEnd={element.type === 'arrow' ? 'url(#arrowhead)' : undefined}
            />
          </g>
        );
      });
  };

  return (
    <div className="relative h-[600px] bg-gray-800 rounded-lg overflow-hidden">
      {/* Left Panel - Home Team */}
      <div className="absolute left-4 top-1/2 transform -translate-y-1/2 space-y-4 z-20">
        <div 
          className="bg-white rounded-lg p-3 shadow-lg cursor-pointer hover:shadow-xl transition-shadow"
          onClick={() => setShowTeamDialog(true)}
        >
          <div 
            className="w-16 h-16 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-md"
            style={{ backgroundColor: homeTeam.color }}
          >
            {homeTeam.name}
          </div>
          <div className="text-xs text-center mt-1 text-gray-600">{homeTeam.year}</div>
        </div>
        
        <div 
          className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg p-3 text-center cursor-pointer transition-colors"
          onClick={() => setShowTeamDialog(true)}
        >
          <Users className="w-6 h-6 mx-auto mb-1" />
          <div className="text-xs">Menu</div>
        </div>
      </div>

      {/* Right Panel - Away Team */}
      <div className="absolute right-4 top-1/2 transform -translate-y-1/2 space-y-4 z-20">
        <div 
          className="bg-white rounded-lg p-3 shadow-lg cursor-pointer hover:shadow-xl transition-shadow"
          onClick={() => setShowTeamDialog(true)}
        >
          <div 
            className="w-16 h-16 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-md"
            style={{ backgroundColor: awayTeam.color }}
          >
            {awayTeam.name}
          </div>
          <div className="text-xs text-center mt-1 text-gray-600">{awayTeam.year}</div>
        </div>
        
        <div 
          className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg p-3 text-center cursor-pointer transition-colors"
          onClick={() => setShowToolsDialog(true)}
        >
          <Edit3 className="w-6 h-6 mx-auto mb-1" />
          <div className="text-xs">Tools</div>
        </div>
      </div>

      {/* Professional Top Toolbar */}
      <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 h-20 z-20 flex items-center justify-between px-4">
        
        {/* Left Side - Field Templates */}
        <div className="flex items-center space-x-2">
          <div className="text-white text-xs font-medium mb-1">Veld templates:</div>
          <div className="flex space-x-1">
            {fieldSizes.map((field, index) => (
              <div
                key={field.name}
                onClick={() => {
                  setSelectedFieldSize(field.name);
                  setElements([]);
                }}
                className={`relative cursor-pointer group ${
                  selectedFieldSize === field.name ? 'ring-2 ring-yellow-400' : ''
                }`}
              >
                <div className="w-16 h-12 bg-green-600 border border-white/30 relative">
                  {/* Mini field representation */}
                  <div className="absolute inset-0.5 border border-white/50">
                    {field.name !== 'mini' && (
                      <>
                        <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-2 h-4 border border-white/50"></div>
                        {field.name === 'full' && (
                          <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-2 h-4 border border-white/50"></div>
                        )}
                        <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/50"></div>
                        <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full border border-white/50"></div>
                      </>
                    )}
                  </div>
                </div>
                <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                  {field.name === 'full' ? 'Volledig' :
                   field.name === 'half' ? 'Half' :
                   field.name === 'quarter' ? 'Kwart' :
                   field.name === 'small' ? 'Klein' :
                   'Mini'}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Center - Pitch Color and Side Selection */}
        <div className="flex items-center space-x-8">
          
          {/* Pitch Color */}
          <div className="flex flex-col items-center">
            <div className="text-white text-xs mb-1">Select Pitch Color</div>
            <div className="flex space-x-1">
              {[
                { name: 'Green', color: '#2d5016' },
                { name: 'Blue', color: '#1e3a8a' },
                { name: 'Red', color: '#7f1d1d' },
                { name: 'Black', color: '#1f2937' },
                { name: 'White', color: '#f3f4f6' }
              ].map((fieldColor) => (
                <div
                  key={fieldColor.name}
                  className="flex flex-col items-center cursor-pointer group"
                  onClick={() => setPitchColor(fieldColor.color)}
                >
                  <div 
                    className={`w-4 h-4 rounded border-2 hover:scale-110 transition-transform ${
                      pitchColor === fieldColor.color ? 'border-yellow-400' : 'border-white/50'
                    }`}
                    style={{ backgroundColor: fieldColor.color }}
                  ></div>
                  <div className="text-white text-xs mt-1">{fieldColor.name}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Pitch Side */}
          <div className="flex flex-col items-center">
            <div className="text-white text-xs mb-1">Select Pitch Side</div>
            <div className="flex space-x-1">
              <div className="flex flex-col items-center cursor-pointer group">
                <div className="w-8 h-6 bg-green-600 border border-white/50 relative">
                  <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-1 h-2 bg-white"></div>
                </div>
                <div className="text-white text-xs mt-1">Attacked</div>
              </div>
              <div className="flex flex-col items-center cursor-pointer group">
                <div className="w-8 h-6 bg-green-600 border border-white/50 relative">
                  <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-1 h-2 bg-white"></div>
                </div>
                <div className="text-white text-xs mt-1">Defended</div>
              </div>
              <div className="flex flex-col items-center cursor-pointer group">
                <div className="w-8 h-6 bg-green-600 border border-white/50 relative">
                  <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-1 h-2 bg-white"></div>
                  <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-1 h-2 bg-white"></div>
                </div>
                <div className="text-white text-xs mt-1">Full</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Camera Views */}
        <div className="flex flex-col items-center">
          <div className="text-white text-xs mb-1">Select Camera View</div>
          <div className="flex space-x-1">
            <div className="flex flex-col items-center cursor-pointer group">
              <div className="w-12 h-8 bg-blue-700 border border-white/50 rounded flex items-center justify-center">
                <span className="text-white text-xs">2D</span>
              </div>
              <div className="text-white text-xs mt-1">Top</div>
            </div>
            <div className="flex flex-col items-center cursor-pointer group">
              <div className="w-12 h-8 bg-blue-600 border border-white/50 rounded flex items-center justify-center">
                <span className="text-white text-xs">45°</span>
              </div>
              <div className="text-white text-xs mt-1">45 Degree</div>
            </div>
            <div className="flex flex-col items-center cursor-pointer group">
              <div className="w-12 h-8 bg-blue-500 border border-white/50 rounded flex items-center justify-center">
                <span className="text-white text-xs">3D</span>
              </div>
              <div className="text-white text-xs mt-1">Rotation</div>
            </div>
          </div>
        </div>
      </div>

      {/* Football Field */}
      <div className="absolute inset-x-20 top-24 bottom-20">
        <div
          ref={fieldRef}
          className="relative w-full h-full"
          onClick={handleFieldClick}
          onMouseMove={handleMouseMove}
          style={{ cursor: selectedTool === 'select' ? 'default' : 'crosshair' }}
        >
          {/* Field Background - Dynamic color */}
          <div className="absolute inset-0" style={{
            backgroundColor: pitchColor
          }}></div>
          
          {/* Authentic grass stripes pattern */}
          <div className="absolute inset-0" style={{
            background: `repeating-linear-gradient(
              90deg,
              rgba(45, 80, 22, 0.8) 0px,
              rgba(45, 80, 22, 0.8) 8px,
              rgba(58, 95, 30, 0.8) 8px,
              rgba(58, 95, 30, 0.8) 16px
            )`
          }}></div>
          
          {/* Natural grass texture overlay */}
          <div className="absolute inset-0 opacity-30">
            <svg width="100%" height="100%">
              <defs>
                <pattern id="grassTexture" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
                  <rect width="60" height="60" fill="rgba(0,0,0,0.05)" />
                  <circle cx="15" cy="15" r="1" fill="rgba(0,0,0,0.1)" />
                  <circle cx="45" cy="30" r="0.8" fill="rgba(0,0,0,0.08)" />
                  <circle cx="30" cy="45" r="1.2" fill="rgba(0,0,0,0.06)" />
                  <rect x="20" y="10" width="20" height="1" fill="rgba(0,0,0,0.03)" />
                  <rect x="10" y="35" width="15" height="1" fill="rgba(0,0,0,0.04)" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grassTexture)" />
            </svg>
          </div>
          
          {/* Field markings */}
          <svg className="absolute inset-0 w-full h-full" viewBox={`0 0 ${getCurrentFieldSize().width} ${getCurrentFieldSize().height}`} preserveAspectRatio="none">
            <defs>
              <marker
                id="arrowhead"
                markerWidth="2"
                markerHeight="2"
                refX="1.8"
                refY="1"
                orient="auto"
                markerUnits="strokeWidth"
              >
                <polygon
                  points="0 0, 2 1, 0 2"
                  fill="white"
                />
              </marker>
            </defs>

            {(() => {
              const field = getCurrentFieldSize();
              const centerX = field.width / 2;
              const centerY = field.height / 2;
              const goalAreaY = (field.height - field.goalAreaHeight) / 2;
              const penaltyAreaY = (field.height - field.penaltyAreaHeight) / 2;
              const goalY = (field.height - field.goalWidth) / 2;

              return (
                <>
                  {/* Outer boundary */}
                  <rect x="0" y="0" width={field.width} height={field.height} fill="none" stroke="white" strokeWidth="0.2"/>
                  
                  {/* Center circle and line (only for larger fields) */}
                  {field.name !== 'mini' && (
                    <>
                      <circle cx={centerX} cy={centerY} r={field.centerCircleRadius} fill="none" stroke="white" strokeWidth="0.2"/>
                      <circle cx={centerX} cy={centerY} r="0.3" fill="white"/>
                      <line x1={centerX} y1="0" x2={centerX} y2={field.height} stroke="white" strokeWidth="0.2"/>
                    </>
                  )}
                  
                  {/* Goal areas */}
                  <rect x="0" y={goalAreaY} width={field.goalAreaWidth} height={field.goalAreaHeight} fill="none" stroke="white" strokeWidth="0.2"/>
                  {selectedFieldSize !== 'half' && (
                    <rect x={field.width - field.goalAreaWidth} y={goalAreaY} width={field.goalAreaWidth} height={field.goalAreaHeight} fill="none" stroke="white" strokeWidth="0.2"/>
                  )}
                  
                  {/* Penalty areas */}
                  <rect x="0" y={penaltyAreaY} width={field.penaltyAreaWidth} height={field.penaltyAreaHeight} fill="none" stroke="white" strokeWidth="0.2"/>
                  {selectedFieldSize !== 'half' && (
                    <rect x={field.width - field.penaltyAreaWidth} y={penaltyAreaY} width={field.penaltyAreaWidth} height={field.penaltyAreaHeight} fill="none" stroke="white" strokeWidth="0.2"/>
                  )}
                  
                  {/* Penalty spots */}
                  <circle cx={field.penaltySpotDistance} cy={centerY} r="0.3" fill="white"/>
                  {selectedFieldSize !== 'half' && (
                    <circle cx={field.width - field.penaltySpotDistance} cy={centerY} r="0.3" fill="white"/>
                  )}
                  
                  {/* Penalty arcs (only for larger fields) */}
                  {field.name !== 'mini' && field.name !== 'quarter' && (
                    <>
                      <path d={`M ${field.penaltySpotDistance + field.centerCircleRadius} ${penaltyAreaY} A ${field.centerCircleRadius} ${field.centerCircleRadius} 0 0 1 ${field.penaltySpotDistance + field.centerCircleRadius} ${penaltyAreaY + field.penaltyAreaHeight}`} fill="none" stroke="white" strokeWidth="0.2"/>
                      {selectedFieldSize !== 'half' && (
                        <path d={`M ${field.width - field.penaltySpotDistance - field.centerCircleRadius} ${penaltyAreaY} A ${field.centerCircleRadius} ${field.centerCircleRadius} 0 0 0 ${field.width - field.penaltySpotDistance - field.centerCircleRadius} ${penaltyAreaY + field.penaltyAreaHeight}`} fill="none" stroke="white" strokeWidth="0.2"/>
                      )}
                    </>
                  )}
                  
                  {/* Goals */}
                  <rect x="-2" y={goalY} width="2" height={field.goalWidth} fill="none" stroke="white" strokeWidth="0.3"/>
                  {selectedFieldSize !== 'half' && (
                    <rect x={field.width} y={goalY} width="2" height={field.goalWidth} fill="none" stroke="white" strokeWidth="0.3"/>
                  )}
                  
                  {/* Corner arcs */}
                  <path d="M 0 0 A 1 1 0 0 1 1 0" fill="none" stroke="white" strokeWidth="0.2"/>
                  <path d={`M ${field.width} 0 A 1 1 0 0 0 ${field.width - 1} 0`} fill="none" stroke="white" strokeWidth="0.2"/>
                  <path d={`M 0 ${field.height} A 1 1 0 0 0 1 ${field.height}`} fill="none" stroke="white" strokeWidth="0.2"/>
                  <path d={`M ${field.width} ${field.height} A 1 1 0 0 1 ${field.width - 1} ${field.height}`} fill="none" stroke="white" strokeWidth="0.2"/>

                  {/* Corner flags */}
                  <circle cx="0" cy="0" r="0.2" fill="white"/>
                  <circle cx={field.width} cy="0" r="0.2" fill="white"/>
                  <circle cx="0" cy={field.height} r="0.2" fill="white"/>
                  <circle cx={field.width} cy={field.height} r="0.2" fill="white"/>
                </>
              );
            })()}

            {/* Rendered lines and arrows */}
            {renderLines()}

            {/* Current drawing path */}
            {isDrawing && currentPath.length > 0 && (
              <path
                d={currentPath
                  .map((point, index) => `${index === 0 ? 'M' : 'L'} ${(point.x / 100) * getCurrentFieldSize().width} ${(point.y / 100) * getCurrentFieldSize().height}`)
                  .join(' ')}
                stroke="white"
                strokeWidth="0.4"
                fill="none"
                opacity={0.8}
                markerEnd={selectedTool === 'arrow' ? 'url(#arrowhead)' : undefined}
              />
            )}
          </svg>

          {/* Rendered elements */}
          {elements.map(renderElement)}
        </div>
      </div>

      {/* Animation Controls */}
      <div className="absolute top-4 right-20 z-20">
        <div className="bg-gray-900/90 rounded-lg p-3 flex items-center space-x-3">
          <Button
            size="sm"
            variant={showAnimationControls ? "default" : "outline"}
            onClick={() => setShowAnimationControls(!showAnimationControls)}
            className="text-white"
          >
            <Play className="w-4 h-4 mr-1" />
            Animatie
          </Button>
          
          {showAnimationControls && (
            <>
              <div className="h-6 w-px bg-gray-600" />
              
              <Button size="sm" variant="outline" onClick={saveSequence} className="text-white">
                Opslaan fase
              </Button>
              
              <Button size="sm" variant="outline" onClick={addNewSequence} className="text-white">
                Nieuwe fase
              </Button>
              
              <Button
                size="sm"
                variant={isPlaying ? "destructive" : "default"}
                onClick={playAnimation}
                className="text-white"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </Button>
              
              <div className="text-white text-sm">
                Fase: {currentSequence + 1}/{maxSequences}
              </div>
              
              <Button size="sm" variant="outline" onClick={exportAnimation} className="text-white">
                <Download className="w-4 h-4 mr-1" />
                Export MP4
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Animation Timeline */}
      {showAnimationControls && (
        <div className="absolute bottom-20 left-20 right-20 z-20">
          <div className="bg-gray-900/95 rounded-lg p-4">
            <h4 className="text-white text-sm font-medium mb-3">Animatie Tijdslijn</h4>
            <div className="flex items-center space-x-2 mb-3">
              {Array.from({ length: maxSequences }, (_, i) => (
                <div
                  key={i}
                  className={`px-3 py-2 rounded cursor-pointer text-xs transition-colors ${
                    currentSequence === i
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                  onClick={() => loadSequence(i)}
                >
                  Fase {i + 1}
                </div>
              ))}
              <Button size="sm" variant="outline" onClick={addNewSequence} className="text-white ml-2">
                + Fase
              </Button>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-white text-xs">Snelheid:</label>
                <select
                  value={playbackSpeed}
                  onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
                  className="bg-gray-700 text-white text-xs px-2 py-1 rounded"
                >
                  <option value={0.5}>0.5x</option>
                  <option value={1}>1x</option>
                  <option value={1.5}>1.5x</option>
                  <option value={2}>2x</option>
                </select>
              </div>
              
              <div className="text-white text-xs">
                Totale duur: {Object.keys(animationSequences).length * (2 / playbackSpeed)}s
              </div>
              
              <Button size="sm" variant="outline" onClick={clearField} className="text-white">
                Reset alle fasen
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Toolbar */}
      <div className="absolute bottom-0 left-0 right-0 bg-gray-900 h-16 flex items-center justify-center space-x-8 z-20">
        <div className="flex items-center space-x-6">
          {/* New Project */}
          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400" onClick={clearField}>
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
              </svg>
            </div>
            <span className="text-xs">Nieuw project</span>
          </div>

          {/* Open Project */}
          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <FolderOpen className="w-6 h-6" />
            </div>
            <span className="text-xs">Open project</span>
          </div>

          {/* Save */}
          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400" onClick={saveProject}>
            <div className="w-8 h-8 flex items-center justify-center">
              <Save className="w-6 h-6" />
            </div>
            <span className="text-xs">Opslaan</span>
          </div>

          {/* Animation */}
          <div 
            className={`flex flex-col items-center cursor-pointer transition-colors ${
              showAnimationControls ? 'text-blue-400' : 'text-white hover:text-blue-400'
            }`}
            onClick={() => setShowAnimationControls(!showAnimationControls)}
          >
            <div className="w-8 h-8 flex items-center justify-center">
              <Play className="w-6 h-6" />
            </div>
            <span className="text-xs">Animatie</span>
          </div>

          {/* Settings */}
          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <Settings className="w-6 h-6" />
            </div>
            <span className="text-xs">Instellingen</span>
          </div>

          {/* Share */}
          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <Share2 className="w-6 h-6" />
            </div>
            <span className="text-xs">Delen</span>
          </div>

          {/* Field */}
          <div 
            className="flex flex-col items-center text-blue-400 cursor-pointer"
            onClick={() => setShowFieldDialog(true)}
          >
            <div className="w-8 h-8 flex items-center justify-center">
              <Square className="w-6 h-6" />
            </div>
            <span className="text-xs">Veld</span>
          </div>

          {/* 3D */}
          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <Box className="w-6 h-6" />
            </div>
            <span className="text-xs">3D</span>
          </div>
        </div>
      </div>

      {/* Team Dialog */}
      <Dialog open={showTeamDialog} onOpenChange={setShowTeamDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Team Configuration</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold">Home Team</h3>
              <div className="space-y-2">
                <Input
                  value={homeTeam.name}
                  onChange={(e) => setHomeTeam(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Team name"
                />
                <Input
                  value={homeTeam.year}
                  onChange={(e) => setHomeTeam(prev => ({ ...prev, year: e.target.value }))}
                  placeholder="Founded year"
                />
                <Select value={homeTeam.formation} onValueChange={(value) => setHomeTeam(prev => ({ ...prev, formation: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {formations.map((formation) => (
                      <SelectItem key={formation.name} value={formation.name}>
                        {formation.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={() => applyFormation('home', homeTeam.formation)} className="w-full">
                  Apply Formation
                </Button>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-semibold">Away Team</h3>
              <div className="space-y-2">
                <Input
                  value={awayTeam.name}
                  onChange={(e) => setAwayTeam(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Team name"
                />
                <Input
                  value={awayTeam.year}
                  onChange={(e) => setAwayTeam(prev => ({ ...prev, year: e.target.value }))}
                  placeholder="Founded year"
                />
                <Select value={awayTeam.formation} onValueChange={(value) => setAwayTeam(prev => ({ ...prev, formation: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {formations.map((formation) => (
                      <SelectItem key={formation.name} value={formation.name}>
                        {formation.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={() => applyFormation('away', awayTeam.formation)} className="w-full">
                  Apply Formation
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Tools Dialog */}
      <Dialog open={showToolsDialog} onOpenChange={setShowToolsDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Tekengereedschappen</DialogTitle>
          </DialogHeader>
          
          {/* Drawing Tools */}
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">Gereedschappen</h4>
              <div className="grid grid-cols-2 gap-2">
                {tools.map((tool) => {
                  const Icon = tool.icon;
                  return (
                    <Button
                      key={tool.id}
                      variant={selectedTool === tool.id ? "default" : "outline"}
                      onClick={() => {
                        setSelectedTool(tool.id);
                        setIsDrawing(false);
                        setCurrentPath([]);
                      }}
                      className="flex items-center gap-2 text-xs"
                      size="sm"
                    >
                      <Icon className="w-3 h-3" />
                      {tool.name}
                    </Button>
                  );
                })}
              </div>
            </div>

            {/* Line Settings */}
            <div>
              <h4 className="font-medium mb-2">Lijn instellingen</h4>
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium">Dikte:</label>
                  <div className="flex gap-2 mt-1">
                    <Button
                      variant={lineThickness === 'small' ? "default" : "outline"}
                      size="sm"
                      onClick={() => setLineThickness('small')}
                    >
                      Dun
                    </Button>
                    <Button
                      variant={lineThickness === 'medium' ? "default" : "outline"}
                      size="sm"
                      onClick={() => setLineThickness('medium')}
                    >
                      Normaal
                    </Button>
                    <Button
                      variant={lineThickness === 'large' ? "default" : "outline"}
                      size="sm"
                      onClick={() => setLineThickness('large')}
                    >
                      Dik
                    </Button>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">Kleur:</label>
                  <div className="flex gap-2 mt-1">
                    {['#ffffff', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff8800'].map((color) => (
                      <button
                        key={color}
                        className={`w-8 h-8 rounded border-2 ${selectedColor === color ? 'border-gray-800' : 'border-gray-300'}`}
                        style={{ backgroundColor: color }}
                        onClick={() => setSelectedColor(color)}
                      />
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="dashed"
                    checked={isDashed}
                    onChange={(e) => setIsDashed(e.target.checked)}
                  />
                  <label htmlFor="dashed" className="text-sm">Stippellijn</label>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <Button onClick={clearField} variant="destructive" className="flex-1">
                <RotateCcw className="w-4 h-4 mr-2" />
                Veld wissen
              </Button>
              <Button onClick={() => setShowToolsDialog(false)} className="flex-1">
                Sluiten
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Field Size Dialog */}
      <Dialog open={showFieldDialog} onOpenChange={setShowFieldDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Veld afmetingen</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-3">
            <p className="text-sm text-gray-600 mb-4">Kies de gewenste veldgrootte voor je tactische analyse:</p>
            
            {fieldSizes.map((field) => (
              <div
                key={field.name}
                className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedFieldSize === field.name
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300'
                }`}
                onClick={() => {
                  setSelectedFieldSize(field.name);
                  setElements([]); // Clear elements when changing field size
                }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{field.description}</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      {field.name === 'half' ? 'Perfect voor aanvalspatronen' :
                       field.name === 'quarter' ? 'Ideaal voor kleine oefeningen' :
                       field.name === 'mini' ? 'Voor technische oefeningen' :
                       field.name === 'small' ? 'Voor jeugdvoetbal' :
                       'Volledige tactische analyses'}
                    </p>
                  </div>
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    selectedFieldSize === field.name
                      ? 'bg-blue-500 border-blue-500'
                      : 'border-gray-300'
                  }`}>
                    {selectedFieldSize === field.name && (
                      <div className="w-full h-full rounded-full bg-white scale-50"></div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            <div className="pt-4 border-t">
              <div className="text-xs text-gray-500 mb-2">Huidige selectie:</div>
              <div className="text-sm font-medium">{getCurrentFieldSize().description}</div>
            </div>
            
            <div className="flex gap-2 pt-2">
              <Button 
                onClick={() => setShowFieldDialog(false)} 
                className="flex-1"
              >
                Toepassen
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSelectedFieldSize('full');
                  setElements([]);
                }}
                className="flex-1"
              >
                Reset naar volledig
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProfessionalTacticalPad;