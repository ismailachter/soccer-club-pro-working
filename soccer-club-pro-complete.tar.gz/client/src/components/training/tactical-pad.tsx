import React, { useState, useRef, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Circle,
  Square,
  Triangle,
  ArrowRight,
  Minus,
  MoreHorizontal,
  Edit3,
  Eraser,
  Undo,
  Redo,
  Save,
  Download,
  Upload,
  Play,
  Pause,
  RotateCcw,
  MousePointer,
  Move,
  Zap,
  Users,
  Target,
  Settings
} from "lucide-react";

interface TacticalElement {
  id: string;
  type: 'player' | 'ball' | 'cone' | 'goal' | 'arrow' | 'line' | 'zone';
  x: number;
  y: number;
  color: string;
  size: 'small' | 'medium' | 'large';
  label?: string;
  rotation?: number;
  width?: number;
  height?: number;
  points?: { x: number; y: number }[];
}

interface TacticalPlay {
  id: string;
  name: string;
  elements: TacticalElement[];
  formation: string;
  description: string;
  tags: string[];
  duration?: number;
}

interface TacticalPadProps {
  onSave?: (play: TacticalPlay) => void;
  initialPlay?: TacticalPlay;
}

const drawingTools = [
  { id: 'select', name: 'Select', icon: MousePointer, cursor: 'default' },
  { id: 'move', name: 'Move', icon: Move, cursor: 'move' },
  { id: 'player', name: 'Player', icon: Circle, cursor: 'crosshair' },
  { id: 'ball', name: 'Ball', icon: Circle, cursor: 'crosshair' },
  { id: 'cone', name: 'Cone', icon: Triangle, cursor: 'crosshair' },
  { id: 'arrow', name: 'Arrow', icon: ArrowRight, cursor: 'crosshair' },
  { id: 'line', name: 'Line', icon: Minus, cursor: 'crosshair' },
  { id: 'zone', name: 'Zone', icon: Square, cursor: 'crosshair' },
  { id: 'eraser', name: 'Eraser', icon: Eraser, cursor: 'crosshair' }
];

const formations = [
  '4-4-2', '4-3-3', '3-4-3', '3-5-2', '4-2-3-1', '4-5-1', '5-3-2', '3-5-3'
];

const playerColors = [
  '#ef4444', '#3b82f6', '#22c55e', '#eab308', '#f97316', 
  '#a855f7', '#ec4899', '#6b7280', '#ffffff', '#000000'
];

export const TacticalPad: React.FC<TacticalPadProps> = ({ 
  onSave, 
  initialPlay 
}) => {
  const [elements, setElements] = useState<TacticalElement[]>(initialPlay?.elements || []);
  const [selectedTool, setSelectedTool] = useState('select');
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState('#ef4444');
  const [selectedSize, setSelectedSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState<{ x: number; y: number }[]>([]);
  const [playName, setPlayName] = useState(initialPlay?.name || '');
  const [formation, setFormation] = useState(initialPlay?.formation || '4-4-2');
  const [description, setDescription] = useState(initialPlay?.description || '');
  const [history, setHistory] = useState<TacticalElement[][]>([[]]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [animationStep, setAnimationStep] = useState(0);
  
  const fieldRef = useRef<HTMLDivElement>(null);

  const addToHistory = useCallback((newElements: TacticalElement[]) => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push([...newElements]);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [history, historyIndex]);

  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setElements([...history[historyIndex - 1]]);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setElements([...history[historyIndex + 1]]);
    }
  };

  const handleFieldClick = (e: React.MouseEvent) => {
    if (!fieldRef.current) return;
    
    const rect = fieldRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    if (selectedTool === 'select') {
      // Find clicked element
      const clickedElement = elements.find(el => {
        const distance = Math.sqrt(Math.pow(el.x - x, 2) + Math.pow(el.y - y, 2));
        return distance < 3;
      });
      setSelectedElement(clickedElement?.id || null);
    } else if (selectedTool === 'eraser') {
      // Remove clicked element
      const newElements = elements.filter(el => {
        const distance = Math.sqrt(Math.pow(el.x - x, 2) + Math.pow(el.y - y, 2));
        return distance >= 3;
      });
      setElements(newElements);
      addToHistory(newElements);
    } else if (['player', 'ball', 'cone'].includes(selectedTool)) {
      // Add new element
      const newElement: TacticalElement = {
        id: `${selectedTool}-${Date.now()}`,
        type: selectedTool as 'player' | 'ball' | 'cone',
        x,
        y,
        color: selectedColor,
        size: selectedSize,
        label: selectedTool === 'player' ? String(elements.filter(el => el.type === 'player').length + 1) : undefined
      };
      const newElements = [...elements, newElement];
      setElements(newElements);
      addToHistory(newElements);
    } else if (['arrow', 'line'].includes(selectedTool)) {
      if (!isDrawing) {
        setIsDrawing(true);
        setCurrentPath([{ x, y }]);
      } else {
        // Finish drawing
        const newElement: TacticalElement = {
          id: `${selectedTool}-${Date.now()}`,
          type: selectedTool as 'arrow' | 'line',
          x: currentPath[0].x,
          y: currentPath[0].y,
          color: selectedColor,
          size: selectedSize,
          points: [...currentPath, { x, y }]
        };
        const newElements = [...elements, newElement];
        setElements(newElements);
        addToHistory(newElements);
        setIsDrawing(false);
        setCurrentPath([]);
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!fieldRef.current || !isDrawing) return;
    
    const rect = fieldRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    setCurrentPath(prev => [...prev.slice(0, -1), { x, y }]);
  };

  const clearField = () => {
    setElements([]);
    addToHistory([]);
    setSelectedElement(null);
  };

  const savePlay = () => {
    if (!playName) return;
    
    const play: TacticalPlay = {
      id: `play-${Date.now()}`,
      name: playName,
      elements,
      formation,
      description,
      tags: [],
      duration: 0
    };
    
    if (onSave) {
      onSave(play);
    }
  };

  const exportPlay = () => {
    const play: TacticalPlay = {
      id: `play-${Date.now()}`,
      name: playName,
      elements,
      formation,
      description,
      tags: []
    };
    
    const dataStr = JSON.stringify(play, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${playName || 'tactical-play'}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const renderElement = (element: TacticalElement) => {
    const isSelected = selectedElement === element.id;
    const sizeMap = { small: 6, medium: 8, large: 12 };
    const size = sizeMap[element.size];

    if (element.type === 'player') {
      return (
        <div
          key={element.id}
          className={`absolute transition-all duration-200 ${isSelected ? 'scale-110 ring-2 ring-blue-500' : ''}`}
          style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            transform: 'translate(-50%, -50%)'
          }}
        >
          <div 
            className={`w-${size} h-${size} rounded-full border-2 border-white shadow-lg flex items-center justify-center text-white font-bold text-xs`}
            style={{ backgroundColor: element.color, width: `${size * 4}px`, height: `${size * 4}px` }}
          >
            {element.label}
          </div>
        </div>
      );
    }

    if (element.type === 'ball') {
      return (
        <div
          key={element.id}
          className={`absolute transition-all duration-200 ${isSelected ? 'scale-110 ring-2 ring-blue-500' : ''}`}
          style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            transform: 'translate(-50%, -50%)'
          }}
        >
          <Circle 
            className="text-white"
            style={{ color: element.color, width: `${size * 3}px`, height: `${size * 3}px` }}
            fill="currentColor"
          />
        </div>
      );
    }

    if (element.type === 'cone') {
      return (
        <div
          key={element.id}
          className={`absolute transition-all duration-200 ${isSelected ? 'scale-110 ring-2 ring-blue-500' : ''}`}
          style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            transform: 'translate(-50%, -50%)'
          }}
        >
          <Triangle 
            style={{ color: element.color, width: `${size * 3}px`, height: `${size * 3}px` }}
            fill="currentColor"
          />
        </div>
      );
    }

    return null;
  };

  const renderLines = () => {
    return elements
      .filter(el => el.type === 'arrow' || el.type === 'line')
      .map(element => {
        if (!element.points || element.points.length < 2) return null;
        
        const pathData = element.points
          .map((point, index) => `${index === 0 ? 'M' : 'L'} ${(point.x / 100) * 300} ${(point.y / 100) * 200}`)
          .join(' ');

        return (
          <g key={element.id}>
            <path
              d={pathData}
              stroke={element.color}
              strokeWidth={element.size === 'small' ? 2 : element.size === 'medium' ? 3 : 4}
              fill="none"
              markerEnd={element.type === 'arrow' ? 'url(#arrowhead)' : undefined}
            />
          </g>
        );
      });
  };

  return (
    <div className="relative h-[600px] bg-gray-800 rounded-lg overflow-hidden">
      {/* Left Panel - Team Selector */}
      <div className="absolute left-4 top-1/2 transform -translate-y-1/2 space-y-4 z-10">
        <div className="bg-white rounded-lg p-3 shadow-lg">
          <div className="w-16 h-16 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold">
            YYC
          </div>
          <div className="text-xs text-center mt-1">1950</div>
        </div>
        
        <div className="bg-gray-700 text-white rounded-lg p-2 text-center">
          <div className="text-xs">Menu</div>
        </div>
      </div>

      {/* Right Panel - Team Selector */}
      <div className="absolute right-4 top-1/2 transform -translate-y-1/2 space-y-4 z-10">
        <div className="bg-white rounded-lg p-3 shadow-lg">
          <div className="w-16 h-16 bg-orange-500 rounded-lg flex items-center justify-center text-white font-bold">
            ACM
          </div>
          <div className="text-xs text-center mt-1">1899</div>
        </div>
        
        <div className="bg-gray-700 text-white rounded-lg p-2 text-center">
          <div className="text-xs">Tools</div>
        </div>
      </div>

      {/* Top Navigation */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10">
        <div className="text-white text-xs">www.tacticalpad.com</div>
      </div>

      {/* Bottom Toolbar */}
      <div className="absolute bottom-0 left-0 right-0 bg-gray-900 h-16 flex items-center justify-center space-x-8 z-10">
        {/* Toolbar Icons */}
        <div className="flex items-center space-x-6">
          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400" onClick={() => setSelectedTool('select')}>
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
              </svg>
            </div>
            <span className="text-xs">Nieuw project</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M10,4H4C2.89,4 2,4.89 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V8C22,6.89 21.1,6 20,6H12L10,4Z" />
              </svg>
            </div>
            <span className="text-xs">Open project</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400" onClick={savePlay}>
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M15,9H5V5H15M12,19A3,3 0 0,1 9,16A3,3 0 0,1 12,13A3,3 0 0,1 15,16A3,3 0 0,1 12,19M17,3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V7L17,3Z" />
              </svg>
            </div>
            <span className="text-xs">Opslaan</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z" />
              </svg>
            </div>
            <span className="text-xs">Opslaan als</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M22.7 19L13.6 9.9C14.5 7.6 14 4.9 12.1 3C10.1 1 7.1 1 5.1 3S1 8.9 3 10.9C4.9 12.8 7.6 13.3 9.9 12.4L19 21.7C19.4 22.1 20 22.1 20.4 21.7L22.7 19.4C23.1 19 23.1 18.4 22.7 19Z" />
              </svg>
            </div>
            <span className="text-xs">Instellingen</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" />
              </svg>
            </div>
            <span className="text-xs">Delen</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M19,20H4C2.89,20 2,19.1 2,18V6C2,4.89 2.89,4 4,4H10L12,6H19A2,2 0 0,1 21,8H21L4,8V18L6.14,10H23.21L20.93,18.5C20.7,19.37 19.92,20 19,20Z" />
              </svg>
            </div>
            <span className="text-xs">Borden</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M12,2L13.09,8.26L22,9L13.09,9.74L12,16L10.91,9.74L2,9L10.91,8.26L12,2Z" />
              </svg>
            </div>
            <span className="text-xs">Veld</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M12,2C13.1,2 14,2.9 14,4C14,5.1 13.1,6 12,6C10.9,6 10,5.1 10,4C10,2.9 10.9,2 12,2M21,9V7L15,1L13.5,2.5L16.17,5.17L10.58,10.76C10.22,10.54 9.78,10.5 9.39,10.76L2,18.15L3.85,20L11.24,12.61C11.5,12.22 11.46,11.78 11.24,11.42L16.83,5.83L19.5,8.5L21,7V9H21Z" />
              </svg>
            </div>
            <span className="text-xs">3D</span>
          </div>

          <div className="flex flex-col items-center text-white cursor-pointer hover:text-blue-400">
            <div className="w-8 h-8 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                <path d="M12,3L1,9L12,15L21,10.09V17H23V9M5,13.18V17.18L12,21L19,17.18V13.18L12,17L5,13.18Z" />
              </svg>
            </div>
            <span className="text-xs">Repositories</span>
          </div>
        </div>
      </div>

      {/* Football Field */}
      <div className="absolute inset-x-20 top-4 bottom-20">
        <div
          ref={fieldRef}
          className="relative w-full h-full"
          onClick={handleFieldClick}
          onMouseMove={handleMouseMove}
          style={{ 
            cursor: drawingTools.find(t => t.id === selectedTool)?.cursor || 'default'
          }}
        >
          {/* Field Background with Grass Texture */}
          <div className="absolute inset-0 bg-gradient-to-br from-green-400 to-green-600"></div>
          
          {/* Field markings */}
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 300 200">
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="7"
                refX="9"
                refY="3.5"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3.5, 0 7"
                  fill="currentColor"
                />
              </marker>
            </defs>

            {/* Outer boundary */}
            <rect x="20" y="20" width="260" height="160" fill="none" stroke="white" strokeWidth="3"/>
            
            {/* Center circle */}
            <circle cx="150" cy="100" r="25" fill="none" stroke="white" strokeWidth="3"/>
            <circle cx="150" cy="100" r="2" fill="white"/>
            
            {/* Center line */}
            <line x1="150" y1="20" x2="150" y2="180" stroke="white" strokeWidth="3"/>
            
            {/* Goal areas (6-yard box) */}
            <rect x="20" y="75" width="18" height="50" fill="none" stroke="white" strokeWidth="3"/>
            <rect x="262" y="75" width="18" height="50" fill="none" stroke="white" strokeWidth="3"/>
            
            {/* Penalty areas (18-yard box) */}
            <rect x="20" y="55" width="44" height="90" fill="none" stroke="white" strokeWidth="3"/>
            <rect x="236" y="55" width="44" height="90" fill="none" stroke="white" strokeWidth="3"/>
            
            {/* Penalty spots */}
            <circle cx="42" cy="100" r="1.5" fill="white"/>
            <circle cx="258" cy="100" r="1.5" fill="white"/>
            
            {/* Penalty arcs */}
            <path d="M 54 85 A 12 12 0 0 1 54 115" fill="none" stroke="white" strokeWidth="3"/>
            <path d="M 246 85 A 12 12 0 0 0 246 115" fill="none" stroke="white" strokeWidth="3"/>
            
            {/* Goals */}
            <rect x="12" y="85" width="8" height="30" fill="none" stroke="white" strokeWidth="4"/>
            <rect x="280" y="85" width="8" height="30" fill="none" stroke="white" strokeWidth="4"/>
            
            {/* Corner arcs */}
            <path d="M 20 20 A 3 3 0 0 1 23 20 A 3 3 0 0 1 20 23" fill="none" stroke="white" strokeWidth="3"/>
            <path d="M 280 20 A 3 3 0 0 0 277 20 A 3 3 0 0 0 280 23" fill="none" stroke="white" strokeWidth="3"/>
            <path d="M 20 180 A 3 3 0 0 0 23 180 A 3 3 0 0 0 20 177" fill="none" stroke="white" strokeWidth="3"/>
            <path d="M 280 180 A 3 3 0 0 1 277 180 A 3 3 0 0 1 280 177" fill="none" stroke="white" strokeWidth="3"/>

            {/* Rendered lines and arrows */}
            {renderLines()}

            {/* Current drawing path */}
            {isDrawing && currentPath.length > 0 && (
              <path
                d={currentPath
                  .map((point, index) => `${index === 0 ? 'M' : 'L'} ${(point.x / 100) * 300} ${(point.y / 100) * 200}`)
                  .join(' ')}
                stroke={selectedColor}
                strokeWidth={selectedSize === 'small' ? 2 : selectedSize === 'medium' ? 3 : 4}
                fill="none"
                opacity={0.6}
                markerEnd={selectedTool === 'arrow' ? 'url(#arrowhead)' : undefined}
              />
            )}
          </svg>

          {/* Rendered elements */}
          {elements.map(renderElement)}

          {/* Drawing instruction */}
          {isDrawing && (
            <div className="absolute top-4 left-4 bg-blue-500 text-white px-3 py-1 rounded text-sm">
              Click to finish drawing
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TacticalPad;