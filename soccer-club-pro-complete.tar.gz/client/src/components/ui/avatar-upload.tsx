import { useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Upload, X } from "lucide-react";
import { getInitials } from "@/lib/utils";

interface AvatarUploadProps {
  firstName?: string;
  lastName?: string;
  currentAvatar?: string;
  imageUrl?: string;
  onUpload: (file: File) => void;
  onClear?: () => void;
  size?: "sm" | "md" | "lg" | "xl";
}

export function AvatarUpload({
  firstName = "",
  lastName = "",
  currentAvatar,
  imageUrl,
  onUpload,
  onClear,
  size = "md",
}: AvatarUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(imageUrl || currentAvatar || null);
  const [isHovering, setIsHovering] = useState(false);

  const sizeClasses = {
    sm: "h-16 w-16",
    md: "h-24 w-24",
    lg: "h-32 w-32",
    xl: "h-40 w-40",
  };

  const iconSizes = {
    sm: "h-5 w-5",
    md: "h-6 w-6",
    lg: "h-8 w-8",
    xl: "h-10 w-10",
  };

  // Update the preview URL when imageUrl changes
  useEffect(() => {
    if (imageUrl) {
      setPreviewUrl(imageUrl);
    }
  }, [imageUrl]);

  const handleClick = () => {
    inputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setPreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(file);

    onUpload(file);
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPreviewUrl(null);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
    onClear?.();
  };

  return (
    <div className="flex flex-col items-center">
      <div 
        className="relative group"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
      >
        <Avatar 
          className={`${sizeClasses[size]} cursor-pointer border-2 border-muted hover:border-primary`}
          onClick={handleClick}
        >
          <AvatarImage src={previewUrl || undefined} />
          <AvatarFallback className="bg-primary/10 text-primary">
            {getInitials(firstName, lastName)}
          </AvatarFallback>
        </Avatar>
        
        {isHovering && (
          <div 
            className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center cursor-pointer"
            onClick={handleClick}
          >
            <Upload className={`${iconSizes[size]} text-white`} />
          </div>
        )}
        
        {previewUrl && onClear && (
          <button 
            className="absolute -top-2 -right-2 rounded-full bg-destructive text-white p-1 shadow-sm"
            onClick={handleClear}
          >
            <X className="h-3 w-3" />
          </button>
        )}
      </div>
      
      <input
        type="file"
        ref={inputRef}
        className="hidden"
        accept="image/*"
        onChange={handleFileChange}
      />
      
      <Button 
        variant="ghost" 
        size="sm" 
        className="mt-2 text-xs" 
        onClick={handleClick}
      >
        {previewUrl ? "Change Photo" : "Upload Photo"}
      </Button>
    </div>
  );
}
