import { useState } from "react";
import { ChevronDown, Target, Users, Zap, Brain, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DepthDetail } from "@/components/topic/depth-detail";

const mainTopics = [
  {
    id: "BASICS",
    name: "Basics",
    icon: Target,
    description: "Fundamentele voetbalvaardigheden",
    subtopics: [
      { 
        id: "B+", 
        name: "B+ (Goud)", 
        description: "Gevorderde basis technieken",
        color: "#FFD700",
        icon: Award,
        elements: [
          "Leiden van de bal",
          "Dribbelen met de bal",
          "Korte Passing",
          "Middellange Passing",
          "Lange Passing",
          "Passing met het Hoofd",
          "1 tijd Passing, Kaatsen",
          "Balcontrole Korte Pass",
          "Balcontrole Middellange Pass",
          "Balcontrole Lange Pass",
          "Schieten op doel",
          "Scoren met de voet",
          "Scoren met het hoofd",
          "Scoren na individuele actie, trucks",
          "Vrijlopen - Aanspeelbaar zijn",
          "Goed ingedraaid staan",
          "Steun je teamgenoot"
        ]
      },
      { 
        id: "B-", 
        name: "B- (Zilver)", 
        description: "Basis technieken",
        color: "#C0C0C0",
        icon: Target,
        elements: [
          "1v1 Druk zetten, Tackle, Remmen",
          "Duel",
          "Interceptie voor balcontrole op korte passing",
          "Interceptie voor balcontrole op middellange passing",
          "Interceptie voor balcontrole op lange passing",
          "Interceptie voor balcontrole op kopbal",
          "Interceptie voor balcontrole op kaatsbal",
          "Interceptie na balcontrole korte pass",
          "Interceptie na balcontrole middellange pass",
          "Interceptie na balcontrole lange pass",
          "Afweren, Schieten op doel beletten",
          "Afweren, Scoren met de voet beletten",
          "Afweren, Scoren met het hoofd beletten",
          "Afweren, Scoren na invididuele actie, tricks beletten",
          "Speelhoeken afsluiten",
          "Strikte dekking",
          "Rugdekking"
        ]
      }
    ]
  },
  {
    id: "TEAMTACTISCH",
    name: "Team Tactisch",
    icon: Users,
    description: "Teamtactieken en samenspel",
    subtopics: [
      { 
        id: "B+", 
        name: "B+ (Goud)", 
        description: "Gevorderde team tactieken",
        color: "#FFD700",
        icon: Award,
        subcategories: [
          {
            id: "OPBOUWEN",
            name: "OPBOUWEN",
            description: "Opbouw spel en balcirculatie",
            elements: [
              "Creeer ruimte",
              "Creeer hoogte, diepte",
              "Creeer meerderheidssituaties",
              "Driekhoeksspel",
              "Creeer 3 x aanspeelbaarheid",
              "Vlotte eficiënte balcirculatie",
              "Hoog tempo balbezit",
              "Diagonal in & uit",
              "Linie overslaan"
            ]
          },
          {
            id: "VOORUITGANG_INFILTRATIE",
            name: "VOORUITGANG & INFILTRATIE",
            description: "Voorwaartse beweging en infiltratie",
            elements: [
              "Positie tussen de linies",
              "Diepgaande infiltraties",
              "Interacties 2, 3 linies",
              "Vermijd onnodig balverlies",
              "Individuele actie",
              "Subtiele laatste pass",
              "Voorzet",
              "Vroege voorzet"
            ]
          },
          {
            id: "DOELPUNTEN_MAKEN",
            name: "DOELPUNTEN MAKEN",
            description: "Afronding en doelpunten creëren",
            elements: [
              "4 in de 16",
              "Aanvallen van de blinde zijde verdediging",
              "Kordate afwerking",
              "Posities innemen in de 16",
              "Flankvoorzetten"
            ]
          }
        ]
      },
      { 
        id: "B-", 
        name: "B- (Zilver)", 
        description: "Basis team tactieken",
        color: "#C0C0C0",
        icon: Users,
        subcategories: [
          {
            id: "DRUK_ZETTEN",
            name: "DRUK ZETTEN",
            description: "Actief druk zetten op de tegenstander",
            elements: [
              "Man 2 man",
              "Sandwich",
              "2-3 jobs",
              "Interceptie",
              "Drukformaties",
              "Vermijd de eindpas",
              "Vermijd lange bal, diepe bal",
              "Vermijd kruispas, zwakke zone",
              "Collectief druk zetten"
            ]
          },
          {
            id: "COMPACT_VERDEDIGEN",
            name: "COMPACT VERDEDIGEN",
            description: "Compacte defensieve organisatie",
            elements: [
              "Compacte ruimte",
              "Druk zetten en dekking geven",
              "Schaduwen",
              "Afstand tov tegenstrever",
              "Hoog blok",
              "Buitenspelval + lijn",
              "Kantelen van het blok",
              "DM schuift mee",
              "Beheer van de ruimtes"
            ]
          },
          {
            id: "BESCHERMEN_VAN_HET_DOEL",
            name: "BESCHERMEN VAN HET DOEL",
            description: "Doelverdediging en laatste linie",
            elements: [
              "Dekking",
              "Veranderen van dekking",
              "Kruisen tijdens dekking of niet",
              "Terugvallen en niet uitgeschakeld w",
              "Duw het blok terug voorwaarts",
              "Duel 1 vs 1",
              "Verdedigende T-vorm",
              "Regels bij infiltraties tegenst m,z bal",
              "Schoten afblokken",
              "Ruimte in de rug vh blok vermijden"
            ]
          }
        ]
      },
      { 
        id: "OMSCH_B_MIN_B_PLUS", 
        name: "OMSCH. B-/B+ (Groen)", 
        description: "Omschakeling van verdedigen naar aanvallen",
        color: "#22c55e",
        icon: Target,
        subcategories: [
          {
            id: "TEGENAANVAL",
            name: "TEGENAANVAL",
            description: "Snelle aanvallende omschakeling",
            elements: [
              "5S in de 16",
              "Schuif mee in",
              "Loop in de ruimte",
              "Speel diep"
            ]
          },
          {
            id: "OP_BALBEZIT_SPELEN",
            name: "OP BALBEZIT SPELEN",
            description: "Balbezit behouden na omschakeling",
            elements: [
              "Speel uit de druk van het blok",
              "Verander van zijde",
              "Verleng het veld"
            ]
          }
        ]
      },
      { 
        id: "OMSCH_B_PLUS_B_MIN", 
        name: "OMSCH. B+/B- (Rood)", 
        description: "Omschakeling van aanvallen naar verdedigen",
        color: "#ef4444",
        icon: Target,
        subcategories: [
          {
            id: "TEGEN_DRUK_ZETTEN",
            name: "TEGEN DRUK ZETTEN",
            description: "Defensieve druk na balverlies",
            elements: [
              "Man 2 man",
              "Sandwich",
              "1 tik verdedigend",
              "Onderbreek en herover de bal"
            ]
          },
          {
            id: "HERVORMEN_OPSTELLING",
            name: "HERVORMEN OPSTELLING",
            description: "Defensieve herorganisatie na balverlies",
            elements: [
              "Bescherm de ruimte",
              "Hou de bal voor je",
              "Doel afschermen"
            ]
          }
        ]
      }
    ]
  },
  {
    id: "FYSIEK",
    name: "Fysiek",
    icon: Zap,
    description: "Fysieke conditioning en kracht",
    subtopics: [
      { 
        id: "ALGEMEEN_FYSIEK", 
        name: "Algemeen Fysiek", 
        description: "Fysieke training en conditie",
        color: "#e67e22",
        icon: Zap,
        elements: [
          "Uithouding",
          "Basismotoriek",
          "Oog-handcoördinatie",
          "Oog-voetcoördinatie",
          "Evenwichtscontrole",
          "Reactiesnelheid",
          "Natuurlijke Lenigheid",
          "Ritme",
          "Loopcoördinatie",
          "Looptechniek",
          "Lenigheid",
          "Snelheid",
          "Kracht",
          "Biometrie",
          "Startsnelheid",
          "Versnellingsvermogen",
          "Snelheidsuithoudingsvermogen",
          "Herhaald Kort Springvermogen",
          "Wendbaarheid tijdens de Sprint",
          "Herstelvermogen",
          "Sprongkracht",
          "Trapkracht",
          "Duelkracht",
          "Werpkracht",
          "Snelkracht",
          "Krachtuithouding",
          "Handelingssnelheid",
          "Blessurepreventie"
        ]
      }
    ]
  },
  {
    id: "MENTAAL",
    name: "Mentaal",
    icon: Brain,
    description: "Mentale aspecten van voetbal",
    subtopics: [
      { 
        id: "ALGEMEEN_MENTAAL", 
        name: "Algemeen Mentaal", 
        description: "Mentale training en focus",
        color: "#8e44ad",
        icon: Brain,
        elements: [
          "Concentratie",
          "Rustig vs onrustig",
          "Spontaniteit",
          "Egoistisch",
          "Afleiding",
          "Nabootsen",
          "Zelfvertrouwen",
          "Zoeken naar bevestiging",
          "Inlevingsvermogen",
          "Winnaarsmentaliteit",
          "Emotionele weerbaarheid/stabiliteit",
          "Leergierig",
          "Doorzettingsvermogen",
          "Omkadering",
          "Motivatie",
          "Inzet",
          "Ambitie",
          "Zelfregulering",
          "Volharding",
          "Zelfbeeld",
          "Leersnelheid",
          "Inzicht",
          "Besluitvaardigheid",
          "Leervermogen",
          "Persoonlijkheid",
          "Leiderschap",
          "Betrokken",
          "Focus",
          "Respectvol"
        ]
      }
    ]
  }
];

interface TopicSelectorProps {
  onTopicChange?: (mainTopic: string, subtopic?: string, subcategory?: string) => void;
}

export function TopicSelector({ onTopicChange }: TopicSelectorProps) {
  const [selectedMainTopic, setSelectedMainTopic] = useState<string>("");
  const [selectedSubtopic, setSelectedSubtopic] = useState<string>("");
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>("");

  const handleMainTopicSelect = (topicId: string) => {
    setSelectedMainTopic(topicId);
    setSelectedSubtopic("");
    setSelectedSubcategory("");
    onTopicChange?.(topicId);
  };

  const handleSubtopicSelect = (mainTopicId: string, subtopicId: string) => {
    setSelectedMainTopic(mainTopicId);
    setSelectedSubtopic(subtopicId);
    setSelectedSubcategory("");
    onTopicChange?.(mainTopicId, subtopicId);
  };

  const handleSubcategorySelect = (mainTopicId: string, subtopicId: string, subcategoryId: string) => {
    setSelectedMainTopic(mainTopicId);
    setSelectedSubtopic(subtopicId);
    setSelectedSubcategory(subcategoryId);
    onTopicChange?.(mainTopicId, subtopicId, subcategoryId);
  };

  const currentTopic = mainTopics.find(topic => topic.id === selectedMainTopic);
  const currentSubtopic = currentTopic?.subtopics.find(sub => sub.id === selectedSubtopic);

  return (
    <div className="space-y-4">
      {/* Main Topic Grid */}
      <div>
        <h3 className="text-lg font-semibold mb-3">Kies Hoofdtopic</h3>
        <div className="grid grid-cols-2 gap-4">
          {mainTopics.map((topic) => (
            <button
              key={topic.id}
              onClick={() => handleMainTopicSelect(topic.id)}
              className={`p-4 rounded-lg border-2 transition-all hover:shadow-md ${
                selectedMainTopic === topic.id
                  ? 'border-primary bg-primary/5'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <topic.icon className="h-6 w-6 text-primary" />
                <div className="text-left">
                  <div className="font-medium">{topic.name}</div>
                  <div className="text-xs text-muted-foreground">{topic.description}</div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Subtopic Selection */}
      {currentTopic && (
        <div>
          <h3 className="text-lg font-semibold mb-3">
            Kies Niveau voor {currentTopic.name}
          </h3>
          <div className="grid grid-cols-1 gap-3">
            {currentTopic.subtopics.map((subtopic) => (
              <button
                key={subtopic.id}
                onClick={() => handleSubtopicSelect(currentTopic.id, subtopic.id)}
                className={`p-4 rounded-lg border-2 transition-all hover:shadow-md ${
                  selectedSubtopic === subtopic.id
                    ? 'border-primary bg-primary/5'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-4 h-4 rounded-full border border-gray-300"
                    style={{ backgroundColor: subtopic.color }}
                  />
                  <subtopic.icon className="h-5 w-5" style={{ color: subtopic.color }} />
                  <div className="text-left flex-1">
                    <div className="font-medium">{subtopic.name}</div>
                    <div className="text-xs text-muted-foreground">{subtopic.description}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Subcategory Selection for TEAMTACTISCH B+, B-, OMSCH B-/B+, and OMSCH B+/B- */}
      {selectedMainTopic === "TEAMTACTISCH" && (selectedSubtopic === "B+" || selectedSubtopic === "B-" || selectedSubtopic === "OMSCH_B_MIN_B_PLUS" || selectedSubtopic === "OMSCH_B_PLUS_B_MIN") && currentSubtopic?.subcategories && (
        <div>
          <h3 className="text-lg font-semibold mb-3">
            Kies Subcategorie voor {currentSubtopic.name}
          </h3>
          <div className="grid grid-cols-1 gap-3">
            {currentSubtopic.subcategories.map((subcategory) => (
              <button
                key={subcategory.id}
                onClick={() => handleSubcategorySelect(selectedMainTopic, selectedSubtopic, subcategory.id)}
                className={`p-4 rounded-lg border-2 transition-all hover:shadow-md ${
                  selectedSubcategory === subcategory.id
                    ? 'border-primary bg-primary/5'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="text-left">
                  <div className="font-medium text-lg">{subcategory.name}</div>
                  <div className="text-sm text-muted-foreground mb-2">{subcategory.description}</div>
                  <div className="text-xs text-gray-500">
                    {subcategory.elements.length} elementen beschikbaar
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Elements Display for Selected Subcategory */}
      {selectedMainTopic === "TEAMTACTISCH" && (selectedSubtopic === "B+" || selectedSubtopic === "B-" || selectedSubtopic === "OMSCH_B_MIN_B_PLUS" || selectedSubtopic === "OMSCH_B_PLUS_B_MIN") && selectedSubcategory && (
        <div>
          <h3 className="text-lg font-semibold mb-3">
            Elementen in {selectedSubcategory}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {currentSubtopic?.subcategories
              ?.find(sub => sub.id === selectedSubcategory)
              ?.elements.map((element, index) => (
              <DepthDetail
                key={index}
                elementName={element}
                topic="TEAMTACTISCH"
                subtopic={selectedSubtopic}
                subcategory={selectedSubcategory}
              />
            ))}
          </div>
        </div>
      )}

      {/* Elements Display for Topics with Direct Elements (BASICS and MENTAAL) */}
      {selectedMainTopic === "MENTAAL" && selectedSubtopic === "ALGEMEEN_MENTAAL" && (
        <div>
          <h3 className="text-lg font-semibold mb-3">
            Elementen in Algemeen Mentaal
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {[
              "Concentratie", "Rustig vs onrustig", "Spontaniteit", "Egoistisch", "Afleiding", "Nabootsen", 
              "Zelfvertrouwen", "Zoeken naar bevestiging", "Inlevingsvermogen", "Winnaarsmentaliteit", 
              "Emotionele weerbaarheid/stabiliteit", "Leergierig", "Doorzettingsvermogen", "Omkadering", 
              "Motivatie", "Inzet", "Ambitie", "Zelfregulering", "Volharding", "Zelfbeeld", "Leersnelheid", 
              "Inzicht", "Besluitvaardigheid", "Leervermogen", "Persoonlijkheid", "Leiderschap", 
              "Betrokken", "Focus", "Respectvol"
            ].map((element, index) => (
              <DepthDetail
                key={index}
                elementName={element}
                topic={selectedMainTopic}
                subtopic={selectedSubtopic}
              />
            ))}
          </div>
        </div>
      )}
      
      {/* Elements Display for Other Topics */}
      {selectedMainTopic && selectedSubtopic && selectedMainTopic !== "MENTAAL" && currentSubtopic?.elements && !currentSubtopic?.subcategories && (
        <div>
          <h3 className="text-lg font-semibold mb-3">
            Elementen in {currentSubtopic.name}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {currentSubtopic.elements.map((element, index) => (
              <DepthDetail
                key={index}
                elementName={element}
                topic={selectedMainTopic}
                subtopic={selectedSubtopic}
              />
            ))}
          </div>
        </div>
      )}

      {/* Current Selection Display */}
      {selectedMainTopic && selectedSubtopic && (
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="font-medium text-green-800">
              Geselecteerd: {currentTopic?.name} - {currentSubtopic?.name}
              {selectedSubcategory && ` - ${selectedSubcategory}`}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}