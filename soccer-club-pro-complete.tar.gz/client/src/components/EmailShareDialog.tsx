import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Mail, Download, Copy, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface EmailShareDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  planId: number;
  planName: string;
}

export function EmailShareDialog({ open, onOpenChange, planId, planName }: EmailShareDialogProps) {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [shareMethod, setShareMethod] = useState<'download' | 'copy' | null>(null);
  const { toast } = useToast();

  const handleDownload = async () => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/year-plans/${planId}/export/pdf`);
      const blob = await response.blob();
      
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `${planName.replace(/\s+/g, '_')}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      setShareMethod('download');
      toast({
        title: "PDF Downloaded",
        description: "Je kunt het bestand nu doormailen vanuit je downloads",
      });
    } catch (error) {
      toast({
        title: "Download Error",
        description: "Er ging iets mis bij het downloaden",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyLink = async () => {
    const shareText = `VVC Brasschaat - ${planName}

VVC Brasschaat - Dames InterProvinciaal Jaarplanning 2025-2026

Download het complete jaarplan:
${window.location.origin}/api/year-plans/${planId}/export/pdf

Alle verbeteringen toegepast:
• Complete thema weergave (geen elementen meer)
• Exacte tijden: 20:00 - 21:45
• VARIA opmerkingen volledig zichtbaar
• Professionele training boxes met nummering
• Chronologische sortering van alle 92 sessies

Dit PDF bevat alle verbeteringen die vandaag zijn geïmplementeerd.

Met vriendelijke groet,
Soccer Club Pro Team
VVC Brasschaat - Passie, Prestatie & Plezier - Samen Sterk!`;

    try {
      await navigator.clipboard.writeText(shareText);
      setShareMethod('copy');
      toast({
        title: "Tekst Gekopieerd",
        description: "Plak dit in je e-mail of WhatsApp bericht",
      });
    } catch (error) {
      toast({
        title: "Kopiëren Mislukt",
        description: "Probeer handmatig te kopiëren",
        variant: "destructive"
      });
    }
  };

  const handleEmailTest = async () => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/year-plans/${planId}/email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: email || 'test@example.com' }),
      });
      
      const result = await response.json();
      
      if (result.downloadReady) {
        toast({
          title: "Share Info Gereed",
          description: "Alle informatie voor delen is voorbereid - gebruik download of kopieer opties",
        });
      } else {
        toast({
          title: "E-mail Setup Info",
          description: result.message || "E-mail service configuratie vereist",
        });
      }
    } catch (error) {
      toast({
        title: "Test Mislukt",
        description: "Gebruik download optie als alternatief",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-blue-600" />
            Jaarplan Delen
          </DialogTitle>
          <DialogDescription>
            Kies hoe je het {planName} wilt delen
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Download Option */}
          <div className="border rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium flex items-center gap-2">
                  <Download className="h-4 w-4 text-green-600" />
                  Direct Downloaden
                </h4>
                <p className="text-sm text-gray-600">Download PDF en verstuur handmatig</p>
              </div>
              {shareMethod === 'download' && (
                <CheckCircle className="h-5 w-5 text-green-600" />
              )}
            </div>
            <Button 
              onClick={handleDownload} 
              disabled={isLoading}
              className="w-full"
              variant="outline"
            >
              {isLoading ? 'Downloaden...' : 'Download PDF (165KB)'}
            </Button>
          </div>

          {/* Copy Link Option */}
          <div className="border rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium flex items-center gap-2">
                  <Copy className="h-4 w-4 text-blue-600" />
                  Link Kopiëren
                </h4>
                <p className="text-sm text-gray-600">Kopieer tekst voor e-mail/WhatsApp</p>
              </div>
              {shareMethod === 'copy' && (
                <CheckCircle className="h-5 w-5 text-green-600" />
              )}
            </div>
            <Button 
              onClick={handleCopyLink}
              className="w-full"
              variant="outline"
            >
              Kopieer Deel Tekst
            </Button>
          </div>

          {/* Direct Email Send */}
          <div className="border border-green-200 rounded-lg p-4 bg-green-50">
            <div className="flex items-center gap-2 mb-2">
              <Mail className="h-4 w-4 text-green-600" />
              <h4 className="font-medium text-green-800">Automatische E-mail</h4>
            </div>
            <p className="text-sm text-green-700 mb-3">
              IP jaarplan wordt direct verstuurd naar ismail.achter@gmail.com
            </p>
            <Button 
              onClick={handleEmailSend}
              disabled={isLoading}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
            >
              {isLoading ? 'Versturen...' : 'Verstuur IP Jaarplan (165KB)'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}