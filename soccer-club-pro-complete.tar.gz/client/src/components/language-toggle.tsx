import { useLanguage } from "@/lib/i18n";

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center gap-1 p-1 bg-white border border-gray-200 rounded-lg shadow-sm">
      <button
        onClick={() => setLanguage('en')}
        className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
          language === 'en' 
            ? 'bg-primary text-white shadow-sm' 
            : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        🇬🇧 EN
      </button>
      <button
        onClick={() => setLanguage('nl')}
        className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
          language === 'nl' 
            ? 'bg-primary text-white shadow-sm' 
            : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        🇳🇱 NL
      </button>
    </div>
  );
}