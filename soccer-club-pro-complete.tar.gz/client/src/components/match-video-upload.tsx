import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Upload, FileVideo, FileImage, Play, CheckCircle, X } from "lucide-react";

interface MatchVideoUploadProps {
  onUploadComplete?: (videoId: number) => void;
}

const MatchVideoUpload: React.FC<MatchVideoUploadProps> = ({ onUploadComplete }) => {
  const [uploadData, setUploadData] = useState({
    title: '',
    teamId: '',
    opponent: '',
    matchDate: '',
    homeAway: 'home',
    notes: ''
  });
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [lineupFile, setLineupFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(1);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Upload video mutation
  const uploadVideoMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        
        xhr.upload.addEventListener('progress', (e) => {
          if (e.lengthComputable) {
            const percentComplete = (e.loaded / e.total) * 100;
            setUploadProgress(percentComplete);
          }
        });

        xhr.onload = () => {
          if (xhr.status === 200) {
            resolve(JSON.parse(xhr.responseText));
          } else {
            reject(new Error('Upload failed'));
          }
        };

        xhr.onerror = () => reject(new Error('Network error'));
        
        xhr.open('POST', '/api/match-performance/upload-video');
        xhr.send(formData);
      });
    },
    onSuccess: (data: any) => {
      toast({
        title: "Video Geüpload",
        description: `${uploadData.title} is succesvol geüpload`,
      });
      setCurrentStep(2);
      if (onUploadComplete) {
        onUploadComplete(data.id);
      }
    },
    onError: () => {
      toast({
        title: "Upload Fout",
        description: "Video kon niet geüpload worden",
        variant: "destructive",
      });
    }
  });

  // Upload lineup mutation
  const uploadLineupMutation = useMutation({
    mutationFn: async ({ formData, videoId }: { formData: FormData, videoId: number }) => {
      formData.append('matchId', videoId.toString());
      return apiRequest('/api/match-performance/upload-lineup', {
        method: 'POST',
        body: formData,
      });
    },
    onSuccess: () => {
      toast({
        title: "Ploegopstelling Verwerkt",
        description: "Spelersnamen en nummers zijn geëxtraheerd",
      });
      setCurrentStep(3);
    },
    onError: () => {
      toast({
        title: "Lineup Fout",
        description: "Ploegopstelling kon niet verwerkt worden",
        variant: "destructive",
      });
    }
  });

  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoFile(file);
      // Auto-generate title from filename
      if (!uploadData.title) {
        const filename = file.name.replace(/\.[^/.]+$/, "");
        setUploadData(prev => ({ ...prev, title: filename }));
      }
    }
  };

  const handleLineupFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setLineupFile(file);
  };

  const handleVideoUpload = () => {
    if (!videoFile || !uploadData.title || !uploadData.teamId) {
      toast({
        title: "Ontbrekende Gegevens",
        description: "Video, titel en team zijn verplicht",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append('video', videoFile);
    formData.append('title', uploadData.title);
    formData.append('teamId', uploadData.teamId);
    formData.append('matchDate', uploadData.matchDate);
    formData.append('opponent', uploadData.opponent);
    formData.append('homeAway', uploadData.homeAway);
    formData.append('notes', uploadData.notes);

    uploadVideoMutation.mutate(formData);
  };

  const handleLineupUpload = (videoId: number) => {
    if (!lineupFile) {
      toast({
        title: "Geen Ploegopstelling",
        description: "Selecteer een foto/PDF met de ploegopstelling",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append('lineup', lineupFile);
    
    uploadLineupMutation.mutate({ formData, videoId });
  };

  const resetUpload = () => {
    setUploadData({
      title: '',
      teamId: '',
      opponent: '',
      matchDate: '',
      homeAway: 'home',
      notes: ''
    });
    setVideoFile(null);
    setLineupFile(null);
    setUploadProgress(0);
    setCurrentStep(1);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileVideo className="h-5 w-5" />
          Wedstrijdvideo & Ploegopstelling Upload
        </CardTitle>
        <CardDescription>
          Upload wedstrijdbeelden en ploegopstelling voor GPS-stijl analyse
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Progress Steps */}
        <div className="flex items-center justify-between">
          <div className={`flex items-center gap-2 ${currentStep >= 1 ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
              {currentStep > 1 ? <CheckCircle className="h-4 w-4" /> : '1'}
            </div>
            <span className="text-sm font-medium">Video Upload</span>
          </div>
          <div className={`flex items-center gap-2 ${currentStep >= 2 ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
              {currentStep > 2 ? <CheckCircle className="h-4 w-4" /> : '2'}
            </div>
            <span className="text-sm font-medium">Ploegopstelling</span>
          </div>
          <div className={`flex items-center gap-2 ${currentStep >= 3 ? 'text-green-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 3 ? 'bg-green-600 text-white' : 'bg-gray-200'}`}>
              {currentStep >= 3 ? <CheckCircle className="h-4 w-4" /> : '3'}
            </div>
            <span className="text-sm font-medium">Gereed</span>
          </div>
        </div>

        {currentStep === 1 && (
          <div className="space-y-4">
            <div>
              <Label htmlFor="video-file">Wedstrijdvideo</Label>
              <Input
                id="video-file"
                type="file"
                accept="video/*"
                onChange={handleVideoFileChange}
                className="mt-1"
              />
              {videoFile && (
                <p className="text-sm text-green-600 mt-1">
                  ✓ {videoFile.name} ({(videoFile.size / 1024 / 1024).toFixed(1)} MB)
                </p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="title">Wedstrijd Titel</Label>
                <Input
                  id="title"
                  value={uploadData.title}
                  onChange={(e) => setUploadData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Svelta Melsele vs VVC IP"
                />
              </div>
              <div>
                <Label>Team</Label>
                <Select value={uploadData.teamId} onValueChange={(value) => setUploadData(prev => ({ ...prev, teamId: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer team" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Dames IP</SelectItem>
                    <SelectItem value="2">Dames Provinciaal</SelectItem>
                    <SelectItem value="3">MU20</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="opponent">Tegenstander</Label>
                <Input
                  id="opponent"
                  value={uploadData.opponent}
                  onChange={(e) => setUploadData(prev => ({ ...prev, opponent: e.target.value }))}
                  placeholder="Svelta Melsele"
                />
              </div>
              <div>
                <Label htmlFor="match-date">Wedstrijd Datum</Label>
                <Input
                  id="match-date"
                  type="date"
                  value={uploadData.matchDate}
                  onChange={(e) => setUploadData(prev => ({ ...prev, matchDate: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Opmerkingen</Label>
              <Textarea
                id="notes"
                value={uploadData.notes}
                onChange={(e) => setUploadData(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Score: 1-5, VVC speelt in het rood..."
                rows={3}
              />
            </div>

            {uploadVideoMutation.isPending && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Uploading...</span>
                  <span>{Math.round(uploadProgress)}%</span>
                </div>
                <Progress value={uploadProgress} />
              </div>
            )}

            <Button 
              onClick={handleVideoUpload}
              disabled={!videoFile || !uploadData.title || !uploadData.teamId || uploadVideoMutation.isPending}
              className="w-full"
            >
              {uploadVideoMutation.isPending ? (
                <>
                  <Upload className="h-4 w-4 mr-2 animate-spin" />
                  Video Uploaden...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Video
                </>
              )}
            </Button>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4">
            <div className="text-center text-green-600 mb-4">
              <CheckCircle className="h-8 w-8 mx-auto mb-2" />
              <p className="font-medium">Video succesvol geüpload!</p>
            </div>

            <div>
              <Label htmlFor="lineup-file">Ploegopstelling (PDF/Foto)</Label>
              <Input
                id="lineup-file"
                type="file"
                accept="image/*,.pdf"
                onChange={handleLineupFileChange}
                className="mt-1"
              />
              {lineupFile && (
                <p className="text-sm text-green-600 mt-1">
                  ✓ {lineupFile.name}
                </p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                Upload een foto of PDF met spelersnamen en nummers van beide teams
              </p>
            </div>

            <Button 
              onClick={() => handleLineupUpload(uploadVideoMutation.data?.id)}
              disabled={!lineupFile || uploadLineupMutation.isPending}
              className="w-full"
            >
              {uploadLineupMutation.isPending ? (
                <>
                  <FileImage className="h-4 w-4 mr-2 animate-spin" />
                  Ploegopstelling Verwerken...
                </>
              ) : (
                <>
                  <FileImage className="h-4 w-4 mr-2" />
                  Upload Ploegopstelling
                </>
              )}
            </Button>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-4 text-center">
            <div className="text-green-600 mb-4">
              <CheckCircle className="h-12 w-12 mx-auto mb-2" />
              <h3 className="text-lg font-semibold">Upload Voltooid!</h3>
              <p className="text-sm text-gray-600">
                Video en ploegopstelling zijn succesvol verwerkt
              </p>
            </div>

            <div className="space-y-2">
              <Button 
                onClick={() => window.location.href = '/match-performance'}
                className="w-full"
              >
                <Play className="h-4 w-4 mr-2" />
                Start GPS Analyse
              </Button>
              
              <Button 
                onClick={resetUpload}
                variant="outline"
                className="w-full"
              >
                <Upload className="h-4 w-4 mr-2" />
                Upload Nieuwe Wedstrijd
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MatchVideoUpload;