import { Switch, Route, useLocation } from "wouter";
import React, { useEffect, lazy } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard-new";
import Players from "@/pages/players";
import Teams from "@/pages/teams";
import Matches from "@/pages/matches";
import Training from "@/pages/training";

import Pitches from "@/pages/pitches";
import Parents from "@/pages/parents";
import Coaches from "@/pages/coaches";
import Settings from "@/pages/settings";
import TeamAssignments from "@/pages/team-assignments";
import Payments from "@/pages/payments";
import ClubInfo from "@/pages/club-info";
import DatabaseAdmin from "@/pages/admin/database";
import PlayerDashboard from "@/pages/player-dashboard";
import AuthPage from "@/pages/auth";
import IADatabank from "@/pages/iadatabank";
import JaarplanningDatabank from "@/pages/jaarplanning-databank";
import YearPlanningPage from "@/pages/year-planning";
import YearPlansPage from "@/pages/year-plans";
import TrainingSessionMaker from "@/pages/training-session-maker";
import ModernTrainingSessionMaker from "@/pages/modern-training-session-maker";
import ModernJaarplanning from "@/pages/modern-jaarplanning-fixed";
import TrainingPDFViewer from "@/pages/training-pdf-viewer";
import CalendarSimple from "@/pages/calendar-simple";
import CalendarClean from "@/pages/calendar-clean";
import TrainingImport from "@/pages/training-import";
import CalendarImport from "@/pages/calendar-import";
import Invitations from "@/pages/invitations";
import TeamSchedule from "@/pages/team-schedule";
import TeamOverviewDashboard from "@/pages/team-overview-dashboard";
import TeamWeekOverview from "@/pages/team-week-overview";
import TeamsManagement from "@/pages/teams-management";
import PlayersDatabase from "@/pages/players-database";
import ScoutDatabase from "@/pages/scout-database";
import PlayerToScout from "@/pages/player-to-scout";
import TeamSelection from "@/pages/team-selection";
import LogoOrganization from "@/pages/logo-organization";
import SubscriptionManagement from "@/pages/subscription-management";
import TermsOfService from "@/pages/terms-of-service";
import AuthenticMatchAnalyzer from "@/pages/authentic-match-analyzer";
import DirectGPSAnalysis from "@/pages/direct-gps-analysis";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { AuthProvider, useAuth } from "@/hooks/use-auth";

function Router() {
  const { user, isLoading } = useAuth();
  const [location, navigate] = useLocation();

  // Redirect authenticated users away from auth page
  useEffect(() => {
    if (user && location === "/auth") {
      navigate("/");
    }
  }, [user, location, navigate]);

  // Allow direct access to all match analysis pages
  const publicRoutes = [
    "/auth", 
    "/real-match-dashboard", 
    "/gps-match-analysis",
    "/direct-gps-analysis",
    "/match-performance",
    "/authentic-match-analyzer",
    "/individual-analysis",
    "/individual-basics",
    "/individual-player-analysis",
    "/match-analysis"
  ];
  
  useEffect(() => {
    if (!isLoading && !user && !publicRoutes.includes(location)) {
      navigate("/auth");
    }
  }, [user, isLoading, location, navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Show auth page for unauthenticated users (except public analysis routes)
  if (!user && !publicRoutes.includes(location)) {
    return (
      <Switch>
        <Route path="/auth" component={AuthPage} />
        <Route component={() => null} />
      </Switch>
    );
  }

  // Show public analysis pages without authentication
  if (publicRoutes.includes(location) && location !== "/auth") {
    if (location === "/match-analysis") {
      const MatchAnalysisDirect = React.lazy(() => import("@/pages/match-analysis-direct"));
      return (
        <div className="min-h-screen bg-white">
          <React.Suspense fallback={<div className="text-center p-8">Laden...</div>}>
            <MatchAnalysisDirect />
          </React.Suspense>
        </div>
      );
    }
    
    if (location === "/direct-gps-analysis") {
      return (
        <div className="min-h-screen bg-white p-6">
          <div className="bg-blue-600 text-white p-4 mb-4 rounded">
            <h1 className="text-xl font-bold mb-2">VVC Brasschaat - GPS Analyse</h1>
            <div className="flex flex-wrap gap-2">
              <a href="/direct-gps-analysis" className="bg-white text-blue-600 px-3 py-1 rounded text-sm">GPS Analyse</a>
              <a href="/" className="bg-white text-blue-600 px-3 py-1 rounded text-sm">Terug naar Menu</a>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold">VVC Brasschaat - GPS Analyse</h1>
              <div className="text-6xl font-bold">
                <span className="text-red-600">1</span>
                <span className="text-gray-400 mx-4">-</span>
                <span className="text-blue-600">5</span>
              </div>
              <div className="text-xl">
                <span className="font-semibold">SVELTA MELSELE</span>
                <span className="mx-2">vs</span>
                <span className="font-semibold">VVC BRASSCHAAT</span>
              </div>
              <div className="bg-gray-200 text-gray-800 px-4 py-2 rounded inline-block">
                za 08 maart 2025 - 15:00
              </div>
              <div className="text-sm text-gray-600">
                Authentieke wedstrijdopstelling - VVC won 1-5 uit
              </div>
            </div>

            <div className="bg-blue-50 p-6 rounded-lg">
              <h2 className="text-2xl font-bold text-blue-600 mb-4 text-center">VVC BRASSCHAAT A - Winnende Team</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#1</div>
                  <div className="font-semibold">Marieke Van Ammers</div>
                  <div className="text-sm text-gray-600">Keeper</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#4</div>
                  <div className="font-semibold">Laura Michielsen</div>
                  <div className="text-sm text-gray-600">Verdediger</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#6</div>
                  <div className="font-semibold">Sien Schepens</div>
                  <div className="text-sm text-gray-600">Middenvelder</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#7</div>
                  <div className="font-semibold">Jorien Dictus</div>
                  <div className="text-sm text-gray-600">Aanvaller</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#8</div>
                  <div className="font-semibold">Eline Bultje</div>
                  <div className="text-sm text-gray-600">Middenvelder</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#9</div>
                  <div className="font-semibold">Melissa Vinckx</div>
                  <div className="text-sm text-gray-600">Aanvaller</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#10</div>
                  <div className="font-semibold">Arianna De Maeyer</div>
                  <div className="text-sm text-gray-600">Middenvelder</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#14</div>
                  <div className="font-semibold">Julie Luyten</div>
                  <div className="text-sm text-gray-600">Verdediger</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#15</div>
                  <div className="font-semibold">Emily Van Rooy</div>
                  <div className="text-sm text-gray-600">Wissel</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#16</div>
                  <div className="font-semibold">Ine Denhaen</div>
                  <div className="text-sm text-gray-600">Wissel</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#17</div>
                  <div className="font-semibold">Louise Creemers</div>
                  <div className="text-sm text-gray-600">Middenvelder</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#19</div>
                  <div className="font-semibold">Ginger van Enthoven</div>
                  <div className="text-sm text-gray-600">Wissel</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#21</div>
                  <div className="font-semibold">Sophie Van Parys</div>
                  <div className="text-sm text-gray-600">Verdediger</div>
                </div>
                <div className="bg-white p-3 rounded-lg text-center shadow">
                  <div className="font-bold text-blue-600">#22</div>
                  <div className="font-semibold">Maud Bastiaensen</div>
                  <div className="text-sm text-gray-600">Verdediger</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg shadow">
                <h3 className="text-lg font-bold mb-2">Eindresultaat</h3>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">VVC won 5-1</div>
                  <div className="text-sm text-gray-600">Uitwedstrijd</div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg shadow">
                <h3 className="text-lg font-bold mb-2">VVC Spelers</h3>
                <div className="text-center">
                  <div className="text-2xl font-bold">14</div>
                  <div className="text-sm text-gray-600">Authentieke namen</div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg shadow">
                <h3 className="text-lg font-bold mb-2">Match Data</h3>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">566</div>
                  <div className="text-sm text-gray-600">Video frames</div>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="text-sm text-gray-600">
                Analyse gebaseerd op authentieke wedstrijddata<br/>
                Geen fictieve namen - uitsluitend officiële opstelling
              </div>
            </div>
          </div>
        </div>
      );
    }
    
    // Import the new match analysis component
    const MatchAnalysisDirect = React.lazy(() => import("@/pages/match-analysis-direct"));
    
    // Default fallback for other analysis routes
    return (
      <div className="min-h-screen bg-white p-6">
        <React.Suspense fallback={<div className="text-center p-8">Laden...</div>}>
          <MatchAnalysisDirect />
        </React.Suspense>
      </div>
    );
  }

  // Show app for authenticated users
  return (
    <div className="flex h-screen overflow-hidden bg-white">
      {/* <Sidebar /> */}
      
      <div className="flex-1 relative z-0 overflow-y-auto pt-2 pb-6">
        <Header />
        
        <main className="mx-auto px-4 sm:px-6 md:px-8">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/player-dashboard" component={PlayerDashboard} />
            <Route path="/club-info" component={ClubInfo} />
            <Route path="/players" component={Players} />
            <Route path="/teams" component={Teams} />
            <Route path="/teams-management" component={TeamsManagement} />
            <Route path="/team-schedule" component={TeamSchedule} />
            <Route path="/team-overview" component={TeamOverviewDashboard} />
            <Route path="/team-week-overview" component={TeamWeekOverview} />
            <Route path="/matches" component={Matches} />
            <Route path="/training" component={Training} />
            <Route path="/training-session-maker" component={TrainingSessionMaker} />
            <Route path="/modern-training-session-maker" component={ModernTrainingSessionMaker} />
            <Route path="/iadatabank" component={IADatabank} />
            <Route path="/jaarplanning" component={ModernJaarplanning} />
            <Route path="/jaarplanning-databank" component={JaarplanningDatabank} />
            <Route path="/calendar" component={CalendarClean} />
            <Route path="/calendar/:planId" component={CalendarClean} />
            <Route path="/training-pdf" component={TrainingPDFViewer} />

            <Route path="/year-planning" component={YearPlanningPage} />
            <Route path="/year-plans" component={YearPlansPage} />

            <Route path="/pitches" component={Pitches} />
            <Route path="/parents" component={Parents} />
            <Route path="/coaches" component={Coaches} />
            <Route path="/team-assignments" component={TeamAssignments} />
            <Route path="/payments" component={Payments} />
            <Route path="/settings" component={Settings} />
            <Route path="/admin/database" component={DatabaseAdmin} />
            <Route path="/players-database" component={PlayersDatabase} />
            <Route path="/scout-database" component={ScoutDatabase} />
            <Route path="/player-to-scout" component={PlayerToScout} />
            <Route path="/team-selection" component={TeamSelection} />
            <Route path="/logo-organization" component={LogoOrganization} />
            <Route path="/training-import" component={TrainingImport} />
            <Route path="/calendar-import" component={CalendarImport} />
            <Route path="/invitations" component={Invitations} />

            <Route path="/authentic-match-analyzer" component={AuthenticMatchAnalyzer} />
            <Route path="/match-performance-analysis" component={DirectGPSAnalysis} />
            <Route path="/match-performance" component={DirectGPSAnalysis} />

            <Route path="/subscription" component={SubscriptionManagement} />
            <Route path="/terms" component={TermsOfService} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
    </div>
  );
}

function App() {
  // Update document title when club info changes
  useEffect(() => {
    // Function to update title
    const updateTitle = async () => {
      try {
        const response = await fetch('/api/club/info');
        if (response.ok) {
          const clubInfo = await response.json();
          if (clubInfo && clubInfo.name) {
            document.title = `${clubInfo.name} - Club Management`;
          }
        }
      } catch (error) {
        console.error('Error fetching club info for title:', error);
      }
    };
    
    updateTitle();
    
    // Set up query subscription to update title when club info changes
    const unsubscribe = queryClient.getQueryCache().subscribe(() => {
      const query = queryClient.getQueryCache().find({ queryKey: ['/api/club/info'] });
      if (query && query.state.data) {
        const clubInfo = query.state.data as any;
        if (clubInfo && clubInfo.name) {
          document.title = `${clubInfo.name} - Club Management`;
        }
      }
    });
    
    return () => {
      unsubscribe();
    };
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
