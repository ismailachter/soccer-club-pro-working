import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Calendar, Download, FileText, Clock, Target, Shield, Play, Edit, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

const TrainingProgramsPage = () => {
  const [showCreateProgram, setShowCreateProgram] = useState(false);
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [editingEvent, setEditingEvent] = useState<string | null>(null);
  const [selectedProgram, setSelectedProgram] = useState<number | null>(null);
  
  // Program Creation State
  const [programForm, setProgramForm] = useState({
    name: "",
    startDate: "",
    endDate: "",
    trainingDays: [] as string[]
  });

  // Event Creation State
  const [eventForm, setEventForm] = useState({
    type: "training", // "training" or "match"
    date: "",
    name: "",
    phase: "foundation",
    opponent: "", // for matches
    location: "", // for matches
    notes: ""
  });

  // Training Day Options
  const trainingDayOptions = [
    { value: "monday", label: "Maandag" },
    { value: "tuesday", label: "Dinsdag" },
    { value: "wednesday", label: "Woensdag" },
    { value: "thursday", label: "Donderdag" },
    { value: "friday", label: "Vrijdag" },
    { value: "saturday", label: "Zaterdag" },
    { value: "sunday", label: "Zondag" }
  ];

  // Blessurepreventie - Geperiodiseerd over 8 weken (10 min per training)
  const blessurepreventieSchema = {
    week1: {
      enkels: { oefening: "Enkeltaps", herhalingen: "3x15", focus: "Stabiliteit" },
      acl: { oefening: "Squat holds", herhalingen: "3x30s", focus: "Knie stabiliteit" },
      hamstrings: { oefening: "Glute bridges", herhalingen: "3x12", focus: "Activatie" },
      adductoren: { oefening: "Side lunges", herhalingen: "3x10", focus: "Mobiliteit" },
      romp: { oefening: "Dead bugs", herhalingen: "3x8", focus: "Core stabiliteit" }
    },
    week2: {
      enkels: { oefening: "Single leg stands", herhalingen: "3x20s", focus: "Balans" },
      acl: { oefening: "Wall squats", herhalingen: "3x12", focus: "Bewegingspatroon" },
      hamstrings: { oefening: "Single leg RDL", herhalingen: "3x8", focus: "Rek & kracht" },
      adductoren: { oefening: "Cossack squats", herhalingen: "3x8", focus: "Dynamische rek" },
      romp: { oefening: "Bird dogs", herhalingen: "3x10", focus: "Diagonale stabiliteit" }
    },
    week3: {
      enkels: { oefening: "Ankle circles", herhalingen: "3x10", focus: "Mobiliteit" },
      acl: { oefening: "Jump landings", herhalingen: "3x8", focus: "Landing mechaniek" },
      hamstrings: { oefening: "Nordic curls (assisted)", herhalingen: "3x5", focus: "Excentrische kracht" },
      adductoren: { oefening: "Lateral bounds", herhalingen: "3x6", focus: "Plyometric" },
      romp: { oefening: "Plank variations", herhalingen: "3x25s", focus: "Isometrische kracht" }
    },
    week4: {
      enkels: { oefening: "Heel walks", herhalingen: "3x15", focus: "Proprioceptie" },
      acl: { oefening: "Single leg squats", herhalingen: "3x6", focus: "Unilaterale kracht" },
      hamstrings: { oefening: "Hamstring curls", herhalingen: "3x10", focus: "Isolatie kracht" },
      adductoren: { oefening: "Sumo squats", herhalingen: "3x12", focus: "Functionele kracht" },
      romp: { oefening: "Russian twists", herhalingen: "3x15", focus: "Rotatie stabiliteit" }
    },
    week5: {
      enkels: { oefening: "Bosu stands", herhalingen: "3x30s", focus: "Instabiele ondergrond" },
      acl: { oefening: "Lateral lunges", herhalingen: "3x10", focus: "Multi-vlak beweging" },
      hamstrings: { oefening: "Good mornings", herhalingen: "3x12", focus: "Hip hinge patroon" },
      adductoren: { oefening: "Side shuffles", herhalingen: "3x12", focus: "Laterale beweging" },
      romp: { oefening: "Mountain climbers", herhalingen: "3x20", focus: "Dynamische core" }
    },
    week6: {
      enkels: { oefening: "Single leg hops", herhalingen: "3x8", focus: "Plyometric power" },
      acl: { oefening: "Deceleration drills", herhalingen: "3x6", focus: "Remmen & stoppen" },
      hamstrings: { oefening: "Sprint build-ups", herhalingen: "3x20m", focus: "Snelheid opbouw" },
      adductoren: { oefening: "Speed skaters", herhalingen: "3x10", focus: "Explosieve laterale kracht" },
      romp: { oefening: "Med ball rotations", herhalingen: "3x12", focus: "Explosieve rotatie" }
    },
    week7: {
      enkels: { oefening: "Multi-directional hops", herhalingen: "3x6", focus: "Sport-specifiek" },
      acl: { oefening: "Change of direction", herhalingen: "3x8", focus: "Richting verandering" },
      hamstrings: { oefening: "High knees", herhalingen: "3x15", focus: "Snelheid voorbereiding" },
      adductoren: { oefening: "Lateral plyos", herhalingen: "3x8", focus: "Explosieve kracht" },
      romp: { oefening: "Plank jacks", herhalingen: "3x15", focus: "Dynamische stabiliteit" }
    },
    week8: {
      enkels: { oefening: "Agility ladder", herhalingen: "3x30s", focus: "Snelheid & coördinatie" },
      acl: { oefening: "Jump sequences", herhalingen: "3x5", focus: "Complex bewegingen" },
      hamstrings: { oefening: "Acceleration runs", herhalingen: "3x15m", focus: "Match intensiteit" },
      adductoren: { oefening: "Cutting drills", herhalingen: "3x6", focus: "Sport-specifieke beweging" },
      romp: { oefening: "Anti-rotation holds", herhalingen: "3x20s", focus: "Functionele stabiliteit" }
    }
  };

  // HIIT Conditie Opbouw (30 minuten) - Start heel laag niveau
  const hiitConditieOpbouw = {
    foundation: {
      work: 15, // seconden - Start heel laag
      rest: 30, // seconden - Kort rust zoals gevraagd
      series: 8, // Minder series
      intensity: "60% max HR",
      description: "Foundation start - 15s werk/30s rust",
      oefeningen: [
        "Rustig joggen op plaats (15s)",
        "Lichte high knees (15s)",
        "Zacht jumping jacks (15s)",
        "Walking lunges (15s)",
        "Arm swings (15s)",
        "Lichte march op plaats (15s)"
      ],
      notes: "Focus op correcte uitvoering, 60% intensiteit"
    },
    building: {
      work: 30, // seconden - Geleidelijke toename
      rest: 60, // seconden - Zoals gevraagd
      series: 12, // Meer series
      intensity: "60% → 75% max HR", 
      description: "Building fase - 30s werk/60s rust, opbouw in %",
      oefeningen: [
        "Shuttle runs (20m)",
        "Mountain climbers (30s)",
        "Burpees aangepast tempo (30s)",
        "High knees tempo verhogen (30s)",
        "Step-ups op plaats (30s)",
        "Squat jumps laag tempo (30s)"
      ],
      notes: "Progressieve opbouw van 60% naar 75% intensiteit"
    },
    work: {
      work: 10, // seconden - Start met 10s
      rest: 45, // seconden - Constante rust
      series: 8, // Series
      intensity: "100% max HR",
      description: "Work fase - 10s→30s werk/45s rust over 8 weken",
      progression: {
        week1: { work: 10, description: "10s all-out/45s rust" },
        week2: { work: 12, description: "12s all-out/45s rust" },
        week3: { work: 15, description: "15s all-out/45s rust" },
        week4: { work: 18, description: "18s all-out/45s rust" },
        week5: { work: 20, description: "20s all-out/45s rust" },
        week6: { work: 24, description: "24s all-out/45s rust" },
        week7: { work: 27, description: "27s all-out/45s rust" },
        week8: { work: 30, description: "30s all-out/45s rust" }
      },
      oefeningen: [
        "All-out sprints (30m)",
        "Explosive burpees (maximale snelheid)",
        "Mountain climbers (100% tempo)",
        "High knees explosief",
        "Jump squats maximaal",
        "Battle ropes all-out"
      ],
      notes: "100% intensiteit - maximale inspanning, progressieve duur opbouw"
    },
    peak: {
      work: 45, // seconden - Verdere toename
      rest: 60, // seconden - Match-like rust
      series: 15, // Meer volume
      intensity: "80-90% max HR",
      description: "Match intensiteit voorbereiding",
      oefeningen: [
        "All-out sprints (30m)",
        "Explosive burpees (45s)",
        "High intensity mountain climbers (45s)",
        "Plyometric jump squats (45s)",
        "Sprint intervals with direction changes",
        "Competition simulation drills"
      ],
      notes: "Maximale intensiteit, match-ready"
    }
  };

  // HIIT Kracht Exercises - Gedetailleerd per spiergroep
  const hiitKrachtExercises = {
    foundation: {
      rompstabilisatie: {
        exercises: ["Planks (30s)", "Side planks (20s elke kant)", "Dead bugs (10 per kant)"],
        duration: "2.5 min",
        focus: "Stabiele basis opbouwen"
      },
      krachtBenen: {
        exercises: ["Bodyweight squats (15 reps)", "Lunges (10 per been)", "Wall sits (30s)"],
        duration: "2.5 min", 
        focus: "Functionele beenkracht"
      },
      krachtHamstrings: {
        exercises: ["Single leg deadlifts (8 per been)", "Glute bridges (15 reps)", "Nordic curls assisted (5 reps)"],
        duration: "2.5 min",
        focus: "Hamstring sterkte en flexibiliteit"
      },
      krachtAdductoren: {
        exercises: ["Side lunges (10 per kant)", "Cossack squats (8 per kant)", "Lateral leg raises (12 per been)"],
        duration: "2.5 min",
        focus: "Laterale stabiliteit"
      },
      krachtRomp: {
        exercises: ["Mountain climbers (20 reps)", "Russian twists (15 per kant)", "Bicycle crunches (15 per kant)"],
        duration: "2.5 min",
        focus: "Core activatie"
      },
      krachtArmen: {
        exercises: ["Push-ups (10 reps)", "Pike push-ups (8 reps)", "Tricep dips (10 reps)"],
        duration: "2.5 min",
        focus: "Bovenlichaam kracht"
      }
    },
    building: {
      rompstabilisatie: {
        exercises: ["Dynamic planks (45s)", "Plank up-downs (10 reps)", "Bear crawls (30s)"],
        duration: "2.5 min",
        focus: "Dynamische stabiliteit"
      },
      krachtBenen: {
        exercises: ["Jump squats (12 reps)", "Split lunges (8 per been)", "Single leg squats (5 per been)"],
        duration: "2.5 min",
        focus: "Explosieve beenkracht"
      },
      krachtHamstrings: {
        exercises: ["Single leg RDL (10 per been)", "Jump glute bridges (12 reps)", "Nordic curls (8 reps)"],
        duration: "2.5 min",
        focus: "Kracht en explosiviteit"
      },
      krachtAdductoren: {
        exercises: ["Lateral bounds (10 per kant)", "Side lunge jumps (8 per kant)", "Adductor slides (12 per kant)"],
        duration: "2.5 min",
        focus: "Dynamische laterale kracht"
      },
      krachtRomp: {
        exercises: ["Explosive mountain climbers (30 reps)", "V-ups (12 reps)", "Plank jacks (15 reps)"],
        duration: "2.5 min",
        focus: "Explosieve core kracht"
      },
      krachtArmen: {
        exercises: ["Explosive push-ups (8 reps)", "Handstand progressions (30s)", "Diamond push-ups (8 reps)"],
        duration: "2.5 min",
        focus: "Explosieve armkracht"
      }
    },
    peak: {
      rompstabilisatie: {
        exercises: ["Single arm planks (30s per arm)", "Plank to pike (10 reps)", "Dynamic bear crawls (45s)"],
        duration: "2.5 min",
        focus: "Maximale stabiliteit"
      },
      krachtBenen: {
        exercises: ["Single leg jump squats (6 per been)", "Pistol squats (3 per been)", "Plyometric lunges (10 reps)"],
        duration: "2.5 min",
        focus: "Maximale explosiviteit"
      },
      krachtHamstrings: {
        exercises: ["Single leg Nordic curls (5 per been)", "Explosive RDL (10 reps)", "Jump bridges (15 reps)"],
        duration: "2.5 min",
        focus: "Maximale hamstring kracht"
      },
      krachtAdductoren: {
        exercises: ["Lateral plyometric bounds (8 per kant)", "Speed skaters (20 reps)", "Single leg lateral hops (10 per been)"],
        duration: "2.5 min",
        focus: "Maximale laterale power"
      },
      krachtRomp: {
        exercises: ["Explosive V-ups (15 reps)", "Plank burpees (8 reps)", "Single arm mountain climbers (20 per arm)"],
        duration: "2.5 min",
        focus: "Maximale core power"
      },
      krachtArmen: {
        exercises: ["Handstand push-ups (5 reps)", "Clap push-ups (6 reps)", "Archer push-ups (4 per arm)"],
        duration: "2.5 min",
        focus: "Maximale armkracht"
      }
    }
  };

  // Storage
  const [createdPrograms, setCreatedPrograms] = useState<Array<{
    id: number;
    name: string;
    startDate: string;
    endDate: string;
    trainingDays: string[];
    events: Array<{
      id: string;
      type: "training" | "match";
      date: string;
      name: string;
      phase?: string;
      opponent?: string;
      location?: string;
      notes: string;
      components?: {
        warmup: { duration: number; description: string };
        conditioning: { duration: number; work: number; rest: number; series: number; intensity: string };
        strength: { duration: number; spiergroepen: string[] };
        cooldown: { duration: number; description: string };
      };
    }>;
    created: string;
  }>>([]);

  // Functions
  const calculateDuration = () => {
    if (programForm.startDate && programForm.endDate) {
      const start = new Date(programForm.startDate);
      const end = new Date(programForm.endDate);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      const weeks = Math.ceil(diffDays / 7);
      return `${weeks} weken (${diffDays} dagen)`;
    }
    return "";
  };

  const handleCreateProgram = () => {
    const newProgram = {
      id: Date.now(),
      name: programForm.name || "Pre Season Program",
      startDate: programForm.startDate,
      endDate: programForm.endDate,
      trainingDays: programForm.trainingDays,
      events: [],
      created: new Date().toLocaleDateString('nl-NL')
    };

    setCreatedPrograms([...createdPrograms, newProgram]);
    setShowCreateProgram(false);
    setProgramForm({ name: "", startDate: "", endDate: "", trainingDays: [] });
  };

  const handleSaveEvent = () => {
    if (!selectedProgram) return;
    
    const phaseData = hiitConditieOpbouw[eventForm.phase as keyof typeof hiitConditieOpbouw];
    
    // Calculate which week this training falls in based on program start date
    const program = createdPrograms.find(p => p.id === selectedProgram);
    let weekNumber = 1;
    if (program && eventForm.date) {
      const startDate = new Date(program.startDate);
      const eventDate = new Date(eventForm.date);
      const diffTime = eventDate.getTime() - startDate.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      weekNumber = Math.max(1, Math.min(8, Math.ceil(diffDays / 7)));
    }
    
    const weekKey = `week${weekNumber}` as keyof typeof blessurepreventieSchema;
    const blessurepreventieData = blessurepreventieSchema[weekKey];
    
    const newEvent = {
      id: editingEvent || Date.now().toString(),
      type: eventForm.type as "training" | "match",
      date: eventForm.date,
      name: eventForm.name || (eventForm.type === "training" ? `Training ${eventForm.phase} Week ${weekNumber}` : `Match vs ${eventForm.opponent}`),
      phase: eventForm.phase,
      opponent: eventForm.opponent,
      location: eventForm.location,
      notes: eventForm.notes,
      components: eventForm.type === "training" ? {
        warmup: { duration: 10, description: "Inlopen - Hartslag Max 140" },
        blessurepreventie: {
          duration: 10,
          week: weekNumber,
          oefeningen: {
            enkels: blessurepreventieData.enkels,
            acl: blessurepreventieData.acl,
            hamstrings: blessurepreventieData.hamstrings,
            adductoren: blessurepreventieData.adductoren,
            romp: blessurepreventieData.romp
          }
        },
        conditioning: { 
          duration: 30, 
          work: phaseData.work, 
          rest: phaseData.rest, 
          series: phaseData.series, 
          intensity: phaseData.intensity 
        },
        strength: { 
          duration: 15, 
          spiergroepen: [
            "Rompstabilisatie", "Kracht benen", "Kracht hamstrings", 
            "Kracht adductoren", "Kracht romp", "Kracht armen"
          ]
        },
        cooldown: { duration: 5, description: "Recovery & prevention" }
      } : undefined
    };

    setCreatedPrograms(prev => prev.map(program => 
      program.id === selectedProgram 
        ? {
            ...program, 
            events: editingEvent 
              ? program.events.map(e => e.id === editingEvent ? newEvent : e)
              : [...program.events, newEvent]
          }
        : program
    ));

    setShowAddEvent(false);
    setEditingEvent(null);
    setEventForm({ type: "training", date: "", name: "", phase: "foundation", opponent: "", location: "", notes: "" });
  };

  const handleEditEvent = (event: any) => {
    setEventForm({
      type: event.type,
      date: event.date,
      name: event.name,
      phase: event.phase || "foundation",
      opponent: event.opponent || "",
      location: event.location || "",
      notes: event.notes
    });
    setEditingEvent(event.id);
    setShowAddEvent(true);
  };

  const handleDeleteEvent = (eventId: string) => {
    if (!selectedProgram || !confirm('Weet je zeker dat je dit event wilt verwijderen?')) return;
    
    setCreatedPrograms(prev => prev.map(program => 
      program.id === selectedProgram 
        ? { ...program, events: program.events.filter(e => e.id !== eventId) }
        : program
    ));
  };

  // Export Functions with Complete Details
  const exportToPDF = (program: any) => {
    // Create comprehensive PDF content
    const pdfContent = {
      title: program.name,
      period: `${program.startDate} t/m ${program.endDate}`,
      trainingDays: program.trainingDays.map(day => trainingDayOptions.find(opt => opt.value === day)?.label).join(", "),
      
      // Training Structure Details
      structure: {
        warmup: {
          duration: "10 minuten",
          description: "Inlopen - Hartslag Max 140",
          activity: "Rustig inlopen om het lichaam voor te bereiden op de training"
        },
        conditioning: {
          duration: "30 minuten",
          foundation: "15s werk/30s rust × 8 series (60% max HR)",
          building: "30s werk/60s rust × 12 series (60%→75% max HR)",
          work: "10s→30s werk/45s rust × 8 series (100% max HR - 8 weken progressie)",
          exercises: {
            foundation: hiitConditieOpbouw.foundation.oefeningen,
            building: hiitConditieOpbouw.building.oefeningen,
            work: hiitConditieOpbouw.work.oefeningen
          },
          workProgression: hiitConditieOpbouw.work.progression
        },
        strength: {
          duration: "15 minuten",
          description: "6 Spiergroepen - 2.5 min per groep",
          foundation: hiitKrachtExercises.foundation,
          building: hiitKrachtExercises.building
        },
        cooldown: {
          duration: "5 minuten",
          exercises: [
            "Hamstring stretch (2x 20s per been): Zittend been gestrekt, reik naar tenen",
            "Calf stretch (2x 15s per been): Tegen muur, achterste been gestrekt",
            "Hip flexor stretch (2x 15s per kant): Lunge positie, heup naar voren",
            "IT-band stretch (2x 15s per kant): Been over been, zijwaarts buigen",
            "Glute stretch (2x 15s per kant): Op rug, knie naar borst",
            "Shoulder doorway stretch (1x 20s): Onderarm tegen deurpost 90°",
            "Ankle mobility (10 circles elke richting): Trage cirkels",
            "Neck rolls (5 langzame rondjes): Voorzichtig hoofd rollen",
            "Ademhaling (5 cycli): 4s inademen → 4s vasthouden → 6s uitademen"
          ]
        }
      },
      
      // All Events with Details
      events: program.events.map((event: any) => ({
        date: event.date,
        type: event.type,
        name: event.name,
        phase: event.phase,
        opponent: event.opponent,
        location: event.location,
        notes: event.notes,
        components: event.components
      }))
    };
    
    // Simulate PDF generation with full details
    console.log("PDF Content:", pdfContent);
    alert(`📄 PDF "${program.name}" gegenereerd met volledige details:\n\n✅ Training structuur (60 min breakdown)\n✅ HIIT conditie schema's per fase\n✅ 6 spiergroepen kracht oefeningen\n✅ 9 blessurepreventieve cool-down oefeningen\n✅ Alle events met datum/tijd\n✅ Wedstrijden met tegenstander/locatie\n\nPDF wordt gedownload...`);
  };

  const exportToExcel = (program: any) => {
    // Create detailed Excel structure
    const excelData = {
      // Sheet 1: Program Overview
      overview: {
        programName: program.name,
        startDate: program.startDate,
        endDate: program.endDate,
        trainingDays: program.trainingDays,
        totalEvents: program.events.length,
        trainingSessions: program.events.filter((e: any) => e.type === 'training').length,
        matches: program.events.filter((e: any) => e.type === 'match').length
      },
      
      // Sheet 2: Training Structure
      trainingStructure: [
        { component: "Opwarming", duration: "10 min", description: "Inlopen - Hartslag Max 140", details: "Rustig inlopen om lichaam voor te bereiden" },
        { component: "Conditie HIIT", duration: "30 min", description: "Foundation: 15s/120s×8", details: "Building: 30s/90s×12" },
        { component: "Kracht HIIT", duration: "15 min", description: "6 spiergroepen × 2.5 min", details: "Rompstabilisatie, Benen, Hamstrings, Adductoren, Romp, Armen" },
        { component: "Cool-down", duration: "5 min", description: "9 blessurepreventieve oefeningen", details: "Stretching + ademhaling" }
      ],
      
      // Sheet 3: HIIT Conditie Details
      hiitConditioning: [
        { fase: "Foundation", werk: "15s", rust: "30s", series: 8, intensity: "60% max HR", oefeningen: hiitConditieOpbouw.foundation.oefeningen.join(", ") },
        { fase: "Building", werk: "30s", rust: "60s", series: 12, intensity: "60%→75% max HR", oefeningen: hiitConditieOpbouw.building.oefeningen.join(", ") },
        { fase: "Work", werk: "10s→30s", rust: "45s", series: 8, intensity: "100% max HR", oefeningen: hiitConditieOpbouw.work.oefeningen.join(", ") }
      ],
      
      // Sheet 7: Work Phase Progression
      workProgression: Object.keys(hiitConditieOpbouw.work.progression).map(week => ({
        week: week,
        work_duration: hiitConditieOpbouw.work.progression[week as keyof typeof hiitConditieOpbouw.work.progression].work + "s",
        rest_duration: "45s",
        intensity: "100% max HR",
        description: hiitConditieOpbouw.work.progression[week as keyof typeof hiitConditieOpbouw.work.progression].description
      })),
      
      // Sheet 4: Kracht Oefeningen per Spiergroep
      strengthExercises: Object.keys(hiitKrachtExercises.foundation).map(muscle => ({
        spiergroep: muscle,
        foundation_oefeningen: hiitKrachtExercises.foundation[muscle as keyof typeof hiitKrachtExercises.foundation].exercises.join(", "),
        foundation_duration: hiitKrachtExercises.foundation[muscle as keyof typeof hiitKrachtExercises.foundation].duration,
        building_oefeningen: hiitKrachtExercises.building[muscle as keyof typeof hiitKrachtExercises.building].exercises.join(", "),
        building_duration: hiitKrachtExercises.building[muscle as keyof typeof hiitKrachtExercises.building].duration
      })),
      
      // Sheet 5: Event Schedule
      schedule: program.events.map((event: any, index: number) => ({
        week: Math.ceil((index + 1) / 3),
        date: event.date,
        day: new Date(event.date).toLocaleDateString('nl-NL', { weekday: 'long' }),
        type: event.type === 'training' ? 'Training' : 'Wedstrijd',
        name: event.name,
        phase: event.phase || '',
        opponent: event.opponent || '',
        location: event.location || '',
        notes: event.notes || '',
        hiit_work: event.components?.conditioning?.work || '',
        hiit_rest: event.components?.conditioning?.rest || '',
        hiit_series: event.components?.conditioning?.series || ''
      })),
      
      // Sheet 6: Cool-down Details
      cooldownExercises: [
        { oefening: "Hamstring stretch", duur: "2x 20s per been", uitvoering: "Zittend been gestrekt, reik naar tenen tot lichte spanning" },
        { oefening: "Calf stretch", duur: "2x 15s per been", uitvoering: "Tegen muur, achterste been gestrekt, hiel op grond drukken" },
        { oefening: "Hip flexor stretch", duur: "2x 15s per kant", uitvoering: "Lunge positie, heup naar voren duwen" },
        { oefening: "IT-band stretch", duur: "2x 15s per kant", uitvoering: "Been over been, zijwaarts buigen" },
        { oefening: "Glute stretch", duur: "2x 15s per kant", uitvoering: "Op rug, knie naar borst, draai been naar andere kant" },
        { oefening: "Shoulder doorway stretch", duur: "1x 20s", uitvoering: "Onderarm tegen deurpost 90°, stap voorwaarts" },
        { oefening: "Ankle mobility", duur: "10 circles elke richting", uitvoering: "Zittend, trage cirkels rechtsom en linksom" },
        { oefening: "Neck rolls", duur: "5 langzame rondjes", uitvoering: "Voorzichtig hoofd rollen in alle richtingen" },
        { oefening: "Ademhaling", duur: "5 cycli", uitvoering: "4s inademen → 4s vasthouden → 6s uitademen" }
      ]
    };
    
    console.log("Excel Data:", excelData);
    alert(`📊 Excel "${program.name}" gegenereerd met 6 gedetailleerde sheets:\n\n📋 Program Overview\n🏃‍♂️ Training Structure (60 min breakdown)\n💪 HIIT Conditie (Foundation/Building schemas)\n🏋️‍♂️ Kracht Oefeningen (per spiergroep)\n📅 Event Schedule (week/datum/details)\n🧘‍♂️ Cool-down Exercises (9 oefeningen)\n\nExcel wordt gedownload...`);
  };

  const exportToICS = (program: any) => {
    // Create ICS calendar format with all details
    const icsEvents = program.events.map((event: any) => {
      const eventDate = new Date(event.date);
      const startTime = new Date(eventDate.setHours(19, 0, 0)); // Default 19:00
      const endTime = new Date(eventDate.setHours(20, 0, 0)); // 1 hour duration
      
      let description = '';
      let summary = '';
      
      if (event.type === 'training') {
        summary = `Training ${event.phase || 'Foundation'}`;
        description = `TRAINING DETAILS:\\n\\n` +
          `📋 Fase: ${event.phase || 'Foundation'}\\n` +
          `⏱️ Duur: 60 minuten\\n\\n` +
          `STRUCTUUR:\\n` +
          `• 10 min Opwarming (Inlopen max 140 HR)\\n` +
          `• 30 min Conditie HIIT\\n` +
          `• 15 min Kracht HIIT (6 spiergroepen)\\n` +
          `• 5 min Cool-down (blessurepreventie)\\n\\n` +
          `HIIT SCHEMA:\\n` +
          `• Foundation: 15s werk/30s rust × 8 (60% HR)\\n` +
          `• Building: 30s werk/60s rust × 12 (60%→75% HR)\\n` +
          `• Work: 10s→30s werk/45s rust × 8 (100% HR)\\n\\n` +
          `KRACHT SPIERGROEPEN:\\n` +
          `• Rompstabilisatie (2.5 min)\\n` +
          `• Kracht benen (2.5 min)\\n` +
          `• Kracht hamstrings (2.5 min)\\n` +
          `• Kracht adductoren (2.5 min)\\n` +
          `• Kracht romp (2.5 min)\\n` +
          `• Kracht armen (2.5 min)\\n\\n` +
          `COOL-DOWN OEFENINGEN:\\n` +
          `• Hamstring stretch (2x 20s)\\n` +
          `• Calf stretch (2x 15s)\\n` +
          `• Hip flexor stretch (2x 15s)\\n` +
          `• IT-band stretch (2x 15s)\\n` +
          `• Glute stretch (2x 15s)\\n` +
          `• Shoulder doorway stretch (20s)\\n` +
          `• Ankle mobility (10 circles)\\n` +
          `• Neck rolls (5 rondjes)\\n` +
          `• Ademhaling (5 cycli)\\n\\n` +
          `NOTITIES: ${event.notes || 'Geen extra notities'}`;
      } else {
        summary = `Wedstrijd vs ${event.opponent || 'TBD'}`;
        description = `WEDSTRIJD DETAILS:\\n\\n` +
          `⚽ Tegenstander: ${event.opponent || 'Te bepalen'}\\n` +
          `📍 Locatie: ${event.location || 'Te bepalen'}\\n` +
          `📝 Notities: ${event.notes || 'Geen extra notities'}\\n\\n` +
          `VOORBEREIDING:\\n` +
          `Zorg voor adequate warming-up en hydratatie voor de wedstrijd.`;
      }
      
      return {
        summary,
        description,
        startTime: startTime.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z',
        endTime: endTime.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z',
        uid: `${event.id}@preseason-program`,
        location: event.location || 'Sportcomplex'
      };
    });
    
    console.log("ICS Events:", icsEvents);
    alert(`📅 ICS Calendar "${program.name}" gegenereerd met volledige details:\n\n✅ ${program.events.filter((e: any) => e.type === 'training').length} Trainingen met complete 60-min structuur\n✅ ${program.events.filter((e: any) => e.type === 'match').length} Wedstrijden met tegenstander/locatie\n✅ HIIT schema's per training fase\n✅ 6 spiergroepen kracht details\n✅ 9 blessurepreventieve cool-down oefeningen\n✅ Compatible met Google Calendar, Outlook, Apple Calendar\n\nICS bestand wordt gedownload...`);
  };

  const getSelectedProgramData = () => {
    return createdPrograms.find(p => p.id === selectedProgram);
  };

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Pre Season Programs</h1>
        <p className="text-muted-foreground mb-4">
          Professionele voorbereiding programma's met startdatum en einddatum
        </p>
        
        {/* Direct Program Creation Form */}
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <h3 className="font-semibold text-blue-800 mb-3">📋 Nieuw Pre Season Program</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="directProgramName" className="text-sm font-medium">Program Naam</Label>
              <input
                id="directProgramName"
                type="text"
                placeholder="bijv. Pre Season 2025"
                value={programForm.name}
                onChange={(e) => setProgramForm(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              />
            </div>

            <div>
              <Label htmlFor="directStartDate" className="text-sm font-medium">Startdatum</Label>
              <input
                id="directStartDate"
                type="date"
                value={programForm.startDate}
                onChange={(e) => setProgramForm(prev => ({ ...prev, startDate: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              />
            </div>

            <div>
              <Label htmlFor="directEndDate" className="text-sm font-medium">Einddatum</Label>
              <input
                id="directEndDate"
                type="date"
                value={programForm.endDate}
                onChange={(e) => setProgramForm(prev => ({ ...prev, endDate: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              />
            </div>
          </div>

          <div className="mt-4">
            <Label className="text-sm font-medium">Training Dagen (selecteer minimaal 3)</Label>
            <div className="grid grid-cols-3 md:grid-cols-7 gap-2 mt-2">
              {trainingDayOptions.map((day) => (
                <label key={day.value} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={programForm.trainingDays.includes(day.value)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setProgramForm(prev => ({ 
                          ...prev, 
                          trainingDays: [...prev.trainingDays, day.value] 
                        }));
                      } else {
                        setProgramForm(prev => ({ 
                          ...prev, 
                          trainingDays: prev.trainingDays.filter(d => d !== day.value) 
                        }));
                      }
                    }}
                    className="rounded border-gray-300"
                  />
                  <span className="text-sm">{day.label}</span>
                </label>
              ))}
            </div>
          </div>

          {calculateDuration() && (
            <div className="bg-white p-3 rounded-lg mt-4 border">
              <p className="text-sm text-blue-700">
                <strong>Duur:</strong> {calculateDuration()}
              </p>
              <p className="text-sm text-blue-700">
                <strong>Training dagen:</strong> {programForm.trainingDays.length} geselecteerd
              </p>
            </div>
          )}

          <div className="flex justify-end gap-2 mt-4">
            <Button 
              onClick={() => {
                if (programForm.name && programForm.startDate && programForm.endDate && programForm.trainingDays.length > 0) {
                  const tempProgram = {
                    id: Date.now(),
                    name: programForm.name || "Pre Season Program",
                    startDate: programForm.startDate,
                    endDate: programForm.endDate,
                    trainingDays: programForm.trainingDays,
                    events: [],
                    created: new Date().toLocaleDateString('nl-NL')
                  };
                  exportToPDF(tempProgram);
                }
              }}
              disabled={!programForm.startDate || !programForm.endDate || programForm.trainingDays.length === 0}
              className="bg-red-600 hover:bg-red-700"
            >
              📄 Download PDF
            </Button>
            
            <Button 
              onClick={() => {
                if (programForm.name && programForm.startDate && programForm.endDate && programForm.trainingDays.length > 0) {
                  const tempProgram = {
                    id: Date.now(),
                    name: programForm.name || "Pre Season Program",
                    startDate: programForm.startDate,
                    endDate: programForm.endDate,
                    trainingDays: programForm.trainingDays,
                    events: [],
                    created: new Date().toLocaleDateString('nl-NL')
                  };
                  exportToExcel(tempProgram);
                }
              }}
              disabled={!programForm.startDate || !programForm.endDate || programForm.trainingDays.length === 0}
              className="bg-green-600 hover:bg-green-700"
            >
              📊 Download Excel
            </Button>
            
            <Button 
              onClick={() => {
                if (programForm.name && programForm.startDate && programForm.endDate && programForm.trainingDays.length > 0) {
                  const tempProgram = {
                    id: Date.now(),
                    name: programForm.name || "Pre Season Program",
                    startDate: programForm.startDate,
                    endDate: programForm.endDate,
                    trainingDays: programForm.trainingDays,
                    events: [],
                    created: new Date().toLocaleDateString('nl-NL')
                  };
                  exportToICS(tempProgram);
                }
              }}
              disabled={!programForm.startDate || !programForm.endDate || programForm.trainingDays.length === 0}
              className="bg-blue-600 hover:bg-blue-700"
            >
              📅 Download ICS
            </Button>
          </div>
        </div>

        {/* Manual Event Management */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            {/* Training Management */}
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h3 className="font-semibold text-green-800 mb-3">🏃‍♂️ Training Beheer</h3>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium">Selecteer Program</Label>
                  <select
                    value={selectedProgram || ''}
                    onChange={(e) => setSelectedProgram(e.target.value ? Number(e.target.value) : null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                  >
                    <option value="">Kies programma...</option>
                    {createdPrograms.map((program) => (
                      <option key={program.id} value={program.id}>
                        {program.name} ({program.startDate} - {program.endDate})
                      </option>
                    ))}
                  </select>
                </div>

                <Button 
                  onClick={() => {
                    if (selectedProgram) {
                      setEventForm({ 
                        type: 'training', 
                        date: '', 
                        name: '', 
                        phase: 'Foundation', 
                        opponent: '', 
                        location: '', 
                        notes: '' 
                      });
                      setEditingEvent(null);
                      setShowAddEvent(true);
                    }
                  }}
                  disabled={!selectedProgram}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Training Toevoegen
                </Button>
              </div>
            </div>

            {/* Match Management */}
            <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
              <h3 className="font-semibold text-orange-800 mb-3">⚽ Wedstrijd Beheer</h3>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium">Selecteer Program</Label>
                  <select
                    value={selectedProgram || ''}
                    onChange={(e) => setSelectedProgram(e.target.value ? Number(e.target.value) : null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                  >
                    <option value="">Kies programma...</option>
                    {createdPrograms.map((program) => (
                      <option key={program.id} value={program.id}>
                        {program.name} ({program.startDate} - {program.endDate})
                      </option>
                    ))}
                  </select>
                </div>

                <Button 
                  onClick={() => {
                    if (selectedProgram) {
                      setEventForm({ 
                        type: 'match', 
                        date: '', 
                        name: '', 
                        phase: '', 
                        opponent: '', 
                        location: '', 
                        notes: '' 
                      });
                      setEditingEvent(null);
                      setShowAddEvent(true);
                    }
                  }}
                  disabled={!selectedProgram}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Wedstrijd Toevoegen
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Manual Event Management - Always visible */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          {/* Training Management */}
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <h3 className="font-semibold text-green-800 mb-3">🏃‍♂️ Training Toevoegen</h3>
            
            <Button 
              onClick={() => {
                const tempProgram = {
                  id: Date.now(),
                  name: programForm.name || "Temp Program",
                  startDate: programForm.startDate,
                  endDate: programForm.endDate,
                  trainingDays: programForm.trainingDays,
                  events: [],
                  created: new Date().toLocaleDateString('nl-NL')
                };
                setCreatedPrograms(prev => [...prev, tempProgram]);
                setSelectedProgram(tempProgram.id);
                setEventForm({ 
                  type: 'training', 
                  date: '', 
                  name: '', 
                  phase: 'Foundation', 
                  opponent: '', 
                  location: '', 
                  notes: '' 
                });
                setEditingEvent(null);
                setShowAddEvent(true);
              }}
              disabled={!programForm.startDate || !programForm.endDate || programForm.trainingDays.length === 0}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Training Toevoegen
            </Button>
          </div>

          {/* Match Management */}
          <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
            <h3 className="font-semibold text-orange-800 mb-3">⚽ Wedstrijd Toevoegen</h3>
            
            <Button 
              onClick={() => {
                const tempProgram = {
                  id: Date.now(),
                  name: programForm.name || "Temp Program",
                  startDate: programForm.startDate,
                  endDate: programForm.endDate,
                  trainingDays: programForm.trainingDays,
                  events: [],
                  created: new Date().toLocaleDateString('nl-NL')
                };
                setCreatedPrograms(prev => [...prev, tempProgram]);
                setSelectedProgram(tempProgram.id);
                setEventForm({ 
                  type: 'match', 
                  date: '', 
                  name: '', 
                  phase: '', 
                  opponent: '', 
                  location: '', 
                  notes: '' 
                });
                setEditingEvent(null);
                setShowAddEvent(true);
              }}
              disabled={!programForm.startDate || !programForm.endDate || programForm.trainingDays.length === 0}
              className="w-full bg-orange-600 hover:bg-orange-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Wedstrijd Toevoegen
            </Button>
          </div>
        </div>
      </div>

      {/* Training Session Structure */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-green-600" />
            Training Sessie Structuur (70 minuten)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <div className="flex items-center gap-2 mb-2">
                <Play className="h-4 w-4 text-yellow-600" />
                <h4 className="font-semibold text-yellow-700">Warming Up</h4>
              </div>
              <p className="text-sm text-gray-600">10 min</p>
              <p className="text-xs mt-1">Inlopen - Hartslag Max 140</p>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-purple-600" />
                <h4 className="font-semibold text-purple-700">Blessurepreventie</h4>
              </div>
              <p className="text-sm text-gray-600">10 min</p>
              <p className="text-xs mt-1">Geperiodiseerd over 8 weken</p>
              <div className="text-xs mt-2 space-y-1">
                <div>• Enkels</div>
                <div>• ACL</div>
                <div>• Hamstrings</div>
                <div>• Adductoren</div>
                <div>• Romp</div>
              </div>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                <Target className="h-4 w-4 text-blue-600" />
                <h4 className="font-semibold text-blue-700">Conditie HIIT</h4>
              </div>
              <p className="text-sm text-gray-600">30 min</p>
              <p className="text-xs mt-1">Opbouw van heel laag niveau</p>
              <div className="text-xs mt-2 space-y-1">
                <div><strong>Foundation:</strong> 15s werk/30s rust × 8</div>
                <div className="text-gray-500">→ Start op 60% max HR</div>
                <div><strong>Building:</strong> 30s werk/60s rust × 12</div>
                <div className="text-gray-500">→ Opbouw van 60% naar 75% max HR</div>
                <div><strong>Work:</strong> 10s→30s werk/45s rust × 8</div>
                <div className="text-gray-500">→ 100% max HR, progressieve duur opbouw</div>
              </div>
              <div className="text-xs mt-2 text-blue-600">
                <div>🎯 Foundation: 60% max HR</div>
                <div>💪 Building: 60% → 75% max HR (progressief)</div>
                <div>🔥 Work: 100% max HR (10s→30s over 8 weken)</div>
              </div>
            </div>

            <div className="bg-red-50 p-4 rounded-lg border border-red-200">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-red-600" />
                <h4 className="font-semibold text-red-700">Kracht HIIT</h4>
              </div>
              <p className="text-sm text-gray-600">15 min</p>
              <p className="text-xs mt-1">6 Spiergroepen - 2.5 min per groep</p>
              <div className="text-xs mt-2 space-y-1">
                <div><strong>Foundation fase:</strong></div>
                <div>• Rompstabilisatie (basis planks)</div>
                <div>• Kracht benen (bodyweight)</div>
                <div>• Kracht hamstrings (glute bridges)</div>
                <div>• Kracht adductoren (side lunges)</div>
                <div>• Kracht romp (basic core)</div>
                <div>• Kracht armen (push-ups)</div>
                <div className="mt-2"><strong>Building fase:</strong></div>
                <div>• Dynamische bewegingen</div>
                <div>• Meer explosiviteit</div>
                <div>• Verhoogde intensiteit</div>
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-green-600" />
                <h4 className="font-semibold text-green-700">Cool-down</h4>
              </div>
              <p className="text-sm text-gray-600">5 min</p>
              <p className="text-xs mt-1">Blessurepreventieve oefeningen met exacte uitvoering</p>
              <div className="text-xs mt-2 space-y-1">
                <div><strong>1. Hamstring stretch (2x 20s per been):</strong></div>
                <div className="ml-2">Zit op grond, been gestrekt, andere been gebogen. Reik naar tenen tot lichte spanning. Niet wippen!</div>
                
                <div><strong>2. Calf stretch (2x 15s per been):</strong></div>
                <div className="ml-2">Stap voorwaarts tegen muur, achterste been gestrekt, hiel op grond drukken. Voel stretch in kuit.</div>
                
                <div><strong>3. Hip flexor stretch (2x 15s per kant):</strong></div>
                <div className="ml-2">Lunge positie, achterste knie op grond, heup naar voren duwen. Voel stretch voorkant heup.</div>
                
                <div><strong>4. IT-band stretch (2x 15s per kant):</strong></div>
                <div className="ml-2">Staand rechter been over linker, buig zijwaarts naar rechts. Voel stretch buitenkant bovenbeen.</div>
                
                <div><strong>5. Glute stretch (2x 15s per kant):</strong></div>
                <div className="ml-2">Lig op rug, trek knie naar borst, draai been naar andere kant. Voel stretch in bil.</div>
                
                <div><strong>6. Shoulder doorway stretch (1x 20s):</strong></div>
                <div className="ml-2">Onderarm tegen deurpost 90°, stap voorwaarts. Voel stretch voorkant schouder.</div>
                
                <div><strong>7. Ankle mobility (10 circles elke richting):</strong></div>
                <div className="ml-2">Zittend, til voet op, maak trage cirkels. Eerst rechtsom, dan linksom.</div>
                
                <div><strong>8. Neck rolls (5 langzame rondjes):</strong></div>
                <div className="ml-2">Voorzichtig hoofd rollen: voor → rechts → achter → links. Langzaam en gecontroleerd.</div>
                
                <div><strong>9. Ademhaling (5 cycli):</strong></div>
                <div className="ml-2">Inademen 4 sec door neus → vasthouden 4 sec → uitademen 6 sec door mond. Ontspan.</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Created Programs */}
      <Card>
        <CardHeader>
          <CardTitle>Aangemaakte Programma's</CardTitle>
          <CardDescription>
            Overzicht van je gecreëerde pre season programma's met export opties
          </CardDescription>
        </CardHeader>
        <CardContent>
          {createdPrograms.length > 0 ? (
            <div className="space-y-4">
              {createdPrograms.map((program) => (
                <div key={program.id} className="bg-gray-50 p-4 rounded-lg border">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h4 className="font-semibold text-lg">{program.name}</h4>
                      <p className="text-sm text-gray-600 mt-1">
                        📅 {program.startDate} t/m {program.endDate}
                      </p>
                      <p className="text-sm text-gray-600">
                        🗓️ Training dagen: {program.trainingDays.map(day => 
                          trainingDayOptions.find(opt => opt.value === day)?.label
                        ).join(", ")}
                      </p>
                      <p className="text-sm text-gray-600">
                        📊 Events: {program.events.length} (trainingen + wedstrijden)
                      </p>
                      <p className="text-xs text-gray-500 mt-2">Aangemaakt: {program.created}</p>
                    </div>
                    <div className="flex flex-col gap-2 ml-4">
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setSelectedProgram(program.id);
                            setShowAddEvent(true);
                          }}
                        >
                          <Plus className="h-4 w-4 mr-1" />
                          Event
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => setSelectedProgram(selectedProgram === program.id ? null : program.id)}
                        >
                          <FileText className="h-4 w-4 mr-1" />
                          {selectedProgram === program.id ? "Verberg" : "Bekijk"}
                        </Button>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => exportToPDF(program)}>
                          📄 PDF
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => exportToExcel(program)}>
                          📊 Excel
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => exportToICS(program)}>
                          📅 ICS
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Program Events List */}
                  {selectedProgram === program.id && (
                    <div className="mt-4 border-t pt-4">
                      <h5 className="font-semibold mb-3">Events in {program.name}</h5>
                      {program.events.length > 0 ? (
                        <div className="space-y-2">
                          {program.events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map((event) => (
                            <div key={event.id} className="bg-white p-3 rounded border flex justify-between items-center">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                                    event.type === 'training' 
                                      ? 'bg-blue-100 text-blue-700' 
                                      : 'bg-green-100 text-green-700'
                                  }`}>
                                    {event.type === 'training' ? '🏃‍♂️ Training' : '⚽ Wedstrijd'}
                                  </span>
                                  <span className="font-medium">{event.name}</span>
                                  {event.phase && (
                                    <span className="text-xs text-gray-500">({event.phase})</span>
                                  )}
                                </div>
                                <p className="text-sm text-gray-600 mt-1">
                                  📅 {event.date}
                                  {event.opponent && ` | vs ${event.opponent}`}
                                  {event.location && ` | @ ${event.location}`}
                                </p>
                                {event.notes && (
                                  <p className="text-sm text-blue-600 mt-1">📝 {event.notes}</p>
                                )}
                              </div>
                              <div className="flex gap-2">
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => handleEditEvent(event)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => handleDeleteEvent(event.id)}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-4">
                          <p className="text-gray-500 mb-2">Nog geen events toegevoegd</p>
                          <Button 
                            size="sm"
                            onClick={() => {
                              setSelectedProgram(program.id);
                              setShowAddEvent(true);
                            }}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Eerste Event Toevoegen
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500 mb-4">
                Nog geen programma's aangemaakt
              </p>
              <Button onClick={() => setShowCreateProgram(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Eerste Program Maken
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Program Dialog */}
      <Dialog open={showCreateProgram} onOpenChange={setShowCreateProgram}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create Pre Season Program</DialogTitle>
            <DialogDescription>
              Professioneel voorbereiding programma met startdatum en einddatum
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="programName">Program Naam</Label>
              <input
                id="programName"
                type="text"
                placeholder="bijv. Pre Season 2025"
                value={programForm.name}
                onChange={(e) => setProgramForm(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate">Startdatum</Label>
                <input
                  id="startDate"
                  type="date"
                  value={programForm.startDate}
                  onChange={(e) => setProgramForm(prev => ({ ...prev, startDate: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <Label htmlFor="endDate">Einddatum</Label>
                <input
                  id="endDate"
                  type="date"
                  value={programForm.endDate}
                  onChange={(e) => setProgramForm(prev => ({ ...prev, endDate: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <Label>Training Dagen (selecteer minimaal 3)</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {trainingDayOptions.map((day) => (
                  <label key={day.value} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={programForm.trainingDays.includes(day.value)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setProgramForm(prev => ({ 
                            ...prev, 
                            trainingDays: [...prev.trainingDays, day.value] 
                          }));
                        } else {
                          setProgramForm(prev => ({ 
                            ...prev, 
                            trainingDays: prev.trainingDays.filter(d => d !== day.value) 
                          }));
                        }
                      }}
                      className="rounded border-gray-300"
                    />
                    <span className="text-sm">{day.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {calculateDuration() && (
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-sm text-blue-700">
                  <strong>Duur:</strong> {calculateDuration()}
                </p>
                <p className="text-sm text-blue-700">
                  <strong>Training dagen:</strong> {programForm.trainingDays.length} geselecteerd
                </p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateProgram(false)}>
              Annuleren
            </Button>
            <Button 
              onClick={handleCreateProgram} 
              disabled={!programForm.startDate || !programForm.endDate || programForm.trainingDays.length === 0}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Program Maken
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Event Dialog */}
      <Dialog open={showAddEvent} onOpenChange={setShowAddEvent}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingEvent ? "Event Bewerken" : "Nieuw Event Toevoegen"}
            </DialogTitle>
            <DialogDescription>
              Voeg een training of wedstrijd toe aan het programma
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="eventType">Event Type</Label>
                <Select 
                  value={eventForm.type} 
                  onValueChange={(value) => setEventForm(prev => ({ ...prev, type: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="training">🏃‍♂️ Training</SelectItem>
                    <SelectItem value="match">⚽ Wedstrijd</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="eventDate">Datum</Label>
                <input
                  id="eventDate"
                  type="date"
                  value={eventForm.date}
                  onChange={(e) => setEventForm(prev => ({ ...prev, date: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="eventName">Event Naam</Label>
              <input
                id="eventName"
                type="text"
                placeholder={eventForm.type === "training" ? "bijv. Foundation Week 1" : "bijv. Oefenwedstrijd"}
                value={eventForm.name}
                onChange={(e) => setEventForm(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {eventForm.type === "training" && (
              <div>
                <Label htmlFor="eventPhase">Training Fase</Label>
                <Select 
                  value={eventForm.phase} 
                  onValueChange={(value) => setEventForm(prev => ({ ...prev, phase: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer fase" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="foundation">Foundation</SelectItem>
                    <SelectItem value="building">Building</SelectItem>
                    <SelectItem value="peak">Peak</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {eventForm.type === "match" && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="opponent">Tegenstander</Label>
                  <input
                    id="opponent"
                    type="text"
                    placeholder="bijv. FCVoorbeeld"
                    value={eventForm.opponent}
                    onChange={(e) => setEventForm(prev => ({ ...prev, opponent: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <Label htmlFor="location">Locatie</Label>
                  <input
                    id="location"
                    type="text"
                    placeholder="bijv. Thuis / Sportpark Noord"
                    value={eventForm.location}
                    onChange={(e) => setEventForm(prev => ({ ...prev, location: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="eventNotes">Notities (optioneel)</Label>
              <textarea
                id="eventNotes"
                placeholder="Extra notities over dit event..."
                value={eventForm.notes}
                onChange={(e) => setEventForm(prev => ({ ...prev, notes: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>

            {/* Event Preview */}
            {eventForm.type === "training" && eventForm.phase && (
              <Card className="bg-blue-50">
                <CardHeader>
                  <CardTitle className="text-lg">Training Preview - {eventForm.phase} fase</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-4 gap-3 text-sm">
                    <div className="bg-yellow-100 p-2 rounded">
                      <div className="font-semibold">Opwarming</div>
                      <div>10 min - Inlopen Max 140 HR</div>
                    </div>
                    <div className="bg-blue-100 p-2 rounded">
                      <div className="font-semibold">Conditie HIIT</div>
                      <div>30 min - {hiitConditieOpbouw[eventForm.phase as keyof typeof hiitConditieOpbouw]?.work}s/{hiitConditieOpbouw[eventForm.phase as keyof typeof hiitConditieOpbouw]?.rest}s × {hiitConditieOpbouw[eventForm.phase as keyof typeof hiitConditieOpbouw]?.series}</div>
                    </div>
                    <div className="bg-red-100 p-2 rounded">
                      <div className="font-semibold">Kracht HIIT</div>
                      <div>15 min - 6 spiergroepen</div>
                    </div>
                    <div className="bg-green-100 p-2 rounded">
                      <div className="font-semibold">Cool-down</div>
                      <div>5 min - Recovery</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowAddEvent(false);
              setEditingEvent(null);
              setEventForm({ type: "training", date: "", name: "", phase: "foundation", opponent: "", location: "", notes: "" });
            }}>
              Annuleren
            </Button>
            <Button 
              onClick={handleSaveEvent} 
              disabled={!eventForm.date}
              className="bg-green-600 hover:bg-green-700"
            >
              {editingEvent ? "Event Bijwerken" : "Event Toevoegen"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TrainingProgramsPage;