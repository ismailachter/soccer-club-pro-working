import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { 
  Plus, 
  Clock, 
  Users, 
  Target, 
  Edit, 
  Trash2, 
  Save, 
  Play, 
  CalendarCheck,
  FileText,
  MapPin,
  Timer,
  Zap,
  Trophy,
  Settings
} from "lucide-react";
import { MaterialSelector, FootballField } from "@/components/training/modern-training-materials";
import { TrainingFieldDesigner } from "@/components/training/training-field-designer";
import { TeamManagement } from "@/components/training/team-management";
import { TrainingTimeline } from "@/components/training/training-timeline";
import { ProfessionalTacticalPad } from "@/components/training/professional-tactical-pad";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

// Schema definitions
const sessionSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  description: z.string().optional(),
  date: z.string(),
  startTime: z.string(),
  duration: z.number().min(30).max(180),
  teamId: z.number().optional(),
  location: z.string().optional(),
  objectives: z.string().optional(),
  notes: z.string().optional(),
  intensity: z.enum(["low", "medium", "high"]),
  difficulty: z.enum(["beginner", "intermediate", "advanced"]),
  equipment: z.string().optional(),
  weatherConditions: z.string().optional()
});

const exerciseBlockSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  description: z.string().optional(),
  duration: z.number().min(1).max(60),
  intensity: z.enum(["low", "medium", "high"]),
  equipment: z.string().optional(),
  objectives: z.string().optional(),
  instructions: z.string().optional(),
  iadatabankElements: z.array(z.string()).default([]),
  players: z.number().min(1).max(30).default(10),
  space: z.string().optional()
});

type SessionFormData = z.infer<typeof sessionSchema>;
type ExerciseBlockFormData = z.infer<typeof exerciseBlockSchema>;

interface TrainingSession {
  id: number;
  name: string;
  description?: string;
  date: string;
  startTime: string;
  duration: number;
  teamId?: number;
  location?: string;
  objectives?: string;
  notes?: string;
  intensity: string;
  difficulty: string;
  equipment?: string;
  weatherConditions?: string;
  exerciseBlocks: ExerciseBlock[];
  team?: { id: number; name: string; };
}

interface ExerciseBlock {
  id: number;
  sessionId: number;
  name: string;
  description?: string;
  duration: number;
  intensity: string;
  equipment?: string;
  objectives?: string;
  instructions?: string;
  iadatabankElements: string[];
  players: number;
  space?: string;
  sortOrder: number;
}

export default function ModernTrainingSessionMaker() {
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);
  const [isCreateSessionOpen, setIsCreateSessionOpen] = useState(false);
  const [isEditSessionOpen, setIsEditSessionOpen] = useState(false);
  const [isExerciseBlockOpen, setIsExerciseBlockOpen] = useState(false);
  const [selectedExerciseBlock, setSelectedExerciseBlock] = useState<ExerciseBlock | null>(null);
  const [previewMode, setPreviewMode] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch training sessions
  const { data: sessions = [], isLoading } = useQuery<TrainingSession[]>({
    queryKey: ['/api/training-sessions'],
  });

  // Fetch teams
  const { data: teams = [] } = useQuery<any[]>({
    queryKey: ['/api/teams'],
  });

  // Session form
  const sessionForm = useForm<SessionFormData>({
    resolver: zodResolver(sessionSchema),
    defaultValues: {
      name: '',
      description: '',
      date: format(new Date(), 'yyyy-MM-dd'),
      startTime: '19:00',
      duration: 90,
      intensity: 'medium',
      difficulty: 'intermediate',
      equipment: 'Voetballen, pionnen, hesjes',
      location: 'Hoofdveld'
    }
  });

  // Exercise block form
  const exerciseForm = useForm<ExerciseBlockFormData>({
    resolver: zodResolver(exerciseBlockSchema),
    defaultValues: {
      name: '',
      description: '',
      duration: 15,
      intensity: 'medium',
      equipment: '',
      objectives: '',
      instructions: '',
      iadatabankElements: [],
      players: 10,
      space: '20x30m'
    }
  });

  // Create session mutation
  const createSession = useMutation({
    mutationFn: (data: SessionFormData) => apiRequest('POST', '/api/training-sessions', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/training-sessions'] });
      toast({ title: "Trainingsessie aangemaakt", description: "De sessie is succesvol aangemaakt." });
      setIsCreateSessionOpen(false);
      sessionForm.reset();
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het aanmaken.", variant: "destructive" });
    }
  });

  const handleCreateSession = (data: SessionFormData) => {
    // Fix date format issue by ensuring proper ISO string format
    const sessionData = {
      ...data,
      date: new Date(data.date).toISOString().split('T')[0], // Convert to YYYY-MM-DD format
      teamId: data.teamId || undefined // Ensure teamId is undefined if not set
    };
    createSession.mutate(sessionData);
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tactical Pad Pro</h1>
          <p className="text-muted-foreground">
            Professional tactical analysis and training session designer
          </p>
        </div>
        
        <div className="flex gap-2">
          <Dialog open={isCreateSessionOpen} onOpenChange={setIsCreateSessionOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                New Tactical Session
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-6xl w-[95vw] max-h-[95vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Tactical Session</DialogTitle>
              </DialogHeader>
              
              <Form {...sessionForm}>
                <form onSubmit={sessionForm.handleSubmit(handleCreateSession)} className="space-y-6">
                  {/* Tactical Design Tabs */}
                  <div className="bg-gradient-to-r from-blue-50 to-slate-100 p-6 rounded-lg border-2 border-blue-200">
                    <div className="text-center mb-6">
                      <h3 className="text-lg font-semibold text-blue-800">Tactical Analysis Studio</h3>
                      <p className="text-sm text-blue-600">Professional tactical board, formations, and session planning</p>
                    </div>
                    
                    <Tabs defaultValue="tactical" className="w-full">
                      <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="tactical">Tactical Board</TabsTrigger>
                        <TabsTrigger value="materials">Training Setup</TabsTrigger>
                        <TabsTrigger value="teams">Formation Analysis</TabsTrigger>
                        <TabsTrigger value="timeline">Session Timeline</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="tactical" className="mt-4">
                        <div className="max-h-[600px] overflow-hidden">
                          <ProfessionalTacticalPad />
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="materials" className="mt-4">
                        <div className="max-h-[500px] overflow-hidden">
                          <TrainingFieldDesigner 
                            onSave={(design) => {
                              const materialNames = design.items.map(item => item.name).join(', ');
                              const lineInfo = design.lines.length > 0 ? ` (${design.lines.length} lines drawn)` : '';
                              sessionForm.setValue('equipment', materialNames + lineInfo);
                            }}
                          />
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="teams" className="mt-4">
                        <div className="max-h-[500px] overflow-hidden">
                          <TeamManagement 
                            onTeamUpdate={(teams) => {
                              const teamInfo = `Formation: ${teams.teamA.name} vs ${teams.teamB.name}`;
                              sessionForm.setValue('notes', `${sessionForm.getValues('notes') || ''}\n\n${teamInfo}`.trim());
                            }}
                          />
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="timeline" className="mt-4">
                        <div className="max-h-[500px] overflow-y-auto">
                          <TrainingTimeline 
                            onSave={(phases) => {
                              const totalDuration = phases.reduce((total, phase) => total + phase.duration, 0);
                              const phaseInfo = `Session Plan: ${phases.length} phases, ${totalDuration} minutes total`;
                              sessionForm.setValue('notes', `${sessionForm.getValues('notes') || ''}\n\n${phaseInfo}`.trim());
                            }}
                          />
                        </div>
                      </TabsContent>
                    </Tabs>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={sessionForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sessienaam</FormLabel>
                          <FormControl>
                            <Input placeholder="bijv. Techniektraining U12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={sessionForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Locatie</FormLabel>
                          <FormControl>
                            <Input placeholder="bijv. Hoofdveld, Kunstgrasveld A" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={sessionForm.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Datum</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={sessionForm.control}
                      name="startTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Starttijd</FormLabel>
                          <FormControl>
                            <Input type="time" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={sessionForm.control}
                      name="duration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Duur (minuten)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="30" 
                              max="180"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={sessionForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Beschrijving</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Korte beschrijving van de training..."
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={sessionForm.control}
                      name="intensity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Intensiteit</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="low">Laag</SelectItem>
                              <SelectItem value="medium">Gemiddeld</SelectItem>
                              <SelectItem value="high">Hoog</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={sessionForm.control}
                      name="difficulty"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Moeilijkheidsgraad</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="beginner">Beginner</SelectItem>
                              <SelectItem value="intermediate">Gemiddeld</SelectItem>
                              <SelectItem value="advanced">Gevorderd</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={sessionForm.control}
                    name="objectives"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Doelstellingen</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Wat wil je bereiken met deze training?"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={sessionForm.control}
                    name="equipment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Materiaal & Voetbalveld</FormLabel>
                        <MaterialSelector 
                          value={field.value}
                          onChange={field.onChange}
                        />
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end gap-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsCreateSessionOpen(false)}
                    >
                      Annuleren
                    </Button>
                    <Button type="submit" disabled={createSession.isPending}>
                      {createSession.isPending ? "Aanmaken..." : "Sessie Aanmaken"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Sessions Overview */}
      <div className="grid gap-6">
        {isLoading ? (
          <div className="text-center py-8">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <p className="mt-2 text-muted-foreground">Trainingsessies laden...</p>
          </div>
        ) : sessions.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Geen trainingsessies gevonden</h3>
              <p className="text-muted-foreground mb-4">
                Maak je eerste trainingsessie aan met moderne materialen en voetbalveld visualisatie.
              </p>
              <Button onClick={() => setIsCreateSessionOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Eerste Sessie Aanmaken
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {sessions.map((session) => (
              <Card key={session.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{session.name}</CardTitle>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                        <CalendarCheck className="h-4 w-4" />
                        {format(new Date(session.date), 'dd MMM yyyy', { locale: nl })}
                        <Clock className="h-4 w-4 ml-2" />
                        {session.startTime}
                      </div>
                    </div>
                    <Badge variant={session.intensity === 'high' ? 'destructive' : session.intensity === 'medium' ? 'default' : 'secondary'}>
                      {session.intensity === 'high' ? 'Hoog' : session.intensity === 'medium' ? 'Gemiddeld' : 'Laag'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{session.location || 'Geen locatie'}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Timer className="h-4 w-4 text-muted-foreground" />
                      <span>{session.duration} minuten</span>
                    </div>
                    {session.equipment && (
                      <div className="flex items-center gap-2 text-sm">
                        <Settings className="h-4 w-4 text-muted-foreground" />
                        <span className="truncate">{session.equipment}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="mt-4 pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">
                        {session.exerciseBlocks?.length || 0} oefeningen
                      </span>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" onClick={() => setSelectedSession(session)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Play className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Football Field Showcase & Demo */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5" />
              Voetbalveld Visualisatie
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <FootballField selectedMaterials={['Voetballen', 'Pionnen', 'Hesjes']} />
              <p className="mt-4 text-muted-foreground">
                Interactieve voetbalveld met materiaal visualisatie
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Demo Trainingsdata</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <h4 className="font-medium mb-2">Moderne Materialen Test</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Demonstratie van de materiaal selector met voetbalveld ondersteuning
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                    <span>Voetballen geselecteerd</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <span>Pionnen toegevoegd</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span>Hesjes beschikbaar</span>
                  </div>
                </div>
              </div>
              
              <Button 
                onClick={() => setIsCreateSessionOpen(true)}
                className="w-full"
              >
                Test Moderne Sessie Maker
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}