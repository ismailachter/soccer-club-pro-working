import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  Search, 
  Plus, 
  Clock, 
  Users, 
  Target, 
  Brain, 
  Zap, 
  Play,
  Save,
  Download,
  Eye,
  Settings,
  Calendar,
  MapPin,
  Thermometer
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TrainingExercise {
  id: string;
  name: string;
  category: 'BASICS' | 'TEAMTACTISCH' | 'FYSIEK' | 'MENTAAL' | 'VARIA';
  subcategory?: string;
  theme: string;
  duration: number;
  intensity: 'low' | 'medium' | 'high';
  players: number;
  equipment: string[];
  description: string;
  objectives: string[];
  progression: string;
  coaching_points: string[];
}

interface ProfessionalTraining {
  id?: number;
  name: string;
  description: string;
  duration: number;
  intensity: 'low' | 'medium' | 'high';
  ageGroup: string;
  playerCount: number;
  focusAreas: string[];
  exercises: TrainingExercise[];
  warmUp: TrainingExercise[];
  mainPart: TrainingExercise[];
  coolDown: TrainingExercise[];
  equipment: string[];
  location: 'indoor' | 'outdoor';
  weather: string;
  notes: string;
  created: string;
  createdBy: string;
}

const intensityColors = {
  low: "bg-green-100 text-green-800",
  medium: "bg-yellow-100 text-yellow-800", 
  high: "bg-red-100 text-red-800"
};

const categoryColors = {
  BASICS: "bg-blue-500",
  TEAMTACTISCH: "bg-green-500", 
  FYSIEK: "bg-red-500",
  MENTAAL: "bg-purple-500",
  VARIA: "bg-amber-500"
};

export default function ProfessionalTraining() {
  const [selectedTraining, setSelectedTraining] = useState<ProfessionalTraining | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterIntensity, setFilterIntensity] = useState("all");
  const [activeTab, setActiveTab] = useState("overview");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch professional trainings
  const { data: trainings = [], isLoading } = useQuery({
    queryKey: ['/api/professional-trainings'],
    queryFn: () => apiRequest('/api/professional-trainings')
  });

  // Fetch IADATABANK elements for exercise library
  const { data: iadatabank = [] } = useQuery({
    queryKey: ['/api/iadatabank/elements'],
    queryFn: () => apiRequest('/api/iadatabank/elements')
  });

  // Create training mutation
  const createTraining = useMutation({
    mutationFn: (trainingData: Partial<ProfessionalTraining>) => 
      apiRequest('/api/professional-trainings', {
        method: 'POST',
        body: JSON.stringify(trainingData)
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/professional-trainings'] });
      toast({ title: "Training aangemaakt", description: "Professionele training succesvol opgeslagen" });
      setShowCreateDialog(false);
    }
  });

  const filteredTrainings = trainings.filter((training: ProfessionalTraining) => {
    const matchesSearch = training.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         training.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "all" || training.focusAreas.includes(filterCategory);
    const matchesIntensity = filterIntensity === "all" || training.intensity === filterIntensity;
    
    return matchesSearch && matchesCategory && matchesIntensity;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-8 text-white">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  ⚽
                </div>
                Professionele Trainingen
              </h1>
              <p className="text-blue-100 text-lg">
                Ontwerp complete professionele voetbaltrainingen met IADATABANK integratie
              </p>
            </div>
            <div className="text-right space-y-2">
              <div className="text-3xl font-bold">{trainings.length}</div>
              <div className="text-blue-200 text-sm">Trainingen Beschikbaar</div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4 items-center justify-between">
              <div className="flex gap-4 items-center flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Zoek trainingen..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Categorie" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle Categorieën</SelectItem>
                    <SelectItem value="BASICS">Basics</SelectItem>
                    <SelectItem value="TEAMTACTISCH">Team Tactiek</SelectItem>
                    <SelectItem value="FYSIEK">Fysiek</SelectItem>
                    <SelectItem value="MENTAAL">Mentaal</SelectItem>
                    <SelectItem value="VARIA">Varia</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filterIntensity} onValueChange={setFilterIntensity}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Intensiteit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle</SelectItem>
                    <SelectItem value="low">Laag</SelectItem>
                    <SelectItem value="medium">Gemiddeld</SelectItem>
                    <SelectItem value="high">Hoog</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Nieuwe Training
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Nieuwe Professionele Training</DialogTitle>
                  </DialogHeader>
                  <ProfessionalTrainingCreator 
                    iadatabank={iadatabank} 
                    onSave={(data) => createTraining.mutate(data)}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Training Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTrainings.map((training: ProfessionalTraining) => (
            <TrainingCard
              key={training.id}
              training={training}
              onClick={() => setSelectedTraining(training)}
            />
          ))}
        </div>

        {/* Training Detail Modal */}
        {selectedTraining && (
          <Dialog open={!!selectedTraining} onOpenChange={() => setSelectedTraining(null)}>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${categoryColors[selectedTraining.focusAreas[0] as keyof typeof categoryColors] || 'bg-gray-400'}`} />
                  {selectedTraining.name}
                </DialogTitle>
              </DialogHeader>
              <TrainingDetailView training={selectedTraining} />
            </DialogContent>
          )}
        {/* Empty State */}
        {filteredTrainings.length === 0 && !isLoading && (
          <Card className="text-center p-12">
            <div className="text-gray-400 mb-4">
              <Target className="h-16 w-16 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">
                Geen trainingen gevonden
              </h3>
              <p className="text-gray-500">
                Begin met het maken van je eerste professionele training
              </p>
            </div>
            <Button onClick={() => setShowCreateDialog(true)} className="mt-4">
              <Plus className="h-4 w-4 mr-2" />
              Maak Eerste Training
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}

// Training Card Component
function TrainingCard({ training, onClick }: { training: ProfessionalTraining, onClick: () => void }) {
  return (
    <Card className="hover:shadow-lg transition-all duration-200 cursor-pointer" onClick={onClick}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg font-semibold line-clamp-2">
            {training.name}
          </CardTitle>
          <Badge className={`${intensityColors[training.intensity]} border-0`}>
            {training.intensity === 'low' ? 'Laag' : training.intensity === 'medium' ? 'Gemiddeld' : 'Hoog'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-gray-600 text-sm line-clamp-2">
          {training.description}
        </p>
        
        <div className="flex flex-wrap gap-2">
          {training.focusAreas.slice(0, 3).map((area, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {area}
            </Badge>
          ))}
          {training.focusAreas.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{training.focusAreas.length - 3}
            </Badge>
          )}
        </div>

        <div className="flex justify-between items-center text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {training.duration} min
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            {training.playerCount} spelers
          </div>
          <div className="flex items-center gap-1">
            <Target className="h-4 w-4" />
            {training.exercises?.length || 0} oefeningen
          </div>
        </div>
        
        <div className="flex justify-between items-center pt-2 border-t">
          <span className="text-xs text-gray-400">
            {training.ageGroup}
          </span>
          <Button size="sm" variant="outline">
            <Eye className="h-4 w-4 mr-1" />
            Bekijk Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Training Creator Component
function ProfessionalTrainingCreator({ iadatabank, onSave }: { iadatabank: any[], onSave: (data: any) => void }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    duration: 90,
    intensity: 'medium' as const,
    ageGroup: '',
    playerCount: 20,
    focusAreas: [] as string[],
    location: 'outdoor' as const,
    weather: '',
    notes: ''
  });

  const [selectedExercises, setSelectedExercises] = useState<any[]>([]);
  const [exerciseSearchTerm, setExerciseSearchTerm] = useState('');

  const filteredExercises = iadatabank.filter((exercise: any) =>
    exercise.name.toLowerCase().includes(exerciseSearchTerm.toLowerCase()) ||
    exercise.theme.toLowerCase().includes(exerciseSearchTerm.toLowerCase())
  );

  const handleSave = () => {
    const trainingData = {
      ...formData,
      exercises: selectedExercises,
      equipment: selectedExercises.flatMap((ex: any) => ex.equipment || []),
      created: new Date().toISOString(),
      createdBy: 'Current User'
    };
    onSave(trainingData);
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="basic" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="basic">Basis Informatie</TabsTrigger>
          <TabsTrigger value="exercises">Oefeningen</TabsTrigger>
          <TabsTrigger value="review">Overzicht</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Training Naam</label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Bijv. Passing & Positiespel"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Leeftijdsgroep</label>
              <Select value={formData.ageGroup} onValueChange={(value) => setFormData({...formData, ageGroup: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecteer leeftijdsgroep" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="U8">U8</SelectItem>
                  <SelectItem value="U10">U10</SelectItem>
                  <SelectItem value="U12">U12</SelectItem>
                  <SelectItem value="U14">U14</SelectItem>
                  <SelectItem value="U16">U16</SelectItem>
                  <SelectItem value="U18">U18</SelectItem>
                  <SelectItem value="U20">U20</SelectItem>
                  <SelectItem value="Beloften">Beloften</SelectItem>
                  <SelectItem value="1e elftal">1e elftal</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Beschrijving</label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Beschrijf de training doelstellingen en focus..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Duur (minuten)</label>
              <Input
                type="number"
                value={formData.duration}
                onChange={(e) => setFormData({...formData, duration: parseInt(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Aantal Spelers</label>
              <Input
                type="number"
                value={formData.playerCount}
                onChange={(e) => setFormData({...formData, playerCount: parseInt(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Intensiteit</label>
              <Select value={formData.intensity} onValueChange={(value: any) => setFormData({...formData, intensity: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Laag</SelectItem>
                  <SelectItem value="medium">Gemiddeld</SelectItem>
                  <SelectItem value="high">Hoog</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="exercises" className="space-y-4">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Selecteer Oefeningen</h3>
              <div className="text-sm text-gray-500">
                {selectedExercises.length} oefeningen geselecteerd
              </div>
            </div>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Zoek oefeningen in IADATABANK..."
                value={exerciseSearchTerm}
                onChange={(e) => setExerciseSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 max-h-96 overflow-y-auto">
              {filteredExercises.slice(0, 20).map((exercise: any) => (
                <Card 
                  key={exercise.id} 
                  className={`cursor-pointer transition-all ${selectedExercises.find(ex => ex.id === exercise.id) ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:shadow-md'}`}
                  onClick={() => {
                    const isSelected = selectedExercises.find(ex => ex.id === exercise.id);
                    if (isSelected) {
                      setSelectedExercises(selectedExercises.filter(ex => ex.id !== exercise.id));
                    } else {
                      setSelectedExercises([...selectedExercises, exercise]);
                    }
                  }}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h4 className="font-semibold">{exercise.name}</h4>
                        <p className="text-sm text-gray-600">{exercise.theme}</p>
                        <div className="flex gap-2 mt-2">
                          <Badge className={`${categoryColors[exercise.topic]} text-white border-0`}>
                            {exercise.topic}
                          </Badge>
                          {exercise.subtopic && (
                            <Badge variant="outline" className="text-xs">
                              {exercise.subtopic}
                            </Badge>
                          )}
                        </div>
                      </div>
                      {selectedExercises.find(ex => ex.id === exercise.id) && (
                        <div className="text-blue-600">
                          <Plus className="h-5 w-5" />
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="review" className="space-y-4">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Training Overzicht</h3>
            
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <strong>Naam:</strong> {formData.name || 'Niet ingevuld'}
                  </div>
                  <div>
                    <strong>Leeftijdsgroep:</strong> {formData.ageGroup || 'Niet geselecteerd'}
                  </div>
                  <div>
                    <strong>Duur:</strong> {formData.duration} minuten
                  </div>
                  <div>
                    <strong>Spelers:</strong> {formData.playerCount}
                  </div>
                  <div>
                    <strong>Intensiteit:</strong> {formData.intensity === 'low' ? 'Laag' : formData.intensity === 'medium' ? 'Gemiddeld' : 'Hoog'}
                  </div>
                  <div>
                    <strong>Oefeningen:</strong> {selectedExercises.length}
                  </div>
                </div>
                
                {formData.description && (
                  <div>
                    <strong>Beschrijving:</strong>
                    <p className="text-gray-600 mt-1">{formData.description}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {selectedExercises.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Geselecteerde Oefeningen</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {selectedExercises.map((exercise, index) => (
                    <div key={exercise.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="text-sm font-medium text-gray-500">
                        {index + 1}.
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">{exercise.name}</div>
                        <div className="text-sm text-gray-600">{exercise.theme}</div>
                      </div>
                      <Badge className={`${categoryColors[exercise.topic]} text-white border-0`}>
                        {exercise.topic}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button variant="outline">
          Annuleren
        </Button>
        <Button onClick={handleSave} disabled={!formData.name || !formData.ageGroup}>
          <Save className="h-4 w-4 mr-2" />
          Training Opslaan
        </Button>
      </div>
    </div>
  );
}

// Training Detail View Component
function TrainingDetailView({ training }: { training: ProfessionalTraining }) {
  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overzicht</TabsTrigger>
          <TabsTrigger value="exercises">Oefeningen</TabsTrigger>
          <TabsTrigger value="timeline">Tijdslijn</TabsTrigger>
          <TabsTrigger value="export">Export</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Training Informatie</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Duur:</span>
                  <span className="font-medium">{training.duration} minuten</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Intensiteit:</span>
                  <Badge className={`${intensityColors[training.intensity]} border-0`}>
                    {training.intensity === 'low' ? 'Laag' : training.intensity === 'medium' ? 'Gemiddeld' : 'Hoog'}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Spelers:</span>
                  <span className="font-medium">{training.playerCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Leeftijdsgroep:</span>
                  <span className="font-medium">{training.ageGroup}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Locatie:</span>
                  <span className="font-medium">{training.location === 'outdoor' ? 'Buiten' : 'Binnen'}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Focus Gebieden</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {training.focusAreas.map((area, index) => (
                    <Badge key={index} className={`${categoryColors[area as keyof typeof categoryColors] || 'bg-gray-500'} text-white border-0`}>
                      {area}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {training.description && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Beschrijving</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{training.description}</p>
              </CardContent>
            </Card>
          )}

          {training.equipment && training.equipment.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Benodigde Materialen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {training.equipment.map((item, index) => (
                    <Badge key={index} variant="outline">
                      {item}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="exercises" className="space-y-4">
          <div className="space-y-4">
            {training.exercises && training.exercises.length > 0 ? (
              training.exercises.map((exercise, index) => (
                <Card key={exercise.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                          {index + 1}
                        </div>
                        {exercise.name}
                      </CardTitle>
                      <div className="flex gap-2">
                        <Badge className={`${categoryColors[exercise.category]} text-white border-0`}>
                          {exercise.category}
                        </Badge>
                        {exercise.intensity && (
                          <Badge className={`${intensityColors[exercise.intensity]} border-0`}>
                            {exercise.intensity === 'low' ? 'Laag' : exercise.intensity === 'medium' ? 'Gemiddeld' : 'Hoog'}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Duur:</span>
                        <span className="ml-2 font-medium">{exercise.duration} min</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Spelers:</span>
                        <span className="ml-2 font-medium">{exercise.players}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Thema:</span>
                        <span className="ml-2 font-medium">{exercise.theme}</span>
                      </div>
                    </div>
                    
                    {exercise.description && (
                      <div>
                        <strong className="text-sm">Beschrijving:</strong>
                        <p className="text-gray-700 mt-1">{exercise.description}</p>
                      </div>
                    )}
                    
                    {exercise.objectives && exercise.objectives.length > 0 && (
                      <div>
                        <strong className="text-sm">Doelstellingen:</strong>
                        <ul className="list-disc list-inside mt-1 text-gray-700">
                          {exercise.objectives.map((objective, idx) => (
                            <li key={idx}>{objective}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    {exercise.equipment && exercise.equipment.length > 0 && (
                      <div>
                        <strong className="text-sm">Materialen:</strong>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {exercise.equipment.map((item, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {item}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="text-center p-8">
                <div className="text-gray-400">
                  <Target className="h-12 w-12 mx-auto mb-4" />
                  <p>Geen oefeningen toegevoegd aan deze training</p>
                </div>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="timeline" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Training Tijdslijn</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-green-50 rounded-lg">
                  <div className="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center font-bold">
                    1
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold">Warming-up</div>
                    <div className="text-sm text-gray-600">15 minuten - Voorbereiding en activatie</div>
                  </div>
                  <Badge variant="outline">15 min</Badge>
                </div>
                
                <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg">
                  <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                    2
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold">Hoofddeel</div>
                    <div className="text-sm text-gray-600">
                      {training.duration - 25} minuten - {training.exercises?.length || 0} oefeningen
                    </div>
                  </div>
                  <Badge variant="outline">{training.duration - 25} min</Badge>
                </div>
                
                <div className="flex items-center gap-4 p-4 bg-purple-50 rounded-lg">
                  <div className="w-12 h-12 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold">
                    3
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold">Cool-down</div>
                    <div className="text-sm text-gray-600">10 minuten - Uitlopen en stretching</div>
                  </div>
                  <Badge variant="outline">10 min</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="export" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Export Opties</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center gap-2">
                  <Download className="h-6 w-6" />
                  <div>
                    <div className="font-semibold">PDF Training</div>
                    <div className="text-xs text-gray-500">Printbare versie</div>
                  </div>
                </Button>
                
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center gap-2">
                  <Calendar className="h-6 w-6" />
                  <div>
                    <div className="font-semibold">Kalender Import</div>
                    <div className="text-xs text-gray-500">ICS bestand</div>
                  </div>
                </Button>
                
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center gap-2">
                  <Settings className="h-6 w-6" />
                  <div>
                    <div className="font-semibold">Excel Export</div>
                    <div className="text-xs text-gray-500">Spreadsheet</div>
                  </div>
                </Button>
                
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center gap-2">
                  <Play className="h-6 w-6" />
                  <div>
                    <div className="font-semibold">PowerPoint</div>
                    <div className="text-xs text-gray-500">Presentatie</div>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}