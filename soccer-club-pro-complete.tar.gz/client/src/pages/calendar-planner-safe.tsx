import { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, Target, Users, MapPin, Star, Plus, Edit, Trash2, Eye, Filter, Search, ChevronLeft, ChevronRight, Zap, Brain, Dumbbell, Trophy, ArrowLeft, Download, FileText, FileSpreadsheet, CalendarDays, Video, Heart } from "lucide-react";
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO, addWeeks, subWeeks, addMonths, startOfMonth, endOfMonth, eachWeekOfInterval, getWeek } from 'date-fns';
import { nl } from 'date-fns/locale';
import { Link } from 'wouter';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface TrainingSession {
  id: string;
  planId: number;
  week: number;
  session: number;
  date: string;
  time: string;
  duration: number;
  focusArea: string;
  location: string;
  ageGroup: string;
  assignedElements: string[];
  intensity: 'low' | 'medium' | 'high';
  weather: 'indoor' | 'outdoor';
  notes: string;
  status: 'planned' | 'completed' | 'cancelled';
}

function CalendarPlannerSafe(props: any) {
  const planId = props.params?.planId;
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showEventDialog, setShowEventDialog] = useState(false);
  const [eventForm, setEventForm] = useState({
    title: '',
    description: '',
    eventType: 'training' as 'training' | 'extra_training' | 'friendly_match' | 'competition_match' | 'stage' | 'tournament' | 'videotraining' | 'teambuilding' | 'other',
    date: '',
    startTime: '',
    duration: 90,
    location: '',
    opponent: '',
    videoUrl: '',
    videoTopic: '',
    teambuildingType: '',
    teambuildingActivity: '',
    maxParticipants: 0,
    costPerPerson: 0,
    intensity: 'matig' as 'laag' | 'matig' | 'hoog' | 'maximaal',
    notes: ''
  });
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState<string | null>(null);
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [selectedElements, setSelectedElements] = useState<string[]>([]);

  // Fetch data with safe defaults and auto-refresh when plan changes
  const { data: yearPlans = [], isLoading: isLoadingPlans } = useQuery({ 
    queryKey: ['/api/year-plans'],
    refetchOnWindowFocus: true
  });
  const { data: sessions = [], refetch: refetchSessions } = useQuery({ 
    queryKey: ['/api/year-plans', selectedPlan?.id, 'sessions'], 
    enabled: !!selectedPlan,
    refetchOnWindowFocus: true
  });
  const { data: calendarEvents = [] } = useQuery({ 
    queryKey: ['/api/calendar-events', selectedPlan?.id], 
    enabled: !!selectedPlan,
    refetchOnWindowFocus: true
  });
  const { data: clubInfo } = useQuery({ queryKey: ['/api/club/info'] });
  const { data: iaElements = [] } = useQuery({ queryKey: ['/api/iadatabank/elements'] });

  // Extract club colors
  const getClubColors = () => {
    if (clubInfo?.colors) {
      const colorArray = clubInfo.colors.split(',');
      return {
        primary: colorArray[0]?.trim() || '#4a90e2',
        secondary: colorArray[1]?.trim() || '#6c5ce7'
      };
    }
    return { primary: '#4a90e2', secondary: '#6c5ce7' };
  };

  const clubColors = getClubColors();

  // Set initial plan if planId is provided and update when plan changes
  useEffect(() => {
    if (planId && yearPlans && Array.isArray(yearPlans) && yearPlans.length > 0) {
      const plan = yearPlans.find((p: any) => p.id === parseInt(planId));
      if (plan) {
        setSelectedPlan(plan);
      }
    }
  }, [planId, yearPlans]);

  // Force calendar refresh when selected plan data changes
  useEffect(() => {
    if (selectedPlan && planId) {
      // Find updated plan data from yearPlans array
      const updatedPlan = yearPlans.find((p: any) => p.id === parseInt(planId));
      if (updatedPlan && JSON.stringify(updatedPlan) !== JSON.stringify(selectedPlan)) {
        console.log('Plan data changed, updating calendar...', updatedPlan);
        setSelectedPlan(updatedPlan);
        refetchSessions();
      }
    }
  }, [yearPlans, selectedPlan, planId, refetchSessions]);

  // Safe date checking function - updates with real-time plan data
  const isDateAvailable = useMemo(() => {
    return (date: Date) => {
      // Get most current plan data from yearPlans array
      const currentPlan = planId && yearPlans.length > 0 ? 
        yearPlans.find((p: any) => p.id === parseInt(planId)) : selectedPlan;
      
      if (!currentPlan || !currentPlan.startDate || !currentPlan.endDate) return false;
      
      try {
        const planStart = parseISO(currentPlan.startDate);
        const planEnd = parseISO(currentPlan.endDate);
        
        if (date < planStart || date > planEnd) return false;
        
        if (!currentPlan.trainingDays || !Array.isArray(currentPlan.trainingDays)) return false;
        
        const dayName = format(date, 'EEEE', { locale: nl });
        const dayMapping: { [key: string]: string } = {
          'maandag': 'Maandag',
          'dinsdag': 'Dinsdag', 
          'woensdag': 'Woensdag',
          'donderdag': 'Donderdag',
          'vrijdag': 'Vrijdag',
          'zaterdag': 'Zaterdag',
          'zondag': 'Zondag'
        };
        
        const dutchDayName = dayMapping[dayName.toLowerCase()];
        return currentPlan.trainingDays.includes(dutchDayName);
      } catch (error) {
        return false;
      }
    };
  }, [selectedPlan, yearPlans, planId]);

  // Calendar day generation
  const getCalendarDays = () => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    const startWeek = startOfWeek(start, { weekStartsOn: 1 });
    const endWeek = endOfWeek(end, { weekStartsOn: 1 });
    
    return eachDayOfInterval({ start: startWeek, end: endWeek });
  };

  // Get sessions for a specific date
  const getSessionsForDate = (date: Date) => {
    if (!Array.isArray(sessions)) return [];
    return sessions.filter((session: any) => {
      try {
        return isSameDay(parseISO(session.date), date);
      } catch {
        return false;
      }
    });
  };

  // Get calendar events for a specific date
  const getEventsForDate = (date: Date) => {
    if (!Array.isArray(calendarEvents)) return [];
    return calendarEvents.filter((event: any) => {
      try {
        return isSameDay(parseISO(event.date), date);
      } catch {
        return false;
      }
    });
  };

  // Get event color styling based on type
  const getEventStyling = (eventType: string) => {
    switch (eventType) {
      case 'friendly_match':
      case 'competition_match':
        return 'bg-red-100 text-red-800 border-red-500';
      case 'stage':
        return 'bg-purple-100 text-purple-800 border-purple-500';
      case 'tournament':
        return 'bg-yellow-100 text-yellow-800 border-yellow-500';
      case 'videotraining':
        return 'bg-indigo-100 text-indigo-800 border-indigo-500';
      case 'teambuilding':
        return 'bg-orange-100 text-orange-800 border-orange-500';
      case 'extra_training':
        return 'bg-green-100 text-green-800 border-green-500';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-500';
    }
  };

  // Export functions
  const exportToPDF = async () => {
    if (!selectedPlan) return;
    
    try {
      const response = await fetch(`/api/year-plans/${selectedPlan.id}/export/pdf`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedPlan.name}_jaarplanning.pdf`;
        a.click();
        window.URL.revokeObjectURL(url);
        toast({ title: "Succes", description: "PDF export gedownload" });
      } else {
        throw new Error('Export failed');
      }
    } catch (error) {
      toast({ title: "Fout", description: "PDF export mislukt", variant: "destructive" });
    }
  };

  const exportToExcel = async () => {
    if (!selectedPlan) return;
    
    try {
      const response = await fetch(`/api/year-plans/${selectedPlan.id}/export/excel`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedPlan.name}_jaarplanning.xlsx`;
        a.click();
        window.URL.revokeObjectURL(url);
        toast({ title: "Succes", description: "Excel export gedownload" });
      } else {
        throw new Error('Export failed');
      }
    } catch (error) {
      toast({ title: "Fout", description: "Excel export mislukt", variant: "destructive" });
    }
  };

  const exportToICS = async () => {
    if (!selectedPlan) return;
    
    try {
      const response = await fetch(`/api/year-plans/${selectedPlan.id}/export/ics`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedPlan.name}_jaarplanning.ics`;
        a.click();
        window.URL.revokeObjectURL(url);
        toast({ title: "Succes", description: "Kalender export gedownload" });
      } else {
        throw new Error('Export failed');
      }
    } catch (error) {
      toast({ title: "Fout", description: "Kalender export mislukt", variant: "destructive" });
    }
  };

  if (isLoadingPlans) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-gray-500 mt-2">Jaarplanningen laden...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {!selectedPlan ? (
          // Plan selection screen
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Selecteer Jaarplanning</span>
              </CardTitle>
              <CardDescription>Kies een jaarplanning om de kalender te bekijken</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {yearPlans && Array.isArray(yearPlans) && yearPlans.map((plan: YearPlan) => (
                  <Card 
                    key={plan.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedPlan(plan)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold">{plan.name}</h3>
                          <p className="text-sm text-gray-600">{plan.description}</p>
                          <div className="flex space-x-4 mt-2 text-xs text-gray-500">
                            <span>Leeftijd: {plan.ageGroup}</span>
                            <span>Seizoen: {plan.season}</span>
                          </div>
                        </div>
                        <Badge variant={plan.status === 'active' ? 'default' : 'secondary'}>
                          {plan.status}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {(!yearPlans || !Array.isArray(yearPlans) || yearPlans.length === 0) && (
                  <p className="text-gray-500">Geen jaarplanningen gevonden</p>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          // Calendar view
          <>
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg text-white p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setSelectedPlan(null)}
                    className="bg-white/10 border-white/20 hover:bg-white hover:text-blue-600 text-white backdrop-blur-sm"
                  >
                    <div className="bg-blue-500 rounded p-1 mr-2">
                      <ArrowLeft className="h-3 w-3 text-white" />
                    </div>
                    Terug
                  </Button>
                  <div>
                    <h1 className="text-2xl font-bold">{selectedPlan.name}</h1>
                    <p className="text-blue-100">Kalender voor {selectedPlan.ageGroup} - {selectedPlan.season}</p>
                  </div>
                </div>
                
                {/* Month navigation */}
                <div className="flex items-center space-x-4">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentDate(subWeeks(currentDate, 4))}
                    className="bg-white/10 border-white/20 hover:bg-white hover:text-blue-600 text-white backdrop-blur-sm"
                  >
                    <div className="bg-blue-500 rounded p-1">
                      <ChevronLeft className="h-3 w-3 text-black" />
                    </div>
                  </Button>
                  <span className="text-xl font-semibold min-w-[200px] text-center">
                    {format(currentDate, 'MMMM yyyy', { locale: nl })}
                  </span>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentDate(addWeeks(currentDate, 4))}
                    className="bg-white/10 border-white/20 hover:bg-white hover:text-blue-600 text-white backdrop-blur-sm"
                  >
                    <div className="bg-blue-500 rounded p-1">
                      <ChevronRight className="h-3 w-3 text-black" />
                    </div>
                  </Button>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-4 gap-4 mt-6">
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="text-2xl font-bold">{Array.isArray(sessions) ? sessions.length : 0}</div>
                  <div className="text-sm text-blue-100">Trainingen</div>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="text-2xl font-bold">{selectedPlan.ageGroup}</div>
                  <div className="text-sm text-blue-100">Leeftijdsgroep</div>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="text-2xl font-bold">
                    {Array.isArray(sessions) ? sessions.reduce((acc: number, s: any) => acc + (s.duration || 0), 0) : 0}
                  </div>
                  <div className="text-sm text-blue-100">Totaal Minuten</div>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="text-2xl font-bold">
                    {Array.isArray(sessions) ? sessions.filter((s: any) => s.assignedElements?.length > 0).length : 0}
                  </div>
                  <div className="text-sm text-blue-100">Met IADATABANK</div>
                </div>
              </div>
            </div>

            {/* Calendar */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                {/* Week headers */}
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map((day) => (
                    <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
                      {day}
                    </div>
                  ))}
                </div>
                
                {/* Calendar grid */}
                <div className="grid grid-cols-7 gap-1">
                  {getCalendarDays().map((day, index) => {
                    const daySessions = getSessionsForDate(day);
                    const dayEvents = getEventsForDate(day);
                    const isCurrentMonth = day.getMonth() === currentDate.getMonth();
                    const isToday = isSameDay(day, new Date());
                    const isAvailable = isDateAvailable(day);
                    const totalActivities = daySessions.length + dayEvents.length;
                    
                    return (
                      <div
                        key={index}
                        className={`
                          min-h-28 border rounded-lg p-2 transition-colors
                          ${!isCurrentMonth ? 'bg-gray-50 text-gray-400' :
                            isAvailable ? 'bg-white hover:bg-green-50 cursor-pointer border-green-200' :
                            'bg-gray-100 text-gray-400 cursor-not-allowed'
                          }
                          ${isToday && isAvailable ? 'border-blue-500 bg-blue-50' : ''}
                          ${isToday && !isAvailable ? 'border-gray-400' : ''}
                        `}
                        onClick={() => {
                          if (isAvailable) {
                            setSelectedDate(day);
                            setShowSessionDialog(true);
                          }
                        }}
                      >
                        <div className={`text-sm ${isToday ? 'font-bold text-blue-600' : ''}`}>
                          {day.getDate()}
                        </div>
                        
                        {/* Training Sessions */}
                        <div className="space-y-1 mt-1">
                          {daySessions.slice(0, 3).map((session: any) => (
                            <div
                              key={session.id}
                              className="text-xs p-1 rounded truncate bg-blue-100 text-blue-800 border-l-2 border-blue-500"
                            >
                              <div className="font-medium">{session.time || '19:00'}</div>
                              {session.assignedElements && session.assignedElements.length > 0 && (
                                <div className="text-xs text-blue-600 truncate">
                                  {session.assignedElements.slice(0, 2).join(', ')}
                                </div>
                              )}
                              {session.focusArea && (
                                <div className="text-xs text-blue-600 truncate">
                                  {session.focusArea}
                                </div>
                              )}
                              {(!session.assignedElements || session.assignedElements.length === 0) && !session.focusArea && (
                                <div className="text-xs text-blue-600">
                                  Training
                                </div>
                              )}
                            </div>
                          ))}
                          
                          {/* Calendar Events */}
                          {dayEvents.slice(0, 3 - daySessions.length).map((event: any) => (
                            <div
                              key={`event-${event.id}`}
                              className={`text-xs p-1 rounded truncate border-l-2 ${getEventStyling(event.eventType)}`}
                            >
                              <div className="font-medium">{event.startTime || '15:00'}</div>
                              <div className="truncate">{event.title}</div>
                            </div>
                          ))}
                          
                          {totalActivities > 3 && (
                            <div className="text-xs text-gray-500 p-1">
                              +{totalActivities - 3} meer
                            </div>
                          )}
                          
                          {totalActivities === 0 && isAvailable && (
                            <div className="text-xs text-green-600 font-medium p-1">
                              + Training toevoegen
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Export Section */}
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-red-50 hover:bg-red-100 text-red-700 border-red-200"
                        onClick={() => setShowEventDialog(true)}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Plan Extra's
                      </Button>
                    </div>
                    <div className="text-center flex-1">
                      <h3 className="text-lg font-semibold text-gray-800">Export Jaarplanning</h3>
                      <p className="text-sm text-gray-600">Download de volledige jaarplanning inclusief alle trainingen</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={exportToPDF}
                        className="flex items-center space-x-2 hover:bg-red-50 hover:border-red-200"
                      >
                        <FileText className="h-4 w-4 text-red-600" />
                        <span>PDF</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={exportToExcel}
                        className="flex items-center space-x-2 hover:bg-green-50 hover:border-green-200"
                      >
                        <FileSpreadsheet className="h-4 w-4 text-green-600" />
                        <span>Excel</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={exportToICS}
                        className="flex items-center space-x-2 hover:bg-blue-50 hover:border-blue-200"
                      >
                        <CalendarDays className="h-4 w-4 text-blue-600" />
                        <span>Kalender</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {/* Session Dialog */}
        <Dialog open={showSessionDialog} onOpenChange={setShowSessionDialog}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Training Plannen</span>
              </DialogTitle>
              <DialogDescription>
                Plan een training voor {selectedDate && format(selectedDate, 'dd MMMM yyyy', { locale: nl })}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Basis Training Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="session-time">Tijd</Label>
                  <Input
                    id="session-time"
                    type="time"
                    defaultValue="19:00"
                    className="w-full"
                  />
                </div>
                <div>
                  <Label htmlFor="session-duration">Duur (minuten)</Label>
                  <Input
                    id="session-duration"
                    type="number"
                    defaultValue="90"
                    min="30"
                    max="180"
                    className="w-full"
                  />
                </div>
                <div>
                  <Label htmlFor="session-intensity">Intensiteit</Label>
                  <Select defaultValue="medium">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer intensiteit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Laag</SelectItem>
                      <SelectItem value="medium">Gemiddeld</SelectItem>
                      <SelectItem value="high">Hoog</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Training Plannen */}
              <div>
                <Label className="text-base font-semibold">Training Plannen</Label>
                
                {/* Navigation Breadcrumb */}
                {(selectedCategory || selectedSubCategory || selectedTheme || selectedSkill) && (
                  <div className="flex items-center space-x-2 mt-2 mb-4 text-sm">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => {
                        setSelectedCategory(null);
                        setSelectedSubCategory(null);
                        setSelectedTheme(null);
                        setSelectedSkill(null);
                      }}
                      className="text-blue-600 hover:text-blue-800 p-0 h-auto"
                    >
                      Hoofdcategorieën
                    </Button>
                    {selectedCategory && (
                      <>
                        <span className="text-gray-400">›</span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => {
                            setSelectedSubCategory(null);
                            setSelectedTheme(null);
                            setSelectedSkill(null);
                          }}
                          className="text-blue-600 hover:text-blue-800 p-0 h-auto"
                        >
                          {selectedCategory}
                        </Button>
                      </>
                    )}
                    {selectedSubCategory && (
                      <>
                        <span className="text-gray-400">›</span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => {
                            setSelectedTheme(null);
                            setSelectedSkill(null);
                          }}
                          className="text-blue-600 hover:text-blue-800 p-0 h-auto"
                        >
                          {selectedSubCategory}
                        </Button>
                      </>
                    )}
                    {selectedTheme && (
                      <>
                        <span className="text-gray-400">›</span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => setSelectedSkill(null)}
                          className="text-blue-600 hover:text-blue-800 p-0 h-auto"
                        >
                          {selectedTheme}
                        </Button>
                      </>
                    )}
                    {selectedSkill && (
                      <>
                        <span className="text-gray-400">›</span>
                        <span className="text-gray-700 font-medium">{selectedSkill}</span>
                      </>
                    )}
                  </div>
                )}

                {/* Level 1: Main Categories */}
                {!selectedCategory && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
                    {['BASICS', 'TEAMTACTISCH', 'FYSIEK', 'MENTAAL'].map((topic) => {
                      const topicConfig: { [key: string]: { color: string, bgColor: string } } = {
                        'BASICS': { color: 'text-blue-700', bgColor: 'bg-blue-50 border-blue-200 hover:bg-blue-100' },
                        'TEAMTACTISCH': { color: 'text-green-700', bgColor: 'bg-green-50 border-green-200 hover:bg-green-100' },
                        'FYSIEK': { color: 'text-orange-700', bgColor: 'bg-orange-50 border-orange-200 hover:bg-orange-100' },
                        'MENTAAL': { color: 'text-purple-700', bgColor: 'bg-purple-50 border-purple-200 hover:bg-purple-100' }
                      };

                      const categoryKey = `category-${topic}`;
                      
                      return (
                        <div 
                          key={topic} 
                          className={`border-2 rounded-lg p-6 cursor-pointer transition-colors ${
                            selectedElements.includes(categoryKey)
                              ? 'bg-green-100 border-green-400'
                              : topicConfig[topic]?.bgColor || 'bg-gray-50 border-gray-200'
                          }`}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (selectedElements.includes(categoryKey)) {
                              setSelectedElements(prev => prev.filter(id => id !== categoryKey));
                            } else {
                              setSelectedElements(prev => [...prev, categoryKey]);
                            }
                          }}
                        >
                          <div className="flex items-start space-x-3">
                            <input
                              type="checkbox"
                              checked={selectedElements.includes(categoryKey)}
                              onChange={() => {}}
                              className="rounded border-gray-300 mt-1"
                            />
                            <div 
                              className="flex-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedCategory(topic);
                              }}
                            >
                              <h4 className={`font-bold text-lg cursor-pointer ${topicConfig[topic]?.color || 'text-gray-700'}`}>
                                {topic}
                              </h4>
                              <p className="text-xs text-gray-400 mt-1">Klik voor details</p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Level 2: Sub Categories (B+, B-, OMSCH. B+/B-, OMSCH. B-/B+) */}
                {selectedCategory && !selectedSubCategory && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
                    {(selectedCategory === 'TEAMTACTISCH' 
                      ? ['B+', 'B-', 'OMSCH. B+/B-', 'OMSCH. B-/B+']
                      : ['B+', 'B-']
                    ).map((subCat) => {
                      const subcatKey = `subcat-${selectedCategory}-${subCat}`;
                      
                      return (
                        <div 
                          key={subCat}
                          className={`border-2 rounded-lg p-6 cursor-pointer transition-colors ${
                            selectedElements.includes(subcatKey)
                              ? 'bg-green-100 border-green-400'
                              : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                          }`}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (selectedElements.includes(subcatKey)) {
                              setSelectedElements(prev => prev.filter(id => id !== subcatKey));
                            } else {
                              setSelectedElements(prev => [...prev, subcatKey]);
                            }
                          }}
                        >
                          <div className="flex items-start space-x-3">
                            <input
                              type="checkbox"
                              checked={selectedElements.includes(subcatKey)}
                              onChange={() => {}}
                              className="rounded border-gray-300 mt-1"
                            />
                            <div 
                              className="flex-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedSubCategory(subCat);
                              }}
                            >
                              <h4 className="font-bold text-lg text-gray-700 cursor-pointer">
                                {selectedCategory} {subCat}
                              </h4>
                              <p className="text-xs text-gray-400 mt-1">Klik voor details</p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Level 3: Themes for selected sub-category */}
                {selectedCategory && selectedSubCategory && !selectedTheme && (
                  <div>
                    <div className="mb-4">
                      <h4 className="font-medium text-base mb-3">{selectedCategory} {selectedSubCategory} thema's:</h4>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
                      {iaElements && Array.isArray(iaElements.data) && (() => {
                        // Get elements for the selected category and sub-category
                        const filteredElements = iaElements.data.filter((element: any) => 
                          element.topic === selectedCategory && 
                          element.subtopic === selectedSubCategory
                        );

                        // Group by theme
                        const themeGroups = filteredElements.reduce((acc: any, element: any) => {
                          const themeName = element.theme;
                          
                          if (themeName && themeName.length > 0) {
                            if (!acc[themeName]) acc[themeName] = [];
                            acc[themeName].push(element);
                          }
                          return acc;
                        }, {});

                        const themeNames = Object.keys(themeGroups);
                        
                        if (themeNames.length === 0) {
                          return (
                            <div className="col-span-full text-center py-8">
                              <p className="text-gray-500">Geen thema's gevonden voor {selectedCategory} {selectedSubCategory}</p>
                            </div>
                          );
                        }

                        return themeNames.map((themeName) => {
                          const themeKey = `theme-${selectedCategory}-${selectedSubCategory}-${themeName}`;
                          
                          return (
                            <div 
                              key={themeName}
                              className={`border-2 rounded-lg p-4 cursor-pointer transition-colors ${
                                selectedElements.includes(themeKey)
                                  ? 'bg-green-100 border-green-400'
                                  : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                              }`}
                              onClick={(e) => {
                                e.stopPropagation();
                                if (selectedElements.includes(themeKey)) {
                                  setSelectedElements(prev => prev.filter(id => id !== themeKey));
                                } else {
                                  setSelectedElements(prev => [...prev, themeKey]);
                                }
                              }}
                            >
                              <div className="flex items-start space-x-3">
                                <input
                                  type="checkbox"
                                  checked={selectedElements.includes(themeKey)}
                                  onChange={() => {}}
                                  className="rounded border-gray-300 mt-1"
                                />
                                <div 
                                  className="flex-1"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedTheme(themeName);
                                  }}
                                >
                                  <h4 className="font-bold text-sm text-gray-700 cursor-pointer">
                                    {themeName}
                                  </h4>
                                  <p className="text-xs text-gray-500 mt-1">
                                    {themeGroups[themeName].length} elementen
                                  </p>
                                  <p className="text-xs text-gray-400 mt-1">Klik voor details</p>
                                </div>
                              </div>
                            </div>
                          );
                        });
                      })()}
                    </div>
                  </div>
                )}

                {/* Level 4: Skills for selected theme */}
                {selectedCategory && selectedSubCategory && selectedTheme && !selectedSkill && (
                  <div>
                    <div className="mb-4">
                      <h4 className="font-medium text-base mb-3">{selectedTheme} elementen:</h4>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
                      {iaElements && Array.isArray(iaElements.data) && (() => {
                        // Get elements for the selected category, sub-category and theme
                        const filteredElements = iaElements.data.filter((element: any) => 
                          element.topic === selectedCategory && 
                          element.subtopic === selectedSubCategory &&
                          element.theme === selectedTheme
                        );

                        console.log('Filtered elements for', selectedCategory, selectedSubCategory, ':', filteredElements);

                        // Group by skill name (each element has a unique name property)
                        const skillGroups = filteredElements.reduce((acc: any, element: any) => {
                          // Use the element name directly as skill name
                          const skillName = element.name;
                          
                          if (skillName && skillName.length > 0) {
                            if (!acc[skillName]) acc[skillName] = [];
                            acc[skillName].push(element);
                          }
                          return acc;
                        }, {});

                        console.log('Skill groups:', skillGroups);

                        const skillNames = Object.keys(skillGroups);
                        
                        if (skillNames.length === 0) {
                          return (
                            <div className="col-span-full text-center py-8">
                              <p className="text-gray-500">Geen elementen gevonden voor {selectedCategory} {selectedSubCategory}</p>
                              <p className="text-xs text-gray-400 mt-2">
                                Totaal aantal IADATABANK elementen: {iaElements?.data?.length || 0}
                              </p>
                            </div>
                          );
                        }

                        return skillNames.map((skillName) => {
                          const skillElement = skillGroups[skillName][0];
                          const skillKey = `skill-${skillElement.id}`;
                          
                          return (
                            <div 
                              key={skillName}
                              className={`border-2 rounded-lg p-4 cursor-pointer transition-colors ${
                                selectedElements.includes(skillKey)
                                  ? 'bg-green-100 border-green-400'
                                  : 'bg-white border-gray-300 hover:bg-blue-50 hover:border-blue-300'
                              }`}
                              onClick={(e) => {
                                e.stopPropagation();
                                if (selectedElements.includes(skillKey)) {
                                  setSelectedElements(prev => prev.filter(id => id !== skillKey));
                                } else {
                                  setSelectedElements(prev => [...prev, skillKey]);
                                }
                              }}
                            >
                              <div className="flex items-start space-x-3">
                                <input
                                  type="checkbox"
                                  checked={selectedElements.includes(skillKey)}
                                  onChange={() => {}}
                                  className="rounded border-gray-300 mt-1"
                                />
                                <div 
                                  className="flex-1"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedSkill(skillName);
                                  }}
                                >
                                  <h5 className="font-medium text-sm text-gray-700 cursor-pointer">
                                    {skillName}
                                  </h5>
                                  <p className="text-xs text-gray-500 mt-1">
                                    {skillGroups[skillName].length} niveau{skillGroups[skillName].length !== 1 ? 's' : ''} • Klik voor details
                                  </p>
                                </div>
                              </div>
                            </div>
                          );
                        });
                      })()}
                    </div>
                  </div>
                )}

                {/* Level 4: Difficulty Levels */}
                {selectedCategory && selectedSubCategory && selectedSkill && (
                  <div className="mt-2">
                    <h4 className="font-medium text-base mb-3">Kies moeilijkheidsgraad voor {selectedSkill}:</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {iaElements && Array.isArray(iaElements.data) && (() => {
                        const skillElements = iaElements.data.filter((element: any) => 
                          element.topic === selectedCategory && 
                          element.subtopic === selectedSubCategory &&
                          element.name.toLowerCase().includes(selectedSkill.toLowerCase())
                        );

                        const allProgressions: any[] = [];
                        skillElements.forEach((element: any) => {
                          if (element.progressions) {
                            element.progressions.forEach((progression: any, index: number) => {
                              allProgressions.push(
                                <div 
                                  key={`${element.id}-${index}`}
                                  className={`border-2 rounded-lg p-4 cursor-pointer transition-colors ${
                                    selectedElements.includes(`${element.id}-${index}`) 
                                      ? 'bg-green-100 border-green-400' 
                                      : 'bg-white border-gray-300 hover:bg-green-50 hover:border-green-300'
                                  }`}
                                  onClick={() => {
                                    const elementKey = `${element.id}-${index}`;
                                    if (selectedElements.includes(elementKey)) {
                                      setSelectedElements(prev => prev.filter(id => id !== elementKey));
                                    } else {
                                      setSelectedElements(prev => [...prev, elementKey]);
                                    }
                                  }}
                                >
                                  <div className="flex items-start space-x-3">
                                    <input
                                      type="checkbox"
                                      checked={selectedElements.includes(`${element.id}-${index}`)}
                                      onChange={() => {}} // Handled by onClick above
                                      className="rounded border-gray-300 mt-1"
                                    />
                                    <div className="flex-1">
                                      <Label className="text-sm font-medium cursor-pointer block">
                                        {progression.name}
                                      </Label>
                                      {progression.description && (
                                        <p className="text-xs text-gray-600 mt-1">{progression.description}</p>
                                      )}
                                      <div className="text-xs text-gray-500 mt-2">
                                        Niveau {progression.level} - {selectedCategory} {selectedSubCategory}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            });
                          }
                        });
                        return allProgressions;
                      })()}
                    </div>
                    
                    {/* Selected Elements Summary */}
                    {selectedElements.length > 0 && (
                      <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                        <h5 className="font-medium text-sm text-blue-800 mb-2">
                          Geselecteerde elementen ({selectedElements.length}):
                        </h5>
                        <div className="flex flex-wrap gap-2">
                          {selectedElements.map((elementKey) => {
                            let content = '';
                            let bgColor = 'bg-blue-200 text-blue-800';
                            
                            if (elementKey.startsWith('category-')) {
                              content = elementKey.replace('category-', '');
                              bgColor = 'bg-purple-200 text-purple-800';
                            } else if (elementKey.startsWith('subcat-')) {
                              const parts = elementKey.replace('subcat-', '').split('-');
                              content = `${parts[0]} ${parts[1]}`;
                              bgColor = 'bg-indigo-200 text-indigo-800';
                            } else if (elementKey.startsWith('skill-')) {
                              const elementId = elementKey.replace('skill-', '');
                              const element = iaElements?.data?.find((el: any) => el.id === elementId);
                              content = element?.name || 'Onbekend element';
                              bgColor = 'bg-green-200 text-green-800';
                            } else {
                              // Progression level
                              const [elementId, progressionIndex] = elementKey.split('-');
                              const element = iaElements?.data?.find((el: any) => el.id.startsWith(elementId));
                              if (element?.progressions) {
                                const progression = element.progressions[parseInt(progressionIndex)];
                                content = progression?.name || 'Onbekend niveau';
                                bgColor = 'bg-orange-200 text-orange-800';
                              }
                            }
                            
                            if (!content) return null;
                            
                            return (
                              <span key={elementKey} className={`text-xs px-2 py-1 rounded ${bgColor}`}>
                                {content}
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Training Notities */}
              <div>
                <Label htmlFor="session-notes">Notities</Label>
                <Textarea
                  id="session-notes"
                  placeholder="Aanvullende opmerkingen voor deze training..."
                  rows={3}
                />
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end space-x-2 pt-4 border-t">
                <Button variant="outline" onClick={() => setShowSessionDialog(false)}>
                  Annuleren
                </Button>
                <Button 
                  onClick={() => {
                    toast({ title: "Training Gepland", description: "De training is succesvol toegevoegd aan de kalender" });
                    setShowSessionDialog(false);
                  }}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Training Plannen
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

export default CalendarPlannerSafe;