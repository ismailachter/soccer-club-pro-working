import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { BarChart3, TrendingUp, Users, Target, Shield, Zap, Brain, Activity } from "lucide-react";
import { BackToMenu } from "@/components/ui/back-to-menu";

interface Team {
  id: number;
  name: string;
  age_group: string;
  description?: string;
  primary_color?: string;
  secondary_color?: string;
  player_count: number;
}

interface TacticalCategory {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  borderColor: string;
  subcategories: {
    id: string;
    name: string;
    description: string;
    elements: number;
    difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  }[];
}

const tacticalCategories: TacticalCategory[] = [
  {
    id: 'teamtactical_b_plus',
    name: 'TEAMTACTISCH B+',
    icon: <TrendingUp className="h-6 w-6" />,
    color: 'text-green-700',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200',
    subcategories: [
      { id: 'opbouwen', name: 'Opbouwen', description: 'Opbouwen vanuit de verdediging met balcontrole', elements: 45, difficulty: 'Advanced' },
      { id: 'aanvallen', name: 'Aanvallen', description: 'Georganiseerde aanvalspatronen en doelgerichte acties', elements: 38, difficulty: 'Advanced' },
      { id: 'omschakelen_naar_aanval', name: 'Omschakelen naar Aanval', description: 'Snelle transitie van verdediging naar aanval', elements: 22, difficulty: 'Intermediate' }
    ]
  },
  {
    id: 'teamtactical_b_minus',
    name: 'TEAMTACTISCH B-',
    icon: <Shield className="h-6 w-6" />,
    color: 'text-red-700',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200',
    subcategories: [
      { id: 'druk_zetten', name: 'Druk Zetten', description: 'Actief pressing en balverovering hoog op het veld', elements: 6, difficulty: 'Advanced' },
      { id: 'compact_verdedigen', name: 'Compact Verdedigen', description: 'Georganiseerde compacte verdediging als team', elements: 6, difficulty: 'Advanced' },
      { id: 'beschermen_eigen_doel', name: 'Beschermen Eigen Doel', description: 'Defensieve organisatie rond eigen zestien', elements: 5, difficulty: 'Intermediate' }
    ]
  },
  {
    id: 'omschakelingen',
    name: 'OMSCHAKELINGEN',
    icon: <Activity className="h-6 w-6" />,
    color: 'text-blue-700',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    subcategories: [
      { id: 'omschakelen_naar_verdediging', name: 'Omschakelen naar Verdediging', description: 'Snelle transitie van aanval naar verdediging bij balverlies', elements: 18, difficulty: 'Advanced' },
      { id: 'omschakelen_naar_aanval', name: 'Omschakelen naar Aanval', description: 'Directe overgang naar aanval na balverovering', elements: 22, difficulty: 'Advanced' },
      { id: 'transitiemomenten', name: 'Transitiemomenten', description: 'Beslissingen in overgangsfasen van het spel', elements: 15, difficulty: 'Intermediate' }
    ]
  }
];

function DifficultyBadge({ difficulty }: { difficulty: string }) {
  const colors = {
    'Beginner': 'bg-green-100 text-green-800',
    'Intermediate': 'bg-yellow-100 text-yellow-800',
    'Advanced': 'bg-red-100 text-red-800'
  };
  
  return (
    <Badge className={colors[difficulty as keyof typeof colors] || 'bg-gray-100 text-gray-800'}>
      {difficulty}
    </Badge>
  );
}

function TeamAnalysisDashboard() {
  const [selectedTeam, setSelectedTeam] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"]
  });

  // Mock analysis data - in real implementation this would come from API
  const getTeamAnalysis = (categoryId: string, teamId: string) => {
    const baseScore = Math.floor(Math.random() * 40) + 60; // 60-100
    const variance = Math.floor(Math.random() * 20) - 10; // -10 to +10
    return Math.max(0, Math.min(100, baseScore + variance));
  };

  const getTeamProgress = (categoryId: string, teamId: string) => {
    return Math.floor(Math.random() * 100);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <BackToMenu />
      
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Team Analysis</h1>
          <p className="text-gray-600 mt-2">Analyse teamprestaties gebaseerd op TeamTactical B+, B- en Omschakelingen</p>
        </div>
        <Activity className="h-8 w-8 text-primary" />
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Analysis Filters
          </CardTitle>
        </CardHeader>
        <CardContent className="flex gap-4">
          <div className="flex-1">
            <label className="text-sm font-medium mb-2 block">Select Team</label>
            <Select value={selectedTeam} onValueChange={setSelectedTeam}>
              <SelectTrigger>
                <SelectValue placeholder="Choose team..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Teams</SelectItem>
                {teams.map((team) => (
                  <SelectItem key={team.id} value={team.id.toString()}>
                    {team.name} ({team.player_count} players)
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex-1">
            <label className="text-sm font-medium mb-2 block">Tactical Category</label>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Choose category..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {tacticalCategories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Analysis Grid */}
      <div className="grid gap-6">
        {tacticalCategories
          .filter(cat => selectedCategory === "all" || cat.id === selectedCategory)
          .map((category) => (
            <Card key={category.id} className={`${category.borderColor} border-2`}>
              <CardHeader className={category.bgColor}>
                <CardTitle className={`flex items-center gap-3 ${category.color}`}>
                  {category.icon}
                  {category.name}
                </CardTitle>
                <CardDescription>
                  Tactical analysis voor {category.name.toLowerCase()} elementen
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid gap-4">
                  {category.subcategories.map((subcategory) => (
                    <div key={subcategory.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-lg">{subcategory.name}</h4>
                          <p className="text-sm text-gray-600">{subcategory.description}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <DifficultyBadge difficulty={subcategory.difficulty} />
                          <Badge variant="outline">{subcategory.elements} elements</Badge>
                        </div>
                      </div>
                      
                      {/* Team Performance Bars */}
                      <div className="space-y-3">
                        {(selectedTeam === "all" ? teams : teams.filter(t => t.id.toString() === selectedTeam))
                          .map((team) => {
                            const score = getTeamAnalysis(category.id, team.id.toString());
                            const progress = getTeamProgress(category.id, team.id.toString());
                            
                            return (
                              <div key={team.id} className="space-y-2">
                                <div className="flex items-center justify-between text-sm">
                                  <span className="font-medium" style={{ color: team.primary_color || '#374151' }}>
                                    {team.name}
                                  </span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-gray-600">Progress: {progress}%</span>
                                    <span className="font-semibold">Score: {score}/100</span>
                                  </div>
                                </div>
                                <div className="flex gap-2">
                                  <div className="flex-1">
                                    <Progress value={progress} className="h-2" />
                                  </div>
                                  <div className="flex-1">
                                    <Progress value={score} className="h-2" />
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
      </div>

      {/* Summary Statistics */}
      {selectedTeam !== "all" && (
        <Card>
          <CardHeader>
            <CardTitle>Team Summary</CardTitle>
            <CardDescription>
              Overall performance overview voor {teams.find(t => t.id.toString() === selectedTeam)?.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {tacticalCategories.map((category) => {
                const avgScore = Math.floor(Math.random() * 30) + 70; // 70-100
                return (
                  <div key={category.id} className={`${category.bgColor} ${category.borderColor} border rounded-lg p-4 text-center`}>
                    <div className={`${category.color} mb-2 flex justify-center`}>
                      {category.icon}
                    </div>
                    <div className={`text-2xl font-bold ${category.color}`}>{avgScore}%</div>
                    <div className="text-sm text-gray-600">{category.name}</div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default TeamAnalysisDashboard;