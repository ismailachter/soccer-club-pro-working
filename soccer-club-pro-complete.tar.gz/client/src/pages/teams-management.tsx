import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { Users, UserPlus, Edit, Crown, Calendar, MapPin, Phone, Mail, Trophy, ChevronRight, Target, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BackToMenu } from "@/components/ui/back-to-menu";

interface Player {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: string;
  position?: string;
  jerseyNumber?: number;
  status: string;
  teamName: string;
  teamId: number;
  profileImage?: string;
}

interface Team {
  id: number;
  name: string;
  age_group: string;
  description?: string;
  primary_color?: string;
  secondary_color?: string;
  total_sessions: number;
  training_sessions: number;
  varia_sessions: number;
  player_count: number;
}

interface NewTeamForm {
  name: string;
  age_group: string;
  description?: string;
  primary_color: string;
  secondary_color: string;
}

function PlayerCard({ player }: { player: Player }) {
  const getPositionColor = (position?: string) => {
    switch (position) {
      case 'goalkeeper': return 'bg-yellow-100 text-yellow-800';
      case 'defender': return 'bg-blue-100 text-blue-800';
      case 'midfielder': return 'bg-green-100 text-green-800';
      case 'forward': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      case 'injured': return 'bg-red-100 text-red-800';
      case 'suspended': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          <Avatar className="h-12 w-12">
            <AvatarImage src={player.profileImage} />
            <AvatarFallback>
              {player.first_name?.[0] || ''}{player.last_name?.[0] || ''}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">
                {player.firstName || ''} {player.lastName || ''}
              </h3>
              {player.jerseyNumber && (
                <Badge variant="outline" className="text-xs">
                  #{player.jerseyNumber}
                </Badge>
              )}
            </div>
            
            <div className="mt-2 space-y-1">
              {player.position && (
                <Badge className={`text-xs ${getPositionColor(player.position)}`}>
                  {player.position}
                </Badge>
              )}
              <Badge className={`text-xs ${getStatusColor(player.status)}`}>
                {player.status}
              </Badge>
            </div>
            
            <div className="mt-2 space-y-1 text-xs text-gray-600">
              {player.email && (
                <div className="flex items-center space-x-1">
                  <Mail className="h-3 w-3" />
                  <span className="truncate">{player.email}</span>
                </div>
              )}
              {player.phone && (
                <div className="flex items-center space-x-1">
                  <Phone className="h-3 w-3" />
                  <span>{player.phone}</span>
                </div>
              )}
            </div>
          </div>
          

        </div>
      </CardContent>
    </Card>
  );
}

function TeamCard({ team, players, onViewPlayers, onViewPlanning }: { 
  team: Team; 
  players: Player[]; 
  onViewPlayers: (team: Team) => void;
  onViewPlanning: (team: Team) => void;
}) {
  const teamPlayers = players.filter(p => p.teamId === team.id);
  const activePlayers = teamPlayers.filter(p => p.status === 'active').length;
  const injuredPlayers = teamPlayers.filter(p => p.status === 'injured').length;
  
  return (
    <Card className="group hover:shadow-lg transition-all duration-200 cursor-pointer border-l-4" 
          style={{ borderLeftColor: team.primary_color || '#3b82f6' }}>
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center space-x-3">
                <div 
                  className="w-3 h-3 rounded-full shadow-sm" 
                  style={{ backgroundColor: team.primary_color || '#3b82f6' }}
                />
                <h3 className="text-xl font-bold text-gray-900">{team.name}</h3>
                <Badge variant="outline" className="text-xs font-medium">
                  {team.age_group}
                </Badge>
              </div>
              {team.description && (
                <p className="text-sm text-gray-600 mt-2">{team.description}</p>
              )}
            </div>
            
            <div className="text-right">
              <div className="text-3xl font-bold text-gray-900">{teamPlayers.length}</div>
              <div className="text-xs text-gray-500 uppercase tracking-wider">Spelers</div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-lg font-semibold text-green-600">{activePlayers}</div>
              <div className="text-xs text-gray-500">Actief</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-red-600">{injuredPlayers}</div>
              <div className="text-xs text-gray-500">Geblesseerd</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-blue-600">{team.training_sessions || 0}</div>
              <div className="text-xs text-gray-500">Trainingen</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 group-hover:border-blue-300 transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                onViewPlayers(team);
              }}
            >
              <Users className="h-4 w-4 mr-2" />
              Teamleden
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 group-hover:border-green-300 transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                onViewPlanning(team);
              }}
            >
              <Calendar className="h-4 w-4 mr-2" />
              Planning
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function TeamsManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm<NewTeamForm>();

  // Fetch teams data
  const { data: teamsData, isLoading: teamsLoading } = useQuery({
    queryKey: ['/api/teams-overview'],
  });

  // Fetch players data
  const { data: playersData, isLoading: playersLoading } = useQuery({
    queryKey: ['/api/players'],
  });

  const teams: Team[] = teamsData || [];
  const players: Player[] = playersData || [];

  // Statistics
  const totalPlayers = players.length;
  const activePlayers = players.filter(p => p.status === 'active').length;
  const inactivePlayers = players.filter(p => p.status === 'inactive').length;
  const injuredPlayers = players.filter(p => p.status === 'injured').length;

  // Handlers voor team acties
  const handleViewPlayers = (team: Team) => {
    // Navigeer naar Players Database met team filter
    window.location.href = '/players-database?team=' + team.id;
  };

  const handleViewPlanning = (team: Team) => {
    // Navigeer naar Jaarplanning met team filter
    window.location.href = '/jaarplanning?team=' + team.id;
  };

  // Create team mutation
  const createTeamMutation = useMutation({
    mutationFn: async (data: NewTeamForm) => {
      return apiRequest('/api/teams', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/teams-overview'] });
      toast({
        title: "Team aangemaakt",
        description: "Het nieuwe team is succesvol aangemaakt.",
      });
      setIsCreateDialogOpen(false);
      reset();
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij aanmaken",
        description: error.message || "Er is een fout opgetreden bij het aanmaken van het team.",
        variant: "destructive",
      });
    },
  });

  // Update team mutation
  const updateTeamMutation = useMutation({
    mutationFn: async (data: NewTeamForm & { id: number }) => {
      return apiRequest(`/api/teams/${data.id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/teams-overview'] });
      toast({
        title: "Team bijgewerkt",
        description: "Het team is succesvol bijgewerkt.",
      });
      setIsEditDialogOpen(false);
      setSelectedTeam(null);
      reset();
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij bijwerken",
        description: error.message || "Er is een fout opgetreden bij het bijwerken van het team.",
        variant: "destructive",
      });
    },
  });

  // Delete team mutation
  const deleteTeamMutation = useMutation({
    mutationFn: async (teamId: number) => {
      return apiRequest(`/api/teams/${teamId}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/teams-overview'] });
      toast({
        title: "Team verwijderd",
        description: "Het team is succesvol verwijderd.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij verwijderen",
        description: error.message || "Er is een fout opgetreden bij het verwijderen van het team.",
        variant: "destructive",
      });
    },
  });

  // Handle functions
  const handleCreateTeam = (data: NewTeamForm) => {
    createTeamMutation.mutate(data);
  };

  const handleEditTeam = (team: Team) => {
    setSelectedTeam(team);
    setValue('name', team.name);
    setValue('age_group', team.age_group);
    setValue('description', team.description || '');
    setValue('primary_color', team.primary_color || '#232e5d');
    setValue('secondary_color', team.secondary_color || '#4a90e2');
    setIsEditDialogOpen(true);
  };

  const handleUpdateTeam = (data: NewTeamForm) => {
    if (selectedTeam) {
      updateTeamMutation.mutate({ ...data, id: selectedTeam.id });
    }
  };

  const handleDeleteTeam = (team: Team) => {
    if (confirm(`Weet je zeker dat je het team "${team.name}" wilt verwijderen? Deze actie kan niet ongedaan worden gemaakt.`)) {
      deleteTeamMutation.mutate(team.id);
    }
  };

  // Group players by position
  const playersByPosition = players.reduce((acc, player) => {
    const position = player.position || 'Niet gespecificeerd';
    acc[position] = (acc[position] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  if (teamsLoading || playersLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="space-y-6">
          <div className="h-8 bg-gray-200 rounded animate-pulse" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded animate-pulse" />
            ))}
          </div>
          <div className="h-96 bg-gray-200 rounded animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Teams & Spelers</h1>
          <p className="text-gray-600 mt-2">
            Beheer al uw teams en spelers op één plaats
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <BackToMenu />
          <div className="text-sm text-gray-600">
            Spelers beheren via Players Database
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-blue-600" />
              <div>
                <div className="text-2xl font-bold">{totalPlayers}</div>
                <div className="text-sm text-gray-600">Totaal Spelers</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 bg-green-500 rounded-full" />
              <div>
                <div className="text-2xl font-bold">{activePlayers}</div>
                <div className="text-sm text-gray-600">Actief</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 bg-gray-400 rounded-full" />
              <div>
                <div className="text-2xl font-bold">{inactivePlayers}</div>
                <div className="text-sm text-gray-600">Inactief</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 bg-red-500 rounded-full" />
              <div>
                <div className="text-2xl font-bold">{injuredPlayers}</div>
                <div className="text-sm text-gray-600">Geblesseerd</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="teams" className="space-y-6">
        <TabsList>
          <TabsTrigger value="teams">Teams Overzicht</TabsTrigger>
          <TabsTrigger value="players">Alle Spelers</TabsTrigger>
          <TabsTrigger value="positions">Posities</TabsTrigger>
        </TabsList>
        
        <TabsContent value="teams" className="space-y-6">
          {teams.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {teams.map((team) => (
                <TeamCard 
                  key={team.id} 
                  team={team} 
                  players={players}
                  onViewPlayers={handleViewPlayers}
                  onViewPlanning={handleViewPlanning}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Users className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">Geen teams gevonden</h3>
                <p className="text-gray-600 mb-4">Begin met het aanmaken van uw eerste team</p>
                <Button>Team Aanmaken</Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="players" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Alle Spelers ({totalPlayers})</CardTitle>
              <CardDescription>
                Overzicht van alle spelers in de club
              </CardDescription>
            </CardHeader>
            <CardContent>
              {players.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {players.map((player) => (
                    <PlayerCard key={player.id} player={player} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Geen spelers gevonden</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="positions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Spelers per Positie</CardTitle>
              <CardDescription>
                Verdeling van spelers over verschillende posities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {Object.entries(playersByPosition).map(([position, count]) => (
                  <div key={position} className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold mb-2">{count}</div>
                    <div className="text-sm text-gray-600 capitalize">{position}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}