import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Star, Users, Target, Brain, Zap, RefreshCw, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface IADatabankElement {
  id: string;
  topic: string;
  subtopic: string;
  name: string;
  theme: string;
  progressions: {
    level: number;
    name: string;
    description: string;
    difficulty: number;
  }[];
}

const topicConfig = {
  BASICS: {
    display: "Basics",
    icon: Target,
    color: "bg-blue-500",
    description: "Fundamentele technische en tactische vaardigheden"
  },
  TEAMTACTISCH: {
    display: "Team Tactiek",
    icon: Users,
    color: "bg-green-500",
    description: "Collectieve spelvormen en teamtactiek"
  },
  MENTAAL: {
    display: "Mentale Aspecten",
    icon: Brain,
    color: "bg-purple-500",
    description: "Psychologische en mentale training"
  },
  FYSIEK: {
    display: "FYSIEK",
    icon: Zap,
    color: "bg-red-500",
    description: "Fysieke training en conditioning"
  }
};

export default function IADatabank() {
  const [selectedTopic, setSelectedTopic] = useState<string>("BASICS");
  const [selectedSubtopic, setSelectedSubtopic] = useState<string>("");
  const [selectedElement, setSelectedElement] = useState<IADatabankElement | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLevel, setSelectedLevel] = useState<number>(1);
  const [showElementDialog, setShowElementDialog] = useState(false);

  // Fetch all IADATABANK elements
  const { data: response, isLoading } = useQuery<{ data: IADatabankElement[] }>({
    queryKey: ['/api/iadatabank/elements'],
  });
  
  const elements = response?.data || [];

  // Filter elements based on topic, subtopic and search
  const filteredElements = elements.filter(element => {
    const matchesTopic = element.topic === selectedTopic;
    const matchesSubtopic = selectedSubtopic === "" || element.subtopic === selectedSubtopic;
    const matchesSearch = searchQuery === "" || 
      element.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      element.theme.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTopic && matchesSubtopic && matchesSearch;
  });

  // Check if current topic has subtopics
  const hasSubtopics = (topic: string) => {
    return topic === 'BASICS' || topic === 'TEAMTACTISCH' || topic === 'FYSIEK';
  };

  // Get available subtopics for current topic
  const getAvailableSubtopics = (topic: string) => {
    const topicElements = elements.filter(el => el.topic === topic);
    const subtopics = [...new Set(topicElements.map(el => el.subtopic))];
    return subtopics.sort((a, b) => {
      if (a === 'B+') return -1;
      if (b === 'B+') return 1;
      if (a === 'B-') return -1;
      if (b === 'B-') return 1;
      if (a === 'UITHOUDING') return -1;
      if (b === 'UITHOUDING') return 1;
      if (a === 'KRACHT') return -1;
      if (b === 'KRACHT') return 1;
      if (a === 'SNELHEID') return -1;
      if (b === 'SNELHEID') return 1;
      if (a === 'LENIGHEID') return -1;
      if (b === 'LENIGHEID') return 1;
      return a.localeCompare(b);
    });
  };

  // Reset subtopic when topic changes
  const handleTopicChange = (topic: string) => {
    setSelectedTopic(topic);
    setSelectedSubtopic("");
    setSearchQuery("");
  };

  // Group elements by subtopic with proper sorting for BASICS
  const elementsBySubtopic = filteredElements.reduce((acc, element) => {
    if (!acc[element.subtopic]) {
      acc[element.subtopic] = [];
    }
    acc[element.subtopic].push(element);
    return acc;
  }, {} as Record<string, IADatabankElement[]>);

  // Sort B+ and B- to appear first for BASICS
  const sortedSubtopics = Object.keys(elementsBySubtopic).sort((a, b) => {
    if (selectedTopic === 'BASICS') {
      if (a === 'B+') return -1;
      if (b === 'B+') return 1;
      if (a === 'B-') return -1;
      if (b === 'B-') return 1;
    }
    return a.localeCompare(b);
  });

  const handleElementClick = (element: IADatabankElement) => {
    setSelectedElement(element);
    setShowElementDialog(true);
  };

  const getDifficultyColor = (difficulty: number) => {
    if (difficulty <= 2) return "bg-green-100 text-green-800";
    if (difficulty <= 4) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const getElementCardStyle = (element: IADatabankElement) => {
    if (element.subtopic === 'B+') {
      return "cursor-pointer hover:shadow-lg transition-shadow border-2 border-yellow-400 bg-gradient-to-br from-yellow-50 to-yellow-100";
    }
    if (element.subtopic === 'B-') {
      return "cursor-pointer hover:shadow-lg transition-shadow border-2 border-gray-400 bg-gradient-to-br from-gray-50 to-gray-100";
    }
    return "cursor-pointer hover:shadow-lg transition-shadow";
  };

  const getElementBadgeStyle = (element: IADatabankElement) => {
    if (element.subtopic === 'B+') {
      return "bg-gradient-to-r from-yellow-400 to-yellow-600 text-white font-semibold";
    }
    if (element.subtopic === 'B-') {
      return "bg-gradient-to-r from-gray-400 to-gray-600 text-white font-semibold";
    }
    return "variant-secondary";
  };

  const renderProgressions = (progressions: IADatabankElement['progressions']) => {
    return (
      <div className="space-y-3">
        {progressions.map((progression) => (
          <div 
            key={progression.level}
            className={`p-3 rounded-lg border-l-4 ${
              progression.level === selectedLevel ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-gray-50'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-sm">Niveau {progression.level}: {progression.name}</span>
              <Badge className={getDifficultyColor(progression.difficulty)}>
                Moeilijkheid {progression.difficulty}
              </Badge>
            </div>
            <p className="text-sm text-gray-600">{progression.description}</p>
          </div>
        ))}
      </div>
    );
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Laden...</div>;
  }



  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">IADATABANK</h1>
          <p className="text-muted-foreground">
            Internationaal Analyse Databank - {elements.length} training elementen
          </p>
        </div>
      </div>

      {/* Topic Navigation */}
      <Tabs value={selectedTopic} onValueChange={handleTopicChange}>
        <TabsList className="grid w-full grid-cols-5">
          {Object.entries(topicConfig).map(([key, config]) => {
            const Icon = config.icon;
            const count = elements.filter(el => el.topic === key).length;
            return (
              <TabsTrigger key={key} value={key} className="flex items-center gap-2 relative">
                <ArrowLeft className="absolute left-1 h-3 w-3 opacity-30" />
                <Icon className="h-4 w-4 ml-3" />
                {config.display} ({count})
              </TabsTrigger>
            );
          })}
        </TabsList>

        {Object.entries(topicConfig).map(([key, config]) => (
          <TabsContent key={key} value={key} className="space-y-6">
            {/* Topic Description */}
            <div className={`p-4 rounded-lg ${config.color} text-white`}>
              <div className="flex items-center gap-3">
                <config.icon className="h-6 w-6" />
                <div>
                  <h2 className="font-semibold">{config.display}</h2>
                  <p className="text-sm opacity-90">{config.description}</p>
                </div>
              </div>
            </div>

            {/* Subtopic Selection for BASICS and TEAMTACTISCH */}
            {hasSubtopics(key) && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Kies categorie:</h3>
                <div className={`grid gap-4 ${key === 'FYSIEK' ? 'grid-cols-4' : 'grid-cols-2'}`}>
                  {getAvailableSubtopics(key).map((subtopic) => (
                    <Button
                      key={subtopic}
                      variant={selectedSubtopic === subtopic ? "default" : "outline"}
                      className={`h-20 flex flex-col items-center justify-center text-center relative ${
                        subtopic === 'B+' 
                          ? 'border-yellow-400 hover:bg-yellow-50' 
                          : subtopic === 'B-'
                          ? 'border-gray-400 hover:bg-gray-50'
                          : subtopic === 'UITHOUDING'
                          ? 'border-red-400 hover:bg-red-50'
                          : subtopic === 'KRACHT'
                          ? 'border-blue-400 hover:bg-blue-50'
                          : subtopic === 'SNELHEID'
                          ? 'border-green-400 hover:bg-green-50'
                          : subtopic === 'LENIGHEID'
                          ? 'border-purple-400 hover:bg-purple-50'
                          : ''
                      } ${
                        selectedSubtopic === subtopic && subtopic === 'B+'
                          ? 'bg-gradient-to-br from-yellow-400 to-yellow-600 text-white'
                          : selectedSubtopic === subtopic && subtopic === 'B-'
                          ? 'bg-gradient-to-br from-gray-400 to-gray-600 text-white'
                          : selectedSubtopic === subtopic && subtopic === 'UITHOUDING'
                          ? 'bg-gradient-to-br from-red-400 to-red-600 text-white'
                          : selectedSubtopic === subtopic && subtopic === 'KRACHT'
                          ? 'bg-gradient-to-br from-blue-400 to-blue-600 text-white'
                          : selectedSubtopic === subtopic && subtopic === 'SNELHEID'
                          ? 'bg-gradient-to-br from-green-400 to-green-600 text-white'
                          : selectedSubtopic === subtopic && subtopic === 'LENIGHEID'
                          ? 'bg-gradient-to-br from-purple-400 to-purple-600 text-white'
                          : ''
                      }`}
                      onClick={() => setSelectedSubtopic(subtopic)}
                    >
                      {/* Subtiele terug-pijl in linkerbovenhoek */}
                      <ArrowLeft className="absolute top-2 left-2 h-3 w-3 opacity-50" />
                      <span className="text-lg font-bold">{subtopic}</span>
                      <span className="text-xs opacity-80">
                        {subtopic === 'B+' ? 'Aanvallend' 
                         : subtopic === 'B-' ? 'Verdedigend'
                         : subtopic === 'UITHOUDING' ? 'Cardio & Endurance'
                         : subtopic === 'KRACHT' ? 'Strength & Power'
                         : subtopic === 'SNELHEID' ? 'Speed & Agility'
                         : subtopic === 'LENIGHEID' ? 'Flexibility'
                         : subtopic}
                      </span>
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Search - only show when subtopic is selected or topic doesn't have subtopics */}
            {(!hasSubtopics(key) || selectedSubtopic) && (
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder={`Zoek in ${config.display}${selectedSubtopic ? ` - ${selectedSubtopic}` : ''}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            )}

            {/* Elements - only show when subtopic is selected or topic doesn't have subtopics */}
            {(!hasSubtopics(key) || selectedSubtopic) && filteredElements.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-xl font-semibold border-b pb-2">
                  {selectedSubtopic || 'Alle elementen'} ({filteredElements.length} elementen)
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredElements.map((element) => (
                    <Card 
                      key={element.id} 
                      className={`${getElementCardStyle(element)} relative`}
                      onClick={() => handleElementClick(element)}
                    >
                      <CardHeader className="pb-3">
                        {/* Subtiele terug-pijl in linkerbovenhoek */}
                        <ArrowLeft className="absolute top-3 left-3 h-3 w-3 opacity-40 text-gray-600" />
                        <CardTitle className="text-sm font-medium pl-6">
                          {element.name}
                        </CardTitle>
                        <div className="flex items-center gap-2">
                          <Badge className={`text-xs ${getElementBadgeStyle(element)}`}>
                            {element.theme}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {element.progressions.length} niveaus
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-1">
                          {[...Array(6)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-3 w-3 ${
                                i < element.progressions.length 
                                  ? 'fill-yellow-400 text-yellow-400' 
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {(!hasSubtopics(key) || selectedSubtopic) && filteredElements.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                {searchQuery ? `Geen elementen gevonden voor "${searchQuery}"` : selectedSubtopic ? `Geen elementen beschikbaar voor ${selectedSubtopic}` : `Kies eerst een categorie (B+ of B-)`}
              </div>
            )}


          </TabsContent>
        ))}
      </Tabs>

      {/* Element Detail Dialog */}
      <Dialog open={showElementDialog} onOpenChange={setShowElementDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 relative">
              {selectedElement && (
                <>
                  <ArrowLeft className="absolute left-0 h-4 w-4 opacity-50 text-gray-600" />
                  {(() => {
                    const IconComponent = topicConfig[selectedElement.topic as keyof typeof topicConfig]?.icon || Target;
                    return <IconComponent className="h-6 w-6 ml-6" />;
                  })()}
                  {selectedElement.name}
                </>
              )}
            </DialogTitle>
          </DialogHeader>
          
          {selectedElement && (
            <div className="space-y-6">
              {/* Element Info */}
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">{selectedElement.topic}</Badge>
                <Badge variant="outline">{selectedElement.subtopic}</Badge>
                <Badge variant="outline">{selectedElement.theme}</Badge>
              </div>

              {/* Level Selector */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <span className="font-medium">Selecteer niveau:</span>
                  <Select value={selectedLevel.toString()} onValueChange={(value) => setSelectedLevel(parseInt(value))}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedElement.progressions.map((progression) => (
                        <SelectItem key={progression.level} value={progression.level.toString()}>
                          Niveau {progression.level}: {progression.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Progressions */}
              {renderProgressions(selectedElement.progressions)}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}