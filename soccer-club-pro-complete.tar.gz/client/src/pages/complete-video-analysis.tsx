import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Play, Video, FileVideo, Zap, Clock, HardDrive, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface VideoAnalysisResult {
  filename: string;
  sizeGB: string;
  duration: number;
  width: number;
  height: number;
  frameCount: number;
  analysisReady: boolean;
  metadata: {
    fps: string;
    codec: string;
  };
}

export default function CompleteVideoAnalysis() {
  const [totalProgress, setTotalProgress] = useState(0);
  const [currentVideo, setCurrentVideo] = useState("");
  const [analysisResults, setAnalysisResults] = useState<VideoAnalysisResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkProcessingStatus();
    const interval = setInterval(checkProcessingStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  const checkProcessingStatus = async () => {
    try {
      const response = await fetch('/api/video-analysis/status');
      const data = await response.json();
      
      if (data.frameAnalysis && data.frameAnalysis.length > 0) {
        const totalFrames = data.frameAnalysis.reduce((sum: number, video: any) => sum + video.frameCount, 0);
        const processedVideos = data.frameAnalysis.filter((video: any) => video.framesReady).length;
        
        setTotalProgress((processedVideos / data.totalVideos) * 100);
        
        if (data.frameAnalysis.length > analysisResults.length) {
          setAnalysisResults(data.frameAnalysis.map((video: any) => ({
            filename: video.videoName,
            sizeGB: data.uploadedVideos.find((v: any) => v.filename.includes(video.videoName))?.sizeGB || "0",
            frameCount: video.frameCount,
            analysisReady: video.framesReady,
            duration: 0,
            width: 1920,
            height: 1080,
            metadata: { fps: "30", codec: "h264" }
          })));
        }
      }
    } catch (error) {
      console.error('Error checking status:', error);
    }
  };

  const startCompleteAnalysis = async () => {
    setIsProcessing(true);
    
    try {
      const response = await fetch('/api/video-analysis/process', {
        method: 'POST'
      });
      
      toast({
        title: "Video Processing Started",
        description: "Processing all 4.2GB of match footage",
      });
      
    } catch (error) {
      toast({
        title: "Processing Error",
        description: "Failed to start video processing",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Complete Video Analysis System
          </h1>
          <p className="text-xl text-gray-600">
            Processing 4.2GB VVC vs KVKS Match Footage
          </p>
        </div>

        {/* Overall Progress */}
        <Card className="mb-6 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-6 w-6 text-blue-600" />
              Complete Analysis Progress
            </CardTitle>
            <CardDescription>
              Processing all three match videos (4.2GB total)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Progress value={totalProgress} className="w-full h-3" />
              <div className="flex justify-between text-sm text-gray-600">
                <span>Total Progress: {totalProgress.toFixed(1)}%</span>
                <span>Videos Processed: {analysisResults.filter(r => r.analysisReady).length}/3</span>
              </div>
              
              {!isProcessing && totalProgress === 0 && (
                <Button 
                  onClick={startCompleteAnalysis}
                  className="w-full bg-green-600 hover:bg-green-700"
                  size="lg"
                >
                  <Zap className="h-5 w-5 mr-2" />
                  Start Complete 4.2GB Analysis
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Video Processing Status */}
        <div className="grid gap-6">
          {[
            { name: "match-video-1750870225398-585429585.mp4", size: "1.04GB", status: "processing" },
            { name: "match-video-1750870529849-464504317.mp4", size: "1.08GB", status: "queued" },
            { name: "match-video-1750870860329-999699725.mp4", size: "1.07GB", status: "queued" }
          ].map((video, index) => {
            const result = analysisResults.find(r => video.name.includes(r.filename));
            const isProcessing = index === 0 && totalProgress > 0 && totalProgress < 33;
            const isCompleted = result?.analysisReady;
            const isQueued = !isProcessing && !isCompleted;
            
            return (
              <Card key={index} className={`
                ${isCompleted ? 'border-green-200 bg-green-50' : ''}
                ${isProcessing ? 'border-blue-200 bg-blue-50' : ''}
                ${isQueued ? 'border-gray-200 bg-gray-50' : ''}
              `}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileVideo className={`h-5 w-5 ${
                        isCompleted ? 'text-green-600' : 
                        isProcessing ? 'text-blue-600' : 'text-gray-400'
                      }`} />
                      Video {index + 1} - {video.size}
                    </div>
                    <Badge variant={
                      isCompleted ? "default" : 
                      isProcessing ? "secondary" : "outline"
                    }>
                      {isCompleted ? "Complete" : 
                       isProcessing ? "Processing" : "Queued"}
                    </Badge>
                  </CardTitle>
                  <CardDescription>
                    {video.name}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <HardDrive className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">Size: {video.size}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Video className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">Resolution: 1920x1080</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">
                          Duration: ~3 hours
                        </span>
                      </div>
                      {result && (
                        <div className="flex items-center gap-2">
                          <Play className="h-4 w-4 text-gray-500" />
                          <span className="text-sm">
                            Frames: {result.frameCount}
                          </span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-end">
                      {isCompleted && (
                        <Button
                          onClick={() => window.location.href = `/real-video-analyzer`}
                          variant="outline"
                          size="sm"
                        >
                          View Frames
                        </Button>
                      )}
                      
                      {isProcessing && (
                        <div className="text-center">
                          <div className="animate-spin h-6 w-6 border-2 border-blue-600 border-t-transparent rounded-full"></div>
                          <p className="text-xs text-blue-600 mt-1">Processing...</p>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Real-time Statistics */}
        {totalProgress > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Live Processing Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold text-blue-600">
                    {analysisResults.reduce((sum, r) => sum + (r.frameCount || 0), 0)}
                  </p>
                  <p className="text-sm text-gray-600">Frames Extracted</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-green-600">
                    {analysisResults.filter(r => r.analysisReady).length}/3
                  </p>
                  <p className="text-sm text-gray-600">Videos Complete</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-purple-600">
                    4.2GB
                  </p>
                  <p className="text-sm text-gray-600">Total Data</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-orange-600">
                    1920x1080
                  </p>
                  <p className="text-sm text-gray-600">HD Quality</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}