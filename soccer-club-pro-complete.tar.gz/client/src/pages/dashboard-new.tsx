import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CalendarDays, Users, Trophy, Activity, User, TrendingUp, MapPin, CreditCard, CheckSquare, PlusCircle, Video, BarChart3, Settings, Database, Shield, UserPlus, Building, Monitor, PlayCircle, Download } from "lucide-react";
import { Link, useLocation } from "wouter";

interface DashboardStats {
  totalPlayers: number;
  activeTeams: number;
  upcomingMatches: number;
  recentTrainings: number;
}

interface ClubInfo {
  id: number;
  name: string;
  fullName?: string;
  logo?: string;
}

interface DashboardTile {
  title: string;
  description: string;
  icon: React.ReactNode;
  href: string;
  color: string;
}

interface DashboardSection {
  title: string;
  description: string;
  color: string;
  tiles: DashboardTile[];
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/stats/dashboard"],
  });

  // Fetch club info for logo
  const { data: clubInfo } = useQuery<ClubInfo>({
    queryKey: ['/api/club/info'],
  });

  const dashboardSections: DashboardSection[] = [
    {
      title: "CLUB ADMIN DASHBOARD",
      description: "Algemeen clubbeheer en administratie",
      color: "bg-blue-500",
      tiles: [
        { title: "Club Information", description: "Clubgegevens beheren", icon: <Building className="h-6 w-6" />, href: "/club-info", color: "border-blue-200 hover:border-blue-400" },
        { title: "Spelers Database", description: "Spelersinformatie", icon: <Users className="h-6 w-6" />, href: "/players-database", color: "border-blue-200 hover:border-blue-400" },
        { title: "Coaches", description: "Trainer beheer", icon: <User className="h-6 w-6" />, href: "/coaches", color: "border-blue-200 hover:border-blue-400" },
        { title: "Pitches", description: "Velden beheren", icon: <MapPin className="h-6 w-6" />, href: "/pitches", color: "border-blue-200 hover:border-blue-400" },
        { title: "Parents", description: "Ouder informatie", icon: <Users className="h-6 w-6" />, href: "/parents", color: "border-blue-200 hover:border-blue-400" },
        { title: "Uitnodigingen", description: "Gebruikers uitnodigen", icon: <UserPlus className="h-6 w-6" />, href: "/invitations", color: "border-blue-200 hover:border-blue-400" },
        { title: "Payments", description: "Betalingen beheren", icon: <CreditCard className="h-6 w-6" />, href: "/payments", color: "border-blue-200 hover:border-blue-400" },
        { title: "Logo Organisatie", description: "Club branding", icon: <Monitor className="h-6 w-6" />, href: "/logo-organization", color: "border-blue-200 hover:border-blue-400" },
        { title: "Settings", description: "Systeeminstellingen", icon: <Settings className="h-6 w-6" />, href: "/settings", color: "border-blue-200 hover:border-blue-400" },
        { title: "Database Admin", description: "Database beheer", icon: <Database className="h-6 w-6" />, href: "/admin/database", color: "border-blue-200 hover:border-blue-400" },
        { title: "Scout Database", description: "Scout informatie", icon: <Activity className="h-6 w-6" />, href: "/scout-database", color: "border-blue-200 hover:border-blue-400" },
        { title: "SaaS Modules", description: "Module beheer", icon: <Shield className="h-6 w-6" />, href: "/subscription", color: "border-blue-200 hover:border-blue-400" },
        { title: "Algemene Voorwaarden", description: "Terms & Conditions", icon: <CheckSquare className="h-6 w-6" />, href: "/terms", color: "border-blue-200 hover:border-blue-400" }
      ]
    },
    {
      title: "TEAM DASHBOARD",
      description: "Team management en organisatie",
      color: "bg-green-500",
      tiles: [
        { title: "Teams", description: "Team overzicht", icon: <Users className="h-6 w-6" />, href: "/teams-management", color: "border-green-200 hover:border-green-400" },
        { title: "Team Weekoverzicht", description: "Wekelijkse planning", icon: <CalendarDays className="h-6 w-6" />, href: "/team-week-overview", color: "border-green-200 hover:border-green-400" },
        { title: "Team Dashboard", description: "Team activiteiten", icon: <Monitor className="h-6 w-6" />, href: "/team-overview", color: "border-green-200 hover:border-green-400" },
        { title: "Selectiemodule", description: "Team selectie", icon: <CheckSquare className="h-6 w-6" />, href: "/team-selection", color: "border-green-200 hover:border-green-400" },
        { title: "Jaarplanning", description: "Seizoensplanning", icon: <CalendarDays className="h-6 w-6" />, href: "/jaarplanning", color: "border-green-200 hover:border-green-400" },
        { title: "IADATABANK", description: "Training database", icon: <Database className="h-6 w-6" />, href: "/iadatabank", color: "border-green-200 hover:border-green-400" },
        { title: "Team Assignments", description: "Team toewijzingen", icon: <Users className="h-6 w-6" />, href: "/team-assignments", color: "border-green-200 hover:border-green-400" }
      ]
    },
    {
      title: "TRAINING DASHBOARD",
      description: "Training planning en beheer",
      color: "bg-purple-500",
      tiles: [
        { title: "Trainings", description: "Training overzicht", icon: <Activity className="h-6 w-6" />, href: "/training", color: "border-purple-200 hover:border-purple-400" },
        { title: "Trainingsessie Maker", description: "Sessie planning", icon: <PlusCircle className="h-6 w-6" />, href: "/training-session-maker", color: "border-purple-200 hover:border-purple-400" },
        { title: "Moderne Sessie Maker", description: "Geavanceerde planning", icon: <PlayCircle className="h-6 w-6" />, href: "/modern-training-session-maker", color: "border-purple-200 hover:border-purple-400" },
        { title: "Training Import", description: "Trainingen importeren", icon: <Download className="h-6 w-6" />, href: "/training-import", color: "border-purple-200 hover:border-purple-400" }
      ]
    },

  ];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium bg-gray-200 h-4 w-20 rounded"></CardTitle>
                <div className="h-4 w-4 bg-gray-200 rounded"></div>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-200 h-8 w-16 rounded mb-1"></div>
                <div className="bg-gray-200 h-3 w-24 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center space-x-8">
        {clubInfo?.logo ? (
          <img 
            src={clubInfo.logo} 
            alt="Club Logo" 
            className="h-32 w-32 object-contain rounded-full bg-white border-4 border-gray-200 shadow-xl"
          />
        ) : (
          <div className="rounded-full bg-primary h-32 w-32 flex items-center justify-center border-4 border-gray-200 shadow-xl">
            <i className="ri-football-line text-white text-5xl"></i>
          </div>
        )}
        <div>
          <h1 className="text-5xl font-bold tracking-tight text-gray-800">DASHBOARD</h1>
          <p className="text-muted-foreground text-xl mt-2">Welkom bij uw Soccer Club Pro management systeem</p>
        </div>
      </div>

      {/* Stats Cards - Hidden for cleaner look */}
      {/* <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        ... stats cards content hidden ...
      </div> */}

      {/* Dashboard Sections */}
      {dashboardSections.map((section, index) => (
        <div key={index} className="space-y-4">
          <div className="flex items-center gap-3">
            <div className={`w-1 h-8 ${section.color} rounded`}></div>
            <div>
              <h2 className="text-xl font-semibold">{section.title}</h2>
              <p className="text-sm text-muted-foreground">{section.description}</p>
            </div>
          </div>
          
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {section.tiles.map((tile, tileIndex) => (
              <Card 
                key={tileIndex} 
                className={`cursor-pointer hover:shadow-lg transition-all duration-200 border-2 ${tile.color}`}
                onClick={() => setLocation(tile.href)}
              >
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    {tile.icon}
                    {tile.title}
                  </CardTitle>
                  <CardDescription className="text-xs">
                    {tile.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}