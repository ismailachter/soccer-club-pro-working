import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { Search, Plus, Edit, Star, Target, Calendar, Phone, Mail, User, Upload, Loader2, ArrowLeft, Trash2 } from "lucide-react";
import { Link } from "wouter";
// Scout database interface matching our database schema
interface ScoutDatabase {
  id: number;
  firstName: string;
  lastName: string;
  dateOfBirth?: string | null;
  nationality?: string | null;
  currentClub?: string | null;
  position?: string | null;
  positionText?: string | null;
  email?: string | null;
  phone?: string | null;
  address?: string | null;
  scoutPriority: 'low' | 'medium' | 'high' | 'urgent';
  scoutStatus: 'prospect' | 'contacted' | 'interested' | 'declined' | 'signed';
  scoutNotes?: string | null;
  overallRating: number;
  technicalSkills: number;
  physicalAttributes: number;
  mentalStrength: number;
  potential: number;
  height?: number | null;
  weight?: number | null;
  preferredFoot: 'left' | 'right' | 'both';
  contractStatus?: string | null;
  marketValue: number;
  videoLinks?: string | null;
  scoutedBy?: string | null;
  scoutedAt?: string | null;
  createdAt: string;
  updatedAt: string;
}
import { useAuth } from "@/hooks/useAuth";

// Form schema for scout data
const scoutFormSchema = z.object({
  firstName: z.string().min(1, "Voornaam is verplicht"),
  lastName: z.string().min(1, "Achternaam is verplicht"),
  dateOfBirth: z.string().optional(),
  nationality: z.string().optional(),
  currentClub: z.string().optional(),
  position: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().optional(),
  address: z.string().optional(),
  scoutPriority: z.enum(["low", "medium", "high", "urgent"]),
  scoutStatus: z.enum(["prospect", "contacted", "interested", "declined", "signed"]),
  scoutNotes: z.string().optional(),
  overallRating: z.number().min(0).max(10),
  technicalSkills: z.number().min(0).max(10),
  physicalAttributes: z.number().min(0).max(10),
  mentalStrength: z.number().min(0).max(10),
  potential: z.number().min(0).max(10),
  height: z.number().min(0),
  weight: z.number().min(0),
  preferredFoot: z.enum(["left", "right", "both"]),
  contractStatus: z.string(),
  marketValue: z.number().min(0),
  videoLinks: z.string().optional(),

});

type ScoutFormData = z.infer<typeof scoutFormSchema>;

function ScoutCard({ scout, onEdit, onDelete }: { scout: ScoutDatabase; onEdit: (scout: ScoutDatabase) => void; onDelete: (scout: ScoutDatabase) => void }) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "bg-red-500 text-white";
      case "high": return "bg-orange-500 text-white";
      case "medium": return "bg-yellow-500 text-black";
      case "low": return "bg-gray-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "signed": return "bg-green-500 text-white";
      case "interested": return "bg-blue-500 text-white";
      case "contacted": return "bg-purple-500 text-white";
      case "declined": return "bg-red-500 text-white";
      case "prospect": return "bg-gray-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg font-semibold">
              {scout.firstName} {scout.lastName}
            </CardTitle>
            <p className="text-sm text-muted-foreground">{scout.positionText || scout.position} • {scout.currentClub}</p>
          </div>
          <div className="flex gap-2">
            <Badge className={getPriorityColor(scout.scoutPriority)}>
              {scout.scoutPriority}
            </Badge>
            <Badge className={getStatusColor(scout.scoutStatus)}>
              {scout.scoutStatus}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {scout.overallRating && (
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-yellow-500" />
              <span className="text-sm">Overall: {scout.overallRating}/10</span>
            </div>
          )}
          {scout.nationality && (
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-blue-500" />
              <span className="text-sm">{scout.nationality}</span>
            </div>
          )}
          {scout.scoutedAt && (
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-green-500" />
              <span className="text-sm">Gescout op: {new Date(scout.scoutedAt).toLocaleDateString()}</span>
            </div>
          )}
          {scout.scoutNotes && (
            <p className="text-sm text-muted-foreground line-clamp-2">{scout.scoutNotes}</p>
          )}
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" size="sm" onClick={() => onEdit(scout)}>
            <Edit className="h-4 w-4 mr-2" />
            Bewerken
          </Button>
          <Button variant="destructive" size="sm" onClick={() => onDelete(scout)}>
            <Trash2 className="h-4 w-4 mr-2" />
            Verwijderen
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function ScoutForm({ scout, onSubmit, onClose }: {
  scout?: ScoutDatabase;
  onSubmit: (data: ScoutFormData) => void;
  onClose: () => void;
}) {
  const form = useForm<ScoutFormData>({
    resolver: zodResolver(scoutFormSchema),
    defaultValues: {
      firstName: scout?.firstName ?? "",
      lastName: scout?.lastName ?? "",
      dateOfBirth: scout?.dateOfBirth ? new Date(scout.dateOfBirth).toISOString().split('T')[0] : "",
      nationality: scout?.nationality ?? "",
      currentClub: scout?.currentClub ?? "",
      position: (scout?.positionText || scout?.position) ?? "",
      email: scout?.email ?? "",
      phone: scout?.phone ?? "",
      address: scout?.address ?? "",
      scoutPriority: (scout?.scoutPriority as "low" | "medium" | "high" | "urgent") ?? "medium",
      scoutStatus: (scout?.scoutStatus as "prospect" | "contacted" | "interested" | "declined" | "signed") ?? "prospect",
      scoutNotes: scout?.scoutNotes ?? "",
      overallRating: scout?.overallRating ?? 0,
      technicalSkills: scout?.technicalSkills ?? 0,
      physicalAttributes: scout?.physicalAttributes ?? 0,
      mentalStrength: scout?.mentalStrength ?? 0,
      potential: scout?.potential ?? 0,
      height: scout?.height ?? 0,
      weight: scout?.weight ?? 0,
      preferredFoot: (scout?.preferredFoot as "left" | "right" | "both") ?? "right",
      contractStatus: scout?.contractStatus ?? "",
      marketValue: scout?.marketValue ?? 0,
      videoLinks: scout?.videoLinks ?? "",

    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="firstName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Voornaam *</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="lastName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Achternaam *</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="dateOfBirth"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Geboortedatum</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="nationality"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nationaliteit</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="currentClub"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Huidige Club</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="position"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Positie</FormLabel>
                <FormControl>
                  <Select value={field.value || ""} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer positie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="goalkeeper">Goalkeeper</SelectItem>
                      <SelectItem value="defender">Verdediger</SelectItem>
                      <SelectItem value="midfielder">Middenvelder</SelectItem>
                      <SelectItem value="forward">Aanvaller</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input type="email" {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Telefoon</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="address"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Adres</FormLabel>
              <FormControl>
                <Textarea {...field} />
              </FormControl>
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="scoutPriority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Scout Prioriteit</FormLabel>
                <FormControl>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Laag</SelectItem>
                      <SelectItem value="medium">Gemiddeld</SelectItem>
                      <SelectItem value="high">Hoog</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="scoutStatus"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Scout Status</FormLabel>
                <FormControl>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="prospect">Prospect</SelectItem>
                      <SelectItem value="contacted">Gecontacteerd</SelectItem>
                      <SelectItem value="interested">Geïnteresseerd</SelectItem>
                      <SelectItem value="declined">Afgewezen</SelectItem>
                      <SelectItem value="signed">Getekend</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-5 gap-4">
          <FormField
            control={form.control}
            name="overallRating"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Overall (0-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="10" 
                    value={field.value || 0}
                    onChange={(e) => field.onChange(Number(e.target.value) || 0)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="technicalSkills"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Techniek (0-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="10" 
                    value={field.value || 0}
                    onChange={(e) => field.onChange(Number(e.target.value) || 0)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="physicalAttributes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Fysiek (0-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="10" 
                    value={field.value || 0}
                    onChange={(e) => field.onChange(Number(e.target.value) || 0)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="mentalStrength"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Mentaal (0-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="10" 
                    value={field.value || 0}
                    onChange={(e) => field.onChange(Number(e.target.value) || 0)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="potential"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Potentieel (0-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="10" 
                    value={field.value || 0}
                    onChange={(e) => field.onChange(Number(e.target.value) || 0)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="height"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Lengte (cm)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0"
                    value={field.value || 0}
                    onChange={(e) => field.onChange(Number(e.target.value) || 0)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="weight"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Gewicht (kg)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0"
                    value={field.value || 0}
                    onChange={(e) => field.onChange(Number(e.target.value) || 0)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="preferredFoot"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Voorkeursvoet</FormLabel>
                <FormControl>
                  <Select value={field.value || ""} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer voet" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="left">Links</SelectItem>
                      <SelectItem value="right">Rechts</SelectItem>
                      <SelectItem value="both">Beide</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="contractStatus"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contract Status</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="marketValue"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Marktwaarde (€)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0"
                    value={field.value || 0}
                    onChange={(e) => field.onChange(Number(e.target.value) || 0)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="videoLinks"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Video Links</FormLabel>
              <FormControl>
                <Textarea placeholder="URL's gescheiden door nieuwe regels" {...field} />
              </FormControl>
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="nextContactDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Volgende Contact Datum</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="scoutNotes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Scout Notities</FormLabel>
              <FormControl>
                <Textarea {...field} />
              </FormControl>
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onClose}>
            Annuleren
          </Button>
          <Button type="submit">
            {scout ? "Bijwerken" : "Toevoegen"}
          </Button>
        </div>
      </form>
    </Form>
  );
}

export default function ScoutDatabase() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedScout, setSelectedScout] = useState<ScoutDatabase | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [filters, setFilters] = useState({
    priority: "",
    status: "",
    position: "",
  });
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { isViewer, canEdit } = useAuth();

  const { data: scoutsData = [], isLoading } = useQuery<ScoutDatabase[]>({
    queryKey: ["/api/scout-database"],
  });

  // Fetch players from Scouting team (team ID 4)
  const { data: scoutingPlayers = [] } = useQuery({
    queryKey: ["/api/players"],
    select: (data) => data.filter((player: any) => player.teamId === 4),
  });

  const createScoutMutation = useMutation({
    mutationFn: async (scoutData: ScoutFormData) => {
      console.log('Creating scout with data:', scoutData);
      const response = await apiRequest("/api/scout-database", {
        method: "POST",
        body: JSON.stringify(scoutData),
      });
      return response;
    },
    onSuccess: (data) => {
      console.log('Scout created successfully:', data);
      toast({
        title: "Scout toegevoegd",
        description: "De scout is succesvol toegevoegd aan de database.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/scout-database"] });
      setIsFormOpen(false);
      setSelectedScout(null);
    },
    onError: (error: any) => {
      console.error('Failed to create scout:', error);
      toast({
        title: "Fout bij toevoegen",
        description: error.message || "Er is een fout opgetreden bij het toevoegen van de scout.",
        variant: "destructive",
      });
    },
  });

  const updateScoutMutation = useMutation({
    mutationFn: async ({ id, ...scoutData }: ScoutFormData & { id: number }) => {
      console.log('Updating scout with data:', { id, ...scoutData });
      const response = await apiRequest(`/api/scout-database/${id}`, {
        method: "PATCH",
        body: JSON.stringify(scoutData),
      });
      return response;
    },
    onSuccess: (data) => {
      console.log('Scout updated successfully:', data);
      toast({
        title: "Scout bijgewerkt",
        description: "De scout gegevens zijn succesvol bijgewerkt.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/scout-database"] });
      setIsFormOpen(false);
      setSelectedScout(null);
    },
    onError: (error: any) => {
      console.error('Failed to update scout:', error);
      toast({
        title: "Fout bij bijwerken",
        description: error.message || "Er is een fout opgetreden bij het bijwerken van de scout.",
        variant: "destructive",
      });
    },
  });

  // Delete scout mutation
  const deleteScoutMutation = useMutation({
    mutationFn: async (scoutId: number) => {
      const response = await apiRequest(`/api/scout-database/${scoutId}`, {
        method: 'DELETE',
      });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Scout verwijderd",
        description: "De scout is succesvol verwijderd uit de database.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/scout-database"] });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij verwijderen",
        description: error.message || "Er is een fout opgetreden bij het verwijderen van de scout.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: ScoutFormData) => {
    console.log('Form submitted with data:', data);
    try {
      if (selectedScout) {
        updateScoutMutation.mutate({ ...data, id: selectedScout.id });
      } else {
        createScoutMutation.mutate(data);
      }
    } catch (error) {
      console.error('Submit error:', error);
      toast({
        title: "Fout bij verzenden",
        description: "Er is een fout opgetreden bij het verzenden van het formulier.",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (scout: ScoutDatabase) => {
    setSelectedScout(scout);
    setIsFormOpen(true);
  };

  const handleDelete = (scout: ScoutDatabase) => {
    // Dubbele bevestiging voor verwijderen
    const firstConfirm = window.confirm(
      `Weet je zeker dat je ${scout.firstName} ${scout.lastName} wilt verwijderen uit de database?`
    );
    
    if (firstConfirm) {
      const secondConfirm = window.confirm(
        `LET OP: Deze actie kan niet ongedaan gemaakt worden!\n\nKlik nogmaals op OK om ${scout.firstName} ${scout.lastName} definitief te verwijderen.`
      );
      
      if (secondConfirm) {
        deleteScoutMutation.mutate(scout.id);
      }
    }
  };

  const handleAddNew = () => {
    setSelectedScout(null);
    setIsFormOpen(true);
  };

  const handleBulkUpload = async () => {
    if (!uploadFile) {
      toast({
        title: "Geen bestand geselecteerd",
        description: "Selecteer eerst een Excel bestand om te uploaden.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    
    try {
      const formData = new FormData();
      formData.append('file', uploadFile);

      const response = await fetch('/api/scout-database/bulk-upload', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Upload succesvol",
          description: `${result.imported} speelsters geïmporteerd uit ${result.sheets.length} tabbladen. ${result.merged} profielen samengevoegd.`,
        });
        
        // Refresh scout data
        queryClient.invalidateQueries({ queryKey: ["/api/scout-database"] });
        
        // Close dialog and reset state
        setIsBulkUploadOpen(false);
        setUploadFile(null);
      } else {
        throw new Error(result.error || 'Upload failed');
      }
    } catch (error) {
      console.error('Bulk upload error:', error);
      toast({
        title: "Upload mislukt",
        description: "Er is een fout opgetreden bij het uploaden van het bestand.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  // Combine scouts from scout database and scouting team players
  const allScouts = [...scoutsData, ...scoutingPlayers.map((player: any) => ({
    id: `player-${player.id}`,
    playerId: player.id,
    firstName: player.firstName,
    lastName: player.lastName,
    email: player.email,
    phone: player.phone,
    dateOfBirth: player.dateOfBirth,
    nationality: player.nationality,
    position: player.position,
    currentClub: 'VVC Brasschaat',
    scoutPriority: 'medium',
    scoutStatus: 'internal',
    scoutNotes: 'Speler van Scouting team',
    playerCode: player.playerCode || `P${String(player.id).padStart(4, '0')}`,
  }))];

  const filteredScouts = allScouts.filter((scout) => {
    const matchesSearch = 
      (scout.firstName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (scout.lastName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (scout.currentClub || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (scout.nationality || '').toLowerCase().includes(searchTerm.toLowerCase());

    const matchesPriority = !filters.priority || scout.scoutPriority === filters.priority;
    const matchesStatus = !filters.status || scout.scoutStatus === filters.status;
    const matchesPosition = !filters.position || scout.position === filters.position;

    return matchesSearch && matchesPriority && matchesStatus && matchesPosition;
  });

  const stats = {
    total: scoutsData.length,
    urgent: scoutsData.filter(s => s.scoutPriority === "urgent").length,
    high: scoutsData.filter(s => s.scoutPriority === "high").length,
    interested: scoutsData.filter(s => s.scoutStatus === "interested").length,
    signed: scoutsData.filter(s => s.scoutStatus === "signed").length,
  };

  if (isLoading) {
    return <div className="p-6">Loading...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Terug
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Database Scouting</h1>
            <p className="text-muted-foreground">
              Beheer je scouting database met spelers van binnen en buiten de club
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline"
            onClick={() => setIsBulkUploadOpen(true)}
          >
            <Upload className="h-4 w-4 mr-2" />
            Excel Import
          </Button>
          <Button onClick={handleAddNew}>
            <Plus className="h-4 w-4 mr-2" />
            Nieuwe Scout
          </Button>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="text-sm text-muted-foreground">Totaal Scouts</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-600">{stats.urgent}</div>
            <div className="text-sm text-muted-foreground">Urgent</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-orange-600">{stats.high}</div>
            <div className="text-sm text-muted-foreground">Hoge Prioriteit</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-600">{stats.interested}</div>
            <div className="text-sm text-muted-foreground">Geïnteresseerd</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">{stats.signed}</div>
            <div className="text-sm text-muted-foreground">Getekend</div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Zoek scouts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filters.priority} onValueChange={(value) => setFilters(prev => ({ ...prev, priority: value === "all" ? "" : value }))}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter op prioriteit" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle prioriteiten</SelectItem>
            <SelectItem value="urgent">Urgent</SelectItem>
            <SelectItem value="high">Hoog</SelectItem>
            <SelectItem value="medium">Gemiddeld</SelectItem>
            <SelectItem value="low">Laag</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filters.status} onValueChange={(value) => setFilters(prev => ({ ...prev, status: value === "all" ? "" : value }))}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter op status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle statussen</SelectItem>
            <SelectItem value="prospect">Prospect</SelectItem>
            <SelectItem value="contacted">Gecontacteerd</SelectItem>
            <SelectItem value="interested">Geïnteresseerd</SelectItem>
            <SelectItem value="declined">Afgewezen</SelectItem>
            <SelectItem value="signed">Getekend</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filters.position} onValueChange={(value) => setFilters(prev => ({ ...prev, position: value === "all" ? "" : value }))}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter op positie" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle posities</SelectItem>
            <SelectItem value="goalkeeper">Goalkeeper</SelectItem>
            <SelectItem value="defender">Verdediger</SelectItem>
            <SelectItem value="midfielder">Middenvelder</SelectItem>
            <SelectItem value="forward">Aanvaller</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Scout Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredScouts.map((scout) => (
          <ScoutCard
            key={scout.id}
            scout={scout}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        ))}
      </div>

      {filteredScouts.length === 0 && (
        <div className="text-center py-12">
          <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Geen scouts gevonden</h3>
          <p className="text-gray-500">Begin met het toevoegen van spelers aan je scout database.</p>
        </div>
      )}

      {/* Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedScout ? "Scout Bewerken" : "Nieuwe Scout Toevoegen"}
            </DialogTitle>
            <DialogDescription>
              {selectedScout ? "Bewerk de scout informatie hieronder." : "Voeg een nieuwe scout toe aan je database."}
            </DialogDescription>
          </DialogHeader>
          <ScoutForm
            scout={selectedScout || undefined}
            onSubmit={handleSubmit}
            onClose={() => setIsFormOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Bulk Upload Dialog */}
      <Dialog open={isBulkUploadOpen} onOpenChange={setIsBulkUploadOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Bulk Upload Scout Database</DialogTitle>
            <DialogDescription>
              Upload een Excel of CSV bestand met speelsters voor de Scout Database
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Upload className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-sm text-gray-600 mb-2">
                Sleep hier uw Excel bestand of klik om te selecteren
              </p>
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                id="scout-bulk-upload"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setUploadFile(file);
                    console.log("Selected file:", file.name);
                  }
                }}
              />
              <label
                htmlFor="scout-bulk-upload"
                className="cursor-pointer bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
              >
                Selecteer Bestand
              </label>
            </div>
            {uploadFile && (
              <div className="text-sm text-green-600 bg-green-50 p-2 rounded">
                Bestand geselecteerd: {uploadFile.name}
              </div>
            )}
            <div className="text-xs text-gray-500">
              Ondersteunde formaten: Excel (.xlsx, .xls) en CSV (.csv)
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsBulkUploadOpen(false)}>
              Annuleren
            </Button>
            <Button 
              onClick={handleBulkUpload}
              disabled={!uploadFile || isUploading}
            >
              {isUploading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Uploaden...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}