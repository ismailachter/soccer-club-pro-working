import { useState, useEffect } from 'react';
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, Target, Users, MapPin, Star, Plus, Edit, Trash2, Eye, Filter, Search, ChevronLeft, ChevronRight, Zap, Brain, Dumbbell, Trophy, ArrowLeft, Video, Heart, FileText, FileSpreadsheet, Monitor, Upload, Copy, ArrowRight, Presentation, RefreshCw as Sync } from "lucide-react";
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO, addWeeks, subWeeks, addMonths, startOfMonth, endOfMonth, eachWeekOfInterval, getWeek } from 'date-fns';
import { nl } from 'date-fns/locale';
import { Link } from 'wouter';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface TrainingSession {
  id: string;
  planId: number;
  week: number;
  session: number;
  date: string;
  time: string;
  duration: number;
  focusArea: string;
  location: string;
  ageGroup: string;
  assignedElements: string[];
  intensity: 'low' | 'medium' | 'high';
  weather: 'indoor' | 'outdoor';
  notes: string;
  status: 'planned' | 'completed' | 'cancelled';
}

export default function ModernJaarplanningFixed() {
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [viewMode, setViewMode] = useState<'day' | 'week' | 'month'>('week');
  const [currentView, setCurrentView] = useState<'list' | 'calendar'>('list');
  const [filterAgeGroup, setFilterAgeGroup] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [showEditPlanDialog, setShowEditPlanDialog] = useState(false);
  const [editingPlan, setEditingPlan] = useState<YearPlan | null>(null);
  const [showEventDialog, setShowEventDialog] = useState(false);
  const [selectedPlanForEvent, setSelectedPlanForEvent] = useState<YearPlan | null>(null);
  const [eventForm, setEventForm] = useState({
    title: '',
    description: '',
    eventType: 'training' as 'training' | 'extra_training' | 'friendly_match' | 'competition_match' | 'stage' | 'tournament' | 'videotraining' | 'teambuilding' | 'other',
    date: '',
    startTime: '',
    duration: 90,
    location: '',
    opponent: '',
    videoUrl: '',
    videoTopic: '',
    teambuildingType: '',
    teambuildingActivity: '',
    maxParticipants: 0,
    costPerPerson: 0,
    intensity: 'matig' as 'laag' | 'matig' | 'hoog' | 'maximaal',
    notes: ''
  });
  const [isCreating, setIsCreating] = useState(false);
  const [newPlanName, setNewPlanName] = useState('');
  const [newPlanDescription, setNewPlanDescription] = useState('');

  const [editPlanData, setEditPlanData] = useState({
    name: '',
    description: '',
    ageGroup: '',
    season: '',
    startDate: '',
    endDate: '',
    sessionsPerWeek: 2,
    trainingDays: [] as string[],
    focusThemes: [] as string[],
    clubId: null as number | null,
    status: 'draft' as 'draft' | 'active' | 'completed'
  });

  const [newSessionData, setNewSessionData] = useState({
    date: format(new Date(), 'yyyy-MM-dd'),
    time: '19:00',
    duration: 90,
    focusArea: '',
    location: 'Hoofdveld',
    ageGroup: '',
    teamId: '',
    intensity: 'medium' as 'low' | 'medium' | 'high',
    notes: '',
    assignedElements: [] as string[]
  });

  // Fetch data
  const { data: yearPlans = [], isLoading: isLoadingPlans } = useQuery({ queryKey: ['/api/year-plans'] });
  const { data: iaElements = [] } = useQuery({ queryKey: ['/api/iadatabank/elements'] });
  const { data: teams = [] } = useQuery({ queryKey: ['/api/teams'] });

  // State for copy dialog
  const [showCopyDialog, setShowCopyDialog] = useState<number | null>(null);
  const [copyFormData, setCopyFormData] = useState({
    name: '',
    ageGroup: '',
    teamId: '',
    season: ''
  });

  // CRUD mutations
  const createYearPlan = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/year-plans', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setIsCreating(false);
      setNewPlanName('');
      setNewPlanDescription('');
      toast({ title: "Jaarplanning aangemaakt", description: "De nieuwe jaarplanning is succesvol aangemaakt." });
    },
    onError: (error: any) => {
      toast({ title: "Fout", description: `Kan jaarplanning niet aanmaken: ${error.message}`, variant: "destructive" });
    }
  });

  const updateYearPlan = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => {
      console.log('Updating year plan:', id, data);
      return apiRequest('PUT', `/api/year-plans/${id}`, data);
    },
    onSuccess: () => {
      // Invalidate all related queries to ensure calendar updates
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      queryClient.invalidateQueries({ queryKey: ['/api/year-plan-sessions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/calendar-events'] });
      setShowEditPlanDialog(false);
      setEditingPlan(null);
      toast({ title: "Jaarplanning bijgewerkt", description: "De jaarplanning en kalender zijn bijgewerkt." });
    },
    onError: (error: any) => {
      console.error('Update error details:', error);
      toast({ title: "Fout", description: `Kan jaarplanning niet bijwerken: ${error.message}`, variant: "destructive" });
    }
  });

  const deleteYearPlan = useMutation({
    mutationFn: (id: number) => 
      fetch(`/api/year-plans/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json',
          'x-confirm-delete': 'true'
        }
      }).then(res => {
        if (!res.ok) throw new Error('Failed to delete');
        return res.json();
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setShowEditPlanDialog(false);
      setEditingPlan(null);
      toast({ title: "Jaarplanning verwijderd", description: "De jaarplanning is permanent verwijderd." });
    },
    onError: (error: any) => {
      console.error('Delete error:', error);
      toast({ title: "Fout", description: `Kan jaarplanning niet verwijderen: ${error.message}`, variant: "destructive" });
    }
  });

  // Event creation mutation
  const createEvent = useMutation({
    mutationFn: async (eventData: any) => {
      const response = await fetch('/api/calendar/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventData)
      });
      if (!response.ok) throw new Error('Failed to create event');
      return response.json();
    },
    onSuccess: () => {
      setShowEventDialog(false);
      resetEventForm();
      toast({ title: "Succes", description: "Event aangemaakt" });
    },
    onError: () => {
      toast({ title: "Fout", description: "Event kon niet worden aangemaakt", variant: "destructive" });
    }
  });

  // Copy Year Plan mutation
  const copyYearPlan = useMutation({
    mutationFn: async ({ planId, copyData }: { planId: number, copyData: any }) => {
      console.log('Copy mutation starting with:', { planId, copyData });
      const response = await fetch(`/api/year-plans/${planId}/copy`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(copyData)
      });
      
      console.log('Copy response status:', response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Copy error response:', errorText);
        throw new Error(`Copy failed: ${response.status} ${response.statusText}`);
      }
      
      const result = await response.json();
      console.log('Copy success result:', result);
      return result;
    },
    onSuccess: (data) => {
      toast({
        title: "Jaarplanning gekopieerd!",
        description: `${data.sessionCount} trainingen succesvol gekopieerd`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setShowCopyDialog(null);
      setCopyFormData({ name: '', ageGroup: '', teamId: '', season: '' });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij kopiëren",
        description: error.message || "Er ging iets mis bij het kopiëren van de jaarplanning",
        variant: "destructive",
      });
    }
  });

  // Update Year Plan Status mutation
  const updateYearPlanStatus = useMutation({
    mutationFn: async ({ planId, status }: { planId: number, status: string }) => {
      return apiRequest(`/api/year-plans/${planId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Status bijgewerkt",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij status update",
        description: error.message || "Er ging iets mis bij het bijwerken van de status",
        variant: "destructive",
      });
    }
  });

  // Copy to Next Season mutation
  const copyToNextSeason = useMutation({
    mutationFn: async (planId: number) => {
      const response = await fetch(`/api/year-plans/${planId}/copy-to-next-season`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'Failed to copy to next season');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      toast({ 
        title: "Seizoen gekopieerd!", 
        description: `${data.sessionCount} trainingen succesvol gekopieerd naar seizoen ${data.newSeason}` 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Fout bij kopiëren", 
        description: error.message, 
        variant: "destructive" 
      });
    }
  });

  // Handler functions
  const handleNewPlan = () => {
    console.log('handleNewPlan clicked');
    setIsCreating(true);
    setNewPlanName('');
    setNewPlanDescription('');
    // Reset editPlanData voor nieuwe jaarplanning
    setEditPlanData({
      name: '',
      description: '',
      ageGroup: 'U13',
      season: '2024-2025',
      startDate: format(new Date(), 'yyyy-MM-dd'),
      endDate: format(addMonths(new Date(), 10), 'yyyy-MM-dd'),
      sessionsPerWeek: 2,
      trainingDays: [],
      focusThemes: [],
      clubId: null,
      teamId: null,
      status: 'draft'
    });
  };

  const handleSaveNewPlan = async () => {
    console.log('handleSaveNewPlan called');
    if (!newPlanName.trim()) {
      toast({ title: "Fout", description: "Voer een naam in voor de jaarplanning", variant: "destructive" });
      return;
    }

    const newPlanData = {
      name: newPlanName,
      description: newPlanDescription,
      ageGroup: editPlanData.ageGroup || 'U13',
      season: editPlanData.season || '2024-2025',
      startDate: editPlanData.startDate || format(new Date(), 'yyyy-MM-dd'),
      endDate: editPlanData.endDate || format(addMonths(new Date(), 10), 'yyyy-MM-dd'),
      sessionsPerWeek: editPlanData.sessionsPerWeek || 2,
      trainingDays: editPlanData.trainingDays.length > 0 ? editPlanData.trainingDays : ['Dinsdag', 'Donderdag'],
      focusThemes: [],
      teamId: editPlanData.teamId || null,
      status: 'draft' as const
    };

    console.log('Creating plan with data:', newPlanData);
    createYearPlan.mutate(newPlanData);
  };

  const handleEditPlan = (plan: any) => {
    setEditingPlan(plan);
    setEditPlanData({
      name: plan.name,
      description: plan.description,
      ageGroup: plan.ageGroup,
      season: plan.season,
      startDate: plan.startDate,
      endDate: plan.endDate,
      sessionsPerWeek: plan.sessionsPerWeek,
      trainingDays: plan.trainingDays || [],
      focusThemes: [],
      clubId: plan.teamId || null,
      teamId: plan.teamId || null,
      status: plan.status || 'draft'
    });
    setShowEditPlanDialog(true);
  };

  const handleSavePlan = async () => {
    if (!editingPlan) return;
    
    try {
      // Validate required fields
      if (!editPlanData.name.trim()) {
        toast({ title: "Fout", description: "Naam is verplicht", variant: "destructive" });
        return;
      }
      
      const updatedData = {
        name: editPlanData.name,
        description: editPlanData.description || '',
        ageGroup: editPlanData.ageGroup,
        season: editPlanData.season,
        startDate: editPlanData.startDate,
        endDate: editPlanData.endDate,
        sessionsPerWeek: editPlanData.sessionsPerWeek,
        trainingDays: editPlanData.trainingDays,
        status: editPlanData.status,
        teamId: editPlanData.teamId
      };
      
      console.log('Saving plan data:', updatedData);
      await updateYearPlan.mutateAsync({ id: editingPlan.id, data: updatedData });
    } catch (error) {
      console.error('Update error:', error);
      toast({ title: "Fout", description: "Kon jaarplanning niet opslaan", variant: "destructive" });
    }
  };

  const handleDeletePlan = async (planId: number) => {
    if (confirm('Weet je zeker dat je deze jaarplanning wilt verwijderen?')) {
      deleteYearPlan.mutate(planId);
    }
  };

  // Event handler functions
  const handlePlanExtras = (plan: YearPlan) => {
    setSelectedPlanForEvent(plan);
    setEventForm(prev => ({
      ...prev,
      date: format(new Date(), 'yyyy-MM-dd') // Set today as default
    }));
    setShowEventDialog(true);
  };

  const handleCopyPlan = (planId: number, originalPlan: YearPlan) => {
    console.log('handleCopyPlan called with:', { planId, originalPlan: originalPlan.name });
    setShowCopyDialog(planId);
    setCopyFormData({
      name: `${originalPlan.name} - Beloften`,
      ageGroup: 'U20',
      teamId: '',
      season: originalPlan.season
    });
    console.log('Copy dialog state set:', { showCopyDialog: planId, copyFormData: copyFormData });
  };

  const handleSubmitCopy = () => {
    console.log('handleSubmitCopy called with:', { showCopyDialog, copyFormData });
    if (!showCopyDialog || !copyFormData.name.trim()) {
      toast({ title: "Fout", description: "Voer een naam in voor de kopie", variant: "destructive" });
      return;
    }

    console.log('Submitting copy mutation...');
    copyYearPlan.mutate({
      planId: showCopyDialog,
      copyData: copyFormData
    });
  };

  const handleStatusChange = (planId: number, newStatus: string) => {
    updateYearPlanStatus.mutate({
      planId,
      status: newStatus
    });
  };

  const handleCopyToNextSeason = (planId: number) => {
    copyToNextSeason.mutate(planId);
  };

  // Read-only sync status check - no changes to jaarplanning
  const syncTeamSchedule = useMutation({
    mutationFn: async (planId: number) => {
      try {
        // Simple status check without modifying jaarplanning
        const response = await fetch(`/api/year-plans/${planId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          }
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch year plan');
        }
        
        const result = await response.json();
        
        if (result && result.teamId) {
          return { 
            status: 'synchronized', 
            message: `Gekoppeld aan team ID: ${result.teamId}`,
            teamName: result.name 
          };
        } else {
          return { 
            status: 'not_synchronized', 
            message: 'Geen team gekoppeld',
            teamName: result.name 
          };
        }
      } catch (error) {
        console.error('Sync check error:', error);
        throw new Error('Status check mislukt');
      }
    },
    onSuccess: (data) => {
      toast({ 
        title: "Sync Status", 
        description: data.message,
        variant: data.status === 'synchronized' ? 'default' : 'destructive'
      });
    },
    onError: (error) => {
      console.error('Sync error:', error);
      toast({ title: "Fout", description: "Kon team schedule niet synchroniseren", variant: "destructive" });
    }
  });

  const handleSyncTeamSchedule = (planId: number) => {
    syncTeamSchedule.mutate(planId);
  };

  const resetEventForm = () => {
    setEventForm({
      title: '',
      description: '',
      eventType: 'training',
      date: '',
      startTime: '',
      duration: 90,
      location: '',
      opponent: '',
      videoUrl: '',
      videoTopic: '',
      teambuildingType: '',
      teambuildingActivity: '',
      maxParticipants: 0,
      costPerPerson: 0,
      intensity: 'matig',
      notes: ''
    });
  };

  const handleEventSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const eventData = {
      ...eventForm,
      yearPlanId: selectedPlanForEvent?.id,
      teamId: selectedPlanForEvent?.teamId,
      eventStatus: 'scheduled' as const
    };
    createEvent.mutate(eventData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg text-white p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Jaarplanning</h1>
              <p className="text-blue-100">Beheer en plan je complete voetbalseizoen</p>
            </div>
          </div>
        </div>

        {/* Jaarplanning Beheer */}
        <Card className="border-0 shadow-lg mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5" />
                  <span>Actieve Jaarplanningen</span>
                </CardTitle>
                <CardDescription>
                  Beheer en bekijk alle trainingsplannen voor dit seizoen
                </CardDescription>
              </div>
              <div className="flex gap-3">
                <Button onClick={handleNewPlan} className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Nieuwe Jaarplanning
                </Button>
                <Link href="/calendar-import">
                  <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                    <Upload className="h-4 w-4 mr-2" />
                    Importeer uw oude planning
                  </Button>
                </Link>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {isLoadingPlans ? (
                <div className="col-span-full text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="text-gray-500 mt-2">Jaarplanningen laden...</p>
                </div>
              ) : (
                <>
                  {/* Nieuwe jaarplanning formulier */}
                  {isCreating && (
                    <div className="col-span-3 mb-6 p-4 bg-gray-50 rounded-lg border">
                      <h3 className="text-lg font-semibold mb-4">Nieuwe Jaarplanning</h3>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="new-plan-name">Naam</Label>
                            <Input
                              id="new-plan-name"
                              placeholder="Naam van de jaarplanning"
                              value={newPlanName}
                              onChange={(e) => setNewPlanName(e.target.value)}
                            />
                          </div>
                          <div>
                            <Label htmlFor="new-plan-age-group">Leeftijdsgroep</Label>
                            <Select value={editPlanData.ageGroup} onValueChange={(value) => setEditPlanData({ ...editPlanData, ageGroup: value })}>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecteer leeftijdsgroep" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="U6">U6</SelectItem>
                                <SelectItem value="U7">U7</SelectItem>
                                <SelectItem value="U8">U8</SelectItem>
                                <SelectItem value="U9">U9</SelectItem>
                                <SelectItem value="U10">U10</SelectItem>
                                <SelectItem value="U11">U11</SelectItem>
                                <SelectItem value="U12">U12</SelectItem>
                                <SelectItem value="U13">U13</SelectItem>
                                <SelectItem value="U15">U15</SelectItem>
                                <SelectItem value="U17">U17</SelectItem>
                                <SelectItem value="U19">U19</SelectItem>
                                <SelectItem value="1e elftal">1e elftal</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        
                        <div>
                          <Label htmlFor="new-plan-description">Beschrijving</Label>
                          <Textarea
                            id="new-plan-description"
                            placeholder="Beschrijving (optioneel)"
                            value={newPlanDescription}
                            onChange={(e) => setNewPlanDescription(e.target.value)}
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="new-plan-team">Team Koppeling</Label>
                          <Select 
                            value={editPlanData.teamId?.toString() || 'none'} 
                            onValueChange={(value) => {
                              console.log('New plan team selection:', value);
                              setEditPlanData({ 
                                ...editPlanData, 
                                teamId: value === 'none' ? null : parseInt(value) 
                              });
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Selecteer team (optioneel)" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">Geen team</SelectItem>
                              {teams && teams.map((team: any) => (
                                <SelectItem key={team.id} value={team.id.toString()}>
                                  {team.name} ({team.ageGroup})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <Label htmlFor="new-plan-season">Seizoen</Label>
                            <Select value={editPlanData.season} onValueChange={(value) => setEditPlanData({ ...editPlanData, season: value })}>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecteer seizoen" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="2023-2024">2023-2024</SelectItem>
                                <SelectItem value="2024-2025">2024-2025</SelectItem>
                                <SelectItem value="2025-2026">2025-2026</SelectItem>
                                <SelectItem value="2026-2027">2026-2027</SelectItem>
                                <SelectItem value="2027-2028">2027-2028</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="new-plan-start-date">Startdatum</Label>
                            <Input
                              id="new-plan-start-date"
                              type="date"
                              value={editPlanData.startDate}
                              onChange={(e) => setEditPlanData({ ...editPlanData, startDate: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="new-plan-end-date">Einddatum</Label>
                            <Input
                              id="new-plan-end-date"
                              type="date"
                              value={editPlanData.endDate}
                              onChange={(e) => setEditPlanData({ ...editPlanData, endDate: e.target.value })}
                            />
                          </div>
                        </div>
                        
                        <div>
                          <Label htmlFor="new-plan-sessions">Sessies per week</Label>
                          <Input
                            id="new-plan-sessions"
                            type="number"
                            min="1"
                            max="7"
                            value={editPlanData.sessionsPerWeek}
                            onChange={(e) => setEditPlanData({ ...editPlanData, sessionsPerWeek: parseInt(e.target.value) || 2 })}
                          />
                        </div>
                        
                        <div>
                          <Label>Trainingsdagen</Label>
                          <div className="grid grid-cols-3 gap-2 mt-2">
                            {['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag'].map((day) => (
                              <div key={day} className="flex items-center space-x-2">
                                <input
                                  type="checkbox"
                                  id={`new-day-${day}`}
                                  checked={editPlanData.trainingDays.includes(day)}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setEditPlanData({
                                        ...editPlanData,
                                        trainingDays: [...editPlanData.trainingDays, day]
                                      });
                                    } else {
                                      setEditPlanData({
                                        ...editPlanData,
                                        trainingDays: editPlanData.trainingDays.filter(d => d !== day)
                                      });
                                    }
                                  }}
                                  className="rounded border-gray-300"
                                />
                                <Label htmlFor={`new-day-${day}`} className="text-sm">{day}</Label>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button 
                            onClick={handleSaveNewPlan}
                            disabled={createYearPlan.isPending}
                            className="flex-1"
                          >
                            {createYearPlan.isPending ? 'Opslaan...' : 'Opslaan'}
                          </Button>
                          <Button 
                            variant="outline" 
                            onClick={() => setIsCreating(false)}
                            className="flex-1"
                          >
                            Annuleren
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Geen jaarplanningen bericht */}
                  {(!yearPlans || (Array.isArray(yearPlans) && yearPlans.length === 0)) && !isCreating && (
                    <div className="col-span-full text-center py-8">
                      <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500">Nog geen jaarplanningen aangemaakt</p>
                    </div>
                  )}
                  
                  {/* Bestaande jaarplanningen */}
                  {Array.isArray(yearPlans) && yearPlans.length > 0 && yearPlans.map((plan: any) => (
                    <Card key={plan.id} className="border border-gray-200 hover:shadow-lg transition-all duration-300 hover:border-blue-300 h-fit">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between mb-2">
                          <Badge className={`text-white ${
                            plan.ageGroup === 'U12' ? 'bg-emerald-600' :
                            plan.ageGroup === 'U15' ? 'bg-blue-600' : 
                            plan.ageGroup === 'U17' ? 'bg-indigo-600' :
                            plan.ageGroup === '1e elftal' ? 'bg-purple-600' : 'bg-gray-600'
                          }`}>
                            {plan.ageGroup}
                          </Badge>
                          <Badge variant="outline" className={
                            plan.status === 'active' ? 'border-green-500 text-green-700 bg-green-50' : 'border-gray-500 bg-gray-50'
                          }>
                            {plan.status === 'active' ? 'Actief' : plan.status}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between mb-1">
                          <CardTitle className="text-lg leading-tight">{plan.name}</CardTitle>
                          <div className="flex items-center gap-1">
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="h-7 w-7 p-0"
                              onClick={() => handleSyncTeamSchedule(plan.id)}
                              disabled={syncTeamSchedule.isPending}
                              title="Synchroniseer met team schedule"
                            >
                              <Sync className="h-4 w-4 text-green-600" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="h-7 w-7 p-0"
                              onClick={() => handleEditPlan(plan)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <CardDescription className="text-sm text-gray-600 leading-relaxed">{plan.description || 'Geen beschrijving'}</CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="space-y-3 text-sm text-gray-600">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <span className="text-xs text-gray-500 uppercase tracking-wide">Sessies per week</span>
                              <div className="font-medium text-gray-900">{plan.sessionsPerWeek || 2}x</div>
                            </div>
                            <div>
                              <span className="text-xs text-gray-500 uppercase tracking-wide">Seizoen</span>
                              <div className="font-medium text-gray-900">{plan.season}</div>
                              <div className="flex gap-1 mt-1">
                                {/* Kopieer naar volgend seizoen knop */}
                                <Button 
                                  size="xs" 
                                  variant="outline" 
                                  onClick={() => handleCopyToNextSeason(plan.id)}
                                  disabled={copyToNextSeason.isPending}
                                  className="text-xs px-2 py-1 bg-blue-50 hover:bg-blue-100 border-blue-300 text-blue-700"
                                >
                                  <Copy className="h-2 w-2 mr-1" />
                                  {copyToNextSeason.isPending ? 'Kopiëren...' : 'Volgend Seizoen'}
                                </Button>
                                

                              </div>
                            </div>
                          </div>
                          <div>
                            <span className="text-xs text-gray-500 uppercase tracking-wide">Trainingsdagen</span>
                            <div className="font-medium text-gray-900 mb-2">
                              {plan.trainingDays && Array.isArray(plan.trainingDays) 
                                ? plan.trainingDays
                                    .filter((day: any) => day && typeof day === 'string' && day.trim())
                                    .map((day: string) => {
                                      const dayMap: { [key: string]: string } = {
                                        'monday': 'Maandag',
                                        'tuesday': 'Dinsdag', 
                                        'wednesday': 'Woensdag',
                                        'thursday': 'Donderdag',
                                        'friday': 'Vrijdag',
                                        'saturday': 'Zaterdag',
                                        'sunday': 'Zondag'
                                      };
                                      return dayMap[day.toLowerCase()] || day;
                                    })
                                    .filter((day: string, index: number, arr: string[]) => arr.indexOf(day) === index)
                                    .join(', ')
                                : 'Maandag, Woensdag'
                              }
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 mt-4">
                          <Link href={`/calendar/${plan.id}`} className="w-full">
                            <Button size="sm" variant="outline" className="w-full text-xs">
                              <Calendar className="h-3 w-3 mr-1" />
                              Kalender
                            </Button>
                          </Link>
                          <Button 
                            size="sm" 
                            variant="destructive" 
                            onClick={() => handleDeletePlan(plan.id)}
                            className="w-full text-xs"
                          >
                            <Trash2 className="h-3 w-3 mr-1" />
                            Verwijder
                          </Button>
                        </div>
                        
                        {/* Action buttons */}
                        <div className="flex justify-between items-center gap-2 mt-4">
                          <div className="flex gap-1">
                            <Button 
                              size="sm" 
                              onClick={() => {
                                console.log('Main copy button clicked for plan:', plan.id, plan.name);
                                handleCopyPlan(plan.id, plan);
                              }} 
                              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 text-xs"
                              title="Kopieer jaarplanning"
                              disabled={copyYearPlan.isPending}
                            >
                              <Plus className="h-3 w-3 mr-1" />
                              Kopiëren
                            </Button>
                            <Button 
                              size="sm"
                              onClick={() => handleEditPlan(plan)} 
                              variant="outline"
                              className="px-3 py-1 text-xs"
                            >
                              <Edit className="h-3 w-3 mr-1" />
                              Bewerken
                            </Button>
                          </div>
                          
                          {/* Export knoppen */}
                          <div className="flex gap-1">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="p-2"
                              onClick={() => window.open(`/api/year-plans/${plan.id}/export/pdf`, '_blank')}
                              title="PDF Export"
                            >
                              <FileText className="h-4 w-4 text-red-600" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="p-2"
                              onClick={() => window.open(`/api/year-plans/${plan.id}/export/excel`, '_blank')}
                              title="Excel Export"
                            >
                              <FileSpreadsheet className="h-4 w-4 text-green-600" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="p-2"
                              onClick={async () => {
                                try {
                                  console.log('PowerPoint export clicked for plan:', plan.id);
                                  const response = await fetch(`/api/year-plans/${plan.id}/export/powerpoint`);
                                  if (!response.ok) throw new Error('Export failed');
                                  
                                  const blob = await response.blob();
                                  const url = window.URL.createObjectURL(blob);
                                  const a = document.createElement('a');
                                  a.href = url;
                                  a.download = `${plan.name.replace(/[^a-zA-Z0-9]/g, '_')}-Jaarplanning.pptx`;
                                  document.body.appendChild(a);
                                  a.click();
                                  window.URL.revokeObjectURL(url);
                                  document.body.removeChild(a);
                                  console.log('PowerPoint export completed successfully');
                                } catch (error) {
                                  console.error('PowerPoint export error:', error);
                                  alert('PowerPoint export mislukt. Probeer opnieuw.');
                                }
                              }}
                              title="PowerPoint Export"
                            >
                              <Monitor className="h-4 w-4 text-orange-600" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Edit Plan Dialog */}
        <Dialog open={showEditPlanDialog} onOpenChange={setShowEditPlanDialog}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Jaarplanning Bewerken</DialogTitle>
              <DialogDescription>
                Bewerk alle details van je jaarplanning
              </DialogDescription>
            </DialogHeader>
            
            {/* Opslaan knoppen bovenaan */}
            <div className="flex justify-end space-x-2 py-4 border-b border-gray-200 mb-4">
              <Button variant="outline" onClick={() => setShowEditPlanDialog(false)}>
                Annuleren
              </Button>
              <Button 
                onClick={handleSavePlan} 
                disabled={updateYearPlan.isPending}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6"
              >
                {updateYearPlan.isPending ? 'Opslaan...' : 'Wijzigingen Opslaan'}
              </Button>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-plan-name">Naam</Label>
                  <Input
                    id="edit-plan-name"
                    value={editPlanData.name}
                    onChange={(e) => setEditPlanData({ ...editPlanData, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-age-group">Leeftijdsgroep</Label>
                  <Select value={editPlanData.ageGroup} onValueChange={(value) => setEditPlanData({ ...editPlanData, ageGroup: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer leeftijdsgroep" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="U6">U6</SelectItem>
                      <SelectItem value="U7">U7</SelectItem>
                      <SelectItem value="U8">U8</SelectItem>
                      <SelectItem value="U9">U9</SelectItem>
                      <SelectItem value="U10">U10</SelectItem>
                      <SelectItem value="U11">U11</SelectItem>
                      <SelectItem value="U12">U12</SelectItem>
                      <SelectItem value="U13">U13</SelectItem>
                      <SelectItem value="U15">U15</SelectItem>
                      <SelectItem value="U17">U17</SelectItem>
                      <SelectItem value="U19">U19</SelectItem>
                      <SelectItem value="1e elftal">1e elftal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="edit-plan-description">Beschrijving</Label>
                <Textarea
                  id="edit-plan-description"
                  value={editPlanData.description}
                  onChange={(e) => setEditPlanData({ ...editPlanData, description: e.target.value })}
                  placeholder="Beschrijving (optioneel)"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="edit-season">Seizoen</Label>
                  <Select value={editPlanData.season} onValueChange={(value) => setEditPlanData({ ...editPlanData, season: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer seizoen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2023-2024">2023-2024</SelectItem>
                      <SelectItem value="2024-2025">2024-2025</SelectItem>
                      <SelectItem value="2025-2026">2025-2026</SelectItem>
                      <SelectItem value="2026-2027">2026-2027</SelectItem>
                      <SelectItem value="2027-2028">2027-2028</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-start-date">Startdatum</Label>
                  <Input
                    id="edit-start-date"
                    type="date"
                    value={editPlanData.startDate}
                    onChange={(e) => setEditPlanData({ ...editPlanData, startDate: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-end-date">Einddatum</Label>
                  <Input
                    id="edit-end-date"
                    type="date"
                    value={editPlanData.endDate}
                    onChange={(e) => setEditPlanData({ ...editPlanData, endDate: e.target.value })}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="edit-sessions-per-week">Sessies per week</Label>
                <Input
                  id="edit-sessions-per-week"
                  type="number"
                  min="1"
                  max="7"
                  value={editPlanData.sessionsPerWeek}
                  onChange={(e) => setEditPlanData({ ...editPlanData, sessionsPerWeek: parseInt(e.target.value) || 2 })}
                />
              </div>
              
              <div>
                <Label htmlFor="edit-status">Status</Label>
                <Select value={editPlanData.status || 'draft'} onValueChange={(value) => setEditPlanData({ ...editPlanData, status: value as 'draft' | 'active' | 'completed' })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Actief</SelectItem>
                    <SelectItem value="completed">Voltooid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="edit-team">Team Koppeling</Label>
                <Select 
                  value={editPlanData.teamId?.toString() || 'none'} 
                  onValueChange={(value) => {
                    console.log('Team selection changed:', value);
                    setEditPlanData({ 
                      ...editPlanData, 
                      teamId: value === 'none' ? null : parseInt(value) 
                    });
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer team (optioneel)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Geen team</SelectItem>
                    {teams && teams.map((team: any) => (
                      <SelectItem key={team.id} value={team.id.toString()}>
                        {team.name} ({team.ageGroup})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Trainingsdagen</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag'].map((day) => (
                    <div key={day} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`edit-day-${day}`}
                        checked={editPlanData.trainingDays.includes(day)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setEditPlanData({
                              ...editPlanData,
                              trainingDays: [...editPlanData.trainingDays, day]
                            });
                          } else {
                            setEditPlanData({
                              ...editPlanData,
                              trainingDays: editPlanData.trainingDays.filter(d => d !== day)
                            });
                          }
                        }}
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor={`edit-day-${day}`} className="text-sm">{day}</Label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <Label>Focus Thema's</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {['Techniek', 'Tactiek', 'Fysiek', 'Mentaal', 'Individueel', 'Teamspel', 'Verdediging', 'Aanval'].map((theme) => (
                    <div key={theme} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`edit-theme-${theme}`}
                        checked={editPlanData.focusThemes.includes(theme)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setEditPlanData({
                              ...editPlanData,
                              focusThemes: [...editPlanData.focusThemes, theme]
                            });
                          } else {
                            setEditPlanData({
                              ...editPlanData,
                              focusThemes: editPlanData.focusThemes.filter(t => t !== theme)
                            });
                          }
                        }}
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor={`edit-theme-${theme}`} className="text-sm">{theme}</Label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-6 border-t">
                <Button variant="outline" onClick={() => setShowEditPlanDialog(false)}>
                  Annuleren
                </Button>
                <Button 
                  onClick={handleSavePlan} 
                  disabled={updateYearPlan.isPending}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6"
                >
                  {updateYearPlan.isPending ? 'Opslaan...' : 'Opslaan'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Event Creation Dialog */}
        <Dialog open={showEventDialog} onOpenChange={setShowEventDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Nieuw Event Aanmaken</DialogTitle>
              <DialogDescription>
                Voeg een extra event toe aan {selectedPlanForEvent?.name}
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleEventSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Titel *</Label>
                  <Input
                    id="title"
                    value={eventForm.title}
                    onChange={(e) => setEventForm(prev => ({ ...prev, title: e.target.value }))}
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="eventType">Type Event *</Label>
                  <Select
                    value={eventForm.eventType}
                    onValueChange={(value) => setEventForm(prev => ({ ...prev, eventType: value as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="training">Training</SelectItem>
                      <SelectItem value="extra_training">Extra Training</SelectItem>
                      <SelectItem value="friendly_match">Vriendschappelijk</SelectItem>
                      <SelectItem value="competition_match">Competitie</SelectItem>
                      <SelectItem value="stage">Stage</SelectItem>
                      <SelectItem value="tournament">Toernooi</SelectItem>
                      <SelectItem value="videotraining">Videotraining</SelectItem>
                      <SelectItem value="teambuilding">Teambuilding</SelectItem>
                      <SelectItem value="other">Overig</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Beschrijving</Label>
                <Textarea
                  id="description"
                  value={eventForm.description}
                  onChange={(e) => setEventForm(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="date">Datum *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={eventForm.date}
                    onChange={(e) => setEventForm(prev => ({ ...prev, date: e.target.value }))}
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="startTime">Starttijd</Label>
                  <Input
                    id="startTime"
                    type="time"
                    value={eventForm.startTime}
                    onChange={(e) => setEventForm(prev => ({ ...prev, startTime: e.target.value }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="duration">Duur (minuten)</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={eventForm.duration}
                    onChange={(e) => setEventForm(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="location">Locatie</Label>
                  <Input
                    id="location"
                    value={eventForm.location}
                    onChange={(e) => setEventForm(prev => ({ ...prev, location: e.target.value }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="intensity">Intensiteit</Label>
                  <Select
                    value={eventForm.intensity}
                    onValueChange={(value) => setEventForm(prev => ({ ...prev, intensity: value as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="laag">Laag</SelectItem>
                      <SelectItem value="matig">Matig</SelectItem>
                      <SelectItem value="hoog">Hoog</SelectItem>
                      <SelectItem value="maximaal">Maximaal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Conditional fields based on event type */}
              {(eventForm.eventType === 'friendly_match' || eventForm.eventType === 'competition_match') && (
                <div>
                  <Label htmlFor="opponent">Tegenstander</Label>
                  <Input
                    id="opponent"
                    value={eventForm.opponent}
                    onChange={(e) => setEventForm(prev => ({ ...prev, opponent: e.target.value }))}
                  />
                </div>
              )}

              {eventForm.eventType === 'videotraining' && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="videoTopic">Video Onderwerp</Label>
                    <Input
                      id="videoTopic"
                      value={eventForm.videoTopic}
                      onChange={(e) => setEventForm(prev => ({ ...prev, videoTopic: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="videoUrl">Video/Meeting Link</Label>
                    <Input
                      id="videoUrl"
                      value={eventForm.videoUrl}
                      onChange={(e) => setEventForm(prev => ({ ...prev, videoUrl: e.target.value }))}
                    />
                  </div>
                </div>
              )}

              {eventForm.eventType === 'teambuilding' && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="teambuildingType">Type Teambuilding</Label>
                    <Select
                      value={eventForm.teambuildingType}
                      onValueChange={(value) => setEventForm(prev => ({ ...prev, teambuildingType: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="indoor">Indoor</SelectItem>
                        <SelectItem value="outdoor">Outdoor</SelectItem>
                        <SelectItem value="restaurant">Restaurant</SelectItem>
                        <SelectItem value="activity">Activiteit</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="teambuildingActivity">Activiteit</Label>
                    <Input
                      id="teambuildingActivity"
                      value={eventForm.teambuildingActivity}
                      onChange={(e) => setEventForm(prev => ({ ...prev, teambuildingActivity: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="maxParticipants">Max Deelnemers</Label>
                    <Input
                      id="maxParticipants"
                      type="number"
                      value={eventForm.maxParticipants}
                      onChange={(e) => setEventForm(prev => ({ ...prev, maxParticipants: parseInt(e.target.value) }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="costPerPerson">Kosten per persoon (€)</Label>
                    <Input
                      id="costPerPerson"
                      type="number"
                      step="0.01"
                      value={eventForm.costPerPerson}
                      onChange={(e) => setEventForm(prev => ({ ...prev, costPerPerson: parseFloat(e.target.value) }))}
                    />
                  </div>
                </div>
              )}

              <div>
                <Label htmlFor="notes">Notities</Label>
                <Textarea
                  id="notes"
                  value={eventForm.notes}
                  onChange={(e) => setEventForm(prev => ({ ...prev, notes: e.target.value }))}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowEventDialog(false)}
                >
                  Annuleren
                </Button>
                <Button
                  type="submit"
                  disabled={createEvent.isPending}
                  className="bg-red-600 hover:bg-red-700"
                >
                  {createEvent.isPending ? 'Aanmaken...' : 'Aanmaken'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Copy Year Plan Dialog */}
        <Dialog open={!!showCopyDialog} onOpenChange={() => setShowCopyDialog(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Jaarplanning Kopiëren</DialogTitle>
              <DialogDescription>
                Maak een kopie van deze jaarplanning voor een ander team
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="copy-name">Nieuwe naam</Label>
                <Input
                  id="copy-name"
                  value={copyFormData.name}
                  onChange={(e) => setCopyFormData({ ...copyFormData, name: e.target.value })}
                  placeholder="Naam voor de kopie"
                />
              </div>
              
              <div>
                <Label htmlFor="copy-age-group">Leeftijdsgroep</Label>
                <Select value={copyFormData.ageGroup} onValueChange={(value) => setCopyFormData({ ...copyFormData, ageGroup: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer leeftijdsgroep" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="U6">U6</SelectItem>
                    <SelectItem value="U7">U7</SelectItem>
                    <SelectItem value="U8">U8</SelectItem>
                    <SelectItem value="U9">U9</SelectItem>
                    <SelectItem value="U10">U10</SelectItem>
                    <SelectItem value="U11">U11</SelectItem>
                    <SelectItem value="U12">U12</SelectItem>
                    <SelectItem value="U13">U13</SelectItem>
                    <SelectItem value="U15">U15</SelectItem>
                    <SelectItem value="U17">U17</SelectItem>
                    <SelectItem value="U19">U19</SelectItem>
                    <SelectItem value="U20">U20</SelectItem>
                    <SelectItem value="Beloften">Beloften</SelectItem>
                    <SelectItem value="1e elftal">1e elftal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="copy-season">Seizoen</Label>
                <Select value={copyFormData.season} onValueChange={(value) => setCopyFormData({ ...copyFormData, season: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer seizoen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2023-2024">2023-2024</SelectItem>
                    <SelectItem value="2024-2025">2024-2025</SelectItem>
                    <SelectItem value="2025-2026">2025-2026</SelectItem>
                    <SelectItem value="2026-2027">2026-2027</SelectItem>
                    <SelectItem value="2027-2028">2027-2028</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-6">
              <Button variant="outline" onClick={() => setShowCopyDialog(null)}>
                Annuleren
              </Button>
              <Button 
                onClick={handleSubmitCopy} 
                disabled={copyYearPlan.isPending || !copyFormData.name.trim()}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {copyYearPlan.isPending ? 'Kopiëren...' : 'Kopiëren'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}