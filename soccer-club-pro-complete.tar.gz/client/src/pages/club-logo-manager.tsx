import React, { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Upload, Trash2, Image, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface Logo {
  filename: string;
  type: 'primary' | 'secondary' | 'team-specific';
  path: string;
  size: number;
  uploadDate: string;
  teamAssociation?: string;
}

export default function ClubLogoManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [logoType, setLogoType] = useState('ip');
  const [uploading, setUploading] = useState(false);

  // Get available logos with team organization
  const { data: logos, isLoading } = useQuery({
    queryKey: ['/api/logos'],
    retry: false,
  });

  // Get logo organization
  const { data: logoOrganization } = useQuery({
    queryKey: ['/api/logos/organization'],
    retry: false,
  });

  // Upload logo mutation
  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/club/logo', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Upload failed');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Logo geüpload",
        description: `${data.logoType.toUpperCase()} logo succesvol geüpload`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/club/logos'] });
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    },
    onError: (error) => {
      toast({
        title: "Upload mislukt",
        description: "Er ging iets mis bij het uploaden van het logo",
        variant: "destructive",
      });
      setUploading(false);
    },
  });

  // Delete logo mutation
  const deleteMutation = useMutation({
    mutationFn: async (filename: string) => {
      await apiRequest(`/api/club/logo/${filename}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      toast({
        title: "Logo verwijderd",
        description: "Logo succesvol verwijderd",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/club/logos'] });
    },
    onError: () => {
      toast({
        title: "Verwijdering mislukt",
        description: "Er ging iets mis bij het verwijderen van het logo",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/svg+xml'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Ongeldig bestandstype",
        description: "Alleen JPG, PNG en SVG bestanden zijn toegestaan",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "Bestand te groot",
        description: "Maximum bestandsgrootte is 10MB",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('logo', file);
    formData.append('logoType', logoType);
    
    uploadMutation.mutate(formData);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getLogoTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      'ip': 'InterProvinciaal',
      'provinciaal': 'Provinciaal',
      'mu20': 'MU20',
      'general': 'Algemeen',
      'vvc': 'VVC Brasschaat'
    };
    return types[type] || type.toUpperCase();
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Club Logo's</h1>
          <p className="text-muted-foreground mt-2">
            Beheer logo's voor verschillende teams en competities
          </p>
        </div>
      </div>

      {/* Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Nieuw Logo Uploaden
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Logo Type</label>
              <Select value={logoType} onValueChange={setLogoType}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecteer logo type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ip">InterProvinciaal (IP)</SelectItem>
                  <SelectItem value="provinciaal">Provinciaal</SelectItem>
                  <SelectItem value="mu20">MU20</SelectItem>
                  <SelectItem value="general">Algemeen</SelectItem>
                  <SelectItem value="vvc">VVC Brasschaat</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Bestand Selecteren</label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/jpg,image/png,image/svg+xml"
                onChange={handleFileSelect}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                disabled={uploading}
              />
            </div>
          </div>
          
          <div className="text-xs text-muted-foreground">
            Ondersteunde formaten: JPG, PNG, SVG • Maximum grootte: 10MB • Aanbevolen: 300x300px
          </div>

          {uploading && (
            <div className="flex items-center gap-2 text-blue-600">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              <span className="text-sm">Logo wordt geüpload...</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Current Logos */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Image className="h-5 w-5" />
            Huidige Logo's
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : logos && logos.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {logos.map((logo: Logo) => (
                <div
                  key={logo.filename}
                  className="border rounded-lg p-4 space-y-3"
                >
                  <div className="aspect-square bg-gray-50 rounded-lg flex items-center justify-center overflow-hidden">
                    <img
                      src={logo.path}
                      alt={`${logo.type} logo`}
                      className="max-w-full max-h-full object-contain"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        target.nextElementSibling?.setAttribute('style', 'display: flex');
                      }}
                    />
                    <div className="hidden items-center justify-center w-full h-full text-gray-400">
                      <Image className="h-12 w-12" />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">
                        {getLogoTypeLabel(logo.type)}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {formatFileSize(logo.size)}
                      </span>
                    </div>
                    
                    <div className="text-sm text-muted-foreground mt-1">
                      {logo.filename}
                    </div>
                    
                    <Button
                      variant="destructive"
                      size="sm"
                      className="mt-2 w-full"
                      onClick={() => deleteMutation.mutate(logo.filename)}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Verwijderen
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Image className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Nog geen logo's geüpload</p>
              <p className="text-sm">Upload je eerste logo hierboven</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}