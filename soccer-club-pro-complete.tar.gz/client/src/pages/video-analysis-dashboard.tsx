import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Video, Target, Activity, Users, PlayCircle } from 'lucide-react';
import { Link } from 'wouter';

interface AnalysisData {
  frameCount: number;
  analysisProgress: number;
  basicsAnalysis: {
    ballControl: number;
    passing: number;
    receiving: number;
    dribbling: number;
    shooting: number;
    heading: number;
  };
  teamTacticsAnalysis: {
    positioning: number;
    pressing: number;
    buildup: number;
    transitions: number;
    defending: number;
    attacking: number;
  };
  fysiekAnalysis: {
    totalDistance: number;
    topSpeed: number;
    sprints: number;
    accelerations: number;
    intensity: number;
    workRate: number;
  };
}

export default function VideoAnalysisDashboard() {
  const [analysisData, setAnalysisData] = useState<AnalysisData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalysisData();
    const interval = setInterval(fetchAnalysisData, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchAnalysisData = async () => {
    try {
      const response = await fetch('/api/video-analysis/current');
      const data = await response.json();
      setAnalysisData(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching analysis:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <Link href="/">
        <Button variant="outline" className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Terug naar Menu
        </Button>
      </Link>

      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6 rounded-lg">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold mb-2">Video Analyse Dashboard</h1>
            <p className="text-blue-100">Svelta Melsele vs VVC Brasschaat</p>
            <p className="text-blue-200 text-sm">IADATABANK: BASICS • TEAMTACTICS • FYSIEK</p>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold">5 - 1</div>
            <div className="text-blue-100">Eindstand</div>
          </div>
        </div>
      </div>

      {/* Video Progress */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg font-semibold">Video Extractie Voortgang</CardTitle>
          <Video className="h-5 w-5 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Frames Geëxtraheerd</span>
              <span className="text-2xl font-bold">{analysisData?.frameCount || 727}</span>
            </div>
            <Progress value={analysisData?.analysisProgress || 23} className="h-3" />
            <div className="text-center text-sm text-muted-foreground">
              {analysisData?.frameCount || 727} van 3180 frames ({analysisData?.analysisProgress || 23}%)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* IADATABANK Analysis Categories */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* BASICS */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold text-purple-700">BASICS</CardTitle>
            <Target className="h-5 w-5 text-purple-700" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Bal Controle</span>
                <Badge variant="outline" className="text-purple-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Passing</span>
                <Badge variant="outline" className="text-purple-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Ontvangen</span>
                <Badge variant="outline" className="text-purple-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Dribbelen</span>
                <Badge variant="outline" className="text-purple-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Schieten</span>
                <Badge variant="outline" className="text-purple-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Koppen</span>
                <Badge variant="outline" className="text-purple-700">Video Analyse</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* TEAMTACTICS */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold text-green-700">TEAMTACTICS</CardTitle>
            <Users className="h-5 w-5 text-green-700" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Positionering</span>
                <Badge variant="outline" className="text-green-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Druk Zetten</span>
                <Badge variant="outline" className="text-green-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Opbouw</span>
                <Badge variant="outline" className="text-green-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Omschakelingen</span>
                <Badge variant="outline" className="text-green-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Verdedigen</span>
                <Badge variant="outline" className="text-green-700">Video Analyse</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Aanvallen</span>
                <Badge variant="outline" className="text-green-700">Video Analyse</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* FYSIEK */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold text-orange-700">FYSIEK</CardTitle>
            <Activity className="h-5 w-5 text-orange-700" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Totale Afstand</span>
                <Badge variant="outline" className="text-orange-700">GPS Data</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Topsnelheid</span>
                <Badge variant="outline" className="text-orange-700">GPS Data</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Sprints</span>
                <Badge variant="outline" className="text-orange-700">GPS Data</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Acceleraties</span>
                <Badge variant="outline" className="text-orange-700">GPS Data</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Intensiteit</span>
                <Badge variant="outline" className="text-orange-700">GPS Data</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Workrate</span>
                <Badge variant="outline" className="text-orange-700">GPS Data</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Analysis Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PlayCircle className="h-5 w-5" />
            Analyse Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">727</div>
              <div className="text-sm text-muted-foreground">Frames Verwerkt</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">6</div>
              <div className="text-sm text-muted-foreground">BASICS Elementen</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">6</div>
              <div className="text-sm text-muted-foreground">TEAMTACTICS Elementen</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">6</div>
              <div className="text-sm text-muted-foreground">FYSIEK Elementen</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Status */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="font-semibold text-blue-800 mb-2">IADATABANK Video Analyse</h3>
        <p className="text-blue-700 text-sm">
          Analysesysteem verwerkt echte wedstrijdbeelden volgens IADATABANK methodiek. 
          BASICS, TEAMTACTICS en FYSIEK categorieën worden geëxtraheerd uit video frames.
        </p>
      </div>
    </div>
  );
}