import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Clock, Play, Shield, Target, Plus, Edit, Trash2, FileText } from "lucide-react";
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';

export default function TrainingProgramsPage() {
  // Training data from backup
  const hiitConditieOpbouw = {
    foundation: {
      work: 15,
      rest: 30,
      series: 8,
      intensity: "60% max HR",
      description: "Foundation start - 15s werk/30s rust",
      oefeningen: [
        "Rustig joggen op plaats (15s)",
        "Lichte high knees (15s)",
        "Zacht jumping jacks (15s)",
        "Walking lunges (15s)",
        "Arm swings (15s)",
        "Lichte march op plaats (15s)"
      ]
    },
    building: {
      work: 30,
      rest: 60,
      series: 12,
      intensity: "60% → 75% max HR",
      description: "Building fase - 30s werk/60s rust, opbouw in %",
      oefeningen: [
        "Shuttle runs (20m)",
        "Mountain climbers (30s)",
        "Burpees aangepast tempo (30s)",
        "High knees tempo verhogen (30s)",
        "Step-ups op plaats (30s)",
        "Squat jumps laag tempo (30s)"
      ]
    },
    work: {
      work: 10,
      rest: 45,
      series: 8,
      intensity: "100% max HR",
      description: "Work fase - 10s→30s werk/45s rust over 8 weken",
      oefeningen: [
        "All-out sprints (30m)",
        "Explosive burpees (maximale snelheid)",
        "Mountain climbers (100% tempo)",
        "High knees explosief",
        "Jump squats maximaal",
        "Battle ropes all-out"
      ]
    }
  };

  const cooldownOefeningen = [
    {
      naam: "Hamstring stretch",
      duur: "2x 20s per been",
      uitvoering: "Zit op grond, been gestrekt, andere been gebogen. Reik naar tenen tot lichte spanning. Niet wippen!"
    },
    {
      naam: "Calf stretch", 
      duur: "2x 15s per been",
      uitvoering: "Stap voorwaarts tegen muur, achterste been gestrekt, hiel op grond drukken. Voel stretch in kuit."
    },
    {
      naam: "Hip flexor stretch",
      duur: "2x 15s per kant", 
      uitvoering: "Lunge positie, achterste knie op grond, heup naar voren duwen. Voel stretch voorkant heup."
    },
    {
      naam: "IT-band stretch",
      duur: "2x 15s per kant",
      uitvoering: "Staand rechter been over linker, buig zijwaarts naar rechts. Voel stretch buitenkant bovenbeen."
    },
    {
      naam: "Glute stretch", 
      duur: "2x 15s per kant",
      uitvoering: "Lig op rug, trek knie naar borst, draai been naar andere kant. Voel stretch in bil."
    },
    {
      naam: "Shoulder doorway stretch",
      duur: "1x 20s",
      uitvoering: "Onderarm tegen deurpost 90°, stap voorwaarts. Voel stretch voorkant schouder."
    },
    {
      naam: "Ankle mobility",
      duur: "10 circles elke richting", 
      uitvoering: "Zittend, til voet op, maak trage cirkels. Eerst rechtsom, dan linksom."
    },
    {
      naam: "Neck rolls",
      duur: "5 langzame rondjes",
      uitvoering: "Voorzichtig hoofd rollen: voor → rechts → achter → links. Langzaam en gecontroleerd."
    },
    {
      naam: "Ademhaling", 
      duur: "5 cycli",
      uitvoering: "Inademen 4 sec door neus → vasthouden 4 sec → uitademen 6 sec door mond. Ontspan."
    }
  ];

  const trainingDayOptions = [
    { value: "monday", label: "Maandag" },
    { value: "tuesday", label: "Dinsdag" },
    { value: "wednesday", label: "Woensdag" },
    { value: "thursday", label: "Donderdag" },
    { value: "friday", label: "Vrijdag" },
    { value: "saturday", label: "Zaterdag" },
    { value: "sunday", label: "Zondag" }
  ];

  // State management
  const [programs, setPrograms] = useState([
    {
      id: 1,
      name: "Pre Season 2025",
      startDate: "2025-01-15",
      endDate: "2025-03-15",
      trainingDays: ["monday", "wednesday", "friday"],
      created: "15/01/2025",
      events: []
    }
  ]);

  // Export Functions with proper error handling
  const exportToPDF = (program: any) => {
    try {
      const doc = new jsPDF();
      let yPosition = 20;
      
      // Title
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text(`PRE SEASON PROGRAM: ${program.name}`, 10, yPosition);
      yPosition += 15;
      
      // Program Details
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text(`Periode: ${program.startDate} tot ${program.endDate}`, 10, yPosition);
      yPosition += 8;
      doc.text(`Training dagen: ${program.trainingDays.map((day: any) => trainingDayOptions.find(opt => opt.value === day)?.label).join(", ")}`, 10, yPosition);
      yPosition += 8;
      doc.text(`Aangemaakt: ${program.created}`, 10, yPosition);
      yPosition += 15;
      
      // Training Structure
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('TRAINING STRUCTUUR (60 MINUTEN):', 10, yPosition);
      yPosition += 12;
      
      // Opwarming
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('1. OPWARMING (10 min)', 10, yPosition);
      yPosition += 8;
      doc.setFont('helvetica', 'normal');
      doc.text('- Inlopen - Hartslag Max 140', 15, yPosition);
      yPosition += 12;
      
      // HIIT Conditie
      doc.setFont('helvetica', 'bold');
      doc.text('2. CONDITIE HIIT (30 min)', 10, yPosition);
      yPosition += 8;
      doc.setFont('helvetica', 'normal');
      doc.text('Foundation: 15s werk/30s rust × 8 series (60% max HR)', 15, yPosition);
      yPosition += 6;
      doc.text('Building: 30s werk/60s rust × 12 series (60%→75% max HR)', 15, yPosition);
      yPosition += 6;
      doc.text('Work: 10s→30s werk/45s rust × 8 series (100% max HR)', 15, yPosition);
      yPosition += 12;
      
      // Kracht HIIT
      doc.setFont('helvetica', 'bold');
      doc.text('3. KRACHT HIIT (15 min)', 10, yPosition);
      yPosition += 8;
      doc.setFont('helvetica', 'normal');
      doc.text('- 6 spiergroepen × 2.5 min elk', 15, yPosition);
      yPosition += 12;
      
      // Cool-down
      doc.setFont('helvetica', 'bold');
      doc.text('4. COOL-DOWN (5 min)', 10, yPosition);
      yPosition += 8;
      doc.setFont('helvetica', 'normal');
      doc.text('- 9 blessurepreventieve oefeningen', 15, yPosition);
      
      // Save PDF
      const fileName = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_training_program.pdf`;
      doc.save(fileName);
      
      alert(`PDF Training programma "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('PDF Export Error:', error);
      alert(`Fout bij het maken van PDF: ${error instanceof Error ? error.message : 'Onbekende fout'}`);
    }
  };

  const exportToExcel = (program: any) => {
    try {
      const wb = XLSX.utils.book_new();
      
      // Sheet 1: Program Overview
      const overview = [
        ['PRE SEASON TRAINING PROGRAM'],
        ['Program Naam', program.name],
        ['Periode', `${program.startDate} tot ${program.endDate}`],
        ['Training Dagen', program.trainingDays.map((day: any) => trainingDayOptions.find(opt => opt.value === day)?.label).join(', ')],
        ['Aangemaakt', program.created],
        [''],
        ['TRAINING STRUCTUUR (60 MINUTEN)'],
        ['Component', 'Duur', 'Beschrijving'],
        ['Opwarming', '10 min', 'Inlopen - Hartslag Max 140'],
        ['Conditie HIIT', '30 min', 'Foundation/Building/Work fases'],
        ['Kracht HIIT', '15 min', '6 spiergroepen × 2.5 min'],
        ['Cool-down', '5 min', '9 blessurepreventieve oefeningen']
      ];
      const ws1 = XLSX.utils.aoa_to_sheet(overview);
      XLSX.utils.book_append_sheet(wb, ws1, 'Program Overview');
      
      // Save Excel file
      const fileName = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_training_program.xlsx`;
      XLSX.writeFile(wb, fileName);
      
      alert(`Excel Training programma "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('Excel Export Error:', error);
      alert(`Fout bij het maken van Excel bestand: ${error instanceof Error ? error.message : 'Onbekende fout'}`);
    }
  };

  const exportToICS = (program: any) => {
    try {
      const icsEvents = program.events.map((event: any) => {
        const eventDate = new Date(event.date + 'T19:00:00');
        const endDate = new Date(event.date + 'T20:00:00');
        
        const formatDate = (date: Date) => {
          return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
        };

        const summary = event.type === 'training' ? `Training ${event.phase || 'Foundation'}` : `Wedstrijd vs ${event.opponent || 'TBD'}`;
        const description = event.type === 'training' ? 'Training - 60 minuten structuur' : `Tegenstander: ${event.opponent || 'Te bepalen'}`;
        
        return `BEGIN:VEVENT
UID:${event.id}@preseason-program
DTSTART:${formatDate(eventDate)}
DTEND:${formatDate(endDate)}
SUMMARY:${summary}
DESCRIPTION:${description}
LOCATION:${event.location || 'Sportcomplex'}
END:VEVENT`;
      });

      const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Soccer Club Pro//Training Program//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
X-WR-CALNAME:${program.name}
X-WR-CALDESC:Pre Season Training Program ${program.startDate} - ${program.endDate}
${icsEvents.join('\n')}
END:VCALENDAR`;

      const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_training_calendar.ics`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      alert(`ICS Training kalender "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('ICS Export Error:', error);
      alert(`Fout bij het maken van ICS bestand: ${error instanceof Error ? error.message : 'Onbekende fout'}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Pre Season Programs</h1>
        <p className="text-muted-foreground mb-4">Professionele voorbereiding programma's met export functionaliteit</p>
        
        {/* Programs List */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {programs.map((program) => (
            <Card key={program.id} className="border-2 hover:border-blue-300 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{program.name}</CardTitle>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="font-medium">Start:</span>
                    <br />
                    {program.startDate}
                  </div>
                  <div>
                    <span className="font-medium">Eind:</span>
                    <br />
                    {program.endDate}
                  </div>
                </div>
                
                <div className="text-sm">
                  <span className="font-medium">Training dagen:</span>
                  <br />
                  {program.trainingDays.map(day => trainingDayOptions.find(opt => opt.value === day)?.label).join(", ")}
                </div>
                
                <div className="grid grid-cols-4 gap-2 mt-4">
                  <div className="bg-orange-100 p-2 rounded text-center">
                    <Clock className="h-4 w-4 mx-auto mb-1 text-orange-600" />
                    <span className="text-xs font-medium text-orange-800">Warm-Up</span>
                  </div>
                  <div className="bg-blue-100 p-2 rounded text-center">
                    <Play className="h-4 w-4 mx-auto mb-1 text-blue-600" />
                    <span className="text-xs font-medium text-blue-800">Conditie HIIT</span>
                  </div>
                  <div className="bg-red-100 p-2 rounded text-center">
                    <Target className="h-4 w-4 mx-auto mb-1 text-red-600" />
                    <span className="text-xs font-medium text-red-800">Kracht HIIT</span>
                  </div>
                  <div className="bg-green-100 p-2 rounded text-center">
                    <Shield className="h-4 w-4 mx-auto mb-1 text-green-600" />
                    <span className="text-xs font-medium text-green-800">Cool-down</span>
                  </div>
                </div>
                
                <div className="flex gap-2 mt-4">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => exportToPDF(program)}
                  >
                    <FileText className="h-4 w-4 mr-1" />
                    PDF
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => exportToExcel(program)}
                  >
                    Excel
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => exportToICS(program)}
                  >
                    ICS
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}