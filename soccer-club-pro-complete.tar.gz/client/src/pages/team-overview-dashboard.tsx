import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Calendar, ChevronLeft, ChevronRight, Users, Clock, MapPin, Trophy, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format, startOfWeek, endOfWeek, addWeeks, subWeeks, addMonths, subMonths, startOfMonth, endOfMonth, parseISO, isWithinInterval } from 'date-fns';
import { nl } from 'date-fns/locale';

interface TeamScheduleEntry {
  id: number;
  teamId: number;
  yearPlanId?: number;
  yearPlanSessionId?: number;
  teamName?: string;
  date: string;
  startTime: string;
  endTime: string;
  duration: number;
  eventType: string;
  title: string;
  location: string;
  notes?: string;
  mainTheme?: string;
  categoryInfo?: string;
  fullDetails?: string;
  opponent?: string;
  isVaria: boolean;
  variaType?: string;
  status: string;
  themes?: string[];
  selectedItems?: any[];
}

interface TeamOverviewData {
  team: {
    id: number;
    name: string;
    ageGroup: string;
  };
  schedule: TeamScheduleEntry[];
  totalSessions: number;
  trainingCount: number;
  variaCount: number;
}

type ViewMode = 'week' | 'month';

export default function TeamOverviewDashboard() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<ViewMode>('week');
  
  // Get all teams overview data with correct ordering
  const { data: allTeamData, isLoading: scheduleLoading, error } = useQuery({
    queryKey: ['/api/teams-overview'],
    retry: false,
  });

  console.log('Team overview data:', { allTeamData, error, scheduleLoading });

  // Teams are already sorted correctly by the API (Dames IP first)
  const sortedTeamData = allTeamData?.teams || [];

  // Calculate date range based on view mode
  const getDateRange = () => {
    if (viewMode === 'week') {
      return {
        start: startOfWeek(currentDate, { weekStartsOn: 1 }), // Start on Monday
        end: endOfWeek(currentDate, { weekStartsOn: 1 })
      };
    } else {
      return {
        start: startOfMonth(currentDate),
        end: endOfMonth(currentDate)
      };
    }
  };

  // Navigation functions
  const navigateBackward = () => {
    if (viewMode === 'week') {
      setCurrentDate(subWeeks(currentDate, 1));
    } else {
      setCurrentDate(subMonths(currentDate, 1));
    }
  };

  const navigateForward = () => {
    if (viewMode === 'week') {
      setCurrentDate(addWeeks(currentDate, 1));
    } else {
      setCurrentDate(addMonths(currentDate, 1));
    }
  };

  // Filter sessions by date range
  const getFilteredSessions = () => {
    if (!allTeamData?.teams) return [];
    
    const { start, end } = getDateRange();
    const allSessions: (TeamScheduleEntry & { teamName: string; teamAgeGroup: string })[] = [];
    
    allTeamData.teams.forEach(teamData => {
      teamData.schedule.forEach(session => {
        const sessionDate = parseISO(session.date);
        if (isWithinInterval(sessionDate, { start, end })) {
          allSessions.push({
            ...session,
            teamName: teamData.team.name,
            teamAgeGroup: teamData.team.ageGroup
          });
        }
      });
    });
    
    // Sort by date and time
    return allSessions.sort((a, b) => {
      const dateCompare = new Date(a.date).getTime() - new Date(b.date).getTime();
      if (dateCompare !== 0) return dateCompare;
      return a.startTime.localeCompare(b.startTime);
    });
  };

  const filteredSessions = getFilteredSessions();
  const { start, end } = getDateRange();

  // Calculate statistics from all team data
  const calculateStatistics = () => {
    if (!allTeamData?.teams) return { totalTeams: 0, totalSessions: 0, totalTrainings: 0, totalVaria: 0 };
    
    const totalTeams = allTeamData.teams.length;
    let totalSessions = 0;
    let totalTrainings = 0;
    let totalVaria = 0;
    
    allTeamData.teams.forEach(teamData => {
      totalSessions += teamData.schedule.length;
      teamData.schedule.forEach(session => {
        if (session.isVaria) {
          totalVaria++;
        } else {
          totalTrainings++;
        }
      });
    });
    
    return { totalTeams, totalSessions, totalTrainings, totalVaria };
  };

  const stats = calculateStatistics();

  // Group sessions by date
  const sessionsByDate = filteredSessions.reduce((acc, session) => {
    const dateKey = session.date;
    if (!acc[dateKey]) acc[dateKey] = [];
    acc[dateKey].push(session);
    return acc;
  }, {} as Record<string, typeof filteredSessions>);

  // Get team color for visual distinction
  const getTeamColor = (teamName: string) => {
    const colors = [
      'bg-blue-100 text-blue-800 border-blue-200',
      'bg-green-100 text-green-800 border-green-200',
      'bg-purple-100 text-purple-800 border-purple-200',
      'bg-orange-100 text-orange-800 border-orange-200',
      'bg-pink-100 text-pink-800 border-pink-200',
      'bg-cyan-100 text-cyan-800 border-cyan-200'
    ];
    
    const hash = teamName.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return colors[hash % colors.length];
  };

  if (scheduleLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <Users className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Team Weekoverzicht Dashboard</h1>
        </div>
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <Users className="h-6 w-6" />
        <h1 className="text-2xl font-bold">Team Weekoverzicht Dashboard</h1>
      </div>

      {/* Controls */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between gap-4">
            {/* View Mode Selector */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Weergave:</span>
              <Select value={viewMode} onValueChange={(value: ViewMode) => setViewMode(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Week</SelectItem>
                  <SelectItem value="month">Maand</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Navigation */}
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={navigateBackward}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="text-lg font-semibold min-w-[200px] text-center">
                {viewMode === 'week' ? (
                  `Week ${format(start, 'w', { locale: nl })} - ${format(start, 'd MMM', { locale: nl })} tot ${format(end, 'd MMM yyyy', { locale: nl })}`
                ) : (
                  format(currentDate, 'MMMM yyyy', { locale: nl })
                )}
              </div>
              
              <Button variant="outline" size="sm" onClick={navigateForward}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            {/* Today Button */}
            <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())}>
              Vandaag
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{allTeamData?.totalTeams || 0}</div>
            <div className="text-sm text-gray-600">Actieve Teams</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{allTeamData?.totalSessions || filteredSessions.length}</div>
            <div className="text-sm text-gray-600">Totaal Activiteiten</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{filteredSessions.filter(s => !s.isVaria).length}</div>
            <div className="text-sm text-gray-600">Trainingen</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{filteredSessions.filter(s => s.isVaria).length}</div>
            <div className="text-sm text-gray-600">VARIA Activiteiten</div>
          </CardContent>
        </Card>
      </div>

      {/* Sessions Overview */}
      <div className="space-y-4">
        {Object.keys(sessionsByDate).length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Calendar className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Geen activiteiten gepland</h3>
              <p className="text-gray-500">
                Er zijn geen trainingen of activiteiten gepland voor {viewMode === 'week' ? 'deze week' : 'deze maand'}.
              </p>
            </CardContent>
          </Card>
        ) : (
          Object.entries(sessionsByDate).map(([date, sessions]) => (
            <Card key={date}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  {format(parseISO(date), 'EEEE d MMMM yyyy', { locale: nl })}
                  <Badge variant="secondary">{sessions.length} activiteiten</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3">
                  {sessions.map((session, index) => (
                    <div key={`${session.id}-${index}`} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={getTeamColor(session.teamName)}>
                              {session.teamName}
                            </Badge>
                            {session.isVaria ? (
                              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                                <Trophy className="h-3 w-3 mr-1" />
                                {session.variaType || 'VARIA'}
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                <Target className="h-3 w-3 mr-1" />
                                Training
                              </Badge>
                            )}
                          </div>
                          
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 text-sm">
                              <Clock className="h-4 w-4 text-gray-500" />
                              <span className="font-medium">{session.startTime} - {session.endTime}</span>
                              <span className="text-gray-500">({session.duration} min)</span>
                            </div>
                            
                            <div className="flex items-center gap-2 text-sm">
                              <MapPin className="h-4 w-4 text-gray-500" />
                              <span>{session.location}</span>
                            </div>
                            
                            {session.mainTheme && (
                              <div className="text-sm">
                                <span className="font-medium text-blue-600">Thema:</span> {session.mainTheme}
                              </div>
                            )}
                            
                            {session.opponent && (
                              <div className="text-sm">
                                <span className="font-medium text-red-600">Tegenstander:</span> {session.opponent}
                              </div>
                            )}
                            
                            {session.selectedItems && session.selectedItems.length > 0 && (
                              <div className="text-sm text-gray-700 mt-2">
                                <span className="font-medium">Elementen:</span>
                                <div className="mt-1 space-y-1">
                                  {session.selectedItems.map((item, idx) => (
                                    <div key={idx} className="text-xs bg-gray-50 p-1 rounded">
                                      {typeof item === 'string' ? item : (item.name || item.elementId || 'Element')}
                                      {typeof item === 'object' && item.theme && (
                                        <span className="text-gray-500 ml-1">({item.theme})</span>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            
                            {session.notes && (
                              <div className="text-sm text-gray-600 italic">
                                {session.notes}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}