import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { BackToMenu } from "@/components/ui/back-to-menu";
import { 
  Play, 
  Pause, 
  Square, 
  RotateCcw, 
  Save, 
  Download,
  Upload,
  Users,
  Target,
  MapPin,
  Clock,
  Plus,
  Minus,
  Eye,
  Edit,
  Trash2
} from "lucide-react";

interface Player {
  id: string;
  name: string;
  number: number;
  position: { x: number; y: number };
  team: 'home' | 'away';
  role: string;
}

interface MatchEvent {
  id: string;
  type: 'goal' | 'assist' | 'foul' | 'card' | 'substitution' | 'offside';
  time: number;
  player: string;
  team: 'home' | 'away';
  description: string;
  position?: { x: number; y: number };
}

interface Formation {
  name: string;
  positions: { x: number; y: number; role: string }[];
}

const formations: { [key: string]: Formation } = {
  '4-4-2': {
    name: '4-4-2',
    positions: [
      { x: 50, y: 5, role: 'GK' },
      { x: 20, y: 25, role: 'LB' }, { x: 40, y: 25, role: 'CB' }, { x: 60, y: 25, role: 'CB' }, { x: 80, y: 25, role: 'RB' },
      { x: 20, y: 50, role: 'LM' }, { x: 40, y: 50, role: 'CM' }, { x: 60, y: 50, role: 'CM' }, { x: 80, y: 50, role: 'RM' },
      { x: 35, y: 75, role: 'ST' }, { x: 65, y: 75, role: 'ST' }
    ]
  },
  '4-3-3': {
    name: '4-3-3',
    positions: [
      { x: 50, y: 5, role: 'GK' },
      { x: 20, y: 25, role: 'LB' }, { x: 40, y: 25, role: 'CB' }, { x: 60, y: 25, role: 'CB' }, { x: 80, y: 25, role: 'RB' },
      { x: 30, y: 50, role: 'CM' }, { x: 50, y: 50, role: 'CM' }, { x: 70, y: 50, role: 'CM' },
      { x: 20, y: 75, role: 'LW' }, { x: 50, y: 75, role: 'ST' }, { x: 80, y: 75, role: 'RW' }
    ]
  },
  '3-5-2': {
    name: '3-5-2',
    positions: [
      { x: 50, y: 5, role: 'GK' },
      { x: 30, y: 25, role: 'CB' }, { x: 50, y: 25, role: 'CB' }, { x: 70, y: 25, role: 'CB' },
      { x: 15, y: 50, role: 'LWB' }, { x: 35, y: 50, role: 'CM' }, { x: 50, y: 50, role: 'CM' }, { x: 65, y: 50, role: 'CM' }, { x: 85, y: 50, role: 'RWB' },
      { x: 40, y: 75, role: 'ST' }, { x: 60, y: 75, role: 'ST' }
    ]
  }
};

export default function TacticalFieldAnalyzer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [events, setEvents] = useState<MatchEvent[]>([]);
  const [selectedFormation, setSelectedFormation] = useState('4-4-2');
  const [currentTeam, setCurrentTeam] = useState<'home' | 'away'>('home');
  const [matchTime, setMatchTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null);
  const [eventType, setEventType] = useState('goal');
  const [eventDescription, setEventDescription] = useState('');
  const [matchInfo, setMatchInfo] = useState({
    homeTeam: 'VVC Brasschaat',
    awayTeam: 'Tegenstander',
    homeScore: 0,
    awayScore: 0
  });

  // Initialize canvas and field
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    drawField(ctx);
    drawPlayers(ctx);
  }, [players, selectedPlayer]);

  // Timer for match simulation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setMatchTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const drawField = (ctx: CanvasRenderingContext2D) => {
    const canvas = ctx.canvas;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Field background
    ctx.fillStyle = '#2d7738';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Field lines
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 2;
    
    // Outer boundary
    ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);
    
    // Center line
    ctx.beginPath();
    ctx.moveTo(20, canvas.height / 2);
    ctx.lineTo(canvas.width - 20, canvas.height / 2);
    ctx.stroke();
    
    // Center circle
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 50, 0, 2 * Math.PI);
    ctx.stroke();
    
    // Penalty areas
    const penaltyWidth = 80;
    const penaltyHeight = 40;
    
    // Top penalty area
    ctx.strokeRect((canvas.width - penaltyWidth) / 2, 20, penaltyWidth, penaltyHeight);
    
    // Bottom penalty area
    ctx.strokeRect((canvas.width - penaltyWidth) / 2, canvas.height - 20 - penaltyHeight, penaltyWidth, penaltyHeight);
    
    // Goals
    const goalWidth = 30;
    ctx.strokeRect((canvas.width - goalWidth) / 2, 15, goalWidth, 10);
    ctx.strokeRect((canvas.width - goalWidth) / 2, canvas.height - 25, goalWidth, 10);
  };

  const drawPlayers = (ctx: CanvasRenderingContext2D) => {
    players.forEach(player => {
      const x = (player.position.x / 100) * (ctx.canvas.width - 40) + 20;
      const y = (player.position.y / 100) * (ctx.canvas.height - 40) + 20;
      
      // Player circle
      ctx.beginPath();
      ctx.arc(x, y, 12, 0, 2 * Math.PI);
      ctx.fillStyle = player.team === 'home' ? '#3b82f6' : '#ef4444';
      ctx.fill();
      
      // Selection highlight
      if (selectedPlayer === player.id) {
        ctx.strokeStyle = '#fbbf24';
        ctx.lineWidth = 3;
        ctx.stroke();
      }
      
      // Player number
      ctx.fillStyle = 'white';
      ctx.font = 'bold 10px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(player.number.toString(), x, y + 3);
    });
  };

  const loadFormation = (team: 'home' | 'away', formationKey: string) => {
    const formation = formations[formationKey];
    const newPlayers = formation.positions.map((pos, index) => ({
      id: `${team}_${index}`,
      name: `Speler ${index + 1}`,
      number: index + 1,
      position: team === 'away' ? { x: 100 - pos.x, y: 100 - pos.y } : pos,
      team,
      role: pos.role
    }));

    setPlayers(prev => [
      ...prev.filter(p => p.team !== team),
      ...newPlayers
    ]);
  };

  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    // Check if clicking on a player
    const clickedPlayer = players.find(player => {
      const playerX = (player.position.x / 100) * (canvas.width - 40) + 20;
      const playerY = (player.position.y / 100) * (canvas.height - 40) + 20;
      const distance = Math.sqrt((x - playerX) ** 2 + (y - playerY) ** 2);
      return distance <= 12;
    });

    if (clickedPlayer) {
      setSelectedPlayer(clickedPlayer.id);
    } else {
      setSelectedPlayer(null);
    }
  };

  const addEvent = () => {
    if (!selectedPlayer) return;

    const player = players.find(p => p.id === selectedPlayer);
    if (!player) return;

    const newEvent: MatchEvent = {
      id: Date.now().toString(),
      type: eventType as any,
      time: matchTime,
      player: player.name,
      team: player.team,
      description: eventDescription || `${eventType} door ${player.name}`,
      position: player.position
    };

    setEvents(prev => [...prev, newEvent]);
    
    // Update score for goals
    if (eventType === 'goal') {
      if (player.team === 'home') {
        setMatchInfo(prev => ({ ...prev, homeScore: prev.homeScore + 1 }));
      } else {
        setMatchInfo(prev => ({ ...prev, awayScore: prev.awayScore + 1 }));
      }
    }

    setEventDescription('');
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const exportAnalysis = () => {
    const data = {
      matchInfo,
      players,
      events,
      timestamp: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tactical-analysis-${matchInfo.homeTeam}-vs-${matchInfo.awayTeam}.json`;
    a.click();
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <BackToMenu />
      
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Tactische Veld Analyzer</h1>
        <p className="text-gray-600">Professionele voetbalanalyse met real-time event tracking</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Field Canvas */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl">
                    {matchInfo.homeTeam} {matchInfo.homeScore} - {matchInfo.awayScore} {matchInfo.awayTeam}
                  </CardTitle>
                  <CardDescription>Tijd: {formatTime(matchTime)}</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant={isPlaying ? "secondary" : "default"}
                    onClick={() => setIsPlaying(!isPlaying)}
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setMatchTime(0)}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <canvas
                ref={canvasRef}
                width={600}
                height={400}
                className="border rounded-lg cursor-pointer w-full"
                onClick={handleCanvasClick}
              />
            </CardContent>
          </Card>
        </div>

        {/* Control Panel */}
        <div className="space-y-6">
          {/* Team Setup */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Team Opstelling
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Team</Label>
                <Select value={currentTeam} onValueChange={(value: 'home' | 'away') => setCurrentTeam(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="home">{matchInfo.homeTeam}</SelectItem>
                    <SelectItem value="away">{matchInfo.awayTeam}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Formatie</Label>
                <Select value={selectedFormation} onValueChange={setSelectedFormation}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.keys(formations).map(formation => (
                      <SelectItem key={formation} value={formation}>
                        {formation}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => loadFormation(currentTeam, selectedFormation)}
                className="w-full"
              >
                Formatie Laden
              </Button>
            </CardContent>
          </Card>

          {/* Event Recording */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Event Registratie
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedPlayer && (
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm font-medium">
                    Geselecteerd: {players.find(p => p.id === selectedPlayer)?.name}
                  </p>
                </div>
              )}
              
              <div>
                <Label>Event Type</Label>
                <Select value={eventType} onValueChange={setEventType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="goal">Doelpunt</SelectItem>
                    <SelectItem value="assist">Assist</SelectItem>
                    <SelectItem value="foul">Overtreding</SelectItem>
                    <SelectItem value="card">Kaart</SelectItem>
                    <SelectItem value="substitution">Wissel</SelectItem>
                    <SelectItem value="offside">Buitenspel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Beschrijving</Label>
                <Textarea
                  value={eventDescription}
                  onChange={(e) => setEventDescription(e.target.value)}
                  placeholder="Event details..."
                  rows={2}
                />
              </div>
              
              <Button 
                onClick={addEvent} 
                disabled={!selectedPlayer}
                className="w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                Event Toevoegen
              </Button>
            </CardContent>
          </Card>

          {/* Match Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Wedstrijd Controle
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Match Tijd (minuten)</Label>
                <Input
                  type="number"
                  value={Math.floor(matchTime / 60)}
                  onChange={(e) => setMatchTime(parseInt(e.target.value) * 60)}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>Thuis Score</Label>
                  <Input
                    type="number"
                    value={matchInfo.homeScore}
                    onChange={(e) => setMatchInfo(prev => ({ ...prev, homeScore: parseInt(e.target.value) || 0 }))}
                  />
                </div>
                <div>
                  <Label>Uit Score</Label>
                  <Input
                    type="number"
                    value={matchInfo.awayScore}
                    onChange={(e) => setMatchInfo(prev => ({ ...prev, awayScore: parseInt(e.target.value) || 0 }))}
                  />
                </div>
              </div>
              
              <Button onClick={exportAnalysis} variant="outline" className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Export Analyse
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Events Timeline */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Wedstrijd Events</CardTitle>
        </CardHeader>
        <CardContent>
          {events.length > 0 ? (
            <div className="space-y-2">
              {events.sort((a, b) => a.time - b.time).map(event => (
                <div key={event.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Badge variant={event.type === 'goal' ? 'default' : 'secondary'}>
                      {formatTime(event.time)}
                    </Badge>
                    <span className="font-medium">{event.player}</span>
                    <span className="text-gray-600">{event.description}</span>
                  </div>
                  <Badge variant={event.team === 'home' ? 'default' : 'destructive'}>
                    {event.team === 'home' ? matchInfo.homeTeam : matchInfo.awayTeam}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">
              Nog geen events geregistreerd. Selecteer een speler en voeg events toe.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}