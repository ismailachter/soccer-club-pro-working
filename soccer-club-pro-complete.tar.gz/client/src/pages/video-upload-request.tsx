import { Upload, Video, AlertCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function VideoUploadRequest() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <Video className="h-16 w-16 text-blue-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Video Upload Required
          </h1>
          <p className="text-lg text-gray-600">
            Upload de echte wedstrijdvideo voor authentieke analyse
          </p>
        </div>

        <div className="grid gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Wedstrijdvideo Vereist
              </CardTitle>
              <CardDescription>
                Het systeem kan alleen echte video's analyseren - geen afbeeldingen of opstellingen
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Status:</strong> Wachten op echte wedstrijdvideo upload van VVC Brasschaat vs KVKS Melsele
                </AlertDescription>
              </Alert>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h3 className="font-semibold text-green-600 mb-2">✓ Beschikbaar</h3>
                  <ul className="text-sm space-y-1">
                    <li>• Team opstellingen</li>
                    <li>• Speler informatie</li>
                    <li>• GPS performance data</li>
                    <li>• Wedstrijd setup</li>
                  </ul>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h3 className="font-semibold text-red-600 mb-2">⚠ Vereist Video</h3>
                  <ul className="text-sm space-y-1">
                    <li>• Doelpunten timing</li>
                    <li>• Eindstand</li>
                    <li>• Match events</li>
                    <li>• Goal scorers</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Ondersteunde Video Formaten</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4 text-center">
                <div className="p-4 border rounded-lg">
                  <Video className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                  <p className="font-medium">.MP4</p>
                  <p className="text-sm text-gray-600">Aanbevolen</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <Video className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                  <p className="font-medium">.AVI</p>
                  <p className="text-sm text-gray-600">Ondersteund</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <Video className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                  <p className="font-medium">.MOV</p>
                  <p className="text-sm text-gray-600">Ondersteund</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <p className="text-gray-600">
            Upload de wedstrijdvideo om automatische goal detectie en match analyse te starten
          </p>
        </div>
      </div>
    </div>
  );
}