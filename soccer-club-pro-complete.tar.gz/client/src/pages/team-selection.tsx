import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Users, Target, Filter, Download, ArrowRight, Star } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface Player {
  id: number;
  firstName: string;
  lastName: string;
  teamName: string;
  position: string;
  status: string;
  jerseyNumber?: number;
  dateOfBirth?: string;
}

interface Team {
  id: number;
  name: string;
}

export default function TeamSelection() {
  const [selectedTeam, setSelectedTeam] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [positionFilter, setPositionFilter] = useState<string>("");
  const [selectedPlayers, setSelectedPlayers] = useState<number[]>([]);
  const [scoutCandidates, setScoutCandidates] = useState<number[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch teams
  const { data: teams = [], isLoading: teamsLoading } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
  });

  // Fetch players
  const { data: players = [], isLoading: playersLoading } = useQuery<Player[]>({
    queryKey: ['/api/players'],
  });

  // Filter players based on selected team, search term and position
  const filteredPlayers = players.filter(player => {
    const matchesTeam = !selectedTeam || player.teamName === selectedTeam;
    const matchesSearch = !searchTerm || 
      `${player.firstName} ${player.lastName}`.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPosition = !positionFilter || player.position === positionFilter;
    const isActive = player.status === 'active';
    
    return matchesTeam && matchesSearch && matchesPosition && isActive;
  });

  // Toggle player selection
  const togglePlayerSelection = (playerId: number) => {
    setSelectedPlayers(prev => 
      prev.includes(playerId) 
        ? prev.filter(id => id !== playerId)
        : [...prev, playerId]
    );
  };

  // Clear all selections
  const clearSelection = () => {
    setSelectedPlayers([]);
  };

  // Get selected players data
  const selectedPlayersData = players.filter(player => selectedPlayers.includes(player.id));

  // Convert player to scout
  const convertToScoutMutation = useMutation({
    mutationFn: async (playerId: number) => {
      const player = players.find(p => p.id === playerId);
      if (!player) throw new Error('Player not found');
      
      return await apiRequest('/api/scout/convert-player', 'POST', {
        playerId: playerId,
        scoutData: {
          currentClub: player.teamName,
          scoutPriority: 'medium',
          notes: `Converted from team selection module`,
          position: player.position,
          strongFoot: 'unknown',
          weaknessAreas: '',
          strengthAreas: '',
          technicalRating: 0,
          physicalRating: 0,
          mentalRating: 0,
          overallRating: 0
        }
      });
    },
    onSuccess: () => {
      toast({
        title: "Speler toegevoegd aan Scout Database",
        description: "De speler is succesvol verplaatst naar de Scout Database.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/players'] });
      queryClient.invalidateQueries({ queryKey: ['/api/scout'] });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij verplaatsen",
        description: error.message || "Er is een fout opgetreden bij het verplaatsen naar Scout Database.",
        variant: "destructive",
      });
    },
  });

  // Handle move to scout database
  const moveToScoutDatabase = (playerId: number) => {
    setScoutCandidates(prev => [...prev, playerId]);
    convertToScoutMutation.mutate(playerId);
  };

  if (teamsLoading || playersLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Laden...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Target className="h-6 w-6" />
        <h1 className="text-2xl font-bold">Selectiemodule</h1>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="team-select">Team</Label>
              <Select value={selectedTeam} onValueChange={setSelectedTeam}>
                <SelectTrigger>
                  <SelectValue placeholder="Alle teams" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle teams</SelectItem>
                  {teams.map((team) => (
                    <SelectItem key={team.id} value={team.name}>
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="position-select">Positie</Label>
              <Select value={positionFilter} onValueChange={setPositionFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Alle posities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle posities</SelectItem>
                  <SelectItem value="goalkeeper">Goalkeeper</SelectItem>
                  <SelectItem value="defender">Verdediger</SelectItem>
                  <SelectItem value="midfielder">Middenvelder</SelectItem>
                  <SelectItem value="forward">Aanvaller</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="search">Zoeken</Label>
              <Input
                id="search"
                placeholder="Zoek spelers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Available Players */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Beschikbare Spelers ({filteredPlayers.length})
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredPlayers.map((player) => (
                <div
                  key={player.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedPlayers.includes(player.id)
                      ? 'bg-primary/10 border-primary'
                      : 'hover:bg-muted/50'
                  }`}
                  onClick={() => togglePlayerSelection(player.id)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{player.firstName} {player.lastName}</p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>{player.teamName}</span>
                        <span>•</span>
                        <span>{player.position}</span>
                        {player.jerseyNumber && (
                          <>
                            <span>•</span>
                            <span>#{player.jerseyNumber}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={selectedPlayers.includes(player.id) ? "default" : "secondary"}>
                        {selectedPlayers.includes(player.id) ? "Geselecteerd" : "Selecteren"}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          moveToScoutDatabase(player.id);
                        }}
                        disabled={scoutCandidates.includes(player.id) || convertToScoutMutation.isPending}
                        className="p-1 h-8 w-8"
                      >
                        {scoutCandidates.includes(player.id) ? (
                          <Star className="h-4 w-4 text-yellow-500" />
                        ) : (
                          <ArrowRight className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
              
              {filteredPlayers.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  Geen spelers gevonden met de huidige filters
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Selected Players */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Geselecteerde Spelers ({selectedPlayers.length})
              </span>
              {selectedPlayers.length > 0 && (
                <Button variant="outline" size="sm" onClick={clearSelection}>
                  Wis Selectie
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {selectedPlayersData.map((player) => (
                <div
                  key={player.id}
                  className="p-3 border rounded-lg bg-primary/5"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{player.firstName} {player.lastName}</p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>{player.teamName}</span>
                        <span>•</span>
                        <span>{player.position}</span>
                        {player.jerseyNumber && (
                          <>
                            <span>•</span>
                            <span>#{player.jerseyNumber}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => togglePlayerSelection(player.id)}
                    >
                      Verwijderen
                    </Button>
                  </div>
                </div>
              ))}
              
              {selectedPlayers.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  Geen spelers geselecteerd
                </div>
              )}
            </div>

            {selectedPlayers.length > 0 && (
              <>
                <Separator className="my-4" />
                <div className="flex gap-2">
                  <Button className="flex-1">
                    <Download className="h-4 w-4 mr-2" />
                    Export Selectie
                  </Button>
                  <Button variant="outline" className="flex-1">
                    Opslaan als Opstelling
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}