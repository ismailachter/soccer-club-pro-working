import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Phone, Mail, Search, Download, Users, UserCheck, Baby } from "lucide-react";

interface ContactPerson {
  id: number;
  firstName: string;
  lastName: string;
  phone?: string;
  email?: string;
  role: string;
  team?: string;
  position?: string;
  status?: string;
}

export default function PhoneNumbers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [teamFilter, setTeamFilter] = useState("all");

  // Fetch all contacts data
  const { data: players = [] } = useQuery({
    queryKey: ["/api/players"],
  });

  const { data: coaches = [] } = useQuery({
    queryKey: ["/api/coaches"],
  });

  const { data: teams = [] } = useQuery({
    queryKey: ["/api/teams"],
  });

  // Transform data into unified contact format
  const allContacts: ContactPerson[] = [
    // Players
    ...players.map((player: any) => ({
      id: player.id,
      firstName: player.user?.firstName || '',
      lastName: player.user?.lastName || '',
      phone: player.user?.phone,
      email: player.user?.email,
      role: 'Player',
      team: player.team?.name,
      position: player.position,
      status: player.status
    })),
    // Coaches
    ...coaches.map((coach: any) => ({
      id: coach.id + 10000, // Offset to avoid ID conflicts
      firstName: coach.user?.firstName || '',
      lastName: coach.user?.lastName || '',
      phone: coach.user?.phone,
      email: coach.user?.email,
      role: 'Coach',
      team: coach.team?.name,
      position: coach.role || 'Coach',
      status: coach.status
    })),
    // TODO: Add parents when parent data is available
  ];

  // Filter contacts
  const filteredContacts = allContacts.filter(contact => {
    const matchesSearch = 
      contact.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.phone?.includes(searchTerm) ||
      contact.email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === "all" || contact.role.toLowerCase() === roleFilter.toLowerCase();
    const matchesTeam = teamFilter === "all" || contact.team === teamFilter;

    return matchesSearch && matchesRole && matchesTeam;
  });

  // Group contacts by role
  const playerContacts = filteredContacts.filter(c => c.role === 'Player');
  const coachContacts = filteredContacts.filter(c => c.role === 'Coach');
  const parentContacts = filteredContacts.filter(c => c.role === 'Parent');

  const exportContacts = () => {
    const csv = [
      ['Name', 'Phone', 'Email', 'Role', 'Team', 'Position'].join(','),
      ...filteredContacts.map(contact => [
        `"${contact.firstName} ${contact.lastName}"`,
        contact.phone || '',
        contact.email || '',
        contact.role,
        contact.team || '',
        contact.position || ''
      ].join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'club-contacts.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const ContactCard = ({ contact }: { contact: ContactPerson }) => (
    <Card className="mb-3">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-lg">
              {contact.firstName} {contact.lastName}
            </h3>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant={contact.role === 'Player' ? 'default' : contact.role === 'Coach' ? 'secondary' : 'outline'}>
                {contact.role}
              </Badge>
              {contact.team && (
                <Badge variant="outline">{contact.team}</Badge>
              )}
              {contact.position && (
                <Badge variant="outline">{contact.position}</Badge>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end space-y-2">
            {contact.phone && (
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <a href={`tel:${contact.phone}`} className="text-primary hover:underline">
                  {contact.phone}
                </a>
              </div>
            )}
            {contact.email && (
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <a href={`mailto:${contact.email}`} className="text-primary hover:underline text-sm">
                  {contact.email}
                </a>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Club Phone Directory</h1>
        <p className="text-muted-foreground">
          Complete contact directory for all club members - players, coaches, and parents
        </p>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Search & Filter Contacts
          </CardTitle>
          <CardDescription>
            Find specific members or filter by role and team
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="search">Search by name, phone, or email</Label>
              <Input
                id="search"
                placeholder="Search contacts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="role-filter">Role</Label>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger id="role-filter">
                  <SelectValue placeholder="All Roles" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="player">Players</SelectItem>
                  <SelectItem value="coach">Coaches</SelectItem>
                  <SelectItem value="parent">Parents</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="team-filter">Team</Label>
              <Select value={teamFilter} onValueChange={setTeamFilter}>
                <SelectTrigger id="team-filter">
                  <SelectValue placeholder="All Teams" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Teams</SelectItem>
                  {teams.map((team: any) => (
                    <SelectItem key={team.id} value={team.name}>
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={exportContacts} className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contact Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <UserCheck className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{playerContacts.length}</p>
                <p className="text-sm text-muted-foreground">Players</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-2xl font-bold">{coachContacts.length}</p>
                <p className="text-sm text-muted-foreground">Coaches</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Baby className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">{parentContacts.length}</p>
                <p className="text-sm text-muted-foreground">Parents</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contact Lists by Category */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Contacts ({filteredContacts.length})</TabsTrigger>
          <TabsTrigger value="players">Players ({playerContacts.length})</TabsTrigger>
          <TabsTrigger value="coaches">Coaches ({coachContacts.length})</TabsTrigger>
          <TabsTrigger value="parents">Parents ({parentContacts.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="space-y-4">
            {filteredContacts.length > 0 ? (
              filteredContacts.map((contact) => (
                <ContactCard key={`${contact.role}-${contact.id}`} contact={contact} />
              ))
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-muted-foreground">No contacts found matching your search criteria.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="players" className="mt-6">
          <div className="space-y-4">
            {playerContacts.length > 0 ? (
              playerContacts.map((contact) => (
                <ContactCard key={`player-${contact.id}`} contact={contact} />
              ))
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-muted-foreground">No players found.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="coaches" className="mt-6">
          <div className="space-y-4">
            {coachContacts.length > 0 ? (
              coachContacts.map((contact) => (
                <ContactCard key={`coach-${contact.id}`} contact={contact} />
              ))
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-muted-foreground">No coaches found.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="parents" className="mt-6">
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6 text-center">
                <Baby className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground mb-2">Parent contacts will be available soon!</p>
                <p className="text-sm text-muted-foreground">
                  This section will show parent contact information once the parent module is implemented.
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}