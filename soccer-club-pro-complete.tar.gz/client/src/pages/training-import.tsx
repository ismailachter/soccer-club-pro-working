import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Upload, Link, FileText, Globe, Download, Plus, Target, Users, Clock } from 'lucide-react';

const TrainingImport = () => {
  const [importType, setImportType] = useState('url');
  const [url, setUrl] = useState('');
  const [providerAuth, setProviderAuth] = useState({
    provider: '',
    username: '',
    password: '',
    apiKey: ''
  });
  const [manualTraining, setManualTraining] = useState({
    title: '',
    description: '',
    category: '',
    subcategory: '',
    theme: '',
    duration: '',
    players: '',
    content: '',
    source: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // IADATABANK categorieën en thema's
  const categories = {
    'BASICS': {
      subcategories: ['B+', 'B-'],
      themes: {
        'B+': ['Bal Leiden', 'Aanname', 'Passing', 'Scoren'],
        'B-': ['Tackelen', 'Interceptie', 'Markeren', 'Dekking']
      }
    },
    'TEAMTACTISCH': {
      subcategories: ['B+', 'B-', 'OMSCH. B+/B-', 'OMSCH. B-/B+'],
      themes: {
        'B+': ['Opbouwen', 'Voortgang & Infiltratie', 'Scoren'],
        'B-': ['Druk Zetten', 'Compact Verdedigen', 'Beschermen Eigen Doel'],
        'OMSCH. B+/B-': ['Onderbreek En Herover', 'Bescherm De Ruimte'],
        'OMSCH. B-/B+': ['Speel Uit De Druk', 'Verander Van Zijde']
      }
    },
    'FYSIEK': {
      subcategories: ['UITHOUDING', 'KRACHT', 'SNELHEID', 'LENIGHEID'],
      themes: {
        'UITHOUDING': ['Algemene uithouding', 'Snelheidsuithoudingsvermogen', 'Herstelvermogen', 'Krachtuithouding', 'Blessurepreventie'],
        'KRACHT': ['Spierkracht', 'Sprongkracht', 'Trapkracht', 'Duelkracht', 'Explosiviteit'],
        'SNELHEID': ['Reactiesnelheid', 'Startsnelheid', 'Versnellingsvermogen', 'Wendbaarheid tijdens sprint', 'Algemene snelheid'],
        'LENIGHEID': ['Natuurlijke lenigheid', 'Evenwichtscontrole', 'Oog-voet coördinatie', 'Loopcoördinatie', 'Bewegingscoördinatie']
      }
    },
    'MENTAAL': {
      subcategories: ['ALGEMEEN MENTAAL'],
      themes: {
        'ALGEMEEN MENTAAL': ['Concentratie & Focus', 'Motivatie & Zelfvertrouwen', 'Teamwork & Communicatie', 'Drukbeheersing & Stress Management']
      }
    }
  };

  const popularSources = [
    { name: 'TouchTight Soccer Coaching', url: 'https://www.touchtight.com/', hasAuth: false, description: 'Professionele training platform' },
    { name: 'UEFA Training Ground', url: 'https://www.uefa.com/training-ground/', hasAuth: false, description: 'Officiële UEFA trainingen' },
    { name: 'Soccer Coaching Pro', url: 'https://www.soccercoachingpro.com/', hasAuth: false, description: 'Coaching methoden en drills' },
    { name: 'The Coaching Manual', url: 'https://www.thecoachingmanual.com/', hasAuth: false, description: 'Training handboeken en guides' },
    { name: 'Soccer Coach Weekly', url: 'https://www.soccercoachweekly.net/', hasAuth: false, description: 'Wekelijkse training tips' },
    { name: 'Coaches Voice', url: 'https://www.coachesvoice.com/', hasAuth: false, description: 'Professionele coach interviews' },
    { name: 'Football Study', url: 'https://www.football-study.com/', hasAuth: false, description: 'Tactische analyse en training' }
  ];

  const handleUrlImport = async () => {
    if (!url.trim()) {
      toast({
        title: "URL vereist",
        description: "Voer een geldige URL in van de training",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/import-training', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url, type: 'url' })
      });
      
      const result = await response.json();

      if (result.success) {
        toast({
          title: "Training geïmporteerd",
          description: `Training "${result.training.title}" succesvol toegevoegd`,
        });
        setUrl('');
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      toast({
        title: "Import mislukt",
        description: error.message || "Kon training niet importeren van deze URL",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleManualImport = async () => {
    if (!manualTraining.title.trim() || !manualTraining.category) {
      toast({
        title: "Vereiste velden",
        description: "Vul minimaal de titel en categorie in",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/import-training', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...manualTraining, type: 'manual' })
      });
      
      const result = await response.json();

      if (result.success) {
        toast({
          title: "Training toegevoegd",
          description: `Training "${manualTraining.title}" succesvol toegevoegd`,
        });
        setManualTraining({
          title: '', description: '', category: '', subcategory: '', 
          theme: '', duration: '', players: '', content: '', source: ''
        });
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      toast({
        title: "Toevoegen mislukt",
        description: error.message || "Kon training niet toevoegen",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Training Import</h1>
          <p className="text-gray-600 mt-2">Importeer trainingen van externe websites en integreer ze in je IADATABANK thema's</p>
        </div>
      </div>

      {/* Import Methods */}
      <Tabs value={importType} onValueChange={setImportType} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="url" className="flex items-center gap-2">
            <Link className="h-4 w-4" />
            URL Import
          </TabsTrigger>
          <TabsTrigger value="provider" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            TouchTight Import
          </TabsTrigger>
          <TabsTrigger value="manual" className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Handmatig Toevoegen
          </TabsTrigger>
          <TabsTrigger value="bulk" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Bulk Import
          </TabsTrigger>
        </TabsList>

        {/* URL Import */}
        <TabsContent value="url" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-blue-600" />
                Website URL Import
              </CardTitle>
              <CardDescription>
                Plak de URL van een training van externe websites. Het systeem probeert automatisch de training inhoud te extraheren.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="training-url">Training URL</Label>
                <Input
                  id="training-url"
                  placeholder="https://www.uefa.com/training-ground/..."
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                />
              </div>
              
              <Button 
                onClick={handleUrlImport} 
                disabled={isLoading || !url.trim()}
                className="w-full"
              >
                {isLoading ? 'Importeren...' : 'Training Importeren'}
              </Button>
            </CardContent>
          </Card>

          {/* Popular Sources */}
          <Card>
            <CardHeader>
              <CardTitle>Populaire Training Websites</CardTitle>
              <CardDescription>Klik op een website om deze te bezoeken en trainingen te vinden</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {popularSources.map((source, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex flex-col">
                      <span className="font-medium">{source.name}</span>
                      <span className="text-xs text-gray-500">{source.description}</span>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => window.open(source.url, '_blank')}
                    >
                      <Globe className="h-4 w-4 mr-2" />
                      Bezoeken
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TouchTight Import */}
        <TabsContent value="provider" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-green-600" />
                TouchTight Soccer Coaching Import
              </CardTitle>
              <CardDescription>
                Kopieer trainingen van je TouchTight lidmaatschap en voeg ze toe aan jouw IADATABANK
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="font-medium text-green-800 mb-2">Hoe werkt het?</h4>
                <ol className="text-sm text-green-700 space-y-1 list-decimal list-inside">
                  <li>Log in op je TouchTight Soccer Coaching account</li>
                  <li>Ga naar een training die je wilt importeren</li>
                  <li>Kopieer de training inhoud (titel, beschrijving, oefeningen)</li>
                  <li>Plak de gegevens hieronder in het formulier</li>
                  <li>Kies de juiste IADATABANK categorie en thema</li>
                  <li>Voeg toe aan jouw eigen training database</li>
                </ol>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="touchtight-title">Training Titel</Label>
                  <Input
                    id="touchtight-title"
                    placeholder="Bijv. Passing under pressure"
                    value={manualTraining.title}
                    onChange={(e) => setManualTraining(prev => ({ ...prev, title: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="touchtight-duration">Duur (minuten)</Label>
                  <Input
                    id="touchtight-duration"
                    type="number"
                    placeholder="30"
                    value={manualTraining.duration}
                    onChange={(e) => setManualTraining(prev => ({ ...prev, duration: e.target.value }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>IADATABANK Categorie</Label>
                  <Select value={manualTraining.category} onValueChange={(value) => {
                    setManualTraining(prev => ({ ...prev, category: value, subcategory: '', theme: '' }));
                  }}>
                    <SelectTrigger>
                      <SelectValue placeholder="Kies categorie" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(categories).map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {manualTraining.category && (
                  <div className="space-y-2">
                    <Label>Subcategorie</Label>
                    <Select value={manualTraining.subcategory} onValueChange={(value) => {
                      setManualTraining(prev => ({ ...prev, subcategory: value, theme: '' }));
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Kies subcategorie" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories[manualTraining.category as keyof typeof categories]?.subcategories.map((subcat) => (
                          <SelectItem key={subcat} value={subcat}>{subcat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {manualTraining.subcategory && (
                  <div className="space-y-2">
                    <Label>Thema</Label>
                    <Select value={manualTraining.theme} onValueChange={(value) => {
                      setManualTraining(prev => ({ ...prev, theme: value }));
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Kies thema" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories[manualTraining.category as keyof typeof categories]?.themes[manualTraining.subcategory]?.map((theme) => (
                          <SelectItem key={theme} value={theme}>{theme}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="touchtight-content">Training Inhoud (van TouchTight)</Label>
                <Textarea
                  id="touchtight-content"
                  placeholder="Plak hier de volledige training inhoud van TouchTight:&#10;&#10;- Setup/opstelling&#10;- Oefening beschrijving&#10;- Coaching points&#10;- Variaties&#10;- etc."
                  value={manualTraining.content}
                  onChange={(e) => setManualTraining(prev => ({ ...prev, content: e.target.value }))}
                  rows={8}
                />
              </div>

              <Button 
                onClick={handleManualImport} 
                disabled={isLoading || !manualTraining.title.trim() || !manualTraining.category || !manualTraining.content.trim()}
                className="w-full"
              >
                {isLoading ? 'Toevoegen...' : 'TouchTight Training Toevoegen'}
              </Button>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h4 className="font-medium text-yellow-800 mb-2">Belangrijk</h4>
                <p className="text-sm text-yellow-700">
                  Respecteer de auteursrechten van TouchTight. Deze functie is bedoeld voor persoonlijk gebruik binnen je eigen club.
                  De trainingen blijven eigendom van TouchTight Soccer Coaching.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Manual Import */}
        <TabsContent value="manual" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-green-600" />
                Handmatig Training Toevoegen
              </CardTitle>
              <CardDescription>
                Voeg een training handmatig toe door alle details in te vullen
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Training Titel *</Label>
                  <Input
                    id="title"
                    placeholder="Bijv. 4v4 Positiespel"
                    value={manualTraining.title}
                    onChange={(e) => setManualTraining(prev => ({ ...prev, title: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="source">Bron Website</Label>
                  <Input
                    id="source"
                    placeholder="Bijv. UEFA Training Ground"
                    value={manualTraining.source}
                    onChange={(e) => setManualTraining(prev => ({ ...prev, source: e.target.value }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Categorie *</Label>
                  <Select value={manualTraining.category} onValueChange={(value) => {
                    setManualTraining(prev => ({ ...prev, category: value, subcategory: '', theme: '' }));
                  }}>
                    <SelectTrigger>
                      <SelectValue placeholder="Kies categorie" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(categories).map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {manualTraining.category && (
                  <div className="space-y-2">
                    <Label htmlFor="subcategory">Subcategorie</Label>
                    <Select value={manualTraining.subcategory} onValueChange={(value) => {
                      setManualTraining(prev => ({ ...prev, subcategory: value, theme: '' }));
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Kies subcategorie" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories[manualTraining.category as keyof typeof categories]?.subcategories.map((subcat) => (
                          <SelectItem key={subcat} value={subcat}>{subcat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {manualTraining.subcategory && (
                  <div className="space-y-2">
                    <Label htmlFor="theme">Thema</Label>
                    <Select value={manualTraining.theme} onValueChange={(value) => {
                      setManualTraining(prev => ({ ...prev, theme: value }));
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Kies thema" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories[manualTraining.category as keyof typeof categories]?.themes[manualTraining.subcategory]?.map((theme) => (
                          <SelectItem key={theme} value={theme}>{theme}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration" className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Duur (minuten)
                  </Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="20"
                    value={manualTraining.duration}
                    onChange={(e) => setManualTraining(prev => ({ ...prev, duration: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="players" className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Aantal Spelers
                  </Label>
                  <Input
                    id="players"
                    placeholder="16"
                    value={manualTraining.players}
                    onChange={(e) => setManualTraining(prev => ({ ...prev, players: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Beschrijving</Label>
                <Textarea
                  id="description"
                  placeholder="Korte beschrijving van de training..."
                  value={manualTraining.description}
                  onChange={(e) => setManualTraining(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">Training Inhoud</Label>
                <Textarea
                  id="content"
                  placeholder="Gedetailleerde uitleg van de oefeningen, regels, coaching points..."
                  value={manualTraining.content}
                  onChange={(e) => setManualTraining(prev => ({ ...prev, content: e.target.value }))}
                  rows={6}
                />
              </div>

              <Button 
                onClick={handleManualImport} 
                disabled={isLoading || !manualTraining.title.trim() || !manualTraining.category}
                className="w-full"
              >
                {isLoading ? 'Toevoegen...' : 'Training Toevoegen'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Bulk Import */}
        <TabsContent value="bulk" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5 text-purple-600" />
                Bulk Import (Toekomstig)
              </CardTitle>
              <CardDescription>
                Upload een CSV bestand met meerdere trainingen tegelijk
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center p-8 border-2 border-dashed border-gray-300 rounded-lg">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">Bulk import functionaliteit</p>
                <p className="text-sm text-gray-500">Wordt binnenkort toegevoegd</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Integration Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-blue-600" />
            Integratie met IADATABANK
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(categories).map(([category, info]) => (
              <div key={category} className="p-4 border rounded-lg">
                <h4 className="font-semibold text-lg mb-2">{category}</h4>
                <div className="space-y-1">
                  {info.subcategories.map((subcat) => (
                    <Badge key={subcat} variant="outline" className="mr-1 mb-1">
                      {subcat}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <p className="text-sm text-gray-600 mt-4">
            Geïmporteerde trainingen worden automatisch gekoppeld aan de juiste IADATABANK categorieën en kunnen gebruikt worden in je jaarplanning en kalender.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default TrainingImport;