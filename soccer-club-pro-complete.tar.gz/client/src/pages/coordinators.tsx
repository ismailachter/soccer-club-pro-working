import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Mail, Phone, Eye, Edit, MoreHorizontal, Plus, Users } from "lucide-react";
import { Coordinator } from "@/types";
import { AvatarUpload } from "@/components/ui/avatar-upload";

export default function Coordinators() {
  const [isAddCoordinatorOpen, setIsAddCoordinatorOpen] = useState(false);
  const [viewCoordinator, setViewCoordinator] = useState<Coordinator | null>(null);
  
  // Fetch coordinators data
  const { data: coordinators, isLoading, error } = useQuery<Coordinator[]>({
    queryKey: ['/api/coordinators'],
  });

  // Define columns for data table
  const columns = [
    {
      header: "Name",
      accessorKey: "user",
      cell: (coordinator: Coordinator) => (
        <div className="flex items-center">
          <div className="h-10 w-10 flex-shrink-0 rounded-full bg-secondary-200">
            {coordinator.user?.profileImage && (
              <img 
                src={coordinator.user.profileImage} 
                alt={`${coordinator.user?.firstName} ${coordinator.user?.lastName}`}
                className="h-full w-full rounded-full object-cover"
              />
            )}
          </div>
          <div className="ml-4">
            <div className="font-medium text-foreground">
              {coordinator.user?.firstName} {coordinator.user?.lastName}
            </div>
            <div className="text-muted-foreground">{coordinator.responsibilities || ''}</div>
          </div>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Contact",
      accessorKey: "user.email",
      cell: (coordinator: Coordinator) => (
        <div>
          <div className="flex items-center text-foreground">
            <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
            {coordinator.user?.email}
          </div>
          {coordinator.user?.phone && (
            <div className="flex items-center text-foreground mt-1">
              <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
              {coordinator.user.phone}
            </div>
          )}
        </div>
      ),
      sortable: true,
    },
    {
      header: "Responsibilities",
      accessorKey: "responsibilities",
      cell: (coordinator: Coordinator) => coordinator.responsibilities || 'N/A',
      sortable: true,
    },
    {
      header: "Start Date",
      accessorKey: "startDate",
      cell: (coordinator: Coordinator) => coordinator.startDate ? 
        new Date(coordinator.startDate).toLocaleDateString() : 'N/A',
      sortable: true,
    },
    {
      header: "Assigned Teams",
      accessorKey: "assignedTeams",
      cell: (coordinator: Coordinator) => {
        const teamCount = coordinator.assignedTeams?.length || 0;
        return (
          <div className="flex flex-wrap gap-1">
            <Badge variant="outline">{teamCount} teams</Badge>
          </div>
        );
      },
      sortable: true,
    },
    {
      header: "Actions",
      accessorKey: "actions",
      cell: (coordinator: Coordinator) => (
        <div className="flex space-x-1">
          <Button variant="outline" size="sm" onClick={() => setViewCoordinator(coordinator)}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm">
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      ),
      sortable: false,
    },
  ];

  if (isLoading) {
    return <div className="p-8 text-center">Loading coordinators...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading coordinators.</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Coordinators</h2>
          <p className="text-muted-foreground">
            Manage club coordinators and their responsibilities
          </p>
        </div>
        <Dialog open={isAddCoordinatorOpen} onOpenChange={setIsAddCoordinatorOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Coordinator
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Add New Coordinator</DialogTitle>
              <DialogDescription>
                Enter the coordinator details below to create a new coordinator record.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
              <div className="flex flex-col items-center justify-center">
                <AvatarUpload 
                  onUpload={(file) => console.log('File uploaded:', file)}
                  size="lg"
                />
              </div>
              <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" placeholder="First Name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" placeholder="Last Name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="Email" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" type="tel" placeholder="Phone Number" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input id="dateOfBirth" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input id="startDate" type="date" />
                </div>
                <div className="space-y-2 col-span-full">
                  <Label htmlFor="responsibilities">Responsibilities</Label>
                  <Textarea id="responsibilities" placeholder="Describe their main responsibilities..." rows={3} />
                </div>
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsAddCoordinatorOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">
                Save Coordinator
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Coordinators cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {coordinators?.map((coordinator) => (
          <Card key={coordinator.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center mb-4">
                <div className="h-16 w-16 rounded-full bg-secondary-200 mb-3 overflow-hidden">
                  {coordinator.user?.profileImage ? (
                    <img 
                      src={coordinator.user.profileImage} 
                      alt={`${coordinator.user?.firstName} ${coordinator.user?.lastName}`}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center">
                      <Users className="h-8 w-8 text-muted-foreground" />
                    </div>
                  )}
                </div>
                <h3 className="text-lg font-semibold text-foreground">
                  {coordinator.user?.firstName} {coordinator.user?.lastName}
                </h3>
                <p className="text-sm text-primary soccer-text-gradient font-medium">
                  {coordinator.responsibilities || 'Coordinator'}
                </p>
              </div>

              <div className="space-y-2 text-sm mb-4">
                <div className="flex items-center">
                  <Mail className="h-4 w-4 text-muted-foreground mr-2" />
                  <span>{coordinator.user?.email}</span>
                </div>
                {coordinator.user?.phone && (
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 text-muted-foreground mr-2" />
                    <span>{coordinator.user.phone}</span>
                  </div>
                )}
                {coordinator.startDate && (
                  <div className="flex items-center">
                    <Users className="h-4 w-4 text-muted-foreground mr-2" />
                    <span>Since {new Date(coordinator.startDate).toLocaleDateString()}</span>
                  </div>
                )}
              </div>
              
              <div className="flex justify-end">
                <Button size="sm" onClick={() => setViewCoordinator(coordinator)}>View Profile</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Coordinators table */}
      <h3 className="text-lg font-medium mb-4">All Coordinators</h3>
      <DataTable
        data={coordinators || []}
        columns={columns}
        searchable={true}
        searchKey="user.lastName"
      />

      {/* Coordinator detail dialog */}
      {viewCoordinator && (
        <Dialog open={!!viewCoordinator} onOpenChange={() => setViewCoordinator(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Coordinator Profile</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
              <div className="flex flex-col items-center space-y-4">
                <div className="h-32 w-32 rounded-full bg-secondary-200 overflow-hidden">
                  {viewCoordinator.user?.profileImage ? (
                    <img 
                      src={viewCoordinator.user.profileImage} 
                      alt={`${viewCoordinator.user?.firstName} ${viewCoordinator.user?.lastName}`}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center">
                      <Users className="h-16 w-16 text-muted-foreground" />
                    </div>
                  )}
                </div>
                <Badge variant="outline" className="text-primary">
                  Coordinator
                </Badge>
              </div>
              
              <div className="md:col-span-2 space-y-4">
                <div>
                  <h3 className="text-xl font-semibold text-foreground">
                    {viewCoordinator.user?.firstName} {viewCoordinator.user?.lastName}
                  </h3>
                  <p className="text-muted-foreground">{viewCoordinator.responsibilities || 'No specific responsibilities listed'}</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Email</h4>
                    <p>{viewCoordinator.user?.email}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Phone</h4>
                    <p>{viewCoordinator.user?.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Start Date</h4>
                    <p>{viewCoordinator.startDate ? new Date(viewCoordinator.startDate).toLocaleDateString() : 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Assigned Teams</h4>
                    <p>{viewCoordinator.assignedTeams?.length || 0} teams</p>
                  </div>
                  {viewCoordinator.children && (
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground">Children</h4>
                      <p>{viewCoordinator.children}</p>
                    </div>
                  )}
                  {viewCoordinator.siblings && (
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground">Siblings</h4>
                      <p>{viewCoordinator.siblings}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}