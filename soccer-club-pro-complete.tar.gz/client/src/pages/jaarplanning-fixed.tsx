import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Plus, Edit, Trash2, Download, Eye, Users, BookOpen, MapPin, Clock, Database } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { format, addDays, startOfWeek, isSameDay, getWeek } from "date-fns";
import { nl } from "date-fns/locale";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import "jspdf-autotable";

interface TrainingPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  sessionsPerWeek: number;
  trainingDays: string[];
  createdAt: string;
}

interface TrainingSession {
  id?: number;
  planId: number;
  week: number;
  session: number;
  date: string;
  duration: number;
  focusArea: string;
  assignedThemes: string[];
  assignedElements: string[];
  iadatabankElements: {
    basics: string[];
    teamtactisch: string[];
    mentaal: string[];
    fysiek: string[];
    omschakeling: string[];
  };
  selectedCategoryElements: {[key: string]: string[]};
  selectedElementThemes: {[key: string]: string};
  objectives: string[];
  notes: string;
}

interface NewPlanForm {
  name: string;
  description: string;
  ageGroup: string;
  teamId: number | null;
  season: string;
  startDate: string;
  endDate: string;
  sessionsPerWeek: number;
  trainingDays: string[];
}

export default function Jaarplanning() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [plans, setPlans] = useState<TrainingPlan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<TrainingPlan | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingPlan, setEditingPlan] = useState<TrainingPlan | null>(null);
  const [selectedTeamFilter, setSelectedTeamFilter] = useState<string>("all");
  const [sessions, setSessions] = useState<TrainingSession[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [sessionNotes, setSessionNotes] = useState<string>("");
  const [showCategoryElements, setShowCategoryElements] = useState<string | null>(null);
  const [selectedCategoryElements, setSelectedCategoryElements] = useState<{[key: string]: string[]}>({});
  const [selectedElementThemes, setSelectedElementThemes] = useState<{[key: string]: string}>({});
  
  // Authentieke thema's gebaseerd op IADATABANK elementen
  const getAvailableThemes = (topicName: string): string[] => {
    const themesByTopic: Record<string, string[]> = {
      "BASICS B+": [
        "Leiden van de bal", "Dribbelen", "Passing", "Balcontrole", "Schieten", 
        "Scoren", "Vrijlopen", "Balbehandeling", "Techniek onder druk"
      ],
      "BASICS B-": [
        "Druk zetten", "Tackle", "Remmen", "Dekken", "Interceptie", 
        "Afweren", "Positie tussen linies", "Strikte dekking", "Ontvluchten"
      ],
      "TEAMTACTISCH B+": [
        "Driehoeken vormen", "Creëer ruimte", "Opbouw van achteruit", "Combinatiespel", 
        "Aanvalsorganisatie", "Breedte creëren", "Diepgang zoeken", "Switchen van spel", 
        "Overlappen", "Ondersteunend spel", "Timing van loopacties"
      ],
      "TEAMTACTISCH B-": [
        "Druk zetten", "Compact verdedigen", "Pressing", "Gegenpressing", "Defensive block", 
        "Offside trap", "Zone verdedigen", "Man marking", "Dubbele dekking", 
        "Verdedigende communicatie", "Clearing", "Defensive positioning"
      ],
      "MENTAAL": [
        "Concentratie", "Zelfvertrouwen", "Doorzettingsvermogen", "Motivatie", 
        "Stressbestendigheid", "Communicatie", "Leiderschap", "Teamwork", 
        "Discipline", "Mentale voorbereiding", "Positieve instelling"
      ],
      "FYSIEK": [
        "Uithouding", "Snelheid", "Kracht", "Lenigheid", "Coördinatie", 
        "Reactiesnelheid", "Explosiviteit", "Wendbaarheid", "Evenwicht", 
        "Handelingssnelheid", "Ritme", "Looptechniek"
      ],
      "OMSCHAKELING B+": [
        "Tegenaanval", "Op balbezit spelen", "Snelle omschakeling naar aanval", 
        "Positie innemen aanval", "Counter-pressing", "Snelle opbouw"
      ],
      "OMSCHAKELING B-": [
        "Tegen druk zetten", "Hervormen opstelling", "Defensieve transitie", 
        "Balverovering organisatie", "Compacte organisatie", "Pressing resistance"
      ]
    };
    
    return themesByTopic[topicName] || [
      "Basis ontwikkeling", "Technische verbetering", "Tactische groei", 
      "Fysieke vooruitgang", "Mentale sterkte", "Teamspel"
    ];
  };
  
  // Authentieke IADATABANK elementen uit backup - 6 progressieve niveaus
  const categoryElements = {
    "BASICS B+": {
      "Leiden van de bal": [
        "1. Eenvoudig bal leiden",
        "2. Gericht bal leiden", 
        "3. Gericht snel bal leiden",
        "4. Blind gericht snel bal leiden",
        "5. Onder druk blind gericht snel bal leiden",
        "6. Onder druk blind gericht snel bal leiden én actie"
      ],
      "Dribbelen met de bal": [
        "1. Eenvoudig dribbelen/Tricks",
        "2. Gericht dribbelen/Tricks",
        "3. Gericht snel dribbelen", 
        "4. Gericht snel dribbelen op het juiste moment",
        "5. Gericht snel dribbelen onder druk",
        "6. Gericht snel dribbelen onder druk en actie"
      ],
      "Korte Passing": [
        "1. Korte pass juiste richting",
        "2. Korte pass binnenkant voet",
        "3. Gericht korte pass",
        "4. Timing korte pass",
        "5. Korte pass onder druk",
        "6. Korte pass onder druk met vervolgactie"
      ],
      "Middellange Passing": [
        "1. Middellange pass basis",
        "2. Middellange pass precisie",
        "3. Middellange pass snelheid",
        "4. Middellange pass timing",
        "5. Middellange pass onder druk",
        "6. Middellange pass onder druk met vervolgactie"
      ],
      "Lange Passing": [
        "1. Lange pass basis",
        "2. Lange pass precisie",
        "3. Lange pass met kracht",
        "4. Lange pass perfecte timing",
        "5. Lange pass onder druk",
        "6. Lange pass onder druk met vervolgactie"
      ],
      "Passing met het hoofd": [
        "1. Basis kopbal passing",
        "2. Gerichte kopbal passing",
        "3. Snelle kopbal passing",
        "4. Timing kopbal passing",
        "5. Kopbal passing onder druk",
        "6. Kopbal passing onder druk met vervolgactie"
      ],
      "1 tijd Passing, Kaatsen": [
        "1. Eenvoudig kaatsen",
        "2. Gericht kaatsen",
        "3. Snel kaatsen",
        "4. Timing 1-tijd passing",
        "5. Kaatsen onder druk",
        "6. Kaatsen onder druk met vervolgactie"
      ],
      "Balcontrole Korte Pass": [
        "1. Eenvoudige balcontrole korte pass",
        "2. Gerichte balcontrole korte pass",
        "3. Snelle balcontrole korte pass",
        "4. Timing balcontrole korte pass",
        "5. Balcontrole korte pass onder druk",
        "6. Balcontrole korte pass onder druk met vervolgactie"
      ],
      "Balcontrole Middellange Pass": [
        "1. Eenvoudige balcontrole middellange pass",
        "2. Gerichte balcontrole middellange pass",
        "3. Snelle balcontrole middellange pass",
        "4. Timing balcontrole middellange pass",
        "5. Balcontrole middellange pass onder druk",
        "6. Balcontrole middellange pass onder druk met vervolgactie"
      ],
      "Balcontrole Lange Pass": [
        "1. Eenvoudige balcontrole lange pass",
        "2. Gerichte balcontrole lange pass",
        "3. Snelle balcontrole lange pass",
        "4. Timing balcontrole lange pass",
        "5. Balcontrole lange pass onder druk",
        "6. Balcontrole lange pass onder druk met vervolgactie"
      ],
      "Schieten op doel": [
        "1. Eenvoudig schieten",
        "2. Gericht schieten",
        "3. Snel schieten",
        "4. Timing schieten",
        "5. Schieten onder druk",
        "6. Schieten onder druk met vervolgactie"
      ],
      "Scoren met de voet": [
        "1. Eenvoudig scoren met voet",
        "2. Gericht scoren met voet",
        "3. Snel scoren met voet",
        "4. Timing scoren met voet",
        "5. Scoren met voet onder druk",
        "6. Scoren met voet onder druk met vervolgactie"
      ],
      "Scoren met het hoofd": [
        "1. Eenvoudig scoren met hoofd",
        "2. Gericht scoren met hoofd",
        "3. Snel scoren met hoofd",
        "4. Timing scoren met hoofd",
        "5. Scoren met hoofd onder druk",
        "6. Scoren met hoofd onder druk met vervolgactie"
      ],
      "Scoren na individuele actie trucks": [
        "1. Eenvoudig scoren na individuele actie",
        "2. Gericht scoren na individuele actie",
        "3. Snel scoren na individuele actie",
        "4. Timing scoren na individuele actie",
        "5. Scoren na individuele actie onder druk",
        "6. Scoren na individuele actie onder druk met vervolgactie"
      ],
      "Vrijlopen aanspeelbaar zijn": [
        "1. Eenvoudig vrijlopen",
        "2. Gericht vrijlopen naar ruimte",
        "3. Snel vrijlopen bij balwisseling",
        "4. Timing vrijlopen met medespeler",
        "5. Vrijlopen onder dekking",
        "6. Creatief vrijlopen met verrassingseffect"
      ]
    },
    "BASICS B-": {
      "Druk zetten tackle remmen": [
        "1. Eenvoudig druk zetten",
        "2. Gericht druk zetten met steun",
        "3. Snel druk zetten bij balverlies",
        "4. Timing druk zetten en tackle",
        "5. Druk zetten onder tegenaanval",
        "6. Intelligente druk met anticipatie"
      ],
      "Duel": [
        "1. Basis 1v1 duel",
        "2. Gericht lichaamsgebruik in duel",
        "3. Snel reageren in duel",
        "4. Timing bij duel winnen",
        "5. Duel onder druk volhouden",
        "6. Creatief duel winnen met techniek"
      ],
      "Interceptie balcontrole korte passing": [
        "1. Eenvoudige interceptie korte passing",
        "2. Gerichte interceptie korte passing lijnen",
        "3. Snelle interceptie korte passing",
        "4. Timing interceptie korte passing",
        "5. Interceptie korte passing onder druk",
        "6. Proactieve interceptie korte passing"
      ],
      "Interceptie balcontrole middellange passing": [
        "1. Eenvoudige interceptie middellange passing",
        "2. Gerichte interceptie middellange passing lijnen",
        "3. Snelle interceptie middellange passing",
        "4. Timing interceptie middellange passing",
        "5. Interceptie middellange passing onder druk",
        "6. Proactieve interceptie middellange passing"
      ],
      "Interceptie balcontrole lange passing": [
        "1. Eenvoudige interceptie lange passing",
        "2. Gerichte interceptie lange passing lijnen",
        "3. Snelle interceptie lange passing",
        "4. Timing interceptie lange passing",
        "5. Interceptie lange passing onder druk",
        "6. Proactieve interceptie lange passing"
      ],
      "Interceptie balcontrole kopbal": [
        "1. Eenvoudige interceptie kopbal",
        "2. Gerichte interceptie kopbal lijnen",
        "3. Snelle interceptie kopbal",
        "4. Timing interceptie kopbal",
        "5. Interceptie kopbal onder druk",
        "6. Proactieve interceptie kopbal"
      ],
      "Interceptie balcontrole kaatsbal": [
        "1. Eenvoudige interceptie kaatsbal",
        "2. Gerichte interceptie kaatsbal lijnen",
        "3. Snelle interceptie kaatsbal",
        "4. Timing interceptie kaatsbal",
        "5. Interceptie kaatsbal onder druk",
        "6. Proactieve interceptie kaatsbal"
      ],
      "Interceptie na balcontrole korte pass": [
        "1. Eenvoudige interceptie na balcontrole korte pass",
        "2. Gerichte interceptie na balcontrole korte pass",
        "3. Snelle interceptie na balcontrole korte pass",
        "4. Timing interceptie na balcontrole korte pass",
        "5. Interceptie na balcontrole korte pass onder druk",
        "6. Proactieve interceptie na balcontrole korte pass"
      ],
      "Interceptie na balcontrole middellange pass": [
        "1. Eenvoudige interceptie na balcontrole middellange pass",
        "2. Gerichte interceptie na balcontrole middellange pass",
        "3. Snelle interceptie na balcontrole middellange pass",
        "4. Timing interceptie na balcontrole middellange pass",
        "5. Interceptie na balcontrole middellange pass onder druk",
        "6. Proactieve interceptie na balcontrole middellange pass"
      ],
      "Interceptie na balcontrole lange pass": [
        "1. Eenvoudige interceptie na balcontrole lange pass",
        "2. Gerichte interceptie na balcontrole lange pass",
        "3. Snelle interceptie na balcontrole lange pass",
        "4. Timing interceptie na balcontrole lange pass",
        "5. Interceptie na balcontrole lange pass onder druk",
        "6. Proactieve interceptie na balcontrole lange pass"
      ],
      "Afweren schieten beletten": [
        "1. Eenvoudig schieten beletten",
        "2. Gericht blokkeren schoten",
        "3. Snel reageren op schoten",
        "4. Timing bij afweren",
        "5. Afweren onder scoringsdruk",
        "6. Creatief afweren met hervattingscontrole"
      ],
      "Afweren scoren voet beletten": [
        "1. Eenvoudig scoren voet beletten",
        "2. Gericht blokkeren scoren voet",
        "3. Snel reageren op scoren voet",
        "4. Timing bij afweren scoren voet",
        "5. Afweren scoren voet onder druk",
        "6. Creatief afweren scoren voet met hervattingscontrole"
      ],
      "Afweren scoren hoofd beletten": [
        "1. Eenvoudig scoren hoofd beletten",
        "2. Gericht blokkeren scoren hoofd",
        "3. Snel reageren op scoren hoofd",
        "4. Timing bij afweren scoren hoofd",
        "5. Afweren scoren hoofd onder druk",
        "6. Creatief afweren scoren hoofd met hervattingscontrole"
      ],
      "Afweren scoren individuele actie beletten": [
        "1. Eenvoudig scoren individuele actie beletten",
        "2. Gericht blokkeren scoren individuele actie",
        "3. Snel reageren op scoren individuele actie",
        "4. Timing bij afweren scoren individuele actie",
        "5. Afweren scoren individuele actie onder druk",
        "6. Creatief afweren scoren individuele actie met hervattingscontrole"
      ],
      "Speelhoeken afsluiten": [
        "1. Eenvoudig hoeken afsluiten",
        "2. Gericht positioneren bij hoeken",
        "3. Snel verschuiven naar hoeken",
        "4. Timing bij hoek afsluiting",
        "5. Hoeken afsluiten onder druk",
        "6. Intelligente hoek afsluiting met communicatie"
      ],
      "Strikte dekking": [
        "1. Eenvoudige man-op-man dekking",
        "2. Gerichte strikte dekking gevaarlijke spelers",
        "3. Snelle aanpassing strikte dekking",
        "4. Timing bij strikte dekking",
        "5. Strikte dekking onder aanvallende druk",
        "6. Flexibele strikte dekking met omschakeling"
      ],
      "Rugdekking": [
        "1. Eenvoudige rugdekking medespelers",
        "2. Gerichte rugdekking bij gevaar",
        "3. Snelle rugdekking bij doorbraken",
        "4. Timing rugdekking met communicatie",
        "5. Rugdekking onder hoge druk",
        "6. Proactieve rugdekking met anticipatie"
      ]
    },
    "TEAMTACTISCH B+": {
      "Opbouwen vanaf achteren": [
        "1. Eenvoudig opbouwen vanaf keeper",
        "2. Gericht opbouwen via korte passing",
        "3. Snel opbouwen onder druk",
        "4. Timing in opbouwfases",
        "5. Opbouwen onder hoge druk",
        "6. Opbouwen onder druk met creatieve oplossingen"
      ],
      "Vooruitgang creëren": [
        "1. Basis vooruitgang via passing",
        "2. Gerichte vooruitgang via flanken",
        "3. Snelle vooruitgang via diepte",
        "4. Timing vooruitgang met loopacties",
        "5. Vooruitgang onder defensieve druk",
        "6. Vooruitgang met creatieve combinaties"
      ],
      "Infiltratie": [
        "1. Eenvoudige infiltratie laatste lijn",
        "2. Gerichte infiltratie via loopacties",
        "3. Snelle infiltratie met timing",
        "4. Gecoördineerde infiltratie bewegingen",
        "5. Infiltratie onder compacte defensie",
        "6. Creatieve infiltratie met verrassingseffect"
      ],
      "Doelpunten maken": [
        "1. Eenvoudige afronding in de 16",
        "2. Gerichte afronding verschillende hoeken",
        "3. Snelle afronding onder druk",
        "4. Timing bij voorzetten en rebounds",
        "5. Afronding onder verdedigende druk",
        "6. Creatieve afronding in moeilijke situaties"
      ],
      "Positiespel": [
        "1. Basis positie innemen",
        "2. Gericht positioneren volgens systeem",
        "3. Snel positioneren bij balwisseling",
        "4. Timing in positiewisselingen",
        "5. Positiespel onder druk handhaven",
        "6. Adaptief positiespel met improvisatie"
      ],
      "Creëer ruimte": [
        "1. Basis ruimte creëren door beweging",
        "2. Gericht ruimte maken voor medespelers",
        "3. Snel ruimte benutten met loopacties",
        "4. Timing ruimte creëren met combinaties",
        "5. Ruimte creëren onder defensieve druk",
        "6. Creatieve ruimte met verrassende bewegingen"
      ]
    },
    "TEAMTACTISCH B-": {
      "Druk zetten": [
        "1. Eenvoudig druk zetten op baldrager",
        "2. Gericht druk zetten met steun",
        "3. Snel druk zetten bij balverlies",
        "4. Timing druk zetten met ploegmaten",
        "5. Druk zetten onder tegenaanval",
        "6. Intelligente druk met anticipatie"
      ],
      "Compact verdedigen": [
        "1. Basis compacte organisatie",
        "2. Gerichte compacte blok formatie",
        "3. Snel sluiten van ruimtes",
        "4. Timing bij compact schuiven",
        "5. Compact blijven onder druk",
        "6. Flexibel compact spel met aanpassingen"
      ],
      "Beschermen van het doel": [
        "1. Eenvoudige doelverdediging",
        "2. Gerichte bescherming gevaarlijke zones",
        "3. Snelle recovery naar doel",
        "4. Timing bij verdedigende acties",
        "5. Doelbescherming onder hoge druk",
        "6. Creatieve doelverdediging met risicomanagement"
      ],
      "Pressing": [
        "1. Basis pressing eerste lijn",
        "2. Gericht pressing met structuur",
        "3. Snel pressing na signaal",
        "4. Timing pressing met medespelers",
        "5. Pressing onder tegendruk",
        "6. Adaptief pressing met val en herstel"
      ],
      "Verdedigende organisatie": [
        "1. Basis verdedigende structuur",
        "2. Gerichte organisatie per zone",
        "3. Snelle reorganisatie na balverlies",
        "4. Timing in verdedigende verschuivingen",
        "5. Organisatie onder aanvallende druk",
        "6. Dynamische organisatie met communicatie"
      ],
      "Intercepteren": [
        "1. Eenvoudige interceptie",
        "2. Gerichte interceptie op passing lijnen",
        "3. Snelle interceptie met anticipatie",
        "4. Timing interceptie met teamwerk",
        "5. Interceptie onder aanvallende druk",
        "6. Proactieve interceptie met voorspelling"
      ]
    },
    "MENTAAL": {
      "Concentratie": [
        "1. Basis concentratie",
        "2. Gerichte concentratie",
        "3. Snelle concentratie",
        "4. Timing concentratie",
        "5. Concentratie onder druk",
        "6. Concentratie onder druk met vervolgactie"
      ],
      "Rustig vs Onrustig": [
        "1. Basis kalmte",
        "2. Gerichte kalmte",
        "3. Snelle kalmte",
        "4. Timing kalmte",
        "5. Kalmte onder druk",
        "6. Kalmte onder druk met vervolgactie"
      ],
      "Spontaniteit": [
        "1. Basis spontaniteit",
        "2. Gerichte spontaniteit",
        "3. Snelle spontaniteit",
        "4. Timing spontaniteit",
        "5. Spontaniteit onder druk",
        "6. Spontaniteit onder druk met vervolgactie"
      ],
      "Zelfvertrouwen": [
        "1. Basis zelfvertrouwen",
        "2. Gericht zelfvertrouwen",
        "3. Snel zelfvertrouwen",
        "4. Timing zelfvertrouwen",
        "5. Zelfvertrouwen onder druk",
        "6. Zelfvertrouwen onder druk met vervolgactie"
      ],
      "Doorzettingsvermogen": [
        "1. Basis doorzettingsvermogen",
        "2. Gericht doorzettingsvermogen",
        "3. Snel doorzettingsvermogen",
        "4. Timing doorzettingsvermogen",
        "5. Doorzettingsvermogen onder druk",
        "6. Doorzettingsvermogen onder druk met vervolgactie"
      ],
      "Motivatie": [
        "1. Basis motivatie",
        "2. Gerichte motivatie",
        "3. Snelle motivatie",
        "4. Timing motivatie",
        "5. Motivatie onder druk",
        "6. Motivatie onder druk met vervolgactie"
      ],
      "Stressbestendigheid": [
        "1. Basis stressbestendigheid",
        "2. Gerichte stressbestendigheid",
        "3. Snelle stressbestendigheid",
        "4. Timing stressbestendigheid",
        "5. Stressbestendigheid onder druk",
        "6. Stressbestendigheid onder druk met vervolgactie"
      ],
      "Communicatie": [
        "1. Basis communicatie",
        "2. Gerichte communicatie",
        "3. Snelle communicatie",
        "4. Timing communicatie",
        "5. Communicatie onder druk",
        "6. Communicatie onder druk met vervolgactie"
      ],
      "Leiderschap": [
        "1. Basis leiderschap",
        "2. Gericht leiderschap",
        "3. Snel leiderschap",
        "4. Timing leiderschap",
        "5. Leiderschap onder druk",
        "6. Leiderschap onder druk met vervolgactie"
      ],
      "Teamwork": [
        "1. Basis teamwork",
        "2. Gericht teamwork",
        "3. Snel teamwork",
        "4. Timing teamwork",
        "5. Teamwork onder druk",
        "6. Teamwork onder druk met vervolgactie"
      ],
      "Discipline": [
        "1. Basis discipline",
        "2. Gerichte discipline",
        "3. Snelle discipline",
        "4. Timing discipline",
        "5. Discipline onder druk",
        "6. Discipline onder druk met vervolgactie"
      ],
      "Mentale voorbereiding": [
        "1. Basis mentale voorbereiding",
        "2. Gerichte mentale voorbereiding",
        "3. Snelle mentale voorbereiding",
        "4. Timing mentale voorbereiding",
        "5. Mentale voorbereiding onder druk",
        "6. Mentale voorbereiding onder druk met vervolgactie"
      ],
      "Omgaan met druk": [
        "1. Basis omgaan met druk",
        "2. Gericht omgaan met druk",
        "3. Snel omgaan met druk",
        "4. Timing omgaan met druk",
        "5. Omgaan met druk onder extra druk",
        "6. Omgaan met druk onder extra druk met vervolgactie"
      ],
      "Positieve instelling": [
        "1. Basis positieve instelling",
        "2. Gerichte positieve instelling",
        "3. Snelle positieve instelling",
        "4. Timing positieve instelling",
        "5. Positieve instelling onder druk",
        "6. Positieve instelling onder druk met vervolgactie"
      ],
      "Zelfcontrole": [
        "1. Basis zelfcontrole",
        "2. Gerichte zelfcontrole",
        "3. Snelle zelfcontrole",
        "4. Timing zelfcontrole",
        "5. Zelfcontrole onder druk",
        "6. Zelfcontrole onder druk met vervolgactie"
      ],
      "Veerkracht": [
        "1. Basis veerkracht",
        "2. Gerichte veerkracht",
        "3. Snelle veerkracht",
        "4. Timing veerkracht",
        "5. Veerkracht onder druk",
        "6. Veerkracht onder druk met vervolgactie"
      ],
      "Focus": [
        "1. Basis focus",
        "2. Gerichte focus",
        "3. Snelle focus",
        "4. Timing focus",
        "5. Focus onder druk",
        "6. Focus onder druk met vervolgactie"
      ]
    },
    "FYSIEK": {
      "Uithouding": [
        "1. Basis uithouding",
        "2. Gerichte uithouding",
        "3. Lange uithouding",
        "4. Timing uithouding",
        "5. Uithouding onder druk",
        "6. Uithouding onder druk met vervolgactie"
      ],
      "Basismotoriek": [
        "1. Basis motoriek",
        "2. Gerichte motoriek",
        "3. Snelle motoriek",
        "4. Timing motoriek",
        "5. Motoriek onder druk",
        "6. Motoriek onder druk met vervolgactie"
      ],
      "Oog hand coördinatie": [
        "1. Basis oog-hand coördinatie",
        "2. Gerichte oog-hand coördinatie",
        "3. Snelle oog-hand coördinatie",
        "4. Timing oog-hand coördinatie",
        "5. Oog-hand coördinatie onder druk",
        "6. Oog-hand coördinatie onder druk met vervolgactie"
      ],
      "Oog voet coördinatie": [
        "1. Basis oog-voet coördinatie",
        "2. Gerichte oog-voet coördinatie",
        "3. Snelle oog-voet coördinatie",
        "4. Timing oog-voet coördinatie",
        "5. Oog-voet coördinatie onder druk",
        "6. Oog-voet coördinatie onder druk met vervolgactie"
      ],
      "Evenwichtscontrole": [
        "1. Basis evenwicht",
        "2. Gericht evenwicht",
        "3. Snel evenwicht",
        "4. Timing evenwicht",
        "5. Evenwicht onder druk",
        "6. Evenwicht onder druk met vervolgactie"
      ],
      "Reactiesnelheid": [
        "1. Basis reactiesnelheid",
        "2. Gerichte reactiesnelheid",
        "3. Snelle reactiesnelheid",
        "4. Timing reactiesnelheid",
        "5. Reactiesnelheid onder druk",
        "6. Reactiesnelheid onder druk met vervolgactie"
      ],
      "Natuurlijke lenigheid": [
        "1. Basis lenigheid",
        "2. Gerichte lenigheid",
        "3. Snelle lenigheid",
        "4. Timing lenigheid",
        "5. Lenigheid onder druk",
        "6. Lenigheid onder druk met vervolgactie"
      ],
      "Ritme": [
        "1. Basis ritme",
        "2. Gericht ritme",
        "3. Snel ritme",
        "4. Timing ritme",
        "5. Ritme onder druk",
        "6. Ritme onder druk met vervolgactie"
      ],
      "Loopcoördinatie": [
        "1. Basis loopcoördinatie",
        "2. Gerichte loopcoördinatie",
        "3. Snelle loopcoördinatie",
        "4. Timing loopcoördinatie",
        "5. Loopcoördinatie onder druk",
        "6. Loopcoördinatie onder druk met vervolgactie"
      ],
      "Looptechniek": [
        "1. Basis looptechniek",
        "2. Gerichte looptechniek",
        "3. Snelle looptechniek",
        "4. Timing looptechniek",
        "5. Looptechniek onder druk",
        "6. Looptechniek onder druk met vervolgactie"
      ],
      "Snelheid": [
        "1. Basis snelheid",
        "2. Gerichte snelheid",
        "3. Explosieve snelheid",
        "4. Timing snelheid",
        "5. Snelheid onder druk",
        "6. Snelheid onder druk met vervolgactie"
      ],
      "Kracht": [
        "1. Basis kracht",
        "2. Gerichte kracht",
        "3. Explosieve kracht",
        "4. Timing kracht",
        "5. Kracht onder druk",
        "6. Kracht onder druk met vervolgactie"
      ],
      "Startsnelheid": [
        "1. Basis startsnelheid",
        "2. Gerichte startsnelheid",
        "3. Explosieve startsnelheid",
        "4. Timing startsnelheid",
        "5. Startsnelheid onder druk",
        "6. Startsnelheid onder druk met vervolgactie"
      ],
      "Versnellingsvermogen": [
        "1. Basis versnelling",
        "2. Gerichte versnelling",
        "3. Snelle versnelling",
        "4. Timing versnelling",
        "5. Versnelling onder druk",
        "6. Versnelling onder druk met vervolgactie"
      ],
      "Snelheidsuithoudingsvermogen": [
        "1. Basis snelheidsuithouding",
        "2. Gerichte snelheidsuithouding",
        "3. Lange snelheidsuithouding",
        "4. Timing snelheidsuithouding",
        "5. Snelheidsuithouding onder druk",
        "6. Snelheidsuithouding onder druk met vervolgactie"
      ],
      "Wendbaarheid tijdens sprint": [
        "1. Basis wendbaarheid sprint",
        "2. Gerichte wendbaarheid sprint",
        "3. Snelle wendbaarheid sprint",
        "4. Timing wendbaarheid sprint",
        "5. Wendbaarheid sprint onder druk",
        "6. Wendbaarheid sprint onder druk met vervolgactie"
      ],
      "Sprongkracht": [
        "1. Basis sprongkracht",
        "2. Gerichte sprongkracht",
        "3. Explosieve sprongkracht",
        "4. Timing sprongkracht",
        "5. Sprongkracht onder druk",
        "6. Sprongkracht onder druk met vervolgactie"
      ],
      "Trapkracht": [
        "1. Basis trapkracht",
        "2. Gerichte trapkracht",
        "3. Explosieve trapkracht",
        "4. Timing trapkracht",
        "5. Trapkracht onder druk",
        "6. Trapkracht onder druk met vervolgactie"
      ],
      "Duelkracht": [
        "1. Basis duelkracht",
        "2. Gerichte duelkracht",
        "3. Explosieve duelkracht",
        "4. Timing duelkracht",
        "5. Duelkracht onder druk",
        "6. Duelkracht onder druk met vervolgactie"
      ],
      "Snelkracht": [
        "1. Basis snelkracht",
        "2. Gerichte snelkracht",
        "3. Explosieve snelkracht",
        "4. Timing snelkracht",
        "5. Snelkracht onder druk",
        "6. Snelkracht onder druk met vervolgactie"
      ],
      "Krachtuithouding": [
        "1. Basis krachtuithouding",
        "2. Gerichte krachtuithouding",
        "3. Lange krachtuithouding",
        "4. Timing krachtuithouding",
        "5. Krachtuithouding onder druk",
        "6. Krachtuithouding onder druk met vervolgactie"
      ],
      "Handelingssnelheid": [
        "1. Basis handelingssnelheid",
        "2. Gerichte handelingssnelheid",
        "3. Snelle handelingssnelheid",
        "4. Timing handelingssnelheid",
        "5. Handelingssnelheid onder druk",
        "6. Handelingssnelheid onder druk met vervolgactie"
      ],
      "Explosiviteit": [
        "1. Basis explosiviteit",
        "2. Gerichte explosiviteit",
        "3. Snelle explosiviteit",
        "4. Timing explosiviteit",
        "5. Explosiviteit onder druk",
        "6. Explosiviteit onder druk met vervolgactie"
      ]
    },
    "OMSCHAKELING B+": {
      "Van balverlies naar balbezit": [
        "1. Eenvoudige balherwinning",
        "2. Gerichte pressing na balverlies",
        "3. Snelle tegen-pressing",
        "4. Timing bij directe balherwinning",
        "5. Balherwinning onder tegenaanval",
        "6. Intelligente balherwinning met anticipatie"
      ],
      "Directe aanval na herwinning": [
        "1. Eenvoudige voorwaartse passing",
        "2. Gerichte snelle uitbraak",
        "3. Directe omschakeling naar aanval",
        "4. Timing bij counter-aanval",
        "5. Snelle aanval onder organiserende tegenstander",
        "6. Creatieve counter met verrassingseffect"
      ],
      "Positieve transitie": [
        "1. Basis positiewisseling naar aanval",
        "2. Gerichte verschuiving naar voren",
        "3. Snelle aanvallende reorganisatie",
        "4. Timing bij aanvallende transitie",
        "5. Positieve transitie onder druk",
        "6. Dynamische aanvallende omschakeling"
      ]
    },
    "OMSCHAKELING B-": {
      "Van balbezit naar balverlies": [
        "1. Eenvoudige defensieve transitie",
        "2. Gerichte terugval na balverlies",
        "3. Snelle verdedigende reorganisatie",
        "4. Timing bij defensieve omschakeling",
        "5. Defensieve transitie onder tegenaanval",
        "6. Intelligente defensieve herstel"
      ],
      "Defensieve organisatie na balverlies": [
        "1. Basis defensieve structuur herwinnen",
        "2. Gerichte verdedigende posities innemen",
        "3. Snelle compacte organisatie",
        "4. Timing bij defensieve herstel",
        "5. Organisatie onder snelle tegenaanval",
        "6. Adaptieve defensieve reorganisatie"
      ],
      "Negatieve transitie": [
        "1. Basis terugval naar verdediging",
        "2. Gerichte verschuiving naar achteren",
        "3. Snelle verdedigende transitie",
        "4. Timing bij defensieve omschakeling",
        "5. Negatieve transitie onder aanvallende druk",
        "6. Dynamische verdedigende aanpassing"
      ]
    }
  };
  
  const [newPlan, setNewPlan] = useState<NewPlanForm>({
    name: "",
    description: "",
    ageGroup: "",
    teamId: null,
    season: "",
    startDate: "",
    endDate: "",
    sessionsPerWeek: 2,
    trainingDays: [],
  });

  const { data: teams = [] } = useQuery({
    queryKey: ["/api/teams"],
  });

  const { data: plansData = [], refetch } = useQuery({
    queryKey: ["/api/training-plans"],
    onSuccess: (data) => {
      setPlans(data || []);
    },
  });

  const ageGroups = [
    "U6", "U7", "U8", "U9", "U10", "U11", "U12", "U13", 
    "U14", "U15", "U16", "U17", "U18", "U19", "U21", "Senioren"
  ];

  const trainingDaysOptions = [
    { value: "monday", label: "Maandag" },
    { value: "tuesday", label: "Dinsdag" },
    { value: "wednesday", label: "Woensdag" },
    { value: "thursday", label: "Donderdag" },
    { value: "friday", label: "Vrijdag" },
    { value: "saturday", label: "Zaterdag" },
    { value: "sunday", label: "Zondag" },
  ];

  useEffect(() => {
    if (plansData) {
      setPlans(plansData);
    }
  }, [plansData]);

  const filteredPlans = plans.filter(plan => {
    if (selectedTeamFilter === "all") return true;
    return plan.teamId?.toString() === selectedTeamFilter;
  });

  const handleTeamSelection = (value: string) => {
    setNewPlan({
      ...newPlan,
      teamId: value ? parseInt(value) : null
    });
  };

  const createPlan = async () => {
    if (!newPlan.name || !newPlan.ageGroup || !newPlan.startDate || !newPlan.endDate) {
      toast({
        title: "Verplichte velden ontbreken",
        description: "Vul alle verplichte velden in om door te gaan.",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await apiRequest("POST", "/api/training-plans", newPlan);
      const createdPlan = await response.json();
      
      setPlans([...plans, createdPlan]);
      
      toast({
        title: "Jaarplanning aangemaakt",
        description: "De nieuwe jaarplanning is succesvol aangemaakt en opgeslagen in de database.",
      });

      setNewPlan({
        name: "",
        description: "",
        ageGroup: "",
        teamId: null,
        season: "",
        startDate: "",
        endDate: "",
        sessionsPerWeek: 2,
        trainingDays: [],
      });
      setShowCreateDialog(false);
      refetch();
    } catch (error) {
      toast({
        title: "Fout bij aanmaken",
        description: "Er is een fout opgetreden bij het aanmaken van de jaarplanning.",
        variant: "destructive",
      });
    }
  };

  const editPlan = (plan: TrainingPlan) => {
    setEditingPlan(plan);
    setNewPlan({
      name: plan.name,
      description: plan.description,
      ageGroup: plan.ageGroup,
      teamId: plan.teamId || null,
      season: plan.season,
      startDate: plan.startDate,
      endDate: plan.endDate,
      sessionsPerWeek: plan.sessionsPerWeek,
      trainingDays: plan.trainingDays,
    });
    setShowEditDialog(true);
  };

  const updatePlan = async () => {
    if (!editingPlan || !newPlan.name || !newPlan.ageGroup) {
      toast({
        title: "Verplichte velden ontbreken",
        description: "Vul alle verplichte velden in om door te gaan.",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest("PUT", `/api/training-plans/${editingPlan.id}`, {
        name: newPlan.name,
        description: newPlan.description,
        ageGroup: newPlan.ageGroup,
        teamId: newPlan.teamId,
        season: newPlan.season,
        startDate: newPlan.startDate,
        endDate: newPlan.endDate,
        sessionsPerWeek: newPlan.sessionsPerWeek,
        trainingDays: newPlan.trainingDays
      });

      setPlans(plans.map(p => 
        p.id === editingPlan.id 
          ? { ...p, ...newPlan, teamName: teams.find((t: any) => t.id === newPlan.teamId)?.name || p.teamName }
          : p
      ));

      toast({
        title: "Jaarplanning bijgewerkt",
        description: "De jaarplanning is succesvol bijgewerkt in de database.",
      });

      setShowEditDialog(false);
      setEditingPlan(null);
      refetch();
    } catch (error) {
      toast({
        title: "Fout bij bijwerken",
        description: "Er is een fout opgetreden bij het bijwerken van de jaarplanning.",
        variant: "destructive",
      });
    }
  };

  const savePlan = async (plan: TrainingPlan) => {
    try {
      await apiRequest("PUT", `/api/training-plans/${plan.id}`, {
        name: plan.name,
        description: plan.description,
        ageGroup: plan.ageGroup,
        teamId: plan.teamId,
        season: plan.season,
        startDate: plan.startDate,
        endDate: plan.endDate,
        sessionsPerWeek: plan.sessionsPerWeek,
        trainingDays: plan.trainingDays
      });

      toast({
        title: "Jaarplanning opgeslagen",
        description: "De jaarplanning is succesvol opgeslagen in de database.",
      });

      refetch();
    } catch (error) {
      toast({
        title: "Fout bij opslaan",
        description: "Er is een fout opgetreden bij het opslaan van de jaarplanning.",
        variant: "destructive",
      });
    }
  };

  const deletePlan = async (planId: number) => {
    if (confirm("Weet je zeker dat je deze jaarplanning wilt verwijderen?")) {
      try {
        await apiRequest("DELETE", `/api/training-plans/${planId}`);
        
        setPlans(plans.filter(p => p.id !== planId));
        setSessions(sessions.filter(s => s.planId !== planId));
        
        toast({
          title: "Jaarplanning verwijderd",
          description: "De jaarplanning is succesvol verwijderd uit de database.",
        });
        
        refetch();
      } catch (error) {
        toast({
          title: "Fout bij verwijderen",
          description: "Er is een fout opgetreden bij het verwijderen van de jaarplanning.",
          variant: "destructive",
        });
      }
    }
  };

  const openSessionDialog = (dateStr: string) => {
    setSelectedDate(dateStr);
    setShowSessionDialog(true);
    
    // Load existing session data if available
    const existingSession = sessions.find(s => s.date === dateStr);
    if (existingSession) {
      setSelectedThemes(existingSession.assignedThemes || []);
      setSessionNotes(existingSession.notes || "");
    } else {
      setSelectedThemes([]);
      setSessionNotes("");
    }
  };

  const exportToExcel = (plan: TrainingPlan) => {
    // Excel export implementation
    console.log("Exporting to Excel:", plan.name);
  };

  const exportToPDF = (plan: TrainingPlan) => {
    // PDF export implementation
    console.log("Exporting to PDF:", plan.name);
  };

  const exportToICS = (plan: TrainingPlan) => {
    // ICS export implementation
    console.log("Exporting to ICS:", plan.name);
  };

  if (!user) {
    return <div>Please log in to access jaarplanning.</div>;
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Jaarplanning</h1>
          <p className="text-muted-foreground">Beheer je seizoensplanningen en trainingsschema's</p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedTeamFilter} onValueChange={setSelectedTeamFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter op team" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle teams</SelectItem>
              {(teams as any[]).map((team: any) => (
                <SelectItem key={team.id} value={team.id.toString()}>
                  {team.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nieuwe Planning
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Nieuwe Jaarplanning Aanmaken</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Naam *</label>
                  <Input
                    value={newPlan.name}
                    onChange={(e) => setNewPlan({...newPlan, name: e.target.value})}
                    placeholder="Bijv. U15 Seizoen 2024/25"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Leeftijdsgroep *</label>
                  <Select value={newPlan.ageGroup} onValueChange={(value) => setNewPlan({...newPlan, ageGroup: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer leeftijdsgroep" />
                    </SelectTrigger>
                    <SelectContent>
                      {ageGroups.map((age) => (
                        <SelectItem key={age} value={age}>
                          {age}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium mb-1">Beschrijving</label>
                  <Textarea
                    value={newPlan.description}
                    onChange={(e) => setNewPlan({...newPlan, description: e.target.value})}
                    placeholder="Beschrijf de doelstellingen en focus van deze jaarplanning..."
                    rows={3}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Team</label>
                  <Select value={newPlan.teamId?.toString() || ""} onValueChange={handleTeamSelection}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer team" />
                    </SelectTrigger>
                    <SelectContent>
                      {(teams as any[]).map((team: any) => (
                        <SelectItem key={team.id} value={team.id.toString()}>
                          {team.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Seizoen</label>
                  <Input
                    value={newPlan.season}
                    onChange={(e) => setNewPlan({...newPlan, season: e.target.value})}
                    placeholder="2024/2025"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Startdatum *</label>
                  <Input
                    type="date"
                    value={newPlan.startDate}
                    onChange={(e) => setNewPlan({...newPlan, startDate: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Einddatum *</label>
                  <Input
                    type="date"
                    value={newPlan.endDate}
                    onChange={(e) => setNewPlan({...newPlan, endDate: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Trainingen per week</label>
                  <Select value={newPlan.sessionsPerWeek.toString()} onValueChange={(value) => setNewPlan({...newPlan, sessionsPerWeek: parseInt(value)})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1x per week</SelectItem>
                      <SelectItem value="2">2x per week</SelectItem>
                      <SelectItem value="3">3x per week</SelectItem>
                      <SelectItem value="4">4x per week</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium mb-1">Trainingsdagen</label>
                  <div className="grid grid-cols-3 gap-2">
                    {trainingDaysOptions.map((day) => (
                      <div key={day.value} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={day.value}
                          checked={newPlan.trainingDays.includes(day.value)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewPlan({
                                ...newPlan,
                                trainingDays: [...newPlan.trainingDays, day.value]
                              });
                            } else {
                              setNewPlan({
                                ...newPlan,
                                trainingDays: newPlan.trainingDays.filter(d => d !== day.value)
                              });
                            }
                          }}
                          className="rounded border-gray-300 text-primary focus:ring-primary"
                        />
                        <label htmlFor={day.value} className="text-sm font-medium">
                          {day.label}
                        </label>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Selecteer de dagen waarop training plaatsvindt
                  </p>
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Annuleren
                </Button>
                <Button onClick={createPlan}>
                  Planning Aanmaken
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-4">
        {filteredPlans.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-8">
              <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold text-muted-foreground mb-2">
                Geen jaarplanningen gevonden
              </h3>
              <p className="text-sm text-muted-foreground text-center mb-4">
                {selectedTeamFilter === "all" 
                  ? "Je hebt nog geen jaarplanningen aangemaakt. Klik op 'Nieuwe Planning' om te beginnen."
                  : "Er zijn geen planningen voor het geselecteerde team."}
              </p>
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Eerste Planning Aanmaken
              </Button>
            </CardContent>
          </Card>
        ) : (
          filteredPlans.map((plan) => (
            <Card key={plan.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="default" 
                      size="sm" 
                      onClick={() => savePlan(plan)}
                      className="bg-green-600 hover:bg-green-700"
                      title="Planning opslaan"
                    >
                      <Database className="h-4 w-4" />
                      <span className="ml-1 hidden sm:inline">Opslaan</span>
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setSelectedPlan(plan)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => editPlan(plan)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => deletePlan(plan.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{plan.ageGroup}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{plan.teamName || "Geen team"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{plan.season}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{plan.sessionsPerWeek}x per week</span>
                  </div>
                </div>
                <div className="flex gap-2 mb-4">
                  <Badge variant="secondary">
                    {format(new Date(plan.startDate), "dd MMM yyyy", { locale: nl })}
                  </Badge>
                  <Badge variant="secondary">
                    {format(new Date(plan.endDate), "dd MMM yyyy", { locale: nl })}
                  </Badge>
                </div>
                <div className="flex gap-2 mb-4">
                  <Button variant="outline" size="sm" onClick={() => exportToExcel(plan)}>
                    <Download className="h-4 w-4 mr-1" />
                    Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => exportToPDF(plan)}>
                    <Download className="h-4 w-4 mr-1" />
                    PDF
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => exportToICS(plan)}>
                    <Download className="h-4 w-4 mr-1" />
                    Kalender
                  </Button>
                </div>
                
                {/* Integrated Calendar for this specific plan */}
                <div className="border-t pt-4">
                  <h4 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Training Kalender
                  </h4>
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"].map(day => (
                      <div key={day} className="p-2 text-center font-medium text-xs bg-gray-100 rounded">
                        {day}
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    {Array.from({ length: 28 }, (_, i) => {
                      const date = addDays(new Date(plan.startDate), i);
                      const dateStr = format(date, "yyyy-MM-dd");
                      const planSessions = sessions.filter(s => s.planId === plan.id && s.date === dateStr);
                      const isTrainingDay = plan.trainingDays.some(day => {
                        const dayMap: { [key: string]: number } = {
                          sunday: 0, monday: 1, tuesday: 2, wednesday: 3, 
                          thursday: 4, friday: 5, saturday: 6
                        };
                        return dayMap[day] === date.getDay();
                      });
                      
                      return (
                        <div
                          key={i}
                          className={`p-1 min-h-[40px] border rounded cursor-pointer hover:bg-accent transition-colors text-xs ${
                            planSessions.length > 0 ? "bg-primary/20 border-primary" : 
                            isTrainingDay ? "bg-blue-50 border-blue-200" : "border-gray-200"
                          }`}
                          onClick={() => {
                            setSelectedDate(dateStr);
                            setSelectedPlan(plan);
                            setShowSessionDialog(true);
                          }}
                        >
                          <div className="font-medium">{format(date, "d")}</div>
                          {planSessions.length > 0 && (
                            <div className="text-primary text-xs">
                              ●
                            </div>
                          )}
                          {isTrainingDay && planSessions.length === 0 && (
                            <div className="text-blue-500 text-xs">
                              ○
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-3 bg-primary/20 border border-primary rounded"></div>
                      <span>Training gepland</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-3 bg-blue-50 border border-blue-200 rounded"></div>
                      <span>Trainingsdag</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Jaarplanning Bewerken</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Naam *</label>
              <Input
                value={newPlan.name}
                onChange={(e) => setNewPlan({...newPlan, name: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Leeftijdsgroep</label>
              <Select value={newPlan.ageGroup} onValueChange={(value) => setNewPlan({...newPlan, ageGroup: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ageGroups.map((age) => (
                    <SelectItem key={age} value={age}>
                      {age}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium mb-1">Beschrijving</label>
              <Textarea
                value={newPlan.description}
                onChange={(e) => setNewPlan({...newPlan, description: e.target.value})}
                rows={3}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Team</label>
              <Select value={newPlan.teamId?.toString() || ""} onValueChange={handleTeamSelection}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecteer team" />
                </SelectTrigger>
                <SelectContent>
                  {(teams as any[]).map((team: any) => (
                    <SelectItem key={team.id} value={team.id.toString()}>
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Seizoen</label>
              <Input
                value={newPlan.season}
                onChange={(e) => setNewPlan({...newPlan, season: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Startdatum</label>
              <Input
                type="date"
                value={newPlan.startDate}
                onChange={(e) => setNewPlan({...newPlan, startDate: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Einddatum</label>
              <Input
                type="date"
                value={newPlan.endDate}
                onChange={(e) => setNewPlan({...newPlan, endDate: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Trainingen per week</label>
              <Select value={newPlan.sessionsPerWeek.toString()} onValueChange={(value) => setNewPlan({...newPlan, sessionsPerWeek: parseInt(value)})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1x per week</SelectItem>
                  <SelectItem value="2">2x per week</SelectItem>
                  <SelectItem value="3">3x per week</SelectItem>
                  <SelectItem value="4">4x per week</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium mb-1">Trainingsdagen</label>
              <div className="grid grid-cols-3 gap-2">
                {trainingDaysOptions.map((day) => (
                  <div key={day.value} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`edit-${day.value}`}
                      checked={newPlan.trainingDays.includes(day.value)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setNewPlan({
                            ...newPlan,
                            trainingDays: [...newPlan.trainingDays, day.value]
                          });
                        } else {
                          setNewPlan({
                            ...newPlan,
                            trainingDays: newPlan.trainingDays.filter(d => d !== day.value)
                          });
                        }
                      }}
                      className="rounded border-gray-300 text-primary focus:ring-primary"
                    />
                    <label htmlFor={`edit-${day.value}`} className="text-sm font-medium">
                      {day.label}
                    </label>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Selecteer de dagen waarop training plaatsvindt
              </p>
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Annuleren
            </Button>
            <Button onClick={updatePlan}>
              Opslaan
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Session Dialog for IADATABANK integration */}
      {showSessionDialog && (
        <Dialog open={showSessionDialog} onOpenChange={setShowSessionDialog}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Training Details - {format(new Date(selectedDate), "dd MMMM yyyy", { locale: nl })}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Session Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Duur</span>
                    </div>
                    <p className="text-lg font-semibold">90 minuten</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Focus</span>
                    </div>
                    <p className="text-lg font-semibold">Algemene ontwikkeling</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Status</span>
                    </div>
                    <p className="text-lg font-semibold text-green-600">Gepland</p>
                  </CardContent>
                </Card>
              </div>

              {/* Training Themes Selection - Hidden */}
              <div className="hidden">
                <h3 className="text-lg font-semibold mb-4">Training Thema's</h3>
              </div>

              {/* Volledige IADATABANK Selectie */}
              <div>
                <h3 className="text-lg font-semibold mb-4">IADATABANK - Selecteer Elementen voor Jaarplanning</h3>
                
                {/* Categorie Tabs */}
                <div className="flex flex-wrap gap-2 mb-6 border-b">
                  {[
                    { name: "BASICS B+", color: "bg-blue-500", description: "Technische vaardigheden met bal" },
                    { name: "BASICS B-", color: "bg-blue-600", description: "Verdedigende basisvaardigheden" },
                    { name: "TEAMTACTISCH B+", color: "bg-green-500", description: "Opbouw en aanval tactiek" },
                    { name: "TEAMTACTISCH B-", color: "bg-green-600", description: "Verdedigende tactiek" },
                    { name: "MENTAAL", color: "bg-purple-500", description: "Mentale aspecten" },
                    { name: "FYSIEK", color: "bg-red-500", description: "Fysieke conditioning" },
                    { name: "OMSCHAKELING B+", color: "bg-orange-500", description: "Van verdediging naar aanval" },
                    { name: "OMSCHAKELING B-", color: "bg-orange-600", description: "Van aanval naar verdediging" }
                  ].map((category) => (
                    <button
                      key={category.name}
                      onClick={() => {
                        if (showCategoryElements === category.name) {
                          setShowCategoryElements(null);
                        } else {
                          setShowCategoryElements(category.name);
                        }
                      }}
                      className={`px-4 py-2 rounded-t-lg border-b-2 transition-colors ${
                        showCategoryElements === category.name
                          ? 'border-primary bg-primary/10 text-primary font-semibold'
                          : 'border-transparent hover:bg-gray-100 text-gray-600'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${category.color}`}></div>
                        <span className="text-sm">{category.name}</span>
                      </div>
                    </button>
                  ))}
                </div>

                {/* Geselecteerde categorie elementen */}
                {showCategoryElements && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className={`w-4 h-4 rounded-full ${
                        showCategoryElements === "BASICS B+" ? "bg-blue-500" :
                        showCategoryElements === "BASICS B-" ? "bg-blue-600" :
                        showCategoryElements === "TEAMTACTISCH B+" ? "bg-green-500" :
                        showCategoryElements === "TEAMTACTISCH B-" ? "bg-green-600" :
                        showCategoryElements === "MENTAAL" ? "bg-purple-500" :
                        showCategoryElements === "FYSIEK" ? "bg-red-500" :
                        showCategoryElements === "OMSCHAKELING B+" ? "bg-orange-500" :
                        showCategoryElements === "OMSCHAKELING B-" ? "bg-orange-600" :
                        "bg-gray-500"
                      }`}></div>
                      <h4 className="text-lg font-semibold">{showCategoryElements}</h4>
                      <span className="text-sm text-gray-500">
                        - Selecteer thema's en diepgang niveaus
                      </span>
                    </div>

                    {/* Thema's in geselecteerde categorie */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {Object.entries(categoryElements[showCategoryElements as keyof typeof categoryElements] as Record<string, string[]> || {}).map(([themeName, levels]) => (
                        <Card key={themeName} className="border hover:shadow-md transition-shadow">
                          <CardHeader className="pb-3">
                            <CardTitle className="text-sm font-semibold text-gray-800">
                              {themeName}
                            </CardTitle>
                            <p className="text-xs text-gray-500">
                              {getAvailableThemes(showCategoryElements || "").find(theme => 
                                theme.toLowerCase().includes(themeName.toLowerCase().split(' ')[0])
                              ) || "Kies diepgang niveau"}
                            </p>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="space-y-2">
                              {levels.map((level, index) => {
                                const elementLevelKey = `${showCategoryElements}-${themeName}-${level}`;
                                const isSelected = selectedCategoryElements[showCategoryElements]?.includes(elementLevelKey) || false;
                                
                                return (
                                  <div
                                    key={`${themeName}-${index}`}
                                    className={`p-2 rounded border cursor-pointer transition-all ${
                                      isSelected 
                                        ? 'border-primary bg-primary/10 shadow-sm' 
                                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                                    }`}
                                    onClick={() => {
                                      const currentElements = selectedCategoryElements[showCategoryElements] || [];
                                      
                                      if (isSelected) {
                                        // Remove element
                                        setSelectedCategoryElements({
                                          ...selectedCategoryElements,
                                          [showCategoryElements]: currentElements.filter(el => el !== elementLevelKey)
                                        });
                                        // Remove theme selection
                                        const updatedThemes = { ...selectedElementThemes };
                                        delete updatedThemes[elementLevelKey];
                                        setSelectedElementThemes(updatedThemes);
                                      } else {
                                        // Add element
                                        setSelectedCategoryElements({
                                          ...selectedCategoryElements,
                                          [showCategoryElements]: [...currentElements, elementLevelKey]
                                        });
                                      }
                                    }}
                                  >
                                    <div className="flex items-center justify-between mb-1">
                                      <div className="text-xs font-medium text-gray-700 flex-1">
                                        {level}
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <div className="flex">
                                          {[1,2,3,4,5,6].map((star) => (
                                            <span 
                                              key={star} 
                                              className={`text-xs ${star <= (index + 1) ? 'text-yellow-400' : 'text-gray-300'}`}
                                            >
                                              ★
                                            </span>
                                          ))}
                                        </div>
                                        {isSelected && (
                                          <div className="w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                                            <span className="text-white text-xs">✓</span>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                    
                                    {/* Thema selectie voor geselecteerde elementen */}
                                    {isSelected && (
                                      <div className="mt-2 pt-2 border-t border-gray-200">
                                        <label className="text-xs text-gray-600 block mb-1">Kies specifiek thema:</label>
                                        <div className="flex flex-wrap gap-1">
                                          {getAvailableThemes(showCategoryElements || "").slice(0, 4).map((theme: string) => (
                                            <button
                                              key={theme}
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                setSelectedElementThemes({
                                                  ...selectedElementThemes,
                                                  [elementLevelKey]: theme
                                                });
                                              }}
                                              className={`px-2 py-1 text-xs rounded border transition-colors ${
                                                selectedElementThemes[elementLevelKey] === theme
                                                  ? 'bg-primary text-primary-foreground border-primary'
                                                  : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'
                                              }`}
                                            >
                                              {theme}
                                            </button>
                                          ))}
                                        </div>
                                        {selectedElementThemes[elementLevelKey] && (
                                          <div className="mt-1 text-xs text-green-600 font-medium">
                                            ✓ {selectedElementThemes[elementLevelKey]}
                                          </div>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </div>
                
                {/* Dynamic Category Elements Selection */}
                {showCategoryElements && (
                  <Card className="mt-4 border-2 border-primary">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <div className={`w-4 h-4 rounded-full ${
                          showCategoryElements === "BASICS B+" ? "bg-blue-500" :
                          showCategoryElements === "BASICS B-" ? "bg-blue-600" :
                          showCategoryElements === "TEAMTACTISCH B+" ? "bg-green-500" :
                          showCategoryElements === "TEAMTACTISCH B-" ? "bg-green-600" :
                          showCategoryElements === "MENTAAL" ? "bg-purple-500" :
                          showCategoryElements === "FYSIEK" ? "bg-red-500" :
                          showCategoryElements === "OMSCHAKELING B+" ? "bg-orange-500" :
                          showCategoryElements === "OMSCHAKELING B-" ? "bg-orange-600" :
                          "bg-gray-500"
                        }`}></div>
                        {showCategoryElements} Thema's
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {showCategoryElements && Object.entries(categoryElements[showCategoryElements as keyof typeof categoryElements] as Record<string, string[]> || {}).map(([elementName, levels]) => (
                          <div key={elementName} className="border rounded-lg p-4 bg-gray-50">
                            <h5 className="font-semibold text-sm mb-3 text-gray-800">{elementName}</h5>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              {(levels as string[]).map((level, index) => {
                                const elementLevelKey = `${elementName}: ${level}`;
                                const isChecked = selectedCategoryElements[showCategoryElements]?.includes(elementLevelKey) || false;
                                
                                return (
                                  <div key={`${elementName}-${index}`} className="border-l-2 border-gray-200 pl-3 py-2">
                                    <div className="flex items-center space-x-2 mb-2">
                                      <input
                                        type="checkbox"
                                        id={`element-${elementName}-${index}`}
                                        checked={isChecked}
                                        onChange={(e) => {
                                          const currentCategory = showCategoryElements;
                                          const currentElements = selectedCategoryElements[currentCategory] || [];
                                          
                                          if (e.target.checked) {
                                            setSelectedCategoryElements({
                                              ...selectedCategoryElements,
                                              [currentCategory]: [...currentElements, elementLevelKey]
                                            });
                                          } else {
                                            setSelectedCategoryElements({
                                              ...selectedCategoryElements,
                                              [currentCategory]: currentElements.filter(el => el !== elementLevelKey)
                                            });
                                            // Remove theme selection when unchecking
                                            const updatedThemes = { ...selectedElementThemes };
                                            delete updatedThemes[elementLevelKey];
                                            setSelectedElementThemes(updatedThemes);
                                          }
                                        }}
                                        className="rounded border-gray-300 text-primary focus:ring-primary"
                                      />
                                      <label htmlFor={`element-${elementName}-${index}`} className="text-xs text-gray-700 flex-1">
                                        {level}
                                      </label>
                                      <div className="flex">
                                        {[1,2,3,4,5,6].map((star) => (
                                          <span 
                                            key={star} 
                                            className={`text-xs ${star <= (index + 1) ? 'text-yellow-400' : 'text-gray-300'}`}
                                          >
                                            ★
                                          </span>
                                        ))}
                                      </div>
                                    </div>
                                    
                                    {/* Thema selectie alleen tonen als element is geselecteerd */}
                                    {isChecked && (
                                      <div className="ml-6 mt-2">
                                        <label className="text-xs text-gray-600 block mb-1">Kies thema:</label>
                                        <div className="flex flex-wrap gap-2">
                                          {getAvailableThemes(showCategoryElements || "").map((theme: string) => (
                                            <button
                                              key={theme}
                                              type="button"
                                              onClick={() => {
                                                setSelectedElementThemes({
                                                  ...selectedElementThemes,
                                                  [elementLevelKey]: theme
                                                });
                                              }}
                                              className={`px-3 py-1 text-xs rounded border transition-colors ${
                                                selectedElementThemes[elementLevelKey] === theme
                                                  ? 'bg-primary text-primary-foreground border-primary'
                                                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                                              }`}
                                            >
                                              {theme}
                                            </button>
                                          ))}
                                        </div>
                                        {selectedElementThemes[elementLevelKey] && (
                                          <div className="mt-2 text-xs text-green-600 font-medium">
                                            ✓ Gekozen: {selectedElementThemes[elementLevelKey]}
                                          </div>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      {selectedCategoryElements[showCategoryElements]?.length > 0 && (
                        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <p className="text-sm font-medium mb-3 text-blue-800">Geselecteerde {showCategoryElements} elementen:</p>
                          <div className="space-y-2">
                            {selectedCategoryElements[showCategoryElements]?.map((element, index) => {
                              const selectedTheme = selectedElementThemes[element];
                              return (
                                <div key={index} className="flex items-center justify-between bg-white p-2 rounded border">
                                  <span className="text-xs text-gray-700 flex-1">{element}</span>
                                  {selectedTheme && (
                                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded ml-2">
                                      {selectedTheme}
                                    </span>
                                  )}
                                  {!selectedTheme && (
                                    <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded ml-2">
                                      Geen thema
                                    </span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Training Notes */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Training Notities</h3>
                <Textarea 
                  placeholder="Voeg notities toe voor deze trainingsdag..."
                  rows={3}
                  className="w-full"
                  value={sessionNotes}
                  onChange={(e) => setSessionNotes(e.target.value)}
                />
              </div>

              {/* Action Buttons */}
              <div className="flex justify-between items-center pt-4 border-t">
                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      // Stay in current session, just log for now
                      console.log("Opening full IADATABANK for date:", selectedDate);
                    }}
                  >
                    <BookOpen className="h-4 w-4 mr-2" />
                    Volledige IADATABANK
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setShowSessionDialog(false)}>
                    Sluiten
                  </Button>
                  <Button 
                    onClick={() => {
                      // Save complete session data with IADATABANK selections
                      const sessionData: TrainingSession = {
                        planId: selectedPlan!.id,
                        week: Math.ceil((new Date(selectedDate).getTime() - new Date(selectedPlan!.startDate).getTime()) / (7 * 24 * 60 * 60 * 1000)) + 1,
                        session: 1,
                        date: selectedDate,
                        duration: 90,
                        focusArea: "Algemeen",
                        assignedThemes: selectedThemes,
                        assignedElements: [],
                        iadatabankElements: {
                          basics: [],
                          teamtactisch: [],
                          mentaal: [],
                          fysiek: [],
                          omschakeling: []
                        },
                        selectedCategoryElements: selectedCategoryElements,
                        selectedElementThemes: selectedElementThemes,
                        objectives: [],
                        notes: sessionNotes
                      };
                      
                      console.log("Complete training session saved:", sessionData);
                      console.log("Selected elements per category:", selectedCategoryElements);
                      console.log("Selected themes per element:", selectedElementThemes);
                      
                      toast({
                        title: "Training sessie opgeslagen",
                        description: `Volledige IADATABANK selecties voor ${format(new Date(selectedDate), "dd MMMM yyyy", { locale: nl })} zijn opgeslagen.`,
                      });
                      
                      setShowSessionDialog(false);
                      
                      // Reset selections for next session
                      setSelectedCategoryElements({});
                      setSelectedElementThemes({});
                      setSessionNotes("");
                      setSelectedThemes([]);
                      setShowCategoryElements(null);
                    }}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Database className="h-4 w-4 mr-2" />
                    Opslaan
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}