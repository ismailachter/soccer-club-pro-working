import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  Legend
} from 'recharts';
import { 
  TrendingUp, 
  User, 
  Users, 
  Target, 
  Zap, 
  Brain, 
  Activity,
  Calendar,
  Trophy,
  BarChart3
} from 'lucide-react';

interface PlayerSeasonStats {
  playerId: number;
  playerName: string;
  position: string;
  matchesPlayed: number;
  
  // BASICS Cumulative
  basics: {
    ballControl: { total: number; average: number; matches: number[] };
    passing: { total: number; average: number; matches: number[] };
    receiving: { total: number; average: number; matches: number[] };
    dribbling: { total: number; average: number; matches: number[] };
    shooting: { total: number; average: number; matches: number[] };
    heading: { total: number; average: number; matches: number[] };
    overallAverage: number;
  };
  
  // TEAMTACTISCH Cumulative
  tactical: {
    positioning: { total: number; average: number; matches: number[] };
    decisionMaking: { total: number; average: number; matches: number[] };
    teamwork: { total: number; average: number; matches: number[] };
    pressing: { total: number; average: number; matches: number[] };
    defending: { total: number; average: number; matches: number[] };
    attacking: { total: number; average: number; matches: number[] };
    overallAverage: number;
  };
  
  // FYSIEK Cumulative
  physical: {
    totalDistance: { total: number; average: number; matches: number[] };
    avgTopSpeed: { total: number; average: number; matches: number[] };
    totalSprints: { total: number; average: number; matches: number[] };
    totalAccelerations: { total: number; average: number; matches: number[] };
    totalDecelerations: { total: number; average: number; matches: number[] };
    avgIntensity: { total: number; average: number; matches: number[] };
    overallAverage: number;
  };
}

interface TeamSeasonStats {
  teamName: string;
  division: string;
  season: string;
  matchesPlayed: number;
  
  // Team BASICS Average
  teamBasics: {
    ballControl: number;
    passing: number;
    receiving: number;
    dribbling: number;
    shooting: number;
    heading: number;
    overallAverage: number;
  };
  
  // Team TEAMTACTISCH Average
  teamTactical: {
    positioning: number;
    decisionMaking: number;
    teamwork: number;
    pressing: number;
    defending: number;
    attacking: number;
    overallAverage: number;
  };
  
  // Team FYSIEK Average
  teamPhysical: {
    avgDistance: number;
    avgTopSpeed: number;
    avgSprints: number;
    avgAccelerations: number;
    avgDecelerations: number;
    avgIntensity: number;
    overallAverage: number;
  };
  
  playerStats: PlayerSeasonStats[];
}

export default function SeasonCumulator() {
  const [seasonStats, setSeasonStats] = useState<TeamSeasonStats | null>(null);
  const [selectedSeason, setSelectedSeason] = useState('2025-2026');
  const [selectedDivision, setSelectedDivision] = useState('IP');
  const [selectedPlayer, setSelectedPlayer] = useState<string>('team');
  const [loading, setLoading] = useState(true);
  const [activeAnalysis, setActiveAnalysis] = useState('basics');

  const seasons = ['2025-2026', '2024-2025'];
  const divisions = ['IP', 'Beloften', 'U20'];

  useEffect(() => {
    fetchSeasonStats();
  }, [selectedSeason, selectedDivision]);

  const fetchSeasonStats = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/season-stats/${selectedSeason}/${selectedDivision}`);
      const data = await response.json();
      setSeasonStats(data);
    } catch (error) {
      console.error('Error fetching season stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const getBasicsChartData = () => {
    if (!seasonStats) return [];
    
    if (selectedPlayer === 'team') {
      return [
        { name: 'Bal Controle', waarde: seasonStats.teamBasics.ballControl },
        { name: 'Passing', waarde: seasonStats.teamBasics.passing },
        { name: 'Ontvangen', waarde: seasonStats.teamBasics.receiving },
        { name: 'Dribbelen', waarde: seasonStats.teamBasics.dribbling },
        { name: 'Schieten', waarde: seasonStats.teamBasics.shooting },
        { name: 'Koppen', waarde: seasonStats.teamBasics.heading }
      ];
    } else {
      const player = seasonStats.playerStats.find(p => p.playerId.toString() === selectedPlayer);
      if (!player) return [];
      
      return [
        { name: 'Bal Controle', waarde: player.basics.ballControl.average },
        { name: 'Passing', waarde: player.basics.passing.average },
        { name: 'Ontvangen', waarde: player.basics.receiving.average },
        { name: 'Dribbelen', waarde: player.basics.dribbling.average },
        { name: 'Schieten', waarde: player.basics.shooting.average },
        { name: 'Koppen', waarde: player.basics.heading.average }
      ];
    }
  };

  const getTacticalChartData = () => {
    if (!seasonStats) return [];
    
    if (selectedPlayer === 'team') {
      return [
        { name: 'Positionering', waarde: seasonStats.teamTactical.positioning },
        { name: 'Besluitvorming', waarde: seasonStats.teamTactical.decisionMaking },
        { name: 'Teamwork', waarde: seasonStats.teamTactical.teamwork },
        { name: 'Druk Zetten', waarde: seasonStats.teamTactical.pressing },
        { name: 'Verdedigen', waarde: seasonStats.teamTactical.defending },
        { name: 'Aanvallen', waarde: seasonStats.teamTactical.attacking }
      ];
    } else {
      const player = seasonStats.playerStats.find(p => p.playerId.toString() === selectedPlayer);
      if (!player) return [];
      
      return [
        { name: 'Positionering', waarde: player.tactical.positioning.average },
        { name: 'Besluitvorming', waarde: player.tactical.decisionMaking.average },
        { name: 'Teamwork', waarde: player.tactical.teamwork.average },
        { name: 'Druk Zetten', waarde: player.tactical.pressing.average },
        { name: 'Verdedigen', waarde: player.tactical.defending.average },
        { name: 'Aanvallen', waarde: player.tactical.attacking.average }
      ];
    }
  };

  const getPhysicalChartData = () => {
    if (!seasonStats) return [];
    
    if (selectedPlayer === 'team') {
      return [
        { name: 'Afstand (km)', waarde: seasonStats.teamPhysical.avgDistance / 1000 },
        { name: 'Top Snelheid', waarde: seasonStats.teamPhysical.avgTopSpeed },
        { name: 'Sprints', waarde: seasonStats.teamPhysical.avgSprints },
        { name: 'Acceleraties', waarde: seasonStats.teamPhysical.avgAccelerations },
        { name: 'Vertragingen', waarde: seasonStats.teamPhysical.avgDecelerations },
        { name: 'Intensiteit (%)', waarde: seasonStats.teamPhysical.avgIntensity }
      ];
    } else {
      const player = seasonStats.playerStats.find(p => p.playerId.toString() === selectedPlayer);
      if (!player) return [];
      
      return [
        { name: 'Afstand (km)', waarde: player.physical.totalDistance.average / 1000 },
        { name: 'Top Snelheid', waarde: player.physical.avgTopSpeed.average },
        { name: 'Sprints', waarde: player.physical.totalSprints.average },
        { name: 'Acceleraties', waarde: player.physical.totalAccelerations.average },
        { name: 'Vertragingen', waarde: player.physical.totalDecelerations.average },
        { name: 'Intensiteit (%)', waarde: player.physical.avgIntensity.average }
      ];
    }
  };

  const getRadarData = () => {
    if (!seasonStats) return [];
    
    if (selectedPlayer === 'team') {
      return [
        {
          subject: 'BASICS',
          A: seasonStats.teamBasics.overallAverage,
          fullMark: 10
        },
        {
          subject: 'TEAMTACTISCH',
          A: seasonStats.teamTactical.overallAverage,
          fullMark: 10
        },
        {
          subject: 'FYSIEK',
          A: seasonStats.teamPhysical.overallAverage,
          fullMark: 10
        }
      ];
    } else {
      const player = seasonStats.playerStats.find(p => p.playerId.toString() === selectedPlayer);
      if (!player) return [];
      
      return [
        {
          subject: 'BASICS',
          A: player.basics.overallAverage,
          fullMark: 10
        },
        {
          subject: 'TEAMTACTISCH',
          A: player.tactical.overallAverage,
          fullMark: 10
        },
        {
          subject: 'FYSIEK',
          A: player.physical.overallAverage,
          fullMark: 10
        }
      ];
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">
            <Activity className="h-12 w-12 animate-spin mx-auto mb-4 text-blue-600" />
            <p className="text-lg text-gray-600">Seizoenstatistieken laden...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Trophy className="h-8 w-8 text-yellow-600" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Seizoen Cumulator</h1>
                <p className="text-gray-600">Volledige seizoenanalyse voor alle speelsters</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Select value={selectedSeason} onValueChange={setSelectedSeason}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {seasons.map(season => (
                    <SelectItem key={season} value={season}>{season}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={selectedDivision} onValueChange={setSelectedDivision}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {divisions.map(division => (
                    <SelectItem key={division} value={division}>{division}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {seasonStats && (
          <>
            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100">Wedstrijden</p>
                      <p className="text-3xl font-bold">{seasonStats.matchesPlayed}</p>
                    </div>
                    <Calendar className="h-8 w-8 text-blue-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100">BASICS Gem.</p>
                      <p className="text-3xl font-bold">{seasonStats.teamBasics.overallAverage.toFixed(1)}</p>
                    </div>
                    <Target className="h-8 w-8 text-green-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100">TEAMTACTISCH Gem.</p>
                      <p className="text-3xl font-bold">{seasonStats.teamTactical.overallAverage.toFixed(1)}</p>
                    </div>
                    <Brain className="h-8 w-8 text-purple-200" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-orange-100">FYSIEK Gem.</p>
                      <p className="text-3xl font-bold">{seasonStats.teamPhysical.overallAverage.toFixed(1)}</p>
                    </div>
                    <Zap className="h-8 w-8 text-orange-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Player/Team Selector */}
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>Analyse Selectie</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                    <SelectTrigger className="w-64">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="team">
                        <div className="flex items-center space-x-2">
                          <Users className="h-4 w-4" />
                          <span>Team Gemiddelde</span>
                        </div>
                      </SelectItem>
                      {seasonStats.playerStats.map(player => (
                        <SelectItem key={player.playerId} value={player.playerId.toString()}>
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4" />
                            <span>{player.playerName}</span>
                            <Badge variant="outline">{player.position}</Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  {selectedPlayer !== 'team' && (
                    <Badge variant="secondary">
                      {seasonStats.playerStats.find(p => p.playerId.toString() === selectedPlayer)?.matchesPlayed} wedstrijden
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Analysis Tabs */}
            <Tabs value={activeAnalysis} onValueChange={setActiveAnalysis} className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="basics" className="flex items-center space-x-2">
                  <Target className="h-4 w-4" />
                  <span>BASICS</span>
                </TabsTrigger>
                <TabsTrigger value="tactical" className="flex items-center space-x-2">
                  <Brain className="h-4 w-4" />
                  <span>TEAMTACTISCH</span>
                </TabsTrigger>
                <TabsTrigger value="physical" className="flex items-center space-x-2">
                  <Zap className="h-4 w-4" />
                  <span>FYSIEK</span>
                </TabsTrigger>
                <TabsTrigger value="overview" className="flex items-center space-x-2">
                  <BarChart3 className="h-4 w-4" />
                  <span>OVERZICHT</span>
                </TabsTrigger>
              </TabsList>

              {/* BASICS Analysis */}
              <TabsContent value="basics">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>BASICS Elementen</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={getBasicsChartData()}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                          <YAxis domain={[0, 10]} />
                          <Tooltip />
                          <Bar dataKey="waarde" fill="#22c55e" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>BASICS Ontwikkeling</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {getBasicsChartData().map((item, index) => (
                          <div key={index}>
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-sm font-medium">{item.name}</span>
                              <span className="text-sm text-gray-600">{item.waarde.toFixed(1)}/10</span>
                            </div>
                            <Progress value={item.waarde * 10} className="h-2" />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* TEAMTACTISCH Analysis */}
              <TabsContent value="tactical">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>TEAMTACTISCH Elementen</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={getTacticalChartData()}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                          <YAxis domain={[0, 10]} />
                          <Tooltip />
                          <Bar dataKey="waarde" fill="#8b5cf6" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>TEAMTACTISCH Ontwikkeling</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {getTacticalChartData().map((item, index) => (
                          <div key={index}>
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-sm font-medium">{item.name}</span>
                              <span className="text-sm text-gray-600">{item.waarde.toFixed(1)}/10</span>
                            </div>
                            <Progress value={item.waarde * 10} className="h-2" />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* FYSIEK Analysis */}
              <TabsContent value="physical">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>FYSIEK Prestaties</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={getPhysicalChartData()}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="waarde" fill="#f59e0b" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>FYSIEK Statistieken</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {getPhysicalChartData().map((item, index) => (
                          <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <span className="font-medium">{item.name}</span>
                            <span className="text-lg font-bold text-orange-600">
                              {item.name.includes('%') || item.name.includes('km') ? 
                                item.waarde.toFixed(1) : 
                                Math.round(item.waarde)
                              }
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Overview Radar */}
              <TabsContent value="overview">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Totaal Overzicht</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={400}>
                        <RadarChart data={getRadarData()}>
                          <PolarGrid />
                          <PolarAngleAxis dataKey="subject" />
                          <PolarRadiusAxis domain={[0, 10]} />
                          <Radar
                            name="Prestatie"
                            dataKey="A"
                            stroke="#3b82f6"
                            fill="#3b82f6"
                            fillOpacity={0.3}
                          />
                        </RadarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Seizoen Samenvatting</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="text-center">
                        <h3 className="text-lg font-semibold mb-4">
                          {selectedPlayer === 'team' ? 'Team Prestatie' : 
                            seasonStats.playerStats.find(p => p.playerId.toString() === selectedPlayer)?.playerName}
                        </h3>
                        
                        <div className="grid grid-cols-3 gap-4">
                          <div className="text-center p-4 bg-green-50 rounded-lg">
                            <Target className="h-6 w-6 mx-auto mb-2 text-green-600" />
                            <p className="text-sm text-gray-600">BASICS</p>
                            <p className="text-xl font-bold text-green-600">
                              {getRadarData()[0]?.A.toFixed(1)}/10
                            </p>
                          </div>
                          
                          <div className="text-center p-4 bg-purple-50 rounded-lg">
                            <Brain className="h-6 w-6 mx-auto mb-2 text-purple-600" />
                            <p className="text-sm text-gray-600">TEAMTACTISCH</p>
                            <p className="text-xl font-bold text-purple-600">
                              {getRadarData()[1]?.A.toFixed(1)}/10
                            </p>
                          </div>
                          
                          <div className="text-center p-4 bg-orange-50 rounded-lg">
                            <Zap className="h-6 w-6 mx-auto mb-2 text-orange-600" />
                            <p className="text-sm text-gray-600">FYSIEK</p>
                            <p className="text-xl font-bold text-orange-600">
                              {getRadarData()[2]?.A.toFixed(1)}/10
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </div>
  );
}