import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
// import { BackToMenu } from "@/components/ui/back-to-menu";
import { BarChart3, Activity, Users, Target, Clock, MapPin } from "lucide-react";

export default function DirectGPSAnalysis() {
  const [analysisData, setAnalysisData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAnalysisData = async () => {
      try {
        const response = await fetch('/uploads/svelta-analysis.json');
        const data = await response.json();
        setAnalysisData(data);
      } catch (error) {
        console.error('Fout bij laden analyse data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadAnalysisData();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <div className="text-center">
          <div className="text-xl">Laden authentieke video analyse...</div>
        </div>
      </div>
    );
  }

  if (!analysisData) {
    return (
      <div className="space-y-6 p-6">
        <div className="text-center">
          <div className="text-xl text-red-600">Geen analyse data beschikbaar</div>
        </div>
      </div>
    );
  }

  // VVC BRASSCHAAT A spelers uit opstelling - correcte namen en nummers
  const realVVCPlayers = [
    { name: "Marieke Van Ammers", position: "GK", number: 1 },
    { name: "Laura Michielsen", position: "Defender", number: 4 },
    { name: "Sien Schepens", position: "Defender", number: 6 },
    { name: "Jorien Dictus", position: "Midfielder", number: 7 },
    { name: "Eline Bultje", position: "Midfielder", number: 8 },
    { name: "Melissa Vinckx", position: "Forward", number: 9 },
    { name: "Arianna De Maeyer", position: "Forward", number: 10 },
    { name: "Julie Luyten", position: "Defender", number: 14 },
    { name: "Emily Van Rooy", position: "Substitute", number: 15 },
    { name: "Ine Denhaen", position: "Substitute", number: 16 },
    { name: "Louise Creemers", position: "Midfielder", number: 17 },
    { name: "Ginger van Enthoven", position: "Substitute", number: 19 },
    { name: "Sophie Van Parys", position: "Defender", number: 21 },
    { name: "Maud Bastiaensen", position: "Defender", number: 22 }
  ];

  // Echte KVKS Melsele spelers uit wedstrijdopstelling
  const realSveltaPlayers = [
    { name: "Joni Billen", position: "GK", number: 71 },
    { name: "Kirsten Van Dassel", position: "Defender", number: 2 },
    { name: "Amber Verlies", position: "Defender", number: 3 },
    { name: "Ana Lucia Claricka", position: "Defender", number: 4 },
    { name: "Sandy De Schepper", position: "Midfielder", number: 8 },
    { name: "Senne Mertens", position: "Midfielder", number: 10 },
    { name: "Jolien De Laet", position: "Forward", number: 11 },
    { name: "Julie Cour", position: "Forward", number: 13 },
    { name: "Anouk Verhiest", position: "Forward", number: 14 },
    { name: "Ellen Van Bockhaven", position: "Midfielder", number: 15 },
    { name: "Sofia Van Royen", position: "Substitute", number: 17 },
    // Wisselspelers
    { name: "Femke Verdonck", position: "Substitute", number: 6 },
    { name: "Amelie Stansaert", position: "Substitute", number: 7 },
    { name: "Emily Maria Coenen", position: "Substitute", number: 9 },
    { name: "Lien Wyndale", position: "Substitute", number: 20 }
  ];

  const vvcPlayers = analysisData.playerData.filter(p => p.team === "VVC Brasschaat A");
  const sveltaPlayers = analysisData.playerData.filter(p => p.team === "Svelta Melsele");

  const allPlayers = [...vvcPlayers, ...sveltaPlayers];
  const topPerformers = allPlayers.sort((a, b) => b.basics.overallRating - a.basics.overallRating).slice(0, 6);

  // Calculate totals from real data
  const totalDistance = allPlayers.reduce((sum, p) => sum + (p.physical.distance / 1000), 0);
  const maxSpeed = Math.max(...allPlayers.map(p => p.physical.topSpeed));
  const totalSprints = allPlayers.reduce((sum, p) => sum + p.physical.sprints, 0);
  const maxSpeedPlayer = allPlayers.find(p => p.physical.topSpeed === maxSpeed);

  return (
    <div className="space-y-6 p-6">

      
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Wedstrijdopstelling Analysis</h1>
        <div className="text-6xl font-bold">
          <span className="text-red-600">1</span>
          <span className="text-gray-400 mx-4">-</span>
          <span className="text-blue-600">5</span>
        </div>
        <div className="text-xl">
          <span className="font-semibold">KVKS MELSELE A</span>
          <span className="mx-2">vs</span>
          <span className="font-semibold">VVC BRASSCHAAT A</span>
        </div>
        <Badge variant="secondary" className="text-lg px-4 py-2">
          za 08 maart 2025 - 15:00
        </Badge>
        <div className="text-sm text-gray-600">
          Authentieke wedstrijdopstelling en uitslag
        </div>
      </div>

      {/* Team Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600">VVC Brasschaat - Echte Opstelling</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {realVVCPlayers.map(player => (
                <div key={player.number} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div>
                    <div className="font-medium">{player.name}</div>
                    <div className="text-sm text-gray-600">#{player.number} - {player.position}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-600">Authentieke speler</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Svelta Melsele - Echte Opstelling</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {realSveltaPlayers.map(player => (
                <div key={player.number} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                  <div>
                    <div className="font-medium">{player.name}</div>
                    <div className="text-sm text-gray-600">#{player.number} - {player.position}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-600">Authentieke speler</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Match Result */}
      <Card>
        <CardHeader>
          <CardTitle>Wedstrijdresultaat</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center space-y-4">
            <div className="text-6xl font-bold">
              <span className="text-red-600">1</span>
              <span className="text-gray-400 mx-4">-</span>
              <span className="text-blue-600">5</span>
            </div>
            <div className="text-xl">
              <span className="font-semibold">KVKS MELSELE A</span>
              <span className="mx-2">vs</span>
              <span className="font-semibold">VVC BRASSCHAAT A</span>
            </div>
            <Badge variant="secondary" className="text-lg px-4 py-2">
              za 08 maart 2025 - 15:00
            </Badge>
            <p className="text-sm text-gray-600">
              Uitslag gebaseerd op authentieke wedstrijdopstelling
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}