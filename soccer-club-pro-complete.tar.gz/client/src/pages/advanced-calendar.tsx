import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, MapPin, Users, Video, Heart, Trophy, Dumbbell, Plus, Edit, Trash2 } from 'lucide-react';
import { format, isSameDay, startOfMonth, endOfMonth, eachDayOfInterval, getDay } from 'date-fns';
import { nl } from 'date-fns/locale';
import { toast } from '@/hooks/use-toast';

interface CalendarEvent {
  id: number;
  title: string;
  description?: string;
  eventType: 'training' | 'extra_training' | 'friendly_match' | 'competition_match' | 'stage' | 'tournament' | 'videotraining' | 'teambuilding' | 'other';
  eventStatus: 'scheduled' | 'completed' | 'cancelled' | 'postponed';
  date: string;
  startTime?: string;
  endTime?: string;
  duration?: number;
  location?: string;
  opponent?: string;
  videoUrl?: string;
  videoTopic?: string;
  teambuildingType?: string;
  teambuildingActivity?: string;
  maxParticipants?: number;
  costPerPerson?: number;
  intensity?: 'laag' | 'matig' | 'hoog' | 'maximaal';
  notes?: string;
  yearPlanId?: number;
  teamId?: number;
}

const eventTypeConfig = {
  training: { icon: Dumbbell, color: 'bg-blue-500', label: 'Training' },
  extra_training: { icon: Dumbbell, color: 'bg-indigo-500', label: 'Extra Training' },
  friendly_match: { icon: Trophy, color: 'bg-green-500', label: 'Vriendschappelijk' },
  competition_match: { icon: Trophy, color: 'bg-red-500', label: 'Competitie' },
  stage: { icon: MapPin, color: 'bg-purple-500', label: 'Stage' },
  tournament: { icon: Trophy, color: 'bg-orange-500', label: 'Toernooi' },
  videotraining: { icon: Video, color: 'bg-cyan-500', label: 'Videotraining' },
  teambuilding: { icon: Heart, color: 'bg-pink-500', label: 'Teambuilding' },
  other: { icon: Calendar, color: 'bg-gray-500', label: 'Overig' }
};

export default function AdvancedCalendar() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [eventForm, setEventForm] = useState({
    title: '',
    description: '',
    eventType: 'training' as CalendarEvent['eventType'],
    date: '',
    startTime: '',
    endTime: '',
    duration: 90,
    location: '',
    opponent: '',
    videoUrl: '',
    videoTopic: '',
    teambuildingType: '',
    teambuildingActivity: '',
    maxParticipants: 0,
    costPerPerson: 0,
    intensity: 'matig' as CalendarEvent['intensity'],
    notes: ''
  });

  const queryClient = useQueryClient();

  // Fetch calendar events
  const { data: events = [], isLoading } = useQuery({
    queryKey: ['/api/calendar/events', {
      startDate: format(startOfMonth(currentMonth), 'yyyy-MM-dd'),
      endDate: format(endOfMonth(currentMonth), 'yyyy-MM-dd')
    }],
    queryFn: async () => {
      const startDate = format(startOfMonth(currentMonth), 'yyyy-MM-dd');
      const endDate = format(endOfMonth(currentMonth), 'yyyy-MM-dd');
      const response = await fetch(`/api/calendar/events?startDate=${startDate}&endDate=${endDate}`);
      if (!response.ok) throw new Error('Failed to fetch events');
      return response.json();
    }
  });

  // Create/update event mutation
  const eventMutation = useMutation({
    mutationFn: async (eventData: any) => {
      const url = editingEvent ? `/api/calendar/events/${editingEvent.id}` : '/api/calendar/events';
      const method = editingEvent ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventData)
      });
      
      if (!response.ok) throw new Error('Failed to save event');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calendar/events'] });
      setIsEventDialogOpen(false);
      resetForm();
      toast({ title: "Succes", description: `Event ${editingEvent ? 'bijgewerkt' : 'aangemaakt'}` });
    },
    onError: () => {
      toast({ title: "Fout", description: "Event kon niet worden opgeslagen", variant: "destructive" });
    }
  });

  // Delete event mutation
  const deleteMutation = useMutation({
    mutationFn: async (eventId: number) => {
      const response = await fetch(`/api/calendar/events/${eventId}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Failed to delete event');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calendar/events'] });
      toast({ title: "Succes", description: "Event verwijderd" });
    }
  });

  const resetForm = () => {
    setEventForm({
      title: '',
      description: '',
      eventType: 'training',
      date: '',
      startTime: '',
      endTime: '',
      duration: 90,
      location: '',
      opponent: '',
      videoUrl: '',
      videoTopic: '',
      teambuildingType: '',
      teambuildingActivity: '',
      maxParticipants: 0,
      costPerPerson: 0,
      intensity: 'matig',
      notes: ''
    });
    setEditingEvent(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    eventMutation.mutate(eventForm);
  };

  const openEditDialog = (event: CalendarEvent) => {
    setEditingEvent(event);
    setEventForm({
      title: event.title,
      description: event.description || '',
      eventType: event.eventType,
      date: event.date,
      startTime: event.startTime || '',
      endTime: event.endTime || '',
      duration: event.duration || 90,
      location: event.location || '',
      opponent: event.opponent || '',
      videoUrl: event.videoUrl || '',
      videoTopic: event.videoTopic || '',
      teambuildingType: event.teambuildingType || '',
      teambuildingActivity: event.teambuildingActivity || '',
      maxParticipants: event.maxParticipants || 0,
      costPerPerson: event.costPerPerson || 0,
      intensity: event.intensity || 'matig',
      notes: event.notes || ''
    });
    setIsEventDialogOpen(true);
  };

  const openNewEventDialog = (date: Date) => {
    resetForm();
    setEventForm(prev => ({
      ...prev,
      date: format(date, 'yyyy-MM-dd')
    }));
    setIsEventDialogOpen(true);
  };

  // Generate calendar days
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarDays = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Add padding days for calendar grid
  const paddingStart = Array.from({ length: getDay(monthStart) }, (_, i) => {
    const paddingDate = new Date(monthStart);
    paddingDate.setDate(paddingDate.getDate() - (getDay(monthStart) - i));
    return paddingDate;
  });

  const paddingEnd = Array.from({ length: 6 - getDay(monthEnd) }, (_, i) => {
    const paddingDate = new Date(monthEnd);
    paddingDate.setDate(paddingDate.getDate() + i + 1);
    return paddingDate;
  });

  const allCalendarDays = [...paddingStart, ...calendarDays, ...paddingEnd];

  const getEventsForDate = (date: Date) => {
    return events.filter((event: CalendarEvent) => 
      isSameDay(new Date(event.date), date)
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Kalender</h1>
        <div className="flex items-center gap-4">
          <Button 
            onClick={() => setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() - 1)))}
            variant="outline"
          >
            ← Vorige
          </Button>
          <h2 className="text-xl font-semibold min-w-[200px] text-center">
            {format(currentMonth, 'MMMM yyyy', { locale: nl })}
          </h2>
          <Button 
            onClick={() => setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() + 1)))}
            variant="outline"
          >
            Volgende →
          </Button>
        </div>
      </div>

      {/* Calendar Grid */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-7 gap-1 mb-4">
            {['Zo', 'Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za'].map(day => (
              <div key={day} className="p-2 text-center font-semibold text-gray-600">
                {day}
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 gap-1">
            {allCalendarDays.map((date, index) => {
              const dayEvents = getEventsForDate(date);
              const isCurrentMonth = date.getMonth() === currentMonth.getMonth();
              const isToday = isSameDay(date, new Date());
              
              return (
                <div
                  key={index}
                  className={`min-h-[100px] p-2 border rounded cursor-pointer transition-colors ${
                    isCurrentMonth ? 'bg-white hover:bg-gray-50' : 'bg-gray-100 text-gray-400'
                  } ${isToday ? 'ring-2 ring-blue-500' : ''}`}
                  onClick={() => openNewEventDialog(date)}
                >
                  <div className="font-semibold text-sm mb-1">
                    {format(date, 'd')}
                  </div>
                  
                  <div className="space-y-1">
                    {dayEvents.slice(0, 3).map((event: CalendarEvent) => {
                      const config = eventTypeConfig[event.eventType];
                      const IconComponent = config.icon;
                      
                      return (
                        <div
                          key={event.id}
                          className={`text-xs p-1 rounded text-white ${config.color} flex items-center gap-1`}
                          onClick={(e) => {
                            e.stopPropagation();
                            openEditDialog(event);
                          }}
                        >
                          <IconComponent size={10} />
                          <span className="truncate">
                            {event.startTime && `${event.startTime} `}
                            {event.title}
                          </span>
                        </div>
                      );
                    })}
                    
                    {dayEvents.length > 3 && (
                      <div className="text-xs text-gray-500">
                        +{dayEvents.length - 3} meer
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Event Form Dialog */}
      <Dialog open={isEventDialogOpen} onOpenChange={setIsEventDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingEvent ? 'Event Bewerken' : 'Nieuw Event Aanmaken'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="title">Titel *</Label>
                <Input
                  id="title"
                  value={eventForm.title}
                  onChange={(e) => setEventForm(prev => ({ ...prev, title: e.target.value }))}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="eventType">Type Event *</Label>
                <Select
                  value={eventForm.eventType}
                  onValueChange={(value) => setEventForm(prev => ({ ...prev, eventType: value as any }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(eventTypeConfig).map(([key, config]) => (
                      <SelectItem key={key} value={key}>
                        {config.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Beschrijving</Label>
              <Textarea
                id="description"
                value={eventForm.description}
                onChange={(e) => setEventForm(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="date">Datum *</Label>
                <Input
                  id="date"
                  type="date"
                  value={eventForm.date}
                  onChange={(e) => setEventForm(prev => ({ ...prev, date: e.target.value }))}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="startTime">Starttijd</Label>
                <Input
                  id="startTime"
                  type="time"
                  value={eventForm.startTime}
                  onChange={(e) => setEventForm(prev => ({ ...prev, startTime: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="duration">Duur (minuten)</Label>
                <Input
                  id="duration"
                  type="number"
                  value={eventForm.duration}
                  onChange={(e) => setEventForm(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="location">Locatie</Label>
                <Input
                  id="location"
                  value={eventForm.location}
                  onChange={(e) => setEventForm(prev => ({ ...prev, location: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="intensity">Intensiteit</Label>
                <Select
                  value={eventForm.intensity}
                  onValueChange={(value) => setEventForm(prev => ({ ...prev, intensity: value as any }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="laag">Laag</SelectItem>
                    <SelectItem value="matig">Matig</SelectItem>
                    <SelectItem value="hoog">Hoog</SelectItem>
                    <SelectItem value="maximaal">Maximaal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Conditional fields based on event type */}
            {(eventForm.eventType === 'friendly_match' || eventForm.eventType === 'competition_match') && (
              <div>
                <Label htmlFor="opponent">Tegenstander</Label>
                <Input
                  id="opponent"
                  value={eventForm.opponent}
                  onChange={(e) => setEventForm(prev => ({ ...prev, opponent: e.target.value }))}
                />
              </div>
            )}

            {eventForm.eventType === 'videotraining' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="videoTopic">Video Onderwerp</Label>
                  <Input
                    id="videoTopic"
                    value={eventForm.videoTopic}
                    onChange={(e) => setEventForm(prev => ({ ...prev, videoTopic: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="videoUrl">Video/Meeting Link</Label>
                  <Input
                    id="videoUrl"
                    value={eventForm.videoUrl}
                    onChange={(e) => setEventForm(prev => ({ ...prev, videoUrl: e.target.value }))}
                  />
                </div>
              </div>
            )}

            {eventForm.eventType === 'teambuilding' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="teambuildingType">Type Teambuilding</Label>
                  <Select
                    value={eventForm.teambuildingType}
                    onValueChange={(value) => setEventForm(prev => ({ ...prev, teambuildingType: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="indoor">Indoor</SelectItem>
                      <SelectItem value="outdoor">Outdoor</SelectItem>
                      <SelectItem value="restaurant">Restaurant</SelectItem>
                      <SelectItem value="activity">Activiteit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="teambuildingActivity">Activiteit</Label>
                  <Input
                    id="teambuildingActivity"
                    value={eventForm.teambuildingActivity}
                    onChange={(e) => setEventForm(prev => ({ ...prev, teambuildingActivity: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="maxParticipants">Max Deelnemers</Label>
                  <Input
                    id="maxParticipants"
                    type="number"
                    value={eventForm.maxParticipants}
                    onChange={(e) => setEventForm(prev => ({ ...prev, maxParticipants: parseInt(e.target.value) }))}
                  />
                </div>
                <div>
                  <Label htmlFor="costPerPerson">Kosten per persoon (€)</Label>
                  <Input
                    id="costPerPerson"
                    type="number"
                    step="0.01"
                    value={eventForm.costPerPerson}
                    onChange={(e) => setEventForm(prev => ({ ...prev, costPerPerson: parseFloat(e.target.value) }))}
                  />
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="notes">Notities</Label>
              <Textarea
                id="notes"
                value={eventForm.notes}
                onChange={(e) => setEventForm(prev => ({ ...prev, notes: e.target.value }))}
              />
            </div>

            <div className="flex justify-between">
              <div>
                {editingEvent && (
                  <Button
                    type="button"
                    variant="destructive"
                    onClick={() => deleteMutation.mutate(editingEvent.id)}
                  >
                    <Trash2 size={16} className="mr-2" />
                    Verwijderen
                  </Button>
                )}
              </div>
              
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEventDialogOpen(false)}
                >
                  Annuleren
                </Button>
                <Button
                  type="submit"
                  disabled={eventMutation.isPending}
                >
                  {eventMutation.isPending ? 'Opslaan...' : (editingEvent ? 'Bijwerken' : 'Aanmaken')}
                </Button>
              </div>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}