import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Video, AlertTriangle, CheckCircle, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function VideoAnalysisStatus() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <Video className="h-16 w-16 text-blue-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Video Analyse Status
          </h1>
          <p className="text-lg text-gray-600">
            VVC Brasschaat vs KVKS Melsele
          </p>
        </div>

        <div className="grid gap-6">
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-700">
                <CheckCircle className="h-5 w-5" />
                Video Geupload
              </CardTitle>
              <CardDescription>
                Wedstrijdvideo succesvol ontvangen en opgeslagen
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p><strong>Bestand:</strong> match-video-1750870860329-999699725.mp4</p>
                <p><strong>Grootte:</strong> 1.07GB</p>
                <p><strong>Status:</strong> Upload voltooid</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-amber-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-700">
                <AlertTriangle className="h-5 w-5" />
                Computer Vision Beperking
              </CardTitle>
              <CardDescription>
                Video-inhoud analyse heeft specifieke software vereisten
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Voor automatische goal detectie zijn OpenCV of ffmpeg libraries vereist die momenteel niet beschikbaar zijn.
                </AlertDescription>
              </Alert>
              
              <div className="space-y-3">
                <h4 className="font-semibold">Wat wel beschikbaar is:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Video bestand detectie en grootte analyse</li>
                  <li>Authentieke team opstellingen uit uploads</li>
                  <li>Speler database met 22 spelers beide teams</li>
                  <li>Wedstrijd setup en structuur</li>
                </ul>
                
                <h4 className="font-semibold mt-4">Voor goal detectie nodig:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Frame extractie uit video</li>
                  <li>Computer vision voor goal herkenning</li>
                  <li>Speler identificatie in frames</li>
                  <li>Tijdstempel analyse</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Handmatige Input Optie</CardTitle>
              <CardDescription>
                Voer de werkelijke wedstrijdresultaten in voor complete analyse
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-4">
                <p className="text-gray-600">
                  Voor nu kunnen we de echte eindstand en doelpunten handmatig invoeren
                </p>
                <Button variant="outline" className="w-full">
                  <Upload className="h-4 w-4 mr-2" />
                  Invoer Wedstrijdresultaten
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}