import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, Target, Users, MapPin, Star, Plus, Edit, Trash2, Eye, Filter, Search, ChevronLeft, ChevronRight, Zap, Brain, Dumbbell, Trophy } from "lucide-react";
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO, addWeeks, subWeeks, addMonths } from 'date-fns';
import { nl } from 'date-fns/locale';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface TrainingSession {
  id: string;
  planId: number;
  week: number;
  session: number;
  date: string;
  time: string;
  duration: number;
  focusArea: string;
  location: string;
  ageGroup: string;
  assignedElements: string[];
  intensity: 'low' | 'medium' | 'high';
  weather: 'indoor' | 'outdoor';
  notes: string;
  status: 'planned' | 'completed' | 'cancelled';
}

export default function ModernJaarplanningFinal() {
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [viewMode, setViewMode] = useState<'day' | 'week' | 'month'>('week');
  const [filterAgeGroup, setFilterAgeGroup] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [showTeamDialog, setShowTeamDialog] = useState(false);
  const [editingTeam, setEditingTeam] = useState<any>(null);
  const [showEditPlanDialog, setShowEditPlanDialog] = useState(false);
  const [editingPlan, setEditingPlan] = useState<YearPlan | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newPlanName, setNewPlanName] = useState('');
  const [newPlanDescription, setNewPlanDescription] = useState('');
  const [editPlanData, setEditPlanData] = useState({
    name: '',
    description: '',
    ageGroup: '',
    season: '',
    startDate: '',
    endDate: '',
    sessionsPerWeek: 2,
    trainingDays: [] as string[],
    focusThemes: [] as string[],
    clubId: 1
  });
  const [newSessionData, setNewSessionData] = useState({
    date: format(new Date(), 'yyyy-MM-dd'),
    time: '19:00',
    duration: 90,
    focusArea: '',
    location: 'Hoofdveld',
    ageGroup: '',
    teamId: '',
    intensity: 'medium' as 'low' | 'medium' | 'high',
    notes: '',
    assignedElements: [] as string[]
  });

  // Fetch data
  const { data: yearPlans = [], isLoading: isLoadingPlans } = useQuery({ queryKey: ['/api/year-plans'] });
  const { data: iaElements = [] } = useQuery({ queryKey: ['/api/iadatabank/elements'] });
  const { data: teams = [] } = useQuery({ queryKey: ['/api/teams'] });

  // Handler functions
  const handleNewPlan = () => {
    setIsCreating(true);
    setNewPlanName('');
    setNewPlanDescription('');
  };

  const handleSaveNewPlan = async () => {
    if (!newPlanName.trim()) {
      toast({ title: "Fout", description: "Voer een naam in voor de jaarplanning", variant: "destructive" });
      return;
    }

    const newPlanData = {
      name: newPlanName,
      description: newPlanDescription,
      ageGroup: editPlanData.ageGroup || 'U13',
      season: editPlanData.season || '2024-2025',
      startDate: editPlanData.startDate || format(new Date(), 'yyyy-MM-dd'),
      endDate: editPlanData.endDate || format(addMonths(new Date(), 10), 'yyyy-MM-dd'),
      sessionsPerWeek: editPlanData.sessionsPerWeek || 2,
      trainingDays: editPlanData.trainingDays || [],
      focusThemes: editPlanData.focusThemes || [],
      teamId: editPlanData.clubId || null,
      status: 'draft' as const
    };

    createYearPlan.mutate(newPlanData);
  };

  const handleEditPlan = (plan: any) => {
    setEditingPlan(plan);
    setEditPlanData({
      name: plan.name,
      description: plan.description,
      ageGroup: plan.ageGroup,
      season: plan.season,
      startDate: plan.startDate,
      endDate: plan.endDate,
      sessionsPerWeek: plan.sessionsPerWeek,
      trainingDays: plan.trainingDays || [],
      focusThemes: [],
      clubId: plan.teamId || 1
    });
    setShowEditPlanDialog(true);
  };

  const handleSavePlan = async () => {
    if (!editingPlan) return;
    
    const updatedData = {
      ...editPlanData,
      teamId: editPlanData.clubId
    };
    
    updateYearPlan.mutate({ id: editingPlan.id, data: updatedData });
  };

  const handleDeletePlan = async (planId: number) => {
    if (confirm('Weet je zeker dat je deze jaarplanning wilt verwijderen?')) {
      deleteYearPlan.mutate(planId);
    }
  };

  // CRUD mutations
  const createYearPlan = useMutation({
    mutationFn: (data: any) => apiRequest(`/api/year-plans`, 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setIsCreating(false);
      setNewPlanName('');
      setNewPlanDescription('');
      toast({ title: "Jaarplanning aangemaakt", description: "De nieuwe jaarplanning is succesvol aangemaakt." });
    },
    onError: (error: any) => {
      toast({ title: "Fout", description: `Kan jaarplanning niet aanmaken: ${error.message}`, variant: "destructive" });
    }
  });

  const updateYearPlan = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => apiRequest(`/api/year-plans/${id}`, 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setShowEditPlanDialog(false);
      setEditingPlan(null);
      toast({ title: "Jaarplanning bijgewerkt", description: "De jaarplanning is succesvol bijgewerkt." });
    },
    onError: (error: any) => {
      toast({ title: "Fout", description: `Kan jaarplanning niet bijwerken: ${error.message}`, variant: "destructive" });
    }
  });

  const deleteYearPlan = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/year-plans/${id}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      toast({ title: "Jaarplanning verwijderd", description: "De jaarplanning is permanent verwijderd." });
    },
    onError: (error: any) => {
      toast({ title: "Fout", description: `Kan jaarplanning niet verwijderen: ${error.message}`, variant: "destructive" });
    }
  });

  // IADATABANK state
  const [selectedElement, setSelectedElement] = useState<any>(null);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubcategory, setSelectedSubcategory] = useState('');
  const [selectedProgression, setSelectedProgression] = useState(1);

  // Extract categories from IADATABANK - handle API response structure
  const getCategories = () => {
    const categories = new Set<string>();
    const elements = Array.isArray(iaElements) ? iaElements : (iaElements as any)?.data || [];
    elements.forEach((element: any) => {
      if (element.category) categories.add(element.category);
    });
    return Array.from(categories).sort();
  };

  // Extract subcategories for selected category
  const getSubcategories = (category: string) => {
    const elements = Array.isArray(iaElements) ? iaElements : (iaElements as any)?.data || [];
    return elements
      .filter((element: any) => element.category === category)
      .map((element: any) => element.subcategory)
      .filter((sub: string, index: number, arr: string[]) => arr.indexOf(sub) === index)
      .sort();
  };

  // Get progressions for selected element
  const getProgressionsForElement = (category: string, subcategory: string) => {
    const elements = Array.isArray(iaElements) ? iaElements : (iaElements as any)?.data || [];
    const element = elements.find((el: any) => 
      el.category === category && el.subcategory === subcategory
    );
    
    // Extract progression names from the element structure
    if (element?.progressions && Array.isArray(element.progressions)) {
      return element.progressions;
    }
    
    // If no progressions array, check for other possible structures
    if (element) {
      const progFields = ['progression1', 'progression2', 'progression3', 'progression4', 'progression5', 'progression6'];
      const progressions = progFields
        .map(field => element[field])
        .filter(prog => prog && prog.trim() !== '');
      
      if (progressions.length > 0) {
        return progressions.map((name: string, index: number) => ({ name, level: index + 1 }));
      }
    }
    
    return [];
  };

  const categories = getCategories();
  const subcategories = selectedCategory ? getSubcategories(selectedCategory) : [];
  const progressions = selectedCategory && selectedSubcategory ? 
    getProgressionsForElement(selectedCategory, selectedSubcategory) : [];

  const getWeekDays = (date: Date) => {
    const start = startOfWeek(date, { weekStartsOn: 1 });
    const end = endOfWeek(date, { weekStartsOn: 1 });
    return eachDayOfInterval({ start, end });
  };

  // Mock year plans with authentic IADATABANK integration
  const [mockYearPlans] = useState<YearPlan[]>([
    {
      id: 1,
      name: "U12 Welpen Seizoen 2024-2025",
      description: "Volledig ontwikkelingsprogramma voor U12 spelers met focus op BASICS B+ elementen",
      ageGroup: "U12",
      teamId: 1,
      teamName: "U12 Welpen",
      season: "2024-2025",
      startDate: "2024-09-01",
      endDate: "2025-05-31",
      totalWeeks: 36,
      sessionsPerWeek: 2,
      trainingDays: ["Dinsdag", "Donderdag"],
      created: "2024-08-15",
      status: "active"
    },
    {
      id: 2,
      name: "U15 Scholieren Competitie Plan",
      description: "Intensief trainingsplan met TEAMTACTICS B+ en BASICS B+ combinaties voor competitievoorbereiding",
      ageGroup: "U15",
      teamId: 2,
      teamName: "U15 Scholieren",
      season: "2024-2025",
      startDate: "2024-09-01",
      endDate: "2025-05-31",
      totalWeeks: 36,
      sessionsPerWeek: 3,
      trainingDays: ["Maandag", "Woensdag", "Vrijdag"],
      created: "2024-08-10",
      status: "active"
    },
    {
      id: 3,
      name: "U17 Elite Ontwikkeling",
      description: "Gevorderde training met alle IADATABANK categorieën - voorbereiding op senioren voetbal",
      ageGroup: "U17",
      teamId: 3,
      teamName: "U17 Junioren",
      season: "2024-2025",
      startDate: "2024-09-01",
      endDate: "2025-05-31",
      totalWeeks: 36,
      sessionsPerWeek: 4,
      trainingDays: ["Maandag", "Dinsdag", "Donderdag", "Zaterdag"],
      created: "2024-08-05",
      status: "active"
    }
  ]);

  // Generate realistic training sessions for current week
  const generateTrainingSessions = (weekDate: Date): TrainingSession[] => {
    const sessions: TrainingSession[] = [];
    const weekDays = getWeekDays(weekDate);
    const today = new Date();
    
    // U12 Welpen Sessions (Tue, Thu) - Plan ID 1
    [1, 3].forEach((dayIndex, sessionIndex) => {
      const sessionDate = weekDays[dayIndex];
      const u12Elements = [
        { category: 'BASICS B+', subcategory: 'Dribbelen met de bal', progression: 2 },
        { category: 'BASICS B+', subcategory: 'Korte Passing', progression: 3 }
      ];
      const element = u12Elements[sessionIndex];
      
      sessions.push({
        id: `u12-${format(sessionDate, 'yyyy-MM-dd')}-${sessionIndex}`,
        planId: 1,
        week: Math.ceil((sessionDate.getTime() - new Date(sessionDate.getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000)),
        session: sessionIndex + 1,
        date: format(sessionDate, 'yyyy-MM-dd'),
        time: '18:00',
        duration: 75,
        focusArea: `${element.category} - ${element.subcategory}`,
        location: 'Veld 2',
        ageGroup: 'U12',
        assignedElements: [`${element.category}-${element.subcategory}-niveau-${element.progression}`.toLowerCase().replace(/\s+/g, '-')],
        intensity: 'medium',
        weather: 'outdoor',
        notes: `Niveau ${element.progression} (${['', 'Eenvoudig', 'Gericht', 'Gericht snel', 'Onder druk', 'Toepassing', 'Meesterschap'][element.progression]}): ${sessionIndex === 0 ? 'Individuele dribbeltechnieken met beide voeten' : 'Korte passing in kleine groepen, timing'}`,
        status: sessionDate < today ? 'completed' : 'planned'
      });
    });

    // U15 Scholieren Sessions (Mon, Wed, Fri) - Plan ID 2
    [0, 2, 4].forEach((dayIndex, sessionIndex) => {
      const sessionDate = weekDays[dayIndex];
      const u15Elements = [
        { category: 'BASICS B+', subcategory: 'Middellange Passing', progression: 4 },
        { category: 'TEAMTACTICS B+', subcategory: 'Positiespel', progression: 3 },
        { category: 'FYSIEK B+', subcategory: 'Snelheid', progression: 3 }
      ];
      const element = u15Elements[sessionIndex];
      
      sessions.push({
        id: `u15-${format(sessionDate, 'yyyy-MM-dd')}-${sessionIndex}`,
        planId: 2,
        week: Math.ceil((sessionDate.getTime() - new Date(sessionDate.getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000)),
        session: sessionIndex + 1,
        date: format(sessionDate, 'yyyy-MM-dd'),
        time: '19:00',
        duration: 90,
        focusArea: `${element.category} - ${element.subcategory}`,
        location: sessionIndex === 2 ? 'Trainingsveld A' : 'Hoofdveld',
        ageGroup: 'U15',
        assignedElements: [`${element.category}-${element.subcategory}-niveau-${element.progression}`.toLowerCase().replace(/\s+/g, '-')],
        intensity: ['medium', 'high', 'low'][sessionIndex] as 'low' | 'medium' | 'high',
        weather: 'outdoor',
        notes: `Niveau ${element.progression} (${['', 'Eenvoudig', 'Gericht', 'Gericht snel', 'Onder druk', 'Toepassing', 'Meesterschap'][element.progression]}): ${
          sessionIndex === 0 ? 'Middellange passing onder tijdsdruk, precisie' :
          sessionIndex === 1 ? 'Positiespel in 7v7, driehoeken vormen' :
          'Sprint intervallen, acceleratie uit verschillende posities'
        }`,
        status: sessionDate < today ? 'completed' : 'planned'
      });
    });

    // U17 Elite Sessions (Mon, Tue, Thu, Sat) - Plan ID 3
    [0, 1, 3, 5].forEach((dayIndex, sessionIndex) => {
      if (sessionIndex >= 4) return;
      const sessionDate = weekDays[dayIndex];
      const u17Elements = [
        { category: 'TEAMTACTICS B+', subcategory: 'Combinatiespel', progression: 5 },
        { category: 'BASICS B-', subcategory: 'Pressing', progression: 4 },
        { category: 'MENTAAL B+', subcategory: 'Concentratie', progression: 5 },
        { category: 'FYSIEK B+', subcategory: 'Explosiviteit', progression: 4 }
      ];
      const element = u17Elements[sessionIndex];
      
      sessions.push({
        id: `u17-${format(sessionDate, 'yyyy-MM-dd')}-${sessionIndex}`,
        planId: 3,
        week: Math.ceil((sessionDate.getTime() - new Date(sessionDate.getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000)),
        session: sessionIndex + 1,
        date: format(sessionDate, 'yyyy-MM-dd'),
        time: sessionIndex === 3 ? '10:00' : '19:30',
        duration: sessionIndex === 3 ? 120 : 105,
        focusArea: `${element.category} - ${element.subcategory}`,
        location: ['Hoofdveld', 'Veld 2', 'Trainingsveld A', 'Hoofdveld'][sessionIndex],
        ageGroup: 'U17',
        assignedElements: [`${element.category}-${element.subcategory}-niveau-${element.progression}`.toLowerCase().replace(/\s+/g, '-')],
        intensity: 'high',
        weather: 'outdoor',
        notes: `Niveau ${element.progression} (${['', 'Eenvoudig', 'Gericht', 'Gericht snel', 'Onder druk', 'Toepassing', 'Meesterschap'][element.progression]}): ${
          sessionIndex === 0 ? 'Geavanceerde combinaties in wedstrijdtempo' :
          sessionIndex === 1 ? 'Pressing als linie, communicatie en timing' :
          sessionIndex === 2 ? 'Mentale focus in stressvolle situaties' :
          'Explosieve kracht, plyometrische oefeningen'
        }`,
        status: sessionDate < today ? 'completed' : 'planned'
      });
    });
    
    return sessions;
  };

  const [trainingSessions, setTrainingSessions] = useState<TrainingSession[]>(() => 
    generateTrainingSessions(new Date())
  );

  // Update sessions when week changes
  useEffect(() => {
    setTrainingSessions(generateTrainingSessions(currentWeek));
  }, [currentWeek]);

  const getSessionsForDate = (date: Date) => {
    return trainingSessions.filter(session => 
      isSameDay(parseISO(session.date), date) &&
      (filterAgeGroup === 'all' || session.ageGroup === filterAgeGroup) &&
      (filterStatus === 'all' || session.status === filterStatus) &&
      (searchTerm === '' || 
        session.focusArea.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.notes.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  };

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'low': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'medium': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'high': return 'bg-rose-100 text-rose-800 border-rose-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planned': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getFocusAreaIcon = (focusArea: string) => {
    if (focusArea.includes('BASICS')) return <Zap className="h-4 w-4" />;
    if (focusArea.includes('TEAMTACTICS')) return <Target className="h-4 w-4" />;
    if (focusArea.includes('MENTAAL')) return <Brain className="h-4 w-4" />;
    if (focusArea.includes('FYSIEK')) return <Dumbbell className="h-4 w-4" />;
    return <Trophy className="h-4 w-4" />;
  };

  const getAgeGroupColor = (ageGroup: string) => {
    switch (ageGroup) {
      case 'U12': return 'border-l-emerald-500 bg-emerald-50';
      case 'U15': return 'border-l-blue-500 bg-blue-50';
      case 'U17': return 'border-l-purple-500 bg-purple-50';
      default: return 'border-l-gray-500 bg-gray-50';
    }
  };

  const weekDays = getWeekDays(currentWeek);
  const weekNumber = Math.ceil(
    (currentWeek.getTime() - new Date(currentWeek.getFullYear(), 0, 1).getTime()) / 
    (7 * 24 * 60 * 60 * 1000)
  );

  const totalSessions = trainingSessions.length;
  const completedSessions = trainingSessions.filter(s => s.status === 'completed').length;
  const plannedSessions = trainingSessions.filter(s => s.status === 'planned').length;

  // Helper functions voor training dagen en thema's

  const handleTrainingDayToggle = (day: string) => {
    setEditPlanData(prev => ({
      ...prev,
      trainingDays: prev.trainingDays.includes(day)
        ? prev.trainingDays.filter(d => d !== day)
        : [...prev.trainingDays, day]
    }));
  };

  const handleThemeToggle = (theme: string) => {
    setEditPlanData(prev => ({
      ...prev,
      focusThemes: prev.focusThemes.includes(theme)
        ? prev.focusThemes.filter(t => t !== theme)
        : [...prev.focusThemes, theme]
    }));
  };

  // Training management functions
  const handleAddSession = () => {
    const elementId = `${selectedCategory}-${selectedSubcategory}-${selectedProgression}`.toLowerCase().replace(/\s+/g, '-');
    const progressionText = progressionLevels[selectedProgression - 1];
    
    const newSession: TrainingSession = {
      id: `session-${Date.now()}`,
      planId: parseInt(newSessionData.teamId) || 1,
      week: Math.ceil((new Date(newSessionData.date).getTime() - new Date(new Date().getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000)),
      session: trainingSessions.filter(s => s.date === newSessionData.date).length + 1,
      date: newSessionData.date,
      time: newSessionData.time,
      duration: newSessionData.duration,
      focusArea: `${selectedCategory} - ${selectedSubcategory}`,
      location: newSessionData.location,
      ageGroup: newSessionData.ageGroup,
      assignedElements: [elementId],
      intensity: newSessionData.intensity,
      weather: 'outdoor',
      notes: `${progressionText}: ${newSessionData.notes}`,
      status: 'planned'
    };
    
    setTrainingSessions([...trainingSessions, newSession]);
    setShowPlanDialog(false);
    
    // Reset form
    setNewSessionData({
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '19:00',
      duration: 90,
      focusArea: '',
      location: 'Hoofdveld',
      ageGroup: '',
      teamId: '',
      intensity: 'medium',
      notes: '',
      assignedElements: []
    });
    setSelectedCategory('');
    setSelectedSubcategory('');
    setSelectedProgression(1);
  };

  const handleDeleteSession = (sessionId: string) => {
    setTrainingSessions(trainingSessions.filter(s => s.id !== sessionId));
    setShowSessionDialog(false);
  };

  const handleUpdateSessionStatus = (sessionId: string, newStatus: 'planned' | 'completed' | 'cancelled') => {
    setTrainingSessions(trainingSessions.map(s => 
      s.id === sessionId ? { ...s, status: newStatus } : s
    ));
  };

  // IADATABANK focus areas - authentieke thema's
  const iadatabankCategories = {
    "BASICS B+": [
      "Leiden van de bal",
      "Dribbelen met de bal", 
      "Korte Passing",
      "Middellange Passing",
      "Lange Passing",
      "Passing met het hoofd",
      "1 tijd Passing, Kaatsen",
      "Balcontrole Korte Pass",
      "Balcontrole Middellange Pass",
      "Balcontrole Lange Pass",
      "Schieten op doel",
      "Scoren met de voet",
      "Scoren met het hoofd",
      "Scoren na individuele actie trucks",
      "Vrijlopen aanspeelbaar zijn"
    ],
    "BASICS B-": [
      "Druk zetten tackle remmen",
      "Duel",
      "Interceptie balcontrole korte passing",
      "Interceptie balcontrole middellange passing", 
      "Interceptie balcontrole lange passing",
      "Interceptie balcontrole kopbal",
      "Interceptie balcontrole kaatsbal",
      "Interceptie na balcontrole korte pass",
      "Interceptie na balcontrole middellange pass",
      "Interceptie na balcontrole lange pass",
      "Afweren schieten beletten",
      "Afweren scoren voet beletten",
      "Afweren scoren hoofd beletten",
      "Afweren scoren individuele actie beletten",
      "Positie tussen de linies",
      "Strikte dekking",
      "Ontvluchten vrij maken"
    ],
    "TEAMTACTICS B+": [
      "Positiespel",
      "Driehoeken vormen",
      "Creeer ruimte",
      "Creeer hoogte, diepte",
      "Opbouw van achteruit",
      "Combinatiespel",
      "Aanvalsorganisatie",
      "Breedte creëren",
      "Diepgang zoeken",
      "Switchen van spel",
      "Overlappen",
      "Ondersteunend spel",
      "Timing van loopacties"
    ],
    "TEAMTACTICS B-": [
      "Verdedigingsorganisatie",
      "Pressing",
      "Compactheid",
      "Dekking",
      "Buitenspelval",
      "Dueling",
      "Schuiven en dekken",
      "Communicatie verdediging",
      "Blok vormen",
      "Verdedigende transitie"
    ],
    "MENTAAL B+": [
      "Concentratie",
      "Motivatie", 
      "Zelfvertrouwen",
      "Doelgerichtheid",
      "Creativiteit",
      "Leiderschap",
      "Positieve instelling",
      "Doorzettingsvermogen",
      "Competitiedrang",
      "Teamwork",
      "Communicatie",
      "Besluitvorming"
    ],
    "MENTAAL B-": [
      "Stresshantering",
      "Frustratie overwinnen",
      "Angst beheersen",
      "Discipline",
      "Respect tonen",
      "Nederlaag verwerken",
      "Kritiek accepteren",
      "Geduld ontwikkelen"
    ],
    "FYSIEK B+": [
      "Snelheid",
      "Explosiviteit",
      "Sprongkracht",
      "Kracht",
      "Behendigheid",
      "Coördinatie",
      "Reactievermogen",
      "Acceleratie",
      "Wendbaarheid",
      "Balans",
      "Timing"
    ],
    "FYSIEK B-": [
      "Uithoudingsvermogen",
      "Herstel",
      "Flexibiliteit",
      "Blessurepreventie",
      "Stabiliteit core",
      "Ademhaling",
      "Recuperatie",
      "Stretching",
      "Mobiliteit"
    ]
  };

  // Gebruik echte IADATABANK progressieniveaus uit de database
  const getProgressionLevels = () => {
    if (!progressions || progressions.length === 0) {
      return [];
    }
    
    // Handle different progression structures from IADATABANK
    return progressions.map((prog: any) => {
      if (typeof prog === 'string') return prog;
      if (prog.name) return prog.name;
      if (prog.progression) return prog.progression;
      return prog;
    }).filter(Boolean);
  };

  const progressionLevels = getProgressionLevels();

  const ageGroupOptions = ['U8', 'U10', 'U12', 'U14', 'U15', 'U17', 'U19', 'Senioren'];
  const locationOptions = ['Hoofdveld', 'Veld 2', 'Trainingsveld A', 'Trainingsveld B', 'Kunstgrasveld', 'Sporthal'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Hero Header with Navigation */}
        <div className="flex flex-col lg:flex-row items-center justify-between py-8 space-y-6 lg:space-y-0">
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full mb-4">
              <Calendar className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
              Moderne Jaarplanning Kalender
            </h1>
            <p className="text-xl text-gray-600">
              {viewMode === 'week' && `Week ${weekNumber} • ${format(weekDays[0], 'd MMM', { locale: nl })} - ${format(weekDays[6], 'd MMM yyyy', { locale: nl })}`}
              {viewMode === 'month' && format(currentWeek, 'MMMM yyyy', { locale: nl })}
              {viewMode === 'day' && format(currentWeek, 'EEEE d MMMM yyyy', { locale: nl })}
            </p>
          </div>
          
          {/* View Controls */}
          <div className="flex items-center space-x-6">
            {/* View Mode Toggle */}
            <div className="flex bg-gray-100 rounded-lg p-1">
              <Button
                variant={viewMode === 'day' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('day')}
                className={`px-4 py-2 ${viewMode === 'day' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'}`}
              >
                Dag
              </Button>
              <Button
                variant={viewMode === 'week' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('week')}
                className={`px-4 py-2 ${viewMode === 'week' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'}`}
              >
                Week
              </Button>
              <Button
                variant={viewMode === 'month' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('month')}
                className={`px-4 py-2 ${viewMode === 'month' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'}`}
              >
                Maand
              </Button>
            </div>
            
            {/* Navigation Arrows */}
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  if (viewMode === 'day') setCurrentWeek(addDays(currentWeek, -1));
                  else if (viewMode === 'week') setCurrentWeek(addWeeks(currentWeek, -1));
                  else setCurrentWeek(addMonths(currentWeek, -1));
                }}
                className="h-10 w-10 p-0"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  if (viewMode === 'day') setCurrentWeek(addDays(currentWeek, 1));
                  else if (viewMode === 'week') setCurrentWeek(addWeeks(currentWeek, 1));
                  else setCurrentWeek(addMonths(currentWeek, 1));
                }}
                className="h-10 w-10 p-0"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Jaarplanning Beheer */}
        <Card className="border-0 shadow-lg mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5" />
                  <span>Actieve Jaarplanningen</span>
                </CardTitle>
                <CardDescription>
                  Beheer en bekijk alle trainingsplannen voor dit seizoen
                </CardDescription>
              </div>
              <Button onClick={handleNewPlan} className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 mr-2" />
                Nieuwe Jaarplanning
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {isLoadingPlans ? (
                <div className="col-span-3 text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="text-gray-500 mt-2">Jaarplanningen laden...</p>
                </div>
              ) : (yearPlans as any[]).length === 0 ? (
                <div className="col-span-3 text-center py-8">
                  <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Nog geen jaarplanningen aangemaakt</p>
                  {isCreating && (
                    <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                      <div className="space-y-4">
                        <Input
                          placeholder="Naam van de jaarplanning"
                          value={newPlanName}
                          onChange={(e) => setNewPlanName(e.target.value)}
                        />
                        <Textarea
                          placeholder="Beschrijving (optioneel)"
                          value={newPlanDescription}
                          onChange={(e) => setNewPlanDescription(e.target.value)}
                        />
                        <div className="flex space-x-2">
                          <Button 
                            onClick={handleSaveNewPlan}
                            disabled={createYearPlan.isPending}
                            className="flex-1"
                          >
                            {createYearPlan.isPending ? 'Opslaan...' : 'Opslaan'}
                          </Button>
                          <Button 
                            variant="outline" 
                            onClick={() => setIsCreating(false)}
                            className="flex-1"
                          >
                            Annuleren
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : yearPlans.map((plan: any) => (
                <Card key={plan.id} className="border border-gray-200 hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <Badge className={`${
                        plan.ageGroup === 'U12' ? 'bg-emerald-600' :
                        plan.ageGroup === 'U15' ? 'bg-blue-600' : 'bg-purple-600'
                      }`}>
                        {plan.ageGroup}
                      </Badge>
                      <Badge variant="outline" className={
                        plan.status === 'active' ? 'border-green-500 text-green-700' : 'border-gray-500'
                      }>
                        {plan.status === 'active' ? 'Actief' : plan.status}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    <CardDescription className="text-sm">{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex justify-between">
                        <span>Sessies per week:</span>
                        <span className="font-medium">{plan.sessionsPerWeek}x</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Trainingsdagen:</span>
                        <span className="font-medium">{plan.trainingDays.join(', ')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Seizoen:</span>
                        <span className="font-medium">{plan.season}</span>
                      </div>
                    </div>
                    <div className="flex space-x-2 mt-4">
                      <Button size="sm" variant="outline" className="flex-1">
                        <Eye className="h-3 w-3 mr-1" />
                        Bekijk
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => handleEditPlan(plan)}
                      >
                        <Edit className="h-3 w-3 mr-1" />
                        Bewerk
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1 text-red-600 hover:bg-red-50"
                        onClick={() => handleDeletePlan(plan.id)}
                      >
                        <Trash2 className="h-3 w-3 mr-1" />
                        Verwijder
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm font-medium">Totaal Sessies</p>
                  <p className="text-3xl font-bold">{totalSessions}</p>
                </div>
                <Calendar className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-lg bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-sm font-medium">Voltooid</p>
                  <p className="text-3xl font-bold">{completedSessions}</p>
                </div>
                <Trophy className="h-8 w-8 text-emerald-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm font-medium">Gepland</p>
                  <p className="text-3xl font-bold">{plannedSessions}</p>
                </div>
                <Clock className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Controls */}
        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center space-x-2">
                <Search className="h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Zoek trainingen..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-64 border-0 bg-gray-100 focus:bg-white transition-colors"
                />
              </div>
              
              <Select value={filterAgeGroup} onValueChange={setFilterAgeGroup}>
                <SelectTrigger className="w-40 border-0 bg-gray-100">
                  <SelectValue placeholder="Leeftijdsgroep" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle groepen</SelectItem>
                  <SelectItem value="U12">U12</SelectItem>
                  <SelectItem value="U15">U15</SelectItem>
                  <SelectItem value="U17">U17</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-32 border-0 bg-gray-100">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle status</SelectItem>
                  <SelectItem value="planned">Gepland</SelectItem>
                  <SelectItem value="completed">Voltooid</SelectItem>
                  <SelectItem value="cancelled">Geannuleerd</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex items-center space-x-2 ml-auto">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentWeek(subWeeks(currentWeek, 1))}
                  className="border-0 bg-gray-100 hover:bg-gray-200"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentWeek(new Date())}
                  className="border-0 bg-gray-100 hover:bg-gray-200"
                >
                  Vandaag
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentWeek(addWeeks(currentWeek, 1))}
                  className="border-0 bg-gray-100 hover:bg-gray-200"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              <Dialog open={showPlanDialog} onOpenChange={setShowPlanDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 border-0">
                    <Plus className="h-4 w-4 mr-2" />
                    Nieuwe Training
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Nieuwe Training Sessie</DialogTitle>
                    <DialogDescription>
                      Plan een nieuwe training sessie met alle details
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-6 py-4">
                    {/* Basis Informatie */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">Datum</label>
                        <Input
                          type="date"
                          value={newSessionData.date}
                          onChange={(e) => setNewSessionData({...newSessionData, date: e.target.value})}
                          className="w-full"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">Tijd</label>
                        <Input
                          type="time"
                          value={newSessionData.time}
                          onChange={(e) => setNewSessionData({...newSessionData, time: e.target.value})}
                          className="w-full"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">Leeftijdsgroep</label>
                        <Select value={newSessionData.ageGroup} onValueChange={(value) => setNewSessionData({...newSessionData, ageGroup: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecteer leeftijdsgroep" />
                          </SelectTrigger>
                          <SelectContent>
                            {ageGroupOptions.map(age => (
                              <SelectItem key={age} value={age}>{age}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">Duur (minuten)</label>
                        <Input
                          type="number"
                          value={newSessionData.duration}
                          onChange={(e) => setNewSessionData({...newSessionData, duration: parseInt(e.target.value)})}
                          className="w-full"
                          min="30"
                          max="180"
                          step="15"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">Locatie</label>
                        <Select value={newSessionData.location} onValueChange={(value) => setNewSessionData({...newSessionData, location: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecteer locatie" />
                          </SelectTrigger>
                          <SelectContent>
                            {locationOptions.map(location => (
                              <SelectItem key={location} value={location}>{location}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">Intensiteit</label>
                        <Select value={newSessionData.intensity} onValueChange={(value: 'low' | 'medium' | 'high') => setNewSessionData({...newSessionData, intensity: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecteer intensiteit" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Laag</SelectItem>
                            <SelectItem value="medium">Gemiddeld</SelectItem>
                            <SelectItem value="high">Hoog</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* IADATABANK Selectie */}
                    <div className="space-y-4 p-4 bg-blue-50 rounded-lg border">
                      <h3 className="font-semibold text-blue-900">IADATABANK Element Selectie</h3>
                      
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700 mb-2 block">Categorie</label>
                          <Select value={selectedCategory} onValueChange={(value) => {
                            setSelectedCategory(value);
                            setSelectedSubcategory('');
                            setNewSessionData({...newSessionData, focusArea: value});
                          }}>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecteer categorie" />
                            </SelectTrigger>
                            <SelectContent>
                              {categories.map(category => (
                                <SelectItem key={category} value={category}>{category}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <label className="text-sm font-medium text-gray-700 mb-2 block">Subcategorie</label>
                          <Select 
                            value={selectedSubcategory} 
                            onValueChange={(value) => {
                              setSelectedSubcategory(value);
                              setNewSessionData({...newSessionData, focusArea: `${selectedCategory} - ${value}`});
                            }}
                            disabled={!selectedCategory}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Selecteer subcategorie" />
                            </SelectTrigger>
                            <SelectContent>
                              {subcategories.map((sub: string) => (
                                <SelectItem key={sub} value={sub}>{sub}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <label className="text-sm font-medium text-gray-700 mb-2 block">Progressie Niveau</label>
                          <Select 
                            value={selectedProgression.toString()} 
                            onValueChange={(value) => setSelectedProgression(parseInt(value))}
                            disabled={progressionLevels.length === 0}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder={progressionLevels.length === 0 ? "Selecteer eerst categorie en subcategorie" : "Selecteer niveau"} />
                            </SelectTrigger>
                            <SelectContent>
                              {progressionLevels.map((level: string, index: number) => (
                                <SelectItem key={index + 1} value={(index + 1).toString()}>
                                  {level}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {progressionLevels.length > 0 && (
                            <p className="text-xs text-gray-500 mt-1">
                              {progressionLevels.length} progressie niveau{progressionLevels.length !== 1 ? 's' : ''} beschikbaar
                            </p>
                          )}
                        </div>
                      </div>

                      {selectedCategory && selectedSubcategory && (
                        <div className="mt-4 p-3 bg-white rounded border">
                          <p className="text-sm text-gray-600">
                            <strong>Geselecteerd element:</strong> {selectedCategory} - {selectedSubcategory}
                          </p>
                          <p className="text-sm text-blue-600 mt-1">
                            <strong>Niveau:</strong> {progressionLevels[selectedProgression - 1]}
                          </p>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">Notities</label>
                      <Textarea
                        value={newSessionData.notes}
                        onChange={(e) => setNewSessionData({...newSessionData, notes: e.target.value})}
                        placeholder="Beschrijf de doelstellingen en oefeningen voor deze training..."
                        className="min-h-[100px]"
                      />
                    </div>

                    <div className="flex justify-end space-x-3 pt-4 border-t">
                      <Button variant="outline" onClick={() => setShowPlanDialog(false)}>
                        Annuleren
                      </Button>
                      <Button 
                        onClick={handleAddSession}
                        disabled={!newSessionData.ageGroup || !newSessionData.focusArea}
                        className="bg-gradient-to-r from-blue-600 to-purple-600"
                      >
                        Training Toevoegen
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Calendar Grid */}
        <div className={`grid gap-4 ${
          viewMode === 'day' ? 'grid-cols-1' : 
          viewMode === 'week' ? 'grid-cols-1 lg:grid-cols-7' : 
          'grid-cols-1 md:grid-cols-2 lg:grid-cols-4'
        }`}>
          {weekDays.map((day, index) => {
            const sessionsForDay = getSessionsForDate(day);
            const isToday = isSameDay(day, new Date());
            const dayName = format(day, 'EEEE', { locale: nl });
            
            return (
              <Card 
                key={index} 
                className={`min-h-[500px] border-0 shadow-lg transition-all duration-300 hover:shadow-xl ${
                  isToday ? 'ring-2 ring-blue-500 bg-blue-50' : 'bg-white'
                }`}
              >
                <CardHeader className="pb-4">
                  <div className="text-center">
                    <div className="text-sm font-medium text-gray-600 uppercase tracking-wide">
                      {dayName}
                    </div>
                    <div className={`text-2xl font-bold mt-1 ${
                      isToday ? 'text-blue-600' : 'text-gray-900'
                    }`}>
                      {format(day, 'd', { locale: nl })}
                    </div>
                    {sessionsForDay.length > 0 && (
                      <Badge 
                        className={`mt-2 ${
                          isToday ? 'bg-blue-600' : 'bg-gray-600'
                        }`}
                      >
                        {sessionsForDay.length} sessie{sessionsForDay.length !== 1 ? 's' : ''}
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  {sessionsForDay.length === 0 ? (
                    <div className="text-center text-gray-400 py-12">
                      <Calendar className="h-12 w-12 mx-auto mb-3 opacity-30" />
                      <p className="text-sm">Geen trainingen</p>
                    </div>
                  ) : (
                    sessionsForDay.map((session) => (
                      <Card
                        key={session.id}
                        className={`cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105 border-l-4 ${
                          getAgeGroupColor(session.ageGroup)
                        } ${session.status === 'completed' ? 'opacity-75' : ''}`}
                        onClick={() => {
                          setSelectedSession(session);
                          setShowSessionDialog(true);
                        }}
                      >
                        <CardContent className="p-4">
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                {getFocusAreaIcon(session.focusArea)}
                                <Badge className={getIntensityColor(session.intensity)}>
                                  {session.intensity}
                                </Badge>
                              </div>
                              <Badge className={getStatusColor(session.status)}>
                                {session.status === 'planned' ? 'Gepland' : 
                                 session.status === 'completed' ? 'Voltooid' : 'Geannuleerd'}
                              </Badge>
                            </div>
                            
                            <div>
                              <div className="font-semibold text-sm text-gray-900 mb-1">
                                {session.focusArea}
                              </div>
                              <div className="text-xs text-gray-600 space-y-1">
                                <div className="flex items-center space-x-1">
                                  <Clock className="h-3 w-3" />
                                  <span>{session.time} ({session.duration}min)</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Users className="h-3 w-3" />
                                  <span>{session.ageGroup}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <MapPin className="h-3 w-3" />
                                  <span>{session.location}</span>
                                </div>
                              </div>
                            </div>
                            
                            {session.notes && (
                              <div className="text-xs text-gray-500 italic line-clamp-2">
                                {session.notes}
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Session Detail Dialog */}
        <Dialog open={showSessionDialog} onOpenChange={setShowSessionDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-3">
                {selectedSession && getFocusAreaIcon(selectedSession.focusArea)}
                <span>{selectedSession?.focusArea}</span>
              </DialogTitle>
              <DialogDescription>
                {selectedSession && format(parseISO(selectedSession.date), 'EEEE d MMMM yyyy', { locale: nl })} • {selectedSession?.time}
              </DialogDescription>
            </DialogHeader>
            
            {selectedSession && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-600">Leeftijdsgroep</label>
                      <p className="text-lg font-semibold text-gray-900">{selectedSession.ageGroup}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-600">Locatie</label>
                      <p className="text-lg font-semibold text-gray-900">{selectedSession.location}</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-600">Duur</label>
                      <p className="text-lg font-semibold text-gray-900">{selectedSession.duration} minuten</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-600">Intensiteit</label>
                      <Badge className={getIntensityColor(selectedSession.intensity)}>
                        {selectedSession.intensity}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-600">Toegewezen Elementen</label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedSession.assignedElements.map((elementId) => (
                      <Badge key={elementId} variant="outline" className="bg-gray-50">
                        {elementId}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                {selectedSession.notes && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Notities</label>
                    <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-900">{selectedSession.notes}</p>
                    </div>
                  </div>
                )}
                
                <div className="flex justify-end space-x-3 pt-4 border-t">
                  <Button variant="outline" onClick={() => setShowSessionDialog(false)}>
                    Sluiten
                  </Button>
                  <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
                    <Edit className="h-4 w-4 mr-2" />
                    Bewerken
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Jaarplanning Parameter Bewerking Dialog */}
        <Dialog open={showEditPlanDialog} onOpenChange={setShowEditPlanDialog}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-3">
                <Calendar className="h-6 w-6" />
                <span>{editingPlan ? 'Jaarplanning Bewerken' : 'Nieuwe Jaarplanning'}</span>
              </DialogTitle>
              <DialogDescription>
                Wijzig de parameters, thema's en instellingen van de jaarplanning
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Basis Informatie */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Naam</label>
                  <Input 
                    value={editPlanData.name}
                    onChange={(e) => setEditPlanData(prev => ({...prev, name: e.target.value}))}
                    placeholder="Naam van de jaarplanning"
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Leeftijdsgroep</label>
                  <Select 
                    value={editPlanData.ageGroup} 
                    onValueChange={(value) => setEditPlanData(prev => ({...prev, ageGroup: value}))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer leeftijdsgroep" />
                    </SelectTrigger>
                    <SelectContent>
                      {ageGroupOptions.map(age => (
                        <SelectItem key={age} value={age}>{age}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Beschrijving</label>
                <Textarea 
                  value={editPlanData.description}
                  onChange={(e) => setEditPlanData(prev => ({...prev, description: e.target.value}))}
                  placeholder="Beschrijving van de jaarplanning"
                  rows={3}
                />
              </div>

              {/* Periode en Seizoen */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Seizoen</label>
                  <Input 
                    value={editPlanData.season}
                    onChange={(e) => setEditPlanData(prev => ({...prev, season: e.target.value}))}
                    placeholder="2024-2025"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Start Datum</label>
                  <Input 
                    type="date"
                    value={editPlanData.startDate}
                    onChange={(e) => setEditPlanData(prev => ({...prev, startDate: e.target.value}))}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Eind Datum</label>
                  <Input 
                    type="date"
                    value={editPlanData.endDate}
                    onChange={(e) => setEditPlanData(prev => ({...prev, endDate: e.target.value}))}
                  />
                </div>
              </div>

              {/* Training Schema */}
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Sessies per week: {editPlanData.sessionsPerWeek}
                  </label>
                  <Input 
                    type="range"
                    min="1"
                    max="6"
                    value={editPlanData.sessionsPerWeek}
                    onChange={(e) => setEditPlanData(prev => ({...prev, sessionsPerWeek: parseInt(e.target.value)}))}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-3 block">Trainingsdagen</label>
                  <div className="grid grid-cols-4 gap-3">
                    {['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag'].map(day => (
                      <div key={day} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={day}
                          checked={editPlanData.trainingDays.includes(day)}
                          onChange={() => handleTrainingDayToggle(day)}
                          className="rounded border-gray-300"
                        />
                        <label htmlFor={day} className="text-sm text-gray-700">{day}</label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* IADATABANK Thema Selectie */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Focus Thema's uit IADATABANK</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {categories.map(theme => (
                    <div key={theme} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={theme}
                        checked={editPlanData.focusThemes.includes(theme)}
                        onChange={() => handleThemeToggle(theme)}
                        className="rounded border-gray-300"
                      />
                      <label htmlFor={theme} className="text-sm text-gray-700 font-medium">
                        {theme}
                      </label>
                    </div>
                  ))}
                </div>
                {editPlanData.focusThemes.length > 0 && (
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-800">
                      <strong>Geselecteerde thema's:</strong> {editPlanData.focusThemes.join(', ')}
                    </p>
                  </div>
                )}
              </div>

              {/* Actie Knoppen */}
              <div className="flex justify-between pt-6 border-t">
                <div>
                  {editingPlan && (
                    <Button 
                      variant="outline" 
                      className="text-red-600 border-red-300 hover:bg-red-50"
                      onClick={() => handleDeletePlan(editingPlan.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Verwijderen
                    </Button>
                  )}
                </div>
                <div className="flex space-x-3">
                  <Button variant="outline" onClick={() => setShowEditPlanDialog(false)}>
                    Annuleren
                  </Button>
                  <Button 
                    onClick={handleSavePlan}
                    className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
                  >
                    <Star className="h-4 w-4 mr-2" />
                    {editingPlan ? 'Opslaan' : 'Aanmaken'}
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}