import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Play, Video, Download, UserCircle, FileDown, FileSpreadsheet, Calendar, CalendarDays, Edit, Trash2, Plus, FileText } from "lucide-react";
import { jsPDF } from "jspdf";
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { useTranslation } from "@/lib/i18n";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

// Training program type definition
type ProgramDifficulty = "beginner" | "intermediate" | "advanced";

type ProgramData = {
  id: number;
  name: string;
  description: string;
  category: string;
  ageGroup: string;
  focusArea: string;
  duration: number;
  author: string;
  difficulty: ProgramDifficulty;
  createdAt: string;
  startDate: string;
  endDate: string;
  trainingDays: string[];
};

interface TrainingProgram {
  id: number;
  name: string;
  startDate: string;
  endDate: string;
  trainingDays: string[];
  created: string;
  events: any[];
}

interface FormData {
  name: string;
  startDate: string;
  endDate: string;
  trainingDays: string[];
}

export default function TrainingProgramsPage() {
  const { t } = useTranslation();

  // Training day options
  const trainingDayOptions = [
    { value: "monday", label: "Maandag" },
    { value: "tuesday", label: "Dinsdag" },
    { value: "wednesday", label: "Woensdag" },
    { value: "thursday", label: "Donderdag" },
    { value: "friday", label: "Vrijdag" },
    { value: "saturday", label: "Zaterdag" },
    { value: "sunday", label: "Zondag" }
  ];

  // Detailed training components
  const opwarmingOefeningen = [
    {
      naam: "Inlopen",
      duur: "5 minuten",
      intensiteit: "60-65% max HR",
      uitvoering: "Rustig tempo, voetcontact op voorvoet, ontspannen armen",
      doel: "Verhogen lichaamstemperatuur en bloedcirculatie"
    },
    {
      naam: "Dynamische stretching",
      duur: "3 minuten",
      intensiteit: "Licht",
      uitvoering: "Leg swings, arm circles, torso twists - 10x elk",
      doel: "Gewrichten mobiliseren en spieren voorbereiden"
    },
    {
      naam: "Activatie oefeningen",
      duur: "2 minuten", 
      intensiteit: "Matig",
      uitvoering: "High knees, butt kicks, side shuffles - 30s elk",
      doel: "Neuromusculaire activatie voor training"
    }
  ];

  const hiitConditieOpbouw = {
    foundation: {
      work: 15,
      rest: 30,
      series: 8,
      intensity: "60% max HR",
      description: "Foundation start - 15s werk/30s rust",
      oefeningen: [
        "Rustig joggen op plaats (15s)",
        "Lichte high knees (15s)",
        "Zacht jumping jacks (15s)",
        "Walking lunges (15s)",
        "Arm swings (15s)",
        "Lichte march op plaats (15s)"
      ]
    },
    building: {
      work: 30,
      rest: 60,
      series: 12,
      intensity: "60% → 75% max HR",
      description: "Building fase - 30s werk/60s rust, opbouw in %",
      oefeningen: [
        "Shuttle runs (20m)",
        "Mountain climbers (30s)",
        "Burpees aangepast tempo (30s)",
        "High knees tempo verhogen (30s)",
        "Step-ups op plaats (30s)",
        "Squat jumps laag tempo (30s)"
      ]
    },
    work: {
      work: 10,
      rest: 45,
      series: 8,
      intensity: "100% max HR",
      description: "Work fase - 10s→30s werk/45s rust over 8 weken",
      oefeningen: [
        "All-out sprints (30m)",
        "Explosive burpees (maximale snelheid)",
        "Mountain climbers (100% tempo)",
        "High knees explosief",
        "Jump squats maximaal",
        "Battle ropes all-out"
      ]
    }
  };

  const krachtTrainingOefeningen = {
    core: [
      {
        naam: "Plank variations",
        series: 3,
        repetities: "30-60s",
        rust: "30s",
        uitvoering: "Standard plank → side plank → plank with leg lift",
        doel: "Core stabiliteit en kracht"
      },
      {
        naam: "Russian twists",
        series: 3,
        repetities: "20 per kant",
        rust: "30s",
        uitvoering: "Zittend, voeten omhoog, romp draaien links-rechts",
        doel: "Rotatie kracht en stabiliteit"
      },
      {
        naam: "Dead bug",
        series: 3,
        repetities: "10 per kant",
        rust: "30s",
        uitvoering: "Rug op grond, tegenovergestelde arm/been strekken",
        doel: "Core controle en coördinatie"
      }
    ],
    arms: [
      {
        naam: "Push-up variations",
        series: 3,
        repetities: "8-15",
        rust: "45s",
        uitvoering: "Standard → wide grip → diamond push-ups",
        doel: "Borst, schouders, triceps kracht"
      },
      {
        naam: "Pike push-ups",
        series: 3,
        repetities: "8-12",
        rust: "45s",
        uitvoering: "Downward dog positie, hoofd naar grond",
        doel: "Schouder kracht en stabiliteit"
      },
      {
        naam: "Tricep dips",
        series: 3,
        repetities: "10-15",
        rust: "45s",
        uitvoering: "Op rand, ellebogen naar achteren",
        doel: "Triceps en schouder achterzijde"
      }
    ],
    legs: [
      {
        naam: "Squat variations",
        series: 4,
        repetities: "15-20",
        rust: "60s",
        uitvoering: "Bodyweight → jump squats → single leg",
        doel: "Quadriceps, hamstrings, glutes"
      },
      {
        naam: "Lunge variations",
        series: 3,
        repetities: "12 per been",
        rust: "45s",
        uitvoering: "Forward → lateral → reverse lunges",
        doel: "Unilaterale beenkracht en balans"
      },
      {
        naam: "Calf raises",
        series: 3,
        repetities: "20-25",
        rust: "30s",
        uitvoering: "Op tenen, langzaam op en neer",
        doel: "Kuitspieren en explosiviteit"
      }
    ]
  };

  const blessurepreventieOefeningen = [
    {
      naam: "Hamstring stretch",
      duur: "2x 30s per been",
      type: "Statisch",
      uitvoering: "Zit op grond, been gestrekt, andere been gebogen. Reik naar tenen tot lichte spanning",
      doel: "Flexibiliteit achterzijde bovenbeen"
    },
    {
      naam: "Hip flexor stretch", 
      duur: "2x 30s per kant",
      type: "Statisch",
      uitvoering: "Lunge positie, achterste knie op grond, heup naar voren duwen",
      doel: "Flexibiliteit voorzijde heup"
    },
    {
      naam: "IT-band stretch",
      duur: "2x 30s per kant",
      type: "Statisch", 
      uitvoering: "Staand rechter been over linker, buig zijwaarts naar rechts",
      doel: "Flexibiliteit buitenzijde bovenbeen"
    },
    {
      naam: "Calf stretch",
      duur: "2x 30s per been",
      type: "Statisch",
      uitvoering: "Stap voorwaarts tegen muur, achterste been gestrekt, hiel op grond",
      doel: "Flexibiliteit kuitspieren"
    },
    {
      naam: "Glute stretch",
      duur: "2x 30s per kant", 
      type: "Statisch",
      uitvoering: "Lig op rug, trek knie naar borst, draai been naar andere kant",
      doel: "Flexibiliteit bilspieren"
    },
    {
      naam: "Shoulder stretch",
      duur: "2x 30s per arm",
      type: "Statisch",
      uitvoering: "Arm over borst trekken, met andere arm ondersteunen",
      doel: "Flexibiliteit schouders"
    },
    {
      naam: "Ankle mobility",
      duur: "15 circles per richting",
      type: "Dynamisch",
      uitvoering: "Zittend, voet optillen, trage cirkels maken",
      doel: "Mobiliteit enkelgewricht"
    },
    {
      naam: "Foam rolling",
      duur: "2 minuten totaal",
      type: "Self-massage",
      uitvoering: "Rol over IT-band, quads, hamstrings - 30s elk",
      doel: "Spierweefsel regeneratie"
    },
    {
      naam: "Ademhaling",
      duur: "10 cycli",
      type: "Ontspanning",
      uitvoering: "4s inademen → 4s vasthouden → 6s uitademen",
      doel: "Herstel en ontspanning"
    }
  ];

  // State management
  const [programs, setPrograms] = useState<TrainingProgram[]>([
    {
      id: 1,
      name: "Pre Season",
      startDate: "2025-01-15",
      endDate: "2025-03-15",
      trainingDays: ["monday", "wednesday", "friday"],
      created: "15/01/2025",
      events: []
    }
  ]);

  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingProgram, setEditingProgram] = useState<TrainingProgram | null>(null);
  const [formData, setFormData] = useState<FormData>({
    name: "",
    startDate: "",
    endDate: "",
    trainingDays: []
  });

  // Form handlers
  const resetForm = () => {
    setFormData({
      name: "",
      startDate: "",
      endDate: "",
      trainingDays: []
    });
    setEditingProgram(null);
  };

  const handleCreateProgram = () => {
    setShowCreateDialog(true);
    resetForm();
  };

  const handleEditProgram = (program: TrainingProgram) => {
    setEditingProgram(program);
    setFormData({
      name: program.name,
      startDate: program.startDate,
      endDate: program.endDate,
      trainingDays: program.trainingDays
    });
    setShowCreateDialog(true);
  };

  const handleSaveProgram = () => {
    if (!formData.name || !formData.startDate || !formData.endDate || formData.trainingDays.length === 0) {
      alert("Vul alle velden in en selecteer minimaal één trainingsdag.");
      return;
    }

    const newProgram: TrainingProgram = {
      id: editingProgram ? editingProgram.id : Date.now(),
      name: formData.name,
      startDate: formData.startDate,
      endDate: formData.endDate,
      trainingDays: formData.trainingDays,
      created: new Date().toLocaleDateString('nl-NL'),
      events: editingProgram ? editingProgram.events : []
    };

    if (editingProgram) {
      setPrograms(programs.map(p => p.id === editingProgram.id ? newProgram : p));
    } else {
      setPrograms([...programs, newProgram]);
    }

    setShowCreateDialog(false);
    resetForm();
  };

  const handleDeleteProgram = (programId: number) => {
    if (confirm("Weet je zeker dat je dit programma wilt verwijderen?")) {
      setPrograms(programs.filter(p => p.id !== programId));
    }
  };

  const handleDayToggle = (dayValue: string, checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        trainingDays: [...formData.trainingDays, dayValue]
      });
    } else {
      setFormData({
        ...formData,
        trainingDays: formData.trainingDays.filter(day => day !== dayValue)
      });
    }
  };

  // Export Functions
  const exportToPDF = (program: TrainingProgram) => {
    try {
      const doc = new jsPDF();
      let yPosition = 20;
      
      // Title
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text(`PRE SEASON PROGRAM: ${program.name}`, 10, yPosition);
      yPosition += 15;
      
      // Program Details
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text(`Periode: ${program.startDate} tot ${program.endDate}`, 10, yPosition);
      yPosition += 8;
      doc.text(`Training dagen: ${program.trainingDays.map(day => trainingDayOptions.find(opt => opt.value === day)?.label).join(", ")}`, 10, yPosition);
      yPosition += 8;
      doc.text(`Aangemaakt: ${program.created}`, 10, yPosition);
      yPosition += 15;
      
      // 1. OPWARMING - DETAILED
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('1. OPWARMING (10 minuten)', 10, yPosition);
      yPosition += 12;
      
      opwarmingOefeningen.forEach(oef => {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${oef.naam} (${oef.duur})`, 15, yPosition);
        yPosition += 6;
        doc.setFont('helvetica', 'normal');
        doc.text(`  Intensiteit: ${oef.intensiteit}`, 20, yPosition);
        yPosition += 5;
        doc.text(`  Uitvoering: ${oef.uitvoering}`, 20, yPosition);
        yPosition += 5;
        doc.text(`  Doel: ${oef.doel}`, 20, yPosition);
        yPosition += 8;
      });
      
      // 2. CONDITIE HIIT - DETAILED WITH PROGRESSION
      doc.addPage();
      yPosition = 20;
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('2. CONDITIE HIIT (30 minuten) - PROGRESSIEVE OPBOUW', 10, yPosition);
      yPosition += 12;
      
      // Foundation Phase
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('FOUNDATION FASE (Week 1-3):', 15, yPosition);
      yPosition += 8;
      doc.setFont('helvetica', 'normal');
      doc.text(`${hiitConditieOpbouw.foundation.work}s werk / ${hiitConditieOpbouw.foundation.rest}s rust × ${hiitConditieOpbouw.foundation.series} series (${hiitConditieOpbouw.foundation.intensity})`, 20, yPosition);
      yPosition += 6;
      
      hiitConditieOpbouw.foundation.oefeningen.forEach(oef => {
        doc.text(`• ${oef}`, 25, yPosition);
        yPosition += 5;
      });
      yPosition += 8;
      
      // Building Phase
      doc.setFont('helvetica', 'bold');
      doc.text('BUILDING FASE (Week 4-6):', 15, yPosition);
      yPosition += 8;
      doc.setFont('helvetica', 'normal');
      doc.text(`${hiitConditieOpbouw.building.work}s werk / ${hiitConditieOpbouw.building.rest}s rust × ${hiitConditieOpbouw.building.series} series (${hiitConditieOpbouw.building.intensity})`, 20, yPosition);
      yPosition += 6;
      
      hiitConditieOpbouw.building.oefeningen.forEach(oef => {
        doc.text(`• ${oef}`, 25, yPosition);
        yPosition += 5;
      });
      yPosition += 8;
      
      // Work Phase
      doc.setFont('helvetica', 'bold');
      doc.text('WORK FASE (Week 7-8):', 15, yPosition);
      yPosition += 8;
      doc.setFont('helvetica', 'normal');
      doc.text(`${hiitConditieOpbouw.work.work}s werk / ${hiitConditieOpbouw.work.rest}s rust × ${hiitConditieOpbouw.work.series} series (${hiitConditieOpbouw.work.intensity})`, 20, yPosition);
      yPosition += 6;
      
      hiitConditieOpbouw.work.oefeningen.forEach(oef => {
        doc.text(`• ${oef}`, 25, yPosition);
        yPosition += 5;
      });
      
      // 3. KRACHT HIIT
      doc.addPage();
      yPosition = 20;
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('3. KRACHT HIIT (15 minuten) - PER SPIERGROEP', 10, yPosition);
      yPosition += 12;
      
      // Core exercises
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('CORE TRAINING (5 minuten):', 15, yPosition);
      yPosition += 8;
      
      krachtTrainingOefeningen.core.forEach(oef => {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${oef.naam}`, 20, yPosition);
        yPosition += 6;
        doc.setFont('helvetica', 'normal');
        doc.text(`  ${oef.series} series × ${oef.repetities}, rust ${oef.rust}`, 25, yPosition);
        yPosition += 5;
        doc.text(`  Uitvoering: ${oef.uitvoering}`, 25, yPosition);
        yPosition += 5;
        doc.text(`  Doel: ${oef.doel}`, 25, yPosition);
        yPosition += 8;
      });

      // 4. BLESSUREPREVENTIE / COOL-DOWN
      doc.addPage();
      yPosition = 20;
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('4. BLESSUREPREVENTIE / COOL-DOWN (5 minuten)', 10, yPosition);
      yPosition += 12;
      
      blessurepreventieOefeningen.forEach(oef => {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${oef.naam} (${oef.duur})`, 15, yPosition);
        yPosition += 6;
        doc.setFont('helvetica', 'normal');
        doc.text(`  Type: ${oef.type}`, 20, yPosition);
        yPosition += 5;
        doc.text(`  Uitvoering: ${oef.uitvoering}`, 20, yPosition);
        yPosition += 5;
        doc.text(`  Doel: ${oef.doel}`, 20, yPosition);
        yPosition += 8;
      });
      
      const fileName = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_detailed_training_program.pdf`;
      doc.save(fileName);
      
      alert(`Gedetailleerd PDF Training programma "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('PDF Export Error:', error);
      alert(`Fout bij het maken van PDF: ${error instanceof Error ? error.message : 'Onbekende fout'}`);
    }
  };

  const exportToExcel = (program: TrainingProgram) => {
    try {
      const wb = XLSX.utils.book_new();
      
      // Sheet 1: Program Overview
      const overview = [
        ['PRE SEASON TRAINING PROGRAM'],
        ['Program Naam', program.name],
        ['Periode', `${program.startDate} tot ${program.endDate}`],
        ['Training Dagen', program.trainingDays.map(day => trainingDayOptions.find(opt => opt.value === day)?.label).join(', ')],
        ['Aangemaakt', program.created],
        [''],
        ['TRAINING STRUCTUUR (60 MINUTEN)'],
        ['Component', 'Duur', 'Beschrijving'],
        ['Opwarming', '10 min', 'Gedetailleerde warming-up oefeningen'],
        ['Conditie HIIT', '30 min', 'Progressieve opbouw: Foundation → Building → Work'],
        ['Kracht HIIT', '15 min', 'Core, Armen, Benen - gedetailleerd per spiergroep'],
        ['Blessurepreventie', '5 min', 'Stretching en mobiliteit oefeningen']
      ];
      const ws1 = XLSX.utils.aoa_to_sheet(overview);
      XLSX.utils.book_append_sheet(wb, ws1, 'Program Overview');
      
      // Sheet 2: Opwarming Details
      const opwarmingData = [
        ['OPWARMING (10 MINUTEN)', '', '', ''],
        ['Oefening', 'Duur', 'Intensiteit', 'Uitvoering', 'Doel'],
        ...opwarmingOefeningen.map(oef => [oef.naam, oef.duur, oef.intensiteit, oef.uitvoering, oef.doel])
      ];
      const ws2 = XLSX.utils.aoa_to_sheet(opwarmingData);
      XLSX.utils.book_append_sheet(wb, ws2, 'Opwarming');
      
      // Sheet 3: HIIT Conditie Details
      const hiitConditieData = [
        ['CONDITIE HIIT (30 MINUTEN) - PROGRESSIEVE OPBOUW', '', '', '', ''],
        [''],
        ['FOUNDATION FASE (Week 1-3)', '', '', '', ''],
        ['Werk/Rust/Series', `${hiitConditieOpbouw.foundation.work}s / ${hiitConditieOpbouw.foundation.rest}s / ${hiitConditieOpbouw.foundation.series}x`, '', 'Intensiteit', hiitConditieOpbouw.foundation.intensity],
        ['Oefeningen:', '', '', '', ''],
        ...hiitConditieOpbouw.foundation.oefeningen.map(oef => [oef, '', '', '', '']),
        [''],
        ['BUILDING FASE (Week 4-6)', '', '', '', ''],
        ['Werk/Rust/Series', `${hiitConditieOpbouw.building.work}s / ${hiitConditieOpbouw.building.rest}s / ${hiitConditieOpbouw.building.series}x`, '', 'Intensiteit', hiitConditieOpbouw.building.intensity],
        ['Oefeningen:', '', '', '', ''],
        ...hiitConditieOpbouw.building.oefeningen.map(oef => [oef, '', '', '', '']),
        [''],
        ['WORK FASE (Week 7-8)', '', '', '', ''],
        ['Werk/Rust/Series', `${hiitConditieOpbouw.work.work}s / ${hiitConditieOpbouw.work.rest}s / ${hiitConditieOpbouw.work.series}x`, '', 'Intensiteit', hiitConditieOpbouw.work.intensity],
        ['Oefeningen:', '', '', '', ''],
        ...hiitConditieOpbouw.work.oefeningen.map(oef => [oef, '', '', '', ''])
      ];
      const ws3 = XLSX.utils.aoa_to_sheet(hiitConditieData);
      XLSX.utils.book_append_sheet(wb, ws3, 'HIIT Conditie');
      
      // Sheet 4: Kracht Training Details
      const krachtData = [
        ['KRACHT HIIT (15 MINUTEN) - PER SPIERGROEP', '', '', '', ''],
        [''],
        ['CORE TRAINING (5 minuten)', '', '', '', ''],
        ['Oefening', 'Series', 'Repetities', 'Rust', 'Uitvoering', 'Doel'],
        ...krachtTrainingOefeningen.core.map(oef => [oef.naam, oef.series, oef.repetities, oef.rust, oef.uitvoering, oef.doel])
      ];
      const ws4 = XLSX.utils.aoa_to_sheet(krachtData);
      XLSX.utils.book_append_sheet(wb, ws4, 'Kracht Training');
      
      // Sheet 5: Blessurepreventie Details
      const blessurepreventieData = [
        ['BLESSUREPREVENTIE / COOL-DOWN (5 MINUTEN)', '', '', '', ''],
        ['Oefening', 'Duur', 'Type', 'Uitvoering', 'Doel'],
        ...blessurepreventieOefeningen.map(oef => [oef.naam, oef.duur, oef.type, oef.uitvoering, oef.doel])
      ];
      const ws5 = XLSX.utils.aoa_to_sheet(blessurepreventieData);
      XLSX.utils.book_append_sheet(wb, ws5, 'Blessurepreventie');
      
      const fileName = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_detailed_training_program.xlsx`;
      XLSX.writeFile(wb, fileName);
      
      alert(`Gedetailleerd Excel Training programma "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('Excel Export Error:', error);
      alert(`Fout bij het maken van Excel bestand: ${error instanceof Error ? error.message : 'Onbekende fout'}`);
    }
  };

  const exportToICS = (program: TrainingProgram) => {
    try {
      const icsEvents = program.events.map((event: any) => {
        const eventDate = new Date(event.date + 'T19:00:00');
        const endDate = new Date(event.date + 'T20:00:00');
        
        const formatDate = (date: Date) => {
          return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
        };

        const summary = event.type === 'training' ? `Training ${event.phase || 'Foundation'}` : `Wedstrijd vs ${event.opponent || 'TBD'}`;
        const description = event.type === 'training' ? 'Training - 60 minuten structuur' : `Tegenstander: ${event.opponent || 'Te bepalen'}`;
        
        return `BEGIN:VEVENT
UID:${event.id}@preseason-program
DTSTART:${formatDate(eventDate)}
DTEND:${formatDate(endDate)}
SUMMARY:${summary}
DESCRIPTION:${description}
LOCATION:${event.location || 'Sportcomplex'}
END:VEVENT`;
      });

      const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Soccer Club Pro//Training Program//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
X-WR-CALNAME:${program.name}
X-WR-CALDESC:Pre Season Training Program ${program.startDate} - ${program.endDate}
${icsEvents.join('\n')}
END:VCALENDAR`;

      const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_training_calendar.ics`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      alert(`ICS Training kalender "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('ICS Export Error:', error);
      alert(`Fout bij het maken van ICS bestand: ${error instanceof Error ? error.message : 'Onbekende fout'}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Pre Season Programs</h1>
            <p className="text-muted-foreground">Professionele voorbereiding programma's met export functionaliteit</p>
          </div>
          <Button onClick={handleCreateProgram} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Nieuw Programma
          </Button>
        </div>
        
        {/* Programs List */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {programs.map((program) => (
            <Card key={program.id} className="border-2 hover:border-blue-300 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{program.name}</CardTitle>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => handleEditProgram(program)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteProgram(program.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="font-medium">Start:</span>
                    <br />
                    {program.startDate}
                  </div>
                  <div>
                    <span className="font-medium">Eind:</span>
                    <br />
                    {program.endDate}
                  </div>
                </div>
                
                <div className="text-sm">
                  <span className="font-medium">Training dagen:</span>
                  <br />
                  {program.trainingDays.map(day => trainingDayOptions.find(opt => opt.value === day)?.label).join(", ")}
                </div>
                
                <div className="flex gap-2 mt-4">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => exportToPDF(program)}
                  >
                    <FileText className="h-4 w-4 mr-1" />
                    PDF
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => exportToExcel(program)}
                  >
                    Excel
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => exportToICS(program)}
                  >
                    ICS
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {editingProgram ? "Programma Bewerken" : "Nieuw Training Programma"}
            </DialogTitle>
            <DialogDescription>
              Vul de gegevens in voor je training programma
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Programma Naam</Label>
              <Input
                id="name"
                placeholder="bijv. Pre Season"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="startDate">Start Datum</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="endDate">Eind Datum</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label>Training Dagen</Label>
              <div className="grid grid-cols-2 gap-2">
                {trainingDayOptions.map((day) => (
                  <div key={day.value} className="flex items-center space-x-2">
                    <Checkbox
                      id={day.value}
                      checked={formData.trainingDays.includes(day.value)}
                      onCheckedChange={(checked) => handleDayToggle(day.value, !!checked)}
                    />
                    <Label htmlFor={day.value} className="text-sm font-normal">
                      {day.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              Annuleren
            </Button>
            <Button onClick={handleSaveProgram}>
              {editingProgram ? "Opslaan" : "Aanmaken"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}