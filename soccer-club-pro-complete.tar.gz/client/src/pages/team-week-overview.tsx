import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Calendar, ChevronLeft, ChevronRight, Users, Clock, MapPin, Trophy, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format, startOfWeek, endOfWeek, addWeeks, subWeeks, parseISO, isWithinInterval } from 'date-fns';
import { nl } from 'date-fns/locale';

interface TeamScheduleEntry {
  id: number;
  teamId: number;
  yearPlanId?: number;
  yearPlanSessionId?: number;
  teamName?: string;
  date: string;
  startTime: string;
  endTime: string;
  duration: number;
  eventType: string;
  title: string;
  location: string;
  notes?: string;
  mainTheme?: string;
  categoryInfo?: string;
  fullDetails?: string;
  opponent?: string;
  isVaria: boolean;
  variaType?: string;
  status: string;
  themes?: string[];
  selectedItems?: any[];
}

interface TeamWeekData {
  team: {
    id: number;
    name: string;
    ageGroup: string;
  };
  schedule: TeamScheduleEntry[];
  totalSessions: number;
  trainingCount: number;
  variaCount: number;
}

export default function TeamWeekOverview() {
  // Start with a week that has sessions (July 21, 2025)
  const [currentWeek, setCurrentWeek] = useState(new Date('2025-07-21'));

  // Calculate week boundaries
  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 });

  // Fetch teams overview data
  const { data: teamsData, isLoading, error } = useQuery({
    queryKey: ['/api/teams-overview'],
    retry: false,
  });

  // Navigation functions
  const goToPreviousWeek = () => {
    setCurrentWeek(subWeeks(currentWeek, 1));
  };

  const goToNextWeek = () => {
    setCurrentWeek(addWeeks(currentWeek, 1));
  };

  const goToCurrentWeek = () => {
    setCurrentWeek(new Date());
  };

  // Filter sessions for current week
  const getWeekSessions = (schedule: TeamScheduleEntry[]) => {
    return schedule.filter(session => {
      const sessionDate = parseISO(session.date);
      return isWithinInterval(sessionDate, { start: weekStart, end: weekEnd });
    });
  };

  // Group sessions by day of week
  const getSessionsByDay = (sessions: TeamScheduleEntry[]) => {
    const days = ['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag'];
    const sessionsByDay: { [key: string]: TeamScheduleEntry[] } = {};
    
    days.forEach(day => {
      sessionsByDay[day] = [];
    });

    sessions.forEach(session => {
      const sessionDate = parseISO(session.date);
      const dayName = format(sessionDate, 'EEEE', { locale: nl });
      const dayKey = dayName.charAt(0).toUpperCase() + dayName.slice(1);
      
      if (sessionsByDay[dayKey]) {
        sessionsByDay[dayKey].push(session);
      }
    });

    return sessionsByDay;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-64 mb-6"></div>
            <div className="grid gap-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="bg-white rounded-lg p-6">
                  <div className="h-6 bg-gray-200 rounded w-48 mb-4"></div>
                  <div className="grid grid-cols-7 gap-4">
                    {[...Array(7)].map((_, j) => (
                      <div key={j} className="h-32 bg-gray-100 rounded"></div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto">
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-6">
              <div className="flex items-center space-x-2 text-red-600">
                <Trophy className="h-5 w-5" />
                <span className="font-medium">Fout bij laden van teams</span>
              </div>
              <p className="text-red-600 mt-2">
                Er kon geen verbinding worden gemaakt met de team data. Probeer de pagina te vernieuwen.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const teams = teamsData?.teams || [];
  const totalTeams = teamsData?.totalTeams || 0;
  const totalSessions = teamsData?.totalSessions || 0;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Team Weekoverzicht</h1>
            <p className="text-gray-600 mt-2">
              Overzicht van alle teams voor week {format(weekStart, 'dd MMM', { locale: nl })} - {format(weekEnd, 'dd MMM yyyy', { locale: nl })}
            </p>
          </div>
          
          {/* Week Navigation */}
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={goToPreviousWeek}
              className="flex items-center space-x-2"
            >
              <ChevronLeft className="h-4 w-4" />
              <span>Vorige Week</span>
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={goToCurrentWeek}
              className="px-4"
            >
              Deze Week
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={goToNextWeek}
              className="flex items-center space-x-2"
            >
              <span>Volgende Week</span>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Totaal Teams</p>
                  <p className="text-2xl font-bold text-blue-600">{totalTeams}</p>
                </div>
                <Users className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Totaal Sessies</p>
                  <p className="text-2xl font-bold text-green-600">{totalSessions}</p>
                </div>
                <Calendar className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Deze Week</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {teams.reduce((total, team) => total + getWeekSessions(team.schedule).length, 0)}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teams Weekly Schedule */}
        <div className="space-y-8">
          {teams.map((team: TeamWeekData) => {
            const weekSessions = getWeekSessions(team.schedule);
            const sessionsByDay = getSessionsByDay(weekSessions);
            const days = ['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag'];

            return (
              <Card key={team.team.id} className="overflow-hidden">
                <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-xl">{team.team.name}</CardTitle>
                      <p className="text-blue-100 mt-1">{team.team.ageGroup}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-blue-100 text-sm">Deze week:</p>
                      <p className="text-xl font-bold">{weekSessions.length} sessies</p>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="p-6">
                  <div className="grid grid-cols-7 gap-4">
                    {days.map((day, index) => {
                      const dayDate = new Date(weekStart);
                      dayDate.setDate(weekStart.getDate() + index);
                      const daySessions = sessionsByDay[day] || [];
                      
                      return (
                        <div key={day} className="border rounded-lg p-3 min-h-[120px]">
                          <div className="text-center mb-3">
                            <p className="font-semibold text-gray-900 text-sm">{day}</p>
                            <p className="text-xs text-gray-500">
                              {format(dayDate, 'dd/MM', { locale: nl })}
                            </p>
                          </div>
                          
                          <div className="space-y-2">
                            {daySessions.map((session) => (
                              <div 
                                key={session.id}
                                className={`p-2 rounded text-xs ${
                                  session.isVaria 
                                    ? 'bg-orange-100 border-l-2 border-orange-400' 
                                    : 'bg-green-100 border-l-2 border-green-400'
                                }`}
                              >
                                <div className="font-medium text-gray-900 truncate">
                                  {session.title}
                                </div>
                                <div className="text-gray-600 flex items-center mt-1">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {session.startTime} - {session.endTime}
                                </div>
                                {session.location && (
                                  <div className="text-gray-600 flex items-center mt-1">
                                    <MapPin className="h-3 w-3 mr-1" />
                                    <span className="truncate">{session.location}</span>
                                  </div>
                                )}
                                {session.opponent && (
                                  <div className="text-gray-600 flex items-center mt-1">
                                    <Trophy className="h-3 w-3 mr-1" />
                                    <span className="truncate">vs {session.opponent}</span>
                                  </div>
                                )}
                                {session.mainTheme && (
                                  <div className="text-blue-600 mt-1 truncate text-xs">
                                    {session.mainTheme}
                                  </div>
                                )}
                              </div>
                            ))}
                            
                            {daySessions.length === 0 && (
                              <div className="text-center text-gray-400 text-xs mt-4">
                                Geen activiteiten
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  {weekSessions.length === 0 && (
                    <div className="text-center py-8">
                      <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500">Geen activiteiten gepland voor deze week</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {teams.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <Users className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">Geen teams gevonden</h3>
              <p className="text-gray-500">
                Er zijn nog geen teams aangemaakt. Maak eerst teams aan om het weekoverzicht te bekijken.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}