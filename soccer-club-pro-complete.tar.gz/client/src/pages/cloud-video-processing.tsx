import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Cloud, Download, Upload, Play, CheckCircle, AlertCircle, Clock } from 'lucide-react';

interface VideoInfo {
  file: string;
  size: number;
  sizeGB: string;
  duration: number;
  durationFormatted: string;
  targetFrames: number;
  frameRate: number;
  resolution: string;
}

interface Progress {
  frameCount: number;
  progress: number;
  targetFrames: number;
  remaining: number;
  status: string;
}

interface CloudProvider {
  name: string;
  features: string[];
  recommended: boolean;
  note?: string;
}

export default function CloudVideoProcessing() {
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [progress, setProgress] = useState<Progress | null>(null);
  const [cloudProviders, setCloudProviders] = useState<CloudProvider[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadVideoInfo();
    loadProgress();
    loadCloudOptions();
  }, []);

  const loadVideoInfo = async () => {
    try {
      const response = await fetch('/api/cloud-video/info');
      const data = await response.json();
      setVideoInfo(data);
    } catch (err) {
      setError('Failed to load video information');
    }
  };

  const loadProgress = async () => {
    try {
      const response = await fetch('/api/cloud-video/progress');
      const data = await response.json();
      setProgress(data);
    } catch (err) {
      setError('Failed to load progress information');
    }
  };

  const loadCloudOptions = async () => {
    try {
      const response = await fetch('/api/cloud-video/prepare');
      const data = await response.json();
      setCloudProviders(data.cloudProcessing.cloudProviders);
      setLoading(false);
    } catch (err) {
      setError('Failed to load cloud processing options');
      setLoading(false);
    }
  };

  const refreshProgress = () => {
    loadProgress();
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="flex items-center space-x-2">
            <Clock className="h-6 w-6 animate-spin" />
            <span>Loading video processing information...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-red-600">
              <AlertCircle className="h-5 w-5" />
              <span>Error</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>{error}</p>
            <Button onClick={() => window.location.reload()} className="mt-4">
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center space-x-2 mb-6">
        <Cloud className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold">Cloud Video Processing</h1>
          <p className="text-gray-600">Professional frame extraction for match analysis</p>
        </div>
      </div>

      {/* Video Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Play className="h-5 w-5" />
            <span>VVC Brasschaat vs Svelta Melsele Match Video</span>
          </CardTitle>
          <CardDescription>Professional soccer match recording for authentic analysis</CardDescription>
        </CardHeader>
        <CardContent>
          {videoInfo && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-gray-500">Duration</p>
                <p className="text-lg font-semibold">{videoInfo.durationFormatted}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-gray-500">File Size</p>
                <p className="text-lg font-semibold">{videoInfo.sizeGB} GB</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-gray-500">Target Frames</p>
                <p className="text-lg font-semibold">{videoInfo.targetFrames.toLocaleString()}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-gray-500">Quality</p>
                <p className="text-lg font-semibold">{videoInfo.resolution} HD</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Current Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Extraction Progress</span>
            <Button onClick={refreshProgress} variant="outline" size="sm">
              Refresh
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {progress && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">
                  {progress.frameCount.toLocaleString()} / {progress.targetFrames.toLocaleString()} frames
                </span>
                <Badge variant={progress.status === 'complete' ? 'default' : 'secondary'}>
                  {progress.status === 'complete' ? 'Complete' : 'In Progress'}
                </Badge>
              </div>
              <Progress value={progress.progress} className="w-full" />
              <p className="text-sm text-gray-600">
                {progress.progress.toFixed(1)}% complete • {progress.remaining.toLocaleString()} frames remaining
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Cloud Processing Recommendation */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-blue-800">
            <Cloud className="h-5 w-5" />
            <span>Cloud Processing Recommended</span>
          </CardTitle>
          <CardDescription>
            Large video files (4.2GB+) require cloud processing for complete frame extraction
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-white p-4 rounded-lg border">
            <h4 className="font-semibold mb-2">Why Cloud Processing?</h4>
            <ul className="text-sm space-y-1 text-gray-600">
              <li>• Complete processing of 3+ hour match videos</li>
              <li>• Professional-grade frame extraction at 0.5 FPS</li>
              <li>• High-quality 1920x1080 HD output</li>
              <li>• Reliable processing without interruptions</li>
              <li>• Estimated completion time: 20-30 minutes</li>
            </ul>
          </div>

          <Separator />

          <div>
            <h4 className="font-semibold mb-3">Recommended Cloud Providers</h4>
            <div className="grid gap-4">
              {cloudProviders.map((provider, index) => (
                <Card key={index} className={provider.recommended ? 'border-green-200 bg-green-50' : ''}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="font-semibold">{provider.name}</h5>
                      {provider.recommended && (
                        <Badge variant="default" className="bg-green-600">
                          Recommended
                        </Badge>
                      )}
                    </div>
                    <ul className="text-sm space-y-1 text-gray-600 mb-3">
                      {provider.features.map((feature, idx) => (
                        <li key={idx}>• {feature}</li>
                      ))}
                    </ul>
                    {provider.note && (
                      <p className="text-sm text-amber-600 bg-amber-50 p-2 rounded">
                        {provider.note}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Separator />

          <div className="bg-white p-4 rounded-lg border">
            <h4 className="font-semibold mb-2 flex items-center">
              <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
              Processing Workflow
            </h4>
            <ol className="text-sm space-y-2 text-gray-600">
              <li className="flex items-center">
                <Upload className="h-4 w-4 mr-2 text-blue-600" />
                1. Upload video to cloud storage service
              </li>
              <li className="flex items-center">
                <Cloud className="h-4 w-4 mr-2 text-blue-600" />
                2. Process video with cloud-based frame extraction
              </li>
              <li className="flex items-center">
                <Download className="h-4 w-4 mr-2 text-blue-600" />
                3. Download extracted frames back to local system
              </li>
              <li className="flex items-center">
                <Play className="h-4 w-4 mr-2 text-green-600" />
                4. Continue with authentic match analysis
              </li>
            </ol>
          </div>

          <div className="flex space-x-4">
            <Button className="flex-1" onClick={() => window.open('https://onedrive.live.com', '_blank')}>
              <Upload className="h-4 w-4 mr-2" />
              Open OneDrive
            </Button>
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={() => window.open('https://drive.google.com', '_blank')}
            >
              <Upload className="h-4 w-4 mr-2" />
              Open Google Drive
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Analysis Preview */}
      <Card>
        <CardHeader>
          <CardTitle>Ready for Authentic Match Analysis</CardTitle>
          <CardDescription>
            Once frame extraction is complete, the system will provide comprehensive match analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold text-blue-600">Individual Analysis</h4>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• Player movement tracking</li>
                <li>• Speed and acceleration</li>
                <li>• Ball touch frequency</li>
                <li>• Positioning heat maps</li>
                <li>• Sprint distances</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-green-600">Team Analysis</h4>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• Formation analysis</li>
                <li>• Possession percentages</li>
                <li>• Passing accuracy</li>
                <li>• Defensive movements</li>
                <li>• Attacking patterns</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-purple-600">Physical Metrics</h4>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• Distance covered</li>
                <li>• High-intensity runs</li>
                <li>• Heart rate zones</li>
                <li>• Fatigue analysis</li>
                <li>• Recovery periods</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}