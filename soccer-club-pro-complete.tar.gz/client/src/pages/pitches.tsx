import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Calendar, Drill, Plus, Edit } from "lucide-react";
import { Pitch } from "@/types";
import { formatDate, getStatusColor, cn } from "@/lib/utils";
import { AvatarUpload } from "@/components/ui/avatar-upload";

export default function Pitches() {
  const [isAddPitchOpen, setIsAddPitchOpen] = useState(false);
  
  // Fetch pitches data
  const { data: pitches, isLoading, error } = useQuery<Pitch[]>({
    queryKey: ['/api/pitches'],
  });

  if (isLoading) {
    return <div className="p-8 text-center">Loading pitches...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading pitches.</div>;
  }

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Pitch Management</h2>
        <Dialog open={isAddPitchOpen} onOpenChange={setIsAddPitchOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Pitch
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Pitch</DialogTitle>
              <DialogDescription>
                Enter the pitch details below to add a new pitch.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
              <div className="flex flex-col items-center justify-center">
                <AvatarUpload 
                  onUpload={(file) => console.log('File uploaded:', file)}
                  size="lg"
                />
                <p className="text-sm text-muted-foreground mt-2">Pitch Image</p>
              </div>
              <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Pitch Name</Label>
                  <Input id="name" placeholder="Pitch Name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input id="location" placeholder="Address or Location" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="size">Size</Label>
                  <Input id="size" placeholder="e.g. 100m x 64m" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="surface">Surface</Label>
                  <Select>
                    <SelectTrigger id="surface">
                      <SelectValue placeholder="Select surface type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="natural_grass">Natural Grass</SelectItem>
                      <SelectItem value="artificial_turf">Artificial Turf</SelectItem>
                      <SelectItem value="hybrid">Hybrid</SelectItem>
                      <SelectItem value="indoor">Indoor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select>
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Available</SelectItem>
                      <SelectItem value="in_use">In Use</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastMaintenance">Last Maintenance</Label>
                  <Input id="lastMaintenance" type="date" />
                </div>
                <div className="space-y-2 col-span-full">
                  <Label htmlFor="maintenanceNotes">Maintenance Notes</Label>
                  <Textarea id="maintenanceNotes" placeholder="Any notes about maintenance requirements" rows={3} />
                </div>
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsAddPitchOpen(false)}>
                Cancel
              </Button>
              <Button>Add Pitch</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Pitches grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {pitches?.map((pitch) => (
          <Card key={pitch.id} className="overflow-hidden">
            <div className="h-40 bg-primary-600 soccer-card-gradient flex items-center justify-center">
              {pitch.image ? (
                <img 
                  src={pitch.image} 
                  alt={pitch.name}
                  className="h-full w-full object-cover"
                />
              ) : (
                <MapPin className="h-12 w-12 text-white/80" />
              )}
            </div>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold text-foreground">{pitch.name}</h3>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "capitalize",
                    getStatusColor(pitch.status).bg,
                    getStatusColor(pitch.status).text
                  )}
                >
                  {pitch.status.replace('_', ' ')}
                </Badge>
              </div>
              
              <div className="space-y-2 text-sm mb-4">
                <div className="flex items-start">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 mr-2 flex-shrink-0" />
                  <span>{pitch.location}</span>
                </div>
                {pitch.size && (
                  <div className="flex items-start">
                    <i className="ri-rulers-line text-base text-muted-foreground mr-2"></i>
                    <span>{pitch.size}</span>
                  </div>
                )}
                {pitch.surface && (
                  <div className="flex items-start">
                    <i className="ri-landscape-line text-base text-muted-foreground mr-2"></i>
                    <span>{pitch.surface}</span>
                  </div>
                )}
                {pitch.lastMaintenance && (
                  <div className="flex items-start">
                    <Calendar className="h-4 w-4 text-muted-foreground mt-0.5 mr-2 flex-shrink-0" />
                    <span>Last Maintenance: {formatDate(pitch.lastMaintenance)}</span>
                  </div>
                )}
                {pitch.nextMaintenance && (
                  <div className="flex items-start">
                    <Drill className="h-4 w-4 text-muted-foreground mt-0.5 mr-2 flex-shrink-0" />
                    <span>Next Maintenance: {formatDate(pitch.nextMaintenance)}</span>
                  </div>
                )}
              </div>
              
              <div className="flex justify-end">
                <Button size="sm" className="flex items-center gap-1">
                  <Edit className="h-3.5 w-3.5" />
                  Manage
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {pitches?.length === 0 && (
          <div className="col-span-full text-center py-12">
            <p className="text-muted-foreground">No pitches found. Add your first pitch to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
}
