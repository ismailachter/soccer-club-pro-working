import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, ChevronLeft, ChevronRight, Calendar, Download } from "lucide-react";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  season: string;
  startDate: string;
  endDate: string;
  trainingDays: string[] | string;
  status: "draft" | "active" | "completed";
}

function CalendarWorkingBackup() {
  const { planId } = useParams<{ planId: string }>();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [currentDate, setCurrentDate] = useState(new Date());

  // Fetch data
  const { data: yearPlans = [], isLoading: isLoadingPlans } = useQuery({ 
    queryKey: ['/api/year-plans']
  });

  const { data: clubInfo } = useQuery({ queryKey: ['/api/club/info'] });
  
  const { data: sessions = [] } = useQuery({ 
    queryKey: ['/api/year-plans', selectedPlan?.id, 'sessions'], 
    enabled: !!selectedPlan
  });

  // Set initial plan if planId is provided
  useEffect(() => {
    if (planId && yearPlans && Array.isArray(yearPlans) && yearPlans.length > 0) {
      const plan = yearPlans.find((p: any) => p.id === parseInt(planId));
      if (plan) {
        setSelectedPlan(plan);
      }
    }
  }, [planId, yearPlans]);

  // Check if date is available for training
  const isDateAvailable = (date: Date) => {
    if (!selectedPlan || !selectedPlan.startDate || !selectedPlan.endDate) return false;
    
    try {
      const dayName = format(date, 'EEEE', { locale: nl });
      const planStart = parseISO(selectedPlan.startDate);
      const planEnd = parseISO(selectedPlan.endDate);
      
      // Always allow dates within plan period for now
      return date >= planStart && date <= planEnd;
    } catch (error) {
      console.error('Date validation error:', error);
      return false;
    }
  };

  // Get sessions for specific date
  const getSessionsForDate = (date: Date) => {
    if (!sessions || !Array.isArray(sessions)) return [];
    return sessions.filter((session: any) => 
      isSameDay(parseISO(session.date), date)
    );
  };

  // Handle date click to add training directly
  const handleDateClick = async (date: Date) => {
    if (!selectedPlan) return;
    
    try {
      const newSession = {
        yearPlanId: selectedPlan.id,
        date: date.toISOString().split('T')[0],
        startTime: '19:00',
        duration: 90,
        eventType: 'training',
        title: 'Training',
        description: 'Reguliere training'
      };

      const response = await fetch(`/api/year-plans/${selectedPlan.id}/sessions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(newSession)
      });

      if (response.ok) {
        toast({
          title: "Training toegevoegd",
          description: `Training gepland voor ${format(date, 'dd MMMM yyyy', { locale: nl })}`
        });
        queryClient.invalidateQueries({ queryKey: ['/api/year-plans', selectedPlan.id, 'sessions'] });
      } else {
        throw new Error('Server error');
      }
    } catch (error) {
      console.error('Error adding training:', error);
      toast({
        title: "Fout",
        description: "Kon training niet toevoegen",
        variant: "destructive"
      });
    }
  };

  // Export handlers
  const handlePlanExtras = (plan: YearPlan) => {
    try {
      const today = new Date();
      const planStart = parseISO(plan.startDate);
      const planEnd = parseISO(plan.endDate);
      
      return {
        totalDays: Math.ceil((planEnd.getTime() - planStart.getTime()) / (1000 * 60 * 60 * 24)),
        daysCompleted: planStart <= today ? Math.ceil((today.getTime() - planStart.getTime()) / (1000 * 60 * 60 * 24)) : 0,
        trainingDaysText: 'Alle dagen beschikbaar'
      };
    } catch (error) {
      console.error('Plan extras error:', error);
      return {
        totalDays: 0,
        daysCompleted: 0,
        trainingDaysText: 'Niet ingesteld'
      };
    }
  };

  const exportToPDF = async (plan: YearPlan) => {
    try {
      const response = await fetch(`/api/year-plans/${plan.id}/export/pdf`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${plan.name}-kalender.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({ 
          title: "PDF geëxporteerd", 
          description: "Kalender succesvol gedownload als PDF" 
        });
      }
    } catch (error) {
      toast({ 
        title: "Export fout", 
        description: "Kon PDF niet genereren", 
        variant: "destructive" 
      });
    }
  };

  const exportToExcel = async (plan: YearPlan) => {
    try {
      const response = await fetch(`/api/year-plans/${plan.id}/export/excel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${plan.name}-planning.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({ 
          title: "Excel geëxporteerd", 
          description: "Planning succesvol gedownload als Excel" 
        });
      }
    } catch (error) {
      toast({ 
        title: "Export fout", 
        description: "Kon Excel niet genereren", 
        variant: "destructive" 
      });
    }
  };

  // Calendar rendering
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 1 });
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start: startDate, end: endDate });

  if (isLoadingPlans) {
    return <div className="p-6">Laden...</div>;
  }

  if (!selectedPlan) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="max-w-4xl mx-auto">
          <Link href="/jaarplanning">
            <Button variant="outline" className="mb-6">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Terug naar Jaarplanningen
            </Button>
          </Link>
          
          <Card>
            <CardHeader>
              <CardTitle>Selecteer een Jaarplanning</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {yearPlans && Array.isArray(yearPlans) && yearPlans.map((plan: YearPlan) => (
                  <Card key={plan.id} className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold">{plan.name}</h3>
                        <p className="text-sm text-gray-600">{plan.ageGroup} • {plan.season}</p>
                      </div>
                      <Button onClick={() => setSelectedPlan(plan)}>
                        <Calendar className="h-4 w-4 mr-2" />
                        Kalender
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Link href="/jaarplanning">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-white/10 border-white/20 hover:bg-white hover:text-blue-600 text-white backdrop-blur-sm"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Jaarplanning
                </Button>
              </Link>
            </div>
          </div>

          {/* Calendar */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentDate(subMonths(currentDate, 1))}
                  className="bg-blue-600 text-white hover:bg-blue-700 border-blue-600"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                
                <CardTitle className="text-xl font-bold text-blue-900">
                  {format(currentDate, 'MMMM yyyy', { locale: nl })}
                </CardTitle>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentDate(addMonths(currentDate, 1))}
                  className="bg-blue-600 text-white hover:bg-blue-700 border-blue-600"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="text-center">
                <h2 className="text-lg font-semibold text-gray-700">{selectedPlan.name}</h2>
                <p className="text-sm text-gray-500">{selectedPlan.ageGroup} • {selectedPlan.season}</p>
              </div>
            </CardHeader>

            <CardContent className="p-0">
              {/* Weekday headers */}
              <div className="grid grid-cols-7 border-b border-gray-200">
                {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map((day) => (
                  <div key={day} className="p-3 text-center font-medium text-gray-600 bg-gray-50">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar grid */}
              <div className="grid grid-cols-7">
                {days.map((day, dayIdx) => {
                  const isCurrentMonth = isSameMonth(day, currentDate);
                  const isAvailable = isDateAvailable(day);
                  const daySessions = getSessionsForDate(day);
                  const isToday = isSameDay(day, new Date());

                  return (
                    <div
                      key={day.toString()}
                      className={`
                        min-h-[100px] p-2 border-r border-b border-gray-200 relative
                        ${!isCurrentMonth ? 'bg-gray-50 text-gray-400' : 'bg-white'}
                        ${isAvailable ? 'hover:bg-blue-50 cursor-pointer' : ''}
                        ${isToday ? 'bg-blue-100' : ''}
                      `}
                      onClick={() => isAvailable && handleDateClick(day)}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`text-sm font-medium ${isToday ? 'text-blue-600' : ''}`}>
                          {format(day, 'd')}
                        </span>
                      </div>

                      {isCurrentMonth && isAvailable && (
                        <div className="space-y-1">
                          {daySessions.map((session: any) => (
                            <div
                              key={session.id}
                              className="text-xs p-1 bg-green-100 text-green-800 rounded font-medium"
                            >
                              {session.title || 'Training'}
                            </div>
                          ))}
                          
                          {daySessions.length === 0 && (
                            <div className="text-xs text-green-600 font-medium p-1">
                              + Training toevoegen
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Export Section */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => exportToPDF(selectedPlan)}
                      className="flex items-center space-x-2"
                    >
                      <Download className="h-4 w-4" />
                      <span>PDF Export</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => exportToExcel(selectedPlan)}
                      className="flex items-center space-x-2"
                    >
                      <Download className="h-4 w-4" />
                      <span>Excel Export</span>
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default CalendarWorkingBackup;