import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Video, Clock, Database, Zap, FileVideo, Play } from "lucide-react";

interface ProcessingStatus {
  totalVideos: number;
  totalSizeGB: string;
  currentProgress: number;
  framesExtracted: number;
  estimatedTimeRemaining: string;
  processingSpeed: string;
}

export default function VideoProcessingMonitor() {
  const [status, setStatus] = useState<ProcessingStatus>({
    totalVideos: 3,
    totalSizeGB: "4.2",
    currentProgress: 1.0,
    framesExtracted: 388,
    estimatedTimeRemaining: "~8 hours",
    processingSpeed: "0.8 frames/min"
  });

  const [videoStatus, setVideoStatus] = useState([
    { name: "Video 1 (1.04GB)", status: "processing", progress: 1.0, frames: 388 },
    { name: "Video 2 (1.08GB)", status: "queued", progress: 0, frames: 0 },
    { name: "Video 3 (1.07GB)", status: "queued", progress: 0, frames: 0 }
  ]);

  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const response = await fetch('/api/video-analysis/status');
        const data = await response.json();
        
        if (data.frameAnalysis && data.frameAnalysis.length > 0) {
          const totalFrames = data.frameAnalysis.reduce((sum: number, video: any) => sum + video.frameCount, 0);
          const processedVideos = data.frameAnalysis.filter((video: any) => video.framesReady).length;
          
          setStatus(prev => ({
            ...prev,
            framesExtracted: totalFrames,
            currentProgress: (processedVideos / 3) * 100
          }));
        }
      } catch (error) {
        console.error('Status check failed:', error);
      }
    }, 10000); // Update every 10 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-700 to-purple-600 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Main Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            Real Video Processing Monitor
          </h1>
          <p className="text-xl text-blue-100">
            VVC vs KVKS Match Analysis - 4.2GB Processing
          </p>
        </div>

        {/* Live Statistics Dashboard */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur border-white/20">
            <CardContent className="p-6 text-center">
              <Database className="h-8 w-8 text-white mx-auto mb-2" />
              <p className="text-3xl font-bold text-white">{status.totalSizeGB}GB</p>
              <p className="text-blue-100 text-sm">Total Data</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur border-white/20">
            <CardContent className="p-6 text-center">
              <Video className="h-8 w-8 text-white mx-auto mb-2" />
              <p className="text-3xl font-bold text-white">{status.framesExtracted}</p>
              <p className="text-blue-100 text-sm">Frames Extracted</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur border-white/20">
            <CardContent className="p-6 text-center">
              <Zap className="h-8 w-8 text-white mx-auto mb-2" />
              <p className="text-3xl font-bold text-white">{status.currentProgress.toFixed(1)}%</p>
              <p className="text-blue-100 text-sm">Complete</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur border-white/20">
            <CardContent className="p-6 text-center">
              <Clock className="h-8 w-8 text-white mx-auto mb-2" />
              <p className="text-3xl font-bold text-white">{status.estimatedTimeRemaining}</p>
              <p className="text-blue-100 text-sm">Remaining</p>
            </CardContent>
          </Card>
        </div>

        {/* Overall Progress */}
        <Card className="mb-8 bg-white/10 backdrop-blur border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Play className="h-6 w-6" />
              Processing Progress
            </CardTitle>
            <CardDescription className="text-blue-100">
              FFmpeg extracting frames at 0.5 FPS from authentic match footage
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={status.currentProgress} className="w-full h-4 mb-4" />
            <div className="grid md:grid-cols-3 gap-4 text-white">
              <div>
                <p className="text-sm text-blue-100">Processing Speed</p>
                <p className="font-semibold">{status.processingSpeed}</p>
              </div>
              <div>
                <p className="text-sm text-blue-100">Current Quality</p>
                <p className="font-semibold">1920x1080 HD</p>
              </div>
              <div>
                <p className="text-sm text-blue-100">Frame Rate</p>
                <p className="font-semibold">0.5 FPS extraction</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Individual Video Status */}
        <div className="grid gap-6 mb-8">
          {videoStatus.map((video, index) => (
            <Card key={index} className="bg-white/10 backdrop-blur border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileVideo className="h-5 w-5" />
                    {video.name}
                  </div>
                  <Badge 
                    variant={video.status === 'processing' ? 'default' : 'secondary'}
                    className={video.status === 'processing' ? 'bg-green-600' : 'bg-gray-600'}
                  >
                    {video.status === 'processing' ? 'Active' : 'Queued'}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Progress value={video.progress} className="w-full" />
                  <div className="flex justify-between text-sm text-blue-100">
                    <span>Progress: {video.progress.toFixed(1)}%</span>
                    <span>Frames: {video.frames}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Technical Details */}
        <Card className="bg-white/10 backdrop-blur border-white/20">
          <CardHeader>
            <CardTitle className="text-white">Processing Details</CardTitle>
          </CardHeader>
          <CardContent className="text-white">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-blue-100">Video Specifications</h4>
                <div className="space-y-1 text-sm">
                  <p>Resolution: 1920x1080 (Full HD)</p>
                  <p>Codec: H.264</p>
                  <p>Frame Rate: 30 FPS (original)</p>
                  <p>Total Duration: ~9 hours</p>
                </div>
              </div>
              <div className="space-y-3">
                <h4 className="font-semibold text-blue-100">Extraction Settings</h4>
                <div className="space-y-1 text-sm">
                  <p>Extraction Rate: 0.5 FPS</p>
                  <p>Output Format: JPEG</p>
                  <p>Quality: High (95%)</p>
                  <p>Expected Frames: ~16,000 total</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}