import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Star, Users, Target, Brain, Zap, RefreshCw } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface IADatabankElement {
  id: number;
  topic: string;
  subtopic: string;
  name: string;
  theme: string;
  progressions: {
    level: number;
    name: string;
    description: string;
    difficulty: number;
  }[];
}

const topicConfig = {
  BASICS: {
    display: "Basics",
    icon: Target,
    color: "bg-blue-500",
    description: "Fundamentele technische en tactische vaardigheden"
  },
  TEAMTACTISCH: {
    display: "Team Tactiek",
    icon: Users,
    color: "bg-green-500",
    description: "Collectieve spelvormen en teamtactiek"
  },
  MENTAAL: {
    display: "Mentale Aspecten",
    icon: Brain,
    color: "bg-purple-500",
    description: "Psychologische en mentale training"
  },
  FYSIEK: {
    display: "Fysieke Conditie",
    icon: Zap,
    color: "bg-red-500",
    description: "Fysieke training en conditioning"
  }
};

export default function IADatabankInterface() {
  const [selectedTopic, setSelectedTopic] = useState<string>("BASICS");
  const [selectedElement, setSelectedElement] = useState<IADatabankElement | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLevel, setSelectedLevel] = useState<number>(1);
  const [showElementDialog, setShowElementDialog] = useState(false);

  // Fetch all IADATABANK elements
  const { data: response, isLoading } = useQuery<{ data: IADatabankElement[] }>({
    queryKey: ['/api/iadatabank/elements'],
  });
  
  const elements = response?.data || [];

  // Filter elements based on topic and search
  const filteredElements = elements.filter(element => {
    const matchesTopic = element.topic === selectedTopic;
    const matchesSearch = searchQuery === "" || 
      element.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      element.theme.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTopic && matchesSearch;
  });

  // Group elements by subtopic with proper sorting for BASICS
  const elementsBySubtopic = filteredElements.reduce((acc, element) => {
    if (!acc[element.subtopic]) {
      acc[element.subtopic] = [];
    }
    acc[element.subtopic].push(element);
    return acc;
  }, {} as Record<string, IADatabankElement[]>);

  // Sort B+ and B- to appear first for BASICS
  const sortedSubtopics = Object.keys(elementsBySubtopic).sort((a, b) => {
    if (selectedTopic === 'BASICS') {
      if (a === 'B+') return -1;
      if (b === 'B+') return 1;
      if (a === 'B-') return -1;
      if (b === 'B-') return 1;
    }
    return a.localeCompare(b);
  });

  const openElementDialog = (element: IADatabankElement) => {
    setSelectedElement(element);
    setShowElementDialog(true);
  };

  const getDifficultyColor = (difficulty: number) => {
    if (difficulty <= 2) return "bg-green-100 text-green-800";
    if (difficulty <= 4) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const getDifficultyText = (difficulty: number) => {
    if (difficulty <= 2) return "Basis";
    if (difficulty <= 4) return "Gemiddeld";
    return "Gevorderd";
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">IA Databank Interface</h1>
        <p className="text-muted-foreground">
          Volledige toegang tot {elements.length} professionele voetbal training elementen
        </p>
        {/* Debug info */}
        {selectedTopic === 'BASICS' && (
          <div className="mt-2 p-2 bg-gray-100 rounded text-sm">
            Debug: BASICS elementen - 
            B+: {elements.filter(e => e.topic === 'BASICS' && e.subtopic === 'B+').length}, 
            B-: {elements.filter(e => e.topic === 'BASICS' && e.subtopic === 'B-').length}
            <br/>
            Filtered: {filteredElements.length}, Grouped: {Object.keys(elementsBySubtopic).length} subtopics
          </div>
        )}
      </div>

      {/* Topic Selection */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
        {Object.entries(topicConfig).map(([key, config]) => {
          const Icon = config.icon;
          const isSelected = selectedTopic === key;
          const topicElements = elements.filter(e => e.topic === key);
          
          return (
            <Card 
              key={key}
              className={`cursor-pointer transition-all hover:shadow-lg ${
                isSelected ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => setSelectedTopic(key)}
            >
              <CardContent className="p-6 text-center">
                <div className={`w-12 h-12 ${config.color} rounded-full flex items-center justify-center mx-auto mb-3`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-semibold text-sm mb-1">{config.display}</h3>
                <p className="text-xs text-muted-foreground mb-2">{config.description}</p>
                <Badge variant="secondary" className="text-xs">
                  {topicElements.length} elementen
                </Badge>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Search and Filters */}
      <div className="flex gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Zoek elementen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={selectedLevel.toString()} onValueChange={(value) => setSelectedLevel(parseInt(value))}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Selecteer niveau" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">Niveau 1 - Introductie</SelectItem>
            <SelectItem value="2">Niveau 2 - Basis</SelectItem>
            <SelectItem value="3">Niveau 3 - Opbouw</SelectItem>
            <SelectItem value="4">Niveau 4 - Verdieping</SelectItem>
            <SelectItem value="5">Niveau 5 - Toepassing</SelectItem>
            <SelectItem value="6">Niveau 6 - Competitie</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Elements Display - Direct Implementation for BASICS */}
      {selectedTopic === 'BASICS' ? (
        <div className="space-y-6">
          {/* B+ Elements */}
          <div>
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              B+ (Aanvallende Elementen)
              <Badge variant="outline">{elements.filter(e => e.topic === 'BASICS' && e.subtopic === 'B+').length} elementen</Badge>
            </h2>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {elements
                .filter(e => e.topic === 'BASICS' && e.subtopic === 'B+')
                .map((element) => (
                  <div 
                    key={element.id} 
                    className="flex items-center p-3 border rounded hover:bg-gray-50 cursor-pointer"
                    onClick={() => openElementDialog(element)}
                  >
                    <div className="flex-1">
                      <div className="font-medium text-sm">{element.name}</div>
                      <div className="text-xs text-muted-foreground">{element.theme}</div>
                    </div>
                    <div className="flex gap-1 ml-4">
                      {[1, 2, 3, 4, 5, 6].map((level) => (
                        <Star
                          key={level}
                          className={`h-3 w-3 ${
                            element.progressions.find(p => p.level === level)
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* B- Elements */}
          <div>
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              B- (Verdedigende Elementen)
              <Badge variant="outline">{elements.filter(e => e.topic === 'BASICS' && e.subtopic === 'B-').length} elementen</Badge>
            </h2>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {elements
                .filter(e => e.topic === 'BASICS' && e.subtopic === 'B-')
                .map((element) => (
                  <div 
                    key={element.id} 
                    className="flex items-center p-3 border rounded hover:bg-gray-50 cursor-pointer"
                    onClick={() => openElementDialog(element)}
                  >
                    <div className="flex-1">
                      <div className="font-medium text-sm">{element.name}</div>
                      <div className="text-xs text-muted-foreground">{element.theme}</div>
                    </div>
                    <div className="flex gap-1 ml-4">
                      {[1, 2, 3, 4, 5, 6].map((level) => (
                        <Star
                          key={level}
                          className={`h-3 w-3 ${
                            element.progressions.find(p => p.level === level)
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      ) : (
        // Original display for other topics
        <div className="space-y-6">
          {sortedSubtopics.map((subtopic) => {
            const elements = elementsBySubtopic[subtopic];
            return (
              <div key={subtopic}>
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  {subtopic}
                  <Badge variant="outline">{elements.length} elementen</Badge>
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {elements.map((element) => (
                    <Card 
                      key={element.id} 
                      className="hover:shadow-lg transition-shadow cursor-pointer"
                      onClick={() => openElementDialog(element)}
                    >
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base">{element.name}</CardTitle>
                        <div className="flex justify-between items-center">
                          <Badge variant="outline" className="text-xs">
                            {element.theme}
                          </Badge>
                          <div className="flex gap-1">
                            {[1, 2, 3, 4, 5, 6].map((level) => (
                              <Star
                                key={level}
                                className={`h-3 w-3 ${
                                  element.progressions.find(p => p.level === level)
                                    ? 'fill-yellow-400 text-yellow-400'
                                    : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Element Detail Dialog */}
      {selectedElement && (
        <Dialog open={showElementDialog} onOpenChange={setShowElementDialog}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-xl">{selectedElement.name}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              <div className="flex gap-4">
                <Badge variant="outline">{selectedElement.topic}</Badge>
                <Badge variant="outline">{selectedElement.subtopic}</Badge>
                <Badge variant="outline">{selectedElement.theme}</Badge>
              </div>

              <Tabs defaultValue="1" className="w-full">
                <TabsList className="grid w-full grid-cols-6">
                  {[1, 2, 3, 4, 5, 6].map((level) => (
                    <TabsTrigger 
                      key={level} 
                      value={level.toString()}
                      disabled={!selectedElement.progressions.find(p => p.level === level)}
                    >
                      Niveau {level}
                    </TabsTrigger>
                  ))}
                </TabsList>
                
                {selectedElement.progressions.map((progression) => (
                  <TabsContent key={progression.level} value={progression.level.toString()}>
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex justify-between items-center">
                          <span>{progression.name}</span>
                          <Badge className={getDifficultyColor(progression.difficulty)}>
                            {getDifficultyText(progression.difficulty)}
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground whitespace-pre-line">
                          {progression.description}
                        </p>
                      </CardContent>
                    </Card>
                  </TabsContent>
                ))}
              </Tabs>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}