import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Save, Building, Plus, X, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import type { Club } from "@shared/schema";
import { HexColorPicker } from "react-colorful";

export default function ClubInfo() {
  const { toast } = useToast();
  
  // Fetch club data
  const {
    data: club,
    isLoading,
    error,
  } = useQuery<Club>({
    queryKey: ['/api/club/info'],
  });
  
  // Form state
  const [formData, setFormData] = useState<Partial<Club>>({});
  const [showColorPicker1, setShowColorPicker1] = useState(false);
  const [showColorPicker2, setShowColorPicker2] = useState(false);
  const [primaryColor, setPrimaryColor] = useState("#4a90e2");
  const [secondaryColor, setSecondaryColor] = useState("#6c5ce7");
  
  // Parse club colors on component load
  useEffect(() => {
    if (club?.colors) {
      try {
        const colorArray = club.colors.split(',');
        if (colorArray.length >= 1) setPrimaryColor(colorArray[0].trim());
        if (colorArray.length >= 2) setSecondaryColor(colorArray[1].trim());
      } catch (e) {
        console.error("Error parsing colors:", e);
      }
    }
  }, [club]);
  
  // Apply club colors to CSS variables
  useEffect(() => {
    if (primaryColor && secondaryColor) {
      // Log the colors for debugging
      console.log("Setting primary color:", primaryColor);
      console.log("Setting secondary color:", secondaryColor);
      
      // Convert hex to HSL for CSS variables
      const primaryHSL = hexToHSL(primaryColor);
      const secondaryHSL = hexToHSL(secondaryColor);
      
      console.log("Primary HSL:", primaryHSL);
      
      // Create CSS custom properties
      const rootStyle = document.documentElement.style;
      
      // Apply primary color
      rootStyle.setProperty('--primary', primaryHSL);
      
      // Apply other color variables
      rootStyle.setProperty('--primary-foreground', '0 0% 100%');
      rootStyle.setProperty('--secondary', secondaryHSL);
      rootStyle.setProperty('--secondary-foreground', '240 10% 3.9%');
      
      // Derive related colors
      const primaryHue = primaryHSL.split(' ')[0];
      rootStyle.setProperty('--accent', `${primaryHue} 70% 95%`);
      rootStyle.setProperty('--accent-foreground', primaryHSL);
      rootStyle.setProperty('--ring', primaryHSL);
      
      // Sidebar colors
      rootStyle.setProperty('--sidebar-primary', primaryHSL);
      rootStyle.setProperty('--sidebar-accent', `${primaryHue} 30% 20%`);
      
      // Chart colors
      rootStyle.setProperty('--chart-1', primaryHSL);
      
      // Update form data
      setFormData(prev => ({
        ...prev,
        colors: `${primaryColor},${secondaryColor}`
      }));
      
      // Force a re-render by toggling a value
      setTimeout(() => {
        const currentColorValue = rootStyle.getPropertyValue('--primary');
        rootStyle.setProperty('--primary', 'inherit');
        setTimeout(() => {
          rootStyle.setProperty('--primary', currentColorValue);
        }, 5);
      }, 10);
    }
  }, [primaryColor, secondaryColor]);
  
  // Convert hex color to HSL format for CSS variables
  const hexToHSL = (hex: string): string => {
    // Remove the # if present
    hex = hex.replace(/^#/, '');
    
    // Parse the hex values
    let r = parseInt(hex.substring(0, 2), 16) / 255;
    let g = parseInt(hex.substring(2, 4), 16) / 255;
    let b = parseInt(hex.substring(4, 6), 16) / 255;
    
    // Find min and max values
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    
    // Calculate lightness
    let l = (max + min) / 2;
    
    let h, s;
    
    if (max === min) {
      // Achromatic (gray)
      h = 0;
      s = 0;
    } else {
      // Calculate saturation
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      
      // Calculate hue
      switch (max) {
        case r:
          h = (g - b) / d + (g < b ? 6 : 0);
          break;
        case g:
          h = (b - r) / d + 2;
          break;
        case b:
          h = (r - g) / d + 4;
          break;
        default:
          h = 0;
      }
      h /= 6;
    }
    
    // Convert to HSL format used in CSS
    h = Math.round(h * 360);
    s = Math.round(s * 100);
    l = Math.round(l * 100);
    
    return `${h} ${s}% ${l}%`;
  };
  
  // Determine if text should be white or black based on background color
  const getContrastColor = (hexColor: string) => {
    // Convert hex to RGB
    const r = parseInt(hexColor.slice(1, 3), 16);
    const g = parseInt(hexColor.slice(3, 5), 16);
    const b = parseInt(hexColor.slice(5, 7), 16);
    
    // Calculate luminance (perceived brightness)
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    
    // Return white for dark colors, black for light colors
    return luminance > 0.5 ? '#000000' : '#ffffff';
  };
  
  // Handle input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Update club mutation
  const updateClubMutation = useMutation({
    mutationFn: async (data: Partial<Club>) => {
      const res = await apiRequest("PATCH", "/api/club/info", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Club information updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/club/info'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update club information",
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateClubMutation.mutate(formData);
  };

  if (isLoading) {
    return <div className="p-8 text-center">Loading club information...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading club information.</div>;
  }

  const mergedData = { ...club, ...formData };

  return (
    <div className="py-4">
      <div className="flex items-center gap-3 mb-4">
        <Link href="/">
          <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 hover:bg-gray-100">
            <ArrowLeft size={18} />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Club Informatie</h1>
      </div>
      <form onSubmit={handleSubmit}>
        <Card>
          <CardContent className="pt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Club Name*</Label>
                  <Input 
                    id="name"
                    name="name"
                    value={mergedData.name || ''}
                    onChange={handleInputChange}
                    placeholder="Enter club name"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="fullName">Full Club Name</Label>
                  <Input 
                    id="fullName"
                    name="fullName"
                    value={mergedData.fullName || ''}
                    onChange={handleInputChange}
                    placeholder="Enter official club full name"
                  />
                </div>
                <div>
                  <Label htmlFor="shortName">Short Name</Label>
                  <Input 
                    id="shortName"
                    name="shortName"
                    value={mergedData.shortName || ''}
                    onChange={handleInputChange}
                    placeholder="Enter short name or abbreviation"
                  />
                </div>
                <div>
                  <Label htmlFor="foundedYear">Founded Year</Label>
                  <Input 
                    id="foundedYear"
                    name="foundedYear"
                    type="number"
                    value={mergedData.foundedYear || ''}
                    onChange={handleInputChange}
                    placeholder="Year when club was founded"
                  />
                </div>
                
                {/* Club Colors */}
                <div className="space-y-2">
                  <Label>Club Colors</Label>
                  <div className="flex flex-wrap items-start gap-8">
                    {/* Primary Color */}
                    <div className="space-y-2">
                      <Label htmlFor="primaryColor" className="text-xs">Primary Color</Label>
                      <div className="flex items-center gap-2">
                        <div 
                          className="h-10 w-10 rounded border cursor-pointer" 
                          style={{ backgroundColor: primaryColor }}
                          onClick={() => setShowColorPicker1(prev => !prev)}
                        />
                        <Input 
                          id="primaryColor"
                          value={primaryColor}
                          onChange={(e) => setPrimaryColor(e.target.value)}
                          className="w-28"
                        />
                      </div>
                      {showColorPicker1 && (
                        <div className="absolute z-10 mt-1 rounded-md shadow-lg">
                          <div className="relative">
                            <button 
                              className="absolute right-1 top-1 p-1 rounded-full bg-white shadow-sm"
                              onClick={() => setShowColorPicker1(false)}
                            >
                              <X className="h-4 w-4" />
                            </button>
                            <HexColorPicker color={primaryColor} onChange={setPrimaryColor} />
                          </div>
                        </div>
                      )}
                    </div>
                    
                    {/* Secondary Color */}
                    <div className="space-y-2">
                      <Label htmlFor="secondaryColor" className="text-xs">Secondary Color</Label>
                      <div className="flex items-center gap-2">
                        <div 
                          className="h-10 w-10 rounded border cursor-pointer" 
                          style={{ backgroundColor: secondaryColor }}
                          onClick={() => setShowColorPicker2(prev => !prev)}
                        />
                        <Input 
                          id="secondaryColor"
                          value={secondaryColor}
                          onChange={(e) => setSecondaryColor(e.target.value)}
                          className="w-28"
                        />
                      </div>
                      {showColorPicker2 && (
                        <div className="absolute z-10 mt-1 rounded-md shadow-lg">
                          <div className="relative">
                            <button 
                              className="absolute right-1 top-1 p-1 rounded-full bg-white shadow-sm"
                              onClick={() => setShowColorPicker2(false)}
                            >
                              <X className="h-4 w-4" />
                            </button>
                            <HexColorPicker color={secondaryColor} onChange={setSecondaryColor} />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="bg-gradient-to-r from-primary to-secondary h-6 rounded-md mt-2"></div>
                </div>
                
                {/* Club Logo */}
                <div className="space-y-2">
                  <Label htmlFor="logo">Club Logo</Label>
                  <div className="flex items-center gap-4">
                    {mergedData.logo ? (
                      <div className="relative h-24 w-24 rounded-md border overflow-hidden bg-white">
                        <img 
                          src={mergedData.logo} 
                          alt="Club Logo" 
                          className="h-full w-full object-contain"
                        />
                        <button
                          className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1"
                          onClick={() => setFormData(prev => ({ ...prev, logo: '' }))}
                          type="button"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="h-24 w-24 rounded-md border flex items-center justify-center bg-muted">
                        <span className="text-xs text-muted-foreground">No logo</span>
                      </div>
                    )}
                    
                    <div className="flex-1">
                      <Input
                        id="logoUpload"
                        type="file"
                        accept=".jpg,.jpeg,.png"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          
                          const formData = new FormData();
                          formData.append('logo', file);
                          
                          try {
                            const response = await fetch('/api/club/logo-upload', {
                              method: 'POST',
                              body: formData,
                              // Do not set Content-Type header, the browser will set it correctly with boundary for multipart/form-data
                            });
                            
                            if (!response.ok) {
                              throw new Error('Failed to upload logo');
                            }
                            
                            const data = await response.json();
                            setFormData(prev => ({ ...prev, logo: data.logo }));
                            
                            toast({
                              title: "Logo uploaded",
                              description: "Club logo has been updated",
                            });
                          } catch (error) {
                            toast({
                              title: "Error",
                              description: "Failed to upload logo",
                              variant: "destructive",
                            });
                          }
                        }}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full"
                        onClick={() => {
                          document.getElementById('logoUpload')?.click();
                        }}
                      >
                        Upload Logo (PNG, JPEG)
                      </Button>
                      <p className="text-xs text-muted-foreground mt-1">
                        Upload your club logo as a PNG or JPEG file (max 5MB)
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="slogan">Clubslogan</Label>
                  <Input 
                    id="slogan"
                    name="slogan"
                    value={mergedData.slogan || ''}
                    onChange={handleInputChange}
                    placeholder="Voer de clubslogan in"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Deze slogan wordt weergegeven in PDF rapporten en documenten
                  </p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="website">Website</Label>
                  <Input 
                    id="website"
                    name="website"
                    value={mergedData.website || ''}
                    onChange={handleInputChange}
                    placeholder="Club website URL"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input 
                    id="email"
                    name="email"
                    type="email"
                    value={mergedData.email || ''}
                    onChange={handleInputChange}
                    placeholder="Club contact email"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input 
                    id="phone"
                    name="phone"
                    value={mergedData.phone || ''}
                    onChange={handleInputChange}
                    placeholder="Club contact phone number"
                  />
                </div>
                <div>
                  <Label htmlFor="federationId">Federation ID</Label>
                  <Input 
                    id="federationId"
                    name="federationId"
                    value={mergedData.federationId || ''}
                    onChange={handleInputChange}
                    placeholder="ID used by the soccer federation"
                  />
                </div>
                <div>
                  <Label htmlFor="vatNumber">VAT Number</Label>
                  <Input 
                    id="vatNumber"
                    name="vatNumber"
                    value={mergedData.vatNumber || ''}
                    onChange={handleInputChange}
                    placeholder="Club VAT number"
                  />
                </div>
                <div>
                  <Label htmlFor="bankAccount">Bank Account</Label>
                  <Input 
                    id="bankAccount"
                    name="bankAccount"
                    value={mergedData.bankAccount || ''}
                    onChange={handleInputChange}
                    placeholder="Club bank account number"
                  />
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="address">Street</Label>
                <Input 
                  id="address"
                  name="address"
                  value={mergedData.address || ''}
                  onChange={handleInputChange}
                  placeholder="Street address"
                  maxLength={50}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input 
                    id="city"
                    name="city"
                    value={mergedData.city || ''}
                    onChange={handleInputChange}
                    placeholder="City"
                  />
                </div>
                <div>
                  <Label htmlFor="postalCode">Postal Code</Label>
                  <Input 
                    id="postalCode"
                    name="postalCode"
                    value={mergedData.postalCode || ''}
                    onChange={handleInputChange}
                    placeholder="Postal code"
                  />
                </div>
                <div>
                  <Label htmlFor="country">Country</Label>
                  <Input 
                    id="country"
                    name="country"
                    value={mergedData.country || 'Belgium'}
                    onChange={handleInputChange}
                    placeholder="Country"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Club Description</Label>
                <Textarea 
                  id="description"
                  name="description"
                  value={mergedData.description || ''}
                  onChange={handleInputChange}
                  placeholder="Brief description of the club, its history, and values"
                  rows={4}
                />
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button 
                type="submit" 
                className="flex items-center gap-2"
                disabled={updateClubMutation.isPending}
              >
                {updateClubMutation.isPending ? (
                  <>
                    <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Save Club Information
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}