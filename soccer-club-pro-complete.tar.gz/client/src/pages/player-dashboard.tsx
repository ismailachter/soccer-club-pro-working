import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Calendar, Clock, MapPin, Users, Target, TrendingUp, Award, Bell, Shield } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function PlayerDashboard() {
  const { user } = useAuth();
  const [selectedWeek, setSelectedWeek] = useState(0);

  // Fetch player's personal data
  const { data: playerData } = useQuery({
    queryKey: ['/api/players/me'],
    queryFn: async () => {
      const response = await fetch('/api/players/me');
      if (!response.ok) throw new Error('Failed to fetch player data');
      return response.json();
    },
  });

  // Fetch team schedule
  const { data: teamSchedule } = useQuery({
    queryKey: ['/api/players/team-schedule'],
    queryFn: async () => {
      const response = await fetch('/api/players/team-schedule');
      if (!response.ok) throw new Error('Failed to fetch team schedule');
      return response.json();
    },
  });

  // Fetch individual assignments
  const { data: individualAssignments } = useQuery({
    queryKey: ['/api/players/assignments'],
    queryFn: async () => {
      const response = await fetch('/api/players/assignments');
      if (!response.ok) throw new Error('Failed to fetch assignments');
      return response.json();
    },
  });

  // Fetch training progress
  const { data: trainingProgress } = useQuery({
    queryKey: ['/api/players/training-progress'],
    queryFn: async () => {
      const response = await fetch('/api/players/training-progress');
      if (!response.ok) throw new Error('Failed to fetch training progress');
      return response.json();
    },
  });

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Welcome Header with Profile Picture */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              {playerData?.user?.profilePicture ? (
                <img 
                  src={playerData.user.profilePicture} 
                  alt={`${user?.firstName} ${user?.lastName}`}
                  className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-lg"
                />
              ) : (
                <span className="text-white font-bold text-xl">
                  {user?.firstName?.[0]}{user?.lastName?.[0]}
                </span>
              )}
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-white"></div>
          </div>
          <div>
            <h1 className="text-3xl font-bold">Welcome back, {user?.firstName}! 👋</h1>
            <p className="text-muted-foreground">
              {playerData?.team?.name} • {playerData?.position} • #{playerData?.jerseyNumber}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            {playerData?.status || 'Active'}
          </Badge>
          <Button variant="outline" size="sm">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </Button>
        </div>
      </div>

      {/* Team Information Card */}
      {playerData?.team && (
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-blue-900">Your Team</h3>
                  <p className="text-blue-700 font-medium">{playerData.team.name}</p>
                  <p className="text-sm text-blue-600">{playerData.team.ageGroup}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-blue-600">Coach</p>
                <p className="font-medium text-blue-900">{playerData.team.coach || 'TBA'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-blue-600" />
              <div>
                <p className="text-sm font-medium">Team Rank</p>
                <p className="text-2xl font-bold">#3</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Target className="h-4 w-4 text-green-600" />
              <div>
                <p className="text-sm font-medium">Goals This Season</p>
                <p className="text-2xl font-bold">{playerData?.statistics?.goals || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-orange-600" />
              <div>
                <p className="text-sm font-medium">Training Progress</p>
                <p className="text-2xl font-bold">85%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Award className="h-4 w-4 text-purple-600" />
              <div>
                <p className="text-sm font-medium">Upcoming Matches</p>
                <p className="text-2xl font-bold">3</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="schedule" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="schedule">Team Schedule</TabsTrigger>
          <TabsTrigger value="assignments">My Assignments</TabsTrigger>
          <TabsTrigger value="training">Training Program</TabsTrigger>
          <TabsTrigger value="progress">Performance</TabsTrigger>
        </TabsList>

        {/* Team Schedule Tab */}
        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Team Schedule
              </CardTitle>
              <CardDescription>
                Upcoming training sessions and matches for {playerData?.team?.name}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {teamSchedule?.map((event: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="flex flex-col items-center justify-center w-12 h-12 bg-blue-100 rounded-lg">
                        <span className="text-xs font-medium text-blue-600">
                          {new Date(event.date).getDate()}
                        </span>
                        <span className="text-xs text-blue-600">
                          {new Date(event.date).toLocaleDateString('en', { month: 'short' })}
                        </span>
                      </div>
                      <div>
                        <h4 className="font-medium">{event.title}</h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {event.time}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {event.location}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Badge variant={event.type === 'match' ? 'default' : 'secondary'}>
                      {event.type}
                    </Badge>
                  </div>
                )) || (
                  <div className="text-center py-8 text-muted-foreground">
                    <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No upcoming events scheduled</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Individual Assignments Tab */}
        <TabsContent value="assignments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                My Individual Assignments
              </CardTitle>
              <CardDescription>
                Personal training tasks and goals assigned by your coach
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {individualAssignments?.map((assignment: any, index: number) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{assignment.title}</h4>
                      <Badge variant={assignment.completed ? 'default' : 'secondary'}>
                        {assignment.completed ? 'Completed' : 'In Progress'}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{assignment.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">
                        Due: {new Date(assignment.dueDate).toLocaleDateString()}
                      </span>
                      <Progress value={assignment.progress} className="w-24" />
                    </div>
                  </div>
                )) || (
                  <div className="text-center py-8 text-muted-foreground">
                    <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No assignments yet</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Training Program Tab */}
        <TabsContent value="training" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                My Training Program
              </CardTitle>
              <CardDescription>
                8-week injury prevention and performance enhancement program
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Week Selector */}
                <div className="flex items-center space-x-2 overflow-x-auto">
                  {Array.from({ length: 8 }, (_, i) => (
                    <Button
                      key={i}
                      variant={selectedWeek === i ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedWeek(i)}
                      className="min-w-fit"
                    >
                      Week {i + 1}
                    </Button>
                  ))}
                </div>

                {/* Training Content for Selected Week */}
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900 mb-2">
                      Week {selectedWeek + 1}: {selectedWeek < 2 ? 'Foundation Phase' : selectedWeek < 5 ? 'Building Phase' : 'Peak Phase'}
                    </h4>
                    <p className="text-sm text-blue-700">
                      Intensity: {selectedWeek < 2 ? '60-70%' : selectedWeek < 5 ? '70-85%' : '85-100%'}
                    </p>
                  </div>

                  {/* Weekly Training Sessions */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Monday - HIIT & Cardio</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="text-sm space-y-1">
                          <li>• Dynamic warm-up (10 min)</li>
                          <li>• Cardiovascular fitness</li>
                          <li>• Core strengthening</li>
                          <li>• Hamstring prevention</li>
                        </ul>
                        <div className="mt-3">
                          <Progress value={trainingProgress?.week1?.monday || 0} />
                          <span className="text-xs text-muted-foreground">
                            {trainingProgress?.week1?.monday || 0}% complete
                          </span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Wednesday - Strength & Power</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="text-sm space-y-1">
                          <li>• Strength development</li>
                          <li>• Power training</li>
                          <li>• Joint stability</li>
                          <li>• Functional movements</li>
                        </ul>
                        <div className="mt-3">
                          <Progress value={trainingProgress?.week1?.wednesday || 0} />
                          <span className="text-xs text-muted-foreground">
                            {trainingProgress?.week1?.wednesday || 0}% complete
                          </span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Friday - Speed & Agility</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="text-sm space-y-1">
                          <li>• Speed development</li>
                          <li>• Agility training</li>
                          <li>• Ankle stability</li>
                          <li>• Knee protection</li>
                        </ul>
                        <div className="mt-3">
                          <Progress value={trainingProgress?.week1?.friday || 0} />
                          <span className="text-xs text-muted-foreground">
                            {trainingProgress?.week1?.friday || 0}% complete
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="progress" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Season Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Goals</span>
                    <span className="font-bold">{playerData?.statistics?.goals || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Assists</span>
                    <span className="font-bold">{playerData?.statistics?.assists || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Matches Played</span>
                    <span className="font-bold">{playerData?.statistics?.matchesPlayed || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Training Attendance</span>
                    <span className="font-bold">92%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Fitness Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Cardiovascular</span>
                      <span>85%</span>
                    </div>
                    <Progress value={85} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Strength</span>
                      <span>78%</span>
                    </div>
                    <Progress value={78} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Agility</span>
                      <span>90%</span>
                    </div>
                    <Progress value={90} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Injury Prevention</span>
                      <span>82%</span>
                    </div>
                    <Progress value={82} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}