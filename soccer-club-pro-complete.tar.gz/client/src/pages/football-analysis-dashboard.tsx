import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BackToMenu } from "@/components/ui/back-to-menu";
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Target, 
  Activity,
  MapPin,
  Clock,
  Zap,
  FileVideo,
  Upload,
  Eye,
  Download,
  Play
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

export default function FootballAnalysisDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch GPS matches
  const { data: matches, isLoading: matchesLoading } = useQuery({
    queryKey: ['/api/gps-match/matches'],
    queryFn: async () => {
      const response = await fetch('/api/gps-match/matches');
      if (!response.ok) throw new Error('Failed to fetch matches');
      return response.json();
    }
  });

  // Fetch club info
  const { data: clubInfo } = useQuery({
    queryKey: ['/api/club/info'],
    queryFn: async () => {
      const response = await fetch('/api/club/info');
      if (!response.ok) throw new Error('Failed to fetch club info');
      return response.json();
    }
  });

  const analysisModules = [
    {
      id: 'gps-upload',
      title: 'GPS Match Upload',
      description: 'Upload wedstrijdopstellingen voor automatische GPS analyse',
      icon: Upload,
      href: '/gps-match-upload',
      color: 'bg-blue-500'
    },
    {
      id: 'match-analysis',
      title: 'Match Performance Analysis',
      description: 'Gedetailleerde wedstrijdanalyse met GPS data',
      icon: BarChart3,
      href: '/match-performance-analysis',
      color: 'bg-green-500'
    },
    {
      id: 'player-tracking',
      title: 'Speler Tracking',
      description: 'Individuele speler performance over tijd',
      icon: Users,
      href: '/player-tracking',
      color: 'bg-purple-500'
    },
    {
      id: 'tactical-field-analyzer',
      title: 'Tactische Veld Analyzer',
      description: 'Real-time tactische analyse met doelpunt tracking',
      icon: Target,
      href: '/tactical-field-analyzer',
      color: 'bg-orange-500'
    },
    {
      id: 'ai-video-analyzer',
      title: 'AI Video Analyzer',
      description: 'Automatische doelpunt- en event-detectie via computer vision',
      icon: FileVideo,
      href: '/ai-video-analyzer',
      color: 'bg-red-500'
    },
    {
      id: 'heat-maps',
      title: 'Heat Maps',
      description: 'Speler positionering en bewegingspatronen',
      icon: MapPin,
      href: '/heat-maps',
      color: 'bg-teal-500'
    }
  ];

  const recentMatches = matches?.slice(0, 5) || [];

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <BackToMenu />
      
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Voetbal Analyse Systeem</h1>
        <p className="text-xl text-gray-600">{clubInfo?.name || 'VVC Brasschaat'} - Professionele Match & Speler Analyse</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overzicht</TabsTrigger>
          <TabsTrigger value="modules">Analyse Modules</TabsTrigger>
          <TabsTrigger value="matches">Wedstrijden</TabsTrigger>
          <TabsTrigger value="statistics">Statistieken</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Totaal Wedstrijden</p>
                    <p className="text-3xl font-bold">{matches?.length || 0}</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Geanalyseerde Spelers</p>
                    <p className="text-3xl font-bold">22</p>
                  </div>
                  <Users className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">GPS Data Points</p>
                    <p className="text-3xl font-bold">15.2K</p>
                  </div>
                  <Activity className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Analyse Modules</p>
                    <p className="text-3xl font-bold">{analysisModules.length}</p>
                  </div>
                  <Target className="h-8 w-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Recente Wedstrijden</CardTitle>
                <CardDescription>Laatste 5 geanalyseerde wedstrijden</CardDescription>
              </CardHeader>
              <CardContent>
                {matchesLoading ? (
                  <div className="text-center py-8">
                    <Activity className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                    <p className="text-gray-500 mt-2">Laden...</p>
                  </div>
                ) : recentMatches.length > 0 ? (
                  <div className="space-y-3">
                    {recentMatches.map((match: any) => (
                      <div key={match.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium">{match.homeTeam} vs {match.awayTeam}</p>
                          <p className="text-sm text-gray-600">{new Date(match.matchDate).toLocaleDateString('nl-NL')}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold">{match.homeScore} - {match.awayScore}</p>
                          <Badge variant="secondary">{match.status}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileVideo className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-500">Nog geen wedstrijden geanalyseerd</p>
                    <Button className="mt-4" onClick={() => window.location.href = '/gps-match-upload'}>
                      Eerste Wedstrijd Uploaden
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Snelle toegang tot belangrijke functies</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start" onClick={() => window.location.href = '/gps-match-upload'}>
                  <Upload className="h-4 w-4 mr-2" />
                  Nieuwe Wedstrijd Uploaden
                </Button>
                <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = '/match-performance-analysis'}>
                  <Eye className="h-4 w-4 mr-2" />
                  Wedstrijd Analyseren
                </Button>
                <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = '/players-database'}>
                  <Users className="h-4 w-4 mr-2" />
                  Spelers Database
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  Export Rapporten
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="modules" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {analysisModules.map((module) => (
              <Card key={module.id} className="hover:shadow-lg transition-shadow cursor-pointer" 
                    onClick={() => window.location.href = module.href}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${module.color}`}>
                      <module.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{module.title}</CardTitle>
                    </div>
                  </div>
                  <CardDescription>{module.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full">
                    <Play className="h-4 w-4 mr-2" />
                    Open Module
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="matches" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Alle Wedstrijden</CardTitle>
              <CardDescription>Overzicht van alle geanalyseerde wedstrijden</CardDescription>
            </CardHeader>
            <CardContent>
              {matchesLoading ? (
                <div className="text-center py-8">
                  <Activity className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                  <p className="text-gray-500 mt-2">Wedstrijden laden...</p>
                </div>
              ) : matches && matches.length > 0 ? (
                <div className="space-y-4">
                  {matches.map((match: any) => (
                    <div key={match.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{match.homeTeam} vs {match.awayTeam}</h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                            <span className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {new Date(match.matchDate).toLocaleDateString('nl-NL')}
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {match.venue}
                            </span>
                            <span>{match.competition}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold">{match.homeScore} - {match.awayScore}</p>
                          <Badge variant={match.status === 'completed' ? 'default' : 'secondary'}>
                            {match.status}
                          </Badge>
                        </div>
                        <div className="ml-4">
                          <Button onClick={() => window.location.href = `/match-performance-analysis?match=${match.id}`}>
                            <Eye className="h-4 w-4 mr-1" />
                            Analyseren
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileVideo className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Nog geen wedstrijden</h3>
                  <p className="text-gray-500 mb-6">Upload je eerste wedstrijdopstelling om te beginnen met analyse</p>
                  <Button onClick={() => window.location.href = '/gps-match-upload'}>
                    <Upload className="h-4 w-4 mr-2" />
                    Eerste Wedstrijd Uploaden
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="statistics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Wedstrijd Performance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={matches || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="matchDate" tickFormatter={(date) => new Date(date).toLocaleDateString('nl-NL')} />
                    <YAxis />
                    <Tooltip labelFormatter={(date) => new Date(date).toLocaleDateString('nl-NL')} />
                    <Line type="monotone" dataKey="homeScore" stroke="#3b82f6" name="Doelpunten Voor" />
                    <Line type="monotone" dataKey="awayScore" stroke="#ef4444" name="Doelpunten Tegen" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Analyse Module Gebruik</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analysisModules.map((module) => (
                    <div key={module.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-1 rounded ${module.color}`}>
                          <module.icon className="h-4 w-4 text-white" />
                        </div>
                        <span className="text-sm">{module.title}</span>
                      </div>
                      <Badge variant="outline">Beschikbaar</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}