import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Phone, Mail, Eye, Edit, MoreHorizontal, Plus, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Parent } from "@/types";
import { AvatarUpload } from "@/components/ui/avatar-upload";

export default function Parents() {
  const [isAddParentOpen, setIsAddParentOpen] = useState(false);
  const [viewParent, setViewParent] = useState<Parent | null>(null);
  
  // Fetch parents data
  const { data: parents, isLoading, error } = useQuery<Parent[]>({
    queryKey: ['/api/parents'],
  });

  // Define columns for data table
  const columns = [
    {
      header: "Name",
      accessorKey: "user",
      cell: (parent: Parent) => (
        <div className="flex items-center">
          <div className="h-10 w-10 flex-shrink-0 rounded-full bg-secondary-200">
            {parent.user?.profileImage && (
              <img 
                src={parent.user.profileImage} 
                alt={`${parent.user?.firstName} ${parent.user?.lastName}`}
                className="h-full w-full rounded-full object-cover"
              />
            )}
          </div>
          <div className="ml-4">
            <div className="font-medium text-foreground">
              {parent.user?.firstName} {parent.user?.lastName}
            </div>
            <div className="text-muted-foreground">{parent.occupation || ''}</div>
          </div>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Contact",
      accessorKey: "user.email",
      cell: (parent: Parent) => (
        <div>
          <div className="flex items-center text-foreground">
            <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
            {parent.user?.email}
          </div>
          {parent.user?.phone && (
            <div className="flex items-center text-foreground mt-1">
              <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
              {parent.user.phone}
            </div>
          )}
        </div>
      ),
      sortable: true,
    },
    {
      header: "Children",
      accessorKey: "players",
      cell: (parent: Parent) => (
        <div>
          {parent.players && parent.players.length > 0 ? (
            parent.players.map((player, index) => (
              <Badge key={index} variant="outline" className="mr-1 mb-1">
                {player.user?.firstName} {player.user?.lastName}
              </Badge>
            ))
          ) : (
            <span className="text-muted-foreground">No children registered</span>
          )}
        </div>
      ),
    },
    {
      header: "Preferred Contact",
      accessorKey: "contactPreference",
      cell: (parent: Parent) => (
        <Badge variant="outline" className="capitalize">
          {parent.contactPreference || 'Email'}
        </Badge>
      ),
      sortable: true,
    },
    {
      header: "Actions",
      accessorKey: "id",
      cell: (parent: Parent) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => setViewParent(parent)}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  if (isLoading) {
    return <div className="p-8 text-center">Loading parents...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading parents.</div>;
  }

  return (
    <div className="py-6">
      <div className="flex items-center gap-3 mb-4">
        <Link href="/">
          <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 hover:bg-gray-100">
            <ArrowLeft size={18} />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Ouders</h1>
      </div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Parents Management</h2>
        <Dialog open={isAddParentOpen} onOpenChange={setIsAddParentOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Parent
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Parent</DialogTitle>
              <DialogDescription>
                Enter the parent details below to create a new parent record.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
              <div className="flex flex-col items-center justify-center">
                <AvatarUpload 
                  onUpload={(file) => console.log('File uploaded:', file)}
                  size="lg"
                />
              </div>
              <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" placeholder="First Name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" placeholder="Last Name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="Email" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" placeholder="Phone" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="alternatePhone">Alternate Phone</Label>
                  <Input id="alternatePhone" placeholder="Alternate Phone" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="occupation">Occupation</Label>
                  <Input id="occupation" placeholder="Occupation" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contactPreference">Contact Preference</Label>
                  <Select>
                    <SelectTrigger id="contactPreference">
                      <SelectValue placeholder="Select preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="both">Both</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input id="address" placeholder="Address" />
                </div>
                <div className="space-y-2 col-span-full">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea id="notes" placeholder="Any additional notes" rows={3} />
                </div>
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsAddParentOpen(false)}>
                Cancel
              </Button>
              <Button>Save Parent</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Parents table */}
      <DataTable
        data={parents || []}
        columns={columns}
        searchable={true}
        searchKey="user.lastName"
      />

      {/* Parent detail dialog */}
      {viewParent && (
        <Dialog open={!!viewParent} onOpenChange={() => setViewParent(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Parent Details</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
              <div className="flex flex-col items-center space-y-4">
                <div className="h-32 w-32 rounded-full bg-secondary-200 overflow-hidden">
                  {viewParent.user?.profileImage && (
                    <img 
                      src={viewParent.user.profileImage} 
                      alt={`${viewParent.user?.firstName} ${viewParent.user?.lastName}`}
                      className="h-full w-full object-cover"
                    />
                  )}
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-semibold">
                    {viewParent.user?.firstName} {viewParent.user?.lastName}
                  </h3>
                  <p className="text-muted-foreground">{viewParent.occupation || ''}</p>
                </div>
              </div>
              <div className="md:col-span-2 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Email</h4>
                    <p>{viewParent.user?.email}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Phone</h4>
                    <p>{viewParent.user?.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Alternate Phone</h4>
                    <p>{viewParent.alternatePhone || 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Contact Preference</h4>
                    <p className="capitalize">{viewParent.contactPreference || 'Email'}</p>
                  </div>
                  {viewParent.user?.address && (
                    <div className="col-span-2">
                      <h4 className="text-sm font-medium text-muted-foreground">Address</h4>
                      <p>{viewParent.user.address}</p>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Children</h4>
                  {viewParent.players && viewParent.players.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {viewParent.players.map((player, index) => (
                        <div key={index} className="flex items-center p-3 rounded-md border border-gray-200">
                          <div className="h-10 w-10 rounded-full bg-secondary-200 mr-3">
                            {player.user?.profileImage && (
                              <img 
                                src={player.user.profileImage} 
                                alt={`${player.user?.firstName} ${player.user?.lastName}`}
                                className="h-full w-full rounded-full object-cover"
                              />
                            )}
                          </div>
                          <div>
                            <p className="font-medium">{player.user?.firstName} {player.user?.lastName}</p>
                            <p className="text-xs text-muted-foreground">
                              {player.team?.name || 'No team'} • {player.position || 'No position'}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No children registered</p>
                  )}
                </div>

                {viewParent.notes && (
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Notes</h4>
                    <p className="text-sm">{viewParent.notes}</p>
                  </div>
                )}
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline">Edit Parent</Button>
              <Button onClick={() => setViewParent(null)}>Close</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
