import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, FileText, Clock, Users, Target } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import jsPDF from 'jspdf';

export default function TrainingPDFViewer() {
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const sendTrainingPDFEmail = async () => {
    setIsGenerating(true);
    try {
      const trainingData = {
        title: "3-4-3 Opbouw Training",
        duration: 90,
        players: 16,
        formation: "3-4-3",
        focus: "Opbouwen van achteruit met decision making"
      };

      const pdf = await generateTrainingPDF(trainingData);
      const pdfBlob = pdf.output('blob');

      const formData = new FormData();
      formData.append('pdf', pdfBlob, '3-4-3_Opbouw_Training_VVC_Brasschaat.pdf');
      formData.append('recipientEmail', 'ismail.achter@gmail.com');
      formData.append('trainingTitle', '3-4-3 Opbouw Training VVC Brasschaat');

      const response = await fetch('/api/send-training-pdf', {
        method: 'POST',
        body: formData
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "PDF Verzonden!",
          description: "De training PDF is succesvol verzonden naar ismail.achter@gmail.com",
        });
      } else {
        throw new Error(result.error || 'Email verzending mislukt');
      }

    } catch (error) {
      console.error('Email error:', error);
      toast({
        title: "Email Fout", 
        description: "Er ging iets mis bij het verzenden van de email",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadTrainingPDF = async () => {
    setIsGenerating(true);
    try {
      const trainingData = {
        name: "Opbouwen van achteruit - 3-4-3 Formatie",
        description: "Professionele training voor het aanleren van opbouwen vanaf de keeper en verdediging in een 3-4-3 systeem met 16 speelsters",
        duration: 90,
        players: 16,
        intensity: "medium",
        phases: [
          {
            name: "OPWARMING",
            duration: 15,
            exercises: [
              {
                name: "Activerende Opwarming met Bal",
                duration: 8,
                setup: "16 speelsters in een 30x20m veld, elk met een bal",
                description: "Vrije beweging met bal, focus op eerste aanraking en oriëntatie",
                objectives: ["Activeren van spieren en gewrichten", "Balgevoel ontwikkelen", "Eerste aanraking verbeteren"],
                coaching_points: ["Hoofd omhoog, kijk rond je", "Zachte eerste aanraking", "Gebruik beide voeten", "Varieer in tempo en richting"],
                progression: ["Start met lopen en bal raken", "Voeg dribbels toe", "Combineer met kleine wendingen"],
                equipment: ["16 ballen", "4 pionnen"],
                players: 16,
                field_size: "30x20m"
              },
              {
                name: "Passing in Beweging - Driehoekvorm",
                duration: 7,
                setup: "4 groepen van 4 speelsters, driehoekvorm 15m zijden",
                description: "Passing en bewegen in driehoeken, focus op aanbieden en oriëntatie",
                objectives: ["Passing techniek onder druk", "Aanbieden en vrijlopen", "Communicatie ontwikkelen"],
                coaching_points: ["Aanbieden met lichaam open naar spel", "Pass en ga - altijd bewegen", "Praat met je medespelers", "Juiste moment van aanbieden"],
                progression: ["2 aanrakingen", "1 aanraking", "Voeg druk toe met passieve verdediger"],
                equipment: ["4 ballen", "12 pionnen"],
                players: 16,
                field_size: "15x15m per groep"
              }
            ]
          },
          {
            name: "TUSSENVORMEN",
            duration: 45,
            exercises: [
              {
                name: "Tussenvorm 1: 3v2 Opbouwen Centraal",
                duration: 15,
                setup: "3 verdedigers tegen 2 aanvallers in 30x20m zone",
                description: "3 verdedigers bouwen op tegen 2 verdedigers, focus op lijnbreking en switching",
                objectives: ["Opbouwen onder druk", "Lijnbreking door passing", "Switching van spel left-right"],
                coaching_points: [
                  "Centrale verdediger dirigeert - 'Links!', 'Rechts!', 'Centraal!'",
                  "Buitenverdedigers: 'Ik ben vrij!' als je aanspeelbaar bent",
                  "Bij druk: 'Switch!' en verleg het spel",
                  "Keeper: 'Tijd!' of 'Druk!' om situatie aan te geven"
                ],
                progression: ["Start zonder tijdsdruk", "Voeg 8-seconden regel toe", "Verdedigers mogen scoren op minitaken"],
                equipment: ["2 ballen", "8 pionnen", "2 minitaken"],
                players: 10,
                field_size: "30x20m"
              },
              {
                name: "Tussenvorm 2: 4v3 Middenveld Connectie",
                duration: 15,
                setup: "4 middenvelders tegen 3 verdedigers in 40x30m zone",
                description: "Middenvelders ontvangen van achteren en spelen door naar aanval",
                objectives: ["Connectie verdediging-middenveld", "Onder druk spelen in box-vorm", "Doorspelen naar aanval"],
                coaching_points: [
                  "Box middenvelders: 'Geef en ga!' na elke pass",
                  "Centrale middenvelders: 'Draai!' bij ontvangen met rug naar doel",
                  "Buitenmiddenvelders: 'Breed!' om veld groot te maken",
                  "Bij verovering: 'Pressure!' - direct druk zetten"
                ],
                progression: ["Vrij spel met afronden op doel", "Maximaal 3 aanrakingen", "Tel aantal geslaagde doorspelingen"],
                equipment: ["2 ballen", "12 pionnen", "1 doel"],
                players: 14,
                field_size: "40x30m"
              },
              {
                name: "Tussenvorm 3: 3v2+1 Aanval Afwerking",
                duration: 15,
                setup: "3 aanvallers tegen 2 verdedigers + keeper in 30x20m + 16m zone",
                description: "Aanvallers ontvangen van middenveld en werken af met numeriek voordeel",
                objectives: ["Afwerken onder druk", "Gebruik van diepte en breedte", "Timing van loopacties"],
                coaching_points: [
                  "Spits: 'Kom!' voor aanspeelbaar zijn of 'Loop!' voor diepgang",
                  "Vleugelaanvallers: 'Overlap!' bij steunmomenten",
                  "Bij shooting moment: 'Schiet!' van medespelers",
                  "Gebruik '1-2 combinatie' om verdediging te passeren"
                ],
                progression: ["Start met aanspelen vanuit rust", "Voeg loopacties toe", "Tijdslimiet van 6 seconden voor afwerking"],
                equipment: ["3 ballen", "8 pionnen", "1 doel"],
                players: 12,
                field_size: "30x36m"
              }
            ]
          },
          {
            name: "WEDSTRIJDVORMEN",
            duration: 25,
            exercises: [
              {
                name: "Wedstrijdvorm 1: 8v8 Complete Opbouw",
                duration: 8,
                setup: "Volledig veld, beide teams 3-4-1 formatie",
                description: "Complete wedstrijdvorm met focus op opbouwen vanaf keeper",
                objectives: ["Toepassen 3-4-3 systeem", "Opbouwen onder wedstrijddruk", "Positioneel spel uitvoeren"],
                coaching_points: [
                  "Keeper: 'Lijn!' om verdediging op lijn te krijgen",
                  "Centrale verdediger: 'Ik heb tijd!' of 'Druk komt!'",
                  "Middenvelders: 'Drop!' om bal op te halen",
                  "Hele team: 'Hoog druk!' bij balverlies voor pressure"
                ],
                progression: ["Vrij spel", "Verplicht via alle 3 verdedigers", "Punten alleen bij opbouw via keeper"],
                equipment: ["1 bal", "2 doelen", "16 hesjes"],
                players: 16,
                field_size: "70x50m"
              },
              {
                name: "Wedstrijdvorm 2: Zones Voetbal 3-4-3",
                duration: 8,
                setup: "Veld in 3 zones, spelers mogen alleen in eigen zone",
                description: "Wedstrijdvorm met vaste zones om positioneel spel te versterken",
                objectives: ["Positioneel discipline", "Zonegebonden passing", "Connectie tussen linies"],
                coaching_points: [
                  "Verdediging: 'Breed staan!' voor optimale hoeken",
                  "Middenveld: 'Connectie!' tussen linies houden",
                  "Aanval: 'Diepgang!' op juiste momenten",
                  "Overgangen: 'Compact!' bij balverlies"
                ],
                progression: ["Strict zones bewaken", "1 speler mag zone verlaten", "Bij doelpunt mogen alle spelers 5 sec overal"],
                equipment: ["1 bal", "2 doelen", "12 pionnen voor zones"],
                players: 16,
                field_size: "60x40m"
              },
              {
                name: "Wedstrijdvorm 3: Eindzones Voetbal",
                duration: 9,
                setup: "Veld met 2 eindzones, scoren door bal controlled te ontvangen in eindzone",
                description: "Focus op doorspelen naar eindzone via 3-4-3 opbouw",
                objectives: ["Doelgericht opbouwen", "Switching onder druk", "Eindproduct leveren"],
                coaching_points: [
                  "Zoek altijd 'Eindzone!' als doel van opbouw",
                  "Bij vastlopen: 'Reset!' en opnieuw via andere kant",
                  "Aanvallers: 'Timing!' voor binnenlopen eindzone",
                  "Verdediging na verovering: 'Omschakeling!' - direct opbouwen"
                ],
                progression: ["Eindzone scoren = 1 punt", "Via alle 3 verdedigers = 2 punten", "Onder 8 seconden = 3 punten"],
                equipment: ["1 bal", "16 pionnen voor eindzones"],
                players: 16,
                field_size: "50x30m + 2 eindzones 10x30m"
              }
            ]
          },
          {
            name: "COOLING DOWN",
            duration: 5,
            exercises: [
              {
                name: "Uitlopen en Stretching",
                duration: 5,
                setup: "Vrij rond het veld, individueel tempo",
                description: "Geleidelijk uitlopen met focus op teambespreking 3-4-3 systeem",
                objectives: ["Geleidelijk afbouwen intensiteit", "Reflectie op training", "Team building"],
                coaching_points: [
                  "Evalueer: 'Wat ging goed met opbouwen?'",
                  "Bespreek: 'Welke coaching woorden hielpen?'",
                  "Preview: 'Volgende keer meer druk tijdens opbouw'",
                  "Positief afsluiten team prestatie"
                ],
                progression: ["Uitlopen", "Stretching", "Team circle evaluatie"],
                equipment: [],
                players: 16,
                field_size: "Volledig veld"
              }
            ]
          }
        ]
      };

      // Generate PDF with field diagrams
      const pdf = await generateTrainingPDF(trainingData);
      
      // Download PDF
      pdf.save('3-4-3_Opbouw_Training_Met_Tekeningen.pdf');

      toast({
        title: "PDF Training Gedownload!",
        description: "De professionele training met veldtekeningen is gedownload",
      });
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "Fout bij downloaden", 
        description: "Er ging iets mis bij het genereren van de PDF",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const generateTrainingPDF = async (training: any) => {
    const doc = new jsPDF('portrait', 'mm', 'a4');
    let yPos = 20;
    
    // Helper functions for drawing
    const drawField = (x: number, y: number, width: number, height: number) => {
      doc.setDrawColor(0, 100, 0); // Dark green
      doc.setLineWidth(0.5);
      doc.rect(x, y, width, height);
    };
    
    const drawPlayer = (x: number, y: number, number: string, color: string = 'blue') => {
      if (color === 'blue') doc.setFillColor(0, 100, 200);
      else if (color === 'red') doc.setFillColor(200, 0, 0);
      else if (color === 'yellow') doc.setFillColor(255, 200, 0);
      
      doc.circle(x, y, 3, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(8);
      doc.text(number, x - 1, y + 1);
      doc.setTextColor(0, 0, 0);
    };
    
    const drawArrow = (x1: number, y1: number, x2: number, y2: number, color: string = 'black') => {
      if (color === 'blue') doc.setDrawColor(0, 100, 200);
      else if (color === 'red') doc.setDrawColor(200, 0, 0);
      else doc.setDrawColor(0, 0, 0);
      
      doc.setLineWidth(1);
      doc.line(x1, y1, x2, y2);
      
      // Arrow head
      const angle = Math.atan2(y2 - y1, x2 - x1);
      const headLength = 3;
      doc.line(x2, y2, 
               x2 - headLength * Math.cos(angle - Math.PI/6), 
               y2 - headLength * Math.sin(angle - Math.PI/6));
      doc.line(x2, y2, 
               x2 - headLength * Math.cos(angle + Math.PI/6), 
               y2 - headLength * Math.sin(angle + Math.PI/6));
    };
    
    const drawBall = (x: number, y: number) => {
      doc.setFillColor(255, 255, 255);
      doc.setDrawColor(0, 0, 0);
      doc.circle(x, y, 2, 'FD');
    };
    
    // Title page
    doc.setFontSize(24);
    doc.setFont('helvetica', 'bold');
    doc.text('PROFESSIONELE VOETBALTRAINING', 105, yPos, { align: 'center' });
    yPos += 15;
    
    doc.setFontSize(18);
    doc.text('Opbouwen van achteruit - 3-4-3 Formatie', 105, yPos, { align: 'center' });
    yPos += 20;
    
    // Training info box
    doc.setFillColor(240, 240, 240);
    doc.rect(20, yPos - 5, 170, 40, 'F');
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text('TRAINING INFORMATIE:', 25, yPos + 5);
    doc.text('• Duur: 90 minuten', 25, yPos + 12);
    doc.text('• Spelers: 16 speelsters', 25, yPos + 19);
    doc.text('• Formatie: 3-4-3 (3 verdedigers, box middenveld, 3 aanvallers)', 25, yPos + 26);
    doc.text('• Focus: Opbouwen onder druk met decision making', 25, yPos + 33);
    yPos += 50;
    
    // 3-4-3 Formation diagram
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('3-4-3 FORMATIE OVERZICHT', 105, yPos, { align: 'center' });
    yPos += 10;
    
    // Draw formation field
    const fieldX = 40, fieldY = yPos, fieldW = 120, fieldH = 80;
    drawField(fieldX, fieldY, fieldW, fieldH);
    
    // Draw center circle
    doc.setDrawColor(0, 100, 0);
    doc.circle(fieldX + fieldW/2, fieldY + fieldH/2, 15, 'S');
    
    // Draw 3-4-3 formation
    // Keeper
    drawPlayer(fieldX + fieldW/2, fieldY + fieldH - 10, 'K', 'yellow');
    
    // 3 Defenders
    drawPlayer(fieldX + 20, fieldY + fieldH - 25, '2', 'blue');
    drawPlayer(fieldX + fieldW/2, fieldY + fieldH - 25, '5', 'blue');
    drawPlayer(fieldX + fieldW - 20, fieldY + fieldH - 25, '3', 'blue');
    
    // Box midfield (4 players)
    drawPlayer(fieldX + 30, fieldY + fieldH - 45, '6', 'blue');
    drawPlayer(fieldX + 50, fieldY + fieldH - 45, '8', 'blue');
    drawPlayer(fieldX + fieldW - 50, fieldY + fieldH - 45, '10', 'blue');
    drawPlayer(fieldX + fieldW - 30, fieldY + fieldH - 45, '4', 'blue');
    
    // 3 Forwards
    drawPlayer(fieldX + 25, fieldY + 15, '11', 'blue');
    drawPlayer(fieldX + fieldW/2, fieldY + 15, '9', 'blue');
    drawPlayer(fieldX + fieldW - 25, fieldY + 15, '7', 'blue');
    
    yPos += 90;
    
    // Training phases
    const phases = [
      {
        name: "OPWARMING",
        duration: 15,
        exercises: [
          {
            name: "Activerende Opwarming met Bal",
            duration: 8,
            setup: "16 speelsters in 30x20m veld, elk met bal",
            description: "Vrije beweging met bal, focus op eerste aanraking",
            coaching: ["Hoofd omhoog!", "Zachte aanraking!", "Gebruik beide voeten!"],
            fieldDiagram: "activation"
          },
          {
            name: "Passing Driehoeken",
            duration: 7,
            setup: "4 groepen van 4, driehoek 15m zijden",
            description: "Passing en bewegen, aanbieden en oriëntatie",
            coaching: ["Lichaam open!", "Pass en ga!", "Praat!"],
            fieldDiagram: "triangles"
          }
        ]
      },
      {
        name: "TUSSENVORMEN", 
        duration: 45,
        exercises: [
          {
            name: "3v2 Opbouwen Centraal",
            duration: 15,
            setup: "3 verdedigers vs 2 aanvallers, 30x20m",
            description: "Opbouwen onder druk, lijnbreking en switching",
            coaching: ["Links/Rechts/Centraal!", "Ik ben vrij!", "Switch!", "Tijd/Druk!"],
            fieldDiagram: "3v2_buildup",
            decisionMaking: [
              "Druk links → Switch naar rechts",
              "Geen druk → Speel centraal door",
              "Hoge druk → Bal breed naar buitenverdediger"
            ]
          },
          {
            name: "4v3 Middenveld Connectie",
            duration: 15,
            setup: "Box middenveld vs 3 verdedigers, 40x30m",
            description: "Connectie verdediging-middenveld-aanval",
            coaching: ["Geef en ga!", "Draai!", "Breed!", "Pressure!"],
            fieldDiagram: "4v3_midfield",
            decisionMaking: [
              "Open medespeler → Directe pass",
              "Onder druk → Drop en draai",
              "Ruimte voor → Doorspelen naar aanval"
            ]
          },
          {
            name: "3v2+1 Aanval Afwerking",
            duration: 15,
            setup: "3 aanvallers vs 2 verdedigers + keeper",
            description: "Numeriek voordeel uitspelen, afwerken",
            coaching: ["Kom/Loop!", "Overlap!", "Schiet!", "1-2 combinatie!"],
            fieldDiagram: "3v2_attack",
            decisionMaking: [
              "1v1 situatie → Individuele actie",
              "Steun beschikbaar → Combinatie",
              "Schietpositie → Direct afronden"
            ]
          }
        ]
      },
      {
        name: "WEDSTRIJDVORMEN",
        duration: 25,
        exercises: [
          {
            name: "8v8 Complete Opbouw",
            duration: 8,
            setup: "Volledig veld, beide teams 3-4-1",
            description: "Complete wedstrijdvorm, opbouw vanaf keeper",
            coaching: ["Lijn!", "Ik heb tijd/Druk komt!", "Drop!", "Hoog druk!"],
            fieldDiagram: "8v8_full",
            decisionMaking: [
              "Keeper vrij → Opbouw via keeper",
              "Druk op keeper → Directe pass verdediging",
              "Balverlies → Onmiddellijke pressure"
            ]
          },
          {
            name: "Zones Voetbal 3-4-3",
            duration: 8,
            setup: "Veld in 3 zones, spelers in eigen zone",
            description: "Positioneel spel, connectie tussen linies",
            coaching: ["Breed staan!", "Connectie!", "Diepgang!", "Compact!"],
            fieldDiagram: "zones_343",
            decisionMaking: [
              "Zone vol → Zoek andere zone",
              "Vrije medespeler → Directe pass",
              "Geen opties → Behoud bezit"
            ]
          },
          {
            name: "Eindzones Voetbal",
            duration: 9,
            setup: "Veld + 2 eindzones 10x30m",
            description: "Doelgericht opbouwen naar eindzone",
            coaching: ["Eindzone!", "Reset!", "Timing!", "Omschakeling!"],
            fieldDiagram: "endzones",
            decisionMaking: [
              "Eindzone open → Directe pass",
              "Eindzone bezet → Geduld en reset",
              "Verovering → Snelle omschakeling"
            ]
          }
        ]
      }
    ];
    
    // Generate each phase
    phases.forEach((phase, phaseIndex) => {
      doc.addPage();
      yPos = 20;
      
      // Phase header
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text(`${phase.name} (${phase.duration} minuten)`, 105, yPos, { align: 'center' });
      yPos += 15;
      
      phase.exercises.forEach((exercise, exerciseIndex) => {
        if (exerciseIndex > 0) {
          doc.addPage();
          yPos = 20;
        }
        
        // Exercise title
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text(`${exerciseIndex + 1}. ${exercise.name} (${exercise.duration} min)`, 20, yPos);
        yPos += 10;
        
        // Field diagram based on exercise type
        const diagramY = yPos;
        yPos += drawExerciseDiagram(doc, exercise.fieldDiagram, 20, diagramY);
        
        // Exercise details
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text('OPSTELLING:', 20, yPos);
        doc.setFont('helvetica', 'normal');
        doc.text(exercise.setup, 55, yPos);
        yPos += 8;
        
        doc.setFont('helvetica', 'bold');
        doc.text('UITVOERING:', 20, yPos);
        doc.setFont('helvetica', 'normal');
        const descLines = doc.splitTextToSize(exercise.description, 150);
        doc.text(descLines, 55, yPos);
        yPos += descLines.length * 5 + 5;
        
        // Coaching points
        doc.setFont('helvetica', 'bold');
        doc.text('COACHING WOORDEN:', 20, yPos);
        yPos += 6;
        exercise.coaching.forEach((point: string) => {
          doc.setFont('helvetica', 'normal');
          doc.text(`• ${point}`, 25, yPos);
          yPos += 5;
        });
        yPos += 3;
        
        // Decision making (if available)
        if (exercise.decisionMaking) {
          doc.setFont('helvetica', 'bold');
          doc.text('DECISION MAKING:', 20, yPos);
          yPos += 6;
          exercise.decisionMaking.forEach((decision: string) => {
            doc.setFont('helvetica', 'normal');
            doc.text(`• ${decision}`, 25, yPos);
            yPos += 5;
          });
        }
      });
    });
    
    return doc;
    
    function drawExerciseDiagram(doc: jsPDF, type: string, x: number, y: number): number {
      const fieldW = 80, fieldH = 50;
      let height = 60;
      
      switch(type) {
        case "3v2_buildup":
          // Draw field
          drawField(x, y, fieldW, fieldH);
          
          // 3 defenders (blue)
          drawPlayer(x + 15, y + fieldH - 10, '2', 'blue');
          drawPlayer(x + fieldW/2, y + fieldH - 10, '5', 'blue');
          drawPlayer(x + fieldW - 15, y + fieldH - 10, '3', 'blue');
          
          // 2 attackers pressuring (red)
          drawPlayer(x + 25, y + fieldH - 25, 'A1', 'red');
          drawPlayer(x + fieldW - 25, y + fieldH - 25, 'A2', 'red');
          
          // Ball at center defender
          drawBall(x + fieldW/2, y + fieldH - 10);
          
          // Decision arrows
          drawArrow(x + fieldW/2, y + fieldH - 10, x + 15, y + fieldH - 10, 'blue'); // To left
          drawArrow(x + fieldW/2, y + fieldH - 10, x + fieldW - 15, y + fieldH - 10, 'blue'); // To right
          drawArrow(x + fieldW/2, y + fieldH - 10, x + fieldW/2, y + fieldH - 30, 'blue'); // Forward
          
          // Add decision text
          doc.setFontSize(8);
          doc.text('DRUK LINKS → SWITCH RECHTS', x, y + fieldH + 5);
          doc.text('GEEN DRUK → SPEEL DOOR', x, y + fieldH + 10);
          break;
          
        case "4v3_midfield":
          // Draw field
          drawField(x, y, fieldW, fieldH);
          
          // Box midfield (blue)
          drawPlayer(x + 20, y + fieldH/2 - 8, '6', 'blue');
          drawPlayer(x + 35, y + fieldH/2 - 8, '8', 'blue');
          drawPlayer(x + fieldW - 35, y + fieldH/2 - 8, '10', 'blue');
          drawPlayer(x + fieldW - 20, y + fieldH/2 - 8, '4', 'blue');
          
          // 3 opponents (red)
          drawPlayer(x + 25, y + 15, 'D1', 'red');
          drawPlayer(x + fieldW/2, y + 15, 'D2', 'red');
          drawPlayer(x + fieldW - 25, y + 15, 'D3', 'red');
          
          // Ball at midfielder
          drawBall(x + 35, y + fieldH/2 - 8);
          
          // Passing options
          drawArrow(x + 35, y + fieldH/2 - 8, x + 20, y + fieldH/2 - 8, 'blue');
          drawArrow(x + 35, y + fieldH/2 - 8, x + fieldW - 35, y + fieldH/2 - 8, 'blue');
          drawArrow(x + 35, y + fieldH/2 - 8, x + 35, y + 10, 'blue');
          
          doc.setFontSize(8);
          doc.text('BOX MIDDENVELD - GEEF EN GA', x, y + fieldH + 5);
          break;
          
        case "3v2_attack":
          // Draw penalty area
          doc.setDrawColor(0, 100, 0);
          doc.rect(x + 10, y, fieldW - 20, 25);
          
          // Goal
          doc.setLineWidth(2);
          doc.line(x + 30, y, x + fieldW - 30, y);
          
          // 3 attackers (blue)
          drawPlayer(x + 20, y + 35, '11', 'blue');
          drawPlayer(x + fieldW/2, y + 35, '9', 'blue');
          drawPlayer(x + fieldW - 20, y + 35, '7', 'blue');
          
          // 2 defenders (red)
          drawPlayer(x + 30, y + 15, 'D1', 'red');
          drawPlayer(x + fieldW - 30, y + 15, 'D2', 'red');
          
          // Keeper (yellow)
          drawPlayer(x + fieldW/2, y + 5, 'K', 'yellow');
          
          // Ball at center forward
          drawBall(x + fieldW/2, y + 35);
          
          // Attack options
          drawArrow(x + fieldW/2, y + 35, x + 20, y + 35, 'blue'); // To winger
          drawArrow(x + fieldW/2, y + 35, x + fieldW/2, y + 20, 'blue'); // To goal
          drawArrow(x + 20, y + 35, x + 15, y + 15, 'blue'); // Run behind
          
          doc.setFontSize(8);
          doc.text('NUMERIEK VOORDEEL - 3v2+K', x, y + fieldH + 5);
          break;
          
        case "8v8_full":
          // Full field
          drawField(x, y, fieldW, fieldH * 1.2);
          
          // Center circle
          doc.circle(x + fieldW/2, y + fieldH * 0.6, 8, 'S');
          
          // Team 1 (blue) - 3-4-3
          drawPlayer(x + fieldW/2, y + fieldH * 1.15, 'K', 'yellow');
          drawPlayer(x + 15, y + fieldH * 0.95, '2', 'blue');
          drawPlayer(x + fieldW/2, y + fieldH * 0.95, '5', 'blue');
          drawPlayer(x + fieldW - 15, y + fieldH * 0.95, '3', 'blue');
          
          // Team 2 (red) - opposing formation
          drawPlayer(x + fieldW/2, y + 5, 'K', 'yellow');
          drawPlayer(x + 20, y + 15, '4', 'red');
          drawPlayer(x + fieldW/2, y + 15, '5', 'red');
          drawPlayer(x + fieldW - 20, y + 15, '6', 'red');
          
          doc.setFontSize(8);
          doc.text('8v8 COMPLETE WEDSTRIJDVORM', x, y + fieldH * 1.2 + 10);
          break;
          
        case "zones_343":
          // Draw zones
          drawField(x, y, fieldW, fieldH);
          doc.setDrawColor(200, 200, 200);
          doc.line(x, y + fieldH/3, x + fieldW, y + fieldH/3);
          doc.line(x, y + 2*fieldH/3, x + fieldW, y + 2*fieldH/3);
          
          // Zone labels
          doc.setFontSize(8);
          doc.text('AANVAL', x + 5, y + fieldH/6);
          doc.text('MIDDENVELD', x + 5, y + fieldH/2);
          doc.text('VERDEDIGING', x + 5, y + 5*fieldH/6);
          
          // Players in zones
          drawPlayer(x + 20, y + fieldH/6, '11', 'blue');
          drawPlayer(x + fieldW/2, y + fieldH/6, '9', 'blue');
          drawPlayer(x + fieldW - 20, y + fieldH/6, '7', 'blue');
          
          drawPlayer(x + 25, y + fieldH/2, '8', 'blue');
          drawPlayer(x + fieldW - 25, y + fieldH/2, '10', 'blue');
          
          doc.setFontSize(8);
          doc.text('POSITIONEEL SPEL - 3 ZONES', x, y + fieldH + 5);
          break;
          
        case "endzones":
          // Main field
          drawField(x + 15, y, fieldW - 30, fieldH);
          
          // End zones
          doc.setFillColor(255, 255, 150);
          doc.rect(x, y, 15, fieldH, 'F');
          doc.rect(x + fieldW - 15, y, 15, fieldH, 'F');
          
          // Players
          drawPlayer(x + 30, y + fieldH/2, '5', 'blue');
          drawPlayer(x + fieldW/2, y + fieldH/2, '8', 'blue');
          drawPlayer(x + fieldW - 30, y + fieldH/2, '10', 'blue');
          
          // Target in endzone
          drawPlayer(x + 8, y + fieldH/2, '11', 'blue');
          
          // Pass to endzone
          drawArrow(x + fieldW/2, y + fieldH/2, x + 8, y + fieldH/2, 'blue');
          
          doc.setFontSize(8);
          doc.text('DOELGERICHT NAAR EINDZONE', x, y + fieldH + 5);
          break;
          
        default:
          height = 20;
      }
      
      return height;
    }
  };

  const generateTrainingText = (training: any) => {
    let text = `
===============================================================================
                           PROFESSIONELE TRAINING
                     Opbouwen van achteruit - 3-4-3 Formatie
===============================================================================

TRAINING INFORMATIE:
Duur: 90 minuten
Spelers: 16 speelsters  
Formatie: 3-4-3 systeem
Intensiteit: Gemiddeld

BESCHRIJVING:
Professionele training voor het aanleren van opbouwen vanaf de keeper en 
verdediging in een 3-4-3 systeem met 16 speelsters. Deze training bevat alle 
coaching woorden, progressie stappen en materiaallijsten volgens EDT principes.

`;

    training.phases.forEach((phase: any, phaseIndex: number) => {
      text += `
===============================================================================
                        ${phase.name} (${phase.duration} minuten)
===============================================================================

`;
      
      phase.exercises.forEach((exercise: any, exerciseIndex: number) => {
        text += `
${exerciseIndex + 1}. ${exercise.name} (${exercise.duration} min)
${'='.repeat(60)}

OPSTELLING:
${exercise.setup}

UITVOERING:
${exercise.description}

DOELSTELLINGEN:
${exercise.objectives?.map((obj: string) => `• ${obj}`).join('\n') || 'Geen specifieke doelstellingen'}

COACHING WOORDEN:
${exercise.coaching_points?.map((point: string) => `• ${point}`).join('\n') || 'Geen coaching punten'}

PROGRESSIE:
${exercise.progression?.map((prog: string, idx: number) => `${idx + 1}. ${prog}`).join('\n') || 'Geen progressie stappen'}

MATERIAAL: ${exercise.equipment?.join(', ') || 'Geen materiaal'}
VELDGROOTTE: ${exercise.field_size || 'Niet gespecificeerd'}

${'='.repeat(60)}
`;
      });
    });

    text += `

===============================================================================
                              VVC Brasschaat
                     Professional Training System
===============================================================================
`;

    return text;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-8 text-white">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  ⚽
                </div>
                Professionele Training PDF
              </h1>
              <p className="text-blue-100 text-lg">
                Download je complete 3-4-3 opbouw training
              </p>
            </div>
          </div>
        </div>

        {/* Training Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center">
              Opbouwen van achteruit - 3-4-3 Formatie
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <Clock className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                <div className="text-2xl font-bold text-blue-600">90</div>
                <div className="text-sm text-gray-600">Minuten</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <Users className="h-8 w-8 mx-auto mb-2 text-green-600" />
                <div className="text-2xl font-bold text-green-600">16</div>
                <div className="text-sm text-gray-600">Speelsters</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <Target className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                <div className="text-2xl font-bold text-purple-600">9</div>
                <div className="text-sm text-gray-600">Oefeningen</div>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-bold text-lg mb-4">Training Inhoud:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-blue-600 mb-2">OPWARMING (15 min)</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Activerende opwarming met bal</li>
                    <li>• Passing in driehoekvorm</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-green-600 mb-2">TUSSENVORMEN (45 min)</h4>
                  <ul className="text-sm space-y-1">
                    <li>• 3v2 Opbouwen centraal</li>
                    <li>• 4v3 Middenveld connectie</li>
                    <li>• 3v2+1 Aanval afwerking</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-600 mb-2">WEDSTRIJDVORMEN (25 min)</h4>
                  <ul className="text-sm space-y-1">
                    <li>• 8v8 Complete opbouw</li>
                    <li>• Zones voetbal 3-4-3</li>
                    <li>• Eindzones voetbal</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-purple-600 mb-2">INCLUSIEF</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Alle coaching woorden</li>
                    <li>• Progressie stappen</li>
                    <li>• Materiaallijsten</li>
                    <li>• Veldafmetingen</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="text-center space-y-4">
              <div className="flex justify-center gap-4">
                <Button 
                  onClick={downloadTrainingPDF}
                  disabled={isGenerating}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg"
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                      PDF Genereren...
                    </>
                  ) : (
                    <>
                      <Download className="h-5 w-5 mr-3" />
                      Download PDF
                  </>
                )}
                </Button>
                
                <Button 
                  onClick={sendTrainingPDFEmail}
                  disabled={isGenerating}
                  size="lg"
                  className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 text-lg"
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                      Verzenden...
                    </>
                  ) : (
                    <>
                      <svg className="h-5 w-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 7.89a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                      Email naar ismail.achter@gmail.com
                    </>
                  )}
                </Button>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-start gap-3">
                <FileText className="h-5 w-5 text-blue-600 mt-0.5" />
                <div className="text-sm">
                  <p className="font-semibold text-blue-800 mb-1">Professionele Training volgens EDT Principes</p>
                  <p className="text-blue-700">
                    Deze training bevat volledige uitleg van elke oefening, coaching woorden, 
                    progressie stappen en materiaallijsten. Perfect voor trainers die een 3-4-3 
                    opbouwsysteem willen implementeren.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}