import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Calendar, Plus, Edit, Trash2, Download, Eye, Users, BookOpen, MapPin, Clock, Database, CalendarDays, Target } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrainingCalendar } from "@/components/calendar/training-calendar";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { format, addDays, startOfWeek, isSameDay, getWeek } from "date-fns";
import { nl } from "date-fns/locale";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import "jspdf-autotable";

interface TrainingPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  sessionsPerWeek: number;
  trainingDays: string[];
  createdAt: string;
}

interface TrainingSession {
  id?: number;
  planId: number;
  week: number;
  session: number;
  date: string;
  duration: number;
  focusArea: string;
  assignedThemes: string[];
  assignedElements: string[];
  iadatabankElements: {
    basics: string[];
    teamtactisch: string[];
    mentaal: string[];
    fysiek: string[];
    omschakeling: string[];
  };
}

interface IADatabankElement {
  id: number;
  topic: string;
  subtopic: string;
  name: string;
  theme: string;
  progressions: {
    level: number;
    name: string;
    description: string;
    difficulty: number;
  }[];
}

export default function JaarplanningDynamic() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // State management
  const [selectedPlan, setSelectedPlan] = useState<TrainingPlan | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [planToDelete, setPlanToDelete] = useState<TrainingPlan | null>(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedIACategory, setSelectedIACategory] = useState("");
  const [selectedSubtopic, setSelectedSubtopic] = useState("");
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [selectedIAElements, setSelectedIAElements] = useState<{[key: string]: boolean}>({});
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [showCategoryElements, setShowCategoryElements] = useState<string | null>(null);
  const [selectedCategoryElements, setSelectedCategoryElements] = useState<{[key: string]: string[]}>({});
  const [selectedElementThemes, setSelectedElementThemes] = useState<{[key: string]: string}>({});
  const [dateThemes, setDateThemes] = useState<{[planId: number]: {[date: string]: string[]}}>({});
  const [showFullCalendar, setShowFullCalendar] = useState(false);
  const [calendarMonth, setCalendarMonth] = useState(new Date());

  // Fetch IADATABANK elements dynamically from server
  const { data: iadatabankResponse } = useQuery<{ data: IADatabankElement[] }>({
    queryKey: ["/api/iadatabank/elements"],
    enabled: !!user,
  });
  
  const iadatabankElements = iadatabankResponse?.data || [];

  // Fetch training plans
  const { data: trainingPlans = [] } = useQuery<TrainingPlan[]>({
    queryKey: ["/api/training-plans"],
    enabled: !!user,
  });

  // Fetch teams for dropdown
  const { data: teams = [] } = useQuery({
    queryKey: ["/api/teams"],
    enabled: !!user,
  });

  // Group IADATABANK elements by topic and subtopic
  const groupedElements = iadatabankElements.reduce((acc, element) => {
    const categoryKey = `${element.topic} ${element.subtopic}`.trim();
    if (!acc[categoryKey]) {
      acc[categoryKey] = {};
    }
    if (!acc[categoryKey][element.theme]) {
      acc[categoryKey][element.theme] = [];
    }
    acc[categoryKey][element.theme].push(element);
    return acc;
  }, {} as Record<string, Record<string, IADatabankElement[]>>);

  // Create new training plan
  const createPlanMutation = useMutation({
    mutationFn: async (planData: Omit<TrainingPlan, 'id' | 'createdAt'>) => {
      const response = await apiRequest("POST", "/api/training-plans", planData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training-plans"] });
      setShowCreateDialog(false);
      toast({ title: "Jaarplanning succesvol aangemaakt" });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij aanmaken jaarplanning",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update training plan
  const updatePlanMutation = useMutation({
    mutationFn: async (planData: TrainingPlan) => {
      const response = await apiRequest("PUT", `/api/training-plans/${planData.id}`, planData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training-plans"] });
      setShowEditDialog(false);
      setSelectedPlan(null);
      toast({ title: "Jaarplanning succesvol bijgewerkt" });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij bijwerken jaarplanning",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete training plan
  const deletePlanMutation = useMutation({
    mutationFn: async (planId: number) => {
      await apiRequest("DELETE", `/api/training-plans/${planId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training-plans"] });
      toast({ title: "Jaarplanning succesvol verwijderd" });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij verwijderen jaarplanning",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Save IADATABANK session
  const saveSessionMutation = useMutation({
    mutationFn: async (sessionData: Partial<TrainingSession>) => {
      const response = await apiRequest("POST", "/api/training-sessions", {
        ...sessionData,
        iadatabankElements: selectedCategoryElements,
        themes: selectedElementThemes,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training-sessions"] });
      setShowSessionDialog(false);
      setSelectedCategoryElements({});
      setSelectedElementThemes({});
      toast({ title: "Training sessie succesvol opgeslagen met IADATABANK elementen" });
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij opslaan sessie",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Helper functions for calendar and export
  function generateCalendarDays(plan: TrainingPlan) {
    const startDate = new Date(plan.startDate);
    const endDate = new Date(plan.endDate);
    const days = [];
    
    // Day mapping for training days comparison
    const dayMapping: {[key: string]: string} = {
      'maandag': 'monday',
      'dinsdag': 'tuesday', 
      'woensdag': 'wednesday',
      'donderdag': 'thursday',
      'vrijdag': 'friday',
      'zaterdag': 'saturday',
      'zondag': 'sunday'
    };
    
    // Get the start of the week for the first day
    const weekStart = startOfWeek(startDate, { weekStartsOn: 1 });
    
    // Generate 6 weeks of calendar
    for (let week = 0; week < 6; week++) {
      for (let day = 0; day < 7; day++) {
        const currentDate = addDays(weekStart, week * 7 + day);
        const dateString = format(currentDate, 'dd', { locale: nl });
        const isInRange = currentDate >= startDate && currentDate <= endDate;
        
        // Get both Dutch and English day names
        const dutchDayName = format(currentDate, 'EEEE', { locale: nl }).toLowerCase();
        const englishDayName = format(currentDate, 'EEEE').toLowerCase();
        
        // Check if this day is a training day using multiple comparison methods
        const isTrainingDay = isInRange && plan.trainingDays.some(day => 
          day.toLowerCase() === dutchDayName || 
          day.toLowerCase() === englishDayName ||
          dayMapping[dutchDayName] === day.toLowerCase()
        );
        
        days.push({
          date: dateString,
          fullDate: currentDate,
          isTrainingDay,
          isInRange
        });
      }
    }
    
    return days;
  }

  function exportToExcel(plan: TrainingPlan) {
    const workbook = XLSX.utils.book_new();
    
    // Create planning sheet
    const planningData = [
      ['Jaarplanning', plan.name],
      ['Beschrijving', plan.description],
      ['Leeftijdsgroep', plan.ageGroup],
      ['Seizoen', plan.season],
      ['Start Datum', plan.startDate],
      ['Eind Datum', plan.endDate],
      ['Sessies per week', plan.sessionsPerWeek],
      ['Training Dagen', plan.trainingDays.join(', ')],
      [],
      ['Week', 'Datum', 'Focus Area', 'IADATABANK Elementen']
    ];
    
    // Add calendar data
    const calendarDays = generateCalendarDays(plan);
    calendarDays.forEach((day, index) => {
      if (day.isTrainingDay) {
        const weekNumber = getWeek(day.fullDate);
        planningData.push([
          weekNumber,
          format(day.fullDate, 'dd-MM-yyyy'),
          'IADATABANK Training',
          'Geselecteerde elementen'
        ]);
      }
    });
    
    const worksheet = XLSX.utils.aoa_to_sheet(planningData);
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Jaarplanning');
    
    XLSX.writeFile(workbook, `${plan.name}_jaarplanning.xlsx`);
  }

  function exportToPDF(plan: TrainingPlan) {
    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(20);
    doc.text(`Jaarplanning: ${plan.name}`, 20, 30);
    
    // Add plan details
    doc.setFontSize(12);
    doc.text(`Beschrijving: ${plan.description}`, 20, 50);
    doc.text(`Leeftijdsgroep: ${plan.ageGroup}`, 20, 65);
    doc.text(`Seizoen: ${plan.season}`, 20, 80);
    doc.text(`Periode: ${plan.startDate} - ${plan.endDate}`, 20, 95);
    doc.text(`Sessies per week: ${plan.sessionsPerWeek}`, 20, 110);
    doc.text(`Training dagen: ${plan.trainingDays.join(', ')}`, 20, 125);
    
    // Add calendar table
    const calendarData = generateCalendarDays(plan)
      .filter(day => day.isTrainingDay)
      .map(day => [
        getWeek(day.fullDate).toString(),
        format(day.fullDate, 'dd-MM-yyyy'),
        'IADATABANK Training',
        'Geselecteerde elementen'
      ]);
    
    (doc as any).autoTable({
      head: [['Week', 'Datum', 'Focus Area', 'IADATABANK Elementen']],
      body: calendarData,
      startY: 140,
    });
    
    doc.save(`${plan.name}_jaarplanning.pdf`);
  }

  function exportToICS(plan: TrainingPlan) {
    const calendarDays = generateCalendarDays(plan).filter(day => day.isTrainingDay);
    
    let icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Soccer Club Management//Training Calendar//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH'
    ];

    calendarDays.forEach((day, index) => {
      const startDate = format(day.fullDate, 'yyyyMMdd');
      const startTime = '180000'; // 18:00
      const endTime = '193000'; // 19:30
      
      icsContent.push(
        'BEGIN:VEVENT',
        `UID:training-${plan.id}-${index}@soccerclub.com`,
        `DTSTAMP:${format(new Date(), 'yyyyMMddTHHmmss')}Z`,
        `DTSTART:${startDate}T${startTime}`,
        `DTEND:${startDate}T${endTime}`,
        `SUMMARY:Training ${plan.name}`,
        `DESCRIPTION:Jaarplanning training sessie\\nLeeftijdsgroep: ${plan.ageGroup}\\nIADATABANK elementen beschikbaar`,
        `LOCATION:Voetbalveld`,
        'STATUS:CONFIRMED',
        'TRANSP:OPAQUE',
        'END:VEVENT'
      );
    });

    icsContent.push('END:VCALENDAR');
    
    const blob = new Blob([icsContent.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${plan.name}_kalender.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Jaarplanning Management</h1>
          <p className="text-muted-foreground">
            Beheer trainingsplannen met dynamische IADATABANK integratie
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/iadatabank">
            <Button variant="outline">
              <Database className="h-4 w-4 mr-2" />
              IADATABANK Beheer
            </Button>
          </Link>
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Nieuw Plan
          </Button>
        </div>
      </div>

      {/* Training Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {trainingPlans.map((plan) => (
          <Card key={plan.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span>{plan.name}</span>
                </div>
                <Badge variant="secondary">{plan.ageGroup}</Badge>
              </CardTitle>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4" />
                  <span>{plan.teamName || 'Geen team'}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4" />
                  <span>{plan.startDate} - {plan.endDate}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4" />
                  <span>{plan.sessionsPerWeek}x per week</span>
                </div>
              </div>
              
              <div className="flex items-center justify-end">
                <div className="flex gap-1">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setSelectedPlan(plan);
                            setShowFullCalendar(true);
                          }}
                        >
                          <Calendar className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Kalender</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setSelectedPlan(plan);
                            setShowEditDialog(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Bewerk</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => exportToPDF(plan)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>PDF Export</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => exportToExcel(plan)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Excel Export</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => exportToICS(plan)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>ICS Kalender</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    onClick={() => {
                      setPlanToDelete(plan);
                      setShowDeleteDialog(true);
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Calendar and Export Functions */}
      {selectedPlan && (
        <div className="mt-8 space-y-6">
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Kalender & Planning - {selectedPlan.name}</h2>
            <div className="flex flex-wrap gap-2">
              <Button 
                variant="outline"
                onClick={() => {
                  console.log('Opening full calendar...');
                  setShowFullCalendar(true);
                }}
              >
                <CalendarDays className="h-4 w-4 mr-2" />
                Kalender
              </Button>
              <Button 
                variant="outline"
                onClick={() => exportToExcel(selectedPlan)}
              >
                <Download className="h-4 w-4 mr-2" />
                Excel Export
              </Button>
              <Button 
                variant="outline"
                onClick={() => exportToPDF(selectedPlan)}
              >
                <Download className="h-4 w-4 mr-2" />
                PDF Export
              </Button>
              <Button 
                variant="outline"
                onClick={() => exportToICS(selectedPlan)}
              >
                <Download className="h-4 w-4 mr-2" />
                ICS Kalender
              </Button>
            </div>
          </div>

          {/* Tabbed Interface */}
          <Tabs defaultValue="calendar" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Overzicht
              </TabsTrigger>
              <TabsTrigger value="calendar" className="flex items-center gap-2">
                <CalendarDays className="h-4 w-4" />
                Training Kalender
              </TabsTrigger>
              <TabsTrigger value="iadatabank" className="flex items-center gap-2">
                <Database className="h-4 w-4" />
                Selecteer uw thema's
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              {/* Weekly Calendar View */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Week Overzicht
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-7 gap-2 mb-4">
                    {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map((day) => (
                      <div key={day} className="p-2 text-center font-semibold bg-gray-100 rounded">
                        {day}
                      </div>
                    ))}
                  </div>
                  
                  {/* Generate calendar days */}
                  <div className="grid grid-cols-7 gap-2">
                    {generateCalendarDays(selectedPlan).map((day, index) => (
                      <div
                        key={index}
                        className={`p-2 min-h-[80px] border rounded cursor-pointer transition-colors ${
                          day.isTrainingDay 
                            ? 'bg-blue-50 border-blue-200 hover:bg-blue-100' 
                            : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                        }`}
                        onClick={() => {
                          if (day.isTrainingDay) {
                            setSelectedDate(format(day.fullDate, 'yyyy-MM-dd'));
                            setShowSessionDialog(true);
                          }
                        }}
                      >
                        <div className="text-sm font-medium">{day.date}</div>
                        {day.isTrainingDay && (
                          <div className="mt-1">
                            <div className="text-xs bg-blue-100 px-2 py-1 rounded">
                              Training
                            </div>
                            <div className="text-xs text-blue-600 mt-1">
                              Klik voor IADATABANK
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="calendar" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarDays className="h-5 w-5" />
                    Training Kalender
                  </CardTitle>
                  <CardDescription>
                    Gebruik de "Kalender" knop voor volledige kalenderfunctionaliteit
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <CalendarDays className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <h3 className="text-lg font-medium mb-2 text-gray-700">Kalender Beschikbaar</h3>
                    <p className="text-gray-500 mb-6">
                      Klik op de "Kalender" knop bovenaan voor:
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-md mx-auto text-left">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                        Ruime maandweergave
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        Thema's kiezen per datum
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                        Aanpassen en bewaren
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                        Verwijderen en toevoegen
                      </div>
                    </div>
                    <Button 
                      className="mt-6"
                      onClick={() => {
                        console.log('Opening full calendar from tab...');
                        setShowFullCalendar(true);
                      }}
                    >
                      <CalendarDays className="h-4 w-4 mr-2" />
                      PLAN IN
                    </Button>
                  </div>
                  

                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="iadatabank" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Selecteer uw thema's
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={() => setShowSessionDialog(true)}
                    className="w-full"
                  >
                    Open IADATABANK Selectie
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )}

      {/* IADATABANK Session Dialog */}
      {showSessionDialog && selectedPlan && (
        <Dialog open={showSessionDialog} onOpenChange={setShowSessionDialog}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                IADATABANK Elementen - {selectedPlan.name}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Dynamische IADATABANK Categorieën */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Selecteer IADATABANK Elementen</h3>
                
                {/* Filter Buttons */}
                <div className="flex flex-wrap gap-2 mb-6">
                  <Button
                    variant={selectedIACategory === "" ? "default" : "outline"}
                    onClick={() => setSelectedIACategory("")}
                    size="sm"
                  >
                    Alle ({iadatabankElements.length})
                  </Button>
                  {[
                    { key: 'BASICS', display: "BASICS", color: "bg-blue-500" },
                    { key: 'TEAMTACTISCH', display: "TEAMTACTISCH", color: "bg-green-500" },
                    { key: 'OMSCHAKELING', display: "OMSCHAKELING", color: "bg-orange-500" },
                    { key: 'MENTAAL', display: "MENTAAL", color: "bg-purple-500" },
                    { key: 'FYSIEK', display: "FYSIEK", color: "bg-red-500" }
                  ].map((topic) => (
                    <Button
                      key={topic.key}
                      variant={selectedIACategory === topic.key ? "default" : "outline"}
                      onClick={() => setSelectedIACategory(topic.key)}
                      size="sm"
                      className="flex items-center gap-2"
                    >
                      <div className={`w-3 h-3 ${topic.color} rounded-full`}></div>
                      {topic.display} ({iadatabankElements.filter(el => el.topic === topic.key).length})
                    </Button>
                  ))}
                </div>

                {/* Elements Grid - Show all elements directly */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(() => {
                    const filteredElements = selectedIACategory === "" 
                      ? iadatabankElements 
                      : iadatabankElements.filter(el => el.topic === selectedIACategory);
                    
                    return filteredElements.map((element) => {
                      const isSelected = selectedCategoryElements[element.topic]?.includes(element.id) || false;
                      
                      const getTopicColor = (topic: string) => {
                        switch (topic.toLowerCase()) {
                          case 'basics': return 'bg-blue-100 text-blue-800 border-blue-200';
                          case 'teamtactisch': return 'bg-green-100 text-green-800 border-green-200';
                          case 'mentaal': return 'bg-purple-100 text-purple-800 border-purple-200';
                          case 'fysiek': return 'bg-orange-100 text-orange-800 border-orange-200';
                          case 'omschakeling': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
                          default: return 'bg-gray-100 text-gray-800 border-gray-200';
                        }
                      };

                      return (
                        <Card 
                          key={element.id} 
                          className={`cursor-pointer transition-all hover:shadow-lg ${
                            isSelected ? 'ring-2 ring-primary shadow-lg bg-primary/5' : ''
                          }`}
                          onClick={() => {
                            setSelectedCategoryElements(prev => {
                              const categoryElements = prev[element.topic] || [];
                              const isCurrentlySelected = categoryElements.includes(element.id);
                              
                              if (isCurrentlySelected) {
                                return {
                                  ...prev,
                                  [element.topic]: categoryElements.filter(id => id !== element.id)
                                };
                              } else {
                                return {
                                  ...prev,
                                  [element.topic]: [...categoryElements, element.id]
                                };
                              }
                            });
                          }}
                        >
                          <CardHeader className="pb-3">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-sm font-semibold mb-2 line-clamp-2">
                                  {element.name}
                                </CardTitle>
                                <div className="flex items-center gap-2 mb-2">
                                  <Badge variant="outline" className={getTopicColor(element.topic)}>
                                    {element.topic}
                                  </Badge>
                                  {isSelected && (
                                    <Badge variant="default" className="bg-green-500">
                                      Geselecteerd
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                            {element.subtopic && (
                              <Badge variant="secondary" className="text-xs w-fit">
                                {element.subtopic}
                              </Badge>
                            )}
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="space-y-3">
                              <div>
                                <p className="text-sm font-medium text-gray-700 mb-1">Thema:</p>
                                <p className="text-sm text-gray-600">{element.theme}</p>
                              </div>
                              
                              {element.progressions && element.progressions.length > 0 && (
                                <div>
                                  <p className="text-sm font-medium text-gray-700 mb-2">
                                    Niveaus ({element.progressions.length}):
                                  </p>
                                  <div className="space-y-2">
                                    {element.progressions.slice(0, 2).map((progression, index) => (
                                      <div key={index} className="text-xs bg-gray-50 p-2 rounded">
                                        <div className="flex items-center justify-between mb-1">
                                          <span className="font-medium">Niveau {progression.level}</span>
                                          <div className="flex">
                                            {Array.from({ length: progression.difficulty }, (_, i) => (
                                              <div key={i} className="w-2 h-2 bg-yellow-400 rounded-full mr-1"></div>
                                            ))}
                                          </div>
                                        </div>
                                        <p className="font-medium text-gray-800">{progression.name}</p>
                                        <p className="text-gray-600 mt-1">{progression.description}</p>
                                      </div>
                                    ))}
                                    {element.progressions.length > 2 && (
                                      <p className="text-xs text-gray-500 text-center">
                                        +{element.progressions.length - 2} meer niveaus...
                                      </p>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      );
                    });
                  })()}
                </div>

                {/* Selected Elements Summary */}
                <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">Geselecteerde Elementen:</h4>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(selectedCategoryElements).map(([category, elementIds]) => 
                      elementIds.map(elementId => {
                        const element = iadatabankElements.find(el => el.id === elementId);
                        return element ? (
                          <Badge key={elementId} variant="secondary" className="bg-green-100 text-green-800">
                            {element.name} ({element.topic})
                          </Badge>
                        ) : null;
                      })
                    )}
                  </div>
                  {Object.values(selectedCategoryElements).flat().length === 0 && (
                    <p className="text-sm text-green-600">Geen elementen geselecteerd</p>
                  )}
                </div>

                {/* Save Button */}
                <div className="flex justify-end mt-6">
                  <Button
                    onClick={() => {
                      // Save the selected elements for the training plan
                      const allSelectedElements = Object.values(selectedCategoryElements).flat();
                      if (allSelectedElements.length > 0) {
                        toast({ 
                          title: "Elementen Opgeslagen", 
                          description: `${allSelectedElements.length} IADATABANK elementen toegevoegd aan trainingsplan` 
                        });
                        setShowSessionDialog(false);
                      } else {
                        toast({ 
                          title: "Geen Selectie", 
                          description: "Selecteer minimaal één element om op te slaan",
                          variant: "destructive"
                        });
                      }
                    }}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Opslaan ({Object.values(selectedCategoryElements).flat().length} elementen)
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Full Calendar Dialog */}
      {showFullCalendar && selectedPlan && (
        <Dialog open={showFullCalendar} onOpenChange={setShowFullCalendar}>
          <DialogContent className="max-w-7xl max-h-[95vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5" />
                Volledige Kalender - {selectedPlan.name}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <TrainingCalendar 
                selectedPlan={selectedPlan}
                iadatabankElements={iadatabankElements}
                onMonthChange={(date) => setCalendarMonth(date)}
                onDateClick={(date, isTraining, isCurrentMonth) => {
                  console.log(`Clicked: ${date}, IsTraining: ${isTraining}, IsCurrentMonth: ${isCurrentMonth}`);
                  if (isTraining && isCurrentMonth) {
                    setSelectedDate(date);
                    setShowSessionDialog(true);
                    setShowFullCalendar(false);
                  }
                }}
              />
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
