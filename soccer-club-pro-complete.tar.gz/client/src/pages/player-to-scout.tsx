import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { Target, User, Mail, Phone, ArrowRight } from "lucide-react";

interface Player {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: string;
  position?: string;
  teamName: string;
  nationality?: string;
  address?: string;
  isScoutCandidate?: boolean;
}

interface ScoutFormData {
  scoutPriority: string;
  scoutStatus: string;
  scoutNotes?: string;
  overallRating?: number;
  technicalSkills?: number;
  physicalAttributes?: number;
  mentalStrength?: number;
  potential?: number;
  height?: number;
  weight?: number;
  preferredFoot?: string;
  contractStatus?: string;
  marketValue?: number;
  videoLinks?: string;
  nextContactDate?: string;
}

const scoutFormSchema = z.object({
  scoutPriority: z.enum(["low", "medium", "high", "urgent"]),
  scoutStatus: z.enum(["prospect", "contacted", "interested", "declined", "signed"]),
  scoutNotes: z.string().optional(),
  overallRating: z.number().min(1).max(10).optional(),
  technicalSkills: z.number().min(1).max(10).optional(),
  physicalAttributes: z.number().min(1).max(10).optional(),
  mentalStrength: z.number().min(1).max(10).optional(),
  potential: z.number().min(1).max(10).optional(),
  height: z.number().optional(),
  weight: z.number().optional(),
  preferredFoot: z.enum(["left", "right", "both"]).optional(),
  contractStatus: z.string().optional(),
  marketValue: z.number().optional(),
  videoLinks: z.string().optional(),
  nextContactDate: z.string().optional(),
});

function PlayerCard({ player, onAssignToScout }: { 
  player: Player; 
  onAssignToScout: (player: Player) => void;
}) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg font-semibold">
              {player.firstName} {player.lastName}
            </CardTitle>
            <p className="text-sm text-muted-foreground">{player.position} • {player.teamName}</p>
          </div>
          <Badge variant="outline">Scout Kandidaat</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {player.email && (
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-blue-500" />
              <span className="text-sm">{player.email}</span>
            </div>
          )}
          {player.phone && (
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-green-500" />
              <span className="text-sm">{player.phone}</span>
            </div>
          )}
          {player.nationality && (
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-orange-500" />
              <span className="text-sm">{player.nationality}</span>
            </div>
          )}
        </div>
        <div className="flex justify-end mt-4">
          <Button 
            variant="default" 
            size="sm" 
            onClick={() => onAssignToScout(player)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <ArrowRight className="h-4 w-4 mr-2" />
            Naar Scout Database
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function ScoutAssignmentForm({ player, onSubmit, onClose }: {
  player: Player;
  onSubmit: (data: ScoutFormData) => void;
  onClose: () => void;
}) {
  const form = useForm<ScoutFormData>({
    resolver: zodResolver(scoutFormSchema),
    defaultValues: {
      scoutPriority: "medium",
      scoutStatus: "prospect",
      scoutNotes: "",
      overallRating: undefined,
      technicalSkills: undefined,
      physicalAttributes: undefined,
      mentalStrength: undefined,
      potential: undefined,
      height: undefined,
      weight: undefined,
      preferredFoot: undefined,
      contractStatus: "",
      marketValue: undefined,
      videoLinks: "",
      nextContactDate: "",
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-semibold mb-2">Speler Informatie</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Naam:</span> {player.firstName} {player.lastName}
            </div>
            <div>
              <span className="font-medium">Team:</span> {player.teamName}
            </div>
            <div>
              <span className="font-medium">Positie:</span> {player.position || "Onbekend"}
            </div>
            <div>
              <span className="font-medium">Nationaliteit:</span> {player.nationality || "Onbekend"}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="scoutPriority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Scout Prioriteit</FormLabel>
                <FormControl>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Laag</SelectItem>
                      <SelectItem value="medium">Gemiddeld</SelectItem>
                      <SelectItem value="high">Hoog</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="scoutStatus"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Scout Status</FormLabel>
                <FormControl>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="prospect">Prospect</SelectItem>
                      <SelectItem value="contacted">Gecontacteerd</SelectItem>
                      <SelectItem value="interested">Geïnteresseerd</SelectItem>
                      <SelectItem value="declined">Afgewezen</SelectItem>
                      <SelectItem value="signed">Getekend</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-5 gap-4">
          <FormField
            control={form.control}
            name="overallRating"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Overall (1-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1" 
                    max="10" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="technicalSkills"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Techniek (1-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1" 
                    max="10" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="physicalAttributes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Fysiek (1-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1" 
                    max="10" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="mentalStrength"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Mentaal (1-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1" 
                    max="10" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="potential"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Potentieel (1-10)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1" 
                    max="10" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="height"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Lengte (cm)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="weight"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Gewicht (kg)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="preferredFoot"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Voorkeursvoet</FormLabel>
                <FormControl>
                  <Select value={field.value || ""} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer voet" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="left">Links</SelectItem>
                      <SelectItem value="right">Rechts</SelectItem>
                      <SelectItem value="both">Beide</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="contractStatus"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contract Status</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="marketValue"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Marktwaarde (€)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="videoLinks"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Video Links</FormLabel>
              <FormControl>
                <Textarea placeholder="URL's gescheiden door nieuwe regels" {...field} />
              </FormControl>
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="nextContactDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Volgende Contact Datum</FormLabel>
              <FormControl>
                <Input type="date" {...field} />
              </FormControl>
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="scoutNotes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Scout Notities</FormLabel>
              <FormControl>
                <Textarea placeholder="Voeg scout notities toe..." {...field} />
              </FormControl>
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onClose}>
            Annuleren
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            Toevoegen aan Scout Database
          </Button>
        </div>
      </form>
    </Form>
  );
}

export default function PlayerToScout() {
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const queryClient = useQueryClient();

  // Get playerId from URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const playerIdFromUrl = urlParams.get('playerId');

  const { data: playersData = [], isLoading } = useQuery<Player[]>({
    queryKey: ["/api/players"],
    select: (data) => {
      console.log('All players data:', data.length);
      // If playerId in URL, find that specific player, otherwise show all non-scout players
      if (playerIdFromUrl) {
        const specificPlayer = data.find((p: Player) => p.id === parseInt(playerIdFromUrl));
        console.log('Found specific player for scout conversion:', specificPlayer);
        if (specificPlayer) {
          // Auto-open form for the specific player
          setTimeout(() => {
            setSelectedPlayer(specificPlayer);
            setIsFormOpen(true);
          }, 100);
          return [specificPlayer];
        }
      }
      // Return all players that are NOT already scout candidates
      return data.filter((player: Player) => !player.isScoutCandidate);
    },
  });

  const assignToScoutMutation = useMutation({
    mutationFn: async (data: { playerData: Player; scoutData: ScoutFormData }) => {
      console.log('Sending scout data:', data);
      const token = localStorage.getItem('authToken');
      const response = await fetch("/api/player-to-scout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token && { Authorization: `Bearer ${token}` }),
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const errorData = await response.text();
        console.error('Scout conversion error:', errorData);
        throw new Error(`Failed to convert player to scout: ${response.status} ${errorData}`);
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      console.log('Scout conversion successful:', result);
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scout-database"] });
      setIsFormOpen(false);
      setSelectedPlayer(null);
    },
    onError: (error) => {
      console.error('Scout conversion mutation error:', error);
    },
  });

  const onSubmit = (data: ScoutFormData) => {
    if (selectedPlayer) {
      assignToScoutMutation.mutate({
        playerData: selectedPlayer,
        scoutData: data,
      });
    }
  };

  const handleAssignToScout = (player: Player) => {
    setSelectedPlayer(player);
    setIsFormOpen(true);
  };

  if (isLoading) {
    return <div className="p-6">Loading...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Spelers naar Scout Database</h1>
        <p className="text-muted-foreground">
          Converteer spelers naar scout kandidaten voor scouting analyse en tracking
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{playersData.length}</div>
            <div className="text-sm text-muted-foreground">Scout Kandidaten</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              {Array.from(new Set(playersData.map((p: Player) => p.teamName))).length}
            </div>
            <div className="text-sm text-muted-foreground">Teams</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              {Array.from(new Set(playersData.map((p: Player) => p.position))).length}
            </div>
            <div className="text-sm text-muted-foreground">Posities</div>
          </CardContent>
        </Card>
      </div>

      {/* Players Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {playersData.map((player: Player) => (
          <PlayerCard
            key={player.id}
            player={player}
            onAssignToScout={handleAssignToScout}
          />
        ))}
      </div>

      {playersData.length === 0 && (
        <div className="text-center py-12">
          <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Geen scout kandidaten gevonden</h3>
          <p className="text-gray-500">
            Markeer spelers als scout kandidaten in de Players Database om ze hier te zien.
          </p>
        </div>
      )}

      {/* Assignment Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Speler Toewijzen aan Scout Database
            </DialogTitle>
            <DialogDescription>
              Voeg scout informatie toe voor {selectedPlayer?.firstName} {selectedPlayer?.lastName}
            </DialogDescription>
          </DialogHeader>
          {selectedPlayer && (
            <ScoutAssignmentForm
              player={selectedPlayer}
              onSubmit={onSubmit}
              onClose={() => setIsFormOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}