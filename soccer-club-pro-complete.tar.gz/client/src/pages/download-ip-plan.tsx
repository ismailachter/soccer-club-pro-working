import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Download, Mail } from "lucide-react";

export default function DownloadIPPlan() {
  const handleDownload = () => {
    // Direct download of the IP plan PDF
    window.open('/api/year-plans/17/export/pdf', '_blank');
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <Card className="bg-gradient-to-br from-blue-50 to-white border-blue-200">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
            <FileText className="w-8 h-8 text-blue-600" />
          </div>
          <CardTitle className="text-2xl text-blue-800">
            VVC Brasschaat - Dames InterProvinciaal
          </CardTitle>
          <CardDescription className="text-lg">
            Jaarplanning 2025-2026 - Volledig Overzicht
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="bg-white p-4 rounded-lg border border-blue-100">
            <h3 className="font-semibold text-blue-800 mb-3">Plan Details:</h3>
            <ul className="space-y-2 text-sm">
              <li><strong>Team:</strong> Dames InterProvinciaal</li>
              <li><strong>Seizoen:</strong> 2025-2026</li>
              <li><strong>Totaal trainingen:</strong> 92 sessies</li>
              <li><strong>Format:</strong> Professionele PDF met verbeterde thema weergave</li>
            </ul>
          </div>

          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <h3 className="font-semibold text-green-800 mb-3">Nieuwe verbeteringen:</h3>
            <ul className="space-y-1 text-sm text-green-700">
              <li>✓ Complete training schema's met exacte tijden (20:00 - 21:45)</li>
              <li>✓ Alle IADATABANK thema's volledig zichtbaar</li>
              <li>✓ VARIA opmerkingen voor wedstrijden volledig weergegeven</li>
              <li>✓ Professionele layout met training boxes</li>
              <li>✓ Chronologische sortering van alle sessies</li>
            </ul>
          </div>

          <div className="flex flex-col gap-3">
            <Button 
              onClick={handleDownload}
              className="bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
              size="lg"
            >
              <Download className="w-5 h-5 mr-2" />
              Download IP Jaarplanning PDF
            </Button>
            
            <p className="text-sm text-gray-600 text-center">
              Na download kun je het PDF bestand doormailen naar jezelf of anderen.
              Het bestand bevat alle 92 training sessies met volledige thema details.
            </p>
          </div>

          <div className="border-t pt-4">
            <p className="text-xs text-gray-500 text-center">
              Gegenereerd door Soccer Club Pro - Professioneel voetbal management platform
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}