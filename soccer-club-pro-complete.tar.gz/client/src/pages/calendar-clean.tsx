import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { EmailShareDialog } from "@/components/EmailShareDialog";
import { Link } from "wouter";
import { ArrowLeft, ChevronLeft, ChevronRight, Calendar, Download, X, Target, Users, Brain, Zap, Search, Plus, Clock, FileSpreadsheet, Share } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  season: string;
  startDate: string;
  endDate: string;
  trainingDays: any;
  status: "draft" | "active" | "completed";
}

// SearchResults component for live search
function SearchResults({ query, data, onSelectElement, onSelectCategory, onSelectTheme }: {
  query: string;
  data: any;
  onSelectElement: (element: any) => void;
  onSelectCategory: (category: string) => void;
  onSelectTheme: (theme: string) => void;
}) {
  const elements = data?.data || [];
  
  // Search through elements
  const matchingElements = elements.filter((el: any) => 
    el.name?.toLowerCase().includes(query.toLowerCase()) ||
    el.topic?.toLowerCase().includes(query.toLowerCase()) ||
    el.theme?.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 10);

  // Search through categories
  const categories = ['BASICS', 'TEAMTACTISCH', 'FYSIEK', 'MENTAAL'];
  const matchingCategories = categories.filter(cat => 
    cat.toLowerCase().includes(query.toLowerCase())
  );

  // Search through themes
  const themes = [...new Set(elements.map((el: any) => el.theme).filter(Boolean))];
  const matchingThemes = themes.filter((theme: string) => 
    theme.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 5);

  if (matchingElements.length === 0 && matchingCategories.length === 0 && matchingThemes.length === 0) {
    return (
      <div className="p-4 text-center text-gray-500">
        Geen resultaten gevonden voor "{query}"
      </div>
    );
  }

  return (
    <div className="p-2">
      {/* Categories */}
      {matchingCategories.length > 0 && (
        <div className="mb-3">
          <h6 className="text-xs font-semibold text-purple-600 mb-1 px-2">CATEGORIEËN</h6>
          {matchingCategories.map(category => (
            <button
              key={category}
              onClick={() => onSelectCategory(category)}
              className="w-full text-left px-3 py-2 hover:bg-purple-50 rounded flex items-center gap-2"
            >
              <Target className="h-4 w-4 text-purple-500" />
              <span className="text-sm font-medium">{category}</span>
              <span className="text-xs text-gray-500 ml-auto">Categorie</span>
            </button>
          ))}
        </div>
      )}

      {/* Themes */}
      {matchingThemes.length > 0 && (
        <div className="mb-3">
          <h6 className="text-xs font-semibold text-green-600 mb-1 px-2">THEMA'S</h6>
          {matchingThemes.map(theme => (
            <button
              key={theme}
              onClick={() => onSelectTheme(theme)}
              className="w-full text-left px-3 py-2 hover:bg-green-50 rounded flex items-center gap-2"
            >
              <Users className="h-4 w-4 text-green-500" />
              <span className="text-sm">{theme}</span>
              <span className="text-xs text-gray-500 ml-auto">Thema</span>
            </button>
          ))}
        </div>
      )}

      {/* Elements */}
      {matchingElements.length > 0 && (
        <div>
          <h6 className="text-xs font-semibold text-blue-600 mb-1 px-2">ELEMENTEN</h6>
          {matchingElements.map((element: any) => (
            <button
              key={element.id}
              onClick={() => onSelectElement(element)}
              className="w-full text-left px-3 py-2 hover:bg-blue-50 rounded"
            >
              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <div className="text-sm font-medium">{element.name}</div>
                  <div className="text-xs text-gray-500">
                    {element.topic} • {element.theme}
                  </div>
                </div>
                <span className="text-xs text-gray-400">Element</span>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Email Share Dialog */}
      <EmailShareDialog
        open={showEmailDialog}
        onOpenChange={setShowEmailDialog}
        planId={parseInt(planId)}
        planName={yearPlanDetails?.name || 'Jaarplan'}
      />
    </div>
  );
}

export default function CalendarClean(props: any) {
  const planId = props.params?.planId; // Get planId from URL params
  const queryClient = useQueryClient();
  const [currentDate, setCurrentDate] = useState(new Date(2025, 6, 1)); // Start at July 1, 2025

  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedActivityType, setSelectedActivityType] = useState<string>('training');
  const [trainingStartTime, setTrainingStartTime] = useState('20:00');
  const [trainingEndTime, setTrainingEndTime] = useState('21:45');
  const [activityNotes, setActivityNotes] = useState<string>(''); // For VARIA activity notes
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [selectedSubtopic, setSelectedSubtopic] = useState<string>("");
  const [selectedTheme, setSelectedTheme] = useState<string>("");
  const [selectedElement, setSelectedElement] = useState<string>("");
  const [selectedElements, setSelectedElements] = useState<any[]>([]);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedSubcategories, setSelectedSubcategories] = useState<string[]>([]);
  const [selectedYearPlan, setSelectedYearPlan] = useState<number | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showDetailedSummary, setShowDetailedSummary] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [showThemeDialog, setShowThemeDialog] = useState(false);
  const [showTimeDialog, setShowTimeDialog] = useState(false);
  const [showActivityDialog, setShowActivityDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [sessionToDelete, setSessionToDelete] = useState<any>(null);
  const [sessionToEdit, setSessionToEdit] = useState<any>(null);
  const [showEmailDialog, setShowEmailDialog] = useState(false);

  const handleDirectDownload = async () => {
    try {
      const response = await fetch(`/api/year-plans/${selectedYearPlan}/export/pdf`);
      const blob = await response.blob();
      
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = 'VVC-Brasschaat-IP-Jaarplanning-2025-2026.pdf';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "PDF Downloaded",
        description: "IP jaarplan (165KB) gedownload. Email naar ismail.achter@gmail.com als bijlage.",
        duration: 5000,
      });
    } catch (error) {
      toast({
        title: "Download Error",
        description: "Er ging iets mis bij het downloaden",
        variant: "destructive"
      });
    }
  };

  // Update session function - complete edit with date, time, notes
  const handleUpdateSessionTime = async () => {
    if (!sessionToEdit || !selectedYearPlan || !selectedDate) {
      console.error('No session to edit, year plan selected, or date selected');
      return;
    }

    try {
      const updateData = {
        date: format(selectedDate, 'yyyy-MM-dd'),
        startTime: trainingStartTime,
        endTime: trainingEndTime,
        notes: activityNotes
      };

      console.log('CRITICAL - Updating SPECIFIC session:', {
        sessionId: sessionToEdit.id,
        sessionDetails: sessionToEdit,
        updateData,
        apiUrl: `/api/year-plans/${selectedYearPlan}/sessions/${sessionToEdit.id}`
      });

      const response = await fetch(`/api/year-plans/${selectedYearPlan}/sessions/${sessionToEdit.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updateData),
      });

      if (response.ok) {
        const updatedSession = await response.json();
        console.log('Session updated successfully:', updatedSession);
        
        toast({
          title: "Training bijgewerkt",
          description: `Nieuwe tijd: ${trainingStartTime} - ${trainingEndTime}`,
        });
        
        // Close dialog and reset
        setShowEditDialog(false);
        setSessionToEdit(null);
        setActivityNotes('');
        
        // Force immediate refresh of all session data
        await Promise.all([
          // Invalidate React Query cache
          queryClient.invalidateQueries({ queryKey: ['/api/year-plans', selectedYearPlan, 'sessions'] }),
          queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] }),
          
          // Force direct fetch to update state immediately
          fetch(`/api/year-plans/${selectedYearPlan}/sessions`)
            .then(res => res.json())
            .then(sessions => {
              console.log('IMMEDIATE REFRESH: Updated sessions loaded:', sessions.length);
              setDirectSessions(sessions);
              
              // Force component re-render by updating current date
              setCurrentDate(new Date(currentDate.getTime()));
            })
        ]);
        
      } else {
        const errorData = await response.text();
        throw new Error(`Failed to update session: ${errorData}`);
      }
    } catch (error) {
      console.error('Error updating session:', error);
      toast({
        title: "Fout bij bijwerken",
        description: error instanceof Error ? error.message : "Kon training niet bijwerken",
        variant: "destructive"
      });
    }
  };

  // PDF Export functionality
  const handlePDFExport = async () => {
    if (!selectedYearPlan) {
      toast({
        title: "Geen jaarplan geselecteerd",
        description: "Selecteer eerst een jaarplan voor export",
        variant: "destructive"
      });
      return;
    }

    try {
      const response = await fetch(`/api/year-plans/${selectedYearPlan}/export/pdf`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `jaarplan-${selectedYearPlan}-maandkalender.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({
          title: "PDF Export Succesvol",
          description: "Maandkalender PDF is gedownload",
        });
      } else {
        throw new Error('PDF export failed');
      }
    } catch (error) {
      console.error('PDF export error:', error);
      toast({
        title: "PDF Export Fout",
        description: "Kon PDF niet genereren",
        variant: "destructive"
      });
    }
  };

  // Excel Export functionality
  const handleExcelExport = async () => {
    if (!selectedYearPlan) {
      toast({
        title: "Geen jaarplan geselecteerd",
        description: "Selecteer eerst een jaarplan voor export",
        variant: "destructive"
      });
      return;
    }

    try {
      const response = await fetch(`/api/year-plans/${selectedYearPlan}/export/excel`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `jaarplan-${selectedYearPlan}-trainingen.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({
          title: "Excel Export Succesvol",
          description: "Training overzicht Excel is gedownload",
        });
      } else {
        throw new Error('Excel export failed');
      }
    } catch (error) {
      console.error('Excel export error:', error);
      toast({
        title: "Excel Export Fout",
        description: "Kon Excel niet genereren",
        variant: "destructive"
      });
    }
  };

  // Bulk update all IP training times to 20:00-21:45
  const handleBulkTimeUpdate = async () => {
    if (!selectedYearPlan) {
      toast({
        title: "Geen jaarplan geselecteerd",
        description: "Selecteer eerst een jaarplan",
        variant: "destructive"
      });
      return;
    }

    const confirmUpdate = window.confirm(
      "Weet je zeker dat je ALLE trainingen in dit jaarplan wilt bijwerken naar 20:00-21:45?"
    );

    if (!confirmUpdate) return;

    try {
      const response = await fetch(`/api/year-plans/${selectedYearPlan}/sessions/bulk-update-times`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          startTime: '20:00',
          endTime: '21:45'
        }),
      });

      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Alle trainingen bijgewerkt",
          description: `${result.updatedCount} trainingen nu 20:00-21:45`,
        });
        
        // Force refresh calendar
        await fetch(`/api/year-plans/${selectedYearPlan}/sessions`)
          .then(res => res.json())
          .then(sessions => {
            console.log('Bulk update: refreshed sessions:', sessions.length);
            setDirectSessions(sessions);
            setCurrentDate(new Date(currentDate.getTime()));
          });
          
      } else {
        throw new Error('Failed to bulk update times');
      }
    } catch (error) {
      console.error('Bulk time update error:', error);
      toast({
        title: "Fout bij bulk update",
        description: "Kon training tijden niet bijwerken",
        variant: "destructive"
      });
    }
  };

  // Debug logging for selected items
  useEffect(() => {
    console.log("Selected items state update:");
    console.log("- Categories:", selectedCategories);
    console.log("- Subcategories:", selectedSubcategories);
    console.log("- Themes:", selectedThemes);
    console.log("- Elements:", selectedElements);
    console.log("- Total selected items:", selectedCategories.length + selectedSubcategories.length + selectedThemes.length + selectedElements.length);
  }, [selectedCategories, selectedSubcategories, selectedThemes, selectedElements]);

  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);

  // Handle saving selection based on current level
  const handleSaveSelection = async () => {
    if (!selectedDate) return;
    
    // Show confirmation dialog first
    setShowConfirmation(true);
  };

  // Confirm and save the training
  const confirmSaveTraining = async () => {
    if (!selectedDate) return;
    
    setIsSaving(true);
    setShowConfirmation(false);
    
    try {
      // Determine which level we're saving
      let level = 'category';
      if (selectedCategories.length > 0) level = 'category';
      else if (selectedSubcategories.length > 0) level = 'subcategory';
      else if (selectedThemes.length > 0) level = 'theme';
      else if (selectedElements.length > 0) level = 'element';
      
      await handleSaveTraining(level);
      
      // Refresh sessions to show the new training
      await refetchSessions();
    } catch (error) {
      console.error('Error saving selection:', error);
      toast({ 
        title: "Fout bij opslaan", 
        description: "Er is een fout opgetreden bij het opslaan van de selectie.",
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Fetch data
  const { data: yearPlans = [], isLoading: isLoadingPlans } = useQuery({ 
    queryKey: ['/api/year-plans']
  });

  // Auto-select year plan based on URL parameter or first available
  useEffect(() => {
    if (yearPlans && Array.isArray(yearPlans) && yearPlans.length > 0 && !selectedYearPlan) {
      let planToSelect: YearPlan;
      
      if (planId) {
        // Try to find the plan by ID from URL
        const urlPlan = yearPlans.find((plan: YearPlan) => plan.id === parseInt(planId));
        if (urlPlan) {
          planToSelect = urlPlan;
          console.log('URL-selected year plan:', urlPlan.id, urlPlan.name);
        } else {
          planToSelect = yearPlans[0] as YearPlan;
          console.log('URL plan not found, fallback to first plan:', planToSelect.id, planToSelect.name);
        }
      } else {
        planToSelect = yearPlans[0] as YearPlan;
        console.log('No URL param, auto-selected first plan:', planToSelect.id, planToSelect.name);
      }
      
      setSelectedYearPlan(planToSelect.id);
    }
  }, [yearPlans, selectedYearPlan, planId]);

  // Get the specific year plan data
  const yearPlanData = yearPlans.find((plan: YearPlan) => plan.id === selectedYearPlan);

  const { data: iaDatabankData, isLoading: isLoadingIA } = useQuery({
    queryKey: ['/api/iadatabank/elements']
  });

  // Fetch training sessions for the selected year plan
  const { data: trainingSessions = [], refetch: refetchSessions } = useQuery({
    queryKey: ['/api/year-plans', selectedYearPlan, 'sessions'],
    enabled: !!selectedYearPlan,
    staleTime: 0,
    gcTime: 0
  });

  // Debug training sessions data 
  console.log('Training sessions loaded:', trainingSessions.length);
  
  // The API is returning year plans instead of training sessions - use direct fetch as workaround
  const [directSessions, setDirectSessions] = useState<any[]>([]);
  
  // Force calendar refresh when directSessions change
  useEffect(() => {
    if (directSessions.length > 0) {
      console.log('Calendar refreshing with', directSessions.length, 'sessions');
    }
  }, [directSessions]);
  
  useEffect(() => {
    if (selectedYearPlan) {
      fetch(`/api/year-plans/${selectedYearPlan}/sessions`)
        .then(res => res.json())
        .then(sessions => {
          console.log('Direct fetch sessions:', sessions.length, sessions.slice(0, 3));
          setDirectSessions(sessions);
        })
        .catch(err => console.error('Direct fetch error:', err));
    }
  }, [selectedYearPlan]);

  // REMOVED - Using immediate restore in handleDateClick instead

  // Theme definitions for calendar display
  const teamTacticsThemes = {
    'B+': [
      { id: 'opbouwen', name: 'Opbouwen', color: 'bg-blue-500' },
      { id: 'voortgang-infiltratie', name: 'Voortgang & Infiltratie', color: 'bg-green-500' },
      { id: 'scoren', name: 'Scoren', color: 'bg-red-500' }
    ],
    'B-': [
      { id: 'druk-zetten', name: 'Druk Zetten', color: 'bg-red-500' },
      { id: 'compact-verdedigen', name: 'Compact Verdedigen', color: 'bg-gray-500' },
      { id: 'beschermen-eigen-doel', name: 'Beschermen Eigen Doel', color: 'bg-purple-500' }
    ]
  };


  
  // Find sessions for July 21, 2025 using direct fetch
  const july21DirectSessions = directSessions.filter((s: any) => s.date === '2025-07-21');
  console.log('July 21 direct sessions found:', july21DirectSessions.length, july21DirectSessions);
  
  // Check for sessions with selectedItems for debugging
  const sessionsWithSelectedItems = directSessions.filter((s: any) => s.selectedItems && s.selectedItems.length > 0);
  console.log('Sessions with selectedItems:', sessionsWithSelectedItems.length, sessionsWithSelectedItems.map(s => ({id: s.id, date: s.date, selectedCount: s.selectedItems.length})));



  // Topic configuration for category tiles
  const topicConfig = {
    BASICS: {
      display: "BASICS",
      icon: Target,
      color: "bg-blue-500",
      bgColor: "bg-blue-100",
      textColor: "text-blue-800",
      borderColor: "border-blue-200"
    },
    TEAMTACTISCH: {
      display: "TEAMTACTISCH",
      icon: Users,
      color: "bg-green-500",
      bgColor: "bg-green-100",
      textColor: "text-green-800",
      borderColor: "border-green-200"
    },
    FYSIEK: {
      display: "FYSIEK",
      icon: Zap,
      color: "bg-orange-500",
      bgColor: "bg-orange-100",
      textColor: "text-orange-800",
      borderColor: "border-orange-200"
    },
    MENTAAL: {
      display: "MENTAAL",
      icon: Brain,
      color: "bg-purple-500",
      bgColor: "bg-purple-100",
      textColor: "text-purple-800",
      borderColor: "border-purple-200"
    },
    LINIE: {
      display: "LINIE",
      icon: Target,
      color: "bg-teal-500",
      bgColor: "bg-teal-100",
      textColor: "text-teal-800",
      borderColor: "border-teal-200"
    },
    INDIVIDUEEL: {
      display: "INDIVIDUEEL",
      icon: Users,
      color: "bg-rose-500",
      bgColor: "bg-rose-100",
      textColor: "text-rose-800",
      borderColor: "border-rose-200"
    },
    VARIA: {
      display: "VARIA",
      icon: Calendar,
      color: "bg-indigo-500",
      bgColor: "bg-indigo-100",
      textColor: "text-indigo-800",
      borderColor: "border-indigo-200"
    }
  };

  // BASICS themes configuration - Authentieke thema's uit IADATABANK
  const basicsThemes = {
    "B+": [
      { id: "leiden", name: "Leiden van de bal", color: "bg-blue-500" },
      { id: "dribbelen", name: "Dribbelen met de bal", color: "bg-blue-600" },
      { id: "passing", name: "Passing", color: "bg-blue-400" },
      { id: "balcontrole", name: "Balcontrole", color: "bg-blue-700" },
      { id: "schieten", name: "Schieten/Scoren", color: "bg-blue-300" },
      { id: "vrijlopen", name: "Vrijlopen", color: "bg-blue-800" },
      { id: "steun", name: "Steun teamgenoot", color: "bg-blue-200" }
    ],
    "B-": [
      { id: "druk_zetten", name: "Druk zetten/Tackle", color: "bg-red-500" },
      { id: "duel", name: "Duel", color: "bg-red-600" },
      { id: "interceptie", name: "Interceptie", color: "bg-red-400" },
      { id: "afweren", name: "Afweren/Beletten", color: "bg-red-700" },
      { id: "speelhoeken", name: "Speelhoeken afsluiten", color: "bg-red-300" },
      { id: "dekking", name: "Dekking", color: "bg-red-800" }
    ]
  };

  // TEAMTACTICS themes configuration
  const teamtacticsThemes = {
    "B+": [
      { id: "opbouwen", name: "Opbouwen", color: "bg-blue-500" },
      { id: "voortgang_infiltratie", name: "Voortgang & Infiltratie", color: "bg-green-500" },
      { id: "scoren", name: "Scoren", color: "bg-yellow-500" }
    ],
    "B-": [
      { id: "druk_zetten", name: "Druk Zetten", color: "bg-red-500" },
      { id: "compact_verdedigen", name: "Compact Verdedigen", color: "bg-gray-500" },
      { id: "beschermen_eigen_doel", name: "Beschermen Eigen Doel", color: "bg-purple-500" }
    ],
    "OMSCH. B+/B-": [
      { id: "tegen_druk_zetten", name: "Tegen Druk Zetten", color: "bg-purple-500" },
      { id: "hervormen_opstelling", name: "Hervormen Opstelling", color: "bg-purple-600" }
    ],
    "OMSCH. B-/B+": [
      { id: "tegenaanval", name: "Tegenaanval", color: "bg-orange-500" },
      { id: "op_balbezit_spelen", name: "Op Balbezit Spelen", color: "bg-orange-600" }
    ]
  };

  // FYSIEK themes configuration
  const fysiekThemes = {
    "UITHOUDING": [
      { id: "cardio_training", name: "Cardio Training", color: "bg-orange-500" },
      { id: "aerobe_capacity", name: "Aerobe Capacity", color: "bg-orange-600" },
      { id: "intervaltraining", name: "Intervaltraining", color: "bg-orange-400" }
    ],
    "KRACHT": [
      { id: "core_stability", name: "Core Stability", color: "bg-red-500" },
      { id: "beenkracht", name: "Beenkracht", color: "bg-red-600" },
      { id: "explosieve_kracht", name: "Explosieve Kracht", color: "bg-red-400" }
    ],
    "SNELHEID": [
      { id: "sprint_training", name: "Sprint Training", color: "bg-yellow-500" },
      { id: "reactiesnelheid", name: "Reactiesnelheid", color: "bg-yellow-600" },
      { id: "wendbaarheid", name: "Wendbaarheid", color: "bg-yellow-400" }
    ],
    "LENIGHEID": [
      { id: "stretching", name: "Stretching", color: "bg-green-500" },
      { id: "mobiliteit", name: "Mobiliteit", color: "bg-green-600" },
      { id: "flexibiliteit", name: "Flexibiliteit", color: "bg-green-400" }
    ]
  };

  // MENTAAL themes configuration
  const mentaalThemes = {
    "ALGEMEEN MENTAAL": [
      { id: "concentratie_focus", name: "Concentratie & Focus", color: "bg-purple-500" },
      { id: "motivatie_zelfvertrouwen", name: "Motivatie & Zelfvertrouwen", color: "bg-purple-600" },
      { id: "teamwork_communicatie", name: "Teamwork & Communicatie", color: "bg-purple-400" },
      { id: "drukbeheersing_stress", name: "Drukbeheersing & Stress Management", color: "bg-purple-700" }
    ]
  };

  // OMSCHAKELING themes configuration  
  const omschakelingThemes = {
    "B-/B+": [
      { id: "tegenaanval", name: "Tegenaanval", color: "bg-orange-500" },
      { id: "op_balbezit_spelen", name: "Op Balbezit Spelen", color: "bg-orange-600" }
    ],
    "B+/B-": [
      { id: "tegen_druk_zetten", name: "Tegen Druk Zetten", color: "bg-purple-500" },
      { id: "hervormen_opstelling", name: "Hervormen Opstelling", color: "bg-purple-600" }
    ]
  };

  // VARIA themes configuration - Alle activiteiten
  const variaThemes = {
    "Activiteiten": [
      { id: "competitiewedstrijd", name: "Competitiewedstrijd", color: "bg-red-500" },
      { id: "oefenwedstrijd", name: "Oefenwedstrijd", color: "bg-yellow-500" },
      { id: "bekerwedstrijd", name: "Bekerwedstrijd", color: "bg-gold-500" },
      { id: "extra_training", name: "Extra Training", color: "bg-green-500" },
      { id: "video_training", name: "Video Training", color: "bg-blue-500" },
      { id: "teambuilding", name: "Teambuilding", color: "bg-purple-500" },
      { id: "fysieke_testen", name: "Fysieke Testen", color: "bg-orange-500" }
    ]
  };

  // Get theme configuration for any category
  const getThemeConfig = (topic: string, subtopic: string) => {
    switch (topic) {
      case 'BASICS':
        return basicsThemes[subtopic as keyof typeof basicsThemes] || [];
      case 'TEAMTACTISCH':
        return teamtacticsThemes[subtopic as keyof typeof teamtacticsThemes] || [];
      case 'FYSIEK':
        return fysiekThemes[subtopic as keyof typeof fysiekThemes] || [];
      case 'MENTAAL':
        return mentaalThemes[subtopic as keyof typeof mentaalThemes] || [];
      case 'VARIA':
        return variaThemes[subtopic as keyof typeof variaThemes] || [];
      default:
        return [];
    }
  };

  // Get theme name by ID across all categories
  const getThemeName = (themeId: string) => {
    // Search in all theme configurations
    const allThemes = [
      ...Object.values(basicsThemes).flat(),
      ...Object.values(teamtacticsThemes).flat(),
      ...Object.values(fysiekThemes).flat(),
      ...Object.values(mentaalThemes).flat(),
      ...Object.values(variaThemes).flat(),
      ...Object.values(omschakelingThemes).flat()
    ];
    
    const theme = allThemes.find(t => t.id === themeId);
    return theme || { id: themeId, name: themeId, color: 'bg-gray-500' };
  };

  // Filter elements based on selected topic and subtopic
  const getFilteredElements = () => {
    const data = (iaDatabankData as any)?.data;
    
    if (!data || !Array.isArray(data)) {
      return [];
    }
    
    return data.filter((element: any) => {
      const matchesTopic = selectedTopic === "" || element.topic === selectedTopic;
      const matchesSubtopic = selectedSubtopic === "" || element.subtopic === selectedSubtopic;
      
      // For TEAMTACTICS, also filter by selected theme using authentic theme matching
      if (selectedTopic === "TEAMTACTISCH" && selectedTheme) {
        // Find theme details from teamtacticsThemes
        let themeDetails = null;
        
        if (selectedSubtopic && teamtacticsThemes[selectedSubtopic as keyof typeof teamtacticsThemes]) {
          themeDetails = teamtacticsThemes[selectedSubtopic as keyof typeof teamtacticsThemes].find(
            (theme: any) => theme.id === selectedTheme
          );
        }
        
        if (themeDetails) {
          // Direct theme name matching for all TEAMTACTISCH elements
          const matchesTheme = element.theme === themeDetails.name;
          return matchesTopic && matchesSubtopic && matchesTheme;
        }
      }
      
      // For BASICS, FYSIEK, MENTAAL - theme filtering using name-based matching
      if ((selectedTopic === "BASICS" || selectedTopic === "FYSIEK" || selectedTopic === "MENTAAL") && selectedTheme) {
        let themeDetails = null;
        let themes = {};
        
        if (selectedTopic === "BASICS" && selectedSubtopic && basicsThemes[selectedSubtopic as keyof typeof basicsThemes]) {
          themes = basicsThemes;
        } else if (selectedTopic === "FYSIEK" && fysiekThemes[selectedSubtopic as keyof typeof fysiekThemes]) {
          themes = fysiekThemes;
        } else if (selectedTopic === "MENTAAL" && mentaalThemes[selectedSubtopic as keyof typeof mentaalThemes]) {
          themes = mentaalThemes;
        }
        
        if (selectedSubtopic && themes[selectedSubtopic as keyof typeof themes]) {
          themeDetails = themes[selectedSubtopic as keyof typeof themes].find(
            (theme: any) => theme.id === selectedTheme
          );
        }
        
        if (themeDetails) {
          // For all categories, try exact theme match first, then fallback to keyword matching
          if (element.theme === themeDetails.name) {
            return matchesTopic && matchesSubtopic;
          }
          
          // Keyword-based matching for BASICS
          if (selectedTopic === "BASICS") {
            const elementName = element.name?.toLowerCase() || '';
            let matchesTheme = false;
            
            switch (selectedTheme) {
              case "leiden":
                matchesTheme = elementName.includes("leiden");
                break;
              case "dribbelen":
                matchesTheme = elementName.includes("dribbelen");
                break;
              case "passing":
                matchesTheme = elementName.includes("passing") || elementName.includes("pass");
                break;
              case "balcontrole":
                matchesTheme = elementName.includes("balcontrole");
                break;
              case "schieten":
                matchesTheme = elementName.includes("schieten") || elementName.includes("scoren");
                break;
              case "vrijlopen":
                matchesTheme = elementName.includes("vrijlopen") || elementName.includes("aanspeelbaar");
                break;
              case "steun":
                matchesTheme = elementName.includes("steun") || elementName.includes("ingedraaid");
                break;
              case "druk_zetten":
                matchesTheme = elementName.includes("druk zetten") || elementName.includes("tackle") || elementName.includes("remmen");
                break;
              case "duel":
                matchesTheme = elementName.includes("duel");
                break;
              case "interceptie":
                matchesTheme = elementName.includes("interceptie");
                break;
              case "afweren":
                matchesTheme = elementName.includes("afweren") || elementName.includes("beletten");
                break;
              case "speelhoeken":
                matchesTheme = elementName.includes("speelhoeken");
                break;
              case "dekking":
                matchesTheme = elementName.includes("dekking");
                break;
              default:
                matchesTheme = false;
            }
            
            return matchesTopic && matchesSubtopic && matchesTheme;
          }
          
          // For FYSIEK and MENTAAL, use theme name matching
          return matchesTopic && matchesSubtopic && (element.theme === themeDetails.name);
        }
      }
      
      return matchesTopic && matchesSubtopic;
    });
  };

  // Get available subtopics for selected topic
  const getAvailableSubtopics = (topic: string) => {
    const data = (iaDatabankData as any)?.data;
    
    if (!data || !Array.isArray(data)) {
      return [];
    }
    
    const topicElements = data.filter((el: any) => el.topic === topic);
    const subtopics = Array.from(new Set(topicElements.map((el: any) => el.subtopic))).filter(Boolean);
    
    return (subtopics as string[]).sort((a, b) => {
      if (a === 'B+') return -1;
      if (b === 'B+') return 1;
      if (a === 'B-') return -1;
      if (b === 'B-') return 1;
      return a.localeCompare(b);
    });
  };

  // Date navigation
  const navigateMonth = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      setCurrentDate(subMonths(currentDate, 1));
    } else {
      setCurrentDate(addMonths(currentDate, 1));
    }
  };

  // Check if date is available for training (within plan period)
  const isDateAvailable = (date: Date) => {
    if (!selectedYearPlan || !yearPlanData) return false;
    
    // Check date range - enforce start and end dates
    if (yearPlanData.startDate && yearPlanData.endDate) {
      const planStart = parseISO(yearPlanData.startDate);
      const planEnd = parseISO(yearPlanData.endDate);
      const isInDateRange = date >= planStart && date <= planEnd;
      
      return isInDateRange;
    }
    
    return false; // No dates available if no plan dates set
  };

  // Handle date click - DIRECT RESTORE VERSION
  const handleDateClick = (clickedDate: Date) => {
    const available = isDateAvailable(clickedDate);
    
    if (!available) {
      return;
    }
    
    // Format clicked date immediately 
    const clickedDateString = format(clickedDate, 'yyyy-MM-dd');
    console.log('*** CLICKED DATE:', clickedDateString);
    
    // Clear selections first
    setSelectedElements([]);
    setSelectedCategories([]);
    setSelectedSubcategories([]);
    setSelectedThemes([]);
    setSelectedTopic("");
    setSelectedSubtopic("");
    setSelectedTheme("");
    setSelectedElement("");
    
    // Set the new date
    setSelectedDate(clickedDate);
    
    // Don't reset time for new sessions to preserve user input
    setActivityNotes('');
    
    // IMMEDIATE restore using the clicked date directly - FIND SESSION WITH SELECTED ITEMS
    if (directSessions.length > 0) {
      // Get ALL sessions for this date
      const sessionsForDate = directSessions.filter((s: any) => s.date === clickedDateString);
      console.log('*** ALL SESSIONS FOR DATE:', sessionsForDate.map(s => ({ id: s.id, selectedItems: s.selectedItems?.length || 0 })));
      
      // Find the session that has selectedItems
      const sessionWithSelectedItems = sessionsForDate.find((s: any) => s.selectedItems && s.selectedItems.length > 0);
      
      console.log('*** IMMEDIATE RESTORE for:', clickedDateString);
      console.log('*** SESSION WITH SELECTED ITEMS:', sessionWithSelectedItems?.id);
      
      if (sessionWithSelectedItems?.selectedItems && sessionWithSelectedItems.selectedItems.length > 0) {
        const savedItems = sessionWithSelectedItems.selectedItems.filter((item: any) => item.selected === true);
        
        console.log('*** SAVED ITEMS:', savedItems);
        
        if (savedItems.length > 0) {
          // Restore all types of selections
          const restoredCategories: string[] = [];
          const restoredSubcategories: string[] = [];
          const restoredThemes: string[] = [];
          const restoredElements: any[] = [];
          
          savedItems.forEach((item: any) => {
            switch (item.type) {
              case 'category':
                restoredCategories.push(item.elementId);
                break;
              case 'subcategory':
                restoredSubcategories.push(item.elementId);
                break;
              case 'theme':
                restoredThemes.push(item.elementId);
                break;
              case 'element':
                // Find the actual element from IADATABANK
                const actualElement = allIADataElements.find(el => 
                  el.id === item.elementId || 
                  el.name === item.name ||
                  el.name?.toLowerCase().includes(item.name?.toLowerCase() || '')
                );
                
                if (actualElement) {
                  restoredElements.push(actualElement);
                } else {
                  // Fallback with more complete data from saved item
                  restoredElements.push({
                    id: item.elementId || `unknown-${Date.now()}`,
                    name: item.name || 'Unknown Element',
                    theme: item.theme || 'Unknown Theme',
                    topic: item.topic || 'BASICS',
                    subtopic: item.subtopic || 'B+',
                    progressions: item.progressions || []
                  });
                }
                break;
            }
          });
          
          console.log('*** RESTORING ALL SELECTIONS:');
          console.log('- Categories:', restoredCategories);
          console.log('- Subcategories:', restoredSubcategories);
          console.log('- Themes:', restoredThemes);
          console.log('- Elements:', restoredElements);
          
          // Set all restored selections
          setSelectedCategories(restoredCategories);
          setSelectedSubcategories(restoredSubcategories);
          setSelectedThemes(restoredThemes);
          setSelectedElements(restoredElements);
          
          // Restore training times and VARIA notes from session
          if (sessionWithSelectedItems.startTime) {
            setTrainingStartTime(sessionWithSelectedItems.startTime);
          }
          if (sessionWithSelectedItems.endTime) {
            setTrainingEndTime(sessionWithSelectedItems.endTime);
          }
          if (sessionWithSelectedItems.notes) {
            setActivityNotes(sessionWithSelectedItems.notes);
            console.log('*** RESTORED VARIA NOTES:', sessionWithSelectedItems.notes);
          }
        }
      } else {
        console.log('*** NO SESSIONS WITH SAVED ITEMS FOR:', clickedDateString);
      }
    }
    
    setShowThemeDialog(true);
  };

  // Toggle element selection
  const toggleElementSelection = (elementId: string) => {
    setSelectedElements(prev => 
      prev.includes(elementId) 
        ? prev.filter(id => id !== elementId)
        : [...prev, elementId]
    );
  };

  // Handle delete training session
  const handleDeleteSession = async () => {
    if (!sessionToDelete) return;
    
    try {
      const response = await fetch(`/api/year-plans/${selectedYearPlan}/sessions/${sessionToDelete.id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        toast({
          title: "Training gewist",
          description: `Training van ${sessionToDelete.startTime || '20:00'}-${sessionToDelete.endTime || '21:30'} is definitief verwijderd.`,
        });
        
        // Refresh the sessions to update the calendar
        const updatedSessions = directSessions.filter(s => s.id !== sessionToDelete.id);
        setDirectSessions(updatedSessions);
        
        setShowDeleteDialog(false);
        setSessionToDelete(null);
      } else {
        throw new Error('Failed to delete session');
      }
    } catch (error) {
      console.error('Error deleting session:', error);
      toast({
        title: "Fout bij wissen",
        description: "Er is een fout opgetreden bij het wissen van de training.",
        variant: "destructive"
      });
    }
  };

  // Save training with different selection levels
  const handleSaveTraining = async (level: 'category' | 'subcategory' | 'theme' | 'element') => {
    if (!selectedDate || !selectedYearPlan) return;
    
    // Collect all selected items into selectedItems array for database storage
    const selectedItems = [];
    
    // Add categories
    selectedCategories.forEach(category => {
      selectedItems.push({
        elementId: category,
        type: 'category',
        selected: true,
        name: topicConfig[category as keyof typeof topicConfig]?.display || category,
        theme: 'Categorie'
      });
    });
    
    // Add subcategories
    selectedSubcategories.forEach(subcategory => {
      selectedItems.push({
        elementId: subcategory,
        type: 'subcategory',
        selected: true,
        name: subcategory,
        theme: 'Subcategorie'
      });
    });
    
    // Add themes
    selectedThemes.forEach(themeId => {
      const themeName = getThemeName(themeId);
      selectedItems.push({
        elementId: themeId,
        type: 'theme',
        selected: true,
        name: themeName.name,
        theme: 'Thema'
      });
    });
    
    // Add elements with complete data
    selectedElements.forEach(element => {
      selectedItems.push({
        elementId: element.id,
        type: 'element',
        selected: true,
        name: element.name,
        theme: element.theme || 'Element',
        topic: element.topic || 'BASICS',
        subtopic: element.subtopic || 'B+',
        progressions: element.progressions || []
      });
    });
    
    // KRITIEKE DATUM FIX - gebruik lokale datum zonder timezone offset
    const year = selectedDate.getFullYear();
    const month = String(selectedDate.getMonth() + 1).padStart(2, '0');
    const day = String(selectedDate.getDate()).padStart(2, '0');
    const dateString = `${year}-${month}-${day}`;
    
    console.log('DATUM DEBUG - FIXED LOCAL FORMAT:', {
      selectedDate: selectedDate.toString(),
      year, month, day,
      dateString,
      getDate: selectedDate.getDate(),
      getMonth: selectedDate.getMonth(),
      timezoneOffset: selectedDate.getTimezoneOffset()
    });

    console.log('TRAINING TIME DEBUG:', {
      trainingStartTime,
      trainingEndTime,
      selectedDate,
      selectedActivityType
    });

    let trainingData = {
      date: dateString,
      eventType: selectedActivityType || 'training',
      title: selectedActivityType === 'training' ? 'Training' : selectedActivityType,
      intensity: "medium",
      isCompleted: false,
      location: '',
      startTime: trainingStartTime,
      endTime: trainingEndTime,
      notes: activityNotes || '', // VARIA opmerking veld voor wedstrijd details
      categories: [] as string[],
      subcategories: [] as string[],
      themes: [] as string[],
      iadataBankElements: [] as string[],
      selectedItems: selectedItems // Include all selected items
    };

    console.log('SENDING TRAINING DATA:', trainingData);



    // Build training data based on selection level (for backward compatibility)
    switch (level) {
      case 'category':
        trainingData.categories = selectedCategories;
        break;
      case 'subcategory':
        trainingData.categories = [selectedTopic].filter(Boolean);
        trainingData.subcategories = selectedSubcategories;
        break;
      case 'theme':
        trainingData.categories = [selectedTopic].filter(Boolean);
        trainingData.subcategories = [selectedSubtopic].filter(Boolean);
        trainingData.themes = selectedThemes;
        break;
      case 'element':
        trainingData.categories = [selectedTopic].filter(Boolean);
        trainingData.subcategories = [selectedSubtopic].filter(Boolean);
        trainingData.themes = selectedThemes;
        trainingData.iadataBankElements = selectedElements.map(el => el.id);
        break;
    }
    
    try {
      const response = await fetch(`/api/year-plans/${selectedYearPlan}/sessions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(trainingData)
      });

      if (response.ok) {
        const levelNames = {
          'category': 'Categorieën',
          'subcategory': 'Subcategorieën', 
          'theme': 'Thema\'s',
          'element': 'Elementen'
        };
        
        toast({ title: `Training met ${levelNames[level]} opgeslagen!` });
        setShowThemeDialog(false);
        
        // Invalidate and refetch training sessions to show the new training
        queryClient.invalidateQueries({ queryKey: ['/api/year-plans', selectedYearPlan, 'sessions'] });
        refetchSessions();
        
        // Also refresh direct sessions
        if (selectedYearPlan) {
          fetch(`/api/year-plans/${selectedYearPlan}/sessions`)
            .then(res => res.json())
            .then(sessions => setDirectSessions(sessions));
        }
        
        // Reset selections
        setSelectedElements([]);
        setSelectedThemes([]);
        setSelectedCategories([]);
        setSelectedSubcategories([]);
        setSelectedTopic("");
        setSelectedSubtopic("");
        setSelectedElement("");
        setActivityNotes(""); // Reset activity notes
      }
    } catch (error) {
      console.error('OPSLAG FOUT:', error);
      toast({ 
        title: "Fout bij opslaan", 
        description: error instanceof Error ? error.message : "Training kon niet worden opgeslagen",
        variant: "destructive" 
      });
    }
  };

  // Generate calendar grid
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  // Helper function to get training sessions for a specific day
  const getSessionsForDay = (day: Date) => {
    const dayString = format(day, 'yyyy-MM-dd');
    
    // FORCE FIND SESSIONS - debug approach
    const sessions = directSessions.filter((session: any) => 
      session.date === dayString
    );
    
    // Sessions found for this day
    
    return sessions;
  };



  if (isLoadingPlans || isLoadingIA) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">Laden...</div>
      </div>
    );
  }



  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header with Year Plan Info */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <Link to="/jaarplanning">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Terug naar Jaarplanning
            </Button>
          </Link>
          
          <div className="flex gap-2">
            <Button 
              onClick={handlePDFExport}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2"
            >
              <Download className="h-4 w-4 mr-2" />
              PDF Export
            </Button>
            <Button 
              onClick={handleExcelExport}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2"
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Excel Export
            </Button>
            <Button 
              onClick={handleBulkTimeUpdate}
              className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2"
            >
              <Clock className="h-4 w-4 mr-2" />
              Alle Tijden → 20:00-21:45
            </Button>
            <Button 
              onClick={() => setShowEmailDialog(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2"
            >
              <Share className="h-4 w-4 mr-2" />
              Delen
            </Button>
          </div>
        </div>

      </div>

      {/* Calendar */}
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <Button variant="outline" onClick={() => navigateMonth('prev')}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <CardTitle className="text-xl">
                {format(currentDate, 'MMMM yyyy', { locale: nl })}
              </CardTitle>
              <Button variant="outline" onClick={() => navigateMonth('next')}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {/* Weekday headers */}
            <div className="grid grid-cols-7 gap-2 mb-4">
              {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map((day) => (
                <div key={day} className="p-2 text-center font-semibold text-gray-600">
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar grid */}
            <div className="grid grid-cols-7 gap-2">
              {calendarDays.map((day) => {
                const isCurrentMonth = isSameMonth(day, currentDate);
                const isToday = isSameDay(day, new Date());
                const isAvailable = isDateAvailable(day);

                return (
                  <div
                    key={day.toString()}
                    className={`
                      min-h-[100px] p-2 border rounded-lg cursor-pointer transition-colors
                      ${isCurrentMonth ? 'bg-white' : 'bg-gray-50'}
                      ${isToday ? 'ring-2 ring-blue-500' : ''}
                      ${isAvailable && isCurrentMonth ? 'hover:bg-blue-50 border-blue-200' : 'border-gray-200'}
                      ${!isAvailable || !isCurrentMonth ? 'cursor-not-allowed opacity-50' : ''}
                    `}
                    onClick={() => handleDateClick(day)}
                  >
                    <div className="flex flex-col h-full">
                      <span className={`text-sm font-medium ${isToday ? 'text-blue-600' : ''}`}>
                        {format(day, 'd')}
                      </span>

                      {(
                        <div className="mt-2 space-y-1">
                          {/* SHOW ALL SESSIONS AND FORCE DISPLAY */}
                          {(() => {
                            const sessions = getSessionsForDay(day);
                            const dayString = format(day, 'yyyy-MM-dd');
                            
                            // FORCE DISPLAY - always show for training days with sessions
                            if (sessions.length > 0) {
                              return sessions.map((session: any) => (
                                <div
                                  key={session.id}
                                  className={`text-xs p-2 rounded font-bold border relative group ${
                                    session.eventType === 'training' ? 'bg-blue-100 text-blue-800 border-blue-300' :
                                    session.eventType === 'extra_training' ? 'bg-green-100 text-green-800 border-green-300' :
                                    session.eventType === 'friendly_match' ? 'bg-yellow-100 text-yellow-800 border-yellow-300' :
                                    session.eventType === 'competition_match' ? 'bg-red-100 text-red-800 border-red-300' :
                                    session.eventType === 'varia' ? 'bg-purple-100 text-purple-800 border-purple-300' :
                                    'bg-gray-100 text-gray-800 border-gray-300'
                                  }`}
                                  title={`Training - ${session.duration || 90} minuten`}
                                >
                                  <div className="text-center mb-1 font-bold text-xs">
                                    {/* ENHANCED ELEMENT DISPLAY - PERMANENT FIX */}
                                    {(() => {
                                      const displayItems = [];
                                      let elementCount = 0;
                                      
                                      // PRIORITY 1: Parse selected items with comprehensive fallbacks
                                      if (session.selectedItems && session.selectedItems.length > 0) {
                                        elementCount = session.selectedItems.length;
                                        session.selectedItems.forEach((item: any) => {
                                          let elementName = '';
                                          
                                          // Try multiple properties for element name
                                          if (item.name && item.name !== 'Unknown Element' && item.name !== 'undefined') {
                                            elementName = item.name;
                                          } else if (item.theme && item.theme !== 'undefined' && item.theme !== 'Element') {
                                            elementName = item.theme;
                                          } else if (item.elementId) {
                                            // Advanced IADATABANK lookup
                                            const foundElement = iadataBankElements?.find(el => 
                                              el.id === item.elementId || 
                                              el.key === item.elementId ||
                                              el.name?.toLowerCase().includes(item.elementId?.toLowerCase() || '')
                                            );
                                            if (foundElement) {
                                              elementName = foundElement.name;
                                            } else {
                                              // Smart element ID parsing
                                              elementName = item.elementId
                                                ?.replace(/_/g, ' ')
                                                ?.replace(/-/g, ' ')
                                                ?.split(' ')
                                                ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
                                                ?.join(' ') || 'Element';
                                            }
                                          } else if (item.category) {
                                            elementName = item.category;
                                          }
                                          
                                          if (elementName && elementName !== 'undefined') {
                                            displayItems.push(elementName);
                                          }
                                        });
                                      }
                                      
                                      // PRIORITY 2: Parse themes array
                                      if (session.themes && session.themes.length > 0) {
                                        session.themes.forEach((theme: string) => {
                                          if (theme && theme !== 'undefined') {
                                            displayItems.push(theme.replace(/-/g, ' ').toUpperCase());
                                          }
                                        });
                                      }
                                      
                                      // PRIORITY 3: Parse description/notes with comprehensive keywords
                                      if (displayItems.length === 0) {
                                        const searchText = (session.description || session.notes || '').toLowerCase();
                                        
                                        // TEAMTACTISCH themes
                                        if (searchText.includes('opbouwen')) displayItems.push('OPBOUWEN');
                                        if (searchText.includes('druk zetten')) displayItems.push('DRUK ZETTEN');
                                        if (searchText.includes('vooruitgang') || searchText.includes('infiltratie')) displayItems.push('VOORUITGANG');
                                        if (searchText.includes('compact') || searchText.includes('verdedigen')) displayItems.push('COMPACT VERDEDIGEN');
                                        if (searchText.includes('scoren') || searchText.includes('afwerken')) displayItems.push('SCOREN');
                                        if (searchText.includes('beschermen') || searchText.includes('doel')) displayItems.push('BESCHERMEN DOEL');
                                        if (searchText.includes('tegenaanval')) displayItems.push('TEGENAANVAL');
                                        if (searchText.includes('omschakeling')) displayItems.push('OMSCHAKELING');
                                        
                                        // BASICS themes
                                        if (searchText.includes('passing')) displayItems.push('PASSING');
                                        if (searchText.includes('balcontrole')) displayItems.push('BALCONTROLE');
                                        if (searchText.includes('schieten')) displayItems.push('SCHIETEN');
                                        if (searchText.includes('dribbelen')) displayItems.push('DRIBBELEN');
                                        if (searchText.includes('leiden')) displayItems.push('LEIDEN VAN DE BAL');
                                        
                                        // VARIA activities
                                        if (searchText.includes('wedstrijd') || searchText.includes('vs ')) displayItems.push('WEDSTRIJD');
                                        if (searchText.includes('oefenwedstrijd')) displayItems.push('OEFENWEDSTRIJD');
                                        if (searchText.includes('beker')) displayItems.push('BEKERWEDSTRIJD');
                                        if (searchText.includes('competitie')) displayItems.push('COMPETITIEWEDSTRIJD');
                                      }
                                      
                                      // FALLBACK: Use 'TRAINING' if nothing found
                                      if (displayItems.length === 0) {
                                        return 'TRAINING';
                                      }
                                      
                                      // DISPLAY LOGIC: Show elements with count
                                      let result = '';
                                      if (displayItems.length <= 2) {
                                        result = displayItems.join(' + ');
                                      } else {
                                        result = `${displayItems.slice(0, 2).join(' + ')} +${displayItems.length - 2}`;
                                      }
                                      
                                      // Add element count badge if multiple elements
                                      if (elementCount > 1) {
                                        result += ` (${elementCount})`;
                                      }
                                      
                                      // Add match opponent info for VARIA
                                      if (session.notes && session.notes.trim() !== '' && 
                                          (session.notes.includes('vs ') || session.notes.includes('uit') || session.notes.includes('thuis'))) {
                                        result += ` - ${session.notes}`;
                                      }
                                      
                                      return result || 'TRAINING';
                                    })()}
                                  </div>
                                  <div className="text-center text-xs opacity-75 font-mono">
                                    {session.startTime || '20:00'}-{session.endTime || '21:45'}
                                  </div>
                                  
                                  {/* Training Actions */}
                                  <div className="flex justify-between items-center mt-2 gap-1">
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        console.log('CRITICAL - Edit clicked for SPECIFIC session:', {
                                          sessionId: session.id,
                                          sessionData: session,
                                          startTime: session.startTime,
                                          endTime: session.endTime,
                                          notes: session.notes
                                        });
                                        setSessionToEdit(session);
                                        setSelectedDate(day);
                                        setTrainingStartTime(session.startTime || '20:00');
                                        setTrainingEndTime(session.endTime || '21:45');
                                        setActivityNotes(session.notes || '');
                                        setShowEditDialog(true);
                                      }}
                                      className="flex-1 bg-blue-500 text-white text-xs px-2 py-1 rounded hover:bg-blue-600"
                                      title={`Bewerk training ${session.id} - ${session.startTime || '20:00'}-${session.endTime || '21:45'}`}
                                    >
                                      ✎ Tijd
                                    </button>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setSessionToDelete(session);
                                        setShowDeleteDialog(true);
                                      }}
                                      className="bg-red-500 text-white text-xs px-2 py-1 rounded hover:bg-red-600"
                                      title="Wis training"
                                    >
                                      🗑
                                    </button>
                                  </div>
                                </div>
                              ));
                            }
                            
                            // No sessions found for this day
                            return null;
                          })()}
                          
                          {/* Show add button only for available dates */}
                          {isAvailable && (
                            <div 
                              className="text-xs text-center text-blue-600 font-medium bg-blue-50 rounded px-2 py-1 cursor-pointer hover:bg-blue-100 mt-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedDate(day);
                                // Behoud bestaande tijd instellingen - geen reset meer
                                setShowTimeDialog(true);
                              }}
                            >
                              {getSessionsForDay(day).length === 0 ? '+ Training' : '+ Extra Training'}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Training Planning Dialog */}
      <Dialog open={showThemeDialog} onOpenChange={setShowThemeDialog}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Training Planner
              </div>
              <span className="text-sm font-normal text-gray-500">
                {selectedDate && format(selectedDate, 'EEEE d MMMM yyyy', { locale: nl })}
              </span>
            </DialogTitle>
            <div className="text-sm text-gray-600">
              Plan je training: gebruik snelle thema's of selecteer individuele IADATABANK elementen
            </div>
          </DialogHeader>

          {/* Enhanced Training Setup with Time and Notes */}
          <div className="space-y-4 mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            {/* Time Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="training-start-time" className="text-sm font-medium text-blue-900">Start Tijd</Label>
                <Input 
                  id="training-start-time" 
                  type="time" 
                  value={trainingStartTime}
                  onChange={(e) => setTrainingStartTime(e.target.value)}
                  className="w-full mt-1 text-lg font-mono border-2 border-blue-200 focus:border-blue-500" 
                  placeholder="19:00"
                />
              </div>
              <div>
                <Label htmlFor="training-end-time" className="text-sm font-medium text-blue-900">Eind Tijd</Label>
                <Input 
                  id="training-end-time" 
                  type="time" 
                  value={trainingEndTime}
                  onChange={(e) => setTrainingEndTime(e.target.value)}
                  className="w-full mt-1 text-lg font-mono border-2 border-blue-200 focus:border-blue-500" 
                  placeholder="20:30"
                />
              </div>
            </div>
            
            {/* VARIA Opmerking Veld - Voor wedstrijd details */}
            <div>
              <Label htmlFor="activity-notes" className="text-sm font-medium text-blue-900">VARIA Opmerkingen</Label>
              <Input 
                id="activity-notes" 
                type="text" 
                value={activityNotes}
                onChange={(e) => setActivityNotes(e.target.value)}
                className="w-full mt-1 text-lg border-2 border-blue-200 focus:border-blue-500" 
                placeholder="vs KRC Genk (Thuis), Oefenwedstrijd, Extra training details..."
              />
              <div className="text-xs text-blue-600 mt-1">
                Voor wedstrijden: tegenstander naam, thuis/uit, competitie details
              </div>
            </div>
            
            {/* Current Time Display */}
            <div className="text-xs text-blue-700 bg-blue-100 rounded p-2">
              Huidige instelling: {trainingStartTime} tot {trainingEndTime}
              {activityNotes && ` - ${activityNotes}`}
            </div>
          </div>


          
          <div className="space-y-6">
            {/* Persistent Selection Menu - Always Visible at Top */}
            <div className="sticky top-0 z-10 p-4 bg-white border border-gray-200 rounded-lg shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <h5 className="font-semibold text-gray-900 flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                  Geselecteerde Training Items
                </h5>
                <div className="flex gap-2">
                  <Button
                    onClick={handleSaveSelection}
                    disabled={isSaving || (selectedCategories.length === 0 && selectedSubcategories.length === 0 && selectedThemes.length === 0 && selectedElements.length === 0)}
                    size="sm"
                    className="bg-green-600 hover:bg-green-700 text-white disabled:bg-gray-300"
                  >
                    {isSaving ? "Opslaan..." : "Training Opslaan"}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedCategories([]);
                      setSelectedSubcategories([]);
                      setSelectedThemes([]);
                      setSelectedElements([]);
                    }}
                    className="text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Alles Wissen
                  </Button>
                </div>
              </div>

              {/* Show selection counts or empty state */}
              <div className="text-sm text-blue-600 font-medium text-center py-2 border border-blue-200 rounded mb-2">
                Live State: Cat={selectedCategories.length} | Sub={selectedSubcategories.length} | Themes={selectedThemes.length} | Elements={selectedElements.length}
              </div>
              
              {/* Enhanced selected items display with full details */}
              {selectedElements.length > 0 && (
                <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded">
                  <h4 className="font-medium text-orange-800 mb-2">Geselecteerde Elementen ({selectedElements.length})</h4>
                  <div className="space-y-2">
                    {selectedElements.map((element) => {
                      // Find the full element data from IADATABANK
                      const fullElement = iaDatabankData?.data?.find(e => e.id === element.id);
                      
                      const elementName = fullElement?.name || element.name || element.id || 'Unknown Element';
                      const elementTopic = fullElement?.topic || element.topic || '';
                      const elementSubtopic = fullElement?.subtopic || element.subtopic || '';
                      const elementTheme = fullElement?.theme || element.theme || '';

                      return (
                        <div key={element.id} className="p-2 bg-white border border-orange-200 rounded text-sm">
                          <div className="font-medium text-orange-900">{elementName}</div>
                          <div className="text-xs text-gray-600 mt-1">
                            {elementTopic && <span className="text-purple-600">{elementTopic}</span>}
                            {elementSubtopic && <span className="text-blue-600"> → {elementSubtopic}</span>}
                            {elementTheme && <span className="text-green-600"> → {elementTheme}</span>}
                          </div>
                          {fullElement?.description && (
                            <div className="text-xs text-gray-500 mt-1 italic">{fullElement.description}</div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
              
              {(selectedCategories.length === 0 && selectedSubcategories.length === 0 && selectedThemes.length === 0 && selectedElements.length === 0) ? (
                <div className="text-sm text-gray-500 italic text-center py-2">
                  Geen items geselecteerd - kies hieronder categorieën, thema's of elementen
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-purple-700 font-medium">
                      Categorieën: {selectedCategories.length}
                    </span>
                    <span className="text-blue-700 font-medium">
                      Subcategorieën: {selectedSubcategories.length}
                    </span>
                    <span className="text-green-700 font-medium">
                      Thema's: {selectedThemes.length}
                    </span>
                    <span className="text-orange-700 font-medium">
                      Elementen: {selectedElements.length}
                    </span>
                  </div>

                  {/* Show actual selected items */}
                  <div className="space-y-2">
                    {/* Selected Categories */}
                    {selectedCategories.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {selectedCategories.map((category) => (
                          <div
                            key={category}
                            className="inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-800 rounded text-xs border"
                          >
                            <span className="font-medium">{topicConfig[category as keyof typeof topicConfig]?.display || category}</span>
                            <button
                              onClick={() => setSelectedCategories(selectedCategories.filter(c => c !== category))}
                              className="text-purple-600 hover:text-red-500"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Selected Subcategories */}
                    {selectedSubcategories.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {selectedSubcategories.map((subcategory) => (
                          <div
                            key={subcategory}
                            className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs border"
                          >
                            <span className="font-medium">{subcategory}</span>
                            <button
                              onClick={() => setSelectedSubcategories(selectedSubcategories.filter(s => s !== subcategory))}
                              className="text-blue-600 hover:text-red-500"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Selected Themes with enhanced details */}
                    {selectedThemes.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-sm font-medium text-green-800">Geselecteerde Thema's:</div>
                        {selectedThemes.map((theme) => {
                          // Find theme details from the predefined themes
                          const themeDetails = Object.values(teamtacticsThemes).flat().find(t => 
                            t.id === theme || t.name.toLowerCase().includes(theme.toLowerCase())
                          );
                          
                          return (
                            <div
                              key={theme}
                              className="flex items-center justify-between p-2 bg-green-50 border border-green-200 rounded"
                            >
                              <div className="flex-1">
                                <div className="font-medium text-green-900">{theme}</div>
                                {themeDetails && (
                                  <div className="text-xs text-green-700 mt-1">
                                    {themeDetails.name} - TeamTactical thema
                                  </div>
                                )}
                              </div>
                              <button
                                onClick={() => setSelectedThemes(selectedThemes.filter(t => t !== theme))}
                                className="text-green-600 hover:text-red-500 p-1"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Selected Elements with enhanced details */}
                    {selectedElements.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-sm font-medium text-orange-800">Geselecteerde Elementen:</div>
                        {selectedElements.map((element) => (
                          <div
                            key={element.id}
                            className="flex items-center justify-between p-2 bg-orange-50 border border-orange-200 rounded"
                          >
                            <div className="flex-1">
                              <div className="font-medium text-orange-900">{element.name}</div>
                              <div className="text-xs text-orange-700 mt-1">
                                {element.topic} → {element.subtopic} → {element.theme}
                                {element.progressions && element.progressions.length > 0 && (
                                  <span className="ml-2">({element.progressions.length} niveaus)</span>
                                )}
                              </div>
                            </div>
                            <button
                              onClick={() => setSelectedElements(selectedElements.filter(e => e.id !== element.id))}
                              className="text-orange-600 hover:text-red-500 p-1"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Smart Search Box */}
            <div className="relative">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Zoek elementen, thema's of categorieën... (bijv. 'passing', 'druk', 'concentratie')"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setShowSearchResults(e.target.value.length > 0);
                  }}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {searchQuery && (
                  <button
                    onClick={() => {
                      setSearchQuery("");
                      setShowSearchResults(false);
                    }}
                    className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>

              {/* Live Search Results */}
              {showSearchResults && searchQuery && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-20 max-h-96 overflow-y-auto">
                  <SearchResults 
                    query={searchQuery}
                    data={iaDatabankData}
                    onSelectElement={(element) => {
                      console.log("Selecting element:", element);
                      try {
                        if (!selectedElements.some(el => el.id === element.id)) {
                          const newElements = [...selectedElements, element];
                          console.log("Adding element to selection:", newElements);
                          setSelectedElements(newElements);
                          
                          // Direct database update - mark as selected (1 = gekozen)
                          setTimeout(async () => {
                            try {
                              const selectedItem = {
                                elementId: element.id,
                                type: 'element' as const,
                                selected: true, // 1 = aangevinkt/gekozen
                                name: element.name,
                                theme: element.theme
                              };
                              
                              console.log("Saving selected item to database:", selectedItem);
                              console.log("Using yearPlanId:", selectedYearPlan);
                              console.log("Using date:", format(selectedDate, 'yyyy-MM-dd'));
                              
                              // First, find or create session for this date - CONSISTENT FORMAT
                              const targetDate = format(selectedDate, 'yyyy-MM-dd');
                              let targetSession = directSessions.find((s: any) => s.date === targetDate);
                              
                              if (!targetSession) {
                                // Create new session for this date
                                const createResponse = await fetch(`/api/year-plans/${selectedYearPlan}/sessions`, {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    date: targetDate,
                                    themes: [],
                                    duration: 90,
                                    selectedItems: [selectedItem]
                                  })
                                });
                                targetSession = await createResponse.json();
                                console.log("Created new session:", targetSession);
                              } else {
                                // Update existing session with selected items
                                const updateResponse = await fetch(`/api/year-plans/${selectedYearPlan}/sessions/${targetSession.id}`, {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    selectedItems: [selectedItem]
                                  })
                                });
                                const updatedSession = await updateResponse.json();
                                console.log("Updated session with selected items:", updatedSession);
                              }
                              
                              console.log("Item marked as selected in database");
                              
                              // Refresh sessions data to show updated state
                              if (selectedYearPlan) {
                                fetch(`/api/year-plans/${selectedYearPlan}/sessions`)
                                  .then(res => res.json())
                                  .then(sessions => {
                                    console.log('Refreshed sessions after save:', sessions.length);
                                    setDirectSessions(sessions);
                                  })
                                  .catch(err => console.error('Refresh error:', err));
                              }
                            } catch (error) {
                              console.error("Error saving selected item:", error);
                            }
                          }, 100);
                        }
                        setSearchQuery("");
                        setShowSearchResults(false);
                      } catch (error) {
                        console.error("Error selecting element:", error);
                      }
                    }}
                    onSelectCategory={(category) => {
                      console.log("Selecting category:", category);
                      if (!selectedCategories.includes(category)) {
                        const newCategories = [...selectedCategories, category];
                        console.log("New selected categories:", newCategories);
                        setSelectedCategories(newCategories);
                      }
                      setSearchQuery("");
                      setShowSearchResults(false);
                    }}
                    onSelectTheme={(theme) => {
                      console.log("Selecting theme:", theme);
                      if (!selectedThemes.includes(theme)) {
                        const newThemes = [...selectedThemes, theme];
                        console.log("New selected themes:", newThemes);
                        setSelectedThemes(newThemes);
                      }
                      setSearchQuery("");
                      setShowSearchResults(false);
                    }}
                  />
                </div>
              )}
            </div>

            {/* Expandable Detailed Selection Summary */}
            {(selectedCategories.length > 0 || selectedSubcategories.length > 0 || selectedThemes.length > 0 || selectedElements.length > 0) && (
              <div className="p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border border-blue-200">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="font-medium text-gray-900">
                    Gedetailleerd Overzicht
                  </h5>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowDetailedSummary(!showDetailedSummary)}
                    className="text-gray-600"
                  >
                    {showDetailedSummary ? "Verberg Details" : "Toon Details"}
                  </Button>
                </div>

                {/* Selected Categories */}
                {selectedCategories.length > 0 && (
                  <div className="mb-3">
                    <h6 className="text-sm font-medium text-purple-700 mb-2">Categorieën ({selectedCategories.length})</h6>
                    <div className="flex flex-wrap gap-2">
                      {selectedCategories.map((category) => (
                        <div
                          key={category}
                          className="inline-flex items-center gap-2 px-3 py-1 bg-purple-100 text-purple-800 rounded-full border text-sm"
                        >
                          <span className="font-medium">{topicConfig[category as keyof typeof topicConfig]?.display || category}</span>
                          <button
                            onClick={() => setSelectedCategories(selectedCategories.filter(c => c !== category))}
                            className="text-purple-600 hover:text-red-500"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Selected Subcategories */}
                {selectedSubcategories.length > 0 && (
                  <div className="mb-3">
                    <h6 className="text-sm font-medium text-blue-700 mb-2">Subcategorieën ({selectedSubcategories.length})</h6>
                    <div className="flex flex-wrap gap-2">
                      {selectedSubcategories.map((subcategory) => (
                        <div
                          key={subcategory}
                          className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-800 rounded-full border text-sm"
                        >
                          <span className="font-medium">{subcategory}</span>
                          <button
                            onClick={() => setSelectedSubcategories(selectedSubcategories.filter(s => s !== subcategory))}
                            className="text-blue-600 hover:text-red-500"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Selected Themes */}
                {selectedThemes.length > 0 && (
                  <div className="mb-3">
                    <h6 className="text-sm font-medium text-green-700 mb-2">Thema's ({selectedThemes.length})</h6>
                    <div className="flex flex-wrap gap-2">
                      {selectedThemes.map((themeId) => {
                        const themeName = getThemeName(themeId);
                        return (
                          <div
                            key={themeId}
                            className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-800 rounded-full border text-sm"
                          >
                            <span className="font-medium">{themeName.name}</span>
                            <button
                              onClick={() => setSelectedThemes(selectedThemes.filter(t => t !== themeId))}
                              className="text-green-600 hover:text-red-500"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Selected Elements */}
                {selectedElements.length > 0 && (
                  <div>
                    <h6 className="text-sm font-medium text-orange-700 mb-2">Elementen ({selectedElements.length})</h6>
                    <div className="flex flex-wrap gap-2">
                      {selectedElements.map((element) => {
                        if (!element || !element.id) return null;
                        
                        return (
                          <div
                            key={element.id}
                            className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100 text-orange-800 rounded-full border text-sm"
                          >
                            <span className="font-medium">{element.name}</span>
                            <span className="text-orange-600">{element.theme}</span>
                            <button
                              onClick={() => setSelectedElements(selectedElements.filter(el => el.id !== element.id))}
                              className="text-orange-600 hover:text-red-500"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* IADATABANK Elements Selection - Level-based Tile Interface */}
            <div className="space-y-6">
              <div className="text-sm text-gray-600 mb-4">
                Selecteer IADATABANK elementen met moeilijkheidsniveaus voor deze training:
              </div>
              
              {/* Scherm 1: Category Tiles - 4 Main Categories */}
              {!selectedTopic && (
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900 text-center">Kies een hoofdcategorie:</h4>
                  
                  {/* Selected Categories Summary at top */}
                  {selectedCategories.length > 0 && (
                    <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-purple-800">
                          Geselecteerde Categorieën ({selectedCategories.length})
                        </h5>
                        <div className="flex gap-2">
                          <Button
                            onClick={handleSaveSelection}
                            disabled={isSaving}
                            size="sm"
                            className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1 text-xs"
                          >
                            {isSaving ? "Opslaan..." : `Opslaan (${selectedCategories.length})`}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedCategories([])}
                            className="text-red-600 border-red-200 hover:bg-red-50 px-2 py-1 text-xs"
                          >
                            Wissen
                          </Button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedCategories.map((category) => (
                          <div
                            key={category}
                            className="inline-flex items-center gap-1 px-2 py-1 bg-white rounded text-xs border"
                          >
                            <span className="font-medium">{topicConfig[category as keyof typeof topicConfig]?.display || category}</span>
                            <button
                              onClick={() => setSelectedCategories(selectedCategories.filter(c => c !== category))}
                              className="text-purple-600 hover:text-red-500"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Category Selection with Checkboxes - 5 categorieën */}
                  <div className="grid grid-cols-5 gap-3">
                    {Object.entries(topicConfig).map(([topic, config]) => {
                      const Icon = config.icon;
                      const isSelected = selectedCategories.includes(topic);
                      

                      
                      // Get count of elements for this topic
                      let elementCount = 0;
                      if (topic === 'VARIA') {
                        elementCount = variaThemes['Activiteiten']?.length || 0;
                      } else {
                        const data = (iaDatabankData as any)?.data;
                        if (data && Array.isArray(data)) {
                          elementCount = data.filter((el: any) => el.topic === topic).length;
                        }
                      }
                      
                      return (
                        <Card 
                          key={topic}
                          className={`cursor-pointer transition-all duration-300 transform hover:scale-105 hover:shadow-lg ${
                            isSelected ? 'bg-blue-50 border-blue-500 border-2' : 'bg-white'
                          }`}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="flex items-center justify-between mb-4">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={(e) => {
                                  e.stopPropagation();
                                  if (e.target.checked) {
                                    setSelectedCategories([...selectedCategories, topic]);
                                  } else {
                                    setSelectedCategories(selectedCategories.filter(c => c !== topic));
                                  }
                                }}
                                className="h-4 w-4 text-blue-600 rounded"
                                onClick={(e) => e.stopPropagation()}
                              />
                              <button
                                onClick={() => {
                                  setSelectedTopic(topic);
                                  setSelectedSubtopic("");
                                  setSelectedElement("");
                                }}
                                className="text-xs text-blue-600 hover:text-blue-800"
                              >
                                Details →
                              </button>
                            </div>
                            <div 
                              className={`w-16 h-16 ${config.color} rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md`}
                              onClick={() => {
                                setSelectedTopic(topic);
                                setSelectedSubtopic("");
                                setSelectedElement("");
                              }}
                            >
                              <Icon className="h-8 w-8 text-white" />
                            </div>
                            <h3 className="font-bold text-lg mb-1">{config.display}</h3>
                            <p className="text-xs text-gray-500">{elementCount} elementen</p>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>

                  {/* Save at Category Level */}
                  {selectedCategories.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('category')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Categorieën ({selectedCategories.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Scherm 2: BASICS Subcategory Selection */}
              {selectedTopic === "BASICS" && !selectedSubtopic && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedTopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar categorieën
                    </button>
                  </div>
                  <h4 className="font-medium text-gray-900 text-center">Kies BASICS subcategorie:</h4>
                  
                  {/* Selected Subcategories Summary at top */}
                  {selectedSubcategories.length > 0 && (
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-blue-800">
                          Geselecteerde Subcategorieën ({selectedSubcategories.length})
                        </h5>
                        <div className="flex gap-2">
                          <Button
                            onClick={handleSaveSelection}
                            disabled={isSaving}
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 text-xs"
                          >
                            {isSaving ? "Opslaan..." : `Opslaan (${selectedSubcategories.length})`}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedSubcategories([])}
                            className="text-red-600 border-red-200 hover:bg-red-50 px-2 py-1 text-xs"
                          >
                            Wissen
                          </Button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedSubcategories.map((subcategory) => (
                          <div
                            key={subcategory}
                            className="inline-flex items-center gap-1 px-2 py-1 bg-white rounded text-xs border"
                          >
                            <span className="font-medium">{subcategory}</span>
                            <button
                              onClick={() => setSelectedSubcategories(selectedSubcategories.filter(s => s !== subcategory))}
                              className="text-blue-600 hover:text-red-500"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 gap-4">
                    {/* B+ Tile */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 hover:shadow-lg ${
                        selectedSubcategories.includes("B+") ? 'bg-blue-50 border-blue-500 border-2' : 'bg-white'
                      }`}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="flex items-center justify-between mb-4">
                          <input
                            type="checkbox"
                            checked={selectedSubcategories.includes("B+")}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (e.target.checked) {
                                setSelectedSubcategories([...selectedSubcategories, "B+"]);
                              } else {
                                setSelectedSubcategories(selectedSubcategories.filter(s => s !== "B+"));
                              }
                            }}
                            className="h-4 w-4 text-blue-600 rounded"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <button
                            onClick={() => {
                              setSelectedSubtopic("B+");
                              setSelectedTheme("");
                              setSelectedElement("");
                            }}
                            className="text-xs text-blue-600 hover:text-blue-800"
                          >
                            Details →
                          </button>
                        </div>
                        <div 
                          className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md"
                          onClick={() => {
                            setSelectedSubtopic("B+");
                            setSelectedTheme("");
                            setSelectedElement("");
                          }}
                        >
                          <span className="text-2xl font-bold text-white">B+</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">Met Bal</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "BASICS" && el.subtopic === "B+").length || 0)} elementen
                        </p>
                      </CardContent>
                    </Card>

                    {/* B- Tile */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 hover:shadow-lg ${
                        selectedSubcategories.includes("B-") ? 'bg-blue-50 border-blue-500 border-2' : 'bg-white'
                      }`}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="flex items-center justify-between mb-4">
                          <input
                            type="checkbox"
                            checked={selectedSubcategories.includes("B-")}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (e.target.checked) {
                                setSelectedSubcategories([...selectedSubcategories, "B-"]);
                              } else {
                                setSelectedSubcategories(selectedSubcategories.filter(s => s !== "B-"));
                              }
                            }}
                            className="h-4 w-4 text-blue-600 rounded"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <button
                            onClick={() => {
                              setSelectedSubtopic("B-");
                              setSelectedTheme("");
                              setSelectedElement("");
                            }}
                            className="text-xs text-blue-600 hover:text-blue-800"
                          >
                            Details →
                          </button>
                        </div>
                        <div 
                          className="w-16 h-16 bg-gradient-to-br from-red-400 to-red-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md"
                          onClick={() => {
                            setSelectedSubtopic("B-");
                            setSelectedTheme("");
                            setSelectedElement("");
                          }}
                        >
                          <span className="text-2xl font-bold text-white">B-</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">Zonder Bal</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "BASICS" && el.subtopic === "B-").length || 0)} elementen
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Save at Subcategory Level */}
                  {selectedSubcategories.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('subcategory')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Subcategorieën ({selectedSubcategories.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Scherm 2A: BASICS Theme Selection */}
              {selectedTopic === "BASICS" && selectedSubtopic && !selectedTheme && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedSubtopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar subcategorieën
                    </button>
                  </div>
                  
                  <div className="text-center mb-6">
                    <h4 className="font-medium text-gray-900 text-lg">
                      Kies {selectedSubtopic} thema:
                    </h4>
                    <p className="text-sm text-gray-600 mt-2">
                      Klik op een thema voor algemene planning, of dubbelklik voor gedetailleerde elementen
                    </p>
                  </div>

                  {/* Selected Themes Summary at top */}
                  {selectedThemes.length > 0 && (
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200 mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-green-800">
                          Geselecteerde Thema's ({selectedThemes.length})
                        </h5>
                        <div className="flex gap-2">
                          <Button
                            onClick={handleSaveSelection}
                            disabled={isSaving}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 text-xs"
                          >
                            {isSaving ? "Opslaan..." : `Opslaan (${selectedThemes.length})`}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedThemes([])}
                            className="text-red-600 border-red-200 hover:bg-red-50 px-2 py-1 text-xs"
                          >
                            Wissen
                          </Button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedThemes.map((themeId) => {
                          const themeName = getThemeName(themeId);
                          return (
                            <div
                              key={themeId}
                              className="inline-flex items-center gap-1 px-2 py-1 bg-white rounded text-xs border"
                            >
                              <span className="font-medium">{themeName.name}</span>
                              <button
                                onClick={() => setSelectedThemes(selectedThemes.filter(t => t !== themeId))}
                                className="text-green-600 hover:text-red-500"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  
                  <div className={`grid gap-4 ${selectedSubtopic === "B+" ? 'grid-cols-3' : 'grid-cols-3'}`}>
                    {basicsThemes[selectedSubtopic as keyof typeof basicsThemes]?.map((theme) => (
                      <Card 
                        key={theme.id}
                        className="cursor-pointer transition-all duration-300 transform hover:scale-105 hover:shadow-lg bg-white"
                        onClick={() => {
                          setSelectedTheme(theme.id);
                          setSelectedElement("");
                        }}
                      >
                        <CardContent className="p-4 text-center relative">
                          {/* Selectie checkbox */}
                          <div className="absolute top-2 right-2">
                            <input 
                              type="checkbox"
                              checked={selectedThemes.includes(theme.id)}
                              onChange={(e) => {
                                e.stopPropagation();
                                if (e.target.checked) {
                                  setSelectedThemes(prev => [...prev, theme.id]);
                                } else {
                                  setSelectedThemes(prev => prev.filter(id => id !== theme.id));
                                }
                              }}
                              className="w-4 h-4 text-blue-600 rounded border border-gray-300 focus:ring-blue-500"
                            />
                          </div>
                          
                          <div className={`w-12 h-12 ${theme.color} rounded-lg flex items-center justify-center mx-auto mb-3 shadow-md`}>
                            <span className="text-white font-bold text-xs">
                              {selectedSubtopic}
                            </span>
                          </div>
                          <h5 className="font-semibold text-sm mb-1">{theme.name}</h5>
                          <div className="text-xs text-gray-500">
                            {/* Count elements for this theme */}
                            {(() => {
                              const data = (iaDatabankData as any)?.data || [];
                              let themeElements = [];
                              
                              // Correcte aantallen gebaseerd op authentieke IADATABANK data
                              const counts = {
                                "leiden": 1, "dribbelen": 1, "passing": 8, "balcontrole": 3, 
                                "schieten": 4, "vrijlopen": 1, "steun": 2,
                                "druk_zetten": 1, "duel": 2, "interceptie": 8, "afweren": 4, 
                                "speelhoeken": 1, "dekking": 2
                              };
                              
                              const count = counts[theme.id as keyof typeof counts] || 0;
                              themeElements = { length: count };
                              
                              return `${themeElements.length} elementen`;
                            })()}
                          </div>
                          
                          {/* Dubbel-klik indicator */}
                          <div className="text-xs text-blue-600 mt-2 opacity-70">
                            Dubbelklik voor elementen
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Save at Theme Level */}
                  {selectedThemes.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('theme')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Thema's ({selectedThemes.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Scherm 2: FYSIEK Subcategory Selection */}
              {selectedTopic === "FYSIEK" && !selectedSubtopic && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedTopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar categorieën
                    </button>
                  </div>
                  <h4 className="font-medium text-gray-900 text-center">Kies FYSIEK subcategorie:</h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {/* UITHOUDING Tile */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubcategories.includes("UITHOUDING") ? 'bg-orange-50 border-orange-500 border-2' : 'bg-white'
                      }`}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="flex items-center justify-between mb-4">
                          <input
                            type="checkbox"
                            checked={selectedSubcategories.includes("UITHOUDING")}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (e.target.checked) {
                                setSelectedSubcategories([...selectedSubcategories, "UITHOUDING"]);
                              } else {
                                setSelectedSubcategories(selectedSubcategories.filter(s => s !== "UITHOUDING"));
                              }
                            }}
                            className="h-4 w-4 text-orange-600 rounded"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <button
                            onClick={() => {
                              setSelectedSubtopic("UITHOUDING");
                              setSelectedTheme("");
                              setSelectedElement("");
                            }}
                            className="text-xs text-orange-600 hover:text-orange-800"
                          >
                            Details →
                          </button>
                        </div>
                        <div 
                          className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md"
                          onClick={() => {
                            setSelectedSubtopic("UITHOUDING");
                            setSelectedTheme("");
                            setSelectedElement("");
                          }}
                        >
                          <span className="text-sm font-bold text-white">UIT</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">UITHOUDING</h3>
                        <p className="text-xs text-gray-500">Cardio & Duurtraining</p>
                      </CardContent>
                    </Card>

                    {/* KRACHT Tile */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubcategories.includes("KRACHT") ? 'bg-orange-50 border-orange-500 border-2' : 'bg-white'
                      }`}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="flex items-center justify-between mb-4">
                          <input
                            type="checkbox"
                            checked={selectedSubcategories.includes("KRACHT")}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (e.target.checked) {
                                setSelectedSubcategories([...selectedSubcategories, "KRACHT"]);
                              } else {
                                setSelectedSubcategories(selectedSubcategories.filter(s => s !== "KRACHT"));
                              }
                            }}
                            className="h-4 w-4 text-orange-600 rounded"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <button
                            onClick={() => {
                              setSelectedSubtopic("KRACHT");
                              setSelectedTheme("");
                              setSelectedElement("");
                            }}
                            className="text-xs text-orange-600 hover:text-orange-800"
                          >
                            Details →
                          </button>
                        </div>
                        <div 
                          className="w-16 h-16 bg-gradient-to-br from-red-400 to-red-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md"
                          onClick={() => {
                            setSelectedSubtopic("KRACHT");
                            setSelectedTheme("");
                            setSelectedElement("");
                          }}
                        >
                          <span className="text-sm font-bold text-white">KRA</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">KRACHT</h3>
                        <p className="text-xs text-gray-500">Krachttraining & Power</p>
                      </CardContent>
                    </Card>

                    {/* SNELHEID Tile */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubcategories.includes("SNELHEID") ? 'bg-orange-50 border-orange-500 border-2' : 'bg-white'
                      }`}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="flex items-center justify-between mb-4">
                          <input
                            type="checkbox"
                            checked={selectedSubcategories.includes("SNELHEID")}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (e.target.checked) {
                                setSelectedSubcategories([...selectedSubcategories, "SNELHEID"]);
                              } else {
                                setSelectedSubcategories(selectedSubcategories.filter(s => s !== "SNELHEID"));
                              }
                            }}
                            className="h-4 w-4 text-orange-600 rounded"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <button
                            onClick={() => {
                              setSelectedSubtopic("SNELHEID");
                              setSelectedTheme("");
                              setSelectedElement("");
                            }}
                            className="text-xs text-orange-600 hover:text-orange-800"
                          >
                            Details →
                          </button>
                        </div>
                        <div 
                          className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md"
                          onClick={() => {
                            setSelectedSubtopic("SNELHEID");
                            setSelectedTheme("");
                            setSelectedElement("");
                          }}
                        >
                          <span className="text-sm font-bold text-white">SNE</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">SNELHEID</h3>
                        <p className="text-xs text-gray-500">Sprint & Explosiviteit</p>
                      </CardContent>
                    </Card>

                    {/* LENIGHEID Tile */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubcategories.includes("LENIGHEID") ? 'bg-orange-50 border-orange-500 border-2' : 'bg-white'
                      }`}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="flex items-center justify-between mb-4">
                          <input
                            type="checkbox"
                            checked={selectedSubcategories.includes("LENIGHEID")}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (e.target.checked) {
                                setSelectedSubcategories([...selectedSubcategories, "LENIGHEID"]);
                              } else {
                                setSelectedSubcategories(selectedSubcategories.filter(s => s !== "LENIGHEID"));
                              }
                            }}
                            className="h-4 w-4 text-orange-600 rounded"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <button
                            onClick={() => {
                              setSelectedSubtopic("LENIGHEID");
                              setSelectedTheme("");
                              setSelectedElement("");
                            }}
                            className="text-xs text-orange-600 hover:text-orange-800"
                          >
                            Details →
                          </button>
                        </div>
                        <div 
                          className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md"
                          onClick={() => {
                            setSelectedSubtopic("LENIGHEID");
                            setSelectedTheme("");
                            setSelectedElement("");
                          }}
                        >
                          <span className="text-sm font-bold text-white">LEN</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">LENIGHEID</h3>
                        <p className="text-xs text-gray-500">Flexibiliteit & Mobiliteit</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Save at Subcategory Level */}
                  {selectedSubcategories.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('subcategory')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Subcategorieën ({selectedSubcategories.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Scherm 2: MENTAAL Subcategory Selection */}
              {selectedTopic === "MENTAAL" && !selectedSubtopic && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedTopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar categorieën
                    </button>
                  </div>
                  <h4 className="font-medium text-gray-900 text-center">Kies MENTAAL subcategorie:</h4>
                  
                  <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
                    {/* ALGEMEEN MENTAAL Tile */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubcategories.includes("ALGEMEEN MENTAAL") ? 'bg-purple-50 border-purple-500 border-2' : 'bg-white'
                      }`}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="flex items-center justify-between mb-4">
                          <input
                            type="checkbox"
                            checked={selectedSubcategories.includes("ALGEMEEN MENTAAL")}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (e.target.checked) {
                                setSelectedSubcategories([...selectedSubcategories, "ALGEMEEN MENTAAL"]);
                              } else {
                                setSelectedSubcategories(selectedSubcategories.filter(s => s !== "ALGEMEEN MENTAAL"));
                              }
                            }}
                            className="h-4 w-4 text-purple-600 rounded"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <button
                            onClick={() => {
                              setSelectedSubtopic("ALGEMEEN MENTAAL");
                              setSelectedTheme("");
                              setSelectedElement("");
                            }}
                            className="text-xs text-purple-600 hover:text-purple-800"
                          >
                            Details →
                          </button>
                        </div>
                        <div 
                          className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md"
                          onClick={() => {
                            setSelectedSubtopic("ALGEMEEN MENTAAL");
                            setSelectedTheme("");
                            setSelectedElement("");
                          }}
                        >
                          <span className="text-sm font-bold text-white">MEN</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">ALGEMEEN MENTAAL</h3>
                        <p className="text-xs text-gray-500">Concentratie & Focus</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Save at Subcategory Level */}
                  {selectedSubcategories.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('subcategory')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Subcategorieën ({selectedSubcategories.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Scherm 2: TEAMTACTICS Subcategory Selection - All 4 Options Together */}
              {selectedTopic === "TEAMTACTISCH" && !selectedSubtopic && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedTopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar categorieën
                    </button>
                  </div>
                  <h4 className="font-medium text-gray-900 text-center">Kies TEAMTACTICS subcategorie:</h4>
                  <div className="grid grid-cols-3 gap-4">
                    {/* B+ Tile - Geel/Goud */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubtopic === "B+" 
                          ? 'ring-2 ring-yellow-500 bg-yellow-50 shadow-lg' 
                          : 'hover:shadow-lg bg-white'
                      }`}
                      onClick={() => {
                        setSelectedSubtopic("B+");
                        setSelectedTheme("");
                        setSelectedElement("");
                      }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md">
                          <span className="text-2xl font-bold text-white">B+</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">Aanvallend</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "TEAMTACTISCH" && el.subtopic === "B+").length || 0)} elementen
                        </p>
                        {selectedSubtopic === "B+" && (
                          <div className="mt-2 text-xs text-yellow-600 font-medium">
                            Geselecteerd ✓
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* B- Tile - Grijs */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubtopic === "B-" 
                          ? 'ring-2 ring-gray-500 bg-gray-50 shadow-lg' 
                          : 'hover:shadow-lg bg-white'
                      }`}
                      onClick={() => {
                        setSelectedSubtopic("B-");
                        setSelectedTheme("");
                        setSelectedElement("");
                      }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-gray-400 to-gray-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md">
                          <span className="text-2xl font-bold text-white">B-</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">Verdedigend</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "TEAMTACTISCH" && el.subtopic === "B-").length || 0)} elementen
                        </p>
                        {selectedSubtopic === "B-" && (
                          <div className="mt-2 text-xs text-gray-600 font-medium">
                            Geselecteerd ✓
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* OMSCH. B+/B- Tile - Paars */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubtopic === "OMSCH. B+/B-" 
                          ? 'ring-2 ring-purple-500 bg-purple-50 shadow-lg' 
                          : 'hover:shadow-lg bg-white'
                      }`}
                      onClick={() => {
                        setSelectedSubtopic("OMSCH. B+/B-");
                        setSelectedTheme("");
                        setSelectedElement("");
                      }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 bg-purple-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md">
                          <span className="text-sm font-bold text-white">B+→B-</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">Omschakeling</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "TEAMTACTISCH" && el.subtopic === "OMSCH. B+/B-").length || 0)} elementen
                        </p>
                        {selectedSubtopic === "OMSCH. B+/B-" && (
                          <div className="mt-2 text-xs text-purple-600 font-medium">
                            Geselecteerd ✓
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* OMSCH. B-/B+ Tile - Oranje */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubtopic === "OMSCH. B-/B+" 
                          ? 'ring-2 ring-orange-500 bg-orange-50 shadow-lg' 
                          : 'hover:shadow-lg bg-white'
                      }`}
                      onClick={() => {
                        setSelectedSubtopic("OMSCH. B-/B+");
                        setSelectedTheme("");
                        setSelectedElement("");
                      }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 bg-orange-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md">
                          <span className="text-sm font-bold text-white">B-→B+</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">Omschakeling</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "TEAMTACTISCH" && el.subtopic === "OMSCH. B-/B+").length || 0)} elementen
                        </p>
                        {selectedSubtopic === "OMSCH. B-/B+" && (
                          <div className="mt-2 text-xs text-orange-600 font-medium">
                            Geselecteerd ✓
                          </div>
                        )}
                      </CardContent>
                    </Card>


                  </div>
                </div>
              )}

              {/* Scherm 2: LINIE Subcategory Selection - B+ and B- */}
              {selectedTopic === "LINIE" && !selectedSubtopic && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedTopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar categorieën
                    </button>
                  </div>
                  <h4 className="font-medium text-gray-900 text-center">Kies LINIE subcategorie:</h4>
                  <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto">
                    {/* B+ Tile - Teal */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubtopic === "B+" 
                          ? 'ring-2 ring-teal-500 bg-teal-50 shadow-lg' 
                          : 'hover:shadow-lg bg-white'
                      }`}
                      onClick={() => {
                        setSelectedSubtopic("B+");
                        setSelectedTheme("");
                        setSelectedElement("");
                      }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-teal-400 to-teal-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md">
                          <span className="text-2xl font-bold text-white">B+</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">LINIE Aanvallend</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "LINIE" && el.subtopic === "B+").length || 0)} elementen
                        </p>
                        {selectedSubtopic === "B+" && (
                          <div className="mt-2 text-xs text-teal-600 font-medium">
                            Geselecteerd ✓
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* B- Tile - Teal Dark */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubtopic === "B-" 
                          ? 'ring-2 ring-teal-600 bg-teal-50 shadow-lg' 
                          : 'hover:shadow-lg bg-white'
                      }`}
                      onClick={() => {
                        setSelectedSubtopic("B-");
                        setSelectedTheme("");
                        setSelectedElement("");
                      }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-teal-700 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md">
                          <span className="text-2xl font-bold text-white">B-</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">LINIE Verdedigend</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "LINIE" && el.subtopic === "B-").length || 0)} elementen
                        </p>
                        {selectedSubtopic === "B-" && (
                          <div className="mt-2 text-xs text-teal-600 font-medium">
                            Geselecteerd ✓
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {/* Scherm 2: INDIVIDUEEL Subcategory Selection - B+ and B- */}
              {selectedTopic === "INDIVIDUEEL" && !selectedSubtopic && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedTopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar categorieën
                    </button>
                  </div>
                  <h4 className="font-medium text-gray-900 text-center">Kies INDIVIDUEEL subcategorie:</h4>
                  <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto">
                    {/* B+ Tile - Rose */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubtopic === "B+" 
                          ? 'ring-2 ring-rose-500 bg-rose-50 shadow-lg' 
                          : 'hover:shadow-lg bg-white'
                      }`}
                      onClick={() => {
                        setSelectedSubtopic("B+");
                        setSelectedTheme("");
                        setSelectedElement("");
                      }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-rose-400 to-rose-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md">
                          <span className="text-2xl font-bold text-white">B+</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">INDIVIDUEEL Aanvallend</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "INDIVIDUEEL" && el.subtopic === "B+").length || 0)} elementen
                        </p>
                        {selectedSubtopic === "B+" && (
                          <div className="mt-2 text-xs text-rose-600 font-medium">
                            Geselecteerd ✓
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* B- Tile - Rose Dark */}
                    <Card 
                      className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                        selectedSubtopic === "B-" 
                          ? 'ring-2 ring-rose-600 bg-rose-50 shadow-lg' 
                          : 'hover:shadow-lg bg-white'
                      }`}
                      onClick={() => {
                        setSelectedSubtopic("B-");
                        setSelectedTheme("");
                        setSelectedElement("");
                      }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-rose-500 to-rose-700 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-md">
                          <span className="text-2xl font-bold text-white">B-</span>
                        </div>
                        <h3 className="font-bold text-lg mb-1">INDIVIDUEEL Verdedigend</h3>
                        <p className="text-xs text-gray-500">
                          {((iaDatabankData as any)?.data?.filter((el: any) => el.topic === "INDIVIDUEEL" && el.subtopic === "B-").length || 0)} elementen
                        </p>
                        {selectedSubtopic === "B-" && (
                          <div className="mt-2 text-xs text-rose-600 font-medium">
                            Geselecteerd ✓
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {/* TEAMTACTICS Theme Selection - Show theme tiles for B+, B-, and OMSCHAKELING */}
              {selectedTopic === "TEAMTACTISCH" && selectedSubtopic && !selectedTheme && 
               (selectedSubtopic === "B+" || selectedSubtopic === "B-" || selectedSubtopic === "OMSCH. B+/B-" || selectedSubtopic === "OMSCH. B-/B+") && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      Selecteer {selectedSubtopic} Thema
                    </h4>
                    <p className="text-sm text-gray-600">
                      Kies een tactisch thema voor deze training
                    </p>
                  </div>
                  
                  <div className={`grid gap-4 ${selectedSubtopic === "OMSCH. B+/B-" || selectedSubtopic === "OMSCH. B-/B+" ? 'grid-cols-2' : 'grid-cols-3'}`}>
                    {teamtacticsThemes[selectedSubtopic as keyof typeof teamtacticsThemes]?.map((theme) => (
                      <Card 
                        key={theme.id}
                        className="cursor-pointer transition-all duration-300 transform hover:scale-105 hover:shadow-lg bg-white"
                        onClick={() => {
                          setSelectedTheme(theme.id);
                          setSelectedElement("");
                        }}
                      >
                        <CardContent className="p-4 text-center">
                          <div className={`w-12 h-12 ${theme.color} rounded-lg flex items-center justify-center mx-auto mb-3 shadow-md`}>
                            <span className="text-white font-bold text-xs">
                              {selectedSubtopic === "B+" ? "B+" : 
                               selectedSubtopic === "B-" ? "B-" :
                               selectedSubtopic === "OMSCH. B+/B-" ? "B+→B-" :
                               "B-→B+"}
                            </span>
                          </div>
                          <h5 className="font-semibold text-sm mb-1">{theme.name}</h5>
                          <div className="text-xs text-gray-500">
                            {/* Count elements for this theme */}
                            {(() => {
                              const data = (iaDatabankData as any)?.data || [];
                              let themeElements = [];
                              
                              if (selectedSubtopic === "OMSCH. B+/B-" || selectedSubtopic === "OMSCH. B-/B+") {
                                // Voor OMSCHAKELING: filter op theme naam
                                themeElements = data.filter((el: any) => 
                                  el.topic === "TEAMTACTISCH" && 
                                  el.subtopic === selectedSubtopic && 
                                  el.theme === theme.name
                                );
                              } else {
                                // Voor B+ en B-: filter op theme naam matching
                                themeElements = data.filter((el: any) => 
                                  el.topic === "TEAMTACTISCH" && 
                                  el.subtopic === selectedSubtopic && 
                                  el.theme === theme.name
                                );
                              }
                              
                              return `${themeElements.length} elementen`;
                            })()}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* BASICS Elements Grid - Show when BASICS subcategory is selected */}
              {selectedTopic === "BASICS" && selectedSubtopic && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedSubtopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar BASICS subcategorieën
                    </button>
                  </div>
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      BASICS {selectedSubtopic} Elementen
                    </h4>
                    <p className="text-sm text-gray-600">
                      Selecteer elementen voor je training
                    </p>
                  </div>
                  
                  <div className="space-y-4 max-h-80 overflow-y-auto">
                    {getFilteredElements().map((element: any) => {
                      return (
                        <Card key={element.id} className="p-4">
                          <div className="mb-3">
                            <div className="flex items-center gap-2 mb-2">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                selectedSubtopic === "B+" 
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {element.subtopic}
                              </span>
                            </div>
                            <h5 className="font-medium text-base mb-1">{element.name}</h5>
                          </div>
                          
                          {/* Progression Level Tiles - Authentic from IADATABANK */}
                          <div className="grid grid-cols-2 gap-2">
                            {element.progressions?.map((progression: any) => {
                              const elementWithLevel = `${element.id}-${progression.level}`;
                              const isSelected = selectedElements.includes(elementWithLevel);
                              
                              return (
                                <Card 
                                  key={elementWithLevel}
                                  className={`cursor-pointer transition-all duration-200 ${
                                    isSelected 
                                      ? selectedSubtopic === "B+" 
                                        ? 'ring-2 ring-blue-500 bg-blue-50'
                                        : 'ring-2 ring-red-500 bg-red-50'
                                      : 'hover:shadow-sm bg-gray-50'
                                  }`}
                                  onClick={() => {
                                    if (isSelected) {
                                      setSelectedElements(prev => prev.filter(id => id !== elementWithLevel));
                                    } else {
                                      setSelectedElements(prev => [...prev, elementWithLevel]);
                                    }
                                  }}
                                >
                                  <CardContent className="p-3">
                                    <div className="text-center">
                                      <div className="font-medium text-sm mb-1">
                                        {progression.level}
                                      </div>
                                      <div className="text-xs text-gray-600">
                                        {progression.name}
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              );
                            })}
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TEAMTACTICS Elements Grid - Show when subcategory is selected */}
              {selectedTopic === "TEAMTACTISCH" && selectedSubtopic && (
                (selectedSubtopic === "OMSCH. B+/B-" || selectedSubtopic === "OMSCH. B-/B+") ||
                (selectedTheme && (selectedSubtopic === "B+" || selectedSubtopic === "B-"))
              ) && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      {selectedTheme ? 
                        `${selectedSubtopic} - ${teamtacticsThemes[selectedSubtopic as keyof typeof teamtacticsThemes]?.find(t => t.id === selectedTheme)?.name || selectedTheme}` :
                        `${selectedSubtopic} TEAMTACTICS Elementen`
                      }
                    </h4>
                    <p className="text-sm text-gray-600">
                      Selecteer elementen voor je training
                    </p>
                  </div>
                  
                  <div className="space-y-4 max-h-80 overflow-y-auto">
                    {getFilteredElements().map((element: any) => {
                      return (
                        <Card key={element.id} className="p-4">
                          <div className="mb-3">
                            <div className="flex items-center gap-2 mb-2">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                selectedSubtopic === "B+" 
                                  ? 'bg-green-100 text-green-800'
                                  : selectedSubtopic === "B-"
                                  ? 'bg-red-100 text-red-800' 
                                  : selectedSubtopic === "OMSCH. B+/B-"
                                  ? 'bg-purple-100 text-purple-800'
                                  : 'bg-orange-100 text-orange-800'
                              }`}>
                                {element.subtopic}
                              </span>
                              <span className="text-xs text-gray-500">{element.theme}</span>
                            </div>
                            <h5 className="font-medium text-base mb-1">{element.name}</h5>
                          </div>
                          
                          {/* Progression Level Tiles - Authentic from IADATABANK */}
                          <div className="grid grid-cols-2 gap-2">
                            {element.progressions?.map((progression: any) => {
                              const elementWithLevel = `${element.id}-${progression.level}`;
                              const isSelected = selectedElements.includes(elementWithLevel);
                              
                              return (
                                <Card 
                                  key={elementWithLevel}
                                  className={`cursor-pointer transition-all duration-200 ${
                                    isSelected 
                                      ? selectedSubtopic === "B+" 
                                        ? 'ring-2 ring-green-500 bg-green-50'
                                        : selectedSubtopic === "B-"
                                        ? 'ring-2 ring-red-500 bg-red-50'
                                        : selectedSubtopic === "OMSCH. B+/B-"
                                        ? 'ring-2 ring-purple-500 bg-purple-50'
                                        : 'ring-2 ring-orange-500 bg-orange-50'
                                      : 'hover:shadow-sm bg-gray-50'
                                  }`}
                                  onClick={() => {
                                    if (isSelected) {
                                      setSelectedElements(prev => prev.filter(id => id !== elementWithLevel));
                                    } else {
                                      setSelectedElements(prev => [...prev, elementWithLevel]);
                                    }
                                  }}
                                >
                                  <CardContent className="p-3">
                                    <div className="flex items-start justify-between">
                                      <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-1">
                                          <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                                            Level {progression.level}
                                          </span>
                                          <div className="flex">
                                            {Array.from({ length: progression.difficulty }).map((_, i) => (
                                              <div key={i} className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-1"></div>
                                            ))}
                                          </div>
                                        </div>
                                        <h6 className="font-medium text-xs mb-1">{progression.name}</h6>
                                        <p className="text-xs text-gray-600">{progression.description}</p>
                                      </div>
                                      <Checkbox 
                                        checked={isSelected}
                                        onCheckedChange={(checked) => {
                                          const elementProgressionId = `${element.id}-${progression.level}`;
                                          if (checked) {
                                            setSelectedElements([...selectedElements, elementProgressionId]);
                                          } else {
                                            setSelectedElements(selectedElements.filter(id => id !== elementProgressionId));
                                          }
                                        }}
                                        className="ml-2"
                                      />
                                    </div>
                                  </CardContent>
                                </Card>
                              );
                            })}
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* BASICS Elements Grid - Show when theme is selected */}
              {selectedTopic === "BASICS" && selectedSubtopic && selectedTheme && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedTheme("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar thema's
                    </button>
                  </div>
                  
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      {selectedSubtopic} - {basicsThemes[selectedSubtopic as keyof typeof basicsThemes]?.find(t => t.id === selectedTheme)?.name || selectedTheme}
                    </h4>
                    <p className="text-sm text-gray-600">
                      Selecteer elementen en moeilijkheidsniveaus voor je training
                    </p>
                  </div>
                  
                  <div className="space-y-4 max-h-80 overflow-y-auto">
                    {getFilteredElements().length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-gray-500">Geen elementen gevonden voor deze selectie.</p>
                        <p className="text-xs text-gray-400 mt-2">
                          Zoek voor: {selectedTopic} - {selectedSubtopic} - {selectedTheme}
                        </p>
                      </div>
                    ) : (
                      getFilteredElements().map((element: any) => (
                        <Card key={element.id} className="p-4">
                          <div className="mb-3">
                            <div className="flex items-center gap-2 mb-2">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                selectedSubtopic === "B+" 
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {element.subtopic}
                              </span>
                              <span className="text-xs text-gray-500">{element.skill}</span>
                            </div>
                            <h5 className="font-medium text-base mb-1">{element.name}</h5>
                          </div>
                          
                          {/* Progression Level Tiles - Authentic BASICS progressions */}
                          <div className="grid grid-cols-2 gap-2">
                            {element.progressions?.map((progression: any) => {
                              const elementWithLevel = `${element.id}-${progression.level}`;
                              const isSelected = selectedElements.includes(elementWithLevel);
                              
                              return (
                                <Card 
                                  key={elementWithLevel}
                                  className={`cursor-pointer transition-all duration-200 ${
                                    isSelected 
                                      ? selectedSubtopic === "B+" 
                                        ? 'ring-2 ring-blue-500 bg-blue-50'
                                        : 'ring-2 ring-red-500 bg-red-50'
                                      : 'hover:shadow-sm bg-gray-50'
                                  }`}
                                  onClick={() => toggleElementSelection(elementWithLevel)}
                                >
                                  <CardContent className="p-3">
                                    <div className="text-center">
                                      <div className={`w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center text-xs font-bold ${
                                        isSelected 
                                          ? selectedSubtopic === "B+" 
                                            ? 'bg-blue-500 text-white'
                                            : 'bg-red-500 text-white'
                                          : 'bg-gray-300 text-gray-600'
                                      }`}>
                                        {progression.level}
                                      </div>
                                      <div className="text-xs font-medium mb-1">
                                        {progression.name}
                                      </div>
                                      {isSelected && (
                                        <div className="text-xs text-green-600 font-medium">
                                          ✓ Geselecteerd
                                        </div>
                                      )}
                                    </div>
                                  </CardContent>
                                </Card>
                              );
                            })}
                          </div>
                        </Card>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* Scherm 2.5: TEAMTACTICS Theme Selection - For all subcategories */}
              {selectedTopic === "TEAMTACTISCH" && selectedSubtopic && !selectedTheme && teamtacticsThemes[selectedSubtopic as keyof typeof teamtacticsThemes] && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedSubtopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar subcategorieën
                    </button>
                  </div>
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      {selectedSubtopic === "B+" ? "Kies een aanvallend thema:" :
                       selectedSubtopic === "B-" ? "Kies een verdedigend thema:" :
                       selectedSubtopic === "OMSCH. B+/B-" ? "Kies een omschakelings thema (B+ naar B-):" :
                       selectedSubtopic === "OMSCH. B-/B+" ? "Kies een omschakelings thema (B- naar B+):" :
                       "Kies een thema:"}
                    </h4>
                  </div>

                  {/* Selected Themes Summary for TEAMTACTICS */}
                  {selectedThemes.length > 0 && (
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200 mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-green-800">
                          Geselecteerde Thema's ({selectedThemes.length})
                        </h5>
                        <div className="flex gap-2">
                          <Button
                            onClick={handleSaveSelection}
                            disabled={isSaving}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 text-xs"
                          >
                            {isSaving ? "Opslaan..." : `Opslaan (${selectedThemes.length})`}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedThemes([])}
                            className="text-red-600 border-red-200 hover:bg-red-50 px-2 py-1 text-xs"
                          >
                            Wissen
                          </Button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedThemes.map((themeId) => {
                          const themeName = getThemeName(themeId);
                          return (
                            <div
                              key={themeId}
                              className="inline-flex items-center gap-1 px-2 py-1 bg-white rounded text-xs border"
                            >
                              <span className="font-medium">{themeName.name}</span>
                              <button
                                onClick={() => setSelectedThemes(selectedThemes.filter(t => t !== themeId))}
                                className="text-green-600 hover:text-red-500"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 gap-3">
                    {teamtacticsThemes[selectedSubtopic as keyof typeof teamtacticsThemes]?.map((theme) => (
                      <Card 
                        key={theme.id}
                        className="cursor-pointer transition-all duration-200 hover:shadow-md bg-white"
                        onClick={() => setSelectedTheme(theme.id)}
                      >
                        <CardContent className="p-4 relative">
                          {/* Selectie checkbox */}
                          <div className="absolute top-2 right-2">
                            <input 
                              type="checkbox"
                              checked={selectedThemes.includes(theme.id)}
                              onChange={(e) => {
                                e.stopPropagation();
                                if (e.target.checked) {
                                  setSelectedThemes(prev => [...prev, theme.id]);
                                } else {
                                  setSelectedThemes(prev => prev.filter(id => id !== theme.id));
                                }
                              }}
                              className="w-4 h-4 text-blue-600 rounded border border-gray-300 focus:ring-blue-500"
                            />
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={`w-12 h-12 ${theme.color} rounded-lg flex items-center justify-center`}>
                                <Users className="h-6 w-6 text-white" />
                              </div>
                              <div>
                                <h5 className="font-medium text-base">{theme.name}</h5>
                                <p className="text-sm text-gray-600">
                                  {(() => {
                                    const themeElementMapping = {
                                      'opbouwen': 9,
                                      'voortgang_infiltratie': 9,
                                      'scoren': 9,
                                      'druk_zetten': 9,
                                      'compact_verdedigen': 9,
                                      'beschermen_eigen_doel': 10,
                                      'tegen_druk_zetten': 4,
                                      'hervormen_opstelling': 3,
                                      'tegenaanval': 4,
                                      'op_balbezit_spelen': 3
                                    };
                                    return themeElementMapping[theme.id as keyof typeof themeElementMapping] || 0;
                                  })()} elementen
                                </p>
                              </div>
                            </div>
                            <ChevronRight className="h-5 w-5 text-gray-400" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Save at Theme Level for TEAMTACTICS */}
                  {selectedThemes.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('theme')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Thema's ({selectedThemes.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* FYSIEK Theme Selection */}
              {selectedTopic === "FYSIEK" && selectedSubtopic && !selectedTheme && getThemeConfig(selectedTopic, selectedSubtopic).length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedSubtopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar subcategorieën
                    </button>
                  </div>
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      Kies {selectedSubtopic} FYSIEK thema:
                    </h4>
                  </div>

                  {/* Selected Themes Summary for FYSIEK */}
                  {selectedThemes.length > 0 && (
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200 mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-green-800">
                          Geselecteerde Thema's ({selectedThemes.length})
                        </h5>
                        <div className="flex gap-2">
                          <Button
                            onClick={handleSaveSelection}
                            disabled={isSaving}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 text-xs"
                          >
                            {isSaving ? "Opslaan..." : `Opslaan (${selectedThemes.length})`}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedThemes([])}
                            className="text-red-600 border-red-200 hover:bg-red-50 px-2 py-1 text-xs"
                          >
                            Wissen
                          </Button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedThemes.map((themeId) => {
                          const themeName = getThemeName(themeId);
                          return (
                            <div
                              key={themeId}
                              className="inline-flex items-center gap-1 px-2 py-1 bg-white rounded text-xs border"
                            >
                              <span className="font-medium">{themeName.name}</span>
                              <button
                                onClick={() => setSelectedThemes(selectedThemes.filter(t => t !== themeId))}
                                className="text-green-600 hover:text-red-500"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 gap-3">
                    {getThemeConfig(selectedTopic, selectedSubtopic).map((theme) => (
                      <Card 
                        key={theme.id}
                        className="cursor-pointer transition-all duration-200 hover:shadow-md bg-white"
                        onClick={() => setSelectedTheme(theme.id)}
                      >
                        <CardContent className="p-4 text-center relative">
                          {/* Selectie checkbox */}
                          <div className="absolute top-2 right-2">
                            <input 
                              type="checkbox"
                              checked={selectedThemes.includes(theme.id)}
                              onChange={(e) => {
                                e.stopPropagation();
                                if (e.target.checked) {
                                  setSelectedThemes(prev => [...prev, theme.id]);
                                } else {
                                  setSelectedThemes(prev => prev.filter(id => id !== theme.id));
                                }
                              }}
                              className="w-4 h-4 text-blue-600 rounded border border-gray-300 focus:ring-blue-500"
                            />
                          </div>
                          
                          <div className={`w-12 h-12 ${theme.color} rounded-lg flex items-center justify-center mx-auto mb-3 shadow-md`}>
                            <Zap className="h-6 w-6 text-white" />
                          </div>
                          <h5 className="font-semibold text-sm mb-1">{theme.name}</h5>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Save at Theme Level for FYSIEK */}
                  {selectedThemes.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('theme')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Thema's ({selectedThemes.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* MENTAAL Theme Selection */}
              {selectedTopic === "MENTAAL" && selectedSubtopic && !selectedTheme && getThemeConfig(selectedTopic, selectedSubtopic).length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedSubtopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar subcategorieën
                    </button>
                  </div>
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      Kies {selectedSubtopic} MENTAAL thema:
                    </h4>
                  </div>

                  {/* Selected Themes Summary for MENTAAL */}
                  {selectedThemes.length > 0 && (
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200 mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-green-800">
                          Geselecteerde Thema's ({selectedThemes.length})
                        </h5>
                        <div className="flex gap-2">
                          <Button
                            onClick={handleSaveSelection}
                            disabled={isSaving}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 text-xs"
                          >
                            {isSaving ? "Opslaan..." : `Opslaan (${selectedThemes.length})`}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedThemes([])}
                            className="text-red-600 border-red-200 hover:bg-red-50 px-2 py-1 text-xs"
                          >
                            Wissen
                          </Button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedThemes.map((themeId) => {
                          const themeName = getThemeName(themeId);
                          return (
                            <div
                              key={themeId}
                              className="inline-flex items-center gap-1 px-2 py-1 bg-white rounded text-xs border"
                            >
                              <span className="font-medium">{themeName.name}</span>
                              <button
                                onClick={() => setSelectedThemes(selectedThemes.filter(t => t !== themeId))}
                                className="text-green-600 hover:text-red-500"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 gap-3">
                    {getThemeConfig(selectedTopic, selectedSubtopic).map((theme) => (
                      <Card 
                        key={theme.id}
                        className="cursor-pointer transition-all duration-200 hover:shadow-md bg-white"
                        onClick={() => setSelectedTheme(theme.id)}
                      >
                        <CardContent className="p-4 text-center relative">
                          {/* Selectie checkbox */}
                          <div className="absolute top-2 right-2">
                            <input 
                              type="checkbox"
                              checked={selectedThemes.includes(theme.id)}
                              onChange={(e) => {
                                e.stopPropagation();
                                if (e.target.checked) {
                                  setSelectedThemes(prev => [...prev, theme.id]);
                                } else {
                                  setSelectedThemes(prev => prev.filter(id => id !== theme.id));
                                }
                              }}
                              className="w-4 h-4 text-blue-600 rounded border border-gray-300 focus:ring-blue-500"
                            />
                          </div>
                          
                          <div className={`w-12 h-12 ${theme.color} rounded-lg flex items-center justify-center mx-auto mb-3 shadow-md`}>
                            <Brain className="h-6 w-6 text-white" />
                          </div>
                          <h5 className="font-semibold text-sm mb-1">{theme.name}</h5>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Save at Theme Level for MENTAAL */}
                  {selectedThemes.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('theme')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Thema's ({selectedThemes.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* VARIA Direct Activity Selection - No themes needed */}
              {selectedTopic === "VARIA" && !selectedTheme && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedTopic("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar categorieën
                    </button>
                  </div>
                  
                  <div className="text-center mb-6">
                    <h4 className="font-medium text-gray-900 text-lg">
                      Kies VARIA activiteit:
                    </h4>
                    <p className="text-sm text-gray-600 mt-2">
                      Selecteer een activiteit en voeg eventueel extra details toe
                    </p>
                  </div>

                  {/* Selected Themes Summary for VARIA */}
                  {selectedThemes.length > 0 && (
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200 mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-green-800">
                          Geselecteerde Activiteiten ({selectedThemes.length})
                        </h5>
                        <div className="flex gap-2">
                          <Button
                            onClick={handleSaveSelection}
                            disabled={isSaving}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 text-xs"
                          >
                            {isSaving ? "Opslaan..." : `Opslaan (${selectedThemes.length})`}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedThemes([])}
                            className="text-red-600 border-red-200 hover:bg-red-50 px-2 py-1 text-xs"
                          >
                            Wissen
                          </Button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedThemes.map((themeId) => {
                          const themeName = getThemeName(themeId);
                          return (
                            <div
                              key={themeId}
                              className="inline-flex items-center gap-1 px-2 py-1 bg-white rounded text-xs border"
                            >
                              <span className="font-medium">{themeName.name}</span>
                              <button
                                onClick={() => setSelectedThemes(selectedThemes.filter(t => t !== themeId))}
                                className="text-green-600 hover:text-red-500"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  
                  {/* VARIA Activity Grid */}
                  <div className="grid grid-cols-2 gap-4">
                    {variaThemes["Activiteiten"]?.map((activity) => (
                      <Card 
                        key={activity.id}
                        className="cursor-pointer transition-all duration-300 transform hover:scale-105 hover:shadow-lg bg-white"
                        onClick={() => {
                          // Toggle selection
                          if (selectedThemes.includes(activity.id)) {
                            setSelectedThemes(prev => prev.filter(id => id !== activity.id));
                          } else {
                            setSelectedThemes(prev => [...prev, activity.id]);
                          }
                        }}
                      >
                        <CardContent className="p-4 text-center relative">
                          {/* Selection checkbox */}
                          <div className="absolute top-2 right-2">
                            <input 
                              type="checkbox"
                              checked={selectedThemes.includes(activity.id)}
                              onChange={(e) => {
                                e.stopPropagation();
                                if (e.target.checked) {
                                  setSelectedThemes(prev => [...prev, activity.id]);
                                } else {
                                  setSelectedThemes(prev => prev.filter(id => id !== activity.id));
                                }
                              }}
                              className="w-4 h-4 text-blue-600 rounded border border-gray-300 focus:ring-blue-500"
                            />
                          </div>
                          
                          <div className={`w-12 h-12 ${activity.color} rounded-lg flex items-center justify-center mx-auto mb-3 shadow-md`}>
                            <span className="text-white font-bold text-xs">
                              {activity.id === "competitiewedstrijd" ? "CW" :
                               activity.id === "oefenwedstrijd" ? "OW" :
                               activity.id === "bekerwedstrijd" ? "BW" :
                               activity.id === "extra_training" ? "ET" :
                               activity.id === "video_training" ? "VT" :
                               activity.id === "teambuilding" ? "TB" :
                               "FT"}
                            </span>
                          </div>
                          <h5 className="font-semibold text-sm mb-1">{activity.name}</h5>
                          <div className="text-xs text-gray-500">
                            {activity.id.includes("wedstrijd") ? "Wedstrijd" : 
                             activity.id.includes("training") ? "Training" : 
                             "Activiteit"}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Activity Notes Input - CRITICAL FOR VARIA DETAILS */}
                  <div className="mt-6 space-y-3">
                    <label className="text-sm font-medium text-gray-700 block">
                      Extra details (optioneel)
                    </label>
                    <textarea
                      value={activityNotes}
                      onChange={(e) => setActivityNotes(e.target.value)}
                      placeholder="Bijv. 'tegen Club Brugge', 'thuis wedstrijd', 'uitwedstrijd Antwerp', 'stage locatie', etc."
                      rows={3}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    />
                    <p className="text-xs text-gray-500">
                      Voeg hier tegenstander, locatie (thuis/uit), of andere relevante details toe
                    </p>
                  </div>

                  {/* Save at Theme Level for VARIA */}
                  {selectedThemes.length > 0 && (
                    <div className="flex justify-center mt-6">
                      <button
                        onClick={() => handleSaveTraining('theme')}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                      >
                        Opslaan Geselecteerde Activiteiten ({selectedThemes.length})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Scherm 3: Elements List - Show elements only after theme selection for TEAMTACTICS */}
              {selectedTopic && selectedSubtopic && !selectedElement && 
               ((selectedTopic === "BASICS" || selectedTopic === "PHYSIEK" || selectedTopic === "MENTAAL") || 
                (selectedTopic === "TEAMTACTISCH" && selectedTheme)) && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => {
                        if (selectedTopic === "TEAMTACTISCH") {
                          setSelectedTheme("");
                        } else {
                          setSelectedSubtopic("");
                        }
                      }}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      {selectedTopic === "TEAMTACTISCH" ? "Terug naar thema's" : "Terug naar subcategorieën"}
                    </button>
                  </div>
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      {selectedTopic === "TEAMTACTISCH" && selectedTheme
                        ? `${selectedTheme} Elementen`
                        : selectedTopic === "BASICS"
                        ? `${selectedSubtopic === "B+" ? "Aanvallende" : "Verdedigende"} ${selectedTopic} Elementen`
                        : `${selectedSubtopic} ${selectedTopic} Elementen`
                      }
                    </h4>
                    <p className="text-sm text-gray-600">
                      Klik op een element om moeilijkheidsgraden te zien
                    </p>
                  </div>

                  {/* Selected Elements Summary at element level - Works for all categories */}
                  {selectedElements.length > 0 && (
                    <div className="mb-4 p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-orange-800">
                          Geselecteerde Elementen ({selectedElements.length})
                        </h5>
                        <div className="flex gap-2">
                          <Button
                            onClick={handleSaveSelection}
                            disabled={isSaving}
                            size="sm"
                            className="bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 text-xs"
                          >
                            {isSaving ? "Opslaan..." : `Opslaan (${selectedElements.length})`}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedElements([])}
                            className="text-red-600 border-red-200 hover:bg-red-50 px-2 py-1 text-xs"
                          >
                            Wissen
                          </Button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedElements.map((element) => {
                          if (!element || !element.id) return null;
                          
                          return (
                            <div
                              key={element.id}
                              className="inline-flex items-center gap-1 px-2 py-1 bg-white rounded text-xs border"
                            >
                              <span className="font-medium">{element.name}</span>
                              <span className="text-orange-600">{element.theme}</span>
                              <button
                                onClick={() => setSelectedElements(selectedElements.filter(el => el.id !== element.id))}
                                className="text-gray-400 hover:text-red-500"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 gap-3 max-h-80 overflow-y-auto">
                    {getFilteredElements().map((element: any) => (
                      <Card 
                        key={element.id}
                        className="cursor-pointer transition-all duration-200 hover:shadow-md bg-white"
                        onClick={() => setSelectedElement(element.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                  selectedSubtopic === "B+" 
                                    ? 'bg-green-100 text-green-800' 
                                    : 'bg-red-100 text-red-800'
                                }`}>
                                  {element.subtopic}
                                </span>
                                <span className="text-xs text-gray-500">{element.theme}</span>
                              </div>
                              <h5 className="font-medium text-base mb-1">{element.name}</h5>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-gray-600">
                                  {element.progressions?.length || 0} moeilijkheidsniveaus
                                </span>
                                <div className="flex">
                                  {Array.from({ length: Math.min(element.progressions?.length || 0, 6) }).map((_, i) => (
                                    <div key={i} className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-1"></div>
                                  ))}
                                </div>
                              </div>
                            </div>
                            <ChevronRight className="h-5 w-5 text-gray-400" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Scherm 4: Element Difficulty Levels - Show when specific element is selected */}
              {selectedTopic && selectedSubtopic && selectedElement && (selectedTopic === "BASICS" || selectedTopic === "TEAMTACTISCH" || selectedTopic === "PHYSIEK" || selectedTopic === "MENTAAL") && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <button 
                      onClick={() => setSelectedElement("")}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Terug naar elementen
                    </button>
                  </div>
                  <div className="text-center">
                    <h4 className="font-medium text-gray-900">
                      {getFilteredElements().find((el: any) => el.id === selectedElement)?.name} Moeilijkheidsgraden
                    </h4>
                    <p className="text-sm text-gray-600">
                      Selecteer de gewenste moeilijkheidsgraden
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {getFilteredElements()
                      .find((el: any) => el.id === selectedElement)
                      ?.progressions?.map((progression: any) => {
                        const elementWithLevel = `${selectedElement}-${progression.level}`;
                        const isSelected = selectedElements.includes(elementWithLevel);
                        
                        return (
                          <Card 
                            key={elementWithLevel}
                            className={`cursor-pointer transition-all duration-200 ${
                              isSelected 
                                ? selectedSubtopic === "B+" 
                                  ? 'ring-2 ring-green-500 bg-green-50' 
                                  : 'ring-2 ring-red-500 bg-red-50'
                                : 'hover:shadow-sm bg-gray-50'
                            }`}
                            onClick={() => {
                              if (isSelected) {
                                setSelectedElements(prev => prev.filter(id => id !== elementWithLevel));
                              } else {
                                setSelectedElements(prev => [...prev, elementWithLevel]);
                              }
                            }}
                          >
                            <CardContent className="p-3">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                                      Level {progression.level}
                                    </span>
                                    <div className="flex">
                                      {Array.from({ length: progression.difficulty }).map((_, i) => (
                                        <div key={i} className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-1"></div>
                                      ))}
                                    </div>
                                  </div>
                                  <h6 className="font-medium text-xs mb-1">{progression.name}</h6>
                                  <p className="text-xs text-gray-600">{progression.description}</p>
                                </div>
                                <Checkbox 
                                  checked={isSelected}
                                  onChange={() => {}}
                                  className="ml-2"
                                />
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* Selection Summary */}
              {selectedElements.length > 0 && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-blue-900">Geselecteerde Elementen</h4>
                      <p className="text-sm text-blue-700">
                        {selectedElements.length} {selectedSubtopic || selectedTopic} elementen geselecteerd
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-blue-900">{selectedElements.length}</div>
                      <div className="text-xs text-blue-600">elementen</div>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Comprehensive Selection Summary */}
            {(selectedCategories.length > 0 || selectedSubcategories.length > 0 || selectedThemes.length > 0 || selectedElements.length > 0) && (
              <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border border-blue-200">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="font-medium text-gray-900">
                    Alle Geselecteerde Items
                  </h5>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedCategories([]);
                      setSelectedSubcategories([]);
                      setSelectedThemes([]);
                      setSelectedElements([]);
                    }}
                    className="text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Alles Wissen
                  </Button>
                </div>

                {/* Selected Categories */}
                {selectedCategories.length > 0 && (
                  <div className="mb-3">
                    <h6 className="text-sm font-medium text-purple-700 mb-2">Categorieën ({selectedCategories.length})</h6>
                    <div className="flex flex-wrap gap-2">
                      {selectedCategories.map((category) => (
                        <div
                          key={category}
                          className="inline-flex items-center gap-2 px-3 py-1 bg-purple-100 text-purple-800 rounded-full border text-sm"
                        >
                          <span className="font-medium">{topicConfig[category as keyof typeof topicConfig]?.display || category}</span>
                          <button
                            onClick={() => setSelectedCategories(selectedCategories.filter(c => c !== category))}
                            className="text-purple-600 hover:text-red-500"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Selected Subcategories */}
                {selectedSubcategories.length > 0 && (
                  <div className="mb-3">
                    <h6 className="text-sm font-medium text-blue-700 mb-2">Subcategorieën ({selectedSubcategories.length})</h6>
                    <div className="flex flex-wrap gap-2">
                      {selectedSubcategories.map((subcategory) => (
                        <div
                          key={subcategory}
                          className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-800 rounded-full border text-sm"
                        >
                          <span className="font-medium">{subcategory}</span>
                          <button
                            onClick={() => setSelectedSubcategories(selectedSubcategories.filter(s => s !== subcategory))}
                            className="text-blue-600 hover:text-red-500"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Selected Themes */}
                {selectedThemes.length > 0 && (
                  <div className="mb-3">
                    <h6 className="text-sm font-medium text-green-700 mb-2">Thema's ({selectedThemes.length})</h6>
                    <div className="flex flex-wrap gap-2">
                      {selectedThemes.map((themeId) => {
                        const themeName = getThemeName(themeId);
                        return (
                          <div
                            key={themeId}
                            className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-800 rounded-full border text-sm"
                          >
                            <span className="font-medium">{themeName.name}</span>
                            <button
                              onClick={() => setSelectedThemes(selectedThemes.filter(t => t !== themeId))}
                              className="text-green-600 hover:text-red-500"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Selected Elements */}
                {selectedElements.length > 0 && (
                  <div>
                    <h6 className="text-sm font-medium text-orange-700 mb-2">Elementen ({selectedElements.length})</h6>
                    <div className="flex flex-wrap gap-2">
                      {selectedElements.map((element) => {
                        if (!element || !element.id) return null;
                        
                        return (
                          <div
                            key={element.id}
                            className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100 text-orange-800 rounded-full border text-sm"
                          >
                            <span className="font-medium">{element.name}</span>
                            <span className="text-orange-600">{element.theme}</span>
                            <button
                              onClick={() => setSelectedElements(selectedElements.filter(el => el.id !== element.id))}
                              className="text-orange-600 hover:text-red-500"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Old Selected Elements Summary - Keep for backward compatibility */}
            {selectedElements.length > 0 && (
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="font-medium text-blue-900">
                    Geselecteerde Elementen ({selectedElements.length})
                  </h5>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedElements([])}
                    className="text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Alles Wissen
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedElements.map((element) => {
                    if (!element || !element.id) return null;
                    
                    return (
                      <div
                        key={element.id}
                        className="inline-flex items-center gap-2 px-3 py-1 bg-white rounded-full border text-sm"
                      >
                        <span className="font-medium">{element.name}</span>
                        <span className="text-blue-600">{element.theme}</span>
                        <button
                          onClick={() => setSelectedElements(selectedElements.filter(el => el.id !== element.id))}
                          className="text-gray-400 hover:text-red-500 ml-1"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-2 pt-4 border-t">
              <Button 
                variant="outline" 
                onClick={() => setShowThemeDialog(false)}
              >
                Annuleren
              </Button>
              <Button 
                onClick={() => handleSaveTraining('element')}
                disabled={selectedElements.length === 0 && selectedThemes.length === 0}
              >
                Training Opslaan ({selectedElements.length + selectedThemes.length} items)
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Training Bevestigen</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-lg font-medium">
                Training inplannen voor:
              </p>
              <p className="text-xl font-bold text-blue-600">
                {selectedDate ? new Date(selectedDate).toLocaleDateString('nl-NL', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                }) : ''}
              </p>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Geselecteerde inhoud:</h4>
              
              {selectedCategories.length > 0 && (
                <div className="mb-2">
                  <span className="text-sm font-medium text-purple-700">Categorieën: </span>
                  <span className="text-sm">
                    {selectedCategories.map(cat => topicConfig[cat as keyof typeof topicConfig]?.display || cat).join(', ')}
                  </span>
                </div>
              )}

              {selectedSubcategories.length > 0 && (
                <div className="mb-2">
                  <span className="text-sm font-medium text-blue-700">Subcategorieën: </span>
                  <span className="text-sm">{selectedSubcategories.join(', ')}</span>
                </div>
              )}

              {selectedThemes.length > 0 && (
                <div className="mb-2">
                  <span className="text-sm font-medium text-green-700">Thema's: </span>
                  <span className="text-sm">{selectedThemes.join(', ')}</span>
                </div>
              )}

              {selectedElements.length > 0 && (
                <div>
                  <span className="text-sm font-medium text-orange-700">Elementen: </span>
                  <span className="text-sm">{selectedElements.length} geselecteerd</span>
                </div>
              )}
            </div>

            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                variant="outline" 
                onClick={() => setShowConfirmation(false)}
              >
                Terug
              </Button>
              <Button 
                onClick={confirmSaveTraining}
                disabled={isSaving}
                className="bg-green-600 hover:bg-green-700"
              >
                {isSaving ? "Opslaan..." : "Bevestigen & Opslaan"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Time Selection Dialog */}
      <Dialog open={showTimeDialog} onOpenChange={setShowTimeDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Nieuwe Training - {selectedDate && format(selectedDate, 'dd MMMM yyyy', { locale: nl })}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 block mb-2">Starttijd</label>
                <input
                  type="time"
                  value={trainingStartTime}
                  onChange={(e) => setTrainingStartTime(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 block mb-2">Eindtijd</label>
                <input
                  type="time"
                  value={trainingEndTime}
                  onChange={(e) => setTrainingEndTime(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="text-sm text-blue-800">
                <strong>Training Details:</strong><br/>
                Datum: {selectedDate && format(selectedDate, 'EEEE dd MMMM yyyy', { locale: nl })}<br/>
                Tijd: {trainingStartTime} - {trainingEndTime}
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowTimeDialog(false);
                }}
                className="flex-1"
              >
                Annuleren
              </Button>
              <Button 
                onClick={() => {
                  console.log('Time dialog -> theme dialog, current times:', { trainingStartTime, trainingEndTime });
                  setShowTimeDialog(false);
                  setShowThemeDialog(true);
                }}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                Verder naar Thema's
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>



      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-red-600">Training Definitief Wissen</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-red-50 p-4 rounded-lg border border-red-200">
              <div className="text-sm text-red-800">
                <strong>Let op:</strong> Deze actie kan niet ongedaan worden gemaakt!
                <br/><br/>
                <strong>Training details:</strong><br/>
                Datum: {sessionToDelete?.date && format(parseISO(sessionToDelete.date), 'EEEE dd MMMM yyyy', { locale: nl })}<br/>
                Tijd: {sessionToDelete?.startTime || '20:00'} - {sessionToDelete?.endTime || '21:30'}<br/>
                Thema's: {sessionToDelete?.selectedItems?.map((item: any) => item.name).join(', ') || 'Geen thema\'s'}
              </div>
            </div>
            
            <div className="text-sm text-gray-600">
              Weet je zeker dat je deze training wilt wissen?
            </div>
            
            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowDeleteDialog(false);
                  setSessionToDelete(null);
                }}
                className="flex-1"
              >
                Annuleren
              </Button>
              <Button 
                onClick={handleDeleteSession}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white"
              >
                Definitief Wissen
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Session Dialog - Complete Edit */}
      {showEditDialog && sessionToEdit && (
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Training Bewerken - Sessie #{sessionToEdit.id}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Current Session Info with Unique ID */}
              <div className="text-sm text-blue-800 bg-blue-50 p-3 rounded border border-blue-200">
                <div className="font-semibold mb-1">Training Sessie ID: {sessionToEdit.id}</div>
                <div><strong>Thema:</strong> {sessionToEdit?.selectedItems?.[0]?.name || 'Training'}</div>
                <div><strong>Huidige tijd:</strong> {sessionToEdit?.startTime || '20:00'} - {sessionToEdit?.endTime || '21:45'}</div>
                {sessionToEdit?.notes && <div><strong>Notities:</strong> {sessionToEdit.notes}</div>}
              </div>
              
              {/* Date Selection */}
              <div>
                <Label htmlFor="edit-date" className="text-sm font-medium text-blue-900">Datum</Label>
                <Input 
                  id="edit-date" 
                  type="date" 
                  value={selectedDate ? format(selectedDate, 'yyyy-MM-dd') : ''}
                  onChange={(e) => {
                    if (e.target.value) {
                      setSelectedDate(new Date(e.target.value + 'T00:00:00'));
                    }
                  }}
                  className="w-full mt-1 border-2 border-blue-200 focus:border-blue-500" 
                />
              </div>
              
              {/* Time Selection */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-start-time" className="text-sm font-medium text-blue-900">Start Tijd</Label>
                  <Input 
                    id="edit-start-time" 
                    type="time" 
                    value={trainingStartTime}
                    onChange={(e) => setTrainingStartTime(e.target.value)}
                    className="w-full mt-1 text-lg font-mono border-2 border-blue-200 focus:border-blue-500" 
                  />
                </div>
                <div>
                  <Label htmlFor="edit-end-time" className="text-sm font-medium text-blue-900">Eind Tijd</Label>
                  <Input 
                    id="edit-end-time" 
                    type="time" 
                    value={trainingEndTime}
                    onChange={(e) => setTrainingEndTime(e.target.value)}
                    className="w-full mt-1 text-lg font-mono border-2 border-blue-200 focus:border-blue-500" 
                  />
                </div>
              </div>
              
              {/* VARIA Notes */}
              <div>
                <Label htmlFor="edit-notes" className="text-sm font-medium text-blue-900">VARIA Opmerking</Label>
                <Input 
                  id="edit-notes" 
                  type="text" 
                  value={activityNotes}
                  onChange={(e) => setActivityNotes(e.target.value)}
                  placeholder="bijv. Stage: Longlier P1, Tegenstander: KV Mechelen, etc."
                  className="w-full mt-1 border-2 border-blue-200 focus:border-blue-500" 
                />
              </div>
              
              {/* Theme Selection Button */}
              <div>
                <Label className="text-sm font-medium text-blue-900">Thema's & Inhoud</Label>
                <div className="mt-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      // Reset selections and open theme dialog
                      setSelectedCategories([]);
                      setSelectedSubcategories([]);
                      setSelectedThemes([]);
                      setSelectedElements([]);
                      setShowThemeDialog(true);
                    }}
                    className="w-full border-2 border-blue-200 hover:border-blue-500"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Thema's & Inhoud Wijzigen
                  </Button>
                </div>
              </div>
              
              {/* Current Content Display */}
              {sessionToEdit?.selectedItems && sessionToEdit.selectedItems.length > 0 && (
                <div className="bg-blue-50 p-3 rounded border border-blue-200">
                  <div className="text-sm font-medium text-blue-900 mb-2">Huidige inhoud:</div>
                  <div className="space-y-1">
                    {sessionToEdit.selectedItems.map((item: any, index: number) => (
                      <div key={index} className="text-xs text-blue-700 bg-white px-2 py-1 rounded">
                        {item.name || item.elementId || 'Training Element'}
                        {item.theme && item.theme !== 'Element' && ` (${item.theme})`}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Preview */}
              <div className="text-xs text-blue-700 bg-blue-100 rounded p-2">
                <strong>Wijziging preview:</strong><br/>
                Datum: {selectedDate ? format(selectedDate, 'EEEE dd MMMM yyyy', { locale: nl }) : 'Geen datum'}<br/>
                Tijd: {trainingStartTime} tot {trainingEndTime}<br/>
                {activityNotes && `Opmerking: ${activityNotes}`}
              </div>
              
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowEditDialog(false);
                    setSessionToEdit(null);
                    setActivityNotes('');
                  }}
                >
                  Annuleren
                </Button>
                <Button
                  onClick={handleUpdateSessionTime}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Training Bijwerken
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

