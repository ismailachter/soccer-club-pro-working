import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Video, Play, Trash2, FileVideo } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { BackToMenu } from "@/components/ui/back-to-menu";

interface VideoUploadData {
  title: string;
  description: string;
  teamId: string;
  analysisType: 'full_match' | 'tactical_analysis' | 'player_performance' | 'training_session' | 'individual_analysis';
  season: string;
  opponent?: string;
  matchResult?: string;
  selectedPlayers?: string[]; // for individual analysis
}

export default function VideoUpload() {
  const [file, setFile] = useState<File | null>(null);
  const [uploadData, setUploadData] = useState<VideoUploadData>({
    title: '',
    description: '',
    teamId: '',
    analysisType: 'full_match',
    season: '2025-2026',
    opponent: '',
    matchResult: '',
    selectedPlayers: []
  });
  const [dragActive, setDragActive] = useState(false);
  const { toast } = useToast();

  // Get teams for selection
  const { data: teams } = useQuery({
    queryKey: ["/api/teams"],
  });

  // Get players for individual analysis
  const { data: players } = useQuery({
    queryKey: ["/api/users"],
    enabled: uploadData.analysisType === 'individual_analysis' && uploadData.teamId !== '',
  });

  const uploadMutation = useMutation({
    mutationFn: async ({ file, data }: { file: File; data: VideoUploadData }) => {
      const formData = new FormData();
      formData.append('video', file);
      Object.entries(data).forEach(([key, value]) => {
        if (value) formData.append(key, value);
      });

      const response = await fetch('/api/videos/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText);
      }

      return response.json();
    },
    onSuccess: (result) => {
      toast({
        title: "Video geüpload!",
        description: `${result.video.title} is succesvol geüpload (${result.fileInfo.size})`,
      });
      setFile(null);
      setUploadData({
        title: '',
        description: '',
        teamId: '',
        analysisType: 'full_match',
        season: '2025-2026',
        opponent: '',
        matchResult: '',
        selectedPlayers: []
      });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
    },
    onError: (error) => {
      toast({
        title: "Upload mislukt",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (selectedFile: File) => {
    // Validate file type
    const allowedTypes = ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/webm', 'video/x-ms-wmv'];
    if (!allowedTypes.includes(selectedFile.type)) {
      toast({
        title: "Ongeldig bestandstype",
        description: "Alleen MP4, MOV, AVI, WebM en WMV bestanden zijn toegestaan",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (10MB)
    if (selectedFile.size > 10 * 1024 * 1024) {
      toast({
        title: "Bestand te groot",
        description: "Maximum bestandsgrootte is 10MB",
        variant: "destructive",
      });
      return;
    }

    setFile(selectedFile);
  };

  const handleSubmit = () => {
    if (!file) {
      toast({
        title: "Geen bestand geselecteerd",
        description: "Selecteer eerst een video bestand",
        variant: "destructive",
      });
      return;
    }

    if (!uploadData.title || !uploadData.teamId) {
      toast({
        title: "Verplichte velden ontbreken",
        description: "Vul minimaal titel en team in",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate({ file, data: uploadData });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Video className="h-8 w-8 text-blue-600" />
          <div>
            <h1 className="text-3xl font-bold">Video Upload</h1>
            <p className="text-muted-foreground">Upload match of training video's voor analyse</p>
          </div>
        </div>
        <BackToMenu />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Upload className="h-5 w-5" />
              <span>Video Bestand</span>
            </CardTitle>
            <CardDescription>
              Sleep je video bestand hiernaartoe of klik om te selecteren
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div
              className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                dragActive
                  ? 'border-blue-500 bg-blue-50'
                  : file
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <input
                type="file"
                accept="video/mp4,video/quicktime,video/x-msvideo,video/webm,video/x-ms-wmv"
                onChange={(e) => e.target.files && handleFileSelect(e.target.files[0])}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              
              {file ? (
                <div className="space-y-4">
                  <FileVideo className="h-12 w-12 text-green-600 mx-auto" />
                  <div>
                    <p className="font-semibold text-green-800">{file.name}</p>
                    <p className="text-sm text-green-600">{formatFileSize(file.size)}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setFile(null);
                    }}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Verwijder
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto" />
                  <div>
                    <p className="text-lg font-semibold">Sleep video bestand hier</p>
                    <p className="text-sm text-muted-foreground">
                      Of klik om bestand te selecteren
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      MP4, MOV, AVI, WebM, WMV (max 10MB)
                    </p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Video Details Form */}
        <Card>
          <CardHeader>
            <CardTitle>Video Details</CardTitle>
            <CardDescription>
              Vul de details van je video in voor analyse
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Titel *</Label>
              <Input
                id="title"
                value={uploadData.title}
                onChange={(e) => setUploadData({ ...uploadData, title: e.target.value })}
                placeholder="Bijvoorbeeld: Gent vs Anderlecht B - 21/09/2024"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Beschrijving</Label>
              <Textarea
                id="description"
                value={uploadData.description}
                onChange={(e) => setUploadData({ ...uploadData, description: e.target.value })}
                placeholder="Korte beschrijving van de video..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="team">Team *</Label>
              <Select value={uploadData.teamId} onValueChange={(value) => setUploadData({ ...uploadData, teamId: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecteer team" />
                </SelectTrigger>
                <SelectContent>
                  {teams?.map((team: any) => (
                    <SelectItem key={team.id} value={team.id.toString()}>
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="analysisType">Analyse Type</Label>
              <Select value={uploadData.analysisType} onValueChange={(value: any) => setUploadData({ ...uploadData, analysisType: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="full_match">Volledige Wedstrijd</SelectItem>
                  <SelectItem value="tactical_analysis">Tactische Analyse</SelectItem>
                  <SelectItem value="player_performance">Speler Prestatie</SelectItem>
                  <SelectItem value="training_session">Training Sessie</SelectItem>
                  <SelectItem value="individual_analysis">Individuele Speler Analyse</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="season">Seizoen</Label>
                <Input
                  id="season"
                  value={uploadData.season}
                  onChange={(e) => setUploadData({ ...uploadData, season: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="opponent">Tegenstander</Label>
                <Input
                  id="opponent"
                  value={uploadData.opponent}
                  onChange={(e) => setUploadData({ ...uploadData, opponent: e.target.value })}
                  placeholder="Bijvoorbeeld: KVC De Toek. Borsbeke"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="matchResult">Resultaat</Label>
              <Input
                id="matchResult"
                value={uploadData.matchResult}
                onChange={(e) => setUploadData({ ...uploadData, matchResult: e.target.value })}
                placeholder="Bijvoorbeeld: 2-1 Winst"
              />
            </div>

            {uploadData.analysisType === 'individual_analysis' && (
              <div>
                <Label>Selecteer spelers voor analyse</Label>
                <div className="mt-2 max-h-40 overflow-y-auto border rounded-md p-3">
                  {players?.filter(player => player.role === 'player' && player.teamId?.toString() === uploadData.teamId).map(player => (
                    <div key={player.id} className="flex items-center space-x-2 mb-2">
                      <input
                        type="checkbox"
                        id={`player-${player.id}`}
                        checked={uploadData.selectedPlayers?.includes(player.id.toString()) || false}
                        onChange={(e) => {
                          const playerIds = uploadData.selectedPlayers || [];
                          if (e.target.checked) {
                            setUploadData({ 
                              ...uploadData, 
                              selectedPlayers: [...playerIds, player.id.toString()] 
                            });
                          } else {
                            setUploadData({ 
                              ...uploadData, 
                              selectedPlayers: playerIds.filter(id => id !== player.id.toString()) 
                            });
                          }
                        }}
                        className="rounded"
                      />
                      <Label htmlFor={`player-${player.id}`} className="text-sm font-normal">
                        {player.firstName} {player.lastName} #{player.jerseyNumber || player.id}
                      </Label>
                    </div>
                  ))}
                  {players?.filter(player => player.role === 'player' && player.teamId?.toString() === uploadData.teamId).length === 0 && (
                    <p className="text-sm text-gray-500">Geen spelers gevonden voor dit team</p>
                  )}
                </div>
              </div>
            )}

            <Button 
              onClick={handleSubmit} 
              disabled={!file || uploadMutation.isPending || !uploadData.title || !uploadData.teamId}
              className="w-full"
            >
              {uploadMutation.isPending ? (
                "Uploaden..."
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Video Uploaden
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}