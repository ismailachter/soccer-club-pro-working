import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Users, Calendar, BarChart3, Trophy, Globe, ChevronRight, Mail, Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function Landing() {
  const [, setLocation] = useLocation();
  const [showLogin, setShowLogin] = useState(false);
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials)
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('authToken', data.token);
        toast({ title: "Welcome to Soccer Club Pro", description: "Login successful" });
        setLocation('/dashboard');
      } else {
        toast({ 
          title: "Access Denied", 
          description: "Invalid credentials for Soccer Club Pro platform",
          variant: "destructive" 
        });
      }
    } catch (error) {
      toast({ 
        title: "Connection Error", 
        description: "Unable to connect to Soccer Club Pro servers",
        variant: "destructive" 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const features = [
    {
      icon: Users,
      title: "Player Database Management",
      description: "Complete player profiles, statistics, and development tracking with integrated scouting system"
    },
    {
      icon: Calendar,
      title: "Advanced Year Planning",
      description: "Professional training schedules with 203-element IADATABANK methodology integration"
    },
    {
      icon: BarChart3,
      title: "Performance Analytics",
      description: "Real-time team performance metrics, player development insights, and match analysis"
    },
    {
      icon: Trophy,
      title: "Match Management",
      description: "Complete fixture management, results tracking, and opponent analysis tools"
    },
    {
      icon: Shield,
      title: "Multi-Role Access Control",
      description: "Secure role-based access for coaches, players, parents, and administrators"
    },
    {
      icon: Globe,
      title: "Multi-Club SaaS Platform",
      description: "Scalable solution supporting multiple clubs with tenant isolation and custom branding"
    }
  ];

  if (showLogin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card className="border-blue-200 shadow-2xl">
            <CardHeader className="text-center space-y-4">
              <div className="mx-auto w-20 h-20 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center">
                <Trophy className="w-10 h-10 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-blue-900">Soccer Club Pro</CardTitle>
              <CardDescription>Professional Club Management Platform</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Username</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="Enter your username"
                      className="pl-10"
                      value={credentials.username}
                      onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      type="password"
                      placeholder="Enter your password"
                      className="pl-10"
                      value={credentials.password}
                      onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                  disabled={isLoading}
                >
                  {isLoading ? "Authenticating..." : "Access Platform"}
                </Button>
              </form>
              <div className="mt-6 text-center">
                <Button 
                  variant="ghost" 
                  onClick={() => setShowLogin(false)}
                  className="text-blue-600 hover:text-blue-800"
                >
                  ← Back to Information
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900">
      {/* Header */}
      <header className="border-b border-blue-700/50 bg-blue-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Soccer Club Pro</h1>
              <p className="text-xs text-blue-200">Professional Club Management</p>
            </div>
          </div>
          <Button 
            onClick={() => setShowLogin(true)}
            className="bg-white text-blue-900 hover:bg-blue-50"
          >
            Platform Login
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto px-4">
          <Badge className="mb-6 bg-blue-100 text-blue-800 border-blue-200">
            🚀 Professional Soccer Club Management Platform
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Professional Soccer Club
            <span className="block bg-gradient-to-r from-blue-300 to-blue-100 bg-clip-text text-transparent">
              Management Platform
            </span>
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto leading-relaxed">
            Comprehensive club administration with advanced training methodology, player development tracking, 
            and multi-role access control. Built for professional soccer clubs seeking modern management solutions.
            Access by invitation only.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => setShowLogin(true)}
              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-8 py-3"
            >
              Access Platform <ChevronRight className="ml-2 w-4 h-4" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-blue-900 px-8 py-3"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-white/5 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Platform Features</h2>
            <p className="text-blue-100 text-lg max-w-2xl mx-auto">
              Complete suite of tools for modern soccer club management and player development
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/15 transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-white">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-blue-100">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Access Information Section */}
      <section className="py-20 bg-white/5 backdrop-blur-sm">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-8">Exclusive Access Platform</h2>
          <div className="max-w-4xl mx-auto">
            <Card className="bg-gradient-to-r from-blue-600/20 to-blue-800/20 backdrop-blur-sm border-blue-400/30">
              <CardContent className="p-8">
                <div className="flex items-center justify-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mr-6">
                    <Shield className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-left">
                    <h3 className="text-3xl font-bold text-white mb-2">Invitation Only</h3>
                    <p className="text-blue-200">Professional Soccer Club Management</p>
                  </div>
                </div>
                <p className="text-blue-100 text-lg leading-relaxed">
                  Soccer Club Pro is an exclusive platform designed for professional soccer clubs. 
                  Access is granted through invitation only, ensuring a premium experience for 
                  serious club management professionals.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-16">Platform Statistics</h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-300 mb-2">203</div>
              <div className="text-blue-100">IADATABANK Training Elements</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-300 mb-2">1000+</div>
              <div className="text-blue-100">Training Sessions Planned</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-300 mb-2">100+</div>
              <div className="text-blue-100">Players Managed</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-300 mb-2">24/7</div>
              <div className="text-blue-100">Platform Availability</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-blue-700/50 bg-blue-900/50 py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center">
              <Trophy className="w-4 h-4 text-white" />
            </div>
            <span className="text-white font-semibold">Soccer Club Pro</span>
          </div>
          <p className="text-blue-200 mb-4">Professional Club Management Platform</p>
          <div className="text-blue-300 text-sm">
            <a href="mailto:info@soccerclubpro.com" className="hover:text-white transition-colors">
              info@soccerclubpro.com
            </a>
            <span className="mx-2">|</span>
            <span>#teamworkmakesthedreamwork</span>
          </div>
        </div>
      </footer>
    </div>
  );
}