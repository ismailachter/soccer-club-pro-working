import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Goal {
  minute: number;
  player: string;
  team: 'VVC' | 'KVKS';
  assist?: string;
}

interface MatchEvent {
  minute: number;
  type: 'goal' | 'yellow_card' | 'red_card' | 'substitution';
  player: string;
  team: 'VVC' | 'KVKS';
  description: string;
}

export default function MatchResultInput() {
  const [vvcScore, setVvcScore] = useState<number>(0);
  const [kvksScore, setKvksScore] = useState<number>(0);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [events, setEvents] = useState<MatchEvent[]>([]);
  const { toast } = useToast();

  const vvcPlayers = [
    'Marieke Van Ammers', 'Laura Michielsen', 'Sien Schepens', 
    'Jorien Dictus', 'Eline Charlotte Bultje', 'Melissa Vinckx',
    'Arianna De Maeyer', 'Julie Luyten', 'Louise Creemers', 
    'Sophie Van Parys', 'Maud Bastiaensen'
  ];

  const kvksPlayers = [
    'Joni Billen', 'Kirsten Van Dessel', 'Amber Verlee',
    'Ana Lucia Dierckx', 'Sandy De Schepper', 'Femke Mertens',
    'Jelien De Laet', 'Anke Goor', 'Anouk Vervaet',
    'Eline Van Bockhaven', 'Sofie Van Troyen'
  ];

  const addGoal = () => {
    setGoals([...goals, {
      minute: 0,
      player: '',
      team: 'VVC',
      assist: ''
    }]);
  };

  const updateGoal = (index: number, field: keyof Goal, value: any) => {
    const newGoals = [...goals];
    newGoals[index] = { ...newGoals[index], [field]: value };
    setGoals(newGoals);
  };

  const removeGoal = (index: number) => {
    setGoals(goals.filter((_, i) => i !== index));
  };

  const addEvent = () => {
    setEvents([...events, {
      minute: 0,
      type: 'yellow_card',
      player: '',
      team: 'VVC',
      description: ''
    }]);
  };

  const updateEvent = (index: number, field: keyof MatchEvent, value: any) => {
    const newEvents = [...events];
    newEvents[index] = { ...newEvents[index], [field]: value };
    setEvents(newEvents);
  };

  const removeEvent = (index: number) => {
    setEvents(events.filter((_, i) => i !== index));
  };

  const saveMatchResults = async () => {
    const matchData = {
      finalScore: { vvc: vvcScore, kvks: kvksScore },
      goals: goals.sort((a, b) => a.minute - b.minute),
      events: events.sort((a, b) => a.minute - b.minute),
      timestamp: new Date().toISOString()
    };

    try {
      // Save to localStorage for now (would be API call in production)
      localStorage.setItem('matchResults', JSON.stringify(matchData));
      
      toast({
        title: "Resultaten opgeslagen",
        description: `Eindstand: VVC ${vvcScore} - ${kvksScore} KVKS`,
      });
    } catch (error) {
      toast({
        title: "Fout bij opslaan",
        description: "Probeer opnieuw",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Wedstrijdresultaten Invoeren
          </h1>
          <p className="text-lg text-gray-600">
            VVC Brasschaat vs KVKS Melsele
          </p>
        </div>

        <div className="grid gap-6">
          {/* Final Score */}
          <Card>
            <CardHeader>
              <CardTitle>Eindstand</CardTitle>
              <CardDescription>
                Voer de definitieve score in
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4 items-center">
                <div>
                  <Label htmlFor="vvc-score">VVC Brasschaat</Label>
                  <Input
                    id="vvc-score"
                    type="number"
                    min="0"
                    value={vvcScore}
                    onChange={(e) => setVvcScore(parseInt(e.target.value) || 0)}
                    className="text-center text-2xl font-bold"
                  />
                </div>
                <div className="text-center text-2xl font-bold text-gray-500">
                  -
                </div>
                <div>
                  <Label htmlFor="kvks-score">KVKS Melsele</Label>
                  <Input
                    id="kvks-score"
                    type="number"
                    min="0"
                    value={kvksScore}
                    onChange={(e) => setKvksScore(parseInt(e.target.value) || 0)}
                    className="text-center text-2xl font-bold"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Goals */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Doelpunten
                <Button onClick={addGoal} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Voeg Goal Toe
                </Button>
              </CardTitle>
              <CardDescription>
                Voer alle doelpunten in met tijd en scorer
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {goals.map((goal, index) => (
                <div key={index} className="grid md:grid-cols-5 gap-4 p-4 border rounded-lg">
                  <div>
                    <Label>Minuut</Label>
                    <Input
                      type="number"
                      min="1"
                      max="90"
                      value={goal.minute}
                      onChange={(e) => updateGoal(index, 'minute', parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div>
                    <Label>Team</Label>
                    <select
                      className="w-full p-2 border rounded"
                      value={goal.team}
                      onChange={(e) => updateGoal(index, 'team', e.target.value as 'VVC' | 'KVKS')}
                    >
                      <option value="VVC">VVC</option>
                      <option value="KVKS">KVKS</option>
                    </select>
                  </div>
                  <div>
                    <Label>Speler</Label>
                    <select
                      className="w-full p-2 border rounded"
                      value={goal.player}
                      onChange={(e) => updateGoal(index, 'player', e.target.value)}
                    >
                      <option value="">Selecteer speler</option>
                      {(goal.team === 'VVC' ? vvcPlayers : kvksPlayers).map(player => (
                        <option key={player} value={player}>{player}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <Label>Assist (optioneel)</Label>
                    <select
                      className="w-full p-2 border rounded"
                      value={goal.assist || ''}
                      onChange={(e) => updateGoal(index, 'assist', e.target.value)}
                    >
                      <option value="">Geen assist</option>
                      {(goal.team === 'VVC' ? vvcPlayers : kvksPlayers).map(player => (
                        <option key={player} value={player}>{player}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-end">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => removeGoal(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {goals.length === 0 && (
                <p className="text-center text-gray-500 py-4">
                  Nog geen doelpunten toegevoegd
                </p>
              )}
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="text-center">
            <Button onClick={saveMatchResults} size="lg" className="px-8">
              <Save className="h-4 w-4 mr-2" />
              Resultaten Opslaan
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}