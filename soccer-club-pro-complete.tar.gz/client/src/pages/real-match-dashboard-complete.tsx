import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BarChart3, Users, Clock, Activity, TrendingUp, Target, ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';

interface MatchData {
  matchId: string;
  homeTeam: string;
  awayTeam: string;
  finalScore: { home: number; away: number };
  date: string;
  duration: number;
  totalFramesAnalyzed: number;
  analysisProgress: number;
}

interface PlayerAnalysis {
  playerId: number;
  playerName: string;
  position: string;
  team: string;
  number: number;
  basics: {
    ballControl: number;
    passing: number;
    receiving: number;
    dribbling: number;
    shooting: number;
    heading: number;
  };
  tactical: {
    positioning: number;
    decisionMaking: number;
    teamwork: number;
    pressing: number;
    defending: number;
    attacking: number;
  };
  physical: {
    totalDistance: number;
    avgTopSpeed: number;
    totalSprints: number;
    totalAccelerations: number;
    totalDecelerations: number;
    avgIntensity: number;
  };
}

export default function RealMatchDashboardComplete() {
  const [matchData, setMatchData] = useState<MatchData | null>(null);
  const [playerAnalysis, setPlayerAnalysis] = useState<PlayerAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTeam, setSelectedTeam] = useState<string>('all');

  useEffect(() => {
    fetchRealMatchData();
  }, []);

  const fetchRealMatchData = async () => {
    try {
      const response = await fetch('/api/real-match-analysis/svelta-vvc-20250625');
      const data = await response.json();
      
      setMatchData({
        matchId: data.matchInfo.matchId,
        homeTeam: data.matchInfo.homeTeam,
        awayTeam: data.matchInfo.awayTeam,
        finalScore: data.matchInfo.finalScore,
        date: data.matchInfo.date,
        duration: data.matchInfo.duration,
        totalFramesAnalyzed: data.totalFramesAnalyzed,
        analysisProgress: data.analysisProgress
      });
      setPlayerAnalysis(data.playerAnalysis || []);
    } catch (error) {
      console.error('Error fetching match data:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredPlayers = selectedTeam === 'all' 
    ? playerAnalysis 
    : playerAnalysis.filter(player => player.team === selectedTeam);

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-green-600 font-bold';
    if (score >= 6) return 'text-yellow-600 font-medium';
    return 'text-red-600 font-medium';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin h-12 w-12 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-gray-600">Analyseer echte wedstrijdbeelden...</p>
        </div>
      </div>
    );
  }

  if (!matchData) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900">Geen wedstrijd data beschikbaar</h2>
        <Link href="/">
          <Button className="mt-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Terug naar Menu
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Back Button */}
      <Link href="/">
        <Button variant="outline" className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Terug naar Menu
        </Button>
      </Link>

      {/* Match Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6 rounded-lg">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold mb-2">Real Match Analysis</h1>
            <p className="text-blue-100">{matchData.date} - Authentieke Video Analyse</p>
            <p className="text-blue-200 text-sm">Wedstrijdduur: {matchData.duration} minuten</p>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold">
              {matchData.finalScore.home} - {matchData.finalScore.away}
            </div>
            <div className="text-blue-100">
              {matchData.homeTeam} vs {matchData.awayTeam}
            </div>
          </div>
        </div>
      </div>

      {/* Analysis Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Video Analyse Voortgang
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Frames geanalyseerd: {matchData.totalFramesAnalyzed}</span>
                <span>{matchData.analysisProgress.toFixed(1)}% voltooid</span>
              </div>
              <Progress value={matchData.analysisProgress} className="h-3" />
            </div>
            <p className="text-sm text-gray-600">
              Echte wedstrijdbeelden worden geanalyseerd voor authentieke performance data van {playerAnalysis.length} spelers
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Team Filter */}
      <div className="flex gap-2 flex-wrap">
        <Button 
          variant={selectedTeam === 'all' ? 'default' : 'outline'}
          onClick={() => setSelectedTeam('all')}
        >
          <Users className="h-4 w-4 mr-2" />
          Alle Spelers ({playerAnalysis.length})
        </Button>
        <Button 
          variant={selectedTeam === 'VVC Brasschaat' ? 'default' : 'outline'}
          onClick={() => setSelectedTeam('VVC Brasschaat')}
        >
          VVC Brasschaat ({playerAnalysis.filter(p => p.team === 'VVC Brasschaat').length})
        </Button>
        <Button 
          variant={selectedTeam === 'Svelta Melsele' ? 'default' : 'outline'}
          onClick={() => setSelectedTeam('Svelta Melsele')}
        >
          Svelta Melsele ({playerAnalysis.filter(p => p.team === 'Svelta Melsele').length})
        </Button>
      </div>

      {/* Player Analysis Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredPlayers.map((player) => (
          <Card key={player.playerId} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm">{player.playerName}</div>
                  <div className="text-xs text-gray-600">{player.position} - #{player.number}</div>
                </div>
                <Badge variant={player.team === 'VVC Brasschaat' ? 'default' : 'secondary'}>
                  {player.team === 'VVC Brasschaat' ? 'VVC' : 'SVE'}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              {/* BASICS Scores */}
              <div>
                <h4 className="font-semibold text-xs mb-2 text-purple-600 border-b border-purple-200 pb-1">BASICS</h4>
                <div className="grid grid-cols-2 gap-1 text-xs">
                  <div className="flex justify-between">
                    <span>Bal Controle:</span>
                    <span className={getScoreColor(player.basics.ballControl)}>
                      {player.basics.ballControl.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Passing:</span>
                    <span className={getScoreColor(player.basics.passing)}>
                      {player.basics.passing.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Receiving:</span>
                    <span className={getScoreColor(player.basics.receiving)}>
                      {player.basics.receiving.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Dribbling:</span>
                    <span className={getScoreColor(player.basics.dribbling)}>
                      {player.basics.dribbling.toFixed(1)}
                    </span>
                  </div>
                </div>
              </div>

              {/* TEAMTACTISCH Scores */}
              <div>
                <h4 className="font-semibold text-xs mb-2 text-green-600 border-b border-green-200 pb-1">TEAMTACTISCH</h4>
                <div className="grid grid-cols-2 gap-1 text-xs">
                  <div className="flex justify-between">
                    <span>Positionering:</span>
                    <span className={getScoreColor(player.tactical.positioning)}>
                      {player.tactical.positioning.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Besluitvorming:</span>
                    <span className={getScoreColor(player.tactical.decisionMaking)}>
                      {player.tactical.decisionMaking.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Teamwork:</span>
                    <span className={getScoreColor(player.tactical.teamwork)}>
                      {player.tactical.teamwork.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Druk Zetten:</span>
                    <span className={getScoreColor(player.tactical.pressing)}>
                      {player.tactical.pressing.toFixed(1)}
                    </span>
                  </div>
                </div>
              </div>

              {/* FYSIEK Data */}
              <div>
                <h4 className="font-semibold text-xs mb-2 text-orange-600 border-b border-orange-200 pb-1">FYSIEK</h4>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span>Afstand:</span>
                    <span className="font-medium text-blue-600">{player.physical.totalDistance.toFixed(1)} km</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Top Snelheid:</span>
                    <span className="font-medium text-blue-600">{player.physical.avgTopSpeed.toFixed(1)} km/h</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sprints:</span>
                    <span className="font-medium text-blue-600">{player.physical.totalSprints}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Intensiteit:</span>
                    <span className={getScoreColor(player.physical.avgIntensity)}>
                      {player.physical.avgIntensity.toFixed(1)}/10
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredPlayers.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-500">Geen spelers gevonden voor het geselecteerde team.</p>
        </div>
      )}
    </div>
  );
}