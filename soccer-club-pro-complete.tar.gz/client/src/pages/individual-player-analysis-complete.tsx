import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Activity, Target, Brain, Zap, User } from "lucide-react";

interface PlayerData {
  playerId: number;
  playerName: string;
  position: string;
  team: string;
  basics: {
    ballControl: number;
    passing: number;
    receiving: number;
    dribbling: number;
    shooting: number;
    heading: number;
    overallRating: number;
  };
  tactical: {
    positioning: number;
    decisionMaking: number;
    teamwork: number;
    pressing: number;
    defending: number;
    attacking: number;
    overallRating: number;
  };
  physical: {
    distance: number;
    topSpeed: number;
    sprints: number;
    accelerations: number;
    decelerations: number;
    intensity: number;
    overallRating: number;
  };
}

export default function IndividualPlayerAnalysisComplete() {
  const [analysisData, setAnalysisData] = useState<any>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<PlayerData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAnalysisData = async () => {
      try {
        const response = await fetch('/uploads/svelta-analysis.json');
        const data = await response.json();
        setAnalysisData(data);
        
        // Selecteer eerste VVC speler
        const vvcPlayers = data.playerData?.filter((p: PlayerData) => p.team === "VVC Brasschaat A") || [];
        if (vvcPlayers.length > 0) {
          setSelectedPlayer(vvcPlayers[0]);
        }
      } catch (error) {
        console.error('Fout bij laden analyse data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadAnalysisData();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <div className="text-center">
          <div className="text-xl">Laden individuele speleranalyse...</div>
        </div>
      </div>
    );
  }

  if (!analysisData || !selectedPlayer) {
    return (
      <div className="space-y-6 p-6">
        <div className="text-center">
          <div className="text-xl text-red-600">Geen speelster data beschikbaar</div>
        </div>
      </div>
    );
  }

  const vvcPlayers = analysisData.playerData?.filter((p: PlayerData) => p.team === "VVC Brasschaat A") || [];

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-600";
    if (score >= 6) return "text-yellow-600";
    return "text-red-600";
  };

  const getProgressColor = (score: number) => {
    if (score >= 8) return "bg-green-500";
    if (score >= 6) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto">
      {/* Header met speelster selectie */}
      <div className="space-y-4">
        <h1 className="text-3xl font-bold text-center">VVC Brasschaat - Individuele Analyse</h1>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
          {vvcPlayers.map((player: PlayerData) => (
            <Button
              key={player.playerId}
              variant={selectedPlayer?.playerId === player.playerId ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedPlayer(player)}
              className="text-xs p-2 h-auto"
            >
              <div className="text-center">
                <div className="font-semibold">{player.playerName}</div>
                <div className="text-xs text-gray-600">{player.position}</div>
              </div>
            </Button>
          ))}
        </div>
      </div>

      {/* Speelster Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            {selectedPlayer.playerName}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-sm text-gray-600">Positie</div>
              <div className="font-semibold">{selectedPlayer.position}</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-600">BASICS Rating</div>
              <div className={`text-2xl font-bold ${getScoreColor(selectedPlayer.basics.overallRating)}`}>
                {selectedPlayer.basics.overallRating}
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-600">TACTICAL Rating</div>
              <div className={`text-2xl font-bold ${getScoreColor(selectedPlayer.tactical.overallRating)}`}>
                {selectedPlayer.tactical.overallRating}
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-600">PHYSICAL Rating</div>
              <div className={`text-2xl font-bold ${getScoreColor(selectedPlayer.physical.overallRating)}`}>
                {selectedPlayer.physical.overallRating}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Gedetailleerde Analyse */}
      <Tabs defaultValue="basics" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="basics" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            BASICS
          </TabsTrigger>
          <TabsTrigger value="tactical" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            TACTICAL
          </TabsTrigger>
          <TabsTrigger value="physical" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            PHYSICAL
          </TabsTrigger>
        </TabsList>

        <TabsContent value="basics">
          <Card>
            <CardHeader>
              <CardTitle>BASICS Analyse - {selectedPlayer.playerName}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(selectedPlayer.basics).map(([skill, score]) => {
                if (skill === 'overallRating') return null;
                return (
                  <div key={skill} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="capitalize font-medium">{skill.replace(/([A-Z])/g, ' $1')}</span>
                      <span className={`font-bold ${getScoreColor(score as number)}`}>
                        {(score as number).toFixed(1)}
                      </span>
                    </div>
                    <Progress 
                      value={(score as number) * 10} 
                      className="h-2"
                    />
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tactical">
          <Card>
            <CardHeader>
              <CardTitle>TACTICAL Analyse - {selectedPlayer.playerName}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(selectedPlayer.tactical).map(([skill, score]) => {
                if (skill === 'overallRating') return null;
                return (
                  <div key={skill} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="capitalize font-medium">{skill.replace(/([A-Z])/g, ' $1')}</span>
                      <span className={`font-bold ${getScoreColor(score as number)}`}>
                        {(score as number).toFixed(1)}
                      </span>
                    </div>
                    <Progress 
                      value={(score as number) * 10} 
                      className="h-2"
                    />
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="physical">
          <Card>
            <CardHeader>
              <CardTitle>PHYSICAL Analyse - {selectedPlayer.playerName}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-sm text-gray-600">Afstand</div>
                  <div className="text-xl font-bold">{(selectedPlayer.physical.distance / 1000).toFixed(1)} km</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-600">Top Snelheid</div>
                  <div className="text-xl font-bold">{selectedPlayer.physical.topSpeed} km/h</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-600">Sprints</div>
                  <div className="text-xl font-bold">{selectedPlayer.physical.sprints}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-600">Acceleraties</div>
                  <div className="text-xl font-bold">{selectedPlayer.physical.accelerations}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-600">Deceleraties</div>
                  <div className="text-xl font-bold">{selectedPlayer.physical.decelerations}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-600">Intensiteit</div>
                  <div className={`text-xl font-bold ${getScoreColor(selectedPlayer.physical.intensity / 10)}`}>
                    {selectedPlayer.physical.intensity}%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Match Info */}
      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-sm text-gray-600">
            Wedstrijd: Svelta Melsele 1 - 5 VVC Brasschaat A | 5 april 2025<br/>
            Analyse gebaseerd op {analysisData.totalFrames} video frames
          </div>
        </CardContent>
      </Card>
    </div>
  );
}