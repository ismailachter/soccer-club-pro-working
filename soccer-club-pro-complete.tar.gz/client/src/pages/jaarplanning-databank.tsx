import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash2, Eye, Edit, Calendar, Users, Clock, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";

interface TrainingPlan {
  id: number;
  name: string;
  description: string | null;
  ageGroup: string | null;
  teamId: number | null;
  teamName: string | null;
  season: string | null;
  startDate: string;
  endDate: string;
  sessionsPerWeek: number;
  trainingDays: string[];
  createdBy: number;
  createdAt: string;
  updatedAt: string;
}

export default function JaarplanningDatabank() {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [planToDelete, setPlanToDelete] = useState<TrainingPlan | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<TrainingPlan | null>(null);
  const [editForm, setEditForm] = useState({
    name: "",
    description: "",
    ageGroup: "",
    season: "",
    startDate: "",
    endDate: "",
    sessionsPerWeek: 2,
    trainingDays: [] as string[],
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: teams = [] } = useQuery({
    queryKey: ["/api/teams"],
  });

  const weekDays = [
    { value: "monday", label: "Maandag" },
    { value: "tuesday", label: "Dinsdag" },
    { value: "wednesday", label: "Woensdag" },
    { value: "thursday", label: "Donderdag" },
    { value: "friday", label: "Vrijdag" },
    { value: "saturday", label: "Zaterdag" },
    { value: "sunday", label: "Zondag" },
  ];

  const { data: trainingPlans = [], isLoading, error } = useQuery<TrainingPlan[]>({
    queryKey: ["/api/training-plans"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (planId: number) => {
      await apiRequest("DELETE", `/api/training-plans/${planId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training-plans"] });
      toast({
        title: "Jaarplanning verwijderd",
        description: "De jaarplanning en alle bijbehorende trainingen zijn permanent verwijderd.",
      });
      setDeleteDialogOpen(false);
      setPlanToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Fout bij verwijderen",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDeleteClick = (plan: TrainingPlan) => {
    setPlanToDelete(plan);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (planToDelete) {
      deleteMutation.mutate(planToDelete.id);
    }
  };

  const formatTrainingDays = (days: string[]) => {
    const dayNames: { [key: string]: string } = {
      monday: "Maandag",
      tuesday: "Dinsdag", 
      wednesday: "Woensdag",
      thursday: "Donderdag",
      friday: "Vrijdag",
      saturday: "Zaterdag",
      sunday: "Zondag"
    };
    return days.map(day => dayNames[day] || day).join(", ");
  };

  const calculateDuration = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffWeeks = Math.ceil(diffTime / (1000 * 60 * 60 * 24 * 7));
    return diffWeeks;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Card>
          <CardContent className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-red-600 mb-2">Fout bij laden</h3>
              <p className="text-gray-600">Kan jaarplanningen niet laden. Probeer opnieuw.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Jaarplanning Databank</h1>
            <p className="text-gray-600">
              Overzicht van alle opgeslagen jaarplanningen en trainingsschema's
            </p>
          </div>
          <Link href="/jaarplanning">
            <Button>
              <Calendar className="w-4 h-4 mr-2" />
              Nieuwe Planning
            </Button>
          </Link>
        </div>
      </div>

      {trainingPlans.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center min-h-[400px] text-center">
            <Calendar className="w-16 h-16 text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Geen jaarplanningen gevonden</h3>
            <p className="text-gray-600 mb-6">
              Er zijn nog geen jaarplanningen aangemaakt. Begin met het maken van je eerste planning.
            </p>
            <Link href="/jaarplanning">
              <Button>
                <Calendar className="w-4 h-4 mr-2" />
                Eerste Planning Maken
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {trainingPlans.map((plan) => (
            <Card key={plan.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg mb-1">{plan.name}</CardTitle>
                    <CardDescription className="text-sm">
                      {plan.description || "Geen beschrijving"}
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="ml-2">
                    {plan.season || "Seizoen onbekend"}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-gray-500" />
                    <span>{plan.ageGroup || "Alle leeftijden"}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span>{plan.teamName || "Geen team"}</span>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Periode:</span>
                    <span className="font-medium">
                      {format(new Date(plan.startDate), "dd MMM", { locale: nl })} - {" "}
                      {format(new Date(plan.endDate), "dd MMM yyyy", { locale: nl })}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Duur:</span>
                    <span className="font-medium">
                      {calculateDuration(plan.startDate, plan.endDate)} weken
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Frequentie:</span>
                    <span className="font-medium">{plan.sessionsPerWeek}x per week</span>
                  </div>
                </div>

                <div className="text-sm">
                  <span className="text-gray-600 block mb-1">Trainingsdagen:</span>
                  <div className="flex flex-wrap gap-1">
                    {plan.trainingDays.map((day) => (
                      <Badge key={day} variant="secondary" className="text-xs">
                        {formatTrainingDays([day])}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="flex items-center space-x-2 text-xs text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span>
                      Aangemaakt {format(new Date(plan.createdAt), "dd MMM yyyy", { locale: nl })}
                    </span>
                  </div>
                  <div className="flex space-x-2">
                    <Link href={`/jaarplanning/${plan.id}`}>
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </Link>
                    <AlertDialog open={deleteDialogOpen && planToDelete?.id === plan.id}>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteClick(plan)}
                          className="text-red-600 hover:text-red-700 hover:border-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Jaarplanning verwijderen?</AlertDialogTitle>
                          <AlertDialogDescription className="space-y-2">
                            <p>
                              Weet je zeker dat je de jaarplanning <strong>"{planToDelete?.name}"</strong> wilt verwijderen?
                            </p>
                            <p className="text-red-600 font-medium">
                              Deze actie kan niet ongedaan worden gemaakt. Alle trainingsmomenten en gekoppelde IADATABANK elementen worden permanent verwijderd.
                            </p>
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel onClick={() => {
                            setDeleteDialogOpen(false);
                            setPlanToDelete(null);
                          }}>
                            Annuleren
                          </AlertDialogCancel>
                          <AlertDialogAction
                            onClick={confirmDelete}
                            className="bg-red-600 hover:bg-red-700"
                            disabled={deleteMutation.isPending}
                          >
                            {deleteMutation.isPending ? "Verwijderen..." : "Definitief verwijderen"}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}