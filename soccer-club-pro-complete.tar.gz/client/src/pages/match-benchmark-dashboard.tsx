import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Upload, Play, BarChart3, Calendar, MapPin, Trophy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface BenchmarkMatch {
  id: string;
  date: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  venue: string;
  competition: string;
  season: string;
  videoUploaded: boolean;
  analysisComplete: boolean;
  frameCount?: number;
}

export default function MatchBenchmarkDashboard() {
  const [matches, setMatches] = useState<BenchmarkMatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadingMatch, setUploadingMatch] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchBenchmarkMatches();
  }, []);

  const fetchBenchmarkMatches = async () => {
    try {
      // Direct data instead of API call
      const data = [
        {
          id: 'svelta-vvc-20250405',
          date: '2025-04-05',
          homeTeam: 'Svelta Melsele',
          awayTeam: 'VVC Brasschaat',
          homeScore: 1,
          awayScore: 5,
          venue: 'away',
          competition: 'Dames IP',
          season: '2024-2025',
          videoUploaded: true,
          analysisComplete: true,
          frameCount: 566
        }
      ];
      setMatches(data);
    } catch (error) {
      toast({
        title: "Fout bij laden wedstrijden",
        description: "Kon wedstrijden niet ophalen",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVideoUpload = async (matchId: string, file: File) => {
    setUploadingMatch(matchId);
    
    const formData = new FormData();
    formData.append('video', file);
    formData.append('matchId', matchId);

    try {
      const response = await fetch('/api/benchmark-matches/upload-video', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        toast({
          title: "Video geüpload",
          description: "Wedstrijdvideo succesvol geüpload voor analyse"
        });
        fetchBenchmarkMatches();
      }
    } catch (error) {
      toast({
        title: "Upload fout",
        description: "Video upload mislukt",
        variant: "destructive"
      });
    } finally {
      setUploadingMatch(null);
    }
  };

  const startAnalysis = async (matchId: string) => {
    try {
      const response = await fetch(`/api/benchmark-matches/${matchId}/analyze`, {
        method: 'POST'
      });

      if (response.ok) {
        toast({
          title: "Analyse gestart",
          description: "Video analyse proces is geïnitieerd"
        });
        fetchBenchmarkMatches();
      }
    } catch (error) {
      toast({
        title: "Analyse fout",
        description: "Kon analyse niet starten",
        variant: "destructive"
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('nl-BE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const getMatchResult = (match: BenchmarkMatch) => {
    const vvcScore = match.venue === 'home' ? match.homeScore : match.awayScore;
    const opponentScore = match.venue === 'home' ? match.awayScore : match.homeScore;
    
    if (vvcScore > opponentScore) return 'win';
    if (vvcScore < opponentScore) return 'loss';
    return 'draw';
  };

  const getResultColor = (result: string) => {
    switch (result) {
      case 'win': return 'bg-green-500';
      case 'loss': return 'bg-red-500';
      case 'draw': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Laden wedstrijden...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Wedstrijd Benchmark Database
        </h1>
        <p className="text-gray-600">
          VVC Brasschaat A - Complete seizoen video analyse
        </p>
      </div>

      {/* Statistics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Trophy className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Totaal Wedstrijden</p>
                <p className="text-2xl font-bold text-gray-900">{matches.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Upload className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Videos Geüpload</p>
                <p className="text-2xl font-bold text-gray-900">
                  {matches.filter(m => m.videoUploaded).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <BarChart3 className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Geanalyseerd</p>
                <p className="text-2xl font-bold text-gray-900">
                  {matches.filter(m => m.analysisComplete).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Play className="h-8 w-8 text-orange-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Voortgang</p>
                <p className="text-2xl font-bold text-gray-900">
                  {Math.round((matches.filter(m => m.analysisComplete).length / matches.length) * 100)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Match Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {matches.map((match) => {
          const result = getMatchResult(match);
          const opponent = match.venue === 'home' ? match.awayTeam : match.homeTeam;
          const score = `${match.homeScore} - ${match.awayScore}`;
          
          return (
            <Card key={match.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <Badge 
                    className={`${getResultColor(result)} text-white`}
                    variant="secondary"
                  >
                    {result === 'win' ? 'Gewonnen' : result === 'loss' ? 'Verloren' : 'Gelijk'}
                  </Badge>
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="h-4 w-4 mr-1" />
                    {formatDate(match.date)}
                  </div>
                </div>
                
                <CardTitle className="text-lg leading-6">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-blue-600">VVC Brasschaat A</span>
                    <span className="text-2xl font-bold">{score}</span>
                    <span className="text-right">{opponent}</span>
                  </div>
                </CardTitle>
                
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {match.venue === 'home' ? 'Thuis' : 'Uit'}
                  </div>
                  <Badge variant="outline">{match.competition}</Badge>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                {/* Status Indicators */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Video Status:</span>
                    <Badge variant={match.videoUploaded ? "default" : "secondary"}>
                      {match.videoUploaded ? "Geüpload" : "Nog niet geüpload"}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Analyse Status:</span>
                    <Badge variant={match.analysisComplete ? "default" : "secondary"}>
                      {match.analysisComplete ? "Voltooid" : "Nog niet gestart"}
                    </Badge>
                  </div>

                  {match.frameCount && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Frames:</span>
                      <span className="text-sm font-medium">{match.frameCount.toLocaleString()}</span>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="space-y-2">
                  {!match.videoUploaded && (
                    <div>
                      <input
                        type="file"
                        accept="video/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleVideoUpload(match.id, file);
                        }}
                        className="hidden"
                        id={`upload-${match.id}`}
                      />
                      <Button
                        onClick={() => document.getElementById(`upload-${match.id}`)?.click()}
                        className="w-full"
                        disabled={uploadingMatch === match.id}
                        variant="outline"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        {uploadingMatch === match.id ? "Uploaden..." : "Upload Video"}
                      </Button>
                    </div>
                  )}

                  {match.videoUploaded && !match.analysisComplete && (
                    <Button
                      onClick={() => startAnalysis(match.id)}
                      className="w-full"
                      variant="default"
                    >
                      <BarChart3 className="h-4 w-4 mr-2" />
                      Start Analyse
                    </Button>
                  )}

                  {match.analysisComplete && (
                    <Button
                      onClick={() => window.open(`/real-match-analysis/${match.id}`, '_blank')}
                      className="w-full"
                      variant="default"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Bekijk Analyse
                    </Button>
                  )}
                </div>

                {/* Progress Bar for Analysis */}
                {match.videoUploaded && !match.analysisComplete && (
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span>Analyse Voortgang</span>
                      <span>0%</span>
                    </div>
                    <Progress value={0} className="h-2" />
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}