import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { BackToMenu } from "@/components/ui/back-to-menu";
import { 
  Upload, 
  Play, 
  Pause, 
  Square, 
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Target,
  Users,
  Clock,
  Eye,
  Zap,
  Download,
  Save,
  AlertCircle
} from "lucide-react";

interface DetectedEvent {
  id: string;
  timestamp: number;
  type: 'goal' | 'yellow_card' | 'red_card' | 'substitution' | 'foul' | 'corner' | 'freekick';
  confidence: number;
  player?: string;
  team: 'home' | 'away';
  description: string;
  frameData?: string;
}

interface MatchData {
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  duration: number;
  events: DetectedEvent[];
}

export default function VideoMatchAnalyzer() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [detectedEvents, setDetectedEvents] = useState<DetectedEvent[]>([]);
  const [matchData, setMatchData] = useState<MatchData>({
    homeTeam: 'VVC Brasschaat',
    awayTeam: 'KVKS Melsele',
    homeScore: 0,
    awayScore: 0,
    duration: 0,
    events: []
  });

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const updateTime = () => setCurrentTime(video.currentTime);
    const updateDuration = () => setDuration(video.duration);

    video.addEventListener('timeupdate', updateTime);
    video.addEventListener('loadedmetadata', updateDuration);

    return () => {
      video.removeEventListener('timeupdate', updateTime);
      video.removeEventListener('loadedmetadata', updateDuration);
    };
  }, [videoFile]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setVideoFile(file);
      const url = URL.createObjectURL(file);
      setVideoUrl(url);
      setDetectedEvents([]);
      setMatchData(prev => ({ ...prev, events: [], homeScore: 0, awayScore: 0 }));
    }
  };

  const togglePlayPause = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (time: number) => {
    const video = videoRef.current;
    if (!video) return;
    
    video.currentTime = time;
    setCurrentTime(time);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const analyzeVideoFrame = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return null;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Capture current frame
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);
    
    // Convert to base64 for analysis
    const frameData = canvas.toDataURL('image/jpeg', 0.8);
    
    // Simulated AI analysis - in real implementation this would use computer vision
    return analyzeFrameWithAI(frameData, currentTime);
  };

  const analyzeFrameWithAI = (frameData: string, timestamp: number): DetectedEvent | null => {
    // Simulated event detection based on video analysis
    // In real implementation, this would use computer vision APIs like OpenCV or cloud services
    
    // Random chance of detecting events for demonstration
    if (Math.random() > 0.95) {
      const eventTypes = ['goal', 'yellow_card', 'foul', 'corner'] as const;
      const randomType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
      const team = Math.random() > 0.5 ? 'home' : 'away';
      
      return {
        id: Date.now().toString(),
        timestamp,
        type: randomType,
        confidence: 0.85 + Math.random() * 0.15,
        team,
        description: `${randomType} gedetecteerd via video analyse`,
        frameData
      };
    }
    
    return null;
  };

  const startVideoAnalysis = async () => {
    if (!videoFile) return;
    
    setIsAnalyzing(true);
    setAnalysisProgress(0);
    
    const video = videoRef.current;
    if (!video) return;
    
    const totalFrames = Math.floor(duration * 2); // Analyze 2 frames per second
    const events: DetectedEvent[] = [];
    
    for (let i = 0; i < totalFrames; i++) {
      const timestamp = (i / 2); // 2 FPS analysis
      
      // Seek to timestamp
      video.currentTime = timestamp;
      
      // Wait for video to seek
      await new Promise(resolve => {
        const onSeeked = () => {
          video.removeEventListener('seeked', onSeeked);
          resolve(undefined);
        };
        video.addEventListener('seeked', onSeeked);
      });
      
      // Analyze frame
      const event = await analyzeVideoFrame();
      if (event) {
        events.push(event);
        
        // Update score for goals
        if (event.type === 'goal') {
          setMatchData(prev => ({
            ...prev,
            homeScore: event.team === 'home' ? prev.homeScore + 1 : prev.homeScore,
            awayScore: event.team === 'away' ? prev.awayScore + 1 : prev.awayScore
          }));
        }
      }
      
      setAnalysisProgress((i / totalFrames) * 100);
      
      // Small delay to prevent overwhelming
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    setDetectedEvents(events);
    setMatchData(prev => ({ ...prev, events, duration }));
    setIsAnalyzing(false);
    setAnalysisProgress(100);
  };

  const jumpToEvent = (timestamp: number) => {
    handleSeek(timestamp);
  };

  const exportAnalysis = () => {
    const analysis = {
      ...matchData,
      videoFile: videoFile?.name,
      analysisDate: new Date().toISOString(),
      detectedEvents: detectedEvents.map(event => ({
        ...event,
        frameData: undefined // Remove frame data for file size
      }))
    };
    
    const blob = new Blob([JSON.stringify(analysis, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `video-analysis-${matchData.homeTeam}-vs-${matchData.awayTeam}.json`;
    a.click();
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <BackToMenu />
      
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Video Wedstrijd Analyzer</h1>
        <p className="text-gray-600">Automatische detectie van doelpunten en events uit wedstrijdbeelden</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Video Player */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Video Upload & Analyse</span>
                {videoFile && (
                  <Badge variant="secondary">{videoFile.name}</Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!videoFile ? (
                <div 
                  className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-900 mb-2">Upload Wedstrijdvideo</p>
                  <p className="text-gray-500">MP4, AVI, MOV bestanden ondersteund</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="space-y-4">
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    className="w-full rounded-lg"
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                  />
                  
                  {/* Video Controls */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Button size="sm" onClick={togglePlayPause}>
                        {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleSeek(currentTime - 10)}>
                        <SkipBack className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleSeek(currentTime + 10)}>
                        <SkipForward className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => setIsMuted(!isMuted)}
                        onClickCapture={() => {
                          if (videoRef.current) {
                            videoRef.current.muted = !isMuted;
                          }
                        }}
                      >
                        {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                      </Button>
                      <span className="text-sm text-gray-500">
                        {formatTime(currentTime)} / {formatTime(duration)}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min="0"
                        max={duration || 0}
                        value={currentTime}
                        onChange={(e) => handleSeek(parseFloat(e.target.value))}
                        className="flex-1"
                      />
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Match Score */}
          {videoFile && (
            <Card>
              <CardHeader>
                <CardTitle className="text-center">
                  {matchData.homeTeam} {matchData.homeScore} - {matchData.awayScore} {matchData.awayTeam}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-center gap-4">
                  <Button 
                    onClick={startVideoAnalysis} 
                    disabled={isAnalyzing}
                    className="px-8"
                  >
                    {isAnalyzing ? (
                      <>
                        <Eye className="h-4 w-4 mr-2 animate-spin" />
                        Analyseren...
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 mr-2" />
                        Start Video Analyse
                      </>
                    )}
                  </Button>
                  {detectedEvents.length > 0 && (
                    <Button variant="outline" onClick={exportAnalysis}>
                      <Download className="h-4 w-4 mr-2" />
                      Export Analyse
                    </Button>
                  )}
                </div>
                
                {isAnalyzing && (
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span>Video analyse voortgang</span>
                      <span>{Math.round(analysisProgress)}%</span>
                    </div>
                    <Progress value={analysisProgress} className="w-full" />
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Events Panel */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Gedetecteerde Events
              </CardTitle>
              <CardDescription>
                {detectedEvents.length} events gevonden
              </CardDescription>
            </CardHeader>
            <CardContent>
              {detectedEvents.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {detectedEvents
                    .sort((a, b) => a.timestamp - b.timestamp)
                    .map(event => (
                      <div 
                        key={event.id} 
                        className="p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                        onClick={() => jumpToEvent(event.timestamp)}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <Badge variant={event.type === 'goal' ? 'default' : 'secondary'}>
                            {formatTime(event.timestamp)}
                          </Badge>
                          <Badge variant={event.team === 'home' ? 'default' : 'destructive'}>
                            {event.team === 'home' ? matchData.homeTeam : matchData.awayTeam}
                          </Badge>
                        </div>
                        <p className="text-sm font-medium">{event.description}</p>
                        <p className="text-xs text-gray-500">
                          Vertrouwen: {Math.round(event.confidence * 100)}%
                        </p>
                      </div>
                    ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500">Nog geen events gedetecteerd</p>
                  <p className="text-sm text-gray-400 mt-1">
                    Upload een video en start de analyse
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Analyse Instellingen</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Thuisploeg</Label>
                <Input
                  value={matchData.homeTeam}
                  onChange={(e) => setMatchData(prev => ({ ...prev, homeTeam: e.target.value }))}
                />
              </div>
              <div>
                <Label>Uitploeg</Label>
                <Input
                  value={matchData.awayTeam}
                  onChange={(e) => setMatchData(prev => ({ ...prev, awayTeam: e.target.value }))}
                />
              </div>
              
              <div className="bg-blue-50 p-3 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">AI Detectie:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Doelpunten automatisch</li>
                  <li>• Kaarten en overtredingen</li>
                  <li>• Corners en vrije trappen</li>
                  <li>• Spelerwissels</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Hidden canvas for frame analysis */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}