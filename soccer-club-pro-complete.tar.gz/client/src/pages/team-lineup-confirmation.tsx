import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BackToMenu } from "@/components/ui/back-to-menu";
import { 
  Upload, 
  Users, 
  CheckCircle, 
  Edit,
  Save,
  FileImage,
  User,
  Hash,
  MapPin
} from "lucide-react";

interface PlayerLineup {
  id: string;
  name: string;
  jerseyNumber: number;
  position: string;
  team: 'home' | 'away';
  confirmed: boolean;
}

const TeamLineupConfirmation = () => {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [detectedPlayers, setDetectedPlayers] = useState<PlayerLineup[]>([]);
  const [editingPlayer, setEditingPlayer] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Predefined VVC and Svelta Melsele players
  const vvcPlayers = [
    { name: 'Joni Billen', jerseyNumber: 1, position: 'goalkeeper' },
    { name: 'Yentl De Coster', jerseyNumber: 2, position: 'defender' },
    { name: 'Lies Stappaerts', jerseyNumber: 3, position: 'defender' },
    { name: 'Sien Schepens', jerseyNumber: 4, position: 'midfielder' },
    { name: 'Jana Andriessen', jerseyNumber: 5, position: 'defender' },
    { name: 'Louise Creemers', jerseyNumber: 6, position: 'midfielder' },
    { name: 'Eline Wyn', jerseyNumber: 7, position: 'midfielder' },
    { name: 'Maud Bastiaensen', jerseyNumber: 8, position: 'defender' },
    { name: 'Emma Scheyvaerts', jerseyNumber: 9, position: 'defender' },
    { name: 'Sif Rapollak', jerseyNumber: 10, position: 'midfielder' },
    { name: 'Aiko Lenaerts', jerseyNumber: 11, position: 'midfielder' }
  ];

  const sveltaPlayers = [
    { name: 'Emma De Smet', jerseyNumber: 1, position: 'goalkeeper' },
    { name: 'Lisa Van Damme', jerseyNumber: 2, position: 'defender' },
    { name: 'Sarah Verstraete', jerseyNumber: 3, position: 'defender' },
    { name: 'Kim Martens', jerseyNumber: 4, position: 'midfielder' },
    { name: 'Nele Jacobs', jerseyNumber: 5, position: 'defender' },
    { name: 'Julie Van Hove', jerseyNumber: 6, position: 'midfielder' },
    { name: 'Amber Claeys', jerseyNumber: 7, position: 'forward' },
    { name: 'Fien De Bruyn', jerseyNumber: 8, position: 'midfielder' },
    { name: 'Lotte Vandecasteele', jerseyNumber: 9, position: 'forward' },
    { name: 'Silke Van Der Meer', jerseyNumber: 10, position: 'midfielder' },
    { name: 'Tine Goossens', jerseyNumber: 11, position: 'forward' }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setUploadedImage(imageUrl);
      
      // Simulate team detection and pre-populate with real player data
      const detectedTeam: PlayerLineup[] = [
        ...vvcPlayers.map((player, index) => ({
          id: `vvc-${index}`,
          name: player.name,
          jerseyNumber: player.jerseyNumber,
          position: player.position,
          team: 'home' as const,
          confirmed: false
        })),
        ...sveltaPlayers.map((player, index) => ({
          id: `svelta-${index}`,
          name: player.name,
          jerseyNumber: player.jerseyNumber,
          position: player.position,
          team: 'away' as const,
          confirmed: false
        }))
      ];
      
      setDetectedPlayers(detectedTeam);
      
      toast({
        title: "Team Lineup Gedetecteerd",
        description: `${detectedTeam.length} spelers gevonden - bevestig de details`,
      });
    };
    reader.readAsDataURL(file);
  };

  const updatePlayer = (playerId: string, field: keyof PlayerLineup, value: any) => {
    setDetectedPlayers(prev => 
      prev.map(player => 
        player.id === playerId ? { ...player, [field]: value } : player
      )
    );
  };

  const confirmPlayer = (playerId: string) => {
    updatePlayer(playerId, 'confirmed', true);
    setEditingPlayer(null);
    toast({
      title: "Speler Bevestigd",
      description: "Spelergegevens zijn opgeslagen",
    });
  };

  const confirmAllPlayers = async () => {
    const unconfirmed = detectedPlayers.filter(p => !p.confirmed);
    if (unconfirmed.length > 0) {
      toast({
        title: "Bevestiging Vereist",
        description: `${unconfirmed.length} spelers moeten nog bevestigd worden`,
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    try {
      // Send confirmed lineup to backend
      await apiRequest('/api/match-performance/confirm-lineup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          matchId: '5',
          players: detectedPlayers
        })
      });

      toast({
        title: "Lineup Bevestigd",
        description: "Alle spelergegevens zijn opgeslagen voor GPS analyse",
      });

      queryClient.invalidateQueries({ queryKey: ['/api/match-performance'] });
    } catch (error) {
      toast({
        title: "Opslaan Mislukt",
        description: "Er ging iets mis bij het opslaan",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const homeTeam = detectedPlayers.filter(p => p.team === 'home');
  const awayTeam = detectedPlayers.filter(p => p.team === 'away');

  return (
    <div className="space-y-6">
      <BackToMenu />
      
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Team Lineup Bevestiging</h1>
          <p className="text-muted-foreground">Upload teamfoto en bevestig spelergegevens</p>
        </div>
      </div>

      {/* Upload Section */}
      {!uploadedImage && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Upload Teamfoto
            </CardTitle>
            <CardDescription>
              Upload een teamfoto om de lineup te detecteren en te bevestigen
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <FileImage className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <Label htmlFor="team-photo" className="cursor-pointer">
                <span className="text-lg font-medium">Klik om teamfoto te uploaden</span>
                <p className="text-sm text-muted-foreground mt-2">JPG, PNG tot 5MB</p>
              </Label>
              <Input
                id="team-photo"
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Image Preview and Player Confirmation */}
      {uploadedImage && (
        <div className="space-y-6">
          {/* Uploaded Image */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Geüploade Teamfoto</span>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setUploadedImage(null);
                    setDetectedPlayers([]);
                  }}
                >
                  Nieuwe Foto
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <img 
                src={uploadedImage} 
                alt="Team Lineup" 
                className="w-full max-h-96 object-contain rounded-lg border"
              />
            </CardContent>
          </Card>

          {/* Team Lineups */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* VVC Dames IP (Home) */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  VVC Dames IP (Thuis)
                  <Badge variant="default">{homeTeam.filter(p => p.confirmed).length}/{homeTeam.length} bevestigd</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {homeTeam.map((player) => (
                  <div key={player.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline">#{player.jerseyNumber}</Badge>
                        <span className="font-medium">{player.name}</span>
                        <Badge variant="secondary">{player.position}</Badge>
                      </div>
                      {player.confirmed ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingPlayer(editingPlayer === player.id ? null : player.id)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    {editingPlayer === player.id && (
                      <div className="grid grid-cols-3 gap-3 pt-3 border-t">
                        <div>
                          <Label>Naam</Label>
                          <Input
                            value={player.name}
                            onChange={(e) => updatePlayer(player.id, 'name', e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>Nummer</Label>
                          <Input
                            type="number"
                            value={player.jerseyNumber}
                            onChange={(e) => updatePlayer(player.id, 'jerseyNumber', parseInt(e.target.value))}
                          />
                        </div>
                        <div>
                          <Label>Positie</Label>
                          <Select 
                            value={player.position} 
                            onValueChange={(value) => updatePlayer(player.id, 'position', value)}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="goalkeeper">Keeper</SelectItem>
                              <SelectItem value="defender">Verdediger</SelectItem>
                              <SelectItem value="midfielder">Middenvelder</SelectItem>
                              <SelectItem value="forward">Aanvaller</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="col-span-3">
                          <Button 
                            onClick={() => confirmPlayer(player.id)}
                            className="w-full"
                            size="sm"
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Bevestigen
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Svelta Melsele (Away) */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Svelta Melsele (Uit)
                  <Badge variant="secondary">{awayTeam.filter(p => p.confirmed).length}/{awayTeam.length} bevestigd</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {awayTeam.map((player) => (
                  <div key={player.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline">#{player.jerseyNumber}</Badge>
                        <span className="font-medium">{player.name}</span>
                        <Badge variant="secondary">{player.position}</Badge>
                      </div>
                      {player.confirmed ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingPlayer(editingPlayer === player.id ? null : player.id)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    {editingPlayer === player.id && (
                      <div className="grid grid-cols-3 gap-3 pt-3 border-t">
                        <div>
                          <Label>Naam</Label>
                          <Input
                            value={player.name}
                            onChange={(e) => updatePlayer(player.id, 'name', e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>Nummer</Label>
                          <Input
                            type="number"
                            value={player.jerseyNumber}
                            onChange={(e) => updatePlayer(player.id, 'jerseyNumber', parseInt(e.target.value))}
                          />
                        </div>
                        <div>
                          <Label>Positie</Label>
                          <Select 
                            value={player.position} 
                            onValueChange={(value) => updatePlayer(player.id, 'position', value)}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="goalkeeper">Keeper</SelectItem>
                              <SelectItem value="defender">Verdediger</SelectItem>
                              <SelectItem value="midfielder">Middenvelder</SelectItem>
                              <SelectItem value="forward">Aanvaller</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="col-span-3">
                          <Button 
                            onClick={() => confirmPlayer(player.id)}
                            className="w-full"
                            size="sm"
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Bevestigen
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Confirm All Button */}
          {detectedPlayers.length > 0 && (
            <Card>
              <CardContent className="pt-6">
                <Button 
                  onClick={confirmAllPlayers}
                  disabled={uploading || detectedPlayers.some(p => !p.confirmed)}
                  className="w-full"
                  size="lg"
                >
                  <Save className="h-5 w-5 mr-2" />
                  {uploading ? 'Opslaan...' : 'Alle Spelers Bevestigen & GPS Data Genereren'}
                </Button>
                <p className="text-sm text-muted-foreground text-center mt-2">
                  Bevestig alle spelers om GPS performance data te genereren
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default TeamLineupConfirmation;