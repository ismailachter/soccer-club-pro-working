import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Eye, Edit, MoreHorizontal, Search, Plus } from "lucide-react";
import { Player } from "@/types";
import { getStatusColor, cn } from "@/lib/utils";
import { AvatarUpload } from "@/components/ui/avatar-upload";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

// Form schema for player creation
const playerFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  dateOfBirth: z.string().min(1, "Date of birth is required"),
  teamId: z.string().min(1, "Team selection is required"),
  position: z.string().min(1, "Position is required"),
  status: z.string().min(1, "Status is required"),
});

type PlayerFormValues = z.infer<typeof playerFormSchema>;

export default function Players() {
  const [isAddPlayerOpen, setIsAddPlayerOpen] = useState(false);
  const [viewPlayer, setViewPlayer] = useState<Player | null>(null);
  const [editPlayer, setEditPlayer] = useState<Player | null>(null);
  const [selectedTeamFilter, setSelectedTeamFilter] = useState<string>("all");
  const [selectedPositionFilter, setSelectedPositionFilter] = useState<string>("all");
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>("active");
  const [playerToRemove, setPlayerToRemove] = useState<Player | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Form setup
  const form = useForm<PlayerFormValues>({
    resolver: zodResolver(playerFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      dateOfBirth: "",
      teamId: "",
      position: "",
      status: "active",
    },
  });

  // Fetch players data
  const { data: players, isLoading, error } = useQuery<Player[]>({
    queryKey: ['/api/players'],
  });

  // Fetch teams data for dropdowns
  const { data: teams } = useQuery({
    queryKey: ['/api/teams'],
    queryFn: async () => {
      const response = await fetch('/api/teams');
      if (!response.ok) throw new Error('Failed to fetch teams');
      return response.json();
    },
  });

  // Create player mutation
  const createPlayerMutation = useMutation({
    mutationFn: async (data: PlayerFormValues) => {
      const response = await fetch('/api/players', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          firstName: data.firstName,
          lastName: data.lastName,
          email: data.email,
          dateOfBirth: data.dateOfBirth,
          teamId: parseInt(data.teamId),
          position: data.position,
          status: data.status,
          sendWelcomeEmail: true, // Flag to send welcome email
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create player');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Player created successfully! Welcome email sent.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/players'] });
      setIsAddPlayerOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create player. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PlayerFormValues) => {
    createPlayerMutation.mutate(data);
  };

  // Define columns for data table
  const columns = [
    {
      header: "Name",
      accessorKey: "user",
      cell: (player: Player) => (
        <div className="flex items-center">
          <div className="h-10 w-10 flex-shrink-0 rounded-full bg-secondary-200">
            {player.user?.profileImage && (
              <img 
                src={player.user.profileImage} 
                alt={`${player.user?.firstName} ${player.user?.lastName}`}
                className="h-full w-full rounded-full object-cover"
              />
            )}
          </div>
          <div className="ml-4">
            <div className="font-medium text-foreground">
              {player.user?.firstName} {player.user?.lastName}
            </div>
            <div className="text-muted-foreground">#{player.jerseyNumber || 'N/A'}</div>
          </div>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Team",
      accessorKey: "team.name",
      sortable: true,
    },
    {
      header: "Position",
      accessorKey: "position",
      cell: (player: Player) => (
        <span className="capitalize">{player.position || 'Unassigned'}</span>
      ),
      sortable: true,
    },
    {
      header: "Age",
      accessorKey: "user.dateOfBirth",
      cell: (player: Player) => {
        if (!player.user?.dateOfBirth) return 'N/A';
        const birthDate = new Date(player.user.dateOfBirth);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
          age--;
        }
        return age;
      },
      sortable: true,
    },
    {
      header: "Goals",
      accessorKey: "statistics.goals",
      cell: (player: Player) => player.statistics?.goals || 0,
      sortable: true,
    },
    {
      header: "Assists",
      accessorKey: "statistics.assists",
      cell: (player: Player) => player.statistics?.assists || 0,
      sortable: true,
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (player: Player) => {
        const statusColor = getStatusColor(player.status);
        return (
          <Badge variant="outline" className={cn("capitalize", statusColor.bg, statusColor.text)}>
            {player.status}
          </Badge>
        );
      },
      sortable: true,
    },
    {
      header: "Actions",
      accessorKey: "id",
      cell: (player: Player) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => setViewPlayer(player)}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  if (isLoading) {
    return <div className="p-8 text-center">Loading players...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading players.</div>;
  }

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Players Management</h2>
        <Dialog open={isAddPlayerOpen} onOpenChange={setIsAddPlayerOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add New Player
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Player</DialogTitle>
              <DialogDescription>
                Enter the player details below to create a new player record. They will receive a welcome email.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
                  <div className="flex flex-col items-center justify-center">
                    <AvatarUpload 
                      onUpload={(file) => console.log('File uploaded:', file)}
                      size="lg"
                    />
                  </div>
                  <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input placeholder="First Name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Last Name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="dateOfBirth"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date of Birth</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="teamId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Team</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select team" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {teams?.map((team: any) => (
                                <SelectItem key={team.id} value={team.id.toString()}>
                                  {team.name} ({team.ageGroup})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="position"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Position</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select position" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="goalkeeper">Goalkeeper</SelectItem>
                              <SelectItem value="defender">Defender</SelectItem>
                              <SelectItem value="midfielder">Midfielder</SelectItem>
                              <SelectItem value="forward">Forward</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="inactive">Inactive</SelectItem>
                              <SelectItem value="injured">Injured</SelectItem>
                              <SelectItem value="suspended">Suspended</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-3">
                  <Button type="button" variant="outline" onClick={() => setIsAddPlayerOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createPlayerMutation.isPending}>
                    {createPlayerMutation.isPending ? "Creating..." : "Save Player"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and filters */}
      <Card className="mb-6 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <Label htmlFor="player-search" className="mb-1 block">Search Players</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input id="player-search" placeholder="Search by name, team or position..." className="pl-10" />
            </div>
          </div>
          <div>
            <Label htmlFor="team-filter" className="mb-1 block">Team</Label>
            <Select value={selectedTeamFilter} onValueChange={setSelectedTeamFilter}>
              <SelectTrigger id="team-filter">
                <SelectValue placeholder="All Teams" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Teams</SelectItem>
                {teams?.map((team) => (
                  <SelectItem key={team.id} value={team.id.toString()}>
                    {team.name} ({team.ageGroup})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="position-filter" className="mb-1 block">Position</Label>
            <Select value={selectedPositionFilter} onValueChange={setSelectedPositionFilter}>
              <SelectTrigger id="position-filter">
                <SelectValue placeholder="All Positions" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Positions</SelectItem>
                <SelectItem value="forward">Forward</SelectItem>
                <SelectItem value="midfielder">Midfielder</SelectItem>
                <SelectItem value="defender">Defender</SelectItem>
                <SelectItem value="goalkeeper">Goalkeeper</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="status-filter" className="mb-1 block">Status</Label>
            <Select value={selectedStatusFilter} onValueChange={setSelectedStatusFilter}>
              <SelectTrigger id="status-filter">
                <SelectValue placeholder="Player Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active Only</SelectItem>
                <SelectItem value="all">All Players</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="injured">Injured</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* Debug info */}
      <div className="mb-4 p-4 bg-gray-50 rounded border">
        <p><strong>Debug Info:</strong></p>
        <p>Players loaded: {players ? players.length : 'none'}</p>
        <p>Loading: {isLoading ? 'yes' : 'no'}</p>
        <p>Error: {error ? error.message : 'none'}</p>
        {players && players.length > 0 && (
          <details className="mt-2">
            <summary>Raw player data</summary>
            <pre className="text-xs bg-white p-2 mt-2 rounded border overflow-auto">
              {JSON.stringify(players, null, 2)}
            </pre>
          </details>
        )}
      </div>

      {/* Simple Players List */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-4">All Registered Players</h3>
        {players && players.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {players
              .filter(player => {
                // Team filter
                const teamMatch = selectedTeamFilter === "all" || 
                  (player.teamId && player.teamId.toString() === selectedTeamFilter);
                
                // Position filter
                const positionMatch = selectedPositionFilter === "all" || 
                  (player.position && player.position.toLowerCase() === selectedPositionFilter.toLowerCase());
                
                // Status filter - Hide players you don't want to see anymore
                const statusMatch = selectedStatusFilter === "all" || 
                  (player.status || 'active') === selectedStatusFilter;
                
                return teamMatch && positionMatch && statusMatch;
              })
              .map((player, index) => (
              <div key={player.id} className="border rounded-lg p-4 bg-white shadow-sm">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    {player.user?.profilePicture ? (
                      <img 
                        src={player.user.profilePicture} 
                        alt={`${player.user.firstName} ${player.user.lastName}`}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-lg font-medium text-primary">
                        {player.user?.firstName?.charAt(0)}{player.user?.lastName?.charAt(0)}
                      </span>
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-foreground">
                      {player.user?.firstName} {player.user?.lastName}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {player.team?.name || 'No team assigned'} • {player.position || 'No position'}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {player.user?.email}
                    </p>
                    {player.user?.phone && (
                      <p className="text-xs text-muted-foreground">
                        📞 {player.user.phone}
                      </p>
                    )}
                  </div>
                </div>
                <div className="mt-3 flex justify-between items-center">
                  <div className="flex space-x-2">
                    {player.jerseyNumber && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        #{player.jerseyNumber}
                      </span>
                    )}
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      player.status === 'active' ? 'bg-green-100 text-green-800' :
                      player.status === 'injured' ? 'bg-red-100 text-red-800' :
                      player.status === 'suspended' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {player.status || 'active'}
                    </span>
                  </div>
                  <div className="flex space-x-1">
                    <Button variant="outline" size="sm" onClick={() => setViewPlayer(player)}>
                      View
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setEditPlayer(player)}>
                      Edit
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            No players registered yet. Click "Add New Player" to get started.
          </div>
        )}
      </div>

      {/* Players table */}
      {isLoading ? (
        <div className="flex items-center justify-center py-8">
          <div className="text-muted-foreground">Loading players...</div>
        </div>
      ) : error ? (
        <div className="flex items-center justify-center py-8">
          <div className="text-red-500">Error loading players: {error.message}</div>
        </div>
      ) : (
        <DataTable
          data={players || []}
          columns={columns}
          searchable={true}
          searchKey="lastName"
        />
      )}

      {/* Player detail dialog */}
      {viewPlayer && (
        <Dialog open={!!viewPlayer} onOpenChange={() => setViewPlayer(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Player Details</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
              <div className="flex flex-col items-center space-y-4">
                <div className="h-32 w-32 rounded-full bg-secondary-200 overflow-hidden">
                  {viewPlayer.user?.profileImage && (
                    <img 
                      src={viewPlayer.user.profileImage} 
                      alt={`${viewPlayer.user?.firstName} ${viewPlayer.user?.lastName}`}
                      className="h-full w-full object-cover"
                    />
                  )}
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-semibold">
                    {viewPlayer.user?.firstName} {viewPlayer.user?.lastName}
                  </h3>
                  <p className="text-muted-foreground">#{viewPlayer.jerseyNumber || 'N/A'}</p>
                </div>
                <Badge variant="outline" className={cn(
                  "capitalize", 
                  getStatusColor(viewPlayer.status).bg, 
                  getStatusColor(viewPlayer.status).text
                )}>
                  {viewPlayer.status}
                </Badge>
              </div>
              <div className="md:col-span-2 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Team</h4>
                    <p>{viewPlayer.team?.name || 'Unassigned'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Position</h4>
                    <p className="capitalize">{viewPlayer.position || 'Unassigned'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Email</h4>
                    <p>{viewPlayer.user?.email || 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Phone</h4>
                    <p>{viewPlayer.user?.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Height</h4>
                    <p>{viewPlayer.height ? `${viewPlayer.height} cm` : 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Weight</h4>
                    <p>{viewPlayer.weight ? `${viewPlayer.weight} kg` : 'N/A'}</p>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Statistics</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-secondary p-3 rounded-md text-center">
                      <p className="text-2xl font-semibold">{viewPlayer.statistics?.goals || 0}</p>
                      <p className="text-xs text-muted-foreground">Goals</p>
                    </div>
                    <div className="bg-secondary p-3 rounded-md text-center">
                      <p className="text-2xl font-semibold">{viewPlayer.statistics?.assists || 0}</p>
                      <p className="text-xs text-muted-foreground">Assists</p>
                    </div>
                    <div className="bg-secondary p-3 rounded-md text-center">
                      <p className="text-2xl font-semibold">{viewPlayer.statistics?.appearances || 0}</p>
                      <p className="text-xs text-muted-foreground">Appearances</p>
                    </div>
                  </div>
                </div>

                {viewPlayer.medicalInfo && (
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Medical Information</h4>
                    <p className="text-sm">{viewPlayer.medicalInfo}</p>
                  </div>
                )}

                {viewPlayer.emergencyContact && (
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Emergency Contact</h4>
                    <p className="text-sm">{viewPlayer.emergencyContact}</p>
                  </div>
                )}
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline">Edit Player</Button>
              <Button>Close</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Player Dialog */}
      {editPlayer && (
        <Dialog open={!!editPlayer} onOpenChange={() => {
          setEditPlayer(null);
          setPreviewImage(null);
        }}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Player: {editPlayer.user?.firstName} {editPlayer.user?.lastName}</DialogTitle>
              <DialogDescription>
                Update player information and team assignments.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              {/* Profile Picture */}
              <div className="flex flex-col items-center space-y-3 pb-4 border-b">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                  {previewImage ? (
                    <img 
                      src={previewImage} 
                      alt="Preview" 
                      className="w-full h-full object-cover"
                    />
                  ) : editPlayer.user?.profilePicture ? (
                    <img 
                      src={editPlayer.user.profilePicture} 
                      alt="Profile" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-2xl font-semibold text-primary">
                      {editPlayer.user?.firstName?.[0]}{editPlayer.user?.lastName?.[0]}
                    </span>
                  )}
                </div>
                <div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => document.getElementById('profile-upload')?.click()}
                  >
                    Change Photo
                  </Button>
                  <input
                    id="profile-upload"
                    type="file"
                    accept="image/png,image/jpg,image/jpeg"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        // Create a preview URL for the uploaded image
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          const imageUrl = event.target?.result as string;
                          setPreviewImage(imageUrl);
                          toast({
                            title: "Photo Selected",
                            description: `Selected: ${file.name}. Click "Save Changes" to update.`,
                          });
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </div>
              </div>

              {/* Team Assignment */}
              <div>
                <Label htmlFor="edit-team">Team</Label>
                <Select defaultValue={editPlayer.teamId?.toString()} onValueChange={(value) => {
                  // Here you would update the player's team
                  console.log('Changing team to:', value);
                }}>
                  <SelectTrigger id="edit-team">
                    <SelectValue placeholder="Select a team" />
                  </SelectTrigger>
                  <SelectContent>
                    {teams?.map((team) => (
                      <SelectItem key={team.id} value={team.id.toString()}>
                        {team.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Position */}
              <div>
                <Label htmlFor="edit-position">Position</Label>
                <Select defaultValue={editPlayer.position || ""} onValueChange={(value) => {
                  console.log('Changing position to:', value);
                }}>
                  <SelectTrigger id="edit-position">
                    <SelectValue placeholder="Select position" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="goalkeeper">Goalkeeper</SelectItem>
                    <SelectItem value="defender">Defender</SelectItem>
                    <SelectItem value="midfielder">Midfielder</SelectItem>
                    <SelectItem value="forward">Forward</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Phone Number */}
              <div>
                <Label htmlFor="edit-phone">Phone Number</Label>
                <Input 
                  id="edit-phone"
                  type="tel" 
                  defaultValue={editPlayer.user?.phone || ""} 
                  placeholder="Phone number"
                />
              </div>

              {/* Jersey Number */}
              <div>
                <Label htmlFor="edit-jersey">Jersey Number</Label>
                <Input 
                  id="edit-jersey"
                  type="number" 
                  defaultValue={editPlayer.jerseyNumber || ""} 
                  placeholder="Jersey number"
                />
              </div>

              {/* Status */}
              <div>
                <Label htmlFor="edit-status">Status</Label>
                <Select 
                  defaultValue={editPlayer.status || "active"}
                  onValueChange={(value) => {
                    console.log('Status changed to:', value);
                    // Update the editPlayer object with new status
                    setEditPlayer({...editPlayer, status: value});
                  }}
                >
                  <SelectTrigger id="edit-status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="injured">Injured</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DialogFooter className="mt-6">
              <div className="flex justify-between w-full">
                <Button 
                  variant="destructive" 
                  onClick={() => {
                    if (confirm(`Are you sure you want to remove ${editPlayer.user?.firstName} ${editPlayer.user?.lastName} from the club? This action cannot be undone.`)) {
                      toast({
                        title: "Player Removed",
                        description: `${editPlayer.user?.firstName} ${editPlayer.user?.lastName} has been removed from the club.`,
                        variant: "destructive",
                      });
                      setEditPlayer(null);
                      // Here you would call the API to delete the player
                    }
                  }}
                >
                  Remove Player
                </Button>
                
                <div className="flex space-x-2">
                  <Button variant="outline" onClick={() => setEditPlayer(null)}>
                    Cancel
                  </Button>
                  <Button onClick={async () => {
                    try {
                      // Get form values
                      const phoneInput = document.getElementById('edit-phone') as HTMLInputElement;
                      const jerseyInput = document.getElementById('edit-jersey') as HTMLInputElement;
                      
                      // Prepare update data
                      const updateData = {
                        status: editPlayer.status || 'active',
                        jerseyNumber: jerseyInput?.value ? parseInt(jerseyInput.value) : editPlayer.jerseyNumber,
                        phone: phoneInput?.value || editPlayer.user?.phone
                      };
                      
                      console.log('Saving player with data:', updateData);
                      
                      // Make API call to update player
                      const response = await fetch(`/api/players/${editPlayer.id}`, {
                        method: 'PUT',
                        headers: {
                          'Content-Type': 'application/json',
                        },
                        credentials: 'include',
                        body: JSON.stringify(updateData)
                      });
                      
                      if (!response.ok) {
                        throw new Error('Failed to update player');
                      }

                      const updatedPlayer = await response.json();
                      console.log('Player updated in database:', updatedPlayer);
                      
                      toast({
                        title: "Player Updated",
                        description: `${editPlayer.user?.firstName} ${editPlayer.user?.lastName} status changed to ${updateData.status}.`,
                      });
                      
                      // Force immediate refresh to show changes
                      queryClient.invalidateQueries({ queryKey: ['/api/players'] });
                      queryClient.invalidateQueries({ queryKey: ['/api/teams'] });
                      
                      // Close dialog and refresh
                      setEditPlayer(null);
                      
                      // Small delay then refresh page to ensure changes are visible
                      setTimeout(() => {
                        window.location.reload();
                      }, 500);
                    } catch (error) {
                      console.error('Update error:', error);
                      toast({
                        title: "Error",
                        description: "Failed to update player information.",
                        variant: "destructive",
                      });
                    }
                  }}>
                    Save Changes
                  </Button>
                </div>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
