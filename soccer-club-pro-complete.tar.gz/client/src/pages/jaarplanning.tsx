import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Plus, Download, Eye, Edit, Trash2, Save, X, Copy, Star, Target, Clock, MapPin, Users, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

interface TrainingPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface TrainingSession {
  week: number;
  session: number;
  date: string;
  duration: number;
  focusArea: string;
  assignedThemes: string[];
  assignedElements: string[];
  iadatabankElements: {
    basics: string[];
    teamtactisch: string[];
    mentaal: string[];
    fysiek: string[];
  };
  objectives: string[];
  notes: string;
}

export default function Jaarplanning() {
  const { user } = useAuth();
  const [plans, setPlans] = useState<TrainingPlan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<TrainingPlan | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingPlan, setEditingPlan] = useState<TrainingPlan | null>(null);
  const [viewMode, setViewMode] = useState<"overview" | "calendar" | "details">("overview");
  const [trainingSessions, setTrainingSessions] = useState<TrainingSession[]>([]);
  const [editingSession, setEditingSession] = useState<TrainingSession | null>(null);
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTeamId, setSelectedTeamId] = useState<number | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<string>("all");
  const [showIADatabankDialog, setShowIADatabankDialog] = useState(false);
  const [selectedSessionForIA, setSelectedSessionForIA] = useState<TrainingSession | null>(null);
  const [selectedIAElements, setSelectedIAElements] = useState<{[key: string]: boolean}>({});
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<number>(1);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [password, setPassword] = useState("");
  const [pendingAction, setPendingAction] = useState<{type: 'add' | 'remove', category: string, subcategory: string, level: number} | null>(null);
  
  // Filter states for enhanced overview
  const [searchTerm, setSearchTerm] = useState("");
  const [ageFilter, setAgeFilter] = useState("all");
  const [seasonFilter, setSeasonFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentWeek, setCurrentWeek] = useState(1);

  // Password handling for IADATABANK modifications
  const handleThemeAction = (type: 'add' | 'remove', category: string, subcategory: string, level: number) => {
    setPendingAction({ type, category, subcategory, level });
    setShowPasswordDialog(true);
  };

  const handlePasswordSubmit = () => {
    if (password === "Qunoot135!" && pendingAction) {
      // Execute the pending action
      console.log(`${pendingAction.type} thema voor ${pendingAction.category} ${pendingAction.subcategory} niveau ${pendingAction.level}`);
      
      // Here you would implement the actual theme modification logic
      // For now, just log the action
      
      // Reset state
      setPassword("");
      setShowPasswordDialog(false);
      setPendingAction(null);
    } else {
      alert("Incorrect wachtwoord!");
    }
  };

  // Fetch teams
  const { data: teams = [] } = useQuery<any[]>({
    queryKey: ["/api/teams"],
    enabled: !!user
  });

  // Form state for creating new plan
  const [newPlan, setNewPlan] = useState({
    name: "",
    description: "",
    ageGroup: "",
    teamId: null as number | null,
    season: "",
    startDate: "",
    endDate: "",
    sessionsPerWeek: 2,
    trainingDays: [] as string[]
  });

  const ageGroups = [
    "U8 - Pupillen (6-7 jaar)",
    "U10 - Pupillen (8-9 jaar)", 
    "U12 - Welpen (10-11 jaar)",
    "U14 - Scholieren (12-13 jaar)",
    "U16 - Junioren (14-15 jaar)",
    "U18 - Junioren (16-17 jaar)",
    "U21 - Beloften (18-20 jaar)",
    "Senioren (21+ jaar)"
  ];

  // Main focus area categories for jaarplanning creation
  const focusAreaOptions = [
    "BASICS B+",
    "BASICS B-",
    "TEAMTACTICS B+", 
    "TEAMTACTICS B-",
    "MENTAAL B+",
    "MENTAAL B-",
    "PHYSICS B+",
    "PHYSICS B-",
    "OMSCHAKELING"
  ];

  // Complete IADATABANK elements for detailed selection
  const iadatabankElements = {
    "BASICS B+": [
      "Leiden van de bal", "Dribbelen met de bal", "Korte Passing", "Middellange Passing", "Lange Passing",
      "Passing met het hoofd", "1 tijd Passing, Kaatsen", "Balcontrole Korte Pass", "Balcontrole Middellange Pass",
      "Balcontrole Lange Pass", "Schieten op doel", "Scoren met de voet", "Scoren met het hoofd",
      "Scoren na individuele actie trucks", "Vrijlopen aanspeelbaar zijn"
    ],
    "BASICS B-": [
      "Druk zetten tackle remmen", "Duel", "Interceptie balcontrole korte passing", "Interceptie balcontrole middellange passing",
      "Interceptie balcontrole lange passing", "Interceptie balcontrole kopbal", "Interceptie balcontrole kaatsbal",
      "Interceptie na balcontrole korte pass", "Interceptie na balcontrole middellange pass", "Interceptie na balcontrole lange pass",
      "Afweren schieten beletten", "Afweren scoren voet beletten", "Afweren scoren hoofd beletten",
      "Afweren scoren individuele actie beletten", "Positie tussen de linies", "Strikte dekking", "Ontvluchten vrij maken"
    ],
    "TEAMTACTICS B+": [
      "Positiespel", "Driehoeken vormen", "Creeer ruimte", "Creeer hoogte, diepte", "Opbouw van achteruit",
      "Combinatiespel", "Aanvalsorganisatie", "Breedte creëren", "Diepgang zoeken", "Switchen van spel",
      "Overlappen", "Ondersteunend spel", "Timing van loopacties", "Ruimte benutten", "Numerieke meerderheid",
      "Snelle omschakeling aanval", "Geduldig opbouwen", "Directe combinaties", "Flankaanvallen", "Centraal spel",
      "Standaardsituaties aanvallend"
    ],
    "TEAMTACTICS B-": [
      "Verdedigingsorganisatie", "Pressing", "Compactheid", "Dekking", "Buitenspelval", "Dueling",
      "Schuiven en dekken", "Communicatie verdediging", "Blok vormen", "Verdedigende transitie",
      "Restdefensie", "Persoonlijke markering", "Ruimte verdediging", "Anticiperen", "Intercepties",
      "Standaardsituaties verdedigend", "Eerste druk", "Tweede druk", "Defensieve discipline", "Counter pressing",
      "Verdedigende breedte"
    ],
    "MENTAAL B+": [
      "Concentratie", "Motivatie", "Zelfvertrouwen", "Doelgerichtheid", "Creativiteit", "Leiderschap",
      "Positieve instelling", "Doorzettingsvermogen", "Competitiedrang", "Teamwork", "Communicatie",
      "Besluitvorming", "Initiatief nemen", "Verantwoordelijkheid", "Coachability", "Adaptabiliteit",
      "Mentale weerbaarheid", "Focus behouden", "Druk omzetten in kans", "Winning mindset",
      "Technische rust onder druk", "Tactische discipline", "Emotionele controle", "Zelfanalyse",
      "Conflicthantering", "Timemanagement", "Visualisatie", "Doelen stellen", "Prestatie evaluatie"
    ],
    "MENTAAL B-": [
      "Stresshantering", "Frustratie overwinnen", "Angst beheersen", "Discipline", "Respect tonen",
      "Nederlaag verwerken", "Kritiek accepteren", "Geduld ontwikkelen", "Agressie kanaliseren",
      "Teleurstelling hanteren", "Zelfbeheersing", "Negatieve gedachten stoppen", "Druk verminderen",
      "Faalangst overwinnen", "Perfectionisme loslaten", "Boosheid beheersen", "Onzekerheid aanpakken",
      "Sociale druk weerstaan", "Afleiding elimineren", "Mentale rust vinden", "Stress signalen herkennen",
      "Ontspanningstechnieken", "Ademhalingsoefeningen", "Mindfulness", "Emotionele stabiliteit",
      "Mentale herstel", "Burn-out preventie", "Balans werk-privé", "Slaaproutine"
    ],
    "PHYSICS B+": [
      "Snelheid", "Explosiviteit", "Sprongkracht", "Kracht", "Behendigheid", "Coördinatie",
      "Reactievermogen", "Acceleratie", "Wendbaarheid", "Balans", "Timing", "Atletiek",
      "Conditietraining", "Krachttraining", "Plyometrische oefeningen", "Sprint techniek",
      "Versnelling", "Verticale sprong", "Horizontale sprong", "Voetwerk", "Laddertraining",
      "Kettlebell training", "Functionele bewegingen", "Sport specifieke kracht", "Power development",
      "Neuromusculaire training", "Proprioceptie", "Stabiliteit core", "Dynamische flexibiliteit"
    ],
    "PHYSICS B-": [
      "Uithoudingsvermogen", "Herstel", "Flexibiliteit", "Blessurepreventie", "Stabiliteit core",
      "Ademhaling", "Recuperatie", "Stretching", "Mobiliteit", "Voeding", "Hydratatie",
      "Slaap optimalisatie", "Actief herstel", "Massage", "Foam rolling", "Warmte/koude therapie",
      "Aerobe conditie", "Anaerobe drempel", "Lactaat tolerantie", "VO2 max training",
      "Intervaltraining", "Duurtraining", "Regeneratie", "Vermoeidheidsmanagement", "Overtraining preventie",
      "Fysiotherapie", "Corrective exercises", "Movement screening", "Injury rehabilitation"
    ],
    "OMSCHAKELING": [
      "Bal verovering", "Bal verlies", "Transitie aanval", "Transitie verdediging", "Pressing na balverlies",
      "Counter aanval", "Defensive recovery", "Mentale omschakeling", "Tactische aanpassing",
      "Tempo wisseling", "Switch van mindset", "Reactie op balverlies"
    ]
  };

  const seasons = [
    "2024-2025", "2025-2026", "2026-2027", "2027-2028"
  ];

  const weekDays = [
    { value: "maandag", label: "Maandag" },
    { value: "dinsdag", label: "Dinsdag" },
    { value: "woensdag", label: "Woensdag" },
    { value: "donderdag", label: "Donderdag" },
    { value: "vrijdag", label: "Vrijdag" },
    { value: "zaterdag", label: "Zaterdag" },
    { value: "zondag", label: "Zondag" }
  ];

  // Enhanced filter logic for plans
  const filteredPlans = plans.filter(plan => {
    // Search term filter
    if (searchTerm && !plan.name.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !plan.description.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // Age group filter
    if (ageFilter !== "all" && plan.ageGroup !== ageFilter) {
      return false;
    }
    
    // Season filter
    if (seasonFilter !== "all" && plan.season !== seasonFilter) {
      return false;
    }
    
    // Status filter
    if (statusFilter !== "all" && plan.status !== statusFilter) {
      return false;
    }
    
    // Team filter
    if (selectedTeam !== "all" && plan.teamId !== parseInt(selectedTeam)) {
      return false;
    }
    
    return true;
  });

  const createTrainingPlan = async () => {
    if (!newPlan.name || !newPlan.ageGroup || !newPlan.season) {
      alert("Vul alle verplichte velden in");
      return;
    }

    const startDate = new Date(newPlan.startDate);
    const endDate = new Date(newPlan.endDate);
    const totalWeeks = Math.ceil((endDate.getTime() - startDate.getTime()) / (7 * 24 * 60 * 60 * 1000));

    const selectedTeam = (teams as any[]).find((team: any) => team.id === newPlan.teamId);

    const plan: TrainingPlan = {
      id: Date.now(),
      name: newPlan.name,
      description: newPlan.description,
      ageGroup: newPlan.ageGroup,
      teamId: newPlan.teamId || undefined,
      teamName: selectedTeam?.name,
      season: newPlan.season,
      startDate: newPlan.startDate,
      endDate: newPlan.endDate,
      totalWeeks,
      sessionsPerWeek: newPlan.sessionsPerWeek,
      trainingDays: newPlan.trainingDays,
      created: new Date().toLocaleDateString('nl-NL'),
      status: "draft"
    };

    setPlans([...plans, plan]);
    setShowCreateDialog(false);
    
    // Reset form
    setNewPlan({
      name: "",
      description: "",
      ageGroup: "",
      teamId: null,
      season: "",
      startDate: "",
      endDate: "",
      sessionsPerWeek: 2,
      trainingDays: [],
    });

    alert(`Jaarplanning "${plan.name}" succesvol aangemaakt!`);
  };

  const editPlan = (plan: TrainingPlan) => {
    setEditingPlan(plan);
    setNewPlan({
      name: plan.name,
      description: plan.description,
      ageGroup: plan.ageGroup,
      teamId: plan.teamId || null,
      season: plan.season,
      startDate: plan.startDate,
      endDate: plan.endDate,
      sessionsPerWeek: plan.sessionsPerWeek,
      trainingDays: plan.trainingDays || [],
    });
    setShowEditDialog(true);
  };

  const updatePlan = async () => {
    if (!editingPlan || !newPlan.name || !newPlan.ageGroup || !newPlan.season) {
      alert("Vul alle verplichte velden in");
      return;
    }

    const startDate = new Date(newPlan.startDate);
    const endDate = new Date(newPlan.endDate);
    const totalWeeks = Math.ceil((endDate.getTime() - startDate.getTime()) / (7 * 24 * 60 * 60 * 1000));

    const updatedPlan: TrainingPlan = {
      ...editingPlan,
      name: newPlan.name,
      description: newPlan.description,
      ageGroup: newPlan.ageGroup,
      season: newPlan.season,
      startDate: newPlan.startDate,
      endDate: newPlan.endDate,
      totalWeeks,
      sessionsPerWeek: newPlan.sessionsPerWeek,
      trainingDays: newPlan.trainingDays,
    };

    setPlans(plans.map(p => p.id === editingPlan.id ? updatedPlan : p));
    setShowEditDialog(false);
    setEditingPlan(null);
    
    // Reset form
    setNewPlan({
      name: "",
      description: "",
      ageGroup: "",
      teamId: null,
      season: "",
      startDate: "",
      endDate: "",
      sessionsPerWeek: 2,
      trainingDays: [],
    });

    alert(`Jaarplanning "${updatedPlan.name}" succesvol bijgewerkt!`);
  };

  const deletePlan = (planId: number) => {
    setPlans(plans.filter(p => p.id !== planId));
    if (selectedPlan && selectedPlan.id === planId) {
      setSelectedPlan(null);
    }
    alert("Jaarplanning succesvol verwijderd!");
  };

  const duplicatePlan = (plan: TrainingPlan) => {
    const duplicatedPlan: TrainingPlan = {
      ...plan,
      id: Date.now(),
      name: `${plan.name} (Kopie)`,
      created: new Date().toLocaleDateString('nl-NL'),
      status: "draft"
    };
    
    setPlans([...plans, duplicatedPlan]);
    alert(`Jaarplanning gedupliceerd als "${duplicatedPlan.name}"`);
  };

  // Training Session Management Functions
  const addSessionToDate = (date: string, themes: string[], elements: string[]) => {
    const newSession: TrainingSession = {
      week: 0,
      session: 0,
      date: date,
      duration: 90,
      focusArea: themes.join(", "),
      assignedThemes: themes,
      assignedElements: elements,
      iadatabankElements: {
        basics: elements.filter(e => e.includes("BASICS")),
        teamtactisch: elements.filter(e => e.includes("TEAMTACTICS")),
        mentaal: elements.filter(e => e.includes("MENTAAL")),
        fysiek: elements.filter(e => e.includes("PHYSICS"))
      },
      objectives: [],
      notes: ""
    };
    
    setTrainingSessions([...trainingSessions, newSession]);
    alert(`Training toegevoegd voor ${date}`);
  };

  const updateSessionForDate = (date: string, themes: string[], elements: string[]) => {
    setTrainingSessions(sessions => 
      sessions.map(session => 
        session.date === date 
          ? {
              ...session,
              focusArea: themes.join(", "),
              assignedThemes: themes,
              assignedElements: elements,
              iadatabankElements: {
                basics: elements.filter(e => e.includes("BASICS")),
                teamtactisch: elements.filter(e => e.includes("TEAMTACTICS")),
                mentaal: elements.filter(e => e.includes("MENTAAL")),
                fysiek: elements.filter(e => e.includes("PHYSICS"))
              }
            }
          : session
      )
    );
    alert(`Training bijgewerkt voor ${date}`);
  };

  const removeSessionFromDate = (date: string) => {
    setTrainingSessions(sessions => sessions.filter(session => session.date !== date));
    alert(`Training verwijderd voor ${date}`);
  };

  const openSessionEditor = (date: string) => {
    setSelectedDate(date);
    const existingSession = trainingSessions.find(s => s.date === date);
    if (existingSession) {
      setEditingSession(existingSession);
    } else {
      setEditingSession(null);
    }
    setShowSessionDialog(true);
  };

  // Generate calendar dates for selected plan
  const generateCalendarDates = (plan: TrainingPlan) => {
    const startDate = new Date(plan.startDate);
    const endDate = new Date(plan.endDate);
    const dates = [];
    
    // Start from first day of the month containing start date
    const calendarStart = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
    // End at last day of the month containing end date
    const calendarEnd = new Date(endDate.getFullYear(), endDate.getMonth() + 1, 0);
    
    // Add days before start of month to fill week
    const startDay = calendarStart.getDay();
    for (let i = startDay - 1; i >= 0; i--) {
      const date = new Date(calendarStart);
      date.setDate(date.getDate() - i - 1);
      dates.push({
        date: date.toLocaleDateString('nl-NL'),
        day: date.getDate(),
        dayName: ['zondag', 'maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag'][date.getDay()],
        isCurrentMonth: false
      });
    }
    
    // Add all days in the plan period
    const current = new Date(calendarStart);
    while (current <= calendarEnd) {
      const isInPlanPeriod = current >= startDate && current <= endDate;
      dates.push({
        date: current.toLocaleDateString('nl-NL'),
        day: current.getDate(),
        dayName: ['zondag', 'maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag'][current.getDay()],
        isCurrentMonth: isInPlanPeriod
      });
      current.setDate(current.getDate() + 1);
    }
    
    return dates;
  };

  const exportToICS = (plan: TrainingPlan) => {
    const sessions = generateTrainingSessions(plan);
    let icsContent = `BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Soccer Club//Jaarplanning//NL\nCALSCALE:GREGORIAN\nMETHOD:PUBLISH\n`;
    
    sessions.forEach((session, index) => {
      const startDate = new Date(session.date.split('/').reverse().join('-'));
      const endDate = new Date(startDate.getTime() + session.duration * 60000);
      
      const formatDate = (date: Date) => {
        return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      };
      
      icsContent += `BEGIN:VEVENT\n`;
      icsContent += `UID:training-${plan.id}-${index}@soccerclub.nl\n`;
      icsContent += `DTSTART:${formatDate(startDate)}\n`;
      icsContent += `DTEND:${formatDate(endDate)}\n`;
      icsContent += `SUMMARY:Training Week ${session.week} - ${session.focusArea}\n`;
      icsContent += `DESCRIPTION:IADATABANK Elementen: ${Object.values(session.iadatabankElements).flat().join(', ')}\n`;
      icsContent += `LOCATION:Training Veld\n`;
      icsContent += `END:VEVENT\n`;
    });
    
    icsContent += `END:VCALENDAR`;
    
    const blob = new Blob([icsContent], { type: 'text/calendar' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${plan.name}-jaarplanning.ics`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    alert(`ICS kalender "${plan.name}" succesvol gedownload!`);
  };

  const exportToExcel = (plan: TrainingPlan) => {
    const sessions = generateTrainingSessions(plan);
    
    // Create CSV content for Excel compatibility
    let csvContent = "Week,Training,Datum,Duur (min),Focus Gebied,BASICS Elementen,TEAMTACTISCH Elementen,MENTAAL Elementen,FYSIEK Elementen,Doelstellingen\n";
    
    sessions.forEach(session => {
      const basicsElements = session.iadatabankElements.basics.join('; ');
      const teamElements = session.iadatabankElements.teamtactisch.join('; ');
      const mentaalElements = session.iadatabankElements.mentaal.join('; ');
      const fysiekElements = session.iadatabankElements.fysiek.join('; ');
      const objectives = session.objectives.join('; ');
      
      csvContent += `${session.week},${session.session},${session.date},${session.duration},"${session.focusArea}","${basicsElements}","${teamElements}","${mentaalElements}","${fysiekElements}","${objectives}"\n`;
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${plan.name}-jaarplanning.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    alert(`Excel bestand "${plan.name}" succesvol gedownload!`);
  };

  // Helper functions first
  const getDurationByAgeGroup = (ageGroup: string): number => {
    if (ageGroup.includes("U8") || ageGroup.includes("U10")) return 60;
    if (ageGroup.includes("U12") || ageGroup.includes("U14")) return 75;
    return 90;
  };

  const selectIADatabankElements = (focusArea: string, ageGroup: string, week: number) => {
    const elements = {
      basics: [] as string[],
      teamtactisch: [] as string[],
      mentaal: [] as string[],
      fysiek: [] as string[]
    };

    if (focusArea.includes("BASICS")) {
      elements.basics = ["Leiden van de bal", "Korte Passing", "Balcontrole"];
    }
    if (focusArea.includes("TEAMTACTICS")) {
      elements.teamtactisch = ["Positiespel", "Driehoeken vormen"];
    }
    if (focusArea.includes("MENTAAL")) {
      elements.mentaal = ["Concentratie", "Zelfvertrouwen"];
    }
    if (focusArea.includes("PHYSICS")) {
      elements.fysiek = ["Snelheid", "Conditie"];
    }

    return elements;
  };

  const generateTrainingSessions = (plan: TrainingPlan): TrainingSession[] => {
    const sessions: TrainingSession[] = [];
    const startDate = new Date(plan.startDate);
    const endDate = new Date(plan.endDate);
    
    // Correct Dutch day mapping
    const dayNameToNumber: {[key: string]: number} = {
      'zondag': 0,
      'maandag': 1, 
      'dinsdag': 2,
      'woensdag': 3,
      'donderdag': 4,
      'vrijdag': 5,
      'zaterdag': 6
    };
    
    // Get selected training days and convert to numbers
    const selectedDays = plan.trainingDays || [];
    const trainingDayNumbers = selectedDays.map(day => dayNameToNumber[day.toLowerCase()]).filter(num => num !== undefined);
    
    console.log('Selected training days:', selectedDays);
    console.log('Training day numbers:', trainingDayNumbers);
    
    if (trainingDayNumbers.length === 0) {
      console.warn('No valid training days selected');
      return sessions;
    }
    
    // Calculate total weeks in plan period
    const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const maxWeeks = Math.ceil(totalDays / 7);
    
    let week = 1;
    let currentDate = new Date(startDate);
    
    // Generate sessions by iterating through each day
    while (currentDate <= endDate && week <= maxWeeks) {
      const dayOfWeek = currentDate.getDay();
      
      // Check if this day is a training day
      if (trainingDayNumbers.includes(dayOfWeek)) {
        const focusAreas = ["BASICS B+", "TEAMTACTICS B+", "MENTAAL B+", "PHYSICS B+"];
        const focusArea = focusAreas[(week - 1) % focusAreas.length];
        const elements = selectIADatabankElements(focusArea, plan.ageGroup, week);
        
        sessions.push({
          week: week,
          session: sessions.filter(s => s.week === week).length + 1,
          date: currentDate.toLocaleDateString('nl-NL'),
          duration: getDurationByAgeGroup(plan.ageGroup),
          focusArea,
          assignedThemes: [focusArea],
          assignedElements: Object.values(elements).flat(),
          iadatabankElements: elements,
          objectives: [`Focus op ${focusArea}`, `Progressie niveau ${week}`],
          notes: ""
        });
        
        console.log(`Added session for ${currentDate.toLocaleDateString('nl-NL')} (${['zondag', 'maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag'][dayOfWeek]})`);
      }
      
      // Move to next day
      currentDate.setDate(currentDate.getDate() + 1);
      
      // Check if we need to move to next week (every 7 days from start)
      const daysSinceStart = Math.floor((currentDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      const newWeek = Math.floor(daysSinceStart / 7) + 1;
      if (newWeek > week) {
        week = newWeek;
      }
    }
    
    console.log('Generated sessions:', sessions.length);
    sessions.forEach(s => console.log(`Week ${s.week}, Session ${s.session}: ${s.date}`));
    
    return sessions;
  };

  const exportPlanToPDF = (plan: TrainingPlan) => {
    const sessions = generateTrainingSessions(plan);
    
    // Create comprehensive PDF content
    let pdfContent = `JAARPLANNING: ${plan.name}\n`;
    pdfContent += `${plan.ageGroup} | ${plan.season}\n`;
    pdfContent += `${plan.startDate} - ${plan.endDate}\n\n`;
    
    sessions.forEach(session => {
      pdfContent += `Week ${session.week}, Training ${session.session} (${session.date})\n`;
      pdfContent += `Focus: ${session.focusArea}\n`;
      pdfContent += `Duur: ${session.duration} minuten\n`;
      pdfContent += `IADATABANK Elementen:\n`;
      Object.entries(session.iadatabankElements).forEach(([category, elements]) => {
        if (elements.length > 0) {
          pdfContent += `  ${category.toUpperCase()}: ${elements.join(', ')}\n`;
        }
      });
      pdfContent += `Doelstellingen: ${session.objectives.join(', ')}\n\n`;
    });
    
    // Create blob and download
    const blob = new Blob([pdfContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${plan.name}-jaarplanning.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    alert(`Jaarplanning "${plan.name}" gedownload als tekstbestand (${sessions.length} trainingen)`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 hover:bg-gray-100">
              <ArrowLeft size={18} />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Jaarplanning Training</h1>
          <p className="text-muted-foreground">
            Maak complete seizoensplanningen met IADATABANK elementen per ploeg
          </p>
          
          {/* Team Filter */}
          <div className="mt-4">
            <Label htmlFor="team-filter">Filter op Team</Label>
            <Select value={selectedTeam} onValueChange={setSelectedTeam}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Alle teams" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle teams</SelectItem>
                {teams.map(team => (
                  <SelectItem key={team.id} value={team.id.toString()}>
                    {team.name} ({team.ageGroup})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-2">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Terug
            </Button>
          </Link>
          <Link href="/teams">
            <Button variant="outline" size="sm">
              <Users className="h-4 w-4 mr-2" />
              Teams Beheer
            </Button>
          </Link>
          <Button
            variant={viewMode === "overview" ? "default" : "outline"}
            onClick={() => setViewMode("overview")}
          >
            <Eye className="h-4 w-4 mr-2" />
            Overzicht
          </Button>
          <Button
            variant={viewMode === "calendar" ? "default" : "outline"}
            onClick={() => setViewMode("calendar")}
          >
            <Calendar className="h-4 w-4 mr-2" />
            Kalender
          </Button>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nieuwe Jaarplanning
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Nieuwe Jaarplanning Aanmaken</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Naam van de Jaarplanning *</Label>
                    <Input
                      id="name"
                      value={newPlan.name}
                      onChange={(e) => setNewPlan(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="bijv. U15 Seizoen 2024-25"
                    />
                  </div>
                  <div>
                    <Label htmlFor="season">Seizoen *</Label>
                    <Select value={newPlan.season} onValueChange={(value) => setNewPlan(prev => ({ ...prev, season: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer seizoen" />
                      </SelectTrigger>
                      <SelectContent>
                        {seasons.map(season => (
                          <SelectItem key={season} value={season}>{season}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="ageGroup">Leeftijdsgroep *</Label>
                    <Select value={newPlan.ageGroup} onValueChange={(value) => setNewPlan(prev => ({ ...prev, ageGroup: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer leeftijdsgroep" />
                      </SelectTrigger>
                      <SelectContent>
                        {ageGroups.map(group => (
                          <SelectItem key={group} value={group}>{group}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="team">Team (optioneel)</Label>
                    <Select value={newPlan.teamId?.toString() || ""} onValueChange={(value) => {
                      const teamId = value ? parseInt(value) : null;
                      const team = teams.find(t => t.id === teamId);
                      setNewPlan(prev => ({ 
                        ...prev, 
                        teamId,
                        teamName: team?.name
                      }));
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer team" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Geen specifiek team</SelectItem>
                        {teams.filter(team => !newPlan.ageGroup || team.ageGroup === newPlan.ageGroup).map(team => (
                          <SelectItem key={team.id} value={team.id.toString()}>
                            {team.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="startDate">Startdatum *</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={newPlan.startDate}
                      onChange={(e) => setNewPlan(prev => ({ ...prev, startDate: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="endDate">Einddatum *</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={newPlan.endDate}
                      onChange={(e) => setNewPlan(prev => ({ ...prev, endDate: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="sessionsPerWeek">Trainingen per week *</Label>
                    <Select value={newPlan.sessionsPerWeek.toString()} onValueChange={(value) => setNewPlan(prev => ({ ...prev, sessionsPerWeek: parseInt(value) }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 training</SelectItem>
                        <SelectItem value="2">2 trainingen</SelectItem>
                        <SelectItem value="3">3 trainingen</SelectItem>
                        <SelectItem value="4">4 trainingen</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Training dagen *</Label>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      {weekDays.map(day => (
                        <label key={day.value} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={newPlan.trainingDays.includes(day.value)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setNewPlan(prev => ({ ...prev, trainingDays: [...prev.trainingDays, day.value] }));
                              } else {
                                setNewPlan(prev => ({ ...prev, trainingDays: prev.trainingDays.filter(d => d !== day.value) }));
                              }
                            }}
                          />
                          <span className="text-sm">{day.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Beschrijving</Label>
                  <Textarea
                    id="description"
                    value={newPlan.description}
                    onChange={(e) => setNewPlan(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Korte beschrijving van de jaarplanning..."
                    rows={3}
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Annuleren
                  </Button>
                  <Button onClick={createTrainingPlan}>
                    <Save className="h-4 w-4 mr-2" />
                    Jaarplanning Aanmaken
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Content based on view mode */}
      {viewMode === "overview" && (
        <div className="space-y-6">
          {/* Advanced Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filters & Zoeken</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="search">Zoek planning</Label>
                  <Input 
                    id="search"
                    placeholder="Zoek op naam..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="filter-age">Leeftijdsgroep</Label>
                  <Select value={ageFilter} onValueChange={setAgeFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Alle leeftijden" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Alle leeftijden</SelectItem>
                      {ageGroups.map(age => (
                        <SelectItem key={age} value={age}>{age}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="filter-season">Seizoen</Label>
                  <Select value={seasonFilter} onValueChange={setSeasonFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Alle seizoenen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Alle seizoenen</SelectItem>
                      <SelectItem value="2024/2025">2024/2025</SelectItem>
                      <SelectItem value="2025/2026">2025/2026</SelectItem>
                      <SelectItem value="2026/2027">2026/2027</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="filter-status">Status</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Alle statussen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Alle statussen</SelectItem>
                      <SelectItem value="draft">Concept</SelectItem>
                      <SelectItem value="active">Actief</SelectItem>
                      <SelectItem value="completed">Voltooid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Plan Details */}
          {selectedPlan && (
            <Card className="border-2 border-blue-200 bg-blue-50/50">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">Plan Details - {selectedPlan.name}</CardTitle>
                    <CardDescription className="mt-2">
                      Uitgebreide informatie over deze jaarplanning
                    </CardDescription>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setSelectedPlan(null)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-blue-700">Basis Informatie</h4>
                    <div className="space-y-2 text-sm">
                      <p><span className="font-medium">Seizoen:</span> {selectedPlan.season}</p>
                      <p><span className="font-medium">Leeftijdsgroep:</span> {selectedPlan.ageGroup}</p>
                      <p><span className="font-medium">Trainingen per week:</span> {selectedPlan.sessionsPerWeek}</p>
                      <p><span className="font-medium">Status:</span> 
                        <span className={`ml-2 px-2 py-1 rounded text-xs ${
                          selectedPlan.status === 'active' ? 'bg-green-100 text-green-700' :
                          selectedPlan.status === 'draft' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-gray-100 text-gray-700'
                        }`}>
                          {selectedPlan.status === 'active' ? 'Actief' : selectedPlan.status === 'draft' ? 'Concept' : 'Voltooid'}
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold text-green-700">Periode & Planning</h4>
                    <div className="space-y-2 text-sm">
                      <p><span className="font-medium">Start:</span> {selectedPlan.startDate}</p>
                      <p><span className="font-medium">Eind:</span> {selectedPlan.endDate}</p>
                      <p><span className="font-medium">Totaal weken:</span> {selectedPlan.totalWeeks}</p>
                      <p><span className="font-medium">Training dagen:</span> {selectedPlan.trainingDays.join(', ')}</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold text-purple-700">Statistieken</h4>
                    <div className="space-y-2 text-sm">
                      <p><span className="font-medium">Totaal trainingen:</span> {generateTrainingSessions(selectedPlan).length}</p>
                      <p><span className="font-medium">Totaal minuten:</span> {generateTrainingSessions(selectedPlan).reduce((acc, s) => acc + s.duration, 0)}</p>
                      <p><span className="font-medium">Met IADATABANK:</span> {generateTrainingSessions(selectedPlan).filter(s => s.assignedElements.length > 0).length}</p>
                      <p><span className="font-medium">Nog in te vullen:</span> {generateTrainingSessions(selectedPlan).filter(s => s.assignedElements.length === 0).length}</p>
                    </div>
                  </div>
                </div>
                <div className="mt-6 pt-4 border-t">
                  <h4 className="font-semibold mb-2">Beschrijving</h4>
                  <p className="text-sm text-muted-foreground">{selectedPlan.description}</p>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button size="sm" onClick={() => setViewMode("calendar")}>
                    <Calendar className="h-4 w-4 mr-2" />
                    Bekijk in Kalender
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => editPlan(selectedPlan)}>
                    <Edit className="h-4 w-4 mr-2" />
                    Bewerk
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => exportToICS(selectedPlan)}>
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <h2 className="text-xl font-semibold">Bestaande Jaarplanningen</h2>
          {filteredPlans.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Nog geen jaarplanningen aangemaakt.</p>
                  <p className="text-sm">Maak je eerste jaarplanning aan om trainingen te structureren.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {filteredPlans.map(plan => (
                <Card key={plan.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{plan.name}</CardTitle>
                        <CardDescription>
                          {plan.ageGroup} • {plan.season} • {plan.totalWeeks} weken
                          {plan.teamName && ` • Team: ${plan.teamName}`}
                        </CardDescription>
                      </div>
                      <div className="flex gap-1">
                        <Button size="sm" variant="default" onClick={() => {
                          setSelectedPlan(plan);
                          setViewMode("calendar");
                        }}>
                          <Calendar className="h-4 w-4 mr-1" />
                          Kalender
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setSelectedPlan(plan)}>
                          <Eye className="h-4 w-4 mr-1" />
                          Bekijk
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => editPlan(plan)}>
                          <Edit className="h-4 w-4 mr-1" />
                          Bewerk
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => duplicatePlan(plan)}>
                          <Copy className="h-4 w-4 mr-1" />
                          Kopieer
                        </Button>
                        <div className="relative group">
                          <Button size="sm" variant="outline">
                            <Download className="h-4 w-4 mr-1" />
                            Export
                          </Button>
                          <div className="absolute right-0 top-full mt-1 w-48 bg-white border rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10">
                            <button 
                              className="w-full px-3 py-2 text-left hover:bg-gray-50 rounded-t-lg"
                              onClick={() => exportToICS(plan)}
                            >
                              📅 ICS Kalender
                            </button>
                            <button 
                              className="w-full px-3 py-2 text-left hover:bg-gray-50"
                              onClick={() => exportToExcel(plan)}
                            >
                              📊 Excel/CSV
                            </button>
                            <button 
                              className="w-full px-3 py-2 text-left hover:bg-gray-50 rounded-b-lg"
                              onClick={() => exportPlanToPDF(plan)}
                            >
                              📄 PDF Document
                            </button>
                          </div>
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="outline">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Jaarplanning verwijderen</AlertDialogTitle>
                              <AlertDialogDescription>
                                Weet je zeker dat je "{plan.name}" wilt verwijderen? Deze actie kan niet ongedaan worden gemaakt.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Annuleren</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deletePlan(plan.id)}>
                                Verwijderen
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-2">{plan.description}</p>
                    <div className="flex items-center gap-4 text-sm">
                      <span>📅 {plan.startDate} tot {plan.endDate}</span>
                      <span>🏃 {plan.sessionsPerWeek}x per week</span>
                      <span>📍 {plan.trainingDays.join(', ')}</span>
                      <span className={`px-2 py-1 rounded text-xs ${
                        plan.status === 'active' ? 'bg-green-100 text-green-800' :
                        plan.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {plan.status === 'active' ? 'Actief' : plan.status === 'draft' ? 'Concept' : 'Voltooid'}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {viewMode === "calendar" && selectedPlan && (() => {
        console.log('Calendar view mode activated for plan:', selectedPlan.name);
        console.log('Generated sessions:', generateTrainingSessions(selectedPlan));
        return true;
      })() && (
        <div className="space-y-6">
          {/* Navigation Header */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <Calendar className="h-6 w-6" />
                    {selectedPlan.name} - Training Kalender
                  </CardTitle>
                  <CardDescription>
                    {selectedPlan.ageGroup} • {selectedPlan.season} • Moderne Interface
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => exportToICS(selectedPlan)}>
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setViewMode("overview")}>
                    ← Terug naar Overzicht
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Ultra-Modern Training Calendar */}
          <div className="space-y-6">
            {/* Calendar Header with Gradient */}
            <Card className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white border-0 shadow-xl">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-2xl font-bold mb-2 flex items-center gap-3">
                      <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                        ⚽
                      </div>
                      Training Kalender
                    </CardTitle>
                    <CardDescription className="text-blue-100 text-lg">
                      {selectedPlan.name} • {selectedPlan.ageGroup}
                    </CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold">{generateTrainingSessions(selectedPlan).length}</div>
                    <div className="text-blue-200 text-sm">Totaal Trainingen</div>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Week Navigation */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Week Navigatie
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 flex-wrap">
                  {Array.from(new Set(generateTrainingSessions(selectedPlan).map(s => s.week))).sort((a, b) => a - b).map(week => (
                    <Button
                      key={week}
                      variant={currentWeek === week ? 'default' : 'outline'}
                      onClick={() => setCurrentWeek(week)}
                      className={`${currentWeek === week ? 'bg-blue-600' : ''}`}
                    >
                      Week {week}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Training Sessions for Selected Week */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Week {currentWeek} Trainingen</CardTitle>
                <CardDescription>
                  {generateTrainingSessions(selectedPlan).filter(s => s.week === currentWeek).length} trainingen gepland deze week
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {generateTrainingSessions(selectedPlan).filter(s => s.week === currentWeek).length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Geen trainingen gepland voor week {currentWeek}</p>
                    </div>
                  ) : (
                    generateTrainingSessions(selectedPlan).filter(s => s.week === currentWeek).map(session => {
                      const getFocusIcon = (focusArea: string) => {
                        if (focusArea.includes('BASICS')) return '⚽';
                        if (focusArea.includes('TEAMTACTICS')) return '🎯';
                        if (focusArea.includes('MENTAAL')) return '🧠';
                        if (focusArea.includes('PHYSICS')) return '💪';
                        return '🏃';
                      };

                      const getIntensityColor = (week: number) => {
                        const intensity = week % 3 === 0 ? 'high' : week % 2 === 0 ? 'medium' : 'low';
                        switch (intensity) {
                          case 'low': return 'bg-green-100 text-green-800 border-green-200';
                          case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
                          case 'high': return 'bg-red-100 text-red-800 border-red-200';
                          default: return 'bg-gray-100 text-gray-800 border-gray-200';
                        }
                      };

                      return (
                        <div
                          key={`${session.week}-${session.session}`}
                          className="group bg-gradient-to-r from-white to-blue-50 border-2 border-blue-200 rounded-xl p-6 hover:shadow-lg transition-all duration-300 cursor-pointer hover:scale-[1.02]"
                          onClick={() => {
                            console.log('Opening IADATABANK for session:', session);
                            setSelectedSessionForIA(session);
                            setShowIADatabankDialog(true);
                          }}
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div className="flex items-center gap-3">
                              <div className="text-3xl">{getFocusIcon(session.focusArea)}</div>
                              <div>
                                <h3 className="font-bold text-lg text-gray-800">{session.focusArea}</h3>
                                <p className="text-sm text-gray-600">Sessie {session.session} • {session.date}</p>
                              </div>
                            </div>
                            <div className={`px-3 py-1 rounded-full text-xs font-medium border ${getIntensityColor(session.week)}`}>
                              {session.week % 3 === 0 ? 'Hoog' : session.week % 2 === 0 ? 'Medium' : 'Laag'}
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-4 mb-4">
                            <div className="text-center">
                              <Clock className="h-4 w-4 mx-auto text-gray-500 mb-1" />
                              <div className="text-sm font-medium">{session.duration} min</div>
                            </div>
                            <div className="text-center">
                              <Target className="h-4 w-4 mx-auto text-gray-500 mb-1" />
                              <div className="text-sm font-medium">{session.assignedElements.length} elementen</div>
                            </div>
                            <div className="text-center">
                              <MapPin className="h-4 w-4 mx-auto text-gray-500 mb-1" />
                              <div className="text-sm font-medium">Trainingsveld</div>
                            </div>
                          </div>

                          <div className="bg-white/60 rounded-lg p-3 mb-3">
                            <h4 className="font-semibold text-sm mb-2 text-gray-700">Doelstellingen:</h4>
                            <ul className="text-xs text-gray-600 space-y-1">
                              {session.objectives.map((obj, idx) => (
                                <li key={idx} className="flex items-center gap-2">
                                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                                  {obj}
                                </li>
                              ))}
                            </ul>
                          </div>

                          <div className="flex justify-between items-center">
                            <div className="text-xs text-gray-500">
                              Klik om IADATABANK te beheren
                            </div>
                            <div className="flex gap-1">
                              {[1, 2, 3].map(star => (
                                <Star key={star} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {viewMode === "calendar" && !selectedPlan && (
        <Card>
          <CardContent className="p-8 text-center">
            <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Selecteer een jaarplanning</h3>
            <p className="text-muted-foreground">
              Klik op een jaarplanning hierboven om de kalender weergave te bekijken
            </p>
          </CardContent>
        </Card>
      )}

      {/* Ultra-Modern Training Session Designer */}
      <Dialog open={showIADatabankDialog} onOpenChange={setShowIADatabankDialog}>
        <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 border-0 shadow-2xl">
          {/* Stunning Header */}
          <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white p-8 -m-6 mb-8 rounded-t-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 via-transparent to-purple-400/20"></div>
            <div className="relative z-10">
              <DialogHeader>
                <DialogTitle className="text-3xl font-bold flex items-center gap-4 mb-2">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl">
                    ⚽
                  </div>
                  Training Session Designer
                </DialogTitle>
                <div className="text-lg text-blue-100 font-medium">
                  Week {selectedSessionForIA?.week} • {selectedSessionForIA?.date}
                </div>
              </DialogHeader>
              
              {/* Session Info Cards */}
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="bg-white/15 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                  <div className="text-white/80 text-sm font-medium mb-1">Focus Gebied</div>
                  <div className="text-white text-lg font-bold">{selectedSessionForIA?.focusArea}</div>
                </div>
                <div className="bg-white/15 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                  <div className="text-white/80 text-sm font-medium mb-1">Sessie Duur</div>
                  <div className="text-white text-lg font-bold">{selectedSessionForIA?.duration} minuten</div>
                </div>
                <div className="bg-white/15 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                  <div className="text-white/80 text-sm font-medium mb-1">Toegewezen</div>
                  <div className="text-white text-lg font-bold">{selectedSessionForIA?.assignedElements?.length || 0} elementen</div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Modern Content Area */}
          <div className="p-6 space-y-8">
            {/* IADATABANK Category Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { name: 'BASICS', icon: '⚽', color: 'from-green-500 to-emerald-600', description: 'Technische vaardigheden' },
                { name: 'TEAMTACTICS', icon: '🎯', color: 'from-blue-500 to-cyan-600', description: 'Tactisch spel' },
                { name: 'MENTAAL', icon: '🧠', color: 'from-purple-500 to-violet-600', description: 'Mentale aspecten' },
                { name: 'FYSIEK', icon: '💪', color: 'from-orange-500 to-red-600', description: 'Fysieke conditie' }
              ].map((category) => (
                <div
                  key={category.name}
                  onClick={() => {
                    setSelectedCategory(category.name);
                    setSelectedSubcategory(null);
                  }}
                  className={`group cursor-pointer transform transition-all duration-300 hover:scale-105 ${
                    selectedCategory === category.name ? 'scale-105 ring-4 ring-blue-300' : ''
                  }`}
                >
                  <div className={`bg-gradient-to-br ${category.color} text-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all`}>
                    <div className="text-4xl mb-3">{category.icon}</div>
                    <h3 className="text-xl font-bold mb-2">{category.name}</h3>
                    <p className="text-white/80 text-sm">{category.description}</p>
                    {selectedCategory === category.name && (
                      <div className="mt-3 flex items-center gap-2">
                        <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                        <span className="text-sm font-medium">Geselecteerd</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* B+ / B- Selection */}
            {selectedCategory && (
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <h3 className="text-xl font-bold mb-4 text-gray-800">
                  Selecteer {selectedCategory} type:
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setSelectedSubcategory('B+')}
                    className={`group p-6 rounded-xl border-2 transition-all duration-300 ${
                      selectedSubcategory === 'B+'
                        ? 'border-green-500 bg-green-50 shadow-lg scale-105'
                        : 'border-gray-200 hover:border-green-300 hover:bg-green-50'
                    }`}
                  >
                    <div className="text-3xl mb-3">⚡</div>
                    <h4 className="text-lg font-bold text-green-700 mb-2">B+ Aanvallend</h4>
                    <p className="text-sm text-gray-600">Offensieve vaardigheden en aanvallende tactieken</p>
                    {selectedSubcategory === 'B+' && (
                      <div className="mt-3 flex items-center justify-center">
                        <span className="px-3 py-1 bg-green-500 text-white rounded-full text-xs font-medium">
                          Actief
                        </span>
                      </div>
                    )}
                  </button>
                  
                  <button
                    onClick={() => setSelectedSubcategory('B-')}
                    className={`group p-6 rounded-xl border-2 transition-all duration-300 ${
                      selectedSubcategory === 'B-'
                        ? 'border-red-500 bg-red-50 shadow-lg scale-105'
                        : 'border-gray-200 hover:border-red-300 hover:bg-red-50'
                    }`}
                  >
                    <div className="text-3xl mb-3">🛡️</div>
                    <h4 className="text-lg font-bold text-red-700 mb-2">B- Verdedigend</h4>
                    <p className="text-sm text-gray-600">Defensieve vaardigheden en verdedigende tactieken</p>
                    {selectedSubcategory === 'B-' && (
                      <div className="mt-3 flex items-center justify-center">
                        <span className="px-3 py-1 bg-red-500 text-white rounded-full text-xs font-medium">
                          Actief
                        </span>
                      </div>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* IADATABANK Elements Grid */}
            {selectedCategory && selectedSubcategory && (
              <div className="bg-gradient-to-br from-white to-gray-50 rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold text-gray-800">
                    {selectedCategory} {selectedSubcategory} Elementen
                  </h3>
                  <div className="flex gap-2">
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                      Week {selectedSessionForIA?.week}
                    </span>
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                      {selectedSessionForIA?.focusArea}
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {iadatabankElements[`${selectedCategory} ${selectedSubcategory}` as keyof typeof iadatabankElements]?.map((element: string, index: number) => (
                    <div
                      key={index}
                      className={`group cursor-pointer p-4 rounded-xl border-2 transition-all duration-300 hover:shadow-lg ${
                        selectedIAElements[element]
                          ? 'border-blue-500 bg-blue-50 shadow-md'
                          : 'border-gray-200 hover:border-blue-300 bg-white'
                      }`}
                      onClick={() => setSelectedIAElements(prev => ({
                        ...prev,
                        [element]: !prev[element]
                      }))}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                          selectedIAElements[element]
                            ? 'border-blue-500 bg-blue-500'
                            : 'border-gray-300 group-hover:border-blue-400'
                        }`}>
                          {selectedIAElements[element] && (
                            <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-800 group-hover:text-blue-700 transition-colors">
                            {element}
                          </h4>
                          <p className="text-xs text-gray-500 mt-1">
                            Klik om toe te voegen aan training
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Action Buttons */}
                <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
                  <div className="text-sm text-gray-600">
                    {Object.values(selectedIAElements).filter(Boolean).length} elementen geselecteerd
                  </div>
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      onClick={() => setShowIADatabankDialog(false)}
                      className="px-6"
                    >
                      Annuleren
                    </Button>
                    <Button
                      onClick={() => {
                        // Save selected elements logic here
                        console.log('Selected elements:', selectedIAElements);
                        setShowIADatabankDialog(false);
                      }}
                      className="px-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    >
                      Elementen Opslaan
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
              <h3 className="text-xl font-bold mb-4 text-gray-800">Snelle Acties</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <button className="p-4 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 text-white hover:shadow-lg transition-all">
                  <div className="text-2xl mb-2">🎯</div>
                  <div className="text-sm font-medium">Aanbevolen Elementen</div>
                </button>
                <button className="p-4 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-600 text-white hover:shadow-lg transition-all">
                  <div className="text-2xl mb-2">📋</div>
                  <div className="text-sm font-medium">Vorige Sessie</div>
                </button>
                <button className="p-4 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 text-white hover:shadow-lg transition-all">
                  <div className="text-2xl mb-2">⭐</div>
                  <div className="text-sm font-medium">Favorieten</div>
                </button>
                <button className="p-4 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 text-white hover:shadow-lg transition-all">
                  <div className="text-2xl mb-2">🔄</div>
                  <div className="text-sm font-medium">Reset Selectie</div>
                </button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

