import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { ArrowLeft, ChevronLeft, ChevronRight, Calendar, Download, X, ChevronDown, Target, Users, Brain, Zap } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  season: string;
  startDate: string;
  endDate: string;
  trainingDays: any;
  status: "draft" | "active" | "completed";
}

export default function CalendarSimple() {
  const [planId] = useState<string | null>(new URLSearchParams(window.location.search).get('planId'));
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showThemeDialog, setShowThemeDialog] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  
  // IADATABANK selection state - simplified for tile structure
  const [selectedTopic, setSelectedTopic] = useState<string>("BASICS");
  const [selectedSubtopic, setSelectedSubtopic] = useState<string>("");
  const [selectedElements, setSelectedElements] = useState<string[]>([]);

  // Fetch data
  const { data: yearPlans = [], isLoading: isLoadingPlans } = useQuery({ 
    queryKey: ['/api/year-plans']
  });

  const { data: clubInfo } = useQuery({ queryKey: ['/api/club/info'] });
  
  // Fetch IADATABANK elements
  const { data: iaDatabankData } = useQuery({ queryKey: ['/api/iadatabank/elements'] });

  // Set selected plan from URL param or first plan
  useEffect(() => {
    if (yearPlans && Array.isArray(yearPlans) && yearPlans.length > 0) {
      if (planId) {
        const plan = yearPlans.find((p: any) => p.id === parseInt(planId));
        if (plan) {
          setSelectedPlan(plan);
        }
      } else if (!selectedPlan) {
        setSelectedPlan(yearPlans[0]);
      }
    }
  }, [planId, yearPlans]);

  // Check if date is available for training
  const isDateAvailable = (date: Date) => {
    if (!selectedPlan || !selectedPlan.startDate || !selectedPlan.endDate) return false;
    
    try {
      const dayName = format(date, 'EEEE', { locale: nl });
      const planStart = parseISO(selectedPlan.startDate);
      const planEnd = parseISO(selectedPlan.endDate);
      

      
      // Check if date is within plan period
      if (date < planStart || date > planEnd) return false;
      
      // Check training days - handle both string and array formats safely
      let trainingDays: string[] = [];
      
      if (selectedPlan.trainingDays) {
        if (typeof selectedPlan.trainingDays === 'string' && selectedPlan.trainingDays.trim()) {
          trainingDays = selectedPlan.trainingDays.split(',').map(day => day.trim()).filter(day => day.length > 0);
        } else if (Array.isArray(selectedPlan.trainingDays)) {
          trainingDays = selectedPlan.trainingDays.filter(day => day && day.trim());
        }
      }
      
      // If no training days specified, don't allow any days
      if (trainingDays.length === 0) {
        return false;
      }
      
      // Check if current day is a training day (case insensitive)
      return trainingDays.some(day => day.toLowerCase() === dayName.toLowerCase());
    } catch (error) {
      console.error('Date validation error:', error);
      return false;
    }
  };

  // Get sessions for date - simplified
  const getSessionsForDate = (date: Date) => {
    return []; // For now, return empty array
  };

  // Handle date click to open theme selection dialog
  const handleDateClick = (date: Date) => {
    if (!selectedPlan || !isDateAvailable(date)) return;
    
    setSelectedDate(date);
    setSelectedThemes([]);
    setShowThemeDialog(true);
  };

  // Topic configuration for category tiles
  const topicConfig = {
    BASICS: {
      display: "Basics",
      icon: Target,
      color: "bg-blue-500",
      bgColor: "bg-blue-100",
      textColor: "text-blue-800",
      borderColor: "border-blue-200"
    },
    TEAMTACTISCH: {
      display: "Team Tactiek",
      icon: Users,
      color: "bg-green-500",
      bgColor: "bg-green-100",
      textColor: "text-green-800",
      borderColor: "border-green-200"
    },
    MENTAAL: {
      display: "Mentale Aspecten",
      icon: Brain,
      color: "bg-purple-500",
      bgColor: "bg-purple-100",
      textColor: "text-purple-800",
      borderColor: "border-purple-200"
    },
    PHYSIEK: {
      display: "Fysieke Conditie",
      icon: Zap,
      color: "bg-orange-500",
      bgColor: "bg-orange-100",
      textColor: "text-orange-800",
      borderColor: "border-orange-200"
    }
  };

  // Filter elements based on selected topic and subtopic
  const getFilteredElements = () => {
    if (!iaDatabankData?.data) return [];
    
    return iaDatabankData.data.filter((element: any) => {
      const matchesTopic = selectedTopic === "" || element.topic === selectedTopic;
      const matchesSubtopic = selectedSubtopic === "" || element.subtopic === selectedSubtopic;
      return matchesTopic && matchesSubtopic;
    });
  };

  // Get available subtopics for selected topic
  const getAvailableSubtopics = (topic: string) => {
    if (!iaDatabankData?.data) return [];
    const topicElements = iaDatabankData.data.filter((el: any) => el.topic === topic);
    const subtopics = [...new Set(topicElements.map((el: any) => el.subtopic))];
    return subtopics.sort((a, b) => {
      if (a === 'B+') return -1;
      if (b === 'B+') return 1;
      if (a === 'B-') return -1;
      if (b === 'B-') return 1;
      return a.localeCompare(b);
    });
  };

  // Handle training creation with selected IADATABANK elements
  const handleCreateTraining = async () => {
    if (!selectedDate || !selectedPlan) return;

    try {
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      
      // Use selected elements from tile interface
      const allSelectedElements = selectedElements.map(elementId => {
        const element = iaDatabankData?.data?.find((el: any) => el.id === elementId);
        return element ? { type: 'element', name: element.name, id: elementId } : null;
      }).filter(Boolean);
      
      const focusAreaText = allSelectedElements.length > 0 
        ? allSelectedElements.map(el => el.name).join(', ')
        : 'Algemene Training';
      
      const response = await fetch(`/api/year-plans/${selectedPlan.id}/sessions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          date: dateStr,
          time: '19:00',
          duration: 90,
          focusArea: focusAreaText,
          location: 'Hoofdveld',
          ageGroup: selectedPlan.ageGroup || 'Algemeen',
          assignedElements: allSelectedElements,
          intensity: 'medium',
          isCompleted: false
        }),
      });

      if (response.ok) {
        toast({
          title: "Training toegevoegd",
          description: `Training met ${allSelectedElements.length} IADATABANK elementen toegevoegd voor ${format(selectedDate, 'dd MMMM yyyy', { locale: nl })}`,
        });
        queryClient.invalidateQueries({ queryKey: [`/api/year-plans/${selectedPlan.id}/sessions`] });
        setShowThemeDialog(false);
        setSelectedDate(null);
        
        // Reset selections
        setSelectedElements([]);
        setSelectedTopic("BASICS");
        setSelectedSubtopic("");
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to add training');
      }
    } catch (error) {
      console.error('Error adding training:', error);
      toast({
        title: "Fout",
        description: "Kon training niet toevoegen",
        variant: "destructive"
      });
    }
  };

  // Calendar calculation
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  if (isLoadingPlans) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600">Laden...</p>
        </div>
      </div>
    );
  }

  if (!selectedPlan) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-4xl mx-auto p-6">
          <Card>
            <CardHeader>
              <CardTitle>Selecteer een Jaarplanning</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {yearPlans && Array.isArray(yearPlans) && yearPlans.map((plan: YearPlan) => (
                  <Card key={plan.id} className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold">{plan.name}</h3>
                        <p className="text-sm text-gray-600">{plan.ageGroup} • {plan.season}</p>
                      </div>
                      <Button onClick={() => setSelectedPlan(plan)}>
                        <Calendar className="h-4 w-4 mr-2" />
                        Kalender
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Link href="/jaarplanning">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-white/10 border-white/20 hover:bg-white hover:text-blue-600 text-white backdrop-blur-sm"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Jaarplanning
                </Button>
              </Link>
            </div>
          </div>

          {/* Calendar */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentDate(subMonths(currentDate, 1))}
                  className="bg-blue-600 text-white hover:bg-blue-700 border-blue-600"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                
                <CardTitle className="text-xl font-bold text-blue-900">
                  {format(currentDate, 'MMMM yyyy', { locale: nl })}
                </CardTitle>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentDate(addMonths(currentDate, 1))}
                  className="bg-blue-600 text-white hover:bg-blue-700 border-blue-600"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="text-center">
                <h2 className="text-lg font-semibold text-gray-700">{selectedPlan.name}</h2>
                <p className="text-sm text-gray-500">{selectedPlan.ageGroup} • {selectedPlan.season}</p>
              </div>
            </CardHeader>

            <CardContent className="p-0">
              {/* Weekday headers */}
              <div className="grid grid-cols-7 border-b border-gray-200">
                {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map((day) => (
                  <div key={day} className="p-3 text-center font-medium text-gray-600 bg-gray-50">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar grid */}
              <div className="grid grid-cols-7">
                {days.map((day, dayIdx) => {
                  const isCurrentMonth = isSameMonth(day, currentDate);
                  const isAvailable = isDateAvailable(day);
                  const daySessions = getSessionsForDate(day);
                  const isToday = isSameDay(day, new Date());

                  return (
                    <div
                      key={day.toString()}
                      className={`
                        min-h-[100px] p-2 border-r border-b border-gray-200 relative
                        ${!isCurrentMonth ? 'bg-gray-50 text-gray-400' : 'bg-white'}
                        ${isAvailable ? 'hover:bg-blue-50 cursor-pointer' : ''}
                        ${isToday ? 'bg-blue-100' : ''}
                      `}
                      onClick={() => isAvailable && handleDateClick(day)}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`text-sm font-medium ${isToday ? 'text-blue-600' : ''}`}>
                          {format(day, 'd')}
                        </span>
                      </div>

                      {isCurrentMonth && isAvailable && (
                        <div className="mt-2">
                          <div className="text-xs text-center text-blue-600 font-medium bg-blue-50 rounded px-2 py-1 cursor-pointer hover:bg-blue-100">
                            + Training toevoegen
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Theme Selection Dialog */}
      <Dialog open={showThemeDialog} onOpenChange={setShowThemeDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              Training Thema's Selecteren
              <span className="text-sm font-normal text-gray-500">
                {selectedDate && format(selectedDate, 'dd MMMM yyyy', { locale: nl })}
              </span>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* IADATABANK Categories */}
            {iaDatabankData?.data && (
              <div className="space-y-4">
                <div className="text-sm text-gray-600 mb-3">
                  Selecteer IADATABANK elementen voor deze training:
                </div>
                
                {/* Categories */}
                {iaDatabankData.data.map((category: any) => (
                  <div key={category.topic} className="border rounded-lg">
                    {/* Category Header */}
                    <div 
                      className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-150 cursor-pointer rounded-t-lg"
                      onClick={() => toggleCategory(category.topic)}
                    >
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          checked={selectedCategories.includes(category.topic)}
                          onCheckedChange={(checked) => handleCategorySelect(category.topic, !!checked)}
                          onClick={(e) => e.stopPropagation()}
                        />
                        <span className="font-semibold text-blue-900">{category.topic}</span>
                      </div>
                      {expandedCategories.includes(category.topic) ? (
                        <ChevronDown className="h-4 w-4 text-blue-600" />
                      ) : (
                        <ChevronRight className="h-4 w-4 text-blue-600" />
                      )}
                    </div>

                    {/* Subcategories */}
                    {expandedCategories.includes(category.topic) && (
                      <div className="border-t">
                        {Object.entries(category.subcategories || {}).map(([subcatName, subcatData]: [string, any]) => (
                          <div key={subcatName} className="border-b last:border-b-0">
                            {/* Subcategory Header */}
                            <div 
                              className="flex items-center justify-between p-3 pl-8 bg-gradient-to-r from-green-50 to-green-100 hover:from-green-100 hover:to-green-150 cursor-pointer"
                              onClick={() => toggleSubcategory(subcatName)}
                            >
                              <div className="flex items-center space-x-3">
                                <Checkbox
                                  checked={selectedSubcategories.includes(subcatName)}
                                  onCheckedChange={(checked) => handleSubcategorySelect(subcatName, !!checked)}
                                  onClick={(e) => e.stopPropagation()}
                                />
                                <span className="font-medium text-green-800">{subcatName}</span>
                              </div>
                              {expandedSubcategories.includes(subcatName) ? (
                                <ChevronDown className="h-4 w-4 text-green-600" />
                              ) : (
                                <ChevronRight className="h-4 w-4 text-green-600" />
                              )}
                            </div>

                            {/* Skills */}
                            {expandedSubcategories.includes(subcatName) && (
                              <div className="bg-gray-50">
                                {Object.entries(subcatData.skills || {}).map(([skillName, skillData]: [string, any]) => (
                                  <div key={skillName} className="border-b border-gray-200 last:border-b-0">
                                    {/* Skill Header */}
                                    <div 
                                      className="flex items-center justify-between p-3 pl-12 hover:bg-yellow-50 cursor-pointer"
                                      onClick={() => toggleSkill(skillName)}
                                    >
                                      <div className="flex items-center space-x-3">
                                        <Checkbox
                                          checked={selectedSkills.includes(skillName)}
                                          onCheckedChange={(checked) => handleSkillSelect(skillName, !!checked)}
                                          onClick={(e) => e.stopPropagation()}
                                        />
                                        <span className="text-orange-700 font-medium">{skillName}</span>
                                      </div>
                                      {expandedSkills.includes(skillName) ? (
                                        <ChevronDown className="h-4 w-4 text-orange-600" />
                                      ) : (
                                        <ChevronRight className="h-4 w-4 text-orange-600" />
                                      )}
                                    </div>

                                    {/* Progressions */}
                                    {expandedSkills.includes(skillName) && skillData.progressions && (
                                      <div className="bg-white border-t border-gray-200">
                                        {skillData.progressions.map((progression: any) => (
                                          <div key={progression.id} className="flex items-center space-x-3 p-3 pl-16 hover:bg-purple-50">
                                            <Checkbox
                                              checked={selectedProgressions.includes(progression.id)}
                                              onCheckedChange={(checked) => handleProgressionSelect(progression.id, !!checked)}
                                            />
                                            <span className="text-purple-700 text-sm">{progression.name}</span>
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
            
            {/* Selected elements summary */}
            {(selectedCategories.length > 0 || selectedSubcategories.length > 0 || selectedSkills.length > 0 || selectedProgressions.length > 0) && (
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border">
                <div className="text-sm font-semibold text-gray-800 mb-3">
                  Geselecteerde IADATABANK elementen:
                </div>
                <div className="space-y-2">
                  {selectedCategories.length > 0 && (
                    <div>
                      <span className="text-xs font-medium text-blue-600 uppercase tracking-wide">Categorieën ({selectedCategories.length}):</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedCategories.map(cat => (
                          <span key={cat} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded font-medium">
                            {cat}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedSubcategories.length > 0 && (
                    <div>
                      <span className="text-xs font-medium text-green-600 uppercase tracking-wide">Subcategorieën ({selectedSubcategories.length}):</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedSubcategories.map(subcat => (
                          <span key={subcat} className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                            {subcat}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedSkills.length > 0 && (
                    <div>
                      <span className="text-xs font-medium text-orange-600 uppercase tracking-wide">Vaardigheden ({selectedSkills.length}):</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedSkills.map(skill => (
                          <span key={skill} className="bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedProgressions.length > 0 && (
                    <div>
                      <span className="text-xs font-medium text-purple-600 uppercase tracking-wide">Progressies ({selectedProgressions.length}):</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedProgressions.map(progId => {
                          // Find progression name from data
                          let progressionName = progId;
                          iaDatabankData?.data?.forEach((category: any) => {
                            Object.values(category.subcategories || {}).forEach((subcategory: any) => {
                              Object.values(subcategory.skills || {}).forEach((skill: any) => {
                                if (skill.progressions) {
                                  const prog = skill.progressions.find((p: any) => p.id === progId);
                                  if (prog) progressionName = prog.name;
                                }
                              });
                            });
                          });
                          return (
                            <span key={progId} className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded">
                              {progressionName}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {/* Action buttons */}
            <div className="flex justify-end space-x-3 pt-4">
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowThemeDialog(false);
                  // Reset all selections
                  setSelectedCategories([]);
                  setSelectedSubcategories([]);
                  setSelectedSkills([]);
                  setSelectedProgressions([]);
                  setExpandedCategories([]);
                  setExpandedSubcategories([]);
                  setExpandedSkills([]);
                }}
              >
                Annuleren
              </Button>
              <Button 
                onClick={handleCreateTraining}
                disabled={selectedCategories.length === 0 && selectedSubcategories.length === 0 && selectedSkills.length === 0 && selectedProgressions.length === 0}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Training Aanmaken ({selectedCategories.length + selectedSubcategories.length + selectedSkills.length + selectedProgressions.length} elementen)
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}