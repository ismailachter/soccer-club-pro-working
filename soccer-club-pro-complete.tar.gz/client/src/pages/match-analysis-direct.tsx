import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Player {
  id: number;
  name: string;
  position: string;
  number: number;
}

interface MatchResult {
  score: string;
  result: string;
  date: string;
}

interface VVCRoster {
  team: string;
  players: Player[];
  matchResult: MatchResult;
}

interface AnalysisData {
  matchId: string;
  totalFrames: number;
  season: string;
  playerData: any[];
  matchResult: {
    homeScore: number;
    awayScore: number;
    scoringEvents: any[];
    duration: number;
  };
}

export default function MatchAnalysisDirect() {
  const { data: vvcRoster, isLoading: rosterLoading } = useQuery<VVCRoster>({
    queryKey: ["/api/analysis/vvc-roster"],
  });

  const { data: analysisData, isLoading: analysisLoading } = useQuery<AnalysisData>({
    queryKey: ["/api/analysis/svelta-analysis"],
  });

  if (rosterLoading || analysisLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  const players = vvcRoster?.players || [];
  const matchResult = vvcRoster?.matchResult || { score: "1-5", result: "VVC won 5-1 away", date: "za 08 maart 2025 - 15:00" };

  return (
    <div className="min-h-screen bg-white p-6">
      {/* Navigation */}
      <div className="bg-blue-600 text-white p-4 mb-6 rounded">
        <h1 className="text-xl font-bold mb-2">VVC Brasschaat - Wedstrijdanalyse</h1>
        <div className="flex flex-wrap gap-2">
          <span className="bg-white text-blue-600 px-3 py-1 rounded text-sm font-semibold">Match Analyse</span>
          <a href="/" className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-400">Terug naar Menu</a>
        </div>
      </div>

      {/* Match Header */}
      <div className="text-center space-y-4 mb-8">
        <h1 className="text-4xl font-bold">VVC Brasschaat - Match Analyse</h1>
        <div className="text-6xl font-bold">
          <span className="text-red-600">1</span>
          <span className="text-gray-400 mx-4">-</span>
          <span className="text-blue-600">5</span>
        </div>
        <div className="text-xl">
          <span className="font-semibold">SVELTA MELSELE</span>
          <span className="mx-2">vs</span>
          <span className="font-semibold">VVC BRASSCHAAT</span>
        </div>
        <Badge variant="secondary" className="text-lg px-4 py-2">
          {matchResult.date || "za 08 maart 2025 - 15:00"}
        </Badge>
        <div className="text-lg font-semibold text-green-600">
          {matchResult.result || "VVC won 5-1 away"}
        </div>
      </div>

      {/* VVC Team Roster */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-center text-blue-600 text-2xl">
            VVC BRASSCHAAT A - Winnende Team
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {players.map((player: any) => (
              <div key={player.id} className="bg-blue-50 p-4 rounded-lg text-center shadow-sm hover:shadow-md transition-shadow">
                <div className="font-bold text-blue-600 text-lg">#{player.number}</div>
                <div className="font-semibold text-gray-900">{player.name}</div>
                <div className="text-sm text-gray-600">{player.position}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Goal Scorers Section */}
      {analysisData?.matchResult?.scoringEvents && (
        <Card className="mb-8 bg-green-50 border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800">Doelpuntenmakers - VVC won 5-1</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-blue-600 mb-2">VVC Brasschaat Doelpunten:</h4>
                <div className="space-y-1">
                  {analysisData.matchResult.scoringEvents
                    .filter((event: any) => event.team === "VVC Brasschaat A")
                    .map((goal: any, index: number) => (
                      <div key={index} className="text-sm">
                        <span className="font-semibold">{goal.minute}'</span> - <span className="text-blue-600">{goal.player}</span>
                      </div>
                    ))}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-red-600 mb-2">Tegenstander:</h4>
                <div className="text-sm">
                  <span className="font-semibold">45'</span> - <span className="text-red-600">Svelta Melsele</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Match Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Eindresultaat</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">5-1</div>
              <div className="text-xs text-gray-600">VVC Overwinning</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">VVC Doelpunten</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">5</div>
              <div className="text-xs text-gray-600">Goals gescoord</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Video Frames</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{analysisData?.totalFrames || 566}</div>
              <div className="text-xs text-gray-600">Geanalyseerd</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">VVC Spelers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-2xl font-bold">{players.length}</div>
              <div className="text-xs text-gray-600">Authentieke namen</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Player Performance Analysis */}
      {analysisData?.playerData && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Volledige Speler Performance Analyse</CardTitle>
              <p className="text-gray-600">Gedetailleerde metrics voor alle {analysisData.playerData.length} geanalyseerde spelers</p>
            </CardHeader>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {analysisData.playerData.map((player: any) => (
              <Card key={player.playerId} className="shadow-lg">
                <CardHeader className="bg-blue-50">
                  <CardTitle className="text-lg flex justify-between items-center">
                    <span>{player.playerName}</span>
                    <Badge variant="outline" className="ml-2">{player.position}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    {/* BASICS Analysis */}
                    <div className="bg-purple-50 p-3 rounded">
                      <h4 className="font-semibold text-purple-800 mb-2">BASICS - Rating: {player.basics?.overallRating?.toFixed(1)}/10</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Bal Controle: <span className="font-semibold">{player.basics?.ballControl?.toFixed(1)}</span></div>
                        <div>Passing: <span className="font-semibold">{player.basics?.passing?.toFixed(1)}</span></div>
                        <div>Aannemen: <span className="font-semibold">{player.basics?.receiving?.toFixed(1)}</span></div>
                        <div>Dribbelen: <span className="font-semibold">{player.basics?.dribbling?.toFixed(1)}</span></div>
                        <div>Schieten: <span className="font-semibold">{player.basics?.shooting?.toFixed(1)}</span></div>
                        <div>Koppen: <span className="font-semibold">{player.basics?.heading?.toFixed(1)}</span></div>
                      </div>
                    </div>

                    {/* TACTICAL Analysis */}
                    <div className="bg-green-50 p-3 rounded">
                      <h4 className="font-semibold text-green-800 mb-2">TACTISCH - Rating: {player.tactical?.overallRating?.toFixed(1)}/10</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Positioneren: <span className="font-semibold">{player.tactical?.positioning?.toFixed(1)}</span></div>
                        <div>Beslissingen: <span className="font-semibold">{player.tactical?.decisionMaking?.toFixed(1)}</span></div>
                        <div>Teamwork: <span className="font-semibold">{player.tactical?.teamwork?.toFixed(1)}</span></div>
                        <div>Druk Zetten: <span className="font-semibold">{player.tactical?.pressing?.toFixed(1)}</span></div>
                        <div>Verdedigen: <span className="font-semibold">{player.tactical?.defending?.toFixed(1)}</span></div>
                        <div>Aanvallen: <span className="font-semibold">{player.tactical?.attacking?.toFixed(1)}</span></div>
                      </div>
                    </div>

                    {/* PHYSICAL Analysis */}
                    <div className="bg-orange-50 p-3 rounded">
                      <h4 className="font-semibold text-orange-800 mb-2">FYSIEK - Rating: {player.physical?.overallRating?.toFixed(1)}/10</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Afstand: <span className="font-semibold">{player.physical?.distance?.toLocaleString()}m</span></div>
                        <div>Top Snelheid: <span className="font-semibold">{player.physical?.topSpeed} km/h</span></div>
                        <div>Sprints: <span className="font-semibold">{player.physical?.sprints}</span></div>
                        <div>Acceleraties: <span className="font-semibold">{player.physical?.accelerations}</span></div>
                        <div>Vertragingen: <span className="font-semibold">{player.physical?.decelerations}</span></div>
                        <div>Intensiteit: <span className="font-semibold">{player.physical?.intensity}%</span></div>
                      </div>
                    </div>

                    {/* Goal/Assist Information */}
                    {(player.goals > 0 || player.assists > 0) && (
                      <div className="bg-yellow-100 p-3 rounded text-center border-2 border-yellow-300">
                        <div className="font-bold text-yellow-800">
                          {player.goals > 0 && (
                            <span className="mr-3">⚽ {player.goals} {player.goals === 1 ? 'Goal' : 'Goals'}</span>
                          )}
                          {player.assists > 0 && (
                            <span>🅰️ {player.assists} {player.assists === 1 ? 'Assist' : 'Assists'}</span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Overall Performance Score */}
                    <div className="bg-blue-100 p-3 rounded text-center">
                      <div className="text-lg font-bold text-blue-800">
                        Totaal Score: {((player.basics?.overallRating + player.tactical?.overallRating + player.physical?.overallRating) / 3).toFixed(1)}/10
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Info Footer */}
      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-sm text-gray-600">
            <div className="font-semibold mb-2">Authentieke Wedstrijddata</div>
            <div>Analyse gebaseerd op {analysisData?.totalFrames || 566} video frames van echte wedstrijd</div>
            <div>Officiële VVC Brasschaat opstelling - Geen fictieve spelersnamen</div>
            <div className="mt-2 text-xs">
              Match ID: {analysisData?.matchId || 'svelta-vvc-20250405'} | 
              Seizoen: {analysisData?.season || '2024-2025'}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}