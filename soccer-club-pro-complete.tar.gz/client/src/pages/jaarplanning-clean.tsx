import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Calendar, Plus, Edit, Copy, Download, FileText, CalendarDays, Target, Users, Brain, Zap } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface TrainingPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface TrainingSession {
  week: number;
  session: number;
  date: string;
  duration: number;
  focusArea: string;
  assignedThemes: string[];
  assignedElements: string[];
  iadatabankElements: {
    basics: string[];
    teamtactisch: string[];
    mentaal: string[];
    fysiek: string[];
  };
  objectives: string[];
  notes: string;
}

export default function Jaarplanning() {
  // Mock user for now - will be replaced with proper auth
  const user = { id: 1, username: "admin" };
  const [plans, setPlans] = useState<TrainingPlan[]>([
    {
      id: 1,
      name: "U12 Seizoen 2024-2025",
      description: "Volledige seizoensplanning voor U12 Welpen",
      ageGroup: "U12 - Welpen (10-11 jaar)",
      teamId: 1,
      teamName: "U12 Welpen",
      season: "2024-2025",
      startDate: "2024-09-01",
      endDate: "2025-05-31",
      totalWeeks: 36,
      sessionsPerWeek: 2,
      trainingDays: ["Maandag", "Woensdag"],
      created: "2024-08-15",
      status: "active"
    },
    {
      id: 2,
      name: "U14 Intensief Programma",
      description: "Intensieve technische ontwikkeling voor U14",
      ageGroup: "U14 - Scholieren (12-13 jaar)",
      teamId: 2,
      teamName: "U14 Scholieren",
      season: "2024-2025",
      startDate: "2024-09-01",
      endDate: "2025-05-31",
      totalWeeks: 36,
      sessionsPerWeek: 3,
      trainingDays: ["Dinsdag", "Donderdag", "Zaterdag"],
      created: "2024-08-10",
      status: "active"
    }
  ]);
  const [selectedPlan, setSelectedPlan] = useState<TrainingPlan | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingPlan, setEditingPlan] = useState<TrainingPlan | null>(null);
  const [viewMode, setViewMode] = useState<"overview" | "calendar" | "details">("overview");
  const [trainingSessions, setTrainingSessions] = useState<TrainingSession[]>([]);
  const [editingSession, setEditingSession] = useState<TrainingSession | null>(null);
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTeamId, setSelectedTeamId] = useState<number | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<string>("all");
  const [showIADatabankDialog, setShowIADatabankDialog] = useState(false);
  const [selectedSessionForIA, setSelectedSessionForIA] = useState<TrainingSession | null>(null);
  const [selectedIAElements, setSelectedIAElements] = useState<{[key: string]: boolean}>({});
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<number>(1);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [password, setPassword] = useState("");
  const [pendingAction, setPendingAction] = useState<{type: 'add' | 'remove', category: string, subcategory: string, level: number} | null>(null);
  const [showCalendarView, setShowCalendarView] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [calendarDates, setCalendarDates] = useState<{date: string, hasTraining: boolean}[]>([]);

  // Password handling for IADATABANK modifications
  const handleThemeAction = (type: 'add' | 'remove', category: string, subcategory: string, level: number) => {
    setPendingAction({ type, category, subcategory, level });
    setShowPasswordDialog(true);
  };

  const handlePasswordSubmit = () => {
    if (password === "Qunoot135!" && pendingAction) {
      // Execute the pending action
      console.log(`${pendingAction.type} thema voor ${pendingAction.category} ${pendingAction.subcategory} niveau ${pendingAction.level}`);
      
      // Here you would implement the actual theme modification logic
      // For now, just log the action
      
      // Reset state
      setPassword("");
      setShowPasswordDialog(false);
      setPendingAction(null);
    } else {
      alert("Incorrect wachtwoord!");
    }
  };

  // Fetch teams - mock data for now
  const teams = [
    { id: 1, name: "U12 Welpen", ageGroup: "U12" },
    { id: 2, name: "U14 Scholieren", ageGroup: "U14" },
    { id: 3, name: "U16 Junioren", ageGroup: "U16" }
  ];

  // Form state for creating new plan
  const [newPlan, setNewPlan] = useState({
    name: "",
    description: "",
    ageGroup: "",
    teamId: null as number | null,
    season: "",
    startDate: "",
    endDate: "",
    sessionsPerWeek: 2,
    trainingDays: [] as string[]
  });

  const ageGroups = [
    "U8 - Pupillen (6-7 jaar)",
    "U10 - Pupillen (8-9 jaar)", 
    "U12 - Welpen (10-11 jaar)",
    "U14 - Scholieren (12-13 jaar)",
    "U16 - Junioren (14-15 jaar)",
    "U18 - Junioren (16-17 jaar)",
    "U21 - Beloften (18-20 jaar)",
    "Senioren (21+ jaar)"
  ];

  const weekdays = [
    "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag", "Zondag"
  ];

  const openIADatabankDialog = (session?: TrainingSession, date?: string) => {
    if (date) {
      setSelectedDate(date);
      // Reset IADATABANK selection state
      setSelectedCategory(null);
      setSelectedSubcategory(null);
      setSelectedLevel(1);
    }
    if (session) {
      setSelectedSessionForIA(session);
    }
    setShowIADatabankDialog(true);
  };

  // Generate calendar for current month
  const generateCalendar = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());
    
    const dates = [];
    const current = new Date(startDate);
    
    for (let i = 0; i < 42; i++) {
      const dateStr = current.toISOString().split('T')[0];
      dates.push({
        date: dateStr,
        day: current.getDate(),
        isCurrentMonth: current.getMonth() === month,
        isToday: current.toDateString() === new Date().toDateString(),
        hasTraining: Math.random() > 0.7 // Mock training data
      });
      current.setDate(current.getDate() + 1);
    }
    
    return dates;
  };

  const calendarData = generateCalendar();

  const monthNames = [
    'Januari', 'Februari', 'Maart', 'April', 'Mei', 'Juni',
    'Juli', 'Augustus', 'September', 'Oktober', 'November', 'December'
  ];

  const dayNames = ['Zo', 'Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Jaarplanning Beheer</h1>
            <p className="text-gray-600">Maak en beheer trainingsplannen voor het seizoen</p>
          </div>
          <Button 
            onClick={() => setShowCreateDialog(true)}
            className="bg-green-600 hover:bg-green-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nieuwe Jaarplanning
          </Button>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Actieve Plannen</p>
                  <p className="text-2xl font-bold text-green-600">{plans.filter(p => p.status === 'active').length}</p>
                </div>
                <CalendarDays className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Totaal Plannen</p>
                  <p className="text-2xl font-bold text-blue-600">{plans.length}</p>
                </div>
                <FileText className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Deze Week</p>
                  <p className="text-2xl font-bold text-purple-600">{trainingSessions.length}</p>
                </div>
                <Calendar className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          {/* View Mode Selector */}
          <div className="flex gap-2 mb-6">
            <Button
              variant={viewMode === "overview" ? "default" : "outline"}
              onClick={() => setViewMode("overview")}
            >
              Overzicht
            </Button>
            <Button
              variant={viewMode === "calendar" ? "default" : "outline"}
              onClick={() => setViewMode("calendar")}
            >
              Kalender
            </Button>
            <Button
              variant={viewMode === "details" ? "default" : "outline"}
              onClick={() => setViewMode("details")}
            >
              Details
            </Button>
          </div>

          {/* Content based on view mode */}
          {viewMode === "overview" && (
            <div className="space-y-4">
              {plans.map((plan) => (
                <Card key={plan.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">{plan.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{plan.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={plan.status === 'active' ? 'default' : 'secondary'}>
                          {plan.status}
                        </Badge>
                        <Button size="sm" variant="outline" onClick={() => setSelectedPlan(plan)}>
                          Bekijk
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => openIADatabankDialog(trainingSessions[0])}>
                          IADATABANK
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Leeftijdsgroep:</span>
                        <p>{plan.ageGroup}</p>
                      </div>
                      <div>
                        <span className="font-medium">Seizoen:</span>
                        <p>{plan.season}</p>
                      </div>
                      <div>
                        <span className="font-medium">Periode:</span>
                        <p>{plan.startDate} - {plan.endDate}</p>
                      </div>
                      <div>
                        <span className="font-medium">Trainingen:</span>
                        <p>{plan.sessionsPerWeek}x per week</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Calendar View */}
          {viewMode === "calendar" && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              {/* Calendar Header */}
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold">
                  {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                </h3>
                <div className="flex gap-4 items-center">
                  {/* Plan Selector */}
                  <Select 
                    value={selectedPlan?.id.toString() || ""} 
                    onValueChange={(value) => {
                      const plan = plans.find(p => p.id.toString() === value);
                      setSelectedPlan(plan || null);
                    }}
                  >
                    <SelectTrigger className="w-64">
                      <SelectValue placeholder="Selecteer een plan" />
                    </SelectTrigger>
                    <SelectContent>
                      {plans.map((plan) => (
                        <SelectItem key={plan.id} value={plan.id.toString()}>
                          {plan.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
                    >
                      Vorige
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentMonth(new Date())}
                    >
                      Vandaag
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
                    >
                      Volgende
                    </Button>
                  </div>
                </div>
              </div>

              {/* Day Headers */}
              <div className="grid grid-cols-7 gap-1 mb-2">
                {dayNames.map((day) => (
                  <div key={day} className="p-2 text-center text-sm font-medium text-gray-600">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-1">
                {calendarData.map((dateInfo, index) => {
                  const dayOfWeek = new Date(dateInfo.date).getDay();
                  // Get training days from selected plan or default to Monday/Wednesday
                  const selectedPlanTrainingDays = selectedPlan?.trainingDays || ["Maandag", "Woensdag"];
                  const dayMapping = {
                    "Zondag": 0, "Maandag": 1, "Dinsdag": 2, "Woensdag": 3, 
                    "Donderdag": 4, "Vrijdag": 5, "Zaterdag": 6
                  };
                  const trainingDayNumbers = selectedPlanTrainingDays.map(day => dayMapping[day as keyof typeof dayMapping]);
                  const isTrainingDay = trainingDayNumbers.includes(dayOfWeek);
                  
                  return (
                    <div
                      key={index}
                      onClick={() => openIADatabankDialog(undefined, dateInfo.date)}
                      className={`
                        min-h-[80px] p-2 border rounded-lg cursor-pointer transition-all hover:shadow-md
                        ${!dateInfo.isCurrentMonth ? 'text-gray-300 bg-gray-50' : 'bg-white'}
                        ${dateInfo.isToday ? 'ring-2 ring-blue-500 bg-blue-50' : ''}
                        ${isTrainingDay && dateInfo.isCurrentMonth ? 'bg-green-50 border-green-200' : ''}
                        hover:bg-blue-50
                      `}
                    >
                      <div className="flex flex-col h-full">
                        <span className={`text-sm font-medium ${dateInfo.isToday ? 'text-blue-600' : ''}`}>
                          {dateInfo.day}
                        </span>
                        
                        {/* Training indicator */}
                        {isTrainingDay && dateInfo.isCurrentMonth && (
                          <div className="mt-1">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <span className="text-xs text-green-700 mt-1 block">Training</span>
                          </div>
                        )}
                        
                        {/* IADATABANK planning indicator */}
                        {dateInfo.hasTraining && (
                          <div className="mt-auto">
                            <div className="text-xs bg-blue-100 text-blue-700 px-1 rounded">
                              IADATABANK
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Legend */}
              <div className="mt-6 flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span>Trainingsdagen ({selectedPlan ? selectedPlan.trainingDays.join('/') : 'Ma/Wo'})</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-100 border border-blue-300 rounded"></div>
                  <span>IADATABANK gepland</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-50 border-2 border-blue-500 rounded"></div>
                  <span>Vandaag</span>
                </div>
                <div className="text-gray-600">
                  Klik op een datum om IADATABANK elementen toe te wijzen
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* IADATABANK Assignment Dialog */}
      <Dialog open={showIADatabankDialog} onOpenChange={setShowIADatabankDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>IADATABANK Elementen Toewijzen</DialogTitle>
            <p className="text-sm text-muted-foreground">
              {selectedDate ? (
                <>Selecteer IADATABANK elementen voor training op {new Date(selectedDate).toLocaleDateString('nl-NL', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}</>
              ) : selectedSessionForIA?.date ? (
                <>Selecteer IADATABANK elementen voor training op {selectedSessionForIA.date}</>
              ) : (
                <>Selecteer IADATABANK elementen voor deze training</>
              )}
            </p>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto p-6">
            {/* Navigation tabs */}
            <div className="mb-6">
              <div className="flex gap-2 mb-4">
                {['BASICS', 'TEAMTACTICS', 'FYSIEK', 'MENTAAL'].map((category) => (
                  <button
                    key={category}
                    onClick={() => {
                      setSelectedCategory(category);
                      setSelectedSubcategory(null);
                    }}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      selectedCategory === category
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 hover:bg-gray-200'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>

              {/* Subcategory selection */}
              {selectedCategory && (
                <div className="flex gap-2 mb-4">
                  <button
                    onClick={() => setSelectedSubcategory('B+')}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      selectedSubcategory === 'B+'
                        ? 'bg-green-600 text-white'
                        : 'bg-green-100 hover:bg-green-200 text-green-800'
                    }`}
                  >
                    B+ (Aanvallend)
                  </button>
                  <button
                    onClick={() => setSelectedSubcategory('B-')}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      selectedSubcategory === 'B-'
                        ? 'bg-red-600 text-white'
                        : 'bg-red-100 hover:bg-red-200 text-red-800'
                    }`}
                  >
                    B- (Verdedigend)
                  </button>
                </div>
              )}

              {/* Progression levels with star system */}
              {selectedCategory && selectedSubcategory && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold mb-3">
                    {selectedCategory} {selectedSubcategory} - Progressieniveaus
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    {[
                      { level: 1, name: 'Eenvoudig', color: 'bg-green-100 border-green-300', textColor: 'text-green-800', stars: '★☆☆☆☆☆', description: 'Basis niveau - eerste kennismaking' },
                      { level: 2, name: 'Gericht', color: 'bg-blue-100 border-blue-300', textColor: 'text-blue-800', stars: '★★☆☆☆☆', description: 'Bewust niveau - gerichte ontwikkeling' },
                      { level: 3, name: 'Gericht snel', color: 'bg-yellow-100 border-yellow-300', textColor: 'text-yellow-800', stars: '★★★☆☆☆', description: 'Toegepast niveau - praktische toepassing' },
                      { level: 4, name: 'Onder druk', color: 'bg-orange-100 border-orange-300', textColor: 'text-orange-800', stars: '★★★★☆☆', description: 'Onder druk niveau - competitieve situaties' },
                      { level: 5, name: 'Toepassing', color: 'bg-red-100 border-red-300', textColor: 'text-red-800', stars: '★★★★★☆', description: 'Adaptief niveau - flexibele aanpassing' },
                      { level: 6, name: 'Meesterschap', color: 'bg-purple-100 border-purple-300', textColor: 'text-purple-800', stars: '★★★★★★', description: 'Meesterschap niveau - maximale prestatie' }
                    ].map((progression) => (
                      <div key={progression.level} className={`${progression.color} border rounded-lg p-3`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="text-lg font-mono text-yellow-600">
                              {progression.stars}
                            </div>
                            <div>
                              <span className={`font-medium ${progression.textColor}`}>
                                Niveau {progression.level}: {progression.name}
                              </span>
                              <p className="text-xs text-gray-600 mt-1">{progression.description}</p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleThemeAction('add', selectedCategory!, selectedSubcategory!, progression.level)}
                              className="text-xs"
                            >
                              Voeg thema toe
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleThemeAction('remove', selectedCategory!, selectedSubcategory!, progression.level)}
                              className="text-xs text-red-600 hover:text-red-700"
                            >
                              Verwijder thema
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Initial selection guide */}
            {!selectedCategory && (
              <div className="text-center py-8">
                <div className="w-12 h-12 mx-auto bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <Calendar className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">Selecteer een categorie</h3>
                <p className="text-muted-foreground">
                  Kies eerst een IADATABANK categorie om de thema's te beheren
                </p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Password dialog for IADATABANK modifications */}
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>IADATABANK Beveiliging</DialogTitle>
            <p className="text-sm text-muted-foreground">
              Voer het wachtwoord in om IADATABANK thema's te wijzigen
            </p>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              type="password"
              placeholder="Wachtwoord..."
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handlePasswordSubmit()}
            />
            <div className="flex gap-2">
              <Button onClick={handlePasswordSubmit} className="flex-1">
                Bevestigen
              </Button>
              <Button variant="outline" onClick={() => setShowPasswordDialog(false)}>
                Annuleren
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}