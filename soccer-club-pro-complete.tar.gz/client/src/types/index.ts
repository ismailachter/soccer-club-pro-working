// API Response Types
export interface ApiResponse<T> {
  data: T;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// User & Role related types
export type UserRole = 'admin' | 'coach' | 'player' | 'parent' | 'coordinator';
export type Gender = 'male' | 'female' | 'other';
export type Position = 'goalkeeper' | 'defender' | 'midfielder' | 'forward';
export type PlayerStatus = 'active' | 'inactive' | 'injured' | 'suspended';
export type MatchLocation = 'home' | 'away';
export type MatchStatus = 'scheduled' | 'completed' | 'cancelled' | 'postponed';
export type PitchStatus = 'available' | 'in_use' | 'maintenance';
export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';

export interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  role: UserRole;
  profileImage?: string;
  address?: string;
  dateOfBirth?: string;
  createdAt: string;
}

// Team related types
export interface Team {
  id: number;
  name: string;
  ageGroup: string;
  description?: string;
  foundedDate?: string;
  logo?: string;
  primaryCoachId?: number;
  primaryCoach?: User;
  createdAt: string;
}

// Player related types
export interface PlayerStatistics {
  goals: number;
  assists: number;
  appearances: number;
  yellowCards: number;
  redCards: number;
  minutesPlayed: number;
}

export interface Player {
  id: number;
  userId: number;
  user?: User;
  teamId?: number;
  team?: Team;
  jerseyNumber?: number;
  position?: Position;
  height?: number; // in cm
  weight?: number; // in kg
  status: PlayerStatus;
  medicalInfo?: string;
  emergencyContact?: string;
  parentId?: number;
  parent?: User;
  statistics?: PlayerStatistics;
  createdAt: string;
}

// Coach related types
export interface Coach {
  id: number;
  userId: number;
  user?: User;
  qualifications?: string;
  experience?: string;
  specialization?: string;
  bio?: string;
  createdAt: string;
}

// Parent related types
export interface Parent {
  id: number;
  userId: number;
  user?: User;
  contactPreference: string;
  occupation?: string;
  alternatePhone?: string;
  notes?: string;
  players?: Player[];
  createdAt: string;
}

// Pitch/Field related types
export interface Pitch {
  id: number;
  name: string;
  location: string;
  size?: string;
  surface?: string;
  status: PitchStatus;
  maintenanceNotes?: string;
  lastMaintenance?: string;
  nextMaintenance?: string;
  image?: string;
  createdAt: string;
}

// Coordinator related types
export interface Coordinator {
  id: number;
  userId: number;
  user?: User;
  responsibilities?: string;
  assignedTeams: number[];
  teams?: Team[];
  startDate?: string;
  createdAt: string;
}

// Match related types
export interface Match {
  id: number;
  teamId: number;
  team?: Team;
  opponentName: string;
  date: string;
  location: MatchLocation;
  pitchId?: number;
  pitch?: Pitch;
  status: MatchStatus;
  homeScore?: number;
  awayScore?: number;
  matchType: string;
  notes?: string;
  createdAt: string;
}

// Training session related types
export interface TrainingSession {
  id: number;
  teamId: number;
  team?: Team;
  coachId?: number;
  coach?: User;
  pitchId?: number;
  pitch?: Pitch;
  date: string;
  startTime: string;
  endTime: string;
  focus?: string;
  notes?: string;
  createdAt: string;
}

// Attendance related types
export interface Attendance {
  id: number;
  playerId: number;
  player?: Player;
  sessionId: number;
  sessionType: 'match' | 'training';
  status: AttendanceStatus;
  notes?: string;
  createdAt: string;
}

// Dashboard types
export interface DashboardStats {
  totalPlayers: number;
  activeTeams: number;
  upcomingMatches: number;
  fieldUtilization: number;
  availableFields: number;
}

export interface TeamPerformanceData {
  id: number;
  name: string;
  performance: number;
}

export interface ActivityItem {
  id: number;
  type: 'new_player' | 'match_result' | 'training_scheduled' | 'field_maintenance';
  content: string;
  timestamp: string;
  entities?: {
    name: string;
    team?: string;
  }[];
}

export interface UpcomingMatchData extends Match {
  team: {
    name: string;
  };
  pitch?: {
    name: string;
  };
}

export interface FieldStatusData {
  id: number;
  name: string;
  status: PitchStatus;
}

// Form related types
export interface FormError {
  field: string;
  message: string;
}

// Input types for creating/updating entities
export interface CreateUserInput {
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  role: UserRole;
  profileImage?: string;
  address?: string;
  dateOfBirth?: string;
}

export interface CreateTeamInput {
  name: string;
  ageGroup: string;
  description?: string;
  foundedDate?: string;
  logo?: string;
  primaryCoachId?: number;
}

export interface CreatePlayerInput {
  userId: number;
  teamId?: number;
  jerseyNumber?: number;
  position?: Position;
  height?: number;
  weight?: number;
  status?: PlayerStatus;
  medicalInfo?: string;
  emergencyContact?: string;
  parentId?: number;
  statistics?: PlayerStatistics;
}
