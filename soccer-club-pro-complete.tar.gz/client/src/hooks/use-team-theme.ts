import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from './use-auth';

export interface TeamTheme {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  textColor: string;
  gradientFrom: string;
  gradientTo: string;
  backgroundLight: string;
  backgroundMedium: string;
  borderColor: string;
}

const defaultTheme: TeamTheme = {
  primaryColor: '#3b82f6',
  secondaryColor: '#1e40af',
  accentColor: '#60a5fa',
  textColor: '#ffffff',
  gradientFrom: '#3b82f6',
  gradientTo: '#1e40af',
  backgroundLight: '#eff6ff',
  backgroundMedium: '#dbeafe',
  borderColor: '#93c5fd'
};

const teamColorPresets = [
  {
    name: 'Royal Blue',
    primaryColor: '#3b82f6',
    secondaryColor: '#1e40af',
    accentColor: '#60a5fa',
    textColor: '#ffffff'
  },
  {
    name: 'Forest Green',
    primaryColor: '#059669',
    secondaryColor: '#047857',
    accentColor: '#34d399',
    textColor: '#ffffff'
  },
  {
    name: 'Crimson Red',
    primaryColor: '#dc2626',
    secondaryColor: '#b91c1c',
    accentColor: '#f87171',
    textColor: '#ffffff'
  },
  {
    name: 'Golden Yellow',
    primaryColor: '#d97706',
    secondaryColor: '#b45309',
    accentColor: '#fbbf24',
    textColor: '#1f2937'
  },
  {
    name: 'Royal Purple',
    primaryColor: '#7c3aed',
    secondaryColor: '#6d28d9',
    accentColor: '#a78bfa',
    textColor: '#ffffff'
  },
  {
    name: 'Orange Blaze',
    primaryColor: '#ea580c',
    secondaryColor: '#c2410c',
    accentColor: '#fb923c',
    textColor: '#ffffff'
  },
  {
    name: 'Teal Ocean',
    primaryColor: '#0891b2',
    secondaryColor: '#0e7490',
    accentColor: '#22d3ee',
    textColor: '#ffffff'
  },
  {
    name: 'Deep Pink',
    primaryColor: '#be185d',
    secondaryColor: '#9d174d',
    accentColor: '#f472b6',
    textColor: '#ffffff'
  }
];

function hexToHsl(hex: string) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;

  if (max === min) {
    h = s = 0;
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
      default: h = 0;
    }
    h /= 6;
  }

  return [h * 360, s * 100, l * 100];
}

function generateThemeFromColors(primaryColor: string, secondaryColor: string, accentColor: string, textColor: string): TeamTheme {
  const [h, s, l] = hexToHsl(primaryColor);
  
  return {
    primaryColor,
    secondaryColor,
    accentColor,
    textColor,
    gradientFrom: primaryColor,
    gradientTo: secondaryColor,
    backgroundLight: `hsl(${h}, ${Math.max(20, s - 40)}%, ${Math.min(97, l + 50)}%)`,
    backgroundMedium: `hsl(${h}, ${Math.max(30, s - 20)}%, ${Math.min(92, l + 35)}%)`,
    borderColor: `hsl(${h}, ${Math.max(40, s - 10)}%, ${Math.min(80, l + 20)}%)`
  };
}

export function useTeamTheme() {
  const { user } = useAuth();
  const [currentTheme, setCurrentTheme] = useState<TeamTheme>(defaultTheme);

  // Fetch user's team data including colors
  const { data: teamData } = useQuery({
    queryKey: ['/api/users', user?.id, 'team'],
    enabled: !!user?.id
  });

  const { data: userTeam } = useQuery({
    queryKey: ['/api/teams', teamData?.teamId],
    enabled: !!teamData?.teamId
  });

  useEffect(() => {
    if (userTeam && userTeam.primaryColor && userTeam.secondaryColor) {
      const theme = generateThemeFromColors(
        userTeam.primaryColor,
        userTeam.secondaryColor,
        userTeam.accentColor || userTeam.primaryColor,
        userTeam.textColor || '#ffffff'
      );
      setCurrentTheme(theme);
    }
  }, [userTeam]);

  const applyTheme = (theme: TeamTheme) => {
    const root = document.documentElement;
    
    // Apply CSS custom properties
    root.style.setProperty('--team-primary', theme.primaryColor);
    root.style.setProperty('--team-secondary', theme.secondaryColor);
    root.style.setProperty('--team-accent', theme.accentColor);
    root.style.setProperty('--team-text', theme.textColor);
    root.style.setProperty('--team-gradient-from', theme.gradientFrom);
    root.style.setProperty('--team-gradient-to', theme.gradientTo);
    root.style.setProperty('--team-bg-light', theme.backgroundLight);
    root.style.setProperty('--team-bg-medium', theme.backgroundMedium);
    root.style.setProperty('--team-border', theme.borderColor);
    
    setCurrentTheme(theme);
  };

  useEffect(() => {
    applyTheme(currentTheme);
  }, [currentTheme]);

  return {
    currentTheme,
    applyTheme,
    generateThemeFromColors,
    teamColorPresets,
    userTeam,
    isTeamThemeAvailable: !!userTeam?.primaryColor
  };
}