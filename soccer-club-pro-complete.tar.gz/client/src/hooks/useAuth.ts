import { useQuery } from "@tanstack/react-query";

export function useAuth() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    isViewer: user?.role === 'viewer',
    isReadOnly: user?.role === 'viewer' || user?.role === 'player',
    canEdit: user?.role && ['admin', 'coach', 'coordinator', 'trainer', 'planner'].includes(user.role),
    canManage: user?.role && ['admin', 'coach', 'coordinator'].includes(user.role),
  };
}