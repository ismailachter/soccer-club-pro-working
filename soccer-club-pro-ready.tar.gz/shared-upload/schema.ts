import { pgTable, text, serial, integer, boolean, timestamp, pgEnum, json, date, decimal, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const roleEnum = pgEnum('role', ['admin', 'coach', 'player', 'parent', 'coordinator', 'trainer']);
export const genderEnum = pgEnum('gender', ['male', 'female', 'other']);
export const positionEnum = pgEnum('position', ['goalkeeper', 'defender', 'midfielder', 'forward']);
export const statusEnum = pgEnum('status', ['active', 'inactive', 'injured', 'suspended']);
export const locationEnum = pgEnum('location', ['home', 'away']);
export const matchStatusEnum = pgEnum('match_status', ['scheduled', 'completed', 'cancelled', 'postponed']);
export const pitchStatusEnum = pgEnum('pitch_status', ['available', 'in_use', 'maintenance']);
export const attendanceStatusEnum = pgEnum('attendance_status', ['present', 'absent', 'late', 'excused']);
export const footPreferenceEnum = pgEnum('foot_preference', ['left', 'right', 'both']);
export const paymentStatusEnum = pgEnum('payment_status', ['pending', 'paid', 'partially_paid', 'overdue', 'cancelled', 'refunded']);
export const paymentMethodEnum = pgEnum('payment_method', ['cash', 'bank_transfer', 'credit_card', 'debit_card', 'check', 'online', 'other']);
export const feeTypeEnum = pgEnum('fee_type', ['membership', 'registration', 'tournament', 'equipment', 'training', 'travel', 'event', 'other']);
export const clubStatusEnum = pgEnum('club_status', ['active', 'inactive', 'pending', 'archived']);
export const mainTopicEnum = pgEnum('main_topic', ['BASICS', 'TEAMTACTISCH', 'PHYSIEK', 'MENTAAL']);
export const subtopicEnum = pgEnum('subtopic', ['B+', 'B-']);
export const intensityEnum = pgEnum('intensity', ['laag', 'matig', 'hoog', 'maximaal']);
export const equipmentEnum = pgEnum('equipment', ['geen', 'bal', 'kegels', 'ladder', 'hoepels', 'pionnen', 'andere']);
export const difficultyEnum = pgEnum('difficulty', ['beginner', 'intermediate', 'advanced', 'expert']);
export const exerciseTypeEnum = pgEnum('exercise_type', ['warming_up', 'techniek', 'tactiek', 'fysiek', 'spelvormen', 'cooling_down']);
export const shapeTypeEnum = pgEnum('shape_type', ['rectangle', 'circle', 'triangle', 'diamond', 'line', 'arrow', 'goal', 'cone', 'player']);
export const playerRoleEnum = pgEnum('player_role', ['attacker', 'defender', 'goalkeeper', 'neutral']);
export const weekdayEnum = pgEnum('weekday', ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']);
export const planStatusEnum = pgEnum('plan_status', ['draft', 'active', 'completed', 'archived']);

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  username: text('username').notNull().unique(),
  password: text('password').notNull(),
  lastName: text('last_name').notNull(),
  firstName: text('first_name').notNull(),
  middleName: text('middle_name'),
  nickname: text('nickname'),
  club: text('club'),
  email: text('email').notNull(),
  email2: text('email_2'),
  email3: text('email_3'),
  email4: text('email_4'),
  email5: text('email_5'),
  phone: text('phone'),
  phone2: text('phone_2'),
  phone3: text('phone_3'),
  phone4: text('phone_4'),
  phone5: text('phone_5'),
  smsNumber: text('sms_number'),
  role: roleEnum('role').notNull(),
  profileImage: text('profile_image'),
  address: text('address'), // Primary address
  secondaryAddress: text('secondary_address'),
  dateOfBirth: timestamp('date_of_birth'),
  birthPlace: text('birth_place'),
  gender: genderEnum('gender'),
  nationality: text('nationality'),
  nativeLanguage: text('native_language'),
  identityCardNumber: text('identity_card_number'),
  identityCardExpiryDate: date('identity_card_expiry_date'),
  nationalRegistryNumber: text('national_registry_number'), // Rijksregisternummer
  accountNumber: text('account_number'), // Rekeningnummer
  associationNumber: text('association_number'), // Bondsnummer
  joinDate: date('join_date'), // Aansluitingsdatum
  // Authentication and invitation fields
  isInvited: boolean('is_invited').default(false),
  invitedBy: integer('invited_by').references(() => users.id),
  invitedAt: timestamp('invited_at'),
  invitationToken: text('invitation_token'),
  invitationSent: timestamp('invitation_sent'),
  lastLogin: timestamp('last_login'),
  resetPasswordToken: text('reset_password_token'),
  resetPasswordExpires: timestamp('reset_password_expires'),
  emailVerified: boolean('email_verified').default(false),
  verificationToken: text('verification_token'),
  isActive: boolean('is_active').default(true),
  lastModifiedDate: timestamp('last_modified_date'),
  status: statusEnum('status').default('active'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Teams table
export const teams = pgTable('teams', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(),
  ageGroup: text('age_group').notNull(),
  description: text('description'),
  foundedDate: timestamp('founded_date'),
  logo: text('logo'),
  primaryCoachId: integer('primary_coach_id').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow(),
});

// Players table
export const players = pgTable('players', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  teamId: integer('team_id').references(() => teams.id),
  jerseyNumber: integer('jersey_number'),
  position: positionEnum('position'),
  height: integer('height'), // in cm
  weight: integer('weight'), // in kg
  status: statusEnum('status').default('active'),
  footPreference: footPreferenceEnum('foot_preference'),
  medicalInfo: text('medical_info'),
  emergencyContact: text('emergency_contact'),
  parentId: integer('parent_id').references(() => users.id),
  siblings: text('siblings'), // Brothers/sisters (broers/zussen)
  children: text('children'), // For players who might have children
  statistics: json('statistics').$type<{
    goals: number;
    assists: number;
    appearances: number;
    yellowCards: number;
    redCards: number;
    minutesPlayed: number;
  }>(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Coaches table
export const coaches = pgTable('coaches', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  qualifications: text('qualifications'),
  experience: text('experience'),
  specialization: text('specialization'),
  bio: text('bio'),
  siblings: text('siblings'), // Brothers/sisters
  children: text('children'), // Children information
  joinDate: date('join_date'), // Aansluitingsdatum
  createdAt: timestamp('created_at').defaultNow(),
});

// Parents table
export const parents = pgTable('parents', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  contactPreference: text('contact_preference').default('email'),
  occupation: text('occupation'),
  alternatePhone: text('alternate_phone'),
  notes: text('notes'),
  children: text('children'), // Children information
  siblings: text('siblings'), // Brothers/sisters
  joinDate: date('join_date'), // Aansluitingsdatum
  createdAt: timestamp('created_at').defaultNow(),
});

// Pitches/Fields table
export const pitches = pgTable('pitches', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(),
  location: text('location').notNull(),
  size: text('size'),
  surface: text('surface'),
  status: pitchStatusEnum('status').default('available'),
  maintenanceNotes: text('maintenance_notes'),
  lastMaintenance: timestamp('last_maintenance'),
  nextMaintenance: timestamp('next_maintenance'),
  image: text('image'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Coordinators table
export const coordinators = pgTable('coordinators', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  responsibilities: text('responsibilities'),
  assignedTeams: json('assigned_teams').$type<number[]>(),
  startDate: timestamp('start_date'),
  siblings: text('siblings'), // Brothers/sisters
  children: text('children'), // Children information
  joinDate: date('join_date'), // Aansluitingsdatum
  createdAt: timestamp('created_at').defaultNow(),
});

// Trainers table
export const trainers = pgTable('trainers', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  qualifications: text('qualifications'),
  experience: text('experience'),
  specialization: text('specialization'), // e.g., fitness, rehabilitation, skills development
  certifications: text('certifications'),
  bio: text('bio'),
  siblings: text('siblings'), // Brothers/sisters
  children: text('children'), // Children information
  joinDate: date('join_date'), // Aansluitingsdatum
  createdAt: timestamp('created_at').defaultNow(),
});

// UserTeam junction table for many-to-many relation between users and teams
export const userTeams = pgTable('user_teams', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  teamId: integer('team_id').notNull().references(() => teams.id),
  roleType: text('role_type').notNull(), // 'player', 'coach', 'trainer', 'medical', 'manager', 'assistant', etc.
  title: text('title'), // Specific title for this role: 'Head Coach', 'Assistant Coach', 'Team Captain', etc.
  isPrimary: boolean('is_primary').default(false), // Is this the user's primary role for this team?
  startDate: date('start_date'), 
  endDate: date('end_date'),
  seasonId: integer('season_id'), // Optional reference to a specific season
  notes: text('notes'),
  permissions: json('permissions').$type<Record<string, string>>(), // Custom permissions for this role
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

// Club information table
export const clubs = pgTable('clubs', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(),
  fullName: text('full_name'),
  shortName: text('short_name'),
  foundedYear: integer('founded_year'),
  colors: text('colors'),
  logo: text('logo'),
  website: text('website'),
  email: text('email'),
  phone: text('phone'),
  address: text('address'),
  city: text('city'),
  postalCode: text('postal_code'),
  country: text('country').default('Belgium'),
  federationId: text('federation_id'), // ID used by the soccer federation
  vatNumber: text('vat_number'),
  bankAccount: text('bank_account'),
  description: text('description'),
  status: clubStatusEnum('status').default('active'),
  createdAt: timestamp('created_at').defaultNow(),
  createdBy: integer('created_by').references(() => users.id),
  updatedAt: timestamp('updated_at'),
  updatedBy: integer('updated_by').references(() => users.id),
});

// Matches table
export const matches = pgTable('matches', {
  id: serial('id').primaryKey(),
  teamId: integer('team_id').notNull().references(() => teams.id),
  opponentName: text('opponent_name').notNull(),
  date: timestamp('date').notNull(),
  location: locationEnum('location').notNull(),
  pitchId: integer('pitch_id').references(() => pitches.id),
  status: matchStatusEnum('status').default('scheduled'),
  homeScore: integer('home_score'),
  awayScore: integer('away_score'),
  matchType: text('match_type').default('league'), // league, friendly, tournament, etc.
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Training sessions table
export const trainingSessions = pgTable('training_sessions', {
  id: serial('id').primaryKey(),
  teamId: integer('team_id').references(() => teams.id),
  planId: integer('plan_id').references(() => trainingPlans.id),
  coachId: integer('coach_id').references(() => users.id),
  pitchId: integer('pitch_id').references(() => pitches.id),
  date: timestamp('date').notNull(),
  startTime: timestamp('start_time').notNull(),
  endTime: timestamp('end_time').notNull(),
  focus: text('focus'),
  notes: text('notes'),
  mainTopic: text('main_topic'),
  subTopic: text('sub_topic'),
  iadataBankElements: json('iadatabank_elements').$type<any[]>().default([]),
  duration: integer('duration').default(90),
  createdAt: timestamp('created_at').defaultNow(),
});

// Attendance table
export const attendance = pgTable('attendance', {
  id: serial('id').primaryKey(),
  playerId: integer('player_id').notNull().references(() => players.id),
  sessionId: integer('session_id').notNull(), // Can be match ID or training session ID
  sessionType: text('session_type').notNull(), // 'match' or 'training'
  status: attendanceStatusEnum('status').default('absent'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Fee categories table
export const feeCategories = pgTable('fee_categories', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(),
  description: text('description'),
  feeType: feeTypeEnum('fee_type').notNull(),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  seasonId: integer('season_id'), // Optional reference to a specific season
  teamId: integer('team_id').references(() => teams.id), // Optional team-specific fee
  ageGroup: text('age_group'), // Optional age group specific fee
  discount: decimal('discount', { precision: 10, scale: 2 }).default('0'), // Discount amount
  isActive: boolean('is_active').default(true),
  dueDate: date('due_date'), // When the fee is due
  createdAt: timestamp('created_at').defaultNow(),
});

// User Fees junction table
export const userFees = pgTable('user_fees', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  feeCategoryId: integer('fee_category_id').notNull().references(() => feeCategories.id),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  discountApplied: decimal('discount_applied', { precision: 10, scale: 2 }).default('0'),
  finalAmount: decimal('final_amount', { precision: 10, scale: 2 }).notNull(),
  dueDate: date('due_date').notNull(),
  status: paymentStatusEnum('status').default('pending'),
  notes: text('notes'),
  seasonId: integer('season_id'), // Optional reference to a specific season
  teamId: integer('team_id').references(() => teams.id), // Optional reference to a specific team
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Payments table
export const payments = pgTable('payments', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  userFeeId: integer('user_fee_id').references(() => userFees.id), // Optional - payment could be for multiple fees
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  paymentDate: timestamp('payment_date').notNull(),
  paymentMethod: paymentMethodEnum('payment_method').notNull(),
  reference: text('reference'), // Reference number, receipt number, etc.
  notes: text('notes'),
  receivedBy: integer('received_by').references(() => users.id), // Which admin user recorded this payment
  attachments: json('attachments').$type<string[]>(), // Array of URLs to receipt images or documents
  createdAt: timestamp('created_at').defaultNow(),
});

// Payment Plans table
export const paymentPlans = pgTable('payment_plans', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull().references(() => users.id),
  userFeeId: integer('user_fee_id').references(() => userFees.id), // Which fee this plan is for
  name: text('name').notNull(),
  description: text('description'),
  totalAmount: decimal('total_amount', { precision: 10, scale: 2 }).notNull(),
  numberOfInstallments: integer('number_of_installments').notNull(),
  installmentAmount: decimal('installment_amount', { precision: 10, scale: 2 }).notNull(),
  startDate: date('start_date').notNull(),
  endDate: date('end_date').notNull(),
  frequency: text('frequency').notNull(), // 'monthly', 'weekly', 'quarterly', etc.
  status: text('status').default('active'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Payment Plan Installments table
export const paymentPlanInstallments = pgTable('payment_plan_installments', {
  id: serial('id').primaryKey(),
  paymentPlanId: integer('payment_plan_id').notNull().references(() => paymentPlans.id),
  installmentNumber: integer('installment_number').notNull(),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  dueDate: date('due_date').notNull(),
  status: paymentStatusEnum('status').default('pending'),
  paymentId: integer('payment_id').references(() => payments.id), // Link to payment if paid
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users, {
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(['admin', 'coach', 'player', 'parent', 'coordinator', 'trainer']),
  dateOfBirth: z.string().optional().transform(val => val ? new Date(val) : undefined),
}).omit({ id: true, createdAt: true });

export const insertTeamSchema = createInsertSchema(teams).omit({ id: true, createdAt: true });
export const insertPlayerSchema = createInsertSchema(players).omit({ id: true, createdAt: true });
export const insertCoachSchema = createInsertSchema(coaches).omit({ id: true, createdAt: true });
export const insertParentSchema = createInsertSchema(parents).omit({ id: true, createdAt: true });
export const insertPitchSchema = createInsertSchema(pitches).omit({ id: true, createdAt: true });
export const insertCoordinatorSchema = createInsertSchema(coordinators).omit({ id: true, createdAt: true });
export const insertTrainerSchema = createInsertSchema(trainers).omit({ id: true, createdAt: true });
export const insertMatchSchema = createInsertSchema(matches).omit({ id: true, createdAt: true });
export const insertTrainingSessionSchema = createInsertSchema(trainingSessions).omit({ id: true, createdAt: true });
export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true, createdAt: true });
export const insertUserTeamSchema = createInsertSchema(userTeams).omit({ id: true, createdAt: true });
export const insertClubSchema = createInsertSchema(clubs, {
  foundedYear: z.string().or(z.number()).optional().transform(val => val ? (typeof val === 'string' ? parseInt(val) : val) : undefined),
  status: z.enum(['active', 'inactive', 'pending', 'archived']).default('active'),
}).omit({ id: true, createdAt: true, updatedAt: true });

// Payment schema definitions
export const insertFeeCategorySchema = createInsertSchema(feeCategories, {
  feeType: z.enum(['membership', 'registration', 'tournament', 'equipment', 'training', 'travel', 'event', 'other']),
  amount: z.string().or(z.number()).transform(val => typeof val === 'string' ? parseFloat(val) : val),
  discount: z.string().or(z.number()).optional().transform(val => val ? (typeof val === 'string' ? parseFloat(val) : val) : 0),
  dueDate: z.string().optional().transform(val => val ? new Date(val) : undefined),
}).omit({ id: true, createdAt: true });

export const insertUserFeeSchema = createInsertSchema(userFees, {
  amount: z.string().or(z.number()).transform(val => typeof val === 'string' ? parseFloat(val) : val),
  discountApplied: z.string().or(z.number()).optional().transform(val => val ? (typeof val === 'string' ? parseFloat(val) : val) : 0),
  finalAmount: z.string().or(z.number()).transform(val => typeof val === 'string' ? parseFloat(val) : val),
  dueDate: z.string().transform(val => new Date(val)),
  status: z.enum(['pending', 'paid', 'partially_paid', 'overdue', 'cancelled', 'refunded']),
}).omit({ id: true, createdAt: true, updatedAt: true });

export const insertPaymentSchema = createInsertSchema(payments, {
  amount: z.string().or(z.number()).transform(val => typeof val === 'string' ? parseFloat(val) : val),
  paymentDate: z.string().transform(val => new Date(val)),
  paymentMethod: z.enum(['cash', 'bank_transfer', 'credit_card', 'debit_card', 'check', 'online', 'other']),
  attachments: z.array(z.string()).optional(),
}).omit({ id: true, createdAt: true });

export const insertPaymentPlanSchema = createInsertSchema(paymentPlans, {
  totalAmount: z.string().or(z.number()).transform(val => typeof val === 'string' ? parseFloat(val) : val),
  installmentAmount: z.string().or(z.number()).transform(val => typeof val === 'string' ? parseFloat(val) : val),
  startDate: z.string().transform(val => new Date(val)),
  endDate: z.string().transform(val => new Date(val)),
}).omit({ id: true, createdAt: true });

export const insertPaymentPlanInstallmentSchema = createInsertSchema(paymentPlanInstallments, {
  amount: z.string().or(z.number()).transform(val => typeof val === 'string' ? parseFloat(val) : val),
  dueDate: z.string().transform(val => new Date(val)),
  status: z.enum(['pending', 'paid', 'partially_paid', 'overdue', 'cancelled', 'refunded']),
}).omit({ id: true, createdAt: true });

// IADATABANK - Basic Elements - BASIS B+ en B- elementen
export const basicElements = pgTable('ia_basic_elements', {
  id: serial('id').primaryKey(),
  key: text('key').notNull().unique(), // bijv: "LEIDEN_VAN_DE_BAL"
  name: text('name').notNull(), // bijv: "Leiden van de bal"
  subtopic: subtopicEnum('subtopic').notNull(), // B+ of B-
  sortOrder: integer('sort_order').default(0),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

// IADATABANK - Depth Levels - 6 diepgang niveaus per element
export const depthLevels = pgTable('ia_depth_levels', {
  id: serial('id').primaryKey(),
  elementId: integer('element_id').references(() => basicElements.id).notNull(),
  levelKey: text('level_key').notNull(), // bijv: "simple_ball_leading"
  name: text('name').notNull(), // bijv: "Eenvoudig leiden van de bal"
  description: text('description').notNull(), // uitgebreide beschrijving
  difficulty: integer('difficulty').notNull(), // 1-6
  sortOrder: integer('sort_order').default(0),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

// IADATABANK - Exercise Categories - 4 Hoofdtopics: BASIS, TEAMTACTISCH, PHYSIEK, MENTAAL
export const exerciseCategories = pgTable('ia_exercise_categories', {
  id: serial('id').primaryKey(),
  mainTopic: mainTopicEnum('main_topic').notNull(), // BASIS, TEAMTACTISCH, PHYSIEK, MENTAAL
  name: text('name').notNull(), // Subcategorie naam
  description: text('description'),
  sortOrder: integer('sort_order').default(0),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

// IADATABANK - Exercises - alle oefeningen database
export const exercises = pgTable('ia_exercises', {
  id: serial('id').primaryKey(),
  categoryId: integer('category_id').references(() => exerciseCategories.id),
  mainTopic: text('main_topic'), // BASICS, TEAMTACTISCH, MENTAAL, FYSIEK, OMSCHAKELING
  subTopic: text('sub_topic'), // B+, B-, etc.
  name: text('name').notNull(), // Naam van de oefening
  description: text('description'), // Korte beschrijving
  instructions: text('instructions'), // Uitvoering stap-voor-stap
  objectives: text('objectives'), // Doelstellingen
  keyPoints: text('key_points').array(), // Belangrijke aandachtspunten
  variations: text('variations').array(), // Variaties van de oefening
  equipment: equipmentEnum('equipment').default('geen'),
  intensity: intensityEnum('intensity').default('matig'),
  difficulty: difficultyEnum('difficulty').default('beginner'),
  minAge: integer('min_age'), // Minimale leeftijd
  maxAge: integer('max_age'), // Maximale leeftijd
  minPlayers: integer('min_players').default(1), // Minimum aantal spelers
  maxPlayers: integer('max_players'), // Maximum aantal spelers
  duration: integer('duration'), // Duur in minuten
  repetitions: text('repetitions'), // Herhalingen/sets
  restTime: integer('rest_time'), // Rust tussen sets in seconden
  spaceRequired: text('space_required'), // Benodigde ruimte
  preparationTime: integer('preparation_time'), // Voorbereiding in minuten
  coachingPoints: text('coaching_points').array(), // Coaching tips
  commonMistakes: text('common_mistakes').array(), // Veelgemaakte fouten
  progressions: text('progressions').array(), // Opbouw/progressie
  regressions: text('regressions').array(), // Eenvoudigere varianten
  videoUrl: text('video_url'), // Link naar instructievideo
  imageUrl: text('image_url'), // Link naar diagram/foto
  tags: text('tags').array(), // Voor zoeken en filteren
  source: text('source'), // Bron van de oefening
  notes: text('notes'), // Extra opmerkingen
  isActive: boolean('is_active').default(true),
  createdBy: integer('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// IADATABANK - Training Programs
export const trainingPrograms = pgTable('ia_training_programs', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  startDate: date('start_date').notNull(),
  endDate: date('end_date').notNull(),
  trainingDays: text('training_days').array(), // ["monday", "wednesday", "friday"]
  totalDuration: integer('total_duration').default(90), // in minuten
  targetAgeGroup: text('target_age_group'), // bijv. "U12", "U15", "Senior"
  difficultyLevel: difficultyEnum('difficulty').default('beginner'),
  objectives: text('objectives').array(), // Doelstellingen van het programma
  focus: text('focus').array(), // Hoofdfocus gebieden
  createdBy: integer('created_by').references(() => users.id),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// IADATABANK - Program Exercises - koppelt oefeningen aan programma's
export const programExercises = pgTable('ia_program_exercises', {
  id: serial('id').primaryKey(),
  programId: integer('program_id').references(() => trainingPrograms.id).notNull(),
  exerciseId: integer('exercise_id').references(() => exercises.id).notNull(),
  categoryId: integer('category_id').references(() => exerciseCategories.id).notNull(),
  sequenceOrder: integer('sequence_order').notNull(), // Volgorde in training
  duration: integer('duration'), // Specifieke duur voor dit programma
  notes: text('notes'), // Specifieke opmerkingen
  adaptations: text('adaptations'), // Aanpassingen voor dit programma
  createdAt: timestamp('created_at').defaultNow(),
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type UserTeam = typeof userTeams.$inferSelect;
export type InsertUserTeam = z.infer<typeof insertUserTeamSchema>;

export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;

export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;

export type Coach = typeof coaches.$inferSelect;
export type InsertCoach = z.infer<typeof insertCoachSchema>;

export type Parent = typeof parents.$inferSelect;
export type InsertParent = z.infer<typeof insertParentSchema>;

export type Pitch = typeof pitches.$inferSelect;
export type InsertPitch = z.infer<typeof insertPitchSchema>;

export type Coordinator = typeof coordinators.$inferSelect;
export type InsertCoordinator = z.infer<typeof insertCoordinatorSchema>;

export type Trainer = typeof trainers.$inferSelect;
export type InsertTrainer = z.infer<typeof insertTrainerSchema>;

export type Match = typeof matches.$inferSelect;
export type InsertMatch = z.infer<typeof insertMatchSchema>;

export type TrainingSession = typeof trainingSessions.$inferSelect;
export type InsertTrainingSession = z.infer<typeof insertTrainingSessionSchema>;

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;

// Payment entity types
export type FeeCategory = typeof feeCategories.$inferSelect;
export type InsertFeeCategory = z.infer<typeof insertFeeCategorySchema>;

export type UserFee = typeof userFees.$inferSelect;
export type InsertUserFee = z.infer<typeof insertUserFeeSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

// IADATABANK Insert Schemas
export const insertBasicElementSchema = createInsertSchema(basicElements, {
  key: z.string().min(1),
  name: z.string().min(1),
  subtopic: z.enum(['B+', 'B-']),
  sortOrder: z.number().optional(),
}).omit({ id: true, createdAt: true });

export const insertDepthLevelSchema = createInsertSchema(depthLevels, {
  elementId: z.number(),
  levelKey: z.string().min(1),
  name: z.string().min(1),
  description: z.string().min(1),
  difficulty: z.number().min(1).max(6),
  sortOrder: z.number().optional(),
}).omit({ id: true, createdAt: true });

// IADATABANK Export types
export type BasicElement = typeof basicElements.$inferSelect;
export type InsertBasicElement = z.infer<typeof insertBasicElementSchema>;

export type DepthLevel = typeof depthLevels.$inferSelect;
export type InsertDepthLevel = z.infer<typeof insertDepthLevelSchema>;



export type TrainingProgram = typeof trainingPrograms.$inferSelect;
export type InsertTrainingProgram = typeof trainingPrograms.$inferInsert;

export type ProgramExercise = typeof programExercises.$inferSelect;
export type InsertProgramExercise = typeof programExercises.$inferInsert;

export type PaymentPlan = typeof paymentPlans.$inferSelect;
export type InsertPaymentPlan = z.infer<typeof insertPaymentPlanSchema>;

export type PaymentPlanInstallment = typeof paymentPlanInstallments.$inferSelect;
export type InsertPaymentPlanInstallment = z.infer<typeof insertPaymentPlanInstallmentSchema>;

export type Club = typeof clubs.$inferSelect;
export type InsertClub = z.infer<typeof insertClubSchema>;

// Training Plans table
export const trainingPlans = pgTable('training_plans', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  ageGroup: text('age_group'),
  teamId: integer('team_id').references(() => teams.id),
  season: text('season'),
  startDate: date('start_date').notNull(),
  endDate: date('end_date').notNull(),
  sessionsPerWeek: integer('sessions_per_week').notNull().default(2),
  trainingDays: json('training_days').$type<string[]>().notNull().default([]),
  createdBy: integer('created_by').references(() => users.id).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const insertTrainingPlanSchema = createInsertSchema(trainingPlans).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export type TrainingPlan = typeof trainingPlans.$inferSelect;
export type InsertTrainingPlan = z.infer<typeof insertTrainingPlanSchema>;

// Year Planning based on IADATABANK
export const yearPlanning = pgTable('year_planning', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  season: text('season').notNull(), // e.g. "2024-2025"
  ageGroup: text('age_group').notNull(), // e.g. "U8", "U10", "U12"
  teamId: integer('team_id').references(() => teams.id),
  startDate: date('start_date').notNull(),
  endDate: date('end_date').notNull(),
  totalWeeks: integer('total_weeks').notNull(),
  sessionsPerWeek: integer('sessions_per_week').notNull().default(2),
  
  // IADATABANK element selection and progression
  selectedElements: json('selected_elements').$type<{
    elementId: string;
    topic: string;
    name: string;
    targetLevel: number; // target progression level to reach
    startWeek: number;
    endWeek: number;
    priority: 'high' | 'medium' | 'low';
    frequency: number; // times per week
  }[]>().notNull().default([]),
  
  // Planning structure
  periodization: json('periodization').$type<{
    preparationPhase: { startWeek: number; endWeek: number; focus: string[] };
    competitionPhase: { startWeek: number; endWeek: number; focus: string[] };
    transitionPhase?: { startWeek: number; endWeek: number; focus: string[] };
  }>(),
  
  // Weekly distribution
  weeklyDistribution: json('weekly_distribution').$type<{
    [week: number]: {
      basics: number; // percentage
      teamtactisch: number;
      mentaal: number;
      physiek: number;
      omschakeling: number;
    };
  }>().notNull().default({}),
  
  objectives: text('objectives').array().notNull().default([]),
  notes: text('notes'),
  createdBy: integer('created_by').references(() => users.id).notNull(),
  isTemplate: boolean('is_template').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const insertYearPlanningSchema = createInsertSchema(yearPlanning).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export type YearPlanning = typeof yearPlanning.$inferSelect;
export type InsertYearPlanning = z.infer<typeof insertYearPlanningSchema>;

// Exercise schema types
export const insertExerciseSchema = createInsertSchema(exercises).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertExerciseCategorySchema = createInsertSchema(exerciseCategories).omit({ 
  id: true, 
  createdAt: true 
});

export type Exercise = typeof exercises.$inferSelect;
export type InsertExercise = z.infer<typeof insertExerciseSchema>;
export type ExerciseCategory = typeof exerciseCategories.$inferSelect;
export type InsertExerciseCategory = z.infer<typeof insertExerciseCategorySchema>;

// Training Diagrams table - for visual exercise designs
export const trainingDiagrams = pgTable('training_diagrams', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  exerciseType: exerciseTypeEnum('exercise_type').notNull(),
  duration: integer('duration').notNull(), // minutes
  playersCount: integer('players_count').notNull(),
  fieldSize: text('field_size'), // e.g. "30x20m", "half field"
  equipment: text('equipment').array().notNull().default([]), // array of equipment needed
  difficulty: difficultyEnum('difficulty').notNull(),
  ageGroup: text('age_group'),
  objectives: text('objectives').array().notNull().default([]), // training objectives
  diagramData: json('diagram_data').$type<{
    shapes: Array<{
      id: string;
      type: string;
      x: number;
      y: number;
      width?: number;
      height?: number;
      radius?: number;
      color?: string;
      label?: string;
      playerRole?: string;
    }>;
    connections: Array<{
      id: string;
      from: string;
      to: string;
      type: 'pass' | 'run' | 'dribble' | 'shot';
      style?: 'solid' | 'dashed' | 'dotted';
      color?: string;
    }>;
  }>().notNull(),
  instructions: text('instructions'),
  variations: text('variations').array().default([]),
  coachingPoints: text('coaching_points').array().default([]),
  createdBy: integer('created_by').references(() => users.id).notNull(),
  teamId: integer('team_id').references(() => teams.id),
  isPublic: boolean('is_public').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const insertTrainingDiagramSchema = createInsertSchema(trainingDiagrams).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export type TrainingDiagram = typeof trainingDiagrams.$inferSelect;
export type InsertTrainingDiagram = z.infer<typeof insertTrainingDiagramSchema>;

// Year Plans with periods and training days
export const yearPlans = pgTable('year_plans', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  teamId: integer('team_id').references(() => teams.id),
  ageGroup: text('age_group'),
  startDate: date('start_date').notNull(),
  endDate: date('end_date').notNull(),
  status: planStatusEnum('status').default('draft'),
  trainingDays: json('training_days').$type<string[]>().notNull().default([]), // ['monday', 'wednesday', 'friday']
  createdBy: integer('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const yearPlanPeriods = pgTable('year_plan_periods', {
  id: serial('id').primaryKey(),
  yearPlanId: integer('year_plan_id').references(() => yearPlans.id).notNull(),
  name: text('name').notNull(), // bijv. "Voorbereiding", "Competitie", "Najaarsronde"
  description: text('description'),
  startDate: date('start_date').notNull(),
  endDate: date('end_date').notNull(),
  focusThemes: json('focus_themes').$type<string[]>().notNull().default([]), // IADATABANK element IDs
  color: text('color').default('#3B82F6'), // Voor kalender weergave
  sortOrder: integer('sort_order').default(0),
  createdAt: timestamp('created_at').defaultNow(),
});

export const yearPlanSessions = pgTable('year_plan_sessions', {
  id: serial('id').primaryKey(),
  yearPlanId: integer('year_plan_id').references(() => yearPlans.id).notNull(),
  periodId: integer('period_id').references(() => yearPlanPeriods.id),
  date: date('date').notNull(),
  themes: json('themes').$type<string[]>().notNull().default([]), // IADATABANK element IDs
  notes: text('notes'),
  duration: integer('duration'), // minuten
  location: text('location'),
  isCompleted: boolean('is_completed').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Insert schemas
export const insertYearPlanSchema = createInsertSchema(yearPlans).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertYearPlanPeriodSchema = createInsertSchema(yearPlanPeriods).omit({ 
  id: true, 
  createdAt: true 
});

export const insertYearPlanSessionSchema = createInsertSchema(yearPlanSessions).omit({ 
  id: true, 
  createdAt: true 
});

//Scout Database - Scouting profiel informatie
export const scoutPriorityEnum = pgEnum('scout_priority', ['low', 'medium', 'high', 'urgent']);
export const scoutStatusEnum = pgEnum('scout_status', ['prospect', 'contacted', 'interested', 'declined', 'signed']);

export const scoutDatabase = pgTable('scout_database', {
  id: serial('id').primaryKey(),
  firstName: text('first_name').notNull(),
  lastName: text('last_name').notNull(),
  dateOfBirth: date('date_of_birth'),
  nationality: text('nationality'),
  currentClub: text('current_club'),
  position: positionEnum('position'),
  email: text('email'),
  phone: text('phone'),
  address: text('address'),
  scoutPriority: scoutPriorityEnum('scout_priority').default('medium'),
  scoutStatus: scoutStatusEnum('scout_status').default('prospect'),
  scoutNotes: text('scout_notes'),
  overallRating: integer('overall_rating').default(0), // 0-10
  technicalSkills: integer('technical_skills').default(0), // 0-10
  physicalAttributes: integer('physical_attributes').default(0), // 0-10
  mentalStrength: integer('mental_strength').default(0), // 0-10
  potential: integer('potential').default(0), // 0-10
  height: integer('height'), // cm
  weight: integer('weight'), // kg
  preferredFoot: footPreferenceEnum('preferred_foot').default('right'),
  contractStatus: text('contract_status'),
  marketValue: integer('market_value').default(0), // euros
  videoLinks: text('video_links'),
  scoutedBy: text('scouted_by'),
  scoutedAt: date('scouted_at'),
  playerCode: text('player_code').unique(), // Unique identifier
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const insertScoutDatabaseSchema = createInsertSchema(scoutDatabase).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

// Types
export type YearPlan = typeof yearPlans.$inferSelect;
export type InsertYearPlan = z.infer<typeof insertYearPlanSchema>;
export type YearPlanPeriod = typeof yearPlanPeriods.$inferSelect;
export type InsertYearPlanPeriod = z.infer<typeof insertYearPlanPeriodSchema>;
export type YearPlanSession = typeof yearPlanSessions.$inferSelect;
export type InsertYearPlanSession = z.infer<typeof insertYearPlanSessionSchema>;
export type ScoutDatabase = typeof scoutDatabase.$inferSelect;
export type InsertScoutDatabase = z.infer<typeof insertScoutDatabaseSchema>;
