export const basicsDepth = {
  "LEIDEN_VAN_DE_BAL": {
    name: "Leiden van de bal",
    levels: [
      {
        id: "basic",
        name: "Eenvoudig bal leiden",
        description: "Basis bal leiden zonder druk",
        difficulty: 1
      },
      {
        id: "directed",
        name: "Gericht bal leiden",
        description: "Bal leiden in een specifieke richting",
        difficulty: 2
      },
      {
        id: "directed_fast",
        name: "Gericht bal snel bal leiden",
        description: "Snel en gericht bal leiden",
        difficulty: 3
      },
      {
        id: "blind_directed_fast",
        name: "Blind gericht snel bal leiden",
        description: "Snel gericht bal leiden zonder kijken",
        difficulty: 4
      },
      {
        id: "under_pressure_blind",
        name: "Onder Druk blind gericht snel bal leiden",
        description: "Onder druk blind gericht snel bal leiden",
        difficulty: 5
      },
      {
        id: "under_pressure_action",
        name: "Onder druk blind gericht snel bal leiden én actie",
        description: "Onder druk blind gericht snel bal leiden met vervolgactie",
        difficulty: 6
      }
    ]
  },
  "DRIBBELEN_MET_DE_BAL": {
    name: "Dribbelen met de bal",
    levels: [
      {
        id: "basic_tricks",
        name: "Eenvoudig dribbelen/Tricks",
        description: "Basis dribbelen en eenvoudige tricks",
        difficulty: 1
      },
      {
        id: "directed_tricks",
        name: "Gericht dribbelen/Tricks",
        description: "Dribbelen en tricks in een specifieke richting",
        difficulty: 2
      },
      {
        id: "directed_fast",
        name: "Gericht snel dribbelen",
        description: "Snel en gericht dribbelen",
        difficulty: 3
      },
      {
        id: "directed_fast_timing",
        name: "Gericht snel dribbelen op het juiste moment",
        description: "Snel dribbelen met perfecte timing",
        difficulty: 4
      },
      {
        id: "under_pressure",
        name: "Gericht snel dribbelen onder druk",
        description: "Snel dribbelen onder tegenstander druk",
        difficulty: 5
      },
      {
        id: "under_pressure_action",
        name: "Gericht snel dribbelen onder druk en actie",
        description: "Dribbelen onder druk met vervolgactie",
        difficulty: 6
      }
    ]
  },
  "KORTE_PASSING": {
    name: "Korte Passing",
    levels: [
      {
        id: "correct_direction",
        name: "Korte pass juiste richting",
        description: "Pass in de juiste richting spelen",
        difficulty: 1
      },
      {
        id: "inside_foot",
        name: "Korte pass binnenkant voet",
        description: "Pass met binnenkant voet uitvoeren",
        difficulty: 2
      },
      {
        id: "directed_pass",
        name: "Gerichte korte pass",
        description: "Doelgericht en precies passen",
        difficulty: 3
      },
      {
        id: "correct_foot",
        name: "Korte pass op de juiste voet",
        description: "Pass op de juiste voet van medespeler",
        difficulty: 4
      },
      {
        id: "correct_speed",
        name: "Korte pass op juiste snelheid",
        description: "Pass met juiste kracht en timing",
        difficulty: 5
      },
      {
        id: "in_stride_action",
        name: "Korte pass in de loop voor volgende actie",
        description: "Pass in de loop met vervolgactie mogelijk",
        difficulty: 6
      }
    ]
  },
  "MIDDELLANGE_PASSING": {
    name: "Middellange Passing",
    levels: [
      {
        id: "simple_medium",
        name: "Eenvoudige Middellange pass",
        description: "Basis middellange afstand pass",
        difficulty: 1
      },
      {
        id: "simple_medium_repeat",
        name: "Eenvoudige Middellange pass",
        description: "Herhaalde basis middellange pass",
        difficulty: 2
      },
      {
        id: "directed_medium",
        name: "Gerichte middellange pass",
        description: "Doelgerichte middellange pass",
        difficulty: 3
      },
      {
        id: "directed_medium_repeat",
        name: "Gerichte middellange pass",
        description: "Herhaalde gerichte middellange pass",
        difficulty: 4
      },
      {
        id: "perfect_medium",
        name: "Gerichte middellange pass op juiste voet op juiste snelheid",
        description: "Perfecte middellange pass met juiste timing",
        difficulty: 5
      },
      {
        id: "perfect_medium_action",
        name: "Gerichte middellange pass op juiste voet op juiste snelheid voor volgende actie",
        description: "Perfecte middellange pass met vervolgactie mogelijk",
        difficulty: 6
      }
    ]
  },
  "LANGE_PASSING": {
    name: "Lange Passing",
    levels: [
      {
        id: "directed_long",
        name: "Gerichte lange passing",
        description: "Basis gerichte lange afstand pass",
        difficulty: 1
      },
      {
        id: "directed_long_repeat",
        name: "Gerichte lange passing",
        description: "Herhaalde gerichte lange pass",
        difficulty: 2
      },
      {
        id: "long_speed_space",
        name: "Gerichte lange passing op juiste snelheid/ruimte",
        description: "Lange pass met juiste kracht naar ruimte",
        difficulty: 3
      },
      {
        id: "long_speed_space_repeat",
        name: "Gerichte lange passing op juiste snelheid/ruimte",
        description: "Herhaalde lange pass naar ruimte",
        difficulty: 4
      },
      {
        id: "long_timing_pressure",
        name: "Gerichte lange passing op juiste moment onder druk",
        description: "Lange pass met perfecte timing onder druk",
        difficulty: 5
      },
      {
        id: "long_switchplay_action",
        name: "Gerichte lange passing voor spelverplaatsing en actie",
        description: "Lange pass voor spelverplaatsing met vervolgactie",
        difficulty: 6
      }
    ]
  },
  "PASSING_MET_HET_HOOFD": {
    name: "Passing met het hoofd",
    levels: [
      {
        id: "simple_heading",
        name: "Eenvoudig koppen",
        description: "Basis kopbal techniek",
        difficulty: 1
      },
      {
        id: "directed_heading",
        name: "Gericht koppen",
        description: "Kopbal in gewenste richting",
        difficulty: 2
      },
      {
        id: "directed_heading_correct",
        name: "Gericht koppen in de juiste richting",
        description: "Precisie kopbal naar juiste richting",
        difficulty: 3
      },
      {
        id: "directed_heading_pressure",
        name: "Gericht koppen in de juiste richting onder druk",
        description: "Gerichte kopbal onder tegenstander druk",
        difficulty: 4
      },
      {
        id: "heading_pass_timing",
        name: "Koppen met juiste timing voor medespeler",
        description: "Kopbal pass met perfecte timing",
        difficulty: 5
      },
      {
        id: "heading_pass_action",
        name: "Koppen voor vervolgactie van medespeler",
        description: "Kopbal die vervolgactie mogelijk maakt",
        difficulty: 6
      }
    ]
  },
  "1_TIJD_PASSING_KAATSEN": {
    name: "1 tijd Passing/Kaatsen",
    levels: [
      {
        id: "bounce_short_direction",
        name: "Kaats korte passing juiste richting",
        description: "Korte kaats in de juiste richting",
        difficulty: 1
      },
      {
        id: "bounce_short_direction_repeat",
        name: "Kaats korte passing juiste richting",
        description: "Herhaalde korte kaats juiste richting",
        difficulty: 2
      },
      {
        id: "directed_bounce_short",
        name: "Gerichte Kaats korte passing gericht",
        description: "Doelgerichte korte kaats",
        difficulty: 3
      },
      {
        id: "directed_bounce_short_repeat",
        name: "Gerichte Kaats korte passing gericht",
        description: "Herhaalde doelgerichte korte kaats",
        difficulty: 4
      },
      {
        id: "bounce_correct_foot",
        name: "Gerichte Kaats korte passing op juiste voet",
        description: "Kaats op de juiste voet van medespeler",
        difficulty: 5
      },
      {
        id: "bounce_stride_action",
        name: "Gerichte kaats korte passing in de loop voor volgende actie",
        description: "Kaats in de loop met vervolgactie mogelijk",
        difficulty: 6
      }
    ]
  },
  "BALCONTROLE_KORTE_PASS": {
    name: "Balcontrole Korte Pass",
    levels: [
      {
        id: "simple_control_short",
        name: "Eenvoudige controle op korte pass",
        description: "Basis balcontrole op korte pass",
        difficulty: 1
      },
      {
        id: "control_inside_foot",
        name: "Controle binnenkant voet",
        description: "Balcontrole met binnenkant voet",
        difficulty: 2
      },
      {
        id: "directed_control_correct_foot",
        name: "Gerichte controle met juiste voet",
        description: "Controle met de juiste voet",
        difficulty: 3
      },
      {
        id: "directed_control_speed_stride",
        name: "Gerichte controle op snelheid/in de loop",
        description: "Controle op snelheid en in beweging",
        difficulty: 4
      },
      {
        id: "control_speed_stride_pressure",
        name: "Gerichte controle op snelheid/in de loop onder druk",
        description: "Controle in beweging onder tegenstander druk",
        difficulty: 5
      },
      {
        id: "control_pressure_action",
        name: "Gerichte controle op snelheid/in de loop onder druk voor volgende actie",
        description: "Controle onder druk met directe vervolgactie",
        difficulty: 6
      }
    ]
  },
  "BALCONTROLE_MIDDELLANGE_PASS": {
    name: "Balcontrole Middellange Pass",
    levels: [
      {
        id: "control_thigh_foot",
        name: "Controle juiste dij/voet",
        description: "Balcontrole met dij of voet",
        difficulty: 1
      },
      {
        id: "control_thigh_foot_repeat",
        name: "Controle juiste dij/voet",
        description: "Herhaalde controle dij/voet",
        difficulty: 2
      },
      {
        id: "directed_control_speed_stride",
        name: "Gerichte controle dij/voet op snelheid/in de loop",
        description: "Controle in beweging op snelheid",
        difficulty: 3
      },
      {
        id: "directed_control_speed_stride_repeat",
        name: "Gerichte controle dij/voet op snelheid/in de loop",
        description: "Herhaalde controle in beweging",
        difficulty: 4
      },
      {
        id: "control_speed_stride_pressure",
        name: "Gerichte controle dij/voet op snelheid/in de loop onder druk",
        description: "Controle in beweging onder tegenstander druk",
        difficulty: 5
      },
      {
        id: "control_pressure_action",
        name: "Gerichte controle dij/voet op snelheid/in de loop onder druk voor volgende actie",
        description: "Controle onder druk met directe vervolgactie",
        difficulty: 6
      }
    ]
  },
  "BALCONTROLE_LANGE_PASS": {
    name: "Balcontrole Lange Pass",
    levels: [
      {
        id: "control_chest_thigh_foot",
        name: "Controle borst/dij/voet",
        description: "Balcontrole met borst, dij of voet",
        difficulty: 1
      },
      {
        id: "control_chest_thigh_foot_repeat",
        name: "Controle borst/dij/voet",
        description: "Herhaalde controle met verschillende lichaamsdelen",
        difficulty: 2
      },
      {
        id: "directed_control_stride",
        name: "Gerichte controle borst/dij/juiste voet in de loop",
        description: "Gerichte controle in beweging",
        difficulty: 3
      },
      {
        id: "directed_control_stride_repeat",
        name: "Gerichte controle borst/dij/juiste voet in de loop",
        description: "Herhaalde gerichte controle in beweging",
        difficulty: 4
      },
      {
        id: "control_stride_action",
        name: "Gerichte controle borst/dij/juiste voet in de loop voor volgende actie",
        description: "Controle in beweging met directe vervolgactie",
        difficulty: 5
      },
      {
        id: "control_stride_action_pressure",
        name: "Gerichte controle borst/dij/juiste voet in de loop voor volgende actie onder druk",
        description: "Controle in beweging met vervolgactie onder tegenstander druk",
        difficulty: 6
      }
    ]
  },
  "SCHIETEN_OP_DOEL": {
    name: "Schieten op doel",
    levels: [
      {
        id: "simple_shooting",
        name: "Eenvoudig schieten op doel",
        description: "Basis schot op doel",
        difficulty: 1
      },
      {
        id: "directed_shooting",
        name: "Gericht Schieten op doel",
        description: "Doelgericht schieten",
        difficulty: 2
      },
      {
        id: "directed_correct_foot",
        name: "Gericht en met juiste voet schieten",
        description: "Gericht schieten met juiste voet",
        difficulty: 3
      },
      {
        id: "fast_directed_correct_foot",
        name: "Snel gericht en met juiste voet schieten",
        description: "Snel en doelgericht schieten",
        difficulty: 4
      },
      {
        id: "pressure_fast_directed",
        name: "Onder druk snel en gericht schieten met juiste voet",
        description: "Schieten onder tegenstander druk",
        difficulty: 5
      },
      {
        id: "pressure_fast_directed_follow",
        name: "Onder druk snel en gericht schieten met juiste voet en navolgen",
        description: "Schieten onder druk met navolgen van bal",
        difficulty: 6
      }
    ]
  },
  "SCOREN_MET_DE_VOET": {
    name: "Scoren met de voet",
    levels: [
      {
        id: "simple_scoring",
        name: "Eenvoudig scoren",
        description: "Basis score met de voet",
        difficulty: 1
      },
      {
        id: "scoring_instep",
        name: "Scoren met de wreef",
        description: "Scoren met wreef techniek",
        difficulty: 2
      },
      {
        id: "directed_scoring_instep",
        name: "Gericht scoren met de wreef",
        description: "Doelgericht scoren met wreef",
        difficulty: 3
      },
      {
        id: "fast_directed_correct_instep",
        name: "Snel gericht scoren met de juiste wreef",
        description: "Snel en doelgericht scoren met juiste voet",
        difficulty: 4
      },
      {
        id: "fast_directed_pressure_instep",
        name: "Snel gericht onder druk scoren met de juiste wreef",
        description: "Scoren onder tegenstander druk",
        difficulty: 5
      },
      {
        id: "scoring_after_individual_action",
        name: "Scoren na indiv.actie (Dribbel/Intensity Run) onder druk met de juiste wreef",
        description: "Scoren na individuele actie onder druk",
        difficulty: 6
      }
    ]
  },
  "SCOREN_MET_HET_HOOFD": {
    name: "Scoren met het hoofd",
    levels: [
      {
        id: "simple_heading_score",
        name: "Eenvoudig scoren met het hoofd",
        description: "Basis score met het hoofd",
        difficulty: 1
      },
      {
        id: "simple_heading_score_repeat",
        name: "Eenvoudig scoren met het hoofd",
        description: "Herhaalde basis score met het hoofd",
        difficulty: 2
      },
      {
        id: "directed_heading_score",
        name: "Gericht scoren met het hoofd",
        description: "Doelgericht koppen naar goal",
        difficulty: 3
      },
      {
        id: "directed_heading_score_repeat",
        name: "Gericht scoren met het hoofd",
        description: "Herhaald doelgericht koppen",
        difficulty: 4
      },
      {
        id: "directed_heading_pressure_position",
        name: "Gericht scoren met het hoofd onder druk/positie voor doel innemend/detente",
        description: "Koppen onder druk met juiste positionering",
        difficulty: 5
      },
      {
        id: "directed_heading_pressure_position_timing",
        name: "Gericht scoren met het hoofd onder druk/positie voor doel innemend/detente met perfecte timing",
        description: "Koppen onder druk met perfecte timing en positionering",
        difficulty: 6
      }
    ]
  },
  "SCOREN_NA_INDIVIDUELE_ACTIE_TRUCKS": {
    name: "Scoren na individuele actie/trucks",
    levels: [
      {
        id: "trick_simple_scoring",
        name: "Trick + Eenvoudig scoren",
        description: "Trick gevolgd door eenvoudig scoren",
        difficulty: 1
      },
      {
        id: "trick_scoring_instep",
        name: "Trick + Scoren met de wreef",
        description: "Trick gevolgd door scoren met wreef",
        difficulty: 2
      },
      {
        id: "trick_directed_scoring_instep",
        name: "Trick+Gericht scoren met de wreef",
        description: "Trick gevolgd door gericht scoren met wreef",
        difficulty: 3
      },
      {
        id: "trick_fast_directed_correct_instep",
        name: "Trick+Snel gericht scoren met de juiste wreef",
        description: "Trick gevolgd door snel gericht scoren",
        difficulty: 4
      },
      {
        id: "trick_fast_directed_pressure_instep",
        name: "Trick+Snel gericht onder druk scoren met de juiste wreef",
        description: "Trick gevolgd door scoren onder druk",
        difficulty: 5
      },
      {
        id: "individual_action_pressure_scoring",
        name: "Scoren na indiv.actie (Dribbel/Intensity Run) onder druk met de juiste wreef",
        description: "Complete individuele actie onder druk met scoren",
        difficulty: 6
      }
    ]
  },
  "VRIJLOPEN_AANSPEELBAAR_ZIJN": {
    name: "Vrijlopen - Aanspeelbaar zijn",
    levels: [
      {
        id: "simple_available_scan",
        name: "Eenvoudig aanspeelbaar zijn + scan",
        description: "Basis aanspeelbaar zijn met scannen",
        difficulty: 1
      },
      {
        id: "always_available_scan",
        name: "Altijd aanspeelbaar zijn+scan",
        description: "Constant aanspeelbaar zijn met scannen",
        difficulty: 2
      },
      {
        id: "fast_available_scan",
        name: "Snel aanspeelbaar zijn+scan",
        description: "Snel positioneren en scannen",
        difficulty: 3
      },
      {
        id: "fast_available_pressure_scan",
        name: "Snel aanspeelbaar zijn onder druk+scan",
        description: "Snel positioneren onder druk met scannen",
        difficulty: 4
      },
      {
        id: "fast_available_pressure_next_action_scan",
        name: "Snel aanspeelbaar zijn onder druk en met oog op volgende actie+scan",
        description: "Anticiperen op vervolgactie onder druk",
        difficulty: 5
      },
      {
        id: "advanced_positioning_scan",
        name: "Optimaal aanspeelbaar zijn onder druk met perfecte anticipatie+scan",
        description: "Geavanceerd positioneren met perfecte timing en scannen",
        difficulty: 6
      }
    ]
  },
  "GOED_INGEDRAAID_STAAN": {
    name: "Goed ingedraaid staan",
    levels: [
      {
        id: "simple_proper_positioning_scan",
        name: "Eenvoudig goed ingedraaid staan + SCAN",
        description: "Basis juiste lichaamshouding met scannen",
        difficulty: 1
      },
      {
        id: "always_proper_positioning_scan",
        name: "Altijd goed ingedraaid staan + SCAN",
        description: "Constant juiste positionering met scannen",
        difficulty: 2
      },
      {
        id: "proper_positioning_correct_foot_scan",
        name: "Altijd goed ingedraaid staan op juiste voet + SCAN",
        description: "Juiste positionering op juiste voet met scannen",
        difficulty: 3
      },
      {
        id: "fast_proper_positioning_correct_foot_scan",
        name: "Snel altijd goed ingedraaid staan op juiste voet + SCAN",
        description: "Snelle juiste positionering met scannen",
        difficulty: 4
      },
      {
        id: "fast_proper_positioning_pressure_scan",
        name: "Snel altijd goed ingedraaid staan op juiste voet onder druk + SCAN",
        description: "Snelle positionering onder druk met scannen",
        difficulty: 5
      },
      {
        id: "fast_proper_positioning_pressure_next_action_scan",
        name: "Snel altijd goed ingedraaid staan op juiste voet onder druk met oog op volgende actie + SCAN",
        description: "Perfecte positionering onder druk met anticipatie",
        difficulty: 6
      }
    ]
  },
  "STEUN_JE_TEAMGENOOT": {
    name: "Steun je teamgenoot",
    levels: [
      {
        id: "simple_support_ask_ball",
        name: "Eenvoudig steunen & bal vragen",
        description: "Basis ondersteuning en bal vragen",
        difficulty: 1
      },
      {
        id: "always_support_ask_ball",
        name: "Altijd steunen & bal vragen",
        description: "Constant ondersteuning bieden",
        difficulty: 2
      },
      {
        id: "directed_support_ask_ball",
        name: "Gericht steunen & bal vragen",
        description: "Doelgerichte ondersteuning",
        difficulty: 3
      },
      {
        id: "fast_directed_support_ask_ball",
        name: "Snel Gericht steunen & bal vragen",
        description: "Snelle doelgerichte ondersteuning",
        difficulty: 4
      },
      {
        id: "fast_directed_support_pressure",
        name: "Snel Gericht steunen & bal vragen wanneer ploegmaat onder druk staat",
        description: "Ondersteuning wanneer teamgenoot onder druk staat",
        difficulty: 5
      },
      {
        id: "fast_directed_support_pressure_next_action",
        name: "Snel Gericht steunen & bal vragen wanneer ploegmaat onder druk staat met oog op volgende actie",
        description: "Ondersteuning onder druk met anticipatie op vervolgactie",
        difficulty: 6
      }
    ]
  },
  // BASICS B- (Silver) Elements - To be filled with detailed levels
  "DRUK_ZETTEN_TACKLE_REMMEN": {
    name: "1: 1 Druk zetten/Tackle/Remmen",
    levels: [
      {
        id: "simple_pressure",
        name: "Eenvoudig druk zetten",
        description: "Basis druk zetten op tegenstander",
        difficulty: 1
      },
      {
        id: "directed_pressure_tackle",
        name: "Gericht druk zetten/Tackle/Remmend wijken",
        description: "Doelgericht druk zetten met tackling optie",
        difficulty: 2
      },
      {
        id: "fast_directed_pressure_tackle",
        name: "Gericht en snel druk zetten/Tackle/Remmend Wijken",
        description: "Snelle en gerichte druk met tactische keuzes",
        difficulty: 3
      },
      {
        id: "pressure_equal_numbers",
        name: "Gericht en snel druk zetten/Tackle/Remmend Wijken in gelijke aantallen",
        description: "Druk zetten in gelijke situaties",
        difficulty: 4
      },
      {
        id: "pressure_outnumbered",
        name: "Gericht en snel druk zetten/Tackle/Remmend Wijken in ondertal",
        description: "Druk zetten wanneer in numeriek ondertal",
        difficulty: 5
      },
      {
        id: "pressure_outnumbered_ball_recovery",
        name: "Gericht en snel druk zetten/Tackle/Remmend Wijken in ondertal + bal veroveren + goed inspelen",
        description: "Complete verdedigende actie in ondertal met balverovering",
        difficulty: 6
      }
    ]
  },
  "DUEL": {
    name: "Duel",
    levels: [
      {
        id: "simple_duels",
        name: "Eenvoudige Duels",
        description: "Basis duel situaties",
        difficulty: 1
      },
      {
        id: "directed_duels",
        name: "Gerichte Duels",
        description: "Doelgerichte duel acties",
        difficulty: 2
      },
      {
        id: "fast_directed_duels",
        name: "Gericht en snelle Duels",
        description: "Snelle en gerichte duels",
        difficulty: 3
      },
      {
        id: "duels_tactical_choice",
        name: "Gericht en snelle Duels ifv keuze Duel/Remmend Wijken",
        description: "Duels met tactische keuzemogelijkheden",
        difficulty: 4
      },
      {
        id: "duels_equal_numbers_play",
        name: "Gericht en snelle Duels ifv keuze Duel/Remmend Wijken/Gelijke Aantal + goed inspelen",
        description: "Duels in gelijke aantallen met goed inspelen",
        difficulty: 5
      },
      {
        id: "duels_outnumbered_play",
        name: "Gericht en snelle Duels ifv keuze Duel/Remmend Wijken/Ondertal + goed inspelen",
        description: "Duels in ondertal met effectief inspelen",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE_BALCONTROLE_KORTE_PASSING": {
    name: "Interceptie voor balcontrole op korte passing",
    levels: [
      {
        id: "simple_intercept_low_pass",
        name: "Eenvoudig Onderscheppen op lage pass",
        description: "Basis onderscheppen van lage passes",
        difficulty: 1
      },
      {
        id: "directed_intercept_low_pass",
        name: "Gericht Onderscheppen vd bal op lage pass",
        description: "Doelgericht onderscheppen van lage passes",
        difficulty: 2
      },
      {
        id: "directed_intercept_play",
        name: "Gericht Onderscheppen op lage pass en goed inspelen",
        description: "Onderscheppen met effectief doorspelen",
        difficulty: 3
      },
      {
        id: "intercept_multiple_options_play",
        name: "Gericht Onderscheppen op lage pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Onderscheppen in complexe situaties",
        difficulty: 4
      },
      {
        id: "fast_intercept_multiple_options",
        name: "Snel Gericht Onderscheppen op lage pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Snelle interceptie in complexe situaties",
        difficulty: 5
      },
      {
        id: "pressure_fast_intercept_options",
        name: "Onder Druk Snel Gericht Onderscheppen op lage pass(met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Interceptie onder druk in complexe situaties",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE_BALCONTROLE_MIDDELLANGE_PASSING": {
    name: "Interceptie voor balcontrole op middellange passing",
    levels: [
      {
        id: "basic_mid_pass_awareness",
        name: "Basis bewustzijn middellange pass",
        description: "Bewustwording van middellange pass mogelijkheden",
        difficulty: 1
      },
      {
        id: "simple_intercept_mid_pass",
        name: "Eenvoudig Onderscheppen op middellange pass",
        description: "Basis onderscheppen middellange passes",
        difficulty: 2
      },
      {
        id: "directed_intercept_mid_pass",
        name: "Gericht Onderscheppen vd bal op middellange pass",
        description: "Doelgericht onderscheppen middellange passes",
        difficulty: 3
      },
      {
        id: "directed_intercept_mid_pass_play",
        name: "Gericht Onderscheppen op middellange pass en goed inspelen",
        description: "Onderscheppen met effectief doorspelen",
        difficulty: 4
      },
      {
        id: "intercept_mid_pass_multiple_options",
        name: "Gericht Onderscheppen op middellange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Onderscheppen in complexe situaties",
        difficulty: 5
      },
      {
        id: "fast_intercept_mid_pass_options",
        name: "Snel Gericht Onderscheppen op middellange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Snelle interceptie middellange passes",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE_BALCONTROLE_LANGE_PASSING": {
    name: "Interceptie voor balcontrole op lange passing",
    levels: [
      {
        id: "basic_long_pass_awareness",
        name: "Basis bewustzijn lange pass",
        description: "Bewustwording van lange pass mogelijkheden",
        difficulty: 1
      },
      {
        id: "developing_long_pass_skills",
        name: "Ontwikkeling lange pass vaardigheden",
        description: "Opbouw van lange pass interceptie skills",
        difficulty: 2
      },
      {
        id: "understanding_long_pass_patterns",
        name: "Begrijpen lange pass patronen",
        description: "Herkenning van lange pass patronen",
        difficulty: 3
      },
      {
        id: "directed_intercept_long_pass_play",
        name: "Gericht Onderscheppen op lange pass en goed inspelen",
        description: "Onderscheppen lange passes met doorspelen",
        difficulty: 4
      },
      {
        id: "fast_intercept_long_pass_options",
        name: "Snel Gericht Onderscheppen op lange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Snelle interceptie lange passes",
        difficulty: 5
      },
      {
        id: "pressure_intercept_long_pass",
        name: "Onder Druk Snel Gericht Onderscheppen op lange pass(met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Interceptie lange passes onder druk",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE_BALCONTROLE_KOPBAL": {
    name: "Interceptie voor balcontrole op kopbal",
    levels: [
      {
        id: "basic_heading_awareness",
        name: "Basis kopbal bewustzijn",
        description: "Bewustwording van kopbal situaties",
        difficulty: 1
      },
      {
        id: "developing_heading_skills",
        name: "Ontwikkeling kopbal vaardigheden",
        description: "Opbouw van kopbal interceptie skills",
        difficulty: 2
      },
      {
        id: "understanding_heading_patterns",
        name: "Begrijpen kopbal patronen",
        description: "Herkenning van kopbal situaties",
        difficulty: 3
      },
      {
        id: "simple_heading_duel",
        name: "Eenvoudig Kopduel",
        description: "Basis kopduel uitvoering",
        difficulty: 4
      },
      {
        id: "heading_duel_movement",
        name: "Kopduel in de loop",
        description: "Kopduel tijdens beweging",
        difficulty: 5
      },
      {
        id: "heading_duel_pressure",
        name: "Kopduel in de loop + onder druk",
        description: "Kopduel onder druk tijdens beweging",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE_BALCONTROLE_KAATSBAL": {
    name: "Interceptie voor balcontrole op kaatsbal",
    levels: [
      {
        id: "basic_rebound_awareness",
        name: "Basis kaatsbal bewustzijn",
        description: "Bewustwording van kaatsbal situaties",
        difficulty: 1
      },
      {
        id: "pressure_rebound_player",
        name: "Kaatser onder druk zetten",
        description: "Druk zetten op kaatsende speler",
        difficulty: 2
      },
      {
        id: "pressure_anticipate_rebound",
        name: "Kaatser onder druk zetten + anticiperen op de kaats",
        description: "Druk zetten met anticipatie op kaats",
        difficulty: 3
      },
      {
        id: "pressure_choice_recover_evade",
        name: "Kaatser onder druk zetten+ anticiperen op de kaats + keuze bal veroveren/wijken",
        description: "Tactische keuzes bij kaatsbal",
        difficulty: 4
      },
      {
        id: "fast_pressure_choice_rebound",
        name: "Kaatser onder druk zetten+ anticiperen op de kaats + keuze bal veroveren/wijken SNEL HANDELEN",
        description: "Snelle tactische keuzes bij kaatsbal",
        difficulty: 5
      },
      {
        id: "pressure_fast_choice_play",
        name: "Kaatser onder druk zetten+ anticiperen op de kaats + keuze bal veroveren/wijken SNEL HANDELEN + goed inspelen",
        description: "Complete kaatsbal interceptie met doorspelen",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE_NA_BALCONTROLE_KORTE_PASS": {
    name: "Interceptie na balcontrole korte pass",
    levels: [
      {
        id: "basic_post_control_awareness",
        name: "Basis bewustzijn na balcontrole",
        description: "Bewustwording van mogelijkheden na balcontrole",
        difficulty: 1
      },
      {
        id: "attempt_intercept_control",
        name: "Trachten te onderscheppen na controle lage pass",
        description: "Poging tot onderscheppen na balcontrole",
        difficulty: 2
      },
      {
        id: "intercept_avoid_elimination",
        name: "Trachten te onderscheppen na controle lage pass + niet laten uitschakelen",
        description: "Onderscheppen zonder uitgeschakeld te worden",
        difficulty: 3
      },
      {
        id: "directed_intercept_control",
        name: "Gericht Onderscheppen vd bal op controle lage pass",
        description: "Doelgericht onderscheppen na balcontrole",
        difficulty: 4
      },
      {
        id: "directed_intercept_control_multiple_options",
        name: "Gericht Onderscheppen op controle lage pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Onderscheppen in complexe situaties na controle",
        difficulty: 5
      },
      {
        id: "fast_directed_intercept_control_options",
        name: "Snel Gericht Onderscheppen op controle lage pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Snelle interceptie na balcontrole",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE_NA_BALCONTROLE_MIDDELLANGE_PASS": {
    name: "Interceptie na balcontrole middellange pass",
    levels: [
      {
        id: "basic_mid_control_awareness",
        name: "Basis bewustzijn middellange controle",
        description: "Bewustwording van middellange pass controle",
        difficulty: 1
      },
      {
        id: "developing_mid_control_skills",
        name: "Ontwikkeling middellange controle vaardigheden",
        description: "Opbouw vaardigheden middellange pass interceptie",
        difficulty: 2
      },
      {
        id: "attempt_intercept_mid_control_avoid_elimination",
        name: "Trachten te onderscheppen na controle middellange pass + niet laten uitschakelen",
        description: "Onderscheppen na middellange pass controle",
        difficulty: 3
      },
      {
        id: "directed_intercept_mid_control_multiple_options",
        name: "Gericht Onderscheppen op controle middellange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Onderscheppen na middellange controle in complexe situaties",
        difficulty: 4
      },
      {
        id: "fast_directed_intercept_mid_control_options",
        name: "Snel Gericht Onderscheppen op controle middellange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Snelle interceptie na middellange controle",
        difficulty: 5
      },
      {
        id: "pressure_fast_intercept_mid_control",
        name: "Onder Druk Snel Gericht Onderscheppen op controle middellange pass(met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Interceptie onder druk na middellange controle",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE_NA_BALCONTROLE_LANGE_PASS": {
    name: "Interceptie na balcontrole lange pass",
    levels: [
      {
        id: "basic_long_control_awareness",
        name: "Basis bewustzijn lange controle",
        description: "Bewustwording van lange pass controle",
        difficulty: 1
      },
      {
        id: "developing_long_control_skills",
        name: "Ontwikkeling lange controle vaardigheden",
        description: "Opbouw vaardigheden lange pass interceptie",
        difficulty: 2
      },
      {
        id: "understanding_long_control_patterns",
        name: "Begrijpen lange controle patronen",
        description: "Herkenning van lange pass controle situaties",
        difficulty: 3
      },
      {
        id: "directed_intercept_long_control_multiple_options",
        name: "Gericht Onderscheppen op controle lange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Onderscheppen na lange controle in complexe situaties",
        difficulty: 4
      },
      {
        id: "fast_directed_intercept_long_control_options",
        name: "Snel Gericht Onderscheppen op controle lange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen",
        description: "Snelle interceptie na lange controle",
        difficulty: 5
      },
      {
        id: "pressure_fast_intercept_long_control_multiple",
        name: "Snel Gericht Onderscheppen op controle lange pass (met meerdere aanspeelmogelijkheden voor tegenstrever)+goed inspelen onder druk",
        description: "Interceptie onder druk na lange controle",
        difficulty: 6
      }
    ]
  },
  "AFWEREN_SCHIETEN_BELETTEN": {
    name: "Afweren/Schieten op doel beletten",
    levels: [
      {
        id: "simple_block_shooting",
        name: "Eenvoudig afweren/schieten op doel beletten",
        description: "Basis blokkeren van schoten",
        difficulty: 1
      },
      {
        id: "directed_block_shooting",
        name: "Gericht afweren/schieten op doel beletten",
        description: "Doelgericht blokkeren van schoten",
        difficulty: 2
      },
      {
        id: "fast_directed_block_shooting",
        name: "Snel en Gericht afweren/schieten op doel beletten",
        description: "Snelle en gerichte blokkering",
        difficulty: 3
      },
      {
        id: "block_shooting_equal_numbers",
        name: "Snel/Gericht afweren/schieten op doel beletten in gelijke aantallen",
        description: "Blokkeren in gelijke situaties",
        difficulty: 4
      },
      {
        id: "block_shooting_outnumbered",
        name: "Snel/Gericht afweren/schieten op doel beletten in ondertal",
        description: "Blokkeren in numeriek ondertal",
        difficulty: 5
      },
      {
        id: "block_shooting_outnumbered_recover",
        name: "Snel/Gericht afweren/schieten op doel beletten in ondertal + bal veroveren + goed inspelen",
        description: "Complete verdedigende actie met balverovering",
        difficulty: 6
      }
    ]
  },
  "AFWEREN_SCOREN_VOET_BELETTEN": {
    name: "Afweren/Scoren met de voet beletten",
    levels: [
      {
        id: "simple_block_foot_scoring",
        name: "Eenvoudig afweren/scoren met voet beletten",
        description: "Basis blokkeren van voetscores",
        difficulty: 1
      },
      {
        id: "directed_block_foot_scoring",
        name: "Gericht afweren/scoren met voet beletten",
        description: "Doelgericht blokkeren van voetscores",
        difficulty: 2
      },
      {
        id: "fast_directed_block_foot_scoring",
        name: "Snel en Gericht afweren/scoren met voet beletten",
        description: "Snelle en gerichte blokkering voetscores",
        difficulty: 3
      },
      {
        id: "block_foot_scoring_equal_numbers",
        name: "Snel/Gericht afweren/scoren met voet beletten in gelijke aantallen",
        description: "Blokkeren voetscores in gelijke situaties",
        difficulty: 4
      },
      {
        id: "block_foot_scoring_outnumbered",
        name: "Snel/Gericht afweren/scoren met voet beletten in ondertal",
        description: "Blokkeren voetscores in ondertal",
        difficulty: 5
      },
      {
        id: "block_foot_scoring_outnumbered_recover",
        name: "Snel/Gericht afweren/scoren met voet beletten in ondertal + bal veroveren + goed inspelen",
        description: "Complete verdediging voetscores met balverovering",
        difficulty: 6
      }
    ]
  },
  "AFWEREN_SCOREN_HOOFD_BELETTEN": {
    name: "Afweren/Scoren met het hoofd beletten",
    levels: [
      {
        id: "basic_heading_defense_awareness",
        name: "Basis kopdoel verdediging bewustzijn",
        description: "Bewustwording van kopdoel verdediging",
        difficulty: 1
      },
      {
        id: "developing_heading_defense_skills",
        name: "Ontwikkeling kopdoel verdediging",
        description: "Opbouw kopdoel verdediging vaardigheden",
        difficulty: 2
      },
      {
        id: "understanding_heading_defense_patterns",
        name: "Begrijpen kopdoel verdediging patronen",
        description: "Herkenning van kopdoel verdediging situaties",
        difficulty: 3
      },
      {
        id: "fast_directed_block_heading",
        name: "Snel en Gericht afweren/koppen op doel beletten",
        description: "Snelle en gerichte kopdoel verdediging",
        difficulty: 4
      },
      {
        id: "block_heading_keep_possession",
        name: "Snel en Gericht afweren/koppen op doel beletten + trachten de bal in de ploeg te houden of safe",
        description: "Kopdoel verdediging met balcontrole",
        difficulty: 5
      },
      {
        id: "advanced_heading_defense_possession",
        name: "Geavanceerde kopdoel verdediging met optimale balcontrole",
        description: "Expertkopdoel verdediging met perfecte balcontrole",
        difficulty: 6
      }
    ]
  },
  "AFWEREN_SCOREN_INDIVIDUELE_ACTIE_BELETTEN": {
    name: "Afweren/Scoren na invididuele actie/tricks beletten",
    levels: [
      {
        id: "simple_block_tricks",
        name: "Eenvoudig beletten van tricks",
        description: "Basis blokkeren van tricks",
        difficulty: 1
      },
      {
        id: "directed_block_tricks",
        name: "Gericht beletten van tricks",
        description: "Doelgericht blokkeren van tricks",
        difficulty: 2
      },
      {
        id: "fast_directed_block_tricks",
        name: "Snel en Gericht beletten van tricks",
        description: "Snelle en gerichte trick verdediging",
        difficulty: 3
      },
      {
        id: "block_tricks_recover_ball",
        name: "Snel en gericht beletten van tricks + bal veroveren",
        description: "Trick verdediging met balverovering",
        difficulty: 4
      },
      {
        id: "block_tricks_recover_play",
        name: "Snel en gericht beletten van tricks + bal veroveren+ goed inspelen",
        description: "Complete trick verdediging met doorspelen",
        difficulty: 5
      },
      {
        id: "block_tricks_outnumbered_play",
        name: "Snel en gericht beletten van tricks + bal veroveren+ goed inspelen (in ondertal)",
        description: "Trick verdediging in ondertal met doorspelen",
        difficulty: 6
      }
    ]
  },
  "SPEELHOEKEN_AFSLUITEN": {
    name: "Speelhoeken afsluiten",
    levels: [
      {
        id: "basic_angle_awareness",
        name: "Basis speelhoek bewustzijn",
        description: "Bewustwording van speelhoeken",
        difficulty: 1
      },
      {
        id: "close_simple_angles",
        name: "Poortje Dicht houden",
        description: "Eenvoudige speelhoeken afsluiten",
        difficulty: 2
      },
      {
        id: "zone_coverage_angles",
        name: "Poortjes Dicht houden/Zonedekking",
        description: "Zonale speelhoek dekking",
        difficulty: 3
      },
      {
        id: "fast_zone_coverage_teammates",
        name: "Snel Poortjes Dicht houden/Zonedekking ifv andere medespelers",
        description: "Snelle zonale dekking met teamcoördinatie",
        difficulty: 4
      },
      {
        id: "zone_coverage_ball_recovery_equal",
        name: "Snel Poortjes Dicht houden/Zonedekking ifv andere medespelers + balveroveren + goed inspelen (gelijke aantallen)",
        description: "Zonale dekking met balverovering in gelijke situaties",
        difficulty: 5
      },
      {
        id: "zone_coverage_ball_recovery_outnumbered",
        name: "Snel Poortjes Dicht houden/Zonedekking ifv andere medespelers + balveroveren + goed inspelen (ondertal)",
        description: "Zonale dekking met balverovering in ondertal",
        difficulty: 6
      }
    ]
  },
  "STRIKTE_DEKKING": {
    name: "Strikte dekking",
    levels: [
      {
        id: "basic_marking_awareness",
        name: "Basis dekking bewustzijn",
        description: "Bewustwording van dekking principes",
        difficulty: 1
      },
      {
        id: "simple_proper_positioning_scan",
        name: "Eenvoudig goed ingedraaid staan + SCAN",
        description: "Basis juiste positionering met scannen",
        difficulty: 2
      },
      {
        id: "always_proper_positioning_scan",
        name: "Altijd goed ingedraaid staan + SCAN",
        description: "Constant juiste positionering met scannen",
        difficulty: 3
      },
      {
        id: "proper_positioning_correct_foot_scan",
        name: "Altijd goed ingedraaid staan op juiste voet + SCAN",
        description: "Juiste positionering op juiste voet",
        difficulty: 4
      },
      {
        id: "fast_proper_positioning_scan",
        name: "Snel altijd goed ingedraaid staan op juiste voet + SCAN",
        description: "Snelle juiste positionering",
        difficulty: 5
      },
      {
        id: "fast_positioning_pressure_next_action_scan",
        name: "Snel altijd goed ingedraaid staan op juiste voet onder druk met oog op volgende actie + SCAN",
        description: "Perfecte positionering onder druk met anticipatie",
        difficulty: 6
      }
    ]
  },
  "RUGDEKKING": {
    name: "Rugdekking",
    levels: [
      {
        id: "basic_cover_awareness",
        name: "Basis rugdekking bewustzijn",
        description: "Bewustwording van rugdekking principes",
        difficulty: 1
      },
      {
        id: "simple_cover",
        name: "Eenvoudig rugdekking geven",
        description: "Basis rugdekking uitvoering",
        difficulty: 2
      },
      {
        id: "cover_block_passing_lanes",
        name: "Eenvoudig rugdekking geven + paslijnen belemmeren",
        description: "Rugdekking met paslijnen blokkeren",
        difficulty: 3
      },
      {
        id: "directed_cover_block_passing_lanes",
        name: "Gericht Rugdekking geven + paslijnen belemmeren",
        description: "Doelgerichte rugdekking met paslijn controle",
        difficulty: 4
      },
      {
        id: "always_directed_cover_passing_lanes",
        name: "Altijd Gericht Rugdekkin geven + paslijnen belemmeren",
        description: "Constant gerichte rugdekking",
        difficulty: 5
      },
      {
        id: "directed_cover_outnumbered_switch",
        name: "Altijd gerichte rugdekking geven in ondertal, klaar om over te schakelen",
        description: "Rugdekking in ondertal met schakelbereidheid",
        difficulty: 6
      }
    ]
  }
};

export type DepthLevel = {
  id: string;
  name: string;
  description: string;
  difficulty: number;
};

export type BasicElement = {
  name: string;
  levels: DepthLevel[];
};