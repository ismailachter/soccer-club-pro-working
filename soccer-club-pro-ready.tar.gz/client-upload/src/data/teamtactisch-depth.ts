export const teamtactischDepth = {
  // TEAMTACTISCH B+ OPBOUWEN Elements
  "CREEER_RUIMTE": {
    name: "Creeer ruimte",
    levels: [
      {
        id: "basic_movement",
        name: "Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing",
        description: "Basis vrijlopen en bal controle",
        difficulty: 1
      },
      {
        id: "improved_movement",
        name: "Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing",
        description: "Verbeterde beweging en balcontrole",
        difficulty: 2
      },
      {
        id: "quick_movement",
        name: "Snel Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing",
        description: "Snelle bewegingen en passing",
        difficulty: 3
      },
      {
        id: "quick_focused_movement",
        name: "Snel Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing",
        description: "Snelle en gerichte bewegingen",
        difficulty: 4
      },
      {
        id: "numerical_advantage",
        name: "Snel en Gericht Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing MEERDERHEIDSSITUATIE",
        description: "Spelen met numeriek voordeel",
        difficulty: 5
      },
      {
        id: "equal_numbers_pressure",
        name: "Snel en Gericht Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing ONDERAANTAL+HOGE DRUK",
        description: "Spelen in ondertal met hoge druk",
        difficulty: 6
      }
    ]
  },
  "CREEER_HOOGTE_DIEPTE": {
    name: "Creeer hoogte, diepte",
    levels: [
      {
        id: "basic_high_movement",
        name: "Hoog vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing",
        description: "Basis hoog vrijlopen en bal controle",
        difficulty: 1
      },
      {
        id: "improved_high_movement",
        name: "Hoog vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing",
        description: "Verbeterde hoge beweging en balcontrole",
        difficulty: 2
      },
      {
        id: "quick_high_movement",
        name: "Snel Hoog Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing",
        description: "Snelle hoge bewegingen en passing",
        difficulty: 3
      },
      {
        id: "quick_focused_high_movement",
        name: "Snel Hoog Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing",
        description: "Snelle en gerichte hoge bewegingen",
        difficulty: 4
      },
      {
        id: "numerical_advantage_high",
        name: "Snel en Gericht Hoog vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing MEERDERHEIDSSITUATIE",
        description: "Hoog spelen met numeriek voordeel",
        difficulty: 5
      },
      {
        id: "disadvantage_high_pressure",
        name: "Snel en Gericht Hoog Vrijlopen-Goed Ingedraaid-Staan-Controle Lage Ball- Korte Passing ONDERAANTAL+HOGE DRUK",
        description: "Hoog spelen in ondertal met hoge druk",
        difficulty: 6
      }
    ]
  },
  "CREEER_MEERDERHEIDSSITUATIES": {
    name: "Creeer meerderheidssituaties",
    levels: [
      {
        id: "majority_situation_1",
        name: "Steunen + Aanspeelbaar zijn + Goed Ingedraaid MEERDERHEIDSSITUATIE",
        description: "Basis ondersteuning in numerieke meerderheid",
        difficulty: 1
      },
      {
        id: "majority_situation_2",
        name: "Steunen + Aanspeelbaar zijn + Goed Ingedraaid MEERDERHEIDSSITUATIE",
        description: "Verbeterde ondersteuning in numerieke meerderheid",
        difficulty: 2
      },
      {
        id: "equal_numbers_1",
        name: "Steunen + Aanspeelbaar zijn + Goed Ingedraaid GELIJKE AANTALLEN",
        description: "Ondersteuning bij gelijke aantallen spelers",
        difficulty: 3
      },
      {
        id: "equal_numbers_2",
        name: "Steunen + Aanspeelbaar zijn + Goed Ingedraaid GELIJKE AANTALLEN",
        description: "Geavanceerde ondersteuning bij gelijke aantallen",
        difficulty: 4
      },
      {
        id: "underdog_situation",
        name: "Steunen + Aanspeelbaar zijn + Goed Ingedraaid ONDERTAL",
        description: "Ondersteuning in numeriek ondertal",
        difficulty: 5
      },
      {
        id: "underdog_high_pressure",
        name: "Steunen + Aanspeelbaar zijn + Goed Ingedraaid ONDERTAL+HOGE DRUK",
        description: "Ondersteuning in ondertal met hoge druk",
        difficulty: 6
      }
    ]
  },
  "DRIEKHOEKSSPEL": {
    name: "Driekhoeksspel",
    levels: [
      {
        id: "basic_triangle_positioning",
        name: "AANSPEELBAAR ZIJN-GOED INGEDRAAID-SCAN-POSITIESPEL",
        description: "Basis driehoek positionering met scanning",
        difficulty: 1
      },
      {
        id: "improved_triangle_positioning", 
        name: "AANSPEELBAAR ZIJN-GOED INGEDRAAID-SCAN-POSITIESPEL",
        description: "Verbeterde driehoek positionering",
        difficulty: 2
      },
      {
        id: "high_speed_triangle_positioning",
        name: "AANSPEELBAAR ZIJN-GOED INGEDRAAID-SCAN-POSITIESPEL (OP HOGE SNELHEID)",
        description: "Driehoek positionering op hoge snelheid",
        difficulty: 3
      },
      {
        id: "advanced_high_speed_triangles",
        name: "AANSPEELBAAR ZIJN-GOED INGEDRAAID-SCAN-POSITIESPEL (OP HOGE SNELHEID)",
        description: "Geavanceerde driehoeken op hoge snelheid",
        difficulty: 4
      },
      {
        id: "expert_triangle_play",
        name: "AANSPEELBAAR ZIJN-GOED INGEDRAAID-SCAN-POSITIESPEL (OP HOGE SNELHEID)",
        description: "Expert niveau driekhoeksspel",
        difficulty: 5
      },
      {
        id: "masterful_triangle_execution",
        name: "AANSPEELBAAR ZIJN-GOED INGEDRAAID-SCAN-POSITIESPEL (OP HOGE SNELHEID)",
        description: "Meesterlijke uitvoering van driekhoeksspel",
        difficulty: 6
      }
    ]
  },
  "CREEER_3X_AANSPEELBAARHEID": {
    name: "Creeer 3 x aanspeelbaarheid",
    levels: [
      {
        id: "three_options_basic",
        name: "3 Aanspeelopties creëren - Basis niveau",
        description: "Eenvoudige drie aanspeelopties bieden",
        difficulty: 1
      },
      {
        id: "three_options_consistent",
        name: "3 Aanspeelopties creëren - Consistent niveau",
        description: "Betrouwbare drie aanspeelopties onder lichte druk",
        difficulty: 2
      },
      {
        id: "three_options_pressure",
        name: "3 Aanspeelopties creëren - Onder druk",
        description: "Drie aanspeelopties behouden onder druk",
        difficulty: 3
      },
      {
        id: "three_options_dynamic",
        name: "3 Aanspeelopties creëren - Dynamisch",
        description: "Flexibele drie aanspeelopties in beweging",
        difficulty: 4
      },
      {
        id: "three_options_advanced",
        name: "3 Aanspeelopties creëren - Geavanceerd",
        description: "Complexe drie aanspeelopties onder alle omstandigheden",
        difficulty: 5
      },
      {
        id: "three_options_masterful",
        name: "3 Aanspeelopties creëren - Meesterlijk",
        description: "Perfecte beheersing van drie aanspeelopties",
        difficulty: 6
      }
    ]
  },
  "BALBEZIT": {
    name: "Vlotte eficiënte balcirculatie",
    levels: [
      {
        id: "possession_majority_1",
        name: "Vrijlopen-Steunen-Goed ingedraaid staan-Balcontrole - Passing MEERDERHEIDSSITUATIE",
        description: "Balbezit in numerieke meerderheid",
        difficulty: 1
      },
      {
        id: "possession_majority_2",
        name: "Vrijlopen-Steunen-Goed ingedraaid staan-Balcontrole - Passing MEERDERHEIDSSITUATIE",
        description: "Verbeterd balbezit in numerieke meerderheid",
        difficulty: 2
      },
      {
        id: "possession_equal_1",
        name: "Vrijlopen-Steunen-Goed ingedraaid staan-Balcontrole - Passing GELIJKE AANTALLEN",
        description: "Balbezit bij gelijke aantallen",
        difficulty: 3
      },
      {
        id: "possession_equal_2",
        name: "Vrijlopen-Steunen-Goed ingedraaid staan-Balcontrole - Passing GELIJKE AANTALLEN",
        description: "Geavanceerd balbezit bij gelijke aantallen",
        difficulty: 4
      },
      {
        id: "possession_minority",
        name: "Vrijlopen-Steunen-Goed ingedraaid staan-Balcontrole - Passing ONDERTAL",
        description: "Balbezit in numeriek ondertal",
        difficulty: 5
      },
      {
        id: "possession_minority_pressure",
        name: "Vrijlopen-Steunen-Goed ingedraaid staan-Balcontrole - Passing ONDERTAL + HOGE DRUK",
        description: "Balbezit in ondertal met hoge druk",
        difficulty: 6
      }
    ]
  },
  "HOOG_TEMPO_BALBEZIT": {
    name: "Hoog tempo balbezit",
    levels: [
      {
        id: "high_tempo_majority_equal",
        name: "SCAN + Snel Gericht vrijlopen/Steunen- Snel Nauwkeurige Passing MEERDERHEIDSSITUATIE + GELIJKE AANTALLEN",
        description: "Hoog tempo spel in meerderheid en gelijke situaties",
        difficulty: 1
      },
      {
        id: "high_tempo_majority_minority",
        name: "SCAN + Snel Gericht vrijlopen/Steunen- Snel Nauwkeurige Passing MEERDERHEIDSSITUATIE + ONDERTAL",
        description: "Hoog tempo spel van meerderheid naar ondertal",
        difficulty: 2
      },
      {
        id: "high_tempo_consistent_minority_1",
        name: "SCAN + Snel Gericht vrijlopen/Steunen- Snel Nauwkeurige Passing MEERDERHEIDSSITUATIE + ONDERTAL",
        description: "Consistent hoog tempo in alle numerieke situaties",
        difficulty: 3
      },
      {
        id: "high_tempo_consistent_minority_2",
        name: "SCAN + Snel Gericht vrijlopen/Steunen- Snel Nauwkeurige Passing MEERDERHEIDSSITUATIE + ONDERTAL",
        description: "Geavanceerd hoog tempo in wisselende situaties",
        difficulty: 4
      },
      {
        id: "high_tempo_pressure_basic",
        name: "SCAN + Snel Gericht vrijlopen/Steunen- Snel Nauwkeurige Passing MEERDERHEIDSSITUATIE + ONDERTAL+HOGE DRUK",
        description: "Hoog tempo onder hoge druk",
        difficulty: 5
      },
      {
        id: "high_tempo_pressure_master",
        name: "SCAN + Snel Gericht vrijlopen/Steunen- Snel Nauwkeurige Passing MEERDERHEIDSSITUATIE + ONDERTAL+HOGE DRUK",
        description: "Meesterlijk hoog tempo onder extreme druk",
        difficulty: 6
      }
    ]
  },
  "DIAGONAL_IN_UIT": {
    name: "Diagonal in & uit",
    levels: [
      {
        id: "diagonal_position_basic",
        name: "In & uit hs/flank/centrum positie bezetten",
        description: "Basis posities innemen in halfspace, flank en centrum",
        difficulty: 1
      },
      {
        id: "diagonal_position_improved",
        name: "In & uit hs/flank/centrum positie bezetten",
        description: "Verbeterde positie bezetting in verschillende zones",
        difficulty: 2
      },
      {
        id: "diagonal_long_passing_basic",
        name: "Lange Passing (laag/hoog) + Ruimte zwakke zone",
        description: "Lange passes naar zwakke zones",
        difficulty: 3
      },
      {
        id: "diagonal_long_passing_improved",
        name: "Lange Passing (laag/hoog) + Ruimte zwakke zone",
        description: "Geavanceerde lange passes naar zwakke zones",
        difficulty: 4
      },
      {
        id: "diagonal_pressure_basic",
        name: "Lange Passing (laag/hoog) + Ruimte zwakke zone ONDER HOGE DRUK",
        description: "Lange passes naar zwakke zones onder hoge druk",
        difficulty: 5
      },
      {
        id: "diagonal_pressure_master",
        name: "Lange Passing (laag/hoog) + Ruimte zwakke zone ONDER HOGE DRUK",
        description: "Meesterlijke lange passes onder extreme druk",
        difficulty: 6
      }
    ]
  },
  "LINIE_OVERSLAAN": {
    name: "Linie overslaan",
    levels: [
      {
        id: "deep_pass_basic_1",
        name: "Passing Diep /Linie Overslaan naar gericht naar medespeler",
        description: "Basis diepe passes naar medespelers",
        difficulty: 1
      },
      {
        id: "deep_pass_basic_2",
        name: "Passing Diep /Linie Overslaan naar gericht naar medespeler",
        description: "Verbeterde diepe passes naar medespelers",
        difficulty: 2
      },
      {
        id: "deep_pass_value_assessment_1",
        name: "Passing Diep /Linie Overslaan naar gericht naar medespeler + inschatten meerwaarde diepe pass",
        description: "Diepe passes met inschatting van meerwaarde",
        difficulty: 3
      },
      {
        id: "deep_pass_value_assessment_2",
        name: "Passing Diep /Linie Overslaan naar gericht naar medespeler + inschatten meerwaarde diepe pass",
        description: "Geavanceerde inschatting van diepe pass meerwaarde",
        difficulty: 4
      },
      {
        id: "deep_pass_value_assessment_3",
        name: "Passing Diep /Linie Overslaan naar gericht naar medespeler + inschatten meerwaarde diepe pass",
        description: "Expert niveau inschatting diepe pass situaties",
        difficulty: 5
      },
      {
        id: "deep_pass_value_assessment_master",
        name: "Passing Diep /Linie Overslaan naar gericht naar medespeler + inschatten meerwaarde diepe pass",
        description: "Meesterlijke beheersing van diepe pass timing en waarde",
        difficulty: 6
      }
    ]
  },

  // TEAMTACTISCH B+ VOORUITGANG & INFILTRATIE Elements
  "POSITIE_TUSSEN_DE_LINIES": {
    name: "Positie tussen de linies",
    levels: [
      {
        id: "strict_marking_escape_1",
        name: "Strikte dekking ontvlucten/vrijlopen en aanspeelbaar zijn",
        description: "Eerste niveau ontsnappen aan strikte dekking",
        difficulty: 1
      },
      {
        id: "strict_marking_escape_2",
        name: "Strikte dekking ontvlucten/vrijlopen en aanspeelbaar zijn",
        description: "Verbeterd ontsnappen aan strikte dekking",
        difficulty: 2
      }
    ]
  },
  "DIEPGAANDE_INFILTRATIES": {
    name: "Diepgaande infiltraties",
    levels: [
      {
        id: "infiltration_with_ball_1",
        name: "Infiltraties met de bal/Leiden van de Bal+Dribbelen",
        description: "Basis infiltraties met bal en dribbelen",
        difficulty: 1
      },
      {
        id: "infiltration_with_ball_2",
        name: "Infiltraties met de bal/Leiden van de Bal+Dribbelen",
        description: "Verbeterde infiltraties met bal",
        difficulty: 2
      },
      {
        id: "infiltration_smart_timing_1",
        name: "Infiltraties met de bal/Geen dom balverlies+op het juiste moment * Infiltraties zonder bal 1/2",
        description: "Slimme infiltraties met juiste timing",
        difficulty: 3
      },
      {
        id: "infiltration_smart_timing_2",
        name: "Infiltraties met de bal/Geen dom balverlies+op het juiste moment * Infiltraties zonder bal 1/2",
        description: "Geavanceerde timing en zonder bal infiltraties",
        difficulty: 4
      },
      {
        id: "infiltration_depth_diving",
        name: "Infiltraties met de bal/Geen dom balverlies+op het juiste moment * Infiltraties zonder bal 1/2 + Diepte Induiken (let op offside)",
        description: "Infiltraties met diepte induiken",
        difficulty: 5
      },
      {
        id: "infiltration_block_players",
        name: "Enkele spelers uit ons blok infiltreren",
        description: "Spelers uit blok laten infiltreren",
        difficulty: 6
      }
    ]
  },
  "INTERACTIES_2_3_LINIES": {
    name: "Interacties 2, 3 linies",
    levels: [
      {
        id: "zone_football_principles_1",
        name: "Principes Zonevoetbal",
        description: "Basis principes van zonevoetbal",
        difficulty: 1
      },
      {
        id: "zone_football_principles_2",
        name: "Principes Zonevoetbal",
        description: "Verbeterde zonevoetbal principes",
        difficulty: 2
      },
      {
        id: "zone_football_principles_3",
        name: "Principes Zonevoetbal",
        description: "Geavanceerde zonevoetbal principes",
        difficulty: 3
      },
      {
        id: "zone_football_principles_4",
        name: "Principes Zonevoetbal",
        description: "Expert niveau zonevoetbal",
        difficulty: 4
      },
      {
        id: "zone_football_principles_5",
        name: "Principes Zonevoetbal",
        description: "Professioneel zonevoetbal",
        difficulty: 5
      },
      {
        id: "zone_football_principles_6",
        name: "Principes Zonevoetbal",
        description: "Meesterlijke zonevoetbal principes",
        difficulty: 6
      }
    ]
  },
  "VERMIJD_ONNODIG_BALVERLIES": {
    name: "Vermijd onnodig balverlies",
    levels: [
      {
        id: "avoid_ball_loss_basic",
        name: "Vermijd Dom Balverlies (Passing/Balcontrole/Leiden/Dribbelen)",
        description: "Basis vermijden van dom balverlies",
        difficulty: 1
      },
      {
        id: "avoid_ball_loss_improved",
        name: "Vermijd Dom Balverlies (Passing/Balcontrole/Leiden/Dribbelen)",
        description: "Verbeterd vermijden van balverlies",
        difficulty: 2
      },
      {
        id: "avoid_ball_loss_majority",
        name: "Vermijd Dom Balverlies (Passing/Balcontrole/Leiden/Dribbelen) MEERDERHEIDSSITUATIE",
        description: "Balverlies vermijden in meerderheid",
        difficulty: 3
      },
      {
        id: "avoid_ball_loss_equal",
        name: "Vermijd Dom Balverlies (Passing/Balcontrole/Leiden/Dribbelen) GELIJKE AANTALLEN",
        description: "Balverlies vermijden bij gelijke aantallen",
        difficulty: 4
      },
      {
        id: "avoid_ball_loss_minority",
        name: "Vermijd Dom Balverlies (Passing/Balcontrole/Leiden/Dribbelen) ONDERAANTAL",
        description: "Balverlies vermijden in ondertal",
        difficulty: 5
      },
      {
        id: "avoid_ball_loss_high_pressure",
        name: "Vermijd Dom Balverlies (Passing/Balcontrole/Leiden/Dribbelen)ONDERAANTAL + HOGE DRUK",
        description: "Balverlies vermijden in ondertal met hoge druk",
        difficulty: 6
      }
    ]
  },
  "INDIVIDUELE_ACTIE": {
    name: "Individuele actie",
    levels: [
      {
        id: "individual_action_basic",
        name: "Leiden/Dribbelen op het juiste moment (ruimte)+geen kans op balverlies",
        description: "Basis individuele acties",
        difficulty: 1
      },
      {
        id: "individual_action_improved",
        name: "Leiden/Dribbelen op het juiste moment (ruimte)+geen kans op balverlies",
        description: "Verbeterde individuele acties",
        difficulty: 2
      },
      {
        id: "individual_action_advanced",
        name: "Leiden/Dribbelen op het juiste moment (ruimte)+geen kans op balverlies",
        description: "Geavanceerde individuele acties",
        difficulty: 3
      },
      {
        id: "individual_action_space_creation",
        name: "Leiden/Dribbelen op het juiste moment (ruimte)+geen kans op balverlies om zo ruimte te creeren voor medespelers",
        description: "Individuele acties voor ruimte creatie",
        difficulty: 4
      },
      {
        id: "individual_action_majority",
        name: "Leiden/Dribbelen op het juiste moment (ruimte)+geen kans op balverlies om zo ruimte te creeren voor medespelers MEERDERHEIDSSITUATIE",
        description: "Individuele acties in meerderheid",
        difficulty: 5
      },
      {
        id: "individual_action_minority",
        name: "Leiden/Dribbelen op het juiste moment (ruimte)+geen kans op balverlies om zo ruimte te creeren voor medespelers ONDERTAL",
        description: "Individuele acties in ondertal",
        difficulty: 6
      }
    ]
  },
  "SUBTIELE_LAATSTE_PASS": {
    name: "Subtiele laatste pass",
    levels: [
      {
        id: "subtle_final_pass_short_medium",
        name: "Subtiele Eindpass (Korte passing/Ruimte benutten van de tegenstrever dmv passing) (kort-middellang)",
        description: "Subtiele korte en middellange eindpasses",
        difficulty: 1
      },
      {
        id: "subtle_final_pass_short_medium_2",
        name: "Subtiele Eindpass (Korte passing/Ruimte benutten van de tegenstrever dmv passing) (kort-middellang)",
        description: "Verbeterde subtiele eindpasses",
        difficulty: 2
      },
      {
        id: "subtle_final_pass_short_medium_3",
        name: "Subtiele Eindpass (Korte passing/Ruimte benutten van de tegenstrever dmv passing) (kort-middellang)",
        description: "Geavanceerde subtiele eindpasses",
        difficulty: 3
      },
      {
        id: "subtle_final_pass_all_ranges_1",
        name: "Subtiele Eindpass (Korte passing/Ruimte benutten van de tegenstrever dmv passing) (kort-middellang-lang+hoog)",
        description: "Alle afstanden subtiele eindpasses",
        difficulty: 4
      },
      {
        id: "subtle_final_pass_all_ranges_2",
        name: "Subtiele Eindpass (Korte passing/Ruimte benutten van de tegenstrever dmv passing) (kort-middellang-lang+hoog)",
        description: "Expert niveau alle afstanden",
        difficulty: 5
      },
      {
        id: "subtle_final_pass_all_ranges_3",
        name: "Subtiele Eindpass (Korte passing/Ruimte benutten van de tegenstrever dmv passing) (kort-middellang-lang+hoog)",
        description: "Meesterlijke subtiele eindpasses",
        difficulty: 6
      }
    ]
  },
  "VOORZET": {
    name: "Voorzet",
    levels: [
      {
        id: "low_cross_basic",
        name: "Lage voorzet: Eenvoudig Schieten/controle",
        description: "Basis lage voorzetten",
        difficulty: 1
      },
      {
        id: "low_cross_improved",
        name: "Lage voorzet: Eenvoudig Schieten/controle",
        description: "Verbeterde lage voorzetten",
        difficulty: 2
      },
      {
        id: "medium_cross_basic",
        name: "Middellange voorzet: Schieten/Controle",
        description: "Basis middellange voorzetten",
        difficulty: 3
      },
      {
        id: "medium_cross_speed",
        name: "Middellange voorzet: Schieten/Controle Op SNELHEID",
        description: "Middellange voorzetten op snelheid",
        difficulty: 4
      },
      {
        id: "long_cross_basic",
        name: "Lange voorzet (laag+hoog): Schieten/Controle",
        description: "Basis lange voorzetten",
        difficulty: 5
      },
      {
        id: "long_cross_speed",
        name: "Lange voorzet (laag+hoog): Schieten/Controle OP SNELHEID",
        description: "Lange voorzetten op snelheid",
        difficulty: 6
      }
    ]
  },
  "VROEGE_VOORZET": {
    name: "Vroege voorzet",
    levels: [
      {
        id: "early_cross_1",
        name: "Vroege Lange voorzet (laag+hoog): Schieten/Controle OP SNELHEID",
        description: "Basis vroege lange voorzetten",
        difficulty: 1
      },
      {
        id: "early_cross_2",
        name: "Vroege Lange voorzet (laag+hoog): Schieten/Controle OP SNELHEID",
        description: "Verbeterde vroege lange voorzetten",
        difficulty: 2
      }
    ]
  },

  // TEAMTACTISCH B+ DOELPUNTEN MAKEN Elements
  "VIER_IN_DE_16": {
    name: "4 in de 16",
    levels: [
      {
        id: "golden_zone_positioning_1",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Basis posities innemen in de golden zone",
        difficulty: 1
      },
      {
        id: "golden_zone_positioning_2",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Verbeterde posities in de golden zone",
        difficulty: 2
      },
      {
        id: "golden_zone_positioning_3",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Geavanceerde posities in de golden zone",
        difficulty: 3
      },
      {
        id: "golden_zone_positioning_4",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Expert posities in de golden zone",
        difficulty: 4
      },
      {
        id: "golden_zone_positioning_5",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Professionele posities in de golden zone",
        difficulty: 5
      },
      {
        id: "golden_zone_positioning_6",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Meesterlijke posities in de golden zone",
        difficulty: 6
      }
    ]
  },
  "AANVALLEN_BLINDE_ZIJDE": {
    name: "Aanvallen van de blinde zijde verdediging",
    levels: [
      {
        id: "blind_side_movement_1",
        name: "Bewust Vrijlopen in de rug van 1 van de 2 CV of rug FV (let op offside) eerst breed dan diep",
        description: "Basis bewuste bewegingen achter verdedigers",
        difficulty: 1
      },
      {
        id: "blind_side_movement_2",
        name: "Bewust Vrijlopen in de rug van 1 van de 2 CV of rug FV (let op offside) eerst breed dan diep",
        description: "Verbeterde bewuste bewegingen achter verdedigers",
        difficulty: 2
      },
      {
        id: "blind_side_movement_3",
        name: "Bewust Vrijlopen in de rug van 1 van de 2 CV of rug FV (let op offside) eerst breed dan diep",
        description: "Geavanceerde bewuste bewegingen achter verdedigers",
        difficulty: 3
      },
      {
        id: "blind_side_movement_4",
        name: "Bewust Vrijlopen in de rug van 1 van de 2 CV of rug FV (let op offside) eerst breed dan diep",
        description: "Expert bewuste bewegingen achter verdedigers",
        difficulty: 4
      },
      {
        id: "blind_side_movement_5",
        name: "Bewust Vrijlopen in de rug van 1 van de 2 CV of rug FV (let op offside) eerst breed dan diep",
        description: "Professionele bewuste bewegingen achter verdedigers",
        difficulty: 5
      },
      {
        id: "blind_side_movement_6",
        name: "Bewust Vrijlopen in de rug van 1 van de 2 CV of rug FV (let op offside) eerst breed dan diep",
        description: "Meesterlijke bewuste bewegingen achter verdedigers",
        difficulty: 6
      }
    ]
  },
  "KORDATE_AFWERKING": {
    name: "Kordate afwerking",
    levels: [
      {
        id: "directed_shooting_basic",
        name: "Gericht Schieten op doel",
        description: "Basis gericht schieten",
        difficulty: 1
      },
      {
        id: "directed_shooting_improved",
        name: "Gericht schieten op doel",
        description: "Verbeterd gericht schieten",
        difficulty: 2
      },
      {
        id: "correct_foot_shooting",
        name: "Gericht en met juiste voet schieten",
        description: "Schieten met de juiste voet",
        difficulty: 3
      },
      {
        id: "fast_correct_shooting",
        name: "Snel gericht en met juiste voet schieten",
        description: "Snelle afwerking met juiste voet",
        difficulty: 4
      },
      {
        id: "pressure_shooting",
        name: "Onder druk snel en gericht schieten met juiste voet",
        description: "Afwerking onder defensieve druk",
        difficulty: 5
      },
      {
        id: "pressure_shooting_follow_up",
        name: "Onder druk snel en gericht schieten met juiste voet en navolgen",
        description: "Afwerking onder druk met navolgen",
        difficulty: 6
      }
    ]
  },
  "POSITIES_INNEMEN_16": {
    name: "Posities innemen in de 16",
    levels: [
      {
        id: "box_positioning_1",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Basis posities innemen in en rond de 16",
        difficulty: 1
      },
      {
        id: "box_positioning_2",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Verbeterde posities in en rond de 16",
        difficulty: 2
      },
      {
        id: "box_positioning_3",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Geavanceerde posities in en rond de 16",
        difficulty: 3
      },
      {
        id: "box_positioning_4",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Expert posities in en rond de 16",
        difficulty: 4
      },
      {
        id: "box_positioning_5",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Professionele posities in en rond de 16",
        difficulty: 5
      },
      {
        id: "box_positioning_6",
        name: "POSTIE INNAME in en rond de GOLDEN ZONE",
        description: "Meesterlijke posities in en rond de 16",
        difficulty: 6
      }
    ]
  },
  "FLANKVOORZETTEN": {
    name: "Flankvoorzetten",
    levels: [
      {
        id: "flank_crosses_basic",
        name: "Basis flankvoorzetten - Eenvoudige timing",
        description: "Eenvoudige flankvoorzetten met basis timing",
        difficulty: 1
      },
      {
        id: "flank_crosses_improved",
        name: "Verbeterde flankvoorzetten - Betere plaatsing",
        description: "Flankvoorzetten met verbeterde plaatsing",
        difficulty: 2
      },
      {
        id: "flank_crosses_varied",
        name: "Gevarieerde flankvoorzetten - Verschillende hoogtes",
        description: "Flankvoorzetten op verschillende hoogtes",
        difficulty: 3
      },
      {
        id: "flank_crosses_speed",
        name: "Snelle flankvoorzetten - Tempo en precisie",
        description: "Flankvoorzetten met hoog tempo en precisie",
        difficulty: 4
      },
      {
        id: "flank_crosses_pressure",
        name: "Flankvoorzetten onder druk - Defensieve druk",
        description: "Effectieve flankvoorzetten onder defensieve druk",
        difficulty: 5
      },
      {
        id: "flank_crosses_masterful",
        name: "Meesterlijke flankvoorzetten - Perfecte timing en plaatsing",
        description: "Perfecte flankvoorzetten met ideale timing",
        difficulty: 6
      }
    ]
  },

  // TEAMTACTISCH B- DRUK ZETTEN Elements
  "DRUK_ZETTEN_OP_BALDRAGER": {
    name: "Druk zetten op baldrager",
    levels: [
      {
        id: "basic_pressure_on_ball",
        name: "Basis druk op baldrager",
        description: "Eenvoudige druk zetten op speler met bal",
        difficulty: 1
      },
      {
        id: "consistent_pressure",
        name: "Consistente druk",
        description: "Betrouwbare druk gedurende het spel",
        difficulty: 2
      },
      {
        id: "intelligent_pressure_timing",
        name: "Intelligente druk timing",
        description: "Juiste moment kiezen voor druk",
        difficulty: 3
      },
      {
        id: "coordinated_pressure",
        name: "Gecoördineerde druk",
        description: "Druk in samenwerking met teamgenoten",
        difficulty: 4
      },
      {
        id: "advanced_pressure_techniques",
        name: "Geavanceerde druk technieken",
        description: "Complexe druk zetten methoden",
        difficulty: 5
      },
      {
        id: "masterful_pressure",
        name: "Meesterlijke druk",
        description: "Perfecte beheersing van druk zetten",
        difficulty: 6
      }
    ]
  },
  "TIMING_VAN_DRUK_ZETTEN": {
    name: "Timing van druk zetten",
    levels: [
      {
        id: "basic_timing_awareness",
        name: "Basis timing bewustzijn",
        description: "Eenvoudig begrip van wanneer druk te zetten",
        difficulty: 1
      },
      {
        id: "improved_timing_recognition",
        name: "Verbeterde timing herkenning",
        description: "Betere herkenning van druk momenten",
        difficulty: 2
      },
      {
        id: "situational_timing",
        name: "Situationele timing",
        description: "Timing aanpassen aan situatie",
        difficulty: 3
      },
      {
        id: "predictive_timing",
        name: "Voorspellende timing",
        description: "Anticiperen op druk momenten",
        difficulty: 4
      },
      {
        id: "advanced_timing_mastery",
        name: "Geavanceerde timing beheersing",
        description: "Complexe timing patronen",
        difficulty: 5
      },
      {
        id: "perfect_timing_execution",
        name: "Perfecte timing uitvoering",
        description: "Meesterlijke timing van druk",
        difficulty: 6
      }
    ]
  },
  "COLLECTIEF_DRUK_ZETTEN": {
    name: "Collectief druk zetten",
    levels: [
      {
        id: "basic_collective_pressure",
        name: "Basis collectieve druk",
        description: "Eenvoudige teamdruk",
        difficulty: 1
      },
      {
        id: "coordinated_team_pressure",
        name: "Gecoördineerde teamdruk",
        description: "Samenwerking in druk zetten",
        difficulty: 2
      },
      {
        id: "systematic_pressing",
        name: "Systematisch pressing",
        description: "Georganiseerde pressing aanpak",
        difficulty: 3
      },
      {
        id: "high_intensity_pressing",
        name: "Hoge intensiteit pressing",
        description: "Intensieve collectieve druk",
        difficulty: 4
      },
      {
        id: "advanced_pressing_systems",
        name: "Geavanceerde pressing systemen",
        description: "Complexe pressing organisatie",
        difficulty: 5
      },
      {
        id: "masterful_collective_pressing",
        name: "Meesterlijke collectieve pressing",
        description: "Perfecte teamdruk uitvoering",
        difficulty: 6
      }
    ]
  },
  "PRESSING_ORGANISATIE": {
    name: "Pressing organisatie",
    levels: [
      {
        id: "basic_pressing_structure",
        name: "Basis pressing structuur",
        description: "Eenvoudige pressing opzet",
        difficulty: 1
      },
      {
        id: "pressing_communication",
        name: "Pressing communicatie",
        description: "Communicatie tijdens pressing",
        difficulty: 2
      },
      {
        id: "pressing_triggers",
        name: "Pressing triggers",
        description: "Signalen voor pressing start",
        difficulty: 3
      },
      {
        id: "coordinated_pressing_lines",
        name: "Gecoördineerde pressing linies",
        description: "Samenwerking tussen linies",
        difficulty: 4
      },
      {
        id: "advanced_pressing_tactics",
        name: "Geavanceerde pressing tactieken",
        description: "Complexe pressing strategieën",
        difficulty: 5
      },
      {
        id: "masterful_pressing_organization",
        name: "Meesterlijke pressing organisatie",
        description: "Perfecte pressing coördinatie",
        difficulty: 6
      }
    ]
  },
  "BALVEROVERING_DRUK": {
    name: "Balverovering druk",
    levels: [
      {
        id: "basic_ball_recovery",
        name: "Basis balverovering",
        description: "Eenvoudige balverovering technieken",
        difficulty: 1
      },
      {
        id: "aggressive_ball_winning",
        name: "Agressieve balverovering",
        description: "Actieve balverovering aanpak",
        difficulty: 2
      },
      {
        id: "intelligent_intercepting",
        name: "Intelligente intercepties",
        description: "Slimme balonderbreking",
        difficulty: 3
      },
      {
        id: "coordinated_ball_recovery",
        name: "Gecoördineerde balverovering",
        description: "Teamwerk in balverovering",
        difficulty: 4
      },
      {
        id: "advanced_recovery_techniques",
        name: "Geavanceerde hersteltechnieken",
        description: "Complexe balverovering methoden",
        difficulty: 5
      },
      {
        id: "masterful_ball_recovery",
        name: "Meesterlijke balverovering",
        description: "Perfecte balverovering uitvoering",
        difficulty: 6
      }
    ]
  },
  "GECOORDINEERDE_DRUK": {
    name: "Gecoördineerde druk",
    levels: [
      {
        id: "basic_coordinated_pressure",
        name: "Basis gecoördineerde druk",
        description: "Eenvoudige samenwerking in druk",
        difficulty: 1
      },
      {
        id: "synchronized_movement",
        name: "Gesynchroniseerde beweging",
        description: "Gelijktijdige beweging in druk",
        difficulty: 2
      },
      {
        id: "tactical_coordination",
        name: "Tactische coördinatie",
        description: "Tactische samenwerking",
        difficulty: 3
      },
      {
        id: "complex_coordination_patterns",
        name: "Complexe coördinatie patronen",
        description: "Geavanceerde samenwerkingspatronen",
        difficulty: 4
      },
      {
        id: "seamless_team_coordination",
        name: "Naadloze team coördinatie",
        description: "Vloeiende teamcoördinatie",
        difficulty: 5
      },
      {
        id: "masterful_coordination",
        name: "Meesterlijke coördinatie",
        description: "Perfecte druk coördinatie",
        difficulty: 6
      }
    ]
  },

  // TEAMTACTISCH B- COMPACT VERDEDIGEN Elements
  "COMPACTE_VERDEDIGING": {
    name: "Compacte verdediging",
    levels: [
      {
        id: "basic_compact_defense",
        name: "Basis compacte verdediging",
        description: "Eenvoudige compacte opzet",
        difficulty: 1
      },
      {
        id: "maintaining_shape",
        name: "Vorm behouden",
        description: "Verdedigende vorm behouden",
        difficulty: 2
      },
      {
        id: "coordinated_compactness",
        name: "Gecoördineerde compactheid",
        description: "Samenwerking in compacte verdediging",
        difficulty: 3
      },
      {
        id: "dynamic_compact_defense",
        name: "Dynamische compacte verdediging",
        description: "Flexibele compacte verdediging",
        difficulty: 4
      },
      {
        id: "advanced_compact_systems",
        name: "Geavanceerde compacte systemen",
        description: "Complexe compacte organisatie",
        difficulty: 5
      },
      {
        id: "masterful_compact_defense",
        name: "Meesterlijke compacte verdediging",
        description: "Perfecte compacte verdediging",
        difficulty: 6
      }
    ]
  },
  "KORTE_AFSTANDEN_HOUDEN": {
    name: "Korte afstanden houden",
    levels: [
      {
        id: "basic_distance_control",
        name: "Basis afstand controle",
        description: "Eenvoudige afstand beheer",
        difficulty: 1
      },
      {
        id: "consistent_spacing",
        name: "Consistente tussenruimte",
        description: "Betrouwbare afstanden houden",
        difficulty: 2
      },
      {
        id: "adaptive_spacing",
        name: "Adaptieve tussenruimte",
        description: "Afstanden aanpassen aan situatie",
        difficulty: 3
      },
      {
        id: "coordinated_spacing",
        name: "Gecoördineerde tussenruimte",
        description: "Teamafstanden coördineren",
        difficulty: 4
      },
      {
        id: "advanced_distance_management",
        name: "Geavanceerd afstand beheer",
        description: "Complexe afstand strategieën",
        difficulty: 5
      },
      {
        id: "perfect_spacing_control",
        name: "Perfecte tussenruimte controle",
        description: "Meesterlijke afstand beheersing",
        difficulty: 6
      }
    ]
  },
  "DEFENSIEVE_BLOK_FORMATIE": {
    name: "Defensieve blok formatie",
    levels: [
      {
        id: "basic_defensive_block",
        name: "Basis defensieve blok",
        description: "Eenvoudige blok formatie",
        difficulty: 1
      },
      {
        id: "structured_block_formation",
        name: "Gestructureerde blok formatie",
        description: "Georganiseerde blok opzet",
        difficulty: 2
      },
      {
        id: "flexible_block_positioning",
        name: "Flexibele blok positionering",
        description: "Adaptieve blok posities",
        difficulty: 3
      },
      {
        id: "coordinated_block_movement",
        name: "Gecoördineerde blok beweging",
        description: "Samenwerking in blok beweging",
        difficulty: 4
      },
      {
        id: "advanced_block_tactics",
        name: "Geavanceerde blok tactieken",
        description: "Complexe blok strategieën",
        difficulty: 5
      },
      {
        id: "masterful_block_formation",
        name: "Meesterlijke blok formatie",
        description: "Perfecte blok organisatie",
        difficulty: 6
      }
    ]
  },
  "MEEBEWEGING_ALS_EENHEID": {
    name: "Meebeweging als eenheid",
    levels: [
      {
        id: "basic_unit_movement",
        name: "Basis eenheid beweging",
        description: "Eenvoudige groepsbeweging",
        difficulty: 1
      },
      {
        id: "synchronized_unit_movement",
        name: "Gesynchroniseerde eenheid beweging",
        description: "Gelijktijdige groepsbeweging",
        difficulty: 2
      },
      {
        id: "coordinated_shifting",
        name: "Gecoördineerd verschuiven",
        description: "Samenwerking in verschuiving",
        difficulty: 3
      },
      {
        id: "fluid_unit_movement",
        name: "Vloeiende eenheid beweging",
        description: "Soepele groepsbeweging",
        difficulty: 4
      },
      {
        id: "advanced_unit_coordination",
        name: "Geavanceerde eenheid coördinatie",
        description: "Complexe groepscoördinatie",
        difficulty: 5
      },
      {
        id: "masterful_unit_movement",
        name: "Meesterlijke eenheid beweging",
        description: "Perfecte groepsbeweging",
        difficulty: 6
      }
    ]
  },
  "RUIMTES_KLEIN_HOUDEN": {
    name: "Ruimtes klein houden",
    levels: [
      {
        id: "basic_space_management",
        name: "Basis ruimte beheer",
        description: "Eenvoudige ruimte controle",
        difficulty: 1
      },
      {
        id: "consistent_space_closure",
        name: "Consistente ruimte afsluiting",
        description: "Betrouwbare ruimte beperking",
        difficulty: 2
      },
      {
        id: "intelligent_space_control",
        name: "Intelligente ruimte controle",
        description: "Slimme ruimte beheersing",
        difficulty: 3
      },
      {
        id: "coordinated_space_management",
        name: "Gecoördineerd ruimte beheer",
        description: "Teamwerk in ruimte controle",
        difficulty: 4
      },
      {
        id: "advanced_space_restriction",
        name: "Geavanceerde ruimte beperking",
        description: "Complexe ruimte strategieën",
        difficulty: 5
      },
      {
        id: "masterful_space_control",
        name: "Meesterlijke ruimte controle",
        description: "Perfecte ruimte beheersing",
        difficulty: 6
      }
    ]
  },
  "DEFENSIEVE_DISCIPLINE": {
    name: "Defensieve discipline",
    levels: [
      {
        id: "basic_defensive_discipline",
        name: "Basis defensieve discipline",
        description: "Eenvoudige defensieve structuur",
        difficulty: 1
      },
      {
        id: "consistent_positioning",
        name: "Consistente positionering",
        description: "Betrouwbare posities houden",
        difficulty: 2
      },
      {
        id: "tactical_discipline",
        name: "Tactische discipline",
        description: "Tactische instructies volgen",
        difficulty: 3
      },
      {
        id: "mental_defensive_strength",
        name: "Mentale defensieve kracht",
        description: "Mentale weerbaarheid in verdediging",
        difficulty: 4
      },
      {
        id: "advanced_defensive_discipline",
        name: "Geavanceerde defensieve discipline",
        description: "Complexe defensieve organisatie",
        difficulty: 5
      },
      {
        id: "masterful_defensive_discipline",
        name: "Meesterlijke defensieve discipline",
        description: "Perfecte defensieve discipline",
        difficulty: 6
      }
    ]
  },

  // TEAMTACTISCH B- BESCHERMEN VAN HET DOEL Elements
  "DOELGEBIED_VERDEDIGING": {
    name: "Doelgebied verdediging",
    levels: [
      {
        id: "basic_goal_area_defense",
        name: "Basis doelgebied verdediging",
        description: "Eenvoudige doelgebied bescherming",
        difficulty: 1
      },
      {
        id: "penalty_area_positioning",
        name: "Penalty gebied positionering",
        description: "Juiste posities in penalty gebied",
        difficulty: 2
      },
      {
        id: "goal_line_defense",
        name: "Doellijn verdediging",
        description: "Bescherming van de doellijn",
        difficulty: 3
      },
      {
        id: "coordinated_box_defense",
        name: "Gecoördineerde box verdediging",
        description: "Samenwerking in doelgebied",
        difficulty: 4
      },
      {
        id: "advanced_goal_protection",
        name: "Geavanceerde doelbescherming",
        description: "Complexe doelgebied tactieken",
        difficulty: 5
      },
      {
        id: "masterful_goal_area_defense",
        name: "Meesterlijke doelgebied verdediging",
        description: "Perfecte doelgebied bescherming",
        difficulty: 6
      }
    ]
  },
  "KEEPER_ONDERSTEUNING": {
    name: "Keeper ondersteuning",
    levels: [
      {
        id: "basic_keeper_support",
        name: "Basis keeper ondersteuning",
        description: "Eenvoudige keeper hulp",
        difficulty: 1
      },
      {
        id: "goalkeeper_communication",
        name: "Keeper communicatie",
        description: "Communicatie met keeper",
        difficulty: 2
      },
      {
        id: "coordinated_keeper_defense",
        name: "Gecoördineerde keeper verdediging",
        description: "Samenwerking met keeper",
        difficulty: 3
      },
      {
        id: "keeper_coverage_support",
        name: "Keeper dekking ondersteuning",
        description: "Ondersteuning bij keeper acties",
        difficulty: 4
      },
      {
        id: "advanced_keeper_coordination",
        name: "Geavanceerde keeper coördinatie",
        description: "Complexe keeper samenwerking",
        difficulty: 5
      },
      {
        id: "masterful_keeper_support",
        name: "Meesterlijke keeper ondersteuning",
        description: "Perfecte keeper ondersteuning",
        difficulty: 6
      }
    ]
  },
  "LAATSTE_MAN_VERDEDIGING": {
    name: "Laatste man verdediging",
    levels: [
      {
        id: "basic_last_man_defense",
        name: "Basis laatste man verdediging",
        description: "Eenvoudige laatste verdediger rol",
        difficulty: 1
      },
      {
        id: "sweeper_positioning",
        name: "Sweeper positionering",
        description: "Juiste laatste man posities",
        difficulty: 2
      },
      {
        id: "last_line_organization",
        name: "Laatste linie organisatie",
        description: "Organisatie van laatste verdediging",
        difficulty: 3
      },
      {
        id: "emergency_defending",
        name: "Noodverdediging",
        description: "Verdediging in noodsituaties",
        difficulty: 4
      },
      {
        id: "advanced_last_man_tactics",
        name: "Geavanceerde laatste man tactieken",
        description: "Complexe laatste verdediger rol",
        difficulty: 5
      },
      {
        id: "masterful_last_man_defense",
        name: "Meesterlijke laatste man verdediging",
        description: "Perfecte laatste verdediging",
        difficulty: 6
      }
    ]
  },
  "CRUCIALE_INTERVENTIES": {
    name: "Cruciale interventies",
    levels: [
      {
        id: "basic_interventions",
        name: "Basis interventies",
        description: "Eenvoudige cruciale acties",
        difficulty: 1
      },
      {
        id: "timely_interventions",
        name: "Tijdige interventies",
        description: "Interventies op het juiste moment",
        difficulty: 2
      },
      {
        id: "decisive_defending",
        name: "Beslissend verdedigen",
        description: "Beslissende defensieve acties",
        difficulty: 3
      },
      {
        id: "game_saving_interventions",
        name: "Wedstrijd reddende interventies",
        description: "Cruciale wedstrijd reddende acties",
        difficulty: 4
      },
      {
        id: "advanced_crisis_management",
        name: "Geavanceerd crisis management",
        description: "Complexe crisis afhandeling",
        difficulty: 5
      },
      {
        id: "masterful_interventions",
        name: "Meesterlijke interventies",
        description: "Perfecte cruciale interventies",
        difficulty: 6
      }
    ]
  },
  "DEFENSIEVE_REDDING": {
    name: "Defensieve redding",
    levels: [
      {
        id: "basic_defensive_saves",
        name: "Basis defensieve reddingen",
        description: "Eenvoudige defensieve reddingen",
        difficulty: 1
      },
      {
        id: "goal_line_clearances",
        name: "Doellijn wegwerkingen",
        description: "Wegwerken vanaf de doellijn",
        difficulty: 2
      },
      {
        id: "desperate_defending",
        name: "Wanhopig verdedigen",
        description: "Defensieve acties in nood",
        difficulty: 3
      },
      {
        id: "heroic_defensive_actions",
        name: "Heroïsche defensieve acties",
        description: "Uitzonderlijke defensieve reddingen",
        difficulty: 4
      },
      {
        id: "advanced_defensive_saves",
        name: "Geavanceerde defensieve reddingen",
        description: "Complexe defensieve reddingsacties",
        difficulty: 5
      },
      {
        id: "masterful_defensive_saves",
        name: "Meesterlijke defensieve reddingen",
        description: "Perfecte defensieve reddingen",
        difficulty: 6
      }
    ]
  },
  "DOELLIJN_BESCHERMING": {
    name: "Doellijn bescherming",
    levels: [
      {
        id: "basic_goal_line_protection",
        name: "Basis doellijn bescherming",
        description: "Eenvoudige doellijn verdediging",
        difficulty: 1
      },
      {
        id: "goal_line_positioning",
        name: "Doellijn positionering",
        description: "Juiste posities op doellijn",
        difficulty: 2
      },
      {
        id: "goal_line_clearance_technique",
        name: "Doellijn wegwerk techniek",
        description: "Technieken voor doellijn wegwerken",
        difficulty: 3
      },
      {
        id: "coordinated_goal_line_defense",
        name: "Gecoördineerde doellijn verdediging",
        description: "Samenwerking bij doellijn verdediging",
        difficulty: 4
      },
      {
        id: "advanced_goal_line_tactics",
        name: "Geavanceerde doellijn tactieken",
        description: "Complexe doellijn strategieën",
        difficulty: 5
      },
      {
        id: "masterful_goal_line_protection",
        name: "Meesterlijke doellijn bescherming",
        description: "Perfecte doellijn bescherming",
        difficulty: 6
      }
    ]
  },

  // Map B- element names to their key names for depth data
  "MAN_2_MAN": {
    name: "Man 2 man",
    levels: [
      {
        id: "basic_man_to_man",
        name: "Basis man tegen man",
        description: "Eenvoudige man dekking",
        difficulty: 1
      },
      {
        id: "consistent_man_marking",
        name: "Consistente man dekking",
        description: "Betrouwbare man tegen man verdediging",
        difficulty: 2
      },
      {
        id: "physical_man_marking",
        name: "Fysieke man dekking",
        description: "Fysiek contact in man dekking",
        difficulty: 3
      },
      {
        id: "intelligent_man_marking",
        name: "Intelligente man dekking",
        description: "Slimme man tegen man verdediging",
        difficulty: 4
      },
      {
        id: "advanced_man_marking",
        name: "Geavanceerde man dekking",
        description: "Complexe man tegen man systemen",
        difficulty: 5
      },
      {
        id: "masterful_man_marking",
        name: "Meesterlijke man dekking",
        description: "Perfecte man tegen man verdediging",
        difficulty: 6
      }
    ]
  },
  "SANDWICH": {
    name: "Sandwich",
    levels: [
      {
        id: "basic_sandwich_pressure",
        name: "Basis sandwich druk",
        description: "Eenvoudige sandwich verdediging",
        difficulty: 1
      },
      {
        id: "coordinated_sandwich",
        name: "Gecoördineerde sandwich",
        description: "Samenwerking in sandwich druk",
        difficulty: 2
      },
      {
        id: "timing_sandwich_pressure",
        name: "Timing sandwich druk",
        description: "Juiste timing voor sandwich",
        difficulty: 3
      },
      {
        id: "effective_sandwich_technique",
        name: "Effectieve sandwich techniek",
        description: "Effectieve sandwich uitvoering",
        difficulty: 4
      },
      {
        id: "advanced_sandwich_tactics",
        name: "Geavanceerde sandwich tactieken",
        description: "Complexe sandwich strategieën",
        difficulty: 5
      },
      {
        id: "masterful_sandwich",
        name: "Meesterlijke sandwich",
        description: "Perfecte sandwich verdediging",
        difficulty: 6
      }
    ]
  },
  "TWEE_DRIE_JOBS": {
    name: "2-3 jobs",
    levels: [
      {
        id: "basic_multiple_jobs",
        name: "Basis meerdere taken",
        description: "Eenvoudige 2-3 taken uitvoering",
        difficulty: 1
      },
      {
        id: "coordinated_job_execution",
        name: "Gecoördineerde taak uitvoering",
        description: "Samenwerking in meerdere taken",
        difficulty: 2
      },
      {
        id: "efficient_job_switching",
        name: "Efficiënt taak wisselen",
        description: "Snel wisselen tussen taken",
        difficulty: 3
      },
      {
        id: "simultaneous_job_management",
        name: "Gelijktijdig taak beheer",
        description: "Meerdere taken tegelijk beheren",
        difficulty: 4
      },
      {
        id: "advanced_job_coordination",
        name: "Geavanceerde taak coördinatie",
        description: "Complexe taak coördinatie",
        difficulty: 5
      },
      {
        id: "masterful_multitasking",
        name: "Meesterlijke multitasking",
        description: "Perfecte beheersing van meerdere taken",
        difficulty: 6
      }
    ]
  },
  "INTERCEPTIE": {
    name: "Interceptie",
    levels: [
      {
        id: "basic_interception",
        name: "Basis interceptie",
        description: "Eenvoudige balonderbreking",
        difficulty: 1
      },
      {
        id: "anticipating_interception",
        name: "Anticiperende interceptie",
        description: "Voorspellen en onderbreken",
        difficulty: 2
      },
      {
        id: "aggressive_interception",
        name: "Agressieve interceptie",
        description: "Actieve balverovering",
        difficulty: 3
      },
      {
        id: "intelligent_interception",
        name: "Intelligente interceptie",
        description: "Slimme bal onderbreking",
        difficulty: 4
      },
      {
        id: "advanced_interception_techniques",
        name: "Geavanceerde interceptie technieken",
        description: "Complexe interceptie methoden",
        difficulty: 5
      },
      {
        id: "masterful_interception",
        name: "Meesterlijke interceptie",
        description: "Perfecte balonderbreking",
        difficulty: 6
      }
    ]
  },
  "DRUKFORMATIES": {
    name: "Drukformaties",
    levels: [
      {
        id: "basic_pressure_formations",
        name: "Basis druk formaties",
        description: "Eenvoudige druk opstellingen",
        difficulty: 1
      },
      {
        id: "coordinated_pressure_shapes",
        name: "Gecoördineerde druk vormen",
        description: "Samenwerking in druk formaties",
        difficulty: 2
      },
      {
        id: "dynamic_pressure_formations",
        name: "Dynamische druk formaties",
        description: "Flexibele druk opstellingen",
        difficulty: 3
      },
      {
        id: "tactical_pressure_systems",
        name: "Tactische druk systemen",
        description: "Strategische druk formaties",
        difficulty: 4
      },
      {
        id: "advanced_pressure_formations",
        name: "Geavanceerde druk formaties",
        description: "Complexe druk systemen",
        difficulty: 5
      },
      {
        id: "masterful_pressure_formations",
        name: "Meesterlijke druk formaties",
        description: "Perfecte druk organisatie",
        difficulty: 6
      }
    ]
  },
  "VERMIJD_DE_EINDPAS": {
    name: "Vermijd de eindpas",
    levels: [
      {
        id: "basic_final_pass_prevention",
        name: "Basis eindpas voorkoming",
        description: "Eenvoudige eindpas blokkering",
        difficulty: 1
      },
      {
        id: "anticipating_final_pass",
        name: "Anticiperen eindpas",
        description: "Voorspellen van eindpasses",
        difficulty: 2
      },
      {
        id: "cutting_passing_lanes",
        name: "Passlijnnen doorsnijden",
        description: "Actief passlijnnen afsluiten",
        difficulty: 3
      },
      {
        id: "intelligent_pass_prevention",
        name: "Intelligente pas voorkoming",
        description: "Slimme eindpas preventie",
        difficulty: 4
      },
      {
        id: "advanced_pass_disruption",
        name: "Geavanceerde pas verstoring",
        description: "Complexe eindpas blokkering",
        difficulty: 5
      },
      {
        id: "masterful_pass_prevention",
        name: "Meesterlijke pas voorkoming",
        description: "Perfecte eindpas preventie",
        difficulty: 6
      }
    ]
  },
  "VERMIJD_LANGE_BAL_DIEPE_BAL": {
    name: "Vermijd lange bal, diepe bal",
    levels: [
      {
        id: "basic_long_ball_prevention",
        name: "Basis lange bal voorkoming",
        description: "Eenvoudige lange bal blokkering",
        difficulty: 1
      },
      {
        id: "anticipating_deep_balls",
        name: "Anticiperen diepe ballen",
        description: "Voorspellen van diepe passes",
        difficulty: 2
      },
      {
        id: "cutting_long_pass_options",
        name: "Lange pas opties doorsnijden",
        description: "Lange passlijnnen afsluiten",
        difficulty: 3
      },
      {
        id: "intelligent_deep_ball_prevention",
        name: "Intelligente diepe bal voorkoming",
        description: "Slimme diepe bal preventie",
        difficulty: 4
      },
      {
        id: "advanced_long_ball_disruption",
        name: "Geavanceerde lange bal verstoring",
        description: "Complexe lange bal blokkering",
        difficulty: 5
      },
      {
        id: "masterful_deep_ball_prevention",
        name: "Meesterlijke diepe bal voorkoming",
        description: "Perfecte lange bal preventie",
        difficulty: 6
      }
    ]
  },
  "VERMIJD_KRUISPAS_ZWAKKE_ZONE": {
    name: "Vermijd kruispas, zwakke zone",
    levels: [
      {
        id: "basic_cross_pass_prevention",
        name: "Basis kruispas voorkoming",
        description: "Eenvoudige kruispas blokkering",
        difficulty: 1
      },
      {
        id: "identifying_weak_zones",
        name: "Zwakke zones identificeren",
        description: "Herkennen van zwakke plekken",
        difficulty: 2
      },
      {
        id: "covering_weak_areas",
        name: "Zwakke gebieden dekken",
        description: "Actief zwakke zones beschermen",
        difficulty: 3
      },
      {
        id: "intelligent_zone_coverage",
        name: "Intelligente zone dekking",
        description: "Slimme zwakke zone preventie",
        difficulty: 4
      },
      {
        id: "advanced_cross_prevention",
        name: "Geavanceerde kruis preventie",
        description: "Complexe kruispas blokkering",
        difficulty: 5
      },
      {
        id: "masterful_zone_protection",
        name: "Meesterlijke zone bescherming",
        description: "Perfecte zwakke zone dekking",
        difficulty: 6
      }
    ]
  },


  // TEAMTACTISCH B- COMPACT VERDEDIGEN Elements (mapping names)
  "COMPACTE_RUIMTE": {
    name: "Compacte ruimte",
    levels: [
      {
        id: "basic_compact_space",
        name: "Basis compacte ruimte",
        description: "Eenvoudige ruimte comprimering",
        difficulty: 1
      },
      {
        id: "maintaining_compact_space",
        name: "Compacte ruimte behouden",
        description: "Consistente ruimte beheersing",
        difficulty: 2
      },
      {
        id: "dynamic_space_compression",
        name: "Dynamische ruimte compressie",
        description: "Flexibele ruimte aanpassing",
        difficulty: 3
      },
      {
        id: "intelligent_space_management",
        name: "Intelligente ruimte beheer",
        description: "Slimme ruimte organisatie",
        difficulty: 4
      },
      {
        id: "advanced_compact_systems",
        name: "Geavanceerde compacte systemen",
        description: "Complexe ruimte beheersing",
        difficulty: 5
      },
      {
        id: "masterful_space_control",
        name: "Meesterlijke ruimte controle",
        description: "Perfecte compacte ruimte",
        difficulty: 6
      }
    ]
  },
  "DRUK_ZETTEN_EN_DEKKING_GEVEN": {
    name: "Druk zetten en dekking geven",
    levels: [
      {
        id: "basic_pressure_and_cover",
        name: "Basis druk en dekking",
        description: "Eenvoudige druk met dekking",
        difficulty: 1
      },
      {
        id: "coordinated_pressure_cover",
        name: "Gecoördineerde druk dekking",
        description: "Samenwerking druk en dekking",
        difficulty: 2
      },
      {
        id: "balanced_pressure_covering",
        name: "Gebalanceerde druk dekking",
        description: "Evenwicht tussen druk en dekking",
        difficulty: 3
      },
      {
        id: "intelligent_pressure_support",
        name: "Intelligente druk ondersteuning",
        description: "Slimme druk en dekking combinatie",
        difficulty: 4
      },
      {
        id: "advanced_pressure_cover_systems",
        name: "Geavanceerde druk dekking systemen",
        description: "Complexe druk en dekking organisatie",
        difficulty: 5
      },
      {
        id: "masterful_pressure_covering",
        name: "Meesterlijke druk dekking",
        description: "Perfecte druk en dekking uitvoering",
        difficulty: 6
      }
    ]
  },
  "SCHADUWEN": {
    name: "Schaduwen",
    levels: [
      {
        id: "basic_shadowing",
        name: "Basis schaduwen",
        description: "Eenvoudige schaduw verdediging",
        difficulty: 1
      },
      {
        id: "consistent_shadowing",
        name: "Consistente schaduwen",
        description: "Betrouwbare schaduw dekking",
        difficulty: 2
      },
      {
        id: "intelligent_shadowing",
        name: "Intelligente schaduwen",
        description: "Slimme schaduw positionering",
        difficulty: 3
      },
      {
        id: "anticipatory_shadowing",
        name: "Anticiperend schaduwen",
        description: "Voorspellende schaduw verdediging",
        difficulty: 4
      },
      {
        id: "advanced_shadowing_techniques",
        name: "Geavanceerde schaduw technieken",
        description: "Complexe schaduw methoden",
        difficulty: 5
      },
      {
        id: "masterful_shadowing",
        name: "Meesterlijke schaduwen",
        description: "Perfecte schaduw verdediging",
        difficulty: 6
      }
    ]
  },
  "AFSTAND_TOV_TEGENSTREVER": {
    name: "Afstand tov tegenstrever",
    levels: [
      {
        id: "basic_distance_management",
        name: "Basis afstand beheer",
        description: "Eenvoudige afstand tot tegenstander",
        difficulty: 1
      },
      {
        id: "optimal_defensive_distance",
        name: "Optimale defensieve afstand",
        description: "Juiste afstand voor verdediging",
        difficulty: 2
      },
      {
        id: "adaptive_distance_control",
        name: "Adaptieve afstand controle",
        description: "Flexibele afstand aanpassing",
        difficulty: 3
      },
      {
        id: "intelligent_spacing",
        name: "Intelligente tussenruimte",
        description: "Slimme afstand beheersing",
        difficulty: 4
      },
      {
        id: "advanced_distance_tactics",
        name: "Geavanceerde afstand tactieken",
        description: "Complexe afstand strategieën",
        difficulty: 5
      },
      {
        id: "masterful_distance_control",
        name: "Meesterlijke afstand controle",
        description: "Perfecte afstand beheersing",
        difficulty: 6
      }
    ]
  },
  "HOOG_BLOK": {
    name: "Hoog blok",
    levels: [
      {
        id: "basic_high_block",
        name: "Basis hoog blok",
        description: "Eenvoudige hoge defensieve lijn",
        difficulty: 1
      },
      {
        id: "coordinated_high_line",
        name: "Gecoördineerde hoge lijn",
        description: "Samenwerking in hoog blok",
        difficulty: 2
      },
      {
        id: "aggressive_high_pressing",
        name: "Agressief hoog pressing",
        description: "Actieve hoge druk",
        difficulty: 3
      },
      {
        id: "intelligent_high_block",
        name: "Intelligent hoog blok",
        description: "Slimme hoge verdediging",
        difficulty: 4
      },
      {
        id: "advanced_high_line_tactics",
        name: "Geavanceerde hoge lijn tactieken",
        description: "Complexe hoog blok strategieën",
        difficulty: 5
      },
      {
        id: "masterful_high_block",
        name: "Meesterlijk hoog blok",
        description: "Perfecte hoge verdediging",
        difficulty: 6
      }
    ]
  },
  "BUITENSPELVAL_LIJN": {
    name: "Buitenspelval + lijn",
    levels: [
      {
        id: "basic_offside_trap",
        name: "Basis buitenspelval",
        description: "Eenvoudige offside val",
        difficulty: 1
      },
      {
        id: "coordinated_offside_line",
        name: "Gecoördineerde offside lijn",
        description: "Samenwerking in offside val",
        difficulty: 2
      },
      {
        id: "timing_offside_trap",
        name: "Timing offside val",
        description: "Juiste timing voor offside",
        difficulty: 3
      },
      {
        id: "intelligent_offside_tactics",
        name: "Intelligente offside tactieken",
        description: "Slimme offside strategieën",
        difficulty: 4
      },
      {
        id: "advanced_offside_systems",
        name: "Geavanceerde offside systemen",
        description: "Complexe offside organisatie",
        difficulty: 5
      },
      {
        id: "masterful_offside_trap",
        name: "Meesterlijke offside val",
        description: "Perfecte offside uitvoering",
        difficulty: 6
      }
    ]
  },
  "KANTELEN_VAN_HET_BLOK": {
    name: "Kantelen van het blok",
    levels: [
      {
        id: "basic_block_shifting",
        name: "Basis blok kantelen",
        description: "Eenvoudige blok beweging",
        difficulty: 1
      },
      {
        id: "coordinated_block_tilting",
        name: "Gecoördineerd blok kantelen",
        description: "Samenwerking in blok beweging",
        difficulty: 2
      },
      {
        id: "fluid_block_adjustment",
        name: "Vloeiende blok aanpassing",
        description: "Soepele blok kanteling",
        difficulty: 3
      },
      {
        id: "intelligent_block_positioning",
        name: "Intelligente blok positionering",
        description: "Slimme blok kanteling",
        difficulty: 4
      },
      {
        id: "advanced_block_dynamics",
        name: "Geavanceerde blok dynamiek",
        description: "Complexe blok bewegingen",
        difficulty: 5
      },
      {
        id: "masterful_block_tilting",
        name: "Meesterlijk blok kantelen",
        description: "Perfecte blok beweging",
        difficulty: 6
      }
    ]
  },
  "DM_SCHUIFT_MEE": {
    name: "DM schuift mee",
    levels: [
      {
        id: "basic_dm_movement",
        name: "Basis DM beweging",
        description: "Eenvoudige middenvelder beweging",
        difficulty: 1
      },
      {
        id: "coordinated_dm_shifting",
        name: "Gecoördineerde DM verschuiving",
        description: "Samenwerking met DM beweging",
        difficulty: 2
      },
      {
        id: "intelligent_dm_positioning",
        name: "Intelligente DM positionering",
        description: "Slimme middenvelder posities",
        difficulty: 3
      },
      {
        id: "dynamic_dm_support",
        name: "Dynamische DM ondersteuning",
        description: "Flexibele DM beweging",
        difficulty: 4
      },
      {
        id: "advanced_dm_coordination",
        name: "Geavanceerde DM coördinatie",
        description: "Complexe DM samenwerking",
        difficulty: 5
      },
      {
        id: "masterful_dm_movement",
        name: "Meesterlijke DM beweging",
        description: "Perfecte DM coördinatie",
        difficulty: 6
      }
    ]
  },
  "BEHEER_VAN_DE_RUIMTES": {
    name: "Beheer van de ruimtes",
    levels: [
      {
        id: "basic_space_management",
        name: "Basis ruimte beheer",
        description: "Eenvoudige ruimte controle",
        difficulty: 1
      },
      {
        id: "systematic_space_control",
        name: "Systematische ruimte controle",
        description: "Georganiseerde ruimte beheersing",
        difficulty: 2
      },
      {
        id: "dynamic_space_management",
        name: "Dynamische ruimte beheer",
        description: "Flexibele ruimte aanpassing",
        difficulty: 3
      },
      {
        id: "intelligent_space_organization",
        name: "Intelligente ruimte organisatie",
        description: "Slimme ruimte verdeling",
        difficulty: 4
      },
      {
        id: "advanced_spatial_control",
        name: "Geavanceerde ruimtelijke controle",
        description: "Complexe ruimte strategieën",
        difficulty: 5
      },
      {
        id: "masterful_space_management",
        name: "Meesterlijk ruimte beheer",
        description: "Perfecte ruimte beheersing",
        difficulty: 6
      }
    ]
  },

  // BESCHERMEN VAN HET DOEL Elements
  "DEKKING": {
    name: "Dekking",
    levels: [
      {
        id: "basic_covering",
        name: "Basis dekking",
        description: "Eenvoudige dekking technieken",
        difficulty: 1
      },
      {
        id: "consistent_cover_support",
        name: "Consistente dekking ondersteuning",
        description: "Betrouwbare dekking",
        difficulty: 2
      },
      {
        id: "intelligent_covering",
        name: "Intelligente dekking",
        description: "Slimme dekking posities",
        difficulty: 3
      },
      {
        id: "coordinated_cover_system",
        name: "Gecoördineerd dekking systeem",
        description: "Teamwerk in dekking",
        difficulty: 4
      },
      {
        id: "advanced_covering_techniques",
        name: "Geavanceerde dekking technieken",
        description: "Complexe dekking methoden",
        difficulty: 5
      },
      {
        id: "masterful_covering",
        name: "Meesterlijke dekking",
        description: "Perfecte dekking uitvoering",
        difficulty: 6
      }
    ]
  },
  "VERANDEREN_VAN_DEKKING": {
    name: "Veranderen van dekking",
    levels: [
      {
        id: "basic_cover_switching",
        name: "Basis dekking wisselen",
        description: "Eenvoudige dekking wisseling",
        difficulty: 1
      },
      {
        id: "smooth_cover_transitions",
        name: "Soepele dekking overgangen",
        description: "Vloeiende dekking wisseling",
        difficulty: 2
      },
      {
        id: "intelligent_cover_changes",
        name: "Intelligente dekking veranderingen",
        description: "Slimme dekking aanpassingen",
        difficulty: 3
      },
      {
        id: "coordinated_cover_switching",
        name: "Gecoördineerde dekking wisseling",
        description: "Teamwerk in dekking verandering",
        difficulty: 4
      },
      {
        id: "advanced_cover_transitions",
        name: "Geavanceerde dekking overgangen",
        description: "Complexe dekking wisseling",
        difficulty: 5
      },
      {
        id: "masterful_cover_switching",
        name: "Meesterlijke dekking wisseling",
        description: "Perfecte dekking verandering",
        difficulty: 6
      }
    ]
  },

  // OMSCH B-/B+ TEGENAANVAL Elements
  "VIJF_S_IN_DE_16": {
    name: "5S in de 16",
    levels: [
      {
        id: "basic_5s_in_box",
        name: "Basis 5S in de 16",
        description: "Eenvoudige snelle aanval in strafschopgebied",
        difficulty: 1
      },
      {
        id: "coordinated_5s_attack",
        name: "Gecoördineerde 5S aanval",
        description: "Samenwerking in snelle 16-aanval",
        difficulty: 2
      },
      {
        id: "intelligent_5s_timing",
        name: "Intelligente 5S timing",
        description: "Slimme timing voor 5-seconden aanval",
        difficulty: 3
      },
      {
        id: "high_speed_5s_execution",
        name: "Hoge snelheid 5S uitvoering",
        description: "Snelle uitvoering van 5S tactiek",
        difficulty: 4
      },
      {
        id: "advanced_5s_combinations",
        name: "Geavanceerde 5S combinaties",
        description: "Complexe 5S aanvallende combinaties",
        difficulty: 5
      },
      {
        id: "masterful_5s_attack",
        name: "Meesterlijke 5S aanval",
        description: "Perfecte 5-seconden strafschopgebied aanval",
        difficulty: 6
      }
    ]
  },
  "SCHUIF_MEE_IN": {
    name: "Schuif mee in",
    levels: [
      {
        id: "basic_sliding_movement",
        name: "Basis meeschuiven",
        description: "Eenvoudige meeschuivende beweging",
        difficulty: 1
      },
      {
        id: "coordinated_sliding_in",
        name: "Gecoördineerd inschuiven",
        description: "Samenwerking in meeschuivende beweging",
        difficulty: 2
      },
      {
        id: "intelligent_sliding_timing",
        name: "Intelligente schuif timing",
        description: "Slimme timing voor inschuiven",
        difficulty: 3
      },
      {
        id: "dynamic_sliding_support",
        name: "Dynamische schuif ondersteuning",
        description: "Flexibele meeschuivende ondersteuning",
        difficulty: 4
      },
      {
        id: "advanced_sliding_tactics",
        name: "Geavanceerde schuif tactieken",
        description: "Complexe meeschuivende strategieën",
        difficulty: 5
      },
      {
        id: "masterful_sliding_movement",
        name: "Meesterlijke schuif beweging",
        description: "Perfecte meeschuivende beweging",
        difficulty: 6
      }
    ]
  },
  "LOOP_IN_DE_RUIMTE": {
    name: "Loop in de ruimte",
    levels: [
      {
        id: "basic_space_running",
        name: "Basis ruimte lopen",
        description: "Eenvoudige loops in open ruimte",
        difficulty: 1
      },
      {
        id: "intelligent_space_finding",
        name: "Intelligente ruimte vinden",
        description: "Slimme ruimte herkenning en benutten",
        difficulty: 2
      },
      {
        id: "timing_space_runs",
        name: "Timing ruimte loops",
        description: "Juiste timing voor ruimte loops",
        difficulty: 3
      },
      {
        id: "explosive_space_movement",
        name: "Explosieve ruimte beweging",
        description: "Krachtige beweging in open ruimte",
        difficulty: 4
      },
      {
        id: "advanced_space_exploitation",
        name: "Geavanceerde ruimte exploitatie",
        description: "Complexe ruimte benutten strategieën",
        difficulty: 5
      },
      {
        id: "masterful_space_running",
        name: "Meesterlijke ruimte lopen",
        description: "Perfecte ruimte benutten en timing",
        difficulty: 6
      }
    ]
  },
  "SPEEL_DIEP": {
    name: "Speel diep",
    levels: [
      {
        id: "basic_deep_playing",
        name: "Basis diep spelen",
        description: "Eenvoudige diepe passes en beweging",
        difficulty: 1
      },
      {
        id: "accurate_deep_passing",
        name: "Nauwkeurige diepe passing",
        description: "Precieze diepe ballen spelen",
        difficulty: 2
      },
      {
        id: "timing_deep_balls",
        name: "Timing diepe ballen",
        description: "Juiste timing voor diepe passes",
        difficulty: 3
      },
      {
        id: "intelligent_deep_play",
        name: "Intelligente diep spel",
        description: "Slimme diepe spel strategieën",
        difficulty: 4
      },
      {
        id: "advanced_deep_combinations",
        name: "Geavanceerde diepe combinaties",
        description: "Complexe diepe spel combinaties",
        difficulty: 5
      },
      {
        id: "masterful_deep_playing",
        name: "Meesterlijke diep spelen",
        description: "Perfecte diepe spel uitvoering",
        difficulty: 6
      }
    ]
  },

  // OMSCH B-/B+ OP BALBEZIT SPELEN Elements
  "SPEEL_UIT_DE_DRUK_VAN_HET_BLOK": {
    name: "Speel uit de druk van het blok",
    levels: [
      {
        id: "basic_pressure_escape",
        name: "Basis druk ontsnappen",
        description: "Eenvoudige ontsnapping uit druk",
        difficulty: 1
      },
      {
        id: "calm_under_pressure",
        name: "Kalm onder druk",
        description: "Behouden van rust onder druk",
        difficulty: 2
      },
      {
        id: "intelligent_pressure_solution",
        name: "Intelligente druk oplossing",
        description: "Slimme oplossingen onder druk",
        difficulty: 3
      },
      {
        id: "quick_pressure_release",
        name: "Snelle druk bevrijding",
        description: "Snelle ontsnapping uit druk situaties",
        difficulty: 4
      },
      {
        id: "advanced_pressure_techniques",
        name: "Geavanceerde druk technieken",
        description: "Complexe druk ontsnapping methoden",
        difficulty: 5
      },
      {
        id: "masterful_pressure_escape",
        name: "Meesterlijke druk ontsnapping",
        description: "Perfecte druk situatie beheersing",
        difficulty: 6
      }
    ]
  },
  "VERANDER_VAN_ZIJDE": {
    name: "Verander van zijde",
    levels: [
      {
        id: "basic_side_switching",
        name: "Basis zijde wisselen",
        description: "Eenvoudige bal naar andere zijde",
        difficulty: 1
      },
      {
        id: "accurate_side_change",
        name: "Nauwkeurige zijde verandering",
        description: "Precieze zijde wisseling",
        difficulty: 2
      },
      {
        id: "quick_side_switching",
        name: "Snelle zijde wisseling",
        description: "Snelle overgang naar andere zijde",
        difficulty: 3
      },
      {
        id: "intelligent_side_change",
        name: "Intelligente zijde verandering",
        description: "Slimme zijde wisseling strategieën",
        difficulty: 4
      },
      {
        id: "advanced_side_switching",
        name: "Geavanceerde zijde wisseling",
        description: "Complexe zijde verandering tactieken",
        difficulty: 5
      },
      {
        id: "masterful_side_change",
        name: "Meesterlijke zijde verandering",
        description: "Perfecte zijde wisseling uitvoering",
        difficulty: 6
      }
    ]
  },
  "VERLENG_HET_VELD": {
    name: "Verleng het veld",
    levels: [
      {
        id: "basic_field_stretching",
        name: "Basis veld verlengen",
        description: "Eenvoudige veld uitbreiding",
        difficulty: 1
      },
      {
        id: "coordinated_field_expansion",
        name: "Gecoördineerde veld uitbreiding",
        description: "Samenwerking in veld verlengen",
        difficulty: 2
      },
      {
        id: "intelligent_field_use",
        name: "Intelligente veld gebruik",
        description: "Slimme veld ruimte benutten",
        difficulty: 3
      },
      {
        id: "dynamic_field_stretching",
        name: "Dynamische veld uitrekking",
        description: "Flexibele veld ruimte creatie",
        difficulty: 4
      },
      {
        id: "advanced_field_expansion",
        name: "Geavanceerde veld uitbreiding",
        description: "Complexe veld ruimte strategieën",
        difficulty: 5
      },
      {
        id: "masterful_field_stretching",
        name: "Meesterlijke veld verlengen",
        description: "Perfecte veld ruimte beheersing",
        difficulty: 6
      }
    ]
  },

  // OMSCH B+/B- TEGEN DRUK ZETTEN Elements
  "EEN_TIK_VERDEDIGEND": {
    name: "1 tik verdedigend",
    levels: [
      {
        id: "basic_one_touch_defending",
        name: "Basis 1 tik verdedigend",
        description: "Eenvoudige 1-aanraking verdediging",
        difficulty: 1
      },
      {
        id: "quick_defensive_reaction",
        name: "Snelle defensieve reactie",
        description: "Snelle defensieve 1-tik respons",
        difficulty: 2
      },
      {
        id: "intelligent_one_touch_defense",
        name: "Intelligente 1 tik verdediging",
        description: "Slimme 1-aanraking defensieve actie",
        difficulty: 3
      },
      {
        id: "coordinated_one_touch_defending",
        name: "Gecoördineerde 1 tik verdedigend",
        description: "Teamwerk in 1-tik verdediging",
        difficulty: 4
      },
      {
        id: "advanced_one_touch_tactics",
        name: "Geavanceerde 1 tik tactieken",
        description: "Complexe 1-aanraking verdediging",
        difficulty: 5
      },
      {
        id: "masterful_one_touch_defending",
        name: "Meesterlijke 1 tik verdedigend",
        description: "Perfecte 1-aanraking defensieve beheersing",
        difficulty: 6
      }
    ]
  },
  "ONDERBREEK_EN_HEROVER_DE_BAL": {
    name: "Onderbreek en herover de bal",
    levels: [
      {
        id: "basic_ball_recovery",
        name: "Basis bal heroveringen",
        description: "Eenvoudige bal onderbreking en herwinning",
        difficulty: 1
      },
      {
        id: "aggressive_ball_recovery",
        name: "Agressieve bal heroveringen",
        description: "Actieve bal onderbreking en herwinning",
        difficulty: 2
      },
      {
        id: "intelligent_ball_recovery",
        name: "Intelligente bal heroveringen",
        description: "Slimme bal onderbreking strategieën",
        difficulty: 3
      },
      {
        id: "quick_ball_recovery",
        name: "Snelle bal heroveringen",
        description: "Snelle bal onderbreking en herwinning",
        difficulty: 4
      },
      {
        id: "advanced_recovery_techniques",
        name: "Geavanceerde heroveringen technieken",
        description: "Complexe bal herwinning methoden",
        difficulty: 5
      },
      {
        id: "masterful_ball_recovery",
        name: "Meesterlijke bal heroveringen",
        description: "Perfecte bal onderbreking en herwinning",
        difficulty: 6
      }
    ]
  },

  // OMSCH B+/B- HERVORMEN OPSTELLING Elements
  "BESCHERM_DE_RUIMTE": {
    name: "Bescherm de ruimte",
    levels: [
      {
        id: "basic_space_protection",
        name: "Basis ruimte bescherming",
        description: "Eenvoudige ruimte verdediging",
        difficulty: 1
      },
      {
        id: "systematic_space_protection",
        name: "Systematische ruimte bescherming",
        description: "Georganiseerde ruimte verdediging",
        difficulty: 2
      },
      {
        id: "intelligent_space_protection",
        name: "Intelligente ruimte bescherming",
        description: "Slimme ruimte verdediging strategieën",
        difficulty: 3
      },
      {
        id: "coordinated_space_protection",
        name: "Gecoördineerde ruimte bescherming",
        description: "Teamwerk in ruimte verdediging",
        difficulty: 4
      },
      {
        id: "advanced_space_protection",
        name: "Geavanceerde ruimte bescherming",
        description: "Complexe ruimte verdediging tactieken",
        difficulty: 5
      },
      {
        id: "masterful_space_protection",
        name: "Meesterlijke ruimte bescherming",
        description: "Perfecte ruimte verdediging beheersing",
        difficulty: 6
      }
    ]
  },
  "HOU_DE_BAL_VOOR_JE": {
    name: "Hou de bal voor je",
    levels: [
      {
        id: "basic_ball_screening",
        name: "Basis bal afschermen",
        description: "Eenvoudige bal bescherming",
        difficulty: 1
      },
      {
        id: "effective_ball_screening",
        name: "Effectieve bal afschermen",
        description: "Doeltreffende bal bescherming",
        difficulty: 2
      },
      {
        id: "intelligent_ball_protection",
        name: "Intelligente bal bescherming",
        description: "Slimme bal afschermen technieken",
        difficulty: 3
      },
      {
        id: "physical_ball_screening",
        name: "Fysieke bal afschermen",
        description: "Krachtige bal bescherming",
        difficulty: 4
      },
      {
        id: "advanced_ball_screening",
        name: "Geavanceerde bal afschermen",
        description: "Complexe bal bescherming methoden",
        difficulty: 5
      },
      {
        id: "masterful_ball_protection",
        name: "Meesterlijke bal bescherming",
        description: "Perfecte bal afschermen beheersing",
        difficulty: 6
      }
    ]
  },
  "DOEL_AFSCHERMEN": {
    name: "Doel afschermen",
    levels: [
      {
        id: "basic_goal_screening",
        name: "Basis doel afschermen",
        description: "Eenvoudige doel bescherming",
        difficulty: 1
      },
      {
        id: "coordinated_goal_protection",
        name: "Gecoördineerde doel bescherming",
        description: "Teamwerk in doel afschermen",
        difficulty: 2
      },
      {
        id: "intelligent_goal_screening",
        name: "Intelligente doel afschermen",
        description: "Slimme doel bescherming strategieën",
        difficulty: 3
      },
      {
        id: "effective_goal_protection",
        name: "Effectieve doel bescherming",
        description: "Doeltreffende doel afschermen",
        difficulty: 4
      },
      {
        id: "advanced_goal_screening",
        name: "Geavanceerde doel afschermen",
        description: "Complexe doel bescherming tactieken",
        difficulty: 5
      },
      {
        id: "masterful_goal_protection",
        name: "Meesterlijke doel bescherming",
        description: "Perfecte doel afschermen beheersing",
        difficulty: 6
      }
    ]
  },

  // Keep existing B- elements that were already there
  "BASIS_FORMATIE_BEGRIP": {
    name: "Basis formatie begrip",
    levels: [
      {
        id: "formation_awareness",
        name: "Formatie bewustzijn",
        description: "Begrijpen van eigen positie in formatie",
        difficulty: 1
      },
      {
        id: "formation_discipline",
        name: "Formatie discipline",
        description: "Handhaven van formatie structuur",
        difficulty: 2
      },
      {
        id: "formation_flexibility",
        name: "Formatie flexibiliteit",
        description: "Aanpassen binnen formatie kader",
        difficulty: 3
      },
      {
        id: "formation_transitions",
        name: "Formatie overgangen",
        description: "Soepele overgangen tussen fases",
        difficulty: 4
      },
      {
        id: "advanced_formation_play",
        name: "Geavanceerd formatie spel",
        description: "Complex formatie begrip",
        difficulty: 5
      },
      {
        id: "masterful_formation_understanding",
        name: "Meesterlijk formatie begrip",
        description: "Complete beheersing van formatie concepten",
        difficulty: 6
      }
    ]
  },
  "EENVOUDIGE_PASSINGPATRONEN": {
    name: "Eenvoudige passingpatronen",
    levels: [
      {
        id: "basic_passing_patterns",
        name: "Basis pass patronen",
        description: "Eenvoudige pass combinaties",
        difficulty: 1
      },
      {
        id: "structured_passing",
        name: "Gestructureerd passen",
        description: "Vaste pass routines",
        difficulty: 2
      },
      {
        id: "varied_passing_patterns",
        name: "Gevarieerde pass patronen",
        description: "Verschillende pass opties",
        difficulty: 3
      },
      {
        id: "complex_passing_combinations",
        name: "Complexe pass combinaties",
        description: "Meerledige pass patronen",
        difficulty: 4
      },
      {
        id: "creative_passing_solutions",
        name: "Creatieve pass oplossingen",
        description: "Innovatieve pass patronen",
        difficulty: 5
      },
      {
        id: "masterful_passing_patterns",
        name: "Meesterlijke pass patronen",
        description: "Perfecte beheersing van alle pass patronen",
        difficulty: 6
      }
    ]
  },
  "COMMUNICATIE_OP_HET_VELD": {
    name: "Communicatie op het veld",
    levels: [
      {
        id: "basic_communication",
        name: "Basis communicatie",
        description: "Eenvoudige verbale signalen",
        difficulty: 1
      },
      {
        id: "clear_instructions",
        name: "Duidelijke instructies",
        description: "Heldere communicatie naar teamgenoten",
        difficulty: 2
      },
      {
        id: "situational_communication",
        name: "Situationele communicatie",
        description: "Communicatie aangepast aan situatie",
        difficulty: 3
      },
      {
        id: "leadership_communication",
        name: "Leiderschaps communicatie",
        description: "Dirigeren en organiseren van team",
        difficulty: 4
      },
      {
        id: "advanced_tactical_communication",
        name: "Geavanceerde tactische communicatie",
        description: "Complexe tactische instructies",
        difficulty: 5
      },
      {
        id: "masterful_field_communication",
        name: "Meesterlijke veld communicatie",
        description: "Perfecte team communicatie",
        difficulty: 6
      }
    ]
  }
};

export type TeamTactischDepthLevel = {
  id: string;
  name: string;
  description: string;
  difficulty: number;
};

export type TeamTactischElement = {
  name: string;
  levels: TeamTactischDepthLevel[];
};