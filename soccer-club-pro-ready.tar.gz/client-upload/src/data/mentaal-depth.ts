export const mentaalDepth = {
  "CONCENTRATIE": {
    name: "Concentratie",
    levels: [
      {
        id: "basic_concentration",
        name: "Basis concentratie",
        description: "Eenvoudige focus tijdens training",
        difficulty: 1
      },
      {
        id: "sustained_concentration",
        name: "Volgehouden concentratie",
        description: "Langere periodes van focus",
        difficulty: 2
      },
      {
        id: "selective_concentration",
        name: "Selectieve concentratie",
        description: "Focus op relevante aspecten",
        difficulty: 3
      },
      {
        id: "deep_concentration",
        name: "Diepe concentratie",
        description: "Intense focus onder druk",
        difficulty: 4
      },
      {
        id: "adaptive_concentration",
        name: "Adaptieve concentratie",
        description: "Flexibele focus aanpassing",
        difficulty: 5
      },
      {
        id: "peak_concentration",
        name: "Piek concentratie",
        description: "Maximale focus in alle situaties",
        difficulty: 6
      }
    ]
  },
  "RUSTIG_VS_ONRUSTIG": {
    name: "Rustig vs onrustig",
    levels: [
      {
        id: "basic_composure",
        name: "Basis kalmte",
        description: "Eenvoudige rust behouden",
        difficulty: 1
      },
      {
        id: "calm_under_pressure",
        name: "Kalm onder druk",
        description: "Rust bewaren in stress situaties",
        difficulty: 2
      },
      {
        id: "emotional_balance",
        name: "Emotioneel evenwicht",
        description: "Stabiele emotionele controle",
        difficulty: 3
      },
      {
        id: "crisis_management",
        name: "Crisis beheersing",
        description: "Kalmte tijdens moeilijke momenten",
        difficulty: 4
      },
      {
        id: "stress_resilience",
        name: "Stress weerstand",
        description: "Weerstand tegen hoge druk",
        difficulty: 5
      },
      {
        id: "unshakeable_composure",
        name: "Onwrikbare kalmte",
        description: "Perfecte rust in alle omstandigheden",
        difficulty: 6
      }
    ]
  },
  "SPONTANITEIT": {
    name: "Spontaniteit",
    levels: [
      {
        id: "basic_spontaneity",
        name: "Basis spontaniteit",
        description: "Eenvoudige spontane acties",
        difficulty: 1
      },
      {
        id: "creative_spontaneity",
        name: "Creatieve spontaniteit",
        description: "Originele spontane oplossingen",
        difficulty: 2
      },
      {
        id: "tactical_spontaneity",
        name: "Tactische spontaniteit",
        description: "Spontane tactische keuzes",
        difficulty: 3
      },
      {
        id: "intelligent_spontaneity",
        name: "Intelligente spontaniteit",
        description: "Slimme spontane beslissingen",
        difficulty: 4
      },
      {
        id: "masterful_spontaneity",
        name: "Meesterlijke spontaniteit",
        description: "Perfecte spontane creativiteit",
        difficulty: 5
      },
      {
        id: "genius_spontaneity",
        name: "Geniale spontaniteit",
        description: "Uitzonderlijke spontane momenten",
        difficulty: 6
      }
    ]
  },
  "EGOISTISCH": {
    name: "Egoistisch",
    levels: [
      {
        id: "team_awareness",
        name: "Team bewustzijn",
        description: "Bewustzijn van teambelang",
        difficulty: 1
      },
      {
        id: "balanced_decisions",
        name: "Gebalanceerde beslissingen",
        description: "Evenwicht tussen persoonlijk en team",
        difficulty: 2
      },
      {
        id: "selfless_play",
        name: "Onzelfzuchtig spel",
        description: "Team belang voorop stellen",
        difficulty: 3
      },
      {
        id: "team_first_mentality",
        name: "Team-first mentaliteit",
        description: "Team succes boven persoonlijke glorie",
        difficulty: 4
      },
      {
        id: "ultimate_team_player",
        name: "Ultieme team speler",
        description: "Volledig opgaan in team doelen",
        difficulty: 5
      },
      {
        id: "team_leadership",
        name: "Team leiderschap",
        description: "Anderen inspireren tot teamspel",
        difficulty: 6
      }
    ]
  },
  "AFLEIDING": {
    name: "Afleiding",
    levels: [
      {
        id: "basic_focus_maintenance",
        name: "Basis focus behoud",
        description: "Eenvoudige focus behouden",
        difficulty: 1
      },
      {
        id: "distraction_resistance",
        name: "Afleiding weerstand",
        description: "Weerstand tegen externe afleiding",
        difficulty: 2
      },
      {
        id: "selective_attention",
        name: "Selectieve aandacht",
        description: "Focus op relevante informatie",
        difficulty: 3
      },
      {
        id: "tunnel_vision_control",
        name: "Tunnelvisie controle",
        description: "Vermijden van te smalle focus",
        difficulty: 4
      },
      {
        id: "dynamic_attention",
        name: "Dynamische aandacht",
        description: "Flexibele aandacht verdeling",
        difficulty: 5
      },
      {
        id: "perfect_attention_control",
        name: "Perfecte aandacht controle",
        description: "Volledige beheersing van focus",
        difficulty: 6
      }
    ]
  },
  "NABOOTSEN": {
    name: "Nabootsen",
    levels: [
      {
        id: "basic_imitation",
        name: "Basis imitatie",
        description: "Eenvoudige bewegingen nabootsen",
        difficulty: 1
      },
      {
        id: "observational_learning",
        name: "Observationeel leren",
        description: "Leren door observatie",
        difficulty: 2
      },
      {
        id: "skill_adaptation",
        name: "Vaardigheid aanpassing",
        description: "Geobserveerde vaardigheden aanpassen",
        difficulty: 3
      },
      {
        id: "style_integration",
        name: "Stijl integratie",
        description: "Verschillende stijlen combineren",
        difficulty: 4
      },
      {
        id: "creative_adaptation",
        name: "Creatieve aanpassing",
        description: "Creatieve interpretatie van voorbeelden",
        difficulty: 5
      },
      {
        id: "mastery_through_modeling",
        name: "Meesterschap door modellering",
        description: "Perfectie bereiken door nabootsen",
        difficulty: 6
      }
    ]
  },
  "ZELFVERTROUWEN": {
    name: "Zelfvertrouwen",
    levels: [
      {
        id: "basic_confidence",
        name: "Basis zelfvertrouwen",
        description: "Eenvoudig vertrouwen in eigen kunnen",
        difficulty: 1
      },
      {
        id: "stable_confidence",
        name: "Stabiel zelfvertrouwen",
        description: "Consistent vertrouwen in prestaties",
        difficulty: 2
      },
      {
        id: "resilient_confidence",
        name: "Veerkrachtig zelfvertrouwen",
        description: "Vertrouwen behouden na tegenslagen",
        difficulty: 3
      },
      {
        id: "unshakeable_confidence",
        name: "Onwrikbaar zelfvertrouwen",
        description: "Onverstoorde zelfverzekerdheid",
        difficulty: 4
      },
      {
        id: "inspiring_confidence",
        name: "Inspirerend zelfvertrouwen",
        description: "Vertrouwen dat anderen motiveert",
        difficulty: 5
      },
      {
        id: "absolute_confidence",
        name: "Absoluut zelfvertrouwen",
        description: "Volledig vertrouwen in alle situaties",
        difficulty: 6
      }
    ]
  },
  "ZOEKEN_NAAR_BEVESTIGING": {
    name: "Zoeken naar bevestiging",
    levels: [
      {
        id: "self_reliance_development",
        name: "Zelfstandigheid ontwikkeling",
        description: "Minder afhankelijk van externe bevestiging",
        difficulty: 1
      },
      {
        id: "internal_validation",
        name: "Interne validatie",
        description: "Zelfevaluatie en interne bevestiging",
        difficulty: 2
      },
      {
        id: "confidence_independence",
        name: "Vertrouwen onafhankelijkheid",
        description: "Onafhankelijk vertrouwen ontwikkelen",
        difficulty: 3
      },
      {
        id: "self_motivated_performance",
        name: "Zelfgemotiveerde prestatie",
        description: "Presteren zonder externe motivatie",
        difficulty: 4
      },
      {
        id: "intrinsic_motivation",
        name: "Intrinsieke motivatie",
        description: "Motivatie van binnenuit",
        difficulty: 5
      },
      {
        id: "complete_self_sufficiency",
        name: "Volledige zelfvoorziening",
        description: "Totale onafhankelijkheid van externe bevestiging",
        difficulty: 6
      }
    ]
  },
  "INLEVINGSVERMOGEN": {
    name: "Inlevingsvermogen",
    levels: [
      {
        id: "basic_empathy",
        name: "Basis empathie",
        description: "Eenvoudig begrip voor anderen",
        difficulty: 1
      },
      {
        id: "emotional_awareness",
        name: "Emotioneel bewustzijn",
        description: "Herkennen van emoties bij anderen",
        difficulty: 2
      },
      {
        id: "perspective_taking",
        name: "Perspectief innemen",
        description: "Situaties vanuit andermans perspectief zien",
        difficulty: 3
      },
      {
        id: "empathetic_leadership",
        name: "Empathisch leiderschap",
        description: "Leiden met begrip en medeleven",
        difficulty: 4
      },
      {
        id: "deep_understanding",
        name: "Diep begrip",
        description: "Diepgaand begrijpen van anderen",
        difficulty: 5
      },
      {
        id: "intuitive_empathy",
        name: "Intuïtieve empathie",
        description: "Natuurlijk aanvoelen van andermans behoeften",
        difficulty: 6
      }
    ]
  },
  "WINNAARSMENTALITEIT": {
    name: "Winnaarsmentaliteit",
    levels: [
      {
        id: "competitive_spirit",
        name: "Competitieve geest",
        description: "Basis wil om te winnen",
        difficulty: 1
      },
      {
        id: "victory_focus",
        name: "Overwinning focus",
        description: "Consistent streven naar overwinning",
        difficulty: 2
      },
      {
        id: "clutch_performance",
        name: "Beslissende prestatie",
        description: "Presteren in cruciale momenten",
        difficulty: 3
      },
      {
        id: "champion_mindset",
        name: "Kampioen mindset",
        description: "Denken en handelen als een kampioen",
        difficulty: 4
      },
      {
        id: "relentless_pursuit",
        name: "Meedogenloze achtervolging",
        description: "Nooit opgeven tot de overwinning",
        difficulty: 5
      },
      {
        id: "born_winner",
        name: "Geboren winnaar",
        description: "Natuurlijke winnaarsinstincten",
        difficulty: 6
      }
    ]
  },
  "EMOTIONELE_WEERBAARHEID_STABILITEIT": {
    name: "Emotionele weerbaarheid/stabiliteit",
    levels: [
      {
        id: "basic_emotional_stability",
        name: "Basis emotionele stabiliteit",
        description: "Eenvoudige emotionele controle",
        difficulty: 1
      },
      {
        id: "stress_management",
        name: "Stress management",
        description: "Omgaan met stressvolle situaties",
        difficulty: 2
      },
      {
        id: "emotional_resilience",
        name: "Emotionele veerkracht",
        description: "Herstellen van emotionele tegenslagen",
        difficulty: 3
      },
      {
        id: "emotional_intelligence",
        name: "Emotionele intelligentie",
        description: "Slimme emotionele reacties",
        difficulty: 4
      },
      {
        id: "emotional_mastery",
        name: "Emotionele meesterschap",
        description: "Volledige emotionele beheersing",
        difficulty: 5
      },
      {
        id: "emotional_fortress",
        name: "Emotionele vesting",
        description: "Onverstoorde emotionele stabiliteit",
        difficulty: 6
      }
    ]
  },
  "LEERGIERIG": {
    name: "Leergierig",
    levels: [
      {
        id: "basic_curiosity",
        name: "Basis nieuwsgierigheid",
        description: "Eenvoudige wil om te leren",
        difficulty: 1
      },
      {
        id: "active_learning",
        name: "Actief leren",
        description: "Actief zoeken naar nieuwe kennis",
        difficulty: 2
      },
      {
        id: "knowledge_seeking",
        name: "Kennis zoeken",
        description: "Constant streven naar verbetering",
        difficulty: 3
      },
      {
        id: "learning_optimization",
        name: "Leer optimalisatie",
        description: "Efficiënt leerproces ontwikkelen",
        difficulty: 4
      },
      {
        id: "mastery_pursuit",
        name: "Meesterschap nastreven",
        description: "Onophoudelijk streven naar perfectie",
        difficulty: 5
      },
      {
        id: "infinite_learner",
        name: "Oneindige leerling",
        description: "Nooit ophouden met leren en groeien",
        difficulty: 6
      }
    ]
  },
  "DOORZETTINGSVERMOGEN": {
    name: "Doorzettingsvermogen",
    levels: [
      {
        id: "basic_persistence",
        name: "Basis volharding",
        description: "Eenvoudige doorzetting bij moeilijkheden",
        difficulty: 1
      },
      {
        id: "sustained_effort",
        name: "Volgehouden inspanning",
        description: "Langdurige inzet bij uitdagingen",
        difficulty: 2
      },
      {
        id: "obstacle_overcoming",
        name: "Obstakels overwinnen",
        description: "Actief overwinnen van hindernissen",
        difficulty: 3
      },
      {
        id: "relentless_determination",
        name: "Meedogenloze vastberadenheid",
        description: "Onwrikbare vastberadenheid",
        difficulty: 4
      },
      {
        id: "unbreakable_will",
        name: "Onbreekbare wil",
        description: "Nooit opgeven mentaliteit",
        difficulty: 5
      },
      {
        id: "legendary_persistence",
        name: "Legendarische volharding",
        description: "Uitzonderlijke doorzettingskracht",
        difficulty: 6
      }
    ]
  },
  "OMKADERING": {
    name: "Omkadering",
    levels: [
      {
        id: "guidance_acceptance",
        name: "Begeleiding acceptatie",
        description: "Open staan voor begeleiding",
        difficulty: 1
      },
      {
        id: "coaching_responsiveness",
        name: "Coaching ontvankelijkheid",
        description: "Positief reageren op coaching",
        difficulty: 2
      },
      {
        id: "feedback_integration",
        name: "Feedback integratie",
        description: "Feedback effectief toepassen",
        difficulty: 3
      },
      {
        id: "mentorship_utilization",
        name: "Mentorschap benutten",
        description: "Maximaal profiteren van mentoring",
        difficulty: 4
      },
      {
        id: "self_directed_learning",
        name: "Zelfgestuurd leren",
        description: "Zelfstandig ontwikkeling sturen",
        difficulty: 5
      },
      {
        id: "mentor_others",
        name: "Anderen begeleiden",
        description: "Anderen helpen en begeleiden",
        difficulty: 6
      }
    ]
  },
  "MOTIVATIE": {
    name: "Motivatie",
    levels: [
      {
        id: "basic_motivation",
        name: "Basis motivatie",
        description: "Eenvoudige drijfveer om te presteren",
        difficulty: 1
      },
      {
        id: "sustained_motivation",
        name: "Volgehouden motivatie",
        description: "Consistent gemotiveerd blijven",
        difficulty: 2
      },
      {
        id: "intrinsic_drive",
        name: "Intrinsieke drijfveer",
        description: "Motivatie van binnenuit",
        difficulty: 3
      },
      {
        id: "peak_motivation",
        name: "Piek motivatie",
        description: "Maximale motivatie in belangrijke momenten",
        difficulty: 4
      },
      {
        id: "infectious_motivation",
        name: "Aanstekelijke motivatie",
        description: "Anderen motiveren door eigen drive",
        difficulty: 5
      },
      {
        id: "unstoppable_force",
        name: "Onstuitbare kracht",
        description: "Onuitputtelijke motivatie en drive",
        difficulty: 6
      }
    ]
  },
  "INZET": {
    name: "Inzet",
    levels: [
      {
        id: "basic_commitment",
        name: "Basis inzet",
        description: "Eenvoudige toewijding aan taken",
        difficulty: 1
      },
      {
        id: "consistent_effort",
        name: "Consistente inspanning",
        description: "Betrouwbare inzet in alle situaties",
        difficulty: 2
      },
      {
        id: "dedicated_performance",
        name: "Toegewijde prestatie",
        description: "Volledige toewijding aan prestaties",
        difficulty: 3
      },
      {
        id: "total_commitment",
        name: "Totale toewijding",
        description: "100% inzet in alles wat gedaan wordt",
        difficulty: 4
      },
      {
        id: "sacrificial_dedication",
        name: "Opofferende toewijding",
        description: "Bereid zijn offers te brengen",
        difficulty: 5
      },
      {
        id: "ultimate_devotion",
        name: "Ultieme devotie",
        description: "Absolute toewijding aan excellentie",
        difficulty: 6
      }
    ]
  },
  "AMBITIE": {
    name: "Ambitie",
    levels: [
      {
        id: "basic_ambition",
        name: "Basis ambitie",
        description: "Eenvoudige wens om beter te worden",
        difficulty: 1
      },
      {
        id: "goal_setting",
        name: "Doelen stellen",
        description: "Duidelijke doelen formuleren",
        difficulty: 2
      },
      {
        id: "high_aspirations",
        name: "Hoge aspiraties",
        description: "Streven naar hoge doelen",
        difficulty: 3
      },
      {
        id: "visionary_thinking",
        name: "Visionair denken",
        description: "Grootse visies ontwikkelen",
        difficulty: 4
      },
      {
        id: "limitless_ambition",
        name: "Grenzeloze ambitie",
        description: "Geen grenzen kennen in ambities",
        difficulty: 5
      },
      {
        id: "legendary_aspirations",
        name: "Legendarische aspiraties",
        description: "Streven naar historische prestaties",
        difficulty: 6
      }
    ]
  },
  "ZELFREGULERING": {
    name: "Zelfregulering",
    levels: [
      {
        id: "basic_self_control",
        name: "Basis zelfbeheersing",
        description: "Eenvoudige zelfcontrole",
        difficulty: 1
      },
      {
        id: "impulse_management",
        name: "Impuls beheersing",
        description: "Controle over impulsen",
        difficulty: 2
      },
      {
        id: "behavioral_regulation",
        name: "Gedrag regulatie",
        description: "Bewuste gedragscontrole",
        difficulty: 3
      },
      {
        id: "emotional_regulation",
        name: "Emotie regulatie",
        description: "Beheersing van emotionele reacties",
        difficulty: 4
      },
      {
        id: "cognitive_control",
        name: "Cognitieve controle",
        description: "Beheersing van denkprocessen",
        difficulty: 5
      },
      {
        id: "total_self_mastery",
        name: "Totale zelfbeheersing",
        description: "Complete controle over alle aspecten",
        difficulty: 6
      }
    ]
  },
  "VOLHARDING": {
    name: "Volharding",
    levels: [
      {
        id: "basic_perseverance",
        name: "Basis volharding",
        description: "Eenvoudige doorzetting bij tegenslag",
        difficulty: 1
      },
      {
        id: "steady_persistence",
        name: "Gestage volharding",
        description: "Consistent doorgaan ondanks obstakels",
        difficulty: 2
      },
      {
        id: "resilient_continuation",
        name: "Veerkrachtige voortzetting",
        description: "Doorgaan na moeilijke momenten",
        difficulty: 3
      },
      {
        id: "unshakeable_persistence",
        name: "Onwrikbare volharding",
        description: "Niets kan de voortgang stoppen",
        difficulty: 4
      },
      {
        id: "infinite_endurance",
        name: "Oneindige uithouding",
        description: "Grenzeloze doorzettingskracht",
        difficulty: 5
      },
      {
        id: "legendary_tenacity",
        name: "Legendarische vasthoudendheid",
        description: "Uitzonderlijke volharding in alle omstandigheden",
        difficulty: 6
      }
    ]
  },
  "ZELFBEELD": {
    name: "Zelfbeeld",
    levels: [
      {
        id: "basic_self_awareness",
        name: "Basis zelfbewustzijn",
        description: "Eenvoudig begrip van eigen capaciteiten",
        difficulty: 1
      },
      {
        id: "realistic_self_assessment",
        name: "Realistische zelfevaluatie",
        description: "Eerlijke beoordeling van eigen kunnen",
        difficulty: 2
      },
      {
        id: "positive_self_image",
        name: "Positief zelfbeeld",
        description: "Gezond en positief beeld van zichzelf",
        difficulty: 3
      },
      {
        id: "confident_self_perception",
        name: "Zelfverzekerde zelfperceptie",
        description: "Vertrouwen in eigen waarde en kunnen",
        difficulty: 4
      },
      {
        id: "empowered_self_identity",
        name: "Krachtige zelfidentiteit",
        description: "Sterke en stabiele zelfidentiteit",
        difficulty: 5
      },
      {
        id: "authentic_self_mastery",
        name: "Authentieke zelfbeheersing",
        description: "Volledige authenticiteit en zelfacceptatie",
        difficulty: 6
      }
    ]
  },
  "LEERSNELHEID": {
    name: "Leersnelheid",
    levels: [
      {
        id: "basic_learning_pace",
        name: "Basis leertempo",
        description: "Normale snelheid van leren",
        difficulty: 1
      },
      {
        id: "accelerated_learning",
        name: "Versneld leren",
        description: "Sneller nieuwe concepten oppakken",
        difficulty: 2
      },
      {
        id: "rapid_skill_acquisition",
        name: "Snelle vaardigheid verwerving",
        description: "Snel nieuwe vaardigheden ontwikkelen",
        difficulty: 3
      },
      {
        id: "adaptive_learning",
        name: "Adaptief leren",
        description: "Leerstijl aanpassen aan situatie",
        difficulty: 4
      },
      {
        id: "lightning_fast_learning",
        name: "Bliksemsnelle leren",
        description: "Exceptioneel snelle kennisopname",
        difficulty: 5
      },
      {
        id: "genius_level_learning",
        name: "Geniaal leerniveau",
        description: "Uitzonderlijke leersnelheid en begrip",
        difficulty: 6
      }
    ]
  },
  "INZICHT": {
    name: "Inzicht",
    levels: [
      {
        id: "basic_understanding",
        name: "Basis begrip",
        description: "Eenvoudig inzicht in situaties",
        difficulty: 1
      },
      {
        id: "pattern_recognition",
        name: "Patroon herkenning",
        description: "Herkennen van patronen en verbanden",
        difficulty: 2
      },
      {
        id: "deep_insight",
        name: "Diep inzicht",
        description: "Diepgaand begrip van complexe situaties",
        difficulty: 3
      },
      {
        id: "intuitive_understanding",
        name: "Intuïtief begrip",
        description: "Natuurlijk aanvoelen van situaties",
        difficulty: 4
      },
      {
        id: "strategic_insight",
        name: "Strategisch inzicht",
        description: "Begrip van strategische aspecten",
        difficulty: 5
      },
      {
        id: "prophetic_insight",
        name: "Profetisch inzicht",
        description: "Uitzonderlijk vooruitziend begrip",
        difficulty: 6
      }
    ]
  },
  "BESLUITVAARDIGHEID": {
    name: "Besluitvaardigheid",
    levels: [
      {
        id: "basic_decision_making",
        name: "Basis besluitvorming",
        description: "Eenvoudige beslissingen nemen",
        difficulty: 1
      },
      {
        id: "confident_decisions",
        name: "Zelfverzekerde beslissingen",
        description: "Beslissingen nemen met vertrouwen",
        difficulty: 2
      },
      {
        id: "quick_decision_making",
        name: "Snelle besluitvorming",
        description: "Snel en efficiënt beslissingen nemen",
        difficulty: 3
      },
      {
        id: "strategic_decisions",
        name: "Strategische beslissingen",
        description: "Weloverwogen strategische keuzes",
        difficulty: 4
      },
      {
        id: "decisive_leadership",
        name: "Besluitvaardig leiderschap",
        description: "Leiden door sterke besluitvorming",
        difficulty: 5
      },
      {
        id: "intuitive_decision_mastery",
        name: "Intuïtieve besluit meesterschap",
        description: "Perfect besluitvermogen in alle situaties",
        difficulty: 6
      }
    ]
  },
  "LEERVERMOGEN": {
    name: "Leervermogen",
    levels: [
      {
        id: "basic_learning_ability",
        name: "Basis leervermogen",
        description: "Eenvoudige capaciteit om te leren",
        difficulty: 1
      },
      {
        id: "enhanced_comprehension",
        name: "Verbeterd begrip",
        description: "Beter begrijpen van nieuwe concepten",
        difficulty: 2
      },
      {
        id: "advanced_learning",
        name: "Geavanceerd leren",
        description: "Complexe onderwerpen snel beheersen",
        difficulty: 3
      },
      {
        id: "meta_learning",
        name: "Meta leren",
        description: "Leren hoe beter te leren",
        difficulty: 4
      },
      {
        id: "exponential_learning",
        name: "Exponentieel leren",
        description: "Steeds sneller leren door ervaring",
        difficulty: 5
      },
      {
        id: "unlimited_learning_potential",
        name: "Onbeperkt leerpotentieel",
        description: "Grenzeloos vermogen om te leren en groeien",
        difficulty: 6
      }
    ]
  },
  "PERSOONLIJKHEID": {
    name: "Persoonlijkheid",
    levels: [
      {
        id: "personality_awareness",
        name: "Persoonlijkheid bewustzijn",
        description: "Bewustzijn van eigen persoonlijke traits",
        difficulty: 1
      },
      {
        id: "personality_development",
        name: "Persoonlijkheid ontwikkeling",
        description: "Bewuste ontwikkeling van karaktereigenschappen",
        difficulty: 2
      },
      {
        id: "balanced_personality",
        name: "Gebalanceerde persoonlijkheid",
        description: "Evenwichtige persoonlijkheidsontwikkeling",
        difficulty: 3
      },
      {
        id: "charismatic_personality",
        name: "Charismatische persoonlijkheid",
        description: "Aantrekkelijke en inspirerende persoonlijkheid",
        difficulty: 4
      },
      {
        id: "influential_character",
        name: "Invloedrijk karakter",
        description: "Persoonlijkheid die anderen beïnvloedt",
        difficulty: 5
      },
      {
        id: "iconic_personality",
        name: "Iconische persoonlijkheid",
        description: "Unieke en memorable persoonlijke aanwezigheid",
        difficulty: 6
      }
    ]
  },
  "LEIDERSCHAP": {
    name: "Leiderschap",
    levels: [
      {
        id: "basic_leadership",
        name: "Basis leiderschap",
        description: "Eenvoudige leiderschapskwaliteiten",
        difficulty: 1
      },
      {
        id: "team_guidance",
        name: "Team begeleiding",
        description: "Effectief begeleiden van teamgenoten",
        difficulty: 2
      },
      {
        id: "inspirational_leadership",
        name: "Inspirerend leiderschap",
        description: "Anderen motiveren en inspireren",
        difficulty: 3
      },
      {
        id: "strategic_leadership",
        name: "Strategisch leiderschap",
        description: "Leiden met strategische visie",
        difficulty: 4
      },
      {
        id: "transformational_leadership",
        name: "Transformationeel leiderschap",
        description: "Verandering en groei stimuleren",
        difficulty: 5
      },
      {
        id: "legendary_leadership",
        name: "Legendarisch leiderschap",
        description: "Uitzonderlijke leiderschapskwaliteiten",
        difficulty: 6
      }
    ]
  },
  "BETROKKEN": {
    name: "Betrokken",
    levels: [
      {
        id: "basic_engagement",
        name: "Basis betrokkenheid",
        description: "Eenvoudige betrokkenheid bij activiteiten",
        difficulty: 1
      },
      {
        id: "active_participation",
        name: "Actieve participatie",
        description: "Actief deelnemen en bijdragen",
        difficulty: 2
      },
      {
        id: "invested_involvement",
        name: "Geïnvesteerde betrokkenheid",
        description: "Emotioneel geïnvesteerd in resultaten",
        difficulty: 3
      },
      {
        id: "passionate_engagement",
        name: "Gepassioneerde betrokkenheid",
        description: "Passie tonen voor team en doelen",
        difficulty: 4
      },
      {
        id: "total_commitment",
        name: "Totale verbondenheid",
        description: "Volledig verbonden met team en missie",
        difficulty: 5
      },
      {
        id: "heart_and_soul_dedication",
        name: "Hart en ziel toewijding",
        description: "Complete toewijding met hart en ziel",
        difficulty: 6
      }
    ]
  },
  "FOCUS": {
    name: "Focus",
    levels: [
      {
        id: "basic_focus",
        name: "Basis focus",
        description: "Eenvoudige concentratie op taken",
        difficulty: 1
      },
      {
        id: "sustained_attention",
        name: "Volgehouden aandacht",
        description: "Langere periodes van concentratie",
        difficulty: 2
      },
      {
        id: "selective_focus",
        name: "Selectieve focus",
        description: "Focus op belangrijke aspecten",
        difficulty: 3
      },
      {
        id: "intense_concentration",
        name: "Intense concentratie",
        description: "Diepe focus onder alle omstandigheden",
        difficulty: 4
      },
      {
        id: "laser_focus",
        name: "Laser focus",
        description: "Scherpe, onverstoorde concentratie",
        difficulty: 5
      },
      {
        id: "zen_like_focus",
        name: "Zen-achtige focus",
        description: "Perfecte mentale focus en helderheid",
        difficulty: 6
      }
    ]
  },
  "RESPECTVOL": {
    name: "Respectvol",
    levels: [
      {
        id: "basic_respect",
        name: "Basis respect",
        description: "Eenvoudig respect voor anderen",
        difficulty: 1
      },
      {
        id: "consistent_courtesy",
        name: "Consistente hoffelijkheid",
        description: "Altijd beleefd en respectvol",
        difficulty: 2
      },
      {
        id: "deep_respect",
        name: "Diep respect",
        description: "Oprecht respect voor alle betrokkenen",
        difficulty: 3
      },
      {
        id: "mutual_respect",
        name: "Wederzijds respect",
        description: "Respect uitstralen en ontvangen",
        difficulty: 4
      },
      {
        id: "respectful_leadership",
        name: "Respectvol leiderschap",
        description: "Leiden met respect en waardigheid",
        difficulty: 5
      },
      {
        id: "universal_respect",
        name: "Universeel respect",
        description: "Respect voor iedereen in alle situaties",
        difficulty: 6
      }
    ]
  }
};

export type MentaalDepthLevel = {
  id: string;
  name: string;
  description: string;
  difficulty: number;
};

export type MentaalElement = {
  name: string;
  levels: MentaalDepthLevel[];
};