import { create } from 'zustand';

export type Language = 'en' | 'nl';

interface LanguageStore {
  language: Language;
  setLanguage: (lang: Language) => void;
}

export const useLanguage = create<LanguageStore>((set) => ({
  language: 'en',
  setLanguage: (lang) => set({ language: lang }),
}));

// English translations
const en = {
  // Navigation
  dashboard: 'Dashboard',
  players: 'Players',
  teams: 'Teams',
  coaches: 'Coaches',
  coordinators: 'Coordinators',
  trainings: 'Trainings',
  trainingSchedules: 'Training Schedules',
  matches: 'Matches',
  payments: 'Payments',
  pitches: 'Pitches',
  settings: 'Settings',
  phoneNumbers: 'Phone Directory',
  
  // Common actions
  add: 'Add',
  edit: 'Edit',
  delete: 'Delete',
  save: 'Save',
  cancel: 'Cancel',
  close: 'Close',
  search: 'Search',
  filter: 'Filter',
  export: 'Export',
  import: 'Import',
  
  // Player management
  addPlayer: 'Add Player',
  editPlayer: 'Edit Player',
  playerName: 'Player Name',
  firstName: 'First Name',
  lastName: 'Last Name',
  email: 'Email',
  dateOfBirth: 'Date of Birth',
  position: 'Position',
  team: 'Team',
  status: 'Status',
  jerseyNumber: 'Jersey Number',
  
  // Positions
  goalkeeper: 'Goalkeeper',
  defender: 'Defender',
  midfielder: 'Midfielder',
  forward: 'Forward',
  
  // Status
  active: 'Active',
  inactive: 'Inactive',
  injured: 'Injured',
  suspended: 'Suspended',
  archived: 'Archived',
  
  // Teams
  addTeam: 'Add Team',
  editTeam: 'Edit Team',
  teamName: 'Team Name',
  ageGroup: 'Age Group',
  description: 'Description',
  coach: 'Coach',
  
  // Dashboard
  totalPlayers: 'Total Players',
  activeTeams: 'Active Teams',
  upcomingMatches: 'Upcoming Matches',
  recentActivity: 'Recent Activity',
  
  // Messages
  playerCreated: 'Player created successfully',
  playerUpdated: 'Player updated successfully',
  playerDeleted: 'Player deleted successfully',
  teamCreated: 'Team created successfully',
  teamUpdated: 'Team updated successfully',
  error: 'An error occurred',
  success: 'Success',
  
  // Welcome
  welcome: 'Welcome to',
  clubManagement: 'Soccer Club Management',
  
  // Language
  language: 'Language',
  english: 'English',
  dutch: 'Dutch',
};

// Dutch translations
const nl = {
  // Navigation
  dashboard: 'Dashboard',
  players: 'Spelers',
  teams: 'Teams',
  coaches: 'Trainers',
  coordinators: 'Coördinatoren',
  trainings: 'Trainingen',
  trainingSchedules: 'Trainingsschema\'s',
  matches: 'Wedstrijden',
  payments: 'Betalingen',
  pitches: 'Velden',
  settings: 'Instellingen',
  phoneNumbers: 'Telefoonlijst',
  
  // Common actions
  add: 'Toevoegen',
  edit: 'Bewerken',
  delete: 'Verwijderen',
  save: 'Opslaan',
  cancel: 'Annuleren',
  close: 'Sluiten',
  search: 'Zoeken',
  filter: 'Filteren',
  export: 'Exporteren',
  import: 'Importeren',
  
  // Player management
  addPlayer: 'Speler Toevoegen',
  editPlayer: 'Speler Bewerken',
  playerName: 'Speler Naam',
  firstName: 'Voornaam',
  lastName: 'Achternaam',
  email: 'E-mail',
  dateOfBirth: 'Geboortedatum',
  position: 'Positie',
  team: 'Team',
  status: 'Status',
  jerseyNumber: 'Rugnummer',
  
  // Positions
  goalkeeper: 'Doelman',
  defender: 'Verdediger',
  midfielder: 'Middenvelder',
  forward: 'Aanvaller',
  
  // Status
  active: 'Actief',
  inactive: 'Inactief',
  injured: 'Geblesseerd',
  suspended: 'Geschorst',
  archived: 'Gearchiveerd',
  
  // Teams
  addTeam: 'Team Toevoegen',
  editTeam: 'Team Bewerken',
  teamName: 'Team Naam',
  ageGroup: 'Leeftijdsgroep',
  description: 'Beschrijving',
  coach: 'Trainer',
  
  // Dashboard
  totalPlayers: 'Totaal Spelers',
  activeTeams: 'Actieve Teams',
  upcomingMatches: 'Aankomende Wedstrijden',
  recentActivity: 'Recente Activiteit',
  
  // Messages
  playerCreated: 'Speler succesvol aangemaakt',
  playerUpdated: 'Speler succesvol bijgewerkt',
  playerDeleted: 'Speler succesvol verwijderd',
  teamCreated: 'Team succesvol aangemaakt',
  teamUpdated: 'Team succesvol bijgewerkt',
  error: 'Er is een fout opgetreden',
  success: 'Succes',
  
  // Welcome
  welcome: 'Welkom bij',
  clubManagement: 'Voetbalclub Beheer',
  
  // Language
  language: 'Taal',
  english: 'Engels',
  dutch: 'Nederlands',
  
  // Training Programs
  trainingPrograms: 'Pre-Season Programma',
  comprehensiveTraining: 'Uitgebreide trainingsprogramma\'s voor alle niveaus en leeftijdsgroepen',
  weekPreSeason: '8-Weken Voorbereiding Trainingsprogramma',
  periodizationPlan: 'Uitgebreid periodiseringsplan met focus op blessurepreventie',
  featuredProgram: 'Uitgelicht Programma',
  programOverview: 'Programma Overzicht',
  trainingSessions: '3 trainingen per week',
  progressivePeriodization: 'Progressieve periodiseringsprincipes',
  hiitCardio: 'HIIT & cardiovasculaire conditietraining',
  strengthPower: 'Kracht & explosiviteit ontwikkeling',
  injuryPrevention: 'Uitgebreide blessurepreventie',
  trainingPhases: 'Trainingsfasen',
  foundationPhase: 'Fundamenten Fase (Week 1-3)',
  buildingPhase: 'Opbouw Fase (Week 4-6)',
  peakPhase: 'Piek Fase (Week 7-8)',
  downloadProgram: 'Download Programma',
  playerSpecific: 'Speler-specifiek Programma',
  week: 'Week',
  duration: 'Duur',
  minutes: 'minuten',
  difficulty: 'Moeilijkheidsgraad',
  beginner: 'Beginner',
  intermediate: 'Gemiddeld',
  advanced: 'Gevorderd',
  trainingFocus: 'Training Focus',
  foundationBuilding: 'Fundamenten opbouw (Week 1-2)',
  volumeIncrease: 'Volume verhoging (Week 3-5)',
  peakIntensity: 'Piek intensiteit (Week 6-8)',
  matchSpecific: 'Wedstrijdspecifieke voorbereiding',
  performanceOptimization: 'Prestatie optimalisatie',
  downloadPdf: 'Download PDF',
  downloadExcel: 'Download Excel',
  addToCalendar: 'Toevoegen aan Kalender',
  
  // Training Programs specific
  createProgram: 'Programma Aanmaken',
  editProgram: 'Programma Bewerken',
  viewDetails: 'Bekijk Details',
  programName: 'Programma Naam',
  focusArea: 'Focus Gebied',
  selectAgeGroup: 'Selecteer Leeftijdsgroep',
  selectDifficulty: 'Selecteer Moeilijkheidsgraad',
  enterProgramName: 'Voer programma naam in',
  enterDescription: 'Voer beschrijving in',
  enterFocusArea: 'Voer focus gebied in',
  createProgramDescription: 'Maak een nieuw trainingsprogramma aan',
  editProgramDescription: 'Bewerk het geselecteerde trainingsprogramma',
  updateProgram: 'Programma Bijwerken',
  
  // Training categories
  physical: 'Fysiek',
  technical: 'Technisch', 
  tactical: 'Tactisch',
  mental: 'Mentaal',
};

const translations = { en, nl };

export const useTranslation = () => {
  const { language } = useLanguage();
  
  const t = (key: keyof typeof en): string => {
    return translations[language][key] || translations.en[key] || key;
  };
  
  return { t, language };
};