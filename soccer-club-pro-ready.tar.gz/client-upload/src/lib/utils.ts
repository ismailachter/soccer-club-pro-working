import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, parseISO, isValid } from "date-fns";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateString: string | Date | undefined, formatString: string = "PPP"): string {
  if (!dateString) return "N/A";
  
  const date = typeof dateString === "string" ? parseISO(dateString) : dateString;
  return isValid(date) ? format(date, formatString) : "Invalid date";
}

export function formatTime(dateString: string | Date | undefined, formatString: string = "h:mm a"): string {
  if (!dateString) return "N/A";
  
  const date = typeof dateString === "string" ? parseISO(dateString) : dateString;
  return isValid(date) ? format(date, formatString) : "Invalid time";
}

export function formatDateTime(dateString: string | Date | undefined, formatString: string = "PPP p"): string {
  if (!dateString) return "N/A";
  
  const date = typeof dateString === "string" ? parseISO(dateString) : dateString;
  return isValid(date) ? format(date, formatString) : "Invalid date/time";
}

export function truncateText(text: string, maxLength: number = 100): string {
  if (!text) return "";
  return text.length > maxLength ? `${text.substring(0, maxLength)}...` : text;
}

export function getInitials(firstName: string, lastName: string): string {
  if (!firstName && !lastName) return "N/A";
  return `${firstName ? firstName.charAt(0).toUpperCase() : ''}${lastName ? lastName.charAt(0).toUpperCase() : ''}`;
}

export function getStatusColor(status: string): { bg: string; text: string } {
  switch (status?.toLowerCase()) {
    case 'active':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'inactive':
      return { bg: 'bg-gray-100', text: 'text-gray-800' };
    case 'injured':
      return { bg: 'bg-amber-100', text: 'text-amber-800' };
    case 'suspended':
      return { bg: 'bg-red-100', text: 'text-red-800' };
    case 'scheduled':
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
    case 'completed':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'cancelled':
      return { bg: 'bg-red-100', text: 'text-red-800' };
    case 'postponed':
      return { bg: 'bg-purple-100', text: 'text-purple-800' };
    case 'available':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'in_use':
    case 'in use':
      return { bg: 'bg-amber-100', text: 'text-amber-800' };
    case 'maintenance':
      return { bg: 'bg-red-100', text: 'text-red-800' };
    case 'present':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'absent':
      return { bg: 'bg-red-100', text: 'text-red-800' };
    case 'late':
      return { bg: 'bg-amber-100', text: 'text-amber-800' };
    case 'excused':
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
    case 'upcoming':
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
    case 'in progress':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'home':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'away':
      return { bg: 'bg-amber-100', text: 'text-amber-800' };
    case 'won':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'lost':
      return { bg: 'bg-red-100', text: 'text-red-800' };
    case 'draw':
      return { bg: 'bg-amber-100', text: 'text-amber-800' };
    case 'light training':
      return { bg: 'bg-amber-100', text: 'text-amber-800' };
    default:
      return { bg: 'bg-gray-100', text: 'text-gray-800' };
  }
}

export function calculateAge(dateOfBirth: string | Date | undefined): number {
  if (!dateOfBirth) return 0;
  
  const birthDate = typeof dateOfBirth === "string" ? new Date(dateOfBirth) : dateOfBirth;
  if (!isValid(birthDate)) return 0;
  
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
}
