import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarCheck, Edit, MoreHorizontal, UserCheck, Download } from "lucide-react";
import { TrainingSession, Player } from "@/types";
import { formatDate, formatTime, getStatusColor, cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { BackToMenu } from "@/components/ui/back-to-menu";

export default function Training() {
  const [isAddTrainingOpen, setIsAddTrainingOpen] = useState(false);
  
  // Fetch training sessions data
  const { data: trainingSessions, isLoading: loadingSessions, error: sessionsError } = useQuery<TrainingSession[]>({
    queryKey: ['/api/training-sessions'],
  });

  // Fetch sample players for attendance (would be filtered by team in a real implementation)
  const { data: players, isLoading: loadingPlayers, error: playersError } = useQuery<Player[]>({
    queryKey: ['/api/players?teamId=3'], // Assuming teamId 3 is for U12 Tigers in the sample data
  });

  // Define columns for training table
  const sessionColumns = [
    {
      header: "Date & Time",
      accessorKey: "date",
      cell: (session: TrainingSession) => (
        <div>
          <div>{formatDate(session.date)}</div>
          <div className="text-xs text-muted-foreground">
            {formatTime(session.startTime)} - {formatTime(session.endTime)}
          </div>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Team",
      accessorKey: "team.name",
      sortable: true,
    },
    {
      header: "Location",
      accessorKey: "pitch.name",
      cell: (session: TrainingSession) => session.pitch?.name || 'Unassigned',
      sortable: true,
    },
    {
      header: "Coach",
      accessorKey: "coach",
      cell: (session: TrainingSession) => {
        if (!session.coach) return 'Unassigned';
        return `${session.coach.firstName} ${session.coach.lastName}`;
      },
      sortable: true,
    },
    {
      header: "Focus",
      accessorKey: "focus",
      cell: (session: TrainingSession) => (
        <div className="max-w-xs truncate" title={session.focus}>
          {session.focus || 'No focus specified'}
        </div>
      ),
    },
    {
      header: "Actions",
      accessorKey: "id",
      cell: (session: TrainingSession) => (
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Edit className="h-3.5 w-3.5" />
            Edit
          </Button>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  if (loadingSessions || loadingPlayers) {
    return <div className="p-8 text-center">Loading training data...</div>;
  }

  if (sessionsError || playersError) {
    return <div className="p-8 text-center text-red-500">Error loading training data.</div>;
  }

  // Filter for today's sessions
  const todaySessions = trainingSessions?.filter(session => {
    const sessionDate = new Date(session.date);
    const today = new Date();
    return sessionDate.getDate() === today.getDate() &&
           sessionDate.getMonth() === today.getMonth() &&
           sessionDate.getFullYear() === today.getFullYear();
  }) || [];

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Training Sessions</h2>
        <div className="flex gap-2">
          <BackToMenu />
          <Dialog open={isAddTrainingOpen} onOpenChange={setIsAddTrainingOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <CalendarCheck className="h-4 w-4" />
                Schedule Training
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Schedule Training Session</DialogTitle>
              <DialogDescription>
                Enter the training session details below.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="team">Team</Label>
                <Select>
                  <SelectTrigger id="team">
                    <SelectValue placeholder="Select team" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">U14 Lions</SelectItem>
                    <SelectItem value="2">U16 Eagles</SelectItem>
                    <SelectItem value="3">U12 Tigers</SelectItem>
                    <SelectItem value="4">U10 Panthers</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="coach">Coach</Label>
                <Select>
                  <SelectTrigger id="coach">
                    <SelectValue placeholder="Select coach" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">David Miller</SelectItem>
                    <SelectItem value="2">Sarah Williams</SelectItem>
                    <SelectItem value="3">James Chen</SelectItem>
                    <SelectItem value="4">Lisa Thompson</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pitch">Location/Pitch</Label>
                <Select>
                  <SelectTrigger id="pitch">
                    <SelectValue placeholder="Select pitch" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Main Field</SelectItem>
                    <SelectItem value="2">Training Field 1</SelectItem>
                    <SelectItem value="3">Training Field 2</SelectItem>
                    <SelectItem value="4">Indoor Facility</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input id="date" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="startTime">Start Time</Label>
                <Input id="startTime" type="time" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endTime">End Time</Label>
                <Input id="endTime" type="time" />
              </div>
              <div className="space-y-2 col-span-full">
                <Label htmlFor="focus">Training Focus</Label>
                <Input id="focus" placeholder="e.g. Passing drills, shooting practice, tactical training" />
              </div>
              <div className="space-y-2 col-span-full">
                <Label htmlFor="notes">Additional Notes</Label>
                <Textarea id="notes" placeholder="Any additional information or special instructions" rows={3} />
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsAddTrainingOpen(false)}>
                Cancel
              </Button>
              <Button>Schedule Training</Button>
            </div>
          </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Today's training sessions */}
      <h3 className="font-medium text-foreground text-lg mb-4">Today's Sessions</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {todaySessions.length > 0 ? (
          todaySessions.map((session) => (
            <Card key={session.id} className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-md bg-primary-100 text-primary-600 flex items-center justify-center mr-3">
                    <CalendarCheck className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground">{session.team?.name}</h4>
                    <p className="text-xs text-muted-foreground">
                      {formatTime(session.startTime)} - {formatTime(session.endTime)}
                    </p>
                  </div>
                </div>
                <Badge className="capitalize" variant="outline">
                  {new Date() < new Date(session.startTime) ? 'Upcoming' : 
                   new Date() > new Date(session.endTime) ? 'Completed' : 'In Progress'}
                </Badge>
              </div>
              <div className="text-sm mb-3">
                <div className="flex items-center text-foreground">
                  <i className="ri-map-pin-line mr-2"></i>
                  <span>{session.pitch?.name || 'Location not specified'}</span>
                </div>
                <div className="flex items-center text-foreground mt-1">
                  <i className="ri-user-line mr-2"></i>
                  <span>Coach: {session.coach ? `${session.coach.firstName} ${session.coach.lastName}` : 'Unassigned'}</span>
                </div>
              </div>
              {session.focus && (
                <div className="text-sm mb-3">
                  <div className="text-foreground font-medium">Focus:</div>
                  <div className="text-muted-foreground">{session.focus}</div>
                </div>
              )}
              <div className="flex justify-end space-x-2 mt-4">
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <UserCheck className="h-3.5 w-3.5" />
                  Attendance
                </Button>
                <Button size="sm" className="flex items-center gap-1">
                  <Edit className="h-3.5 w-3.5" />
                  Edit
                </Button>
              </div>
            </Card>
          ))
        ) : (
          <div className="col-span-full text-center py-8">
            <p className="text-muted-foreground">No training sessions scheduled for today.</p>
          </div>
        )}
      </div>

      {/* Attendance Tracking */}
      <h3 className="font-medium text-foreground text-lg mb-4">Attendance Tracking</h3>
      <Card className="overflow-hidden mb-8">
        <div className="p-4 border-b border-gray-200 bg-secondary">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-lg font-medium text-foreground">U12 Tigers Training Session</h3>
              <p className="text-sm text-muted-foreground">Today, 4:00 PM - 5:30 PM • Training Field 2</p>
            </div>
            <div className="mt-3 sm:mt-0">
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Download className="h-3.5 w-3.5" />
                Export
              </Button>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-border">
            <thead>
              <tr>
                <th className="bg-secondary px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Player</th>
                <th className="bg-secondary px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Position</th>
                <th className="bg-secondary px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Status</th>
                <th className="bg-secondary px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Present</th>
                <th className="bg-secondary px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border bg-background">
              {players?.map((player) => (
                <tr key={player.id} className="group hover:bg-secondary/50">
                  <td className="px-6 py-4 text-sm">
                    <div className="flex items-center">
                      <div className="h-8 w-8 flex-shrink-0 rounded-full bg-secondary">
                        {player.user?.profileImage && (
                          <img 
                            src={player.user.profileImage} 
                            alt={`${player.user?.firstName} ${player.user?.lastName}`}
                            className="h-full w-full rounded-full object-cover"
                          />
                        )}
                      </div>
                      <div className="ml-3">
                        <div className="font-medium text-foreground">
                          {player.user?.firstName} {player.user?.lastName}
                        </div>
                        <div className="text-muted-foreground">#{player.jerseyNumber || 'N/A'}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm capitalize">
                    {player.position || 'Unassigned'}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <Badge variant="outline" className={cn(
                      "capitalize",
                      getStatusColor(player.status).bg,
                      getStatusColor(player.status).text
                    )}>
                      {player.status}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <Checkbox className="h-4 w-4 rounded border-muted-foreground text-primary focus:ring-primary" />
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <Input className="h-8 text-xs" placeholder="Add notes..." />
                  </td>
                </tr>
              ))}
              
              {players?.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-muted-foreground">
                    No players found in this team.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="bg-background px-4 py-3 flex justify-end border-t border-gray-200">
          <Button>
            Save Attendance
          </Button>
        </div>
      </Card>

      {/* Upcoming Training Schedule */}
      <h3 className="font-medium text-foreground text-lg mb-4">Upcoming Training Schedule</h3>
      <DataTable
        data={trainingSessions || []}
        columns={sessionColumns}
        searchable={false}
      />
    </div>
  );
}
