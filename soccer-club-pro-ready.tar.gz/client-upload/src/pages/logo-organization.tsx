import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Palette, Star, Award, Trophy, Upload } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default function LogoOrganization() {
  const { data: logoOrganization, isLoading } = useQuery({
    queryKey: ['/api/logos/organization'],
    retry: false,
  });

  const { data: logos } = useQuery({
    queryKey: ['/api/logos'],
    retry: false,
  });

  const getTeamInfo = (type: string) => {
    const teamMapping = {
      primary: {
        name: 'Dames IP',
        description: 'Hoofdlogo voor InterProvinciaal team',
        icon: Star,
        color: 'text-green-600',
        bgColor: 'bg-green-50'
      },
      secondary: {
        name: 'Beloften/Provinciaal',
        description: 'Tweede logo voor Beloften en Provinciaal teams',
        icon: Award,
        color: 'text-blue-600',
        bgColor: 'bg-blue-50'
      },
      teamSpecific: {
        name: 'MU20',
        description: 'Specifiek logo voor MU20 team',
        icon: Trophy,
        color: 'text-purple-600',
        bgColor: 'bg-purple-50'
      }
    };
    return teamMapping[type] || teamMapping.primary;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Palette className="h-8 w-8" />
            Logo Organisatie per Team
          </h1>
          <p className="text-gray-600 mt-2">
            Overzicht van logo toewijzingen voor verschillende teams en gebruik in PDF exports
          </p>
        </div>
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => window.location.href = '/club-info'}
        >
          <Upload className="mr-2 h-4 w-4" />
          Nieuw Logo Uploaden
        </Button>
      </div>

      {/* Organization Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {['primary', 'secondary', 'teamSpecific'].map((type) => {
          const teamInfo = getTeamInfo(type);
          const hasLogo = logoOrganization?.[type];
          const Icon = teamInfo.icon;

          return (
            <Card key={type} className={`border-2 ${hasLogo ? 'border-green-200' : 'border-gray-200'}`}>
              <CardHeader className={`${teamInfo.bgColor} rounded-t-lg`}>
                <CardTitle className={`flex items-center gap-2 ${teamInfo.color}`}>
                  <Icon className="h-5 w-5" />
                  {teamInfo.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <p className="text-sm text-gray-600 mb-3">{teamInfo.description}</p>
                
                {hasLogo ? (
                  <div className="space-y-2">
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Logo beschikbaar
                    </Badge>
                    <p className="text-xs text-gray-500">
                      Wordt gebruikt in PDF exports
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                      Geen specifiek logo
                    </Badge>
                    <p className="text-xs text-gray-500">
                      Valt terug op hoger niveau logo
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Watermark Usage Info */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Watermerk Functionaliteit</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-2">PDF Export Gebruik</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Eerste pagina: Volledig logo gecentreerd</li>
                <li>• Andere pagina's: Transparant watermerk</li>
                <li>• Bescherming tegen ongewenste duplicatie</li>
                <li>• Automatische team-specifieke selectie</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Team Mapping</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• <strong>Dames IP:</strong> Primary logo</li>
                <li>• <strong>Beloften:</strong> Secondary → Primary</li>
                <li>• <strong>MU20:</strong> Team-specific → Secondary → Primary</li>
                <li>• <strong>Fallback:</strong> Altijd nieuwste logo</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* All Available Logos */}
      <Card>
        <CardHeader>
          <CardTitle>Alle Beschikbare Logo's</CardTitle>
        </CardHeader>
        <CardContent>
          {logos && logos.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {logos.map((logo) => {
                const teamInfo = getTeamInfo(logo.type);
                return (
                  <div key={logo.filename} className="text-center space-y-2">
                    <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center p-2">
                      <img 
                        src={`/${logo.path}`} 
                        alt={logo.filename}
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${teamInfo.color.replace('text-', 'border-').replace('600', '200')} ${teamInfo.color}`}
                    >
                      {logo.type}
                    </Badge>
                    <p className="text-xs text-gray-500 truncate">{logo.filename}</p>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-8">Geen logo's beschikbaar</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}