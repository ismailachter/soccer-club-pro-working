import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, PlusCircle, Trash2 } from "lucide-react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { format } from "date-fns";

// Available age groups for teams
export const ageGroups = [
  // Boys youth age groups
  "Boys U6", "Boys U7", "Boys U8", "Boys U9", "Boys U10", "Boys U11", "Boys U12", 
  "Boys U13", "Boys U14", "Boys U15", "Boys U16", "Boys U17", "Boys U18", "Boys U19", 
  "Boys U20", "Boys U21",
  
  // Girls youth age groups
  "Girls U6", "Girls U7", "Girls U8", "Girls U9", "Girls U10", "Girls U11", "Girls U12", 
  "Girls U13", "Girls U14", "Girls U15", "Girls U16", "Girls U17", "Girls U18", "Girls U19", 
  "Girls U20", "Girls U21",
  
  // Senior teams (men's)
  "Senior A", "Senior B", "Senior C", "Senior D", "Senior E",
  
  // Women's senior teams
  "Women's Senior A", "Women's Senior B", "Women's Senior C", "Women's Senior D", "Women's Senior E",
  
  // Ladies teams
  "Ladies A", "Ladies B", "Ladies C", "Ladies D", "Ladies E"
];

// Create schema for the user-team assignment form
const userTeamFormSchema = z.object({
  userId: z.number({
    required_error: "Please select a user",
  }),
  teamId: z.number({
    required_error: "Please select a team",
  }),
  roleType: z.string({
    required_error: "Please select a role type",
  }),
  title: z.string().optional(),
  isPrimary: z.boolean().default(false),
  startDate: z.date().optional(),
  endDate: z.date().optional(),
  notes: z.string().optional(),
});

type UserTeamFormValues = z.infer<typeof userTeamFormSchema>;

export default function TeamAssignments() {
  const { toast } = useToast();
  const [selectedTeam, setSelectedTeam] = useState<number | null>(null);
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<string>("by-team");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Query to fetch all teams
  const { data: teams, isLoading: isTeamsLoading } = useQuery({
    queryKey: ["/api/teams"],
    queryFn: async () => {
      const response = await fetch("/api/teams");
      if (!response.ok) {
        throw new Error("Failed to fetch teams");
      }
      return response.json();
    },
  });

  // Query to fetch all users
  const { data: users, isLoading: isUsersLoading } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users");
      if (!response.ok) {
        throw new Error("Failed to fetch users");
      }
      return response.json();
    },
  });

  // Query to fetch team assignments for a selected team
  const { 
    data: teamAssignments, 
    isLoading: isTeamAssignmentsLoading,
    refetch: refetchTeamAssignments
  } = useQuery({
    queryKey: ["/api/user-teams", { teamId: selectedTeam }],
    queryFn: async () => {
      if (!selectedTeam) return [];
      const response = await fetch(`/api/user-teams?teamId=${selectedTeam}`);
      if (!response.ok) {
        throw new Error("Failed to fetch team assignments");
      }
      return response.json();
    },
    enabled: !!selectedTeam,
  });

  // Query to fetch team assignments for a selected user
  const { 
    data: userAssignments, 
    isLoading: isUserAssignmentsLoading,
    refetch: refetchUserAssignments
  } = useQuery({
    queryKey: ["/api/user-teams", { userId: selectedUser }],
    queryFn: async () => {
      if (!selectedUser) return [];
      const response = await fetch(`/api/user-teams?userId=${selectedUser}`);
      if (!response.ok) {
        throw new Error("Failed to fetch user assignments");
      }
      return response.json();
    },
    enabled: !!selectedUser,
  });

  // Mutation to create a new user-team assignment
  const createAssignmentMutation = useMutation({
    mutationFn: async (data: UserTeamFormValues) => {
      const res = await apiRequest("POST", "/api/user-teams", data);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to create assignment");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Assignment created",
        description: "The user has been assigned to the team successfully.",
      });
      // Close the dialog and reset form
      setIsAddDialogOpen(false);
      form.reset();
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/user-teams"] });
      if (selectedTeam) refetchTeamAssignments();
      if (selectedUser) refetchUserAssignments();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create assignment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation to delete a user-team assignment
  const deleteAssignmentMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/user-teams/${id}`);
      if (!res.ok) {
        throw new Error("Failed to delete assignment");
      }
      return true;
    },
    onSuccess: () => {
      toast({
        title: "Assignment deleted",
        description: "The user assignment has been removed successfully.",
      });
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/user-teams"] });
      if (selectedTeam) refetchTeamAssignments();
      if (selectedUser) refetchUserAssignments();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete assignment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Set up form for creating a new user-team assignment
  const form = useForm<UserTeamFormValues>({
    resolver: zodResolver(userTeamFormSchema),
    defaultValues: {
      isPrimary: false,
    },
  });

  // Form submission handler
  function onSubmit(data: UserTeamFormValues) {
    createAssignmentMutation.mutate(data);
  }

  if (isTeamsLoading || isUsersLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Team Assignments</h1>
      <p className="text-muted-foreground mb-6">
        Manage user assignments to teams. Users can be assigned to multiple teams with different roles.
      </p>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="by-team">By Team</TabsTrigger>
          <TabsTrigger value="by-user">By User</TabsTrigger>
        </TabsList>

        <TabsContent value="by-team" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Team Assignments</CardTitle>
              <CardDescription>
                Select a team to view and manage its member assignments
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <Label htmlFor="team-select">Select Team</Label>
                <Select
                  onValueChange={(value) => setSelectedTeam(Number(value))}
                  value={selectedTeam?.toString() || ""}
                >
                  <SelectTrigger id="team-select" className="w-full">
                    <SelectValue placeholder="Select a team" />
                  </SelectTrigger>
                  <SelectContent>
                    {teams?.map((team) => (
                      <SelectItem key={team.id} value={team.id.toString()}>
                        {team.name} ({team.ageGroup})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedTeam && (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold">
                      Members of {teams?.find(t => t.id === selectedTeam)?.name}
                    </h3>
                    <Button onClick={() => setIsAddDialogOpen(true)}>
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Add Member
                    </Button>
                  </div>

                  {isTeamAssignmentsLoading ? (
                    <div className="flex justify-center p-4">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  ) : teamAssignments?.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Title</TableHead>
                          <TableHead>Start Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {teamAssignments?.map((assignment) => (
                          <TableRow key={assignment.id}>
                            <TableCell>
                              {assignment.user.firstName} {assignment.user.lastName}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{assignment.roleType}</Badge>
                            </TableCell>
                            <TableCell>{assignment.title || "-"}</TableCell>
                            <TableCell>
                              {assignment.startDate
                                ? format(new Date(assignment.startDate), "MMM d, yyyy")
                                : "-"}
                            </TableCell>
                            <TableCell>
                              <Badge 
                                variant={assignment.isActive ? "default" : "secondary"}
                              >
                                {assignment.isActive ? "Active" : "Inactive"}
                              </Badge>
                              {assignment.isPrimary && (
                                <Badge variant="outline" className="ml-2">Primary</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      This will remove {assignment.user.firstName} {assignment.user.lastName}'s 
                                      assignment as {assignment.roleType} from this team.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteAssignmentMutation.mutate(assignment.id)}
                                    >
                                      {deleteAssignmentMutation.isPending ? (
                                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                                      ) : null}
                                      Remove
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center p-6 border rounded-lg bg-muted/50">
                      <p>No members assigned to this team yet.</p>
                      <Button 
                        variant="outline"
                        className="mt-4"
                        onClick={() => setIsAddDialogOpen(true)}
                      >
                        Add the first member
                      </Button>
                    </div>
                  )}
                </div>
              )}
              
              {!selectedTeam && (
                <div className="text-center p-6 border rounded-lg bg-muted/50">
                  <p>Please select a team to view and manage its assignments.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="by-user" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>User Assignments</CardTitle>
              <CardDescription>
                Select a user to view and manage their team assignments
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <Label htmlFor="user-select">Select User</Label>
                <Select
                  onValueChange={(value) => setSelectedUser(Number(value))}
                  value={selectedUser?.toString() || ""}
                >
                  <SelectTrigger id="user-select" className="w-full">
                    <SelectValue placeholder="Select a user" />
                  </SelectTrigger>
                  <SelectContent>
                    {users?.map((user) => (
                      <SelectItem key={user.id} value={user.id.toString()}>
                        {user.firstName} {user.lastName} ({user.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedUser && (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold">
                      Teams for {users?.find(u => u.id === selectedUser)?.firstName} {users?.find(u => u.id === selectedUser)?.lastName}
                    </h3>
                    <Button onClick={() => setIsAddDialogOpen(true)}>
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Add to Team
                    </Button>
                  </div>

                  {isUserAssignmentsLoading ? (
                    <div className="flex justify-center p-4">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  ) : userAssignments?.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Team</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Title</TableHead>
                          <TableHead>Start Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {userAssignments?.map((assignment) => (
                          <TableRow key={assignment.id}>
                            <TableCell>
                              {assignment.team.name} ({assignment.team.ageGroup})
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{assignment.roleType}</Badge>
                            </TableCell>
                            <TableCell>{assignment.title || "-"}</TableCell>
                            <TableCell>
                              {assignment.startDate
                                ? format(new Date(assignment.startDate), "MMM d, yyyy")
                                : "-"}
                            </TableCell>
                            <TableCell>
                              <Badge 
                                variant={assignment.isActive ? "default" : "secondary"}
                              >
                                {assignment.isActive ? "Active" : "Inactive"}
                              </Badge>
                              {assignment.isPrimary && (
                                <Badge variant="outline" className="ml-2">Primary</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      This will remove this user's assignment as {assignment.roleType} from {assignment.team.name}.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteAssignmentMutation.mutate(assignment.id)}
                                    >
                                      {deleteAssignmentMutation.isPending ? (
                                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                                      ) : null}
                                      Remove
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center p-6 border rounded-lg bg-muted/50">
                      <p>This user is not assigned to any teams yet.</p>
                      <Button 
                        variant="outline"
                        className="mt-4"
                        onClick={() => setIsAddDialogOpen(true)}
                      >
                        Add to a team
                      </Button>
                    </div>
                  )}
                </div>
              )}
              
              {!selectedUser && (
                <div className="text-center p-6 border rounded-lg bg-muted/50">
                  <p>Please select a user to view and manage their team assignments.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialog for adding a new user-team assignment */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>Add Team Assignment</DialogTitle>
            <DialogDescription>
              Assign a user to a team with a specific role.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>User</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange(Number(value))}
                      defaultValue={selectedUser?.toString() || field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a user" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {users?.map((user) => (
                          <SelectItem key={user.id} value={user.id.toString()}>
                            {user.firstName} {user.lastName} ({user.role})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="teamId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Team</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange(Number(value))}
                      defaultValue={selectedTeam?.toString() || field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a team" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {teams?.map((team) => (
                          <SelectItem key={team.id} value={team.id.toString()}>
                            {team.name} ({team.ageGroup})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="roleType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role Type</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="player">Player</SelectItem>
                        <SelectItem value="coach">Coach</SelectItem>
                        <SelectItem value="assistant_coach">Assistant Coach</SelectItem>
                        <SelectItem value="trainer">Trainer</SelectItem>
                        <SelectItem value="manager">Manager</SelectItem>
                        <SelectItem value="medical">Medical Staff</SelectItem>
                        <SelectItem value="administrator">Administrator</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Head Coach, Team Captain" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormDescription>
                      Specific title for this role, if applicable
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="isPrimary"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <input
                        type="checkbox"
                        className="h-4 w-4 mt-1"
                        checked={field.value}
                        onChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Primary Assignment</FormLabel>
                      <FormDescription>
                        Mark this as the user's primary role for this team
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createAssignmentMutation.isPending}
                >
                  {createAssignmentMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Create Assignment
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}