import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar, Plus, Edit, Trash2, Download, FileText, Calendar as CalendarIcon, Users, Clock, MapPin, AlertTriangle, FileSpreadsheet, Presentation, Copy, ArrowRight } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

const weekdays = [
  { value: 'monday', label: 'Maandag' },
  { value: 'tuesday', label: 'Dinsdag' },
  { value: 'wednesday', label: 'Woensdag' },
  { value: 'thursday', label: 'Donderdag' },
  { value: 'friday', label: 'Vrijdag' },
  { value: 'saturday', label: 'Zaterdag' },
  { value: 'sunday', label: 'Zondag' }
];

const yearPlanSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  description: z.string().optional(),
  teamId: z.number().optional(),
  ageGroup: z.string().optional(),
  startDate: z.string().min(1, "Startdatum is verplicht"),
  endDate: z.string().min(1, "Einddatum is verplicht"),
  trainingDays: z.array(z.string()).min(1, "Selecteer minimaal één trainingsdag"),
  status: z.enum(['draft', 'active', 'completed', 'archived']).default('draft')
});

const periodSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  description: z.string().optional(),
  startDate: z.string().min(1, "Startdatum is verplicht"),
  endDate: z.string().min(1, "Einddatum is verplicht"),
  focusThemes: z.array(z.string()).default([]),
  color: z.string().default('#3B82F6'),
  sortOrder: z.number().default(0)
});

type YearPlanFormData = z.infer<typeof yearPlanSchema>;
type PeriodFormData = z.infer<typeof periodSchema>;

interface YearPlan {
  id: number;
  name: string;
  description?: string;
  teamId?: number;
  ageGroup?: string;
  startDate: string;
  endDate: string;
  status: string;
  trainingDays: string[];
  team?: { id: number; name: string; };
  periods?: Period[];
  sessions?: Session[];
}

interface Period {
  id: number;
  yearPlanId: number;
  name: string;
  description?: string;
  startDate: string;
  endDate: string;
  focusThemes: string[];
  color: string;
  sortOrder: number;
}

interface Session {
  id: number;
  yearPlanId: number;
  periodId?: number;
  date: string;
  themes: string[];
  notes?: string;
  duration?: number;
  location?: string;
  isCompleted: boolean;
}

export default function YearPlansPage() {
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPeriodDialogOpen, setIsPeriodDialogOpen] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch year plans
  const { data: yearPlans = [], isLoading } = useQuery<YearPlan[]>({
    queryKey: ['/api/year-plans'],
  });

  // Fetch teams
  const { data: teams = [] } = useQuery<any[]>({
    queryKey: ['/api/teams'],
  });

  // Fetch IADATABANK elements for themes
  const { data: iadatabank } = useQuery<{ data: any[] }>({
    queryKey: ['/api/iadatabank/elements'],
  });
  
  const iadatabankElements = iadatabank?.data || [];

  // Form for creating/editing year plans
  const form = useForm<YearPlanFormData>({
    resolver: zodResolver(yearPlanSchema),
    defaultValues: {
      name: "",
      description: "",
      ageGroup: "",
      startDate: "",
      endDate: "",
      trainingDays: [],
      status: 'draft'
    }
  });

  // Form for creating periods
  const periodForm = useForm<PeriodFormData>({
    resolver: zodResolver(periodSchema),
    defaultValues: {
      name: "",
      description: "",
      startDate: "",
      endDate: "",
      focusThemes: [],
      color: '#3B82F6',
      sortOrder: 0
    }
  });

  // Create year plan mutation
  const createYearPlan = useMutation({
    mutationFn: (data: YearPlanFormData) => apiRequest('/api/year-plans', {
      method: 'POST',
      body: JSON.stringify(data)
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({ title: "Jaarplanning aangemaakt", description: "De nieuwe jaarplanning is succesvol aangemaakt." });
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het aanmaken.", variant: "destructive" });
    }
  });

  // Update year plan mutation
  const updateYearPlan = useMutation({
    mutationFn: ({ id, data }: { id: number; data: YearPlanFormData }) => 
      apiRequest(`/api/year-plans/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setIsEditDialogOpen(false);
      setSelectedPlan(null);
      form.reset();
      toast({ title: "Jaarplanning bijgewerkt", description: "De jaarplanning is succesvol bijgewerkt." });
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het bijwerken.", variant: "destructive" });
    }
  });

  // Delete year plan mutation with double confirmation
  const deleteYearPlan = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/year-plans/${id}`, {
      method: 'DELETE',
      headers: { 'x-confirm-delete': 'true' }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setDeleteConfirmation(null);
      toast({ title: "Jaarplanning verwijderd", description: "De jaarplanning is permanent verwijderd." });
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het verwijderen.", variant: "destructive" });
    }
  });

  // Create period mutation
  const createPeriod = useMutation({
    mutationFn: ({ planId, data }: { planId: number; data: PeriodFormData }) =>
      apiRequest(`/api/year-plans/${planId}/periods`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setIsPeriodDialogOpen(false);
      periodForm.reset();
      toast({ title: "Periode toegevoegd", description: "De nieuwe periode is toegevoegd aan de jaarplanning." });
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het toevoegen van de periode.", variant: "destructive" });
    }
  });

  const handleCreateSubmit = (data: YearPlanFormData) => {
    createYearPlan.mutate(data);
  };

  const handleEditSubmit = (data: YearPlanFormData) => {
    if (selectedPlan) {
      updateYearPlan.mutate({ id: selectedPlan.id, data });
    }
  };

  const handlePeriodSubmit = (data: PeriodFormData) => {
    if (selectedPlan) {
      createPeriod.mutate({ planId: selectedPlan.id, data });
    }
  };

  const handleEdit = (plan: YearPlan) => {
    setSelectedPlan(plan);
    form.reset({
      name: plan.name,
      description: plan.description || "",
      teamId: plan.teamId,
      ageGroup: plan.ageGroup || "",
      startDate: plan.startDate,
      endDate: plan.endDate,
      trainingDays: plan.trainingDays || [],
      status: plan.status as any
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (deleteConfirmation === id) {
      deleteYearPlan.mutate(id);
    } else {
      setDeleteConfirmation(id);
      // Reset confirmation after 5 seconds
      setTimeout(() => setDeleteConfirmation(null), 5000);
    }
  };

  const copyToNextSeason = useMutation({
    mutationFn: async (planId: number) => {
      const response = await fetch(`/api/year-plans/${planId}/copy-to-next-season`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'Failed to copy to next season');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      toast({ 
        title: "Seizoen gekopieerd!", 
        description: `${data.sessionCount} trainingen succesvol gekopieerd naar seizoen ${data.newSeason}` 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Fout bij kopiëren", 
        description: error.message, 
        variant: "destructive" 
      });
    }
  });

  const handleCopyToNextSeason = (planId: number) => {
    copyToNextSeason.mutate(planId);
  };

  const handleExport = async (planId: number, format: 'pdf' | 'excel' | 'ics' | 'powerpoint') => {
    try {
      const response = await fetch(`/api/year-plans/${planId}/export/${format}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
        }
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = response.headers.get('Content-Disposition')?.split('filename=')[1]?.replace(/"/g, '') || `jaarplanning.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({ title: "Export succesvol", description: `Jaarplanning geëxporteerd als ${format.toUpperCase()}` });
      } else {
        throw new Error('Export failed');
      }
    } catch (error) {
      toast({ title: "Export fout", description: "Er is een fout opgetreden bij het exporteren.", variant: "destructive" });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      default: return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Actief';
      case 'completed': return 'Voltooid';
      case 'archived': return 'Gearchiveerd';
      default: return 'Concept';
    }
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Laden...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Jaarplanningen</h1>
          <p className="text-muted-foreground">
            Beheer training jaarplanningen met periodes en trainingsweekdagen
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Nieuwe Jaarplanning
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Nieuwe Jaarplanning Maken</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleCreateSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Naam</FormLabel>
                      <FormControl>
                        <Input placeholder="bijv. Seizoen 2024-2025 U12" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Beschrijving</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Korte beschrijving van de jaarplanning..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="teamId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Team (optioneel)</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecteer team" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">Geen specifiek team</SelectItem>
                            {teams.map((team: any) => (
                              <SelectItem key={team.id} value={team.id.toString()}>
                                {team.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="ageGroup"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Leeftijdsgroep</FormLabel>
                        <FormControl>
                          <Input placeholder="bijv. U12, U15, Senior" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Startdatum</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Einddatum</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="trainingDays"
                  render={() => (
                    <FormItem>
                      <FormLabel>Trainingsdagen</FormLabel>
                      <div className="grid grid-cols-3 gap-2">
                        {weekdays.map((day) => (
                          <FormField
                            key={day.value}
                            control={form.control}
                            name="trainingDays"
                            render={({ field }) => {
                              return (
                                <FormItem
                                  key={day.value}
                                  className="flex flex-row items-start space-x-3 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(day.value)}
                                      onCheckedChange={(checked) => {
                                        return checked
                                          ? field.onChange([...field.value, day.value])
                                          : field.onChange(
                                              field.value?.filter(
                                                (value) => value !== day.value
                                              )
                                            )
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal">
                                    {day.label}
                                  </FormLabel>
                                </FormItem>
                              )
                            }}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="draft">Concept</SelectItem>
                          <SelectItem value="active">Actief</SelectItem>
                          <SelectItem value="completed">Voltooid</SelectItem>
                          <SelectItem value="archived">Gearchiveerd</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Annuleren
                  </Button>
                  <Button type="submit" disabled={createYearPlan.isPending}>
                    {createYearPlan.isPending ? "Maken..." : "Jaarplanning Maken"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Year Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {yearPlans.map((plan) => (
          <Card key={plan.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge className={getStatusColor(plan.status)}>
                      {getStatusLabel(plan.status)}
                    </Badge>
                    {plan.team && (
                      <Badge variant="outline" className="text-xs">
                        <Users className="h-3 w-3 mr-1" />
                        {plan.team.name}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {plan.description && (
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              )}
              
              <div className="flex items-center gap-2 text-sm">
                <CalendarIcon className="h-4 w-4" />
                {format(new Date(plan.startDate), 'dd MMM yyyy', { locale: nl })} - {format(new Date(plan.endDate), 'dd MMM yyyy', { locale: nl })}
              </div>
              
              {plan.ageGroup && (
                <div className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4" />
                  {plan.ageGroup}
                </div>
              )}
              
              {plan.trainingDays && plan.trainingDays.length > 0 && (
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4" />
                  {plan.trainingDays.map(day => weekdays.find(w => w.value === day)?.label).join(', ')}
                </div>
              )}

              {/* Kopieer naar volgend seizoen knop */}
              <div className="pt-3 border-t">
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => handleCopyToNextSeason(plan.id)}
                  disabled={copyToNextSeason.isPending}
                  className="w-full mb-3 bg-blue-50 hover:bg-blue-100 border-blue-300 text-blue-700"
                >
                  <Copy className="h-3 w-3 mr-2" />
                  {copyToNextSeason.isPending ? 'Kopiëren...' : 'Kopieer naar Volgend Seizoen'}
                  <ArrowRight className="h-3 w-3 ml-2" />
                </Button>
              </div>

              <div className="flex justify-between items-center">
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(plan)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant={deleteConfirmation === plan.id ? "destructive" : "outline"}
                    onClick={() => handleDelete(plan.id)}
                  >
                    {deleteConfirmation === plan.id ? (
                      <AlertTriangle className="h-3 w-3" />
                    ) : (
                      <Trash2 className="h-3 w-3" />
                    )}
                  </Button>
                </div>
                
                <div className="flex gap-1">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => handleExport(plan.id, 'pdf')}
                    title="PDF Export"
                  >
                    <FileText className="h-3 w-3 text-red-600" />
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => handleExport(plan.id, 'excel')}
                    title="Excel Export"
                  >
                    <FileSpreadsheet className="h-3 w-3 text-green-600" />
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => handleExport(plan.id, 'powerpoint')}
                    title="PowerPoint Export"
                  >
                    <Presentation className="h-3 w-3 text-orange-600" />
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => handleExport(plan.id, 'ics')}
                    title="ICS Kalender Export"
                  >
                    <Calendar className="h-3 w-3 text-blue-600" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {yearPlans.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Geen jaarplanningen</h3>
          <p className="text-muted-foreground mb-4">Maak uw eerste jaarplanning om te beginnen.</p>
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Nieuwe Jaarplanning
          </Button>
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Jaarplanning Bewerken</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleEditSubmit)} className="space-y-4">
              {/* Same form fields as create dialog */}
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naam</FormLabel>
                    <FormControl>
                      <Input placeholder="bijv. Seizoen 2024-2025 U12" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Beschrijving</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Korte beschrijving van de jaarplanning..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="teamId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team (optioneel)</FormLabel>
                      <Select onValueChange={(value) => field.onChange(value ? parseInt(value) : undefined)} value={field.value?.toString() || ""}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecteer team" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">Geen specifiek team</SelectItem>
                          {teams.map((team: any) => (
                            <SelectItem key={team.id} value={team.id.toString()}>
                              {team.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="ageGroup"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Leeftijdsgroep</FormLabel>
                      <FormControl>
                        <Input placeholder="bijv. U12, U15, Senior" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Startdatum</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Einddatum</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="trainingDays"
                render={() => (
                  <FormItem>
                    <FormLabel>Trainingsdagen</FormLabel>
                    <div className="grid grid-cols-3 gap-2">
                      {weekdays.map((day) => (
                        <FormField
                          key={day.value}
                          control={form.control}
                          name="trainingDays"
                          render={({ field }) => {
                            return (
                              <FormItem
                                key={day.value}
                                className="flex flex-row items-start space-x-3 space-y-0"
                              >
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(day.value)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, day.value])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== day.value
                                            )
                                          )
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal">
                                  {day.label}
                                </FormLabel>
                              </FormItem>
                            )
                          }}
                        />
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="draft">Concept</SelectItem>
                        <SelectItem value="active">Actief</SelectItem>
                        <SelectItem value="completed">Voltooid</SelectItem>
                        <SelectItem value="archived">Gearchiveerd</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Annuleren
                </Button>
                <Button type="submit" disabled={updateYearPlan.isPending}>
                  {updateYearPlan.isPending ? "Bijwerken..." : "Wijzigingen Opslaan"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}