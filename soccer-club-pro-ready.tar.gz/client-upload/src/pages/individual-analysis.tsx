import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Video, User, Star, Clock, FileText, TrendingUp, Target, BarChart3, Activity, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { BackToMenu } from "@/components/ui/back-to-menu";

interface PlayerAnalysisData {
  videoId: string;
  playerId: string;
  analysisType: 'technical_skills' | 'tactical_positioning' | 'physical_performance' | 'decision_making' | 'overall_performance';
  startTime?: number;
  endTime?: number;
  notes: string;
  rating: number;
  
  // Pass Statistics
  passesAttempted: number;
  passesCompleted: number;
  passSuccessRate: number;
  
  // Dribbling Statistics
  dribblesAttempted: number;
  dribblesSuccessful: number;
  dribbleSuccessRate: number;
  
  // Shooting Statistics
  shotsTotal: number;
  shotsOnTarget: number;
  shotsOffTarget: number;
  shotAccuracy: number;
  
  // Defensive Statistics
  defensiveDuelsTotal: number;
  defensiveDuelsWon: number;
  defensiveDuelSuccessRate: number;
  
  // 1v1 Situations
  oneVOneTotal: number;
  oneVOneWon: number;
  oneVOneSuccessRate: number;
  
  // Additional Metrics
  touches: number;
  ballRecoveries: number;
  interceptions: number;
  tackles: number;
  tackleSuccessRate: number;
  
  strengths: string[];
  improvements: string[];
  keyMoments: { time: number; description: string }[];
}

export default function IndividualAnalysis() {
  const [analysisData, setAnalysisData] = useState<PlayerAnalysisData>({
    videoId: '',
    playerId: '',
    analysisType: 'overall_performance',
    startTime: 0,
    endTime: 0,
    notes: '',
    rating: 5,
    
    // Pass Statistics
    passesAttempted: 0,
    passesCompleted: 0,
    passSuccessRate: 0,
    
    // Dribbling Statistics
    dribblesAttempted: 0,
    dribblesSuccessful: 0,
    dribbleSuccessRate: 0,
    
    // Shooting Statistics
    shotsTotal: 0,
    shotsOnTarget: 0,
    shotsOffTarget: 0,
    shotAccuracy: 0,
    
    // Defensive Statistics
    defensiveDuelsTotal: 0,
    defensiveDuelsWon: 0,
    defensiveDuelSuccessRate: 0,
    
    // 1v1 Situations
    oneVOneTotal: 0,
    oneVOneWon: 0,
    oneVOneSuccessRate: 0,
    
    // Additional Metrics
    touches: 0,
    ballRecoveries: 0,
    interceptions: 0,
    tackles: 0,
    tackleSuccessRate: 0,
    
    strengths: [],
    improvements: [],
    keyMoments: []
  });
  const [newStrength, setNewStrength] = useState('');
  const [newImprovement, setNewImprovement] = useState('');
  const [newMoment, setNewMoment] = useState({ time: 0, description: '' });
  const { toast } = useToast();

  // Get videos for analysis
  const { data: videos } = useQuery({
    queryKey: ["/api/videos"],
  });

  // Get players for selection
  const { data: players } = useQuery({
    queryKey: ["/api/users"],
  });

  const createAnalysisMutation = useMutation({
    mutationFn: async (data: PlayerAnalysisData) => {
      const response = await fetch('/api/player-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText);
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Analyse opgeslagen!",
        description: "De individuele speler analyse is succesvol opgeslagen",
      });
      setAnalysisData({
        videoId: '',
        playerId: '',
        analysisType: 'overall_performance',
        startTime: 0,
        endTime: 0,
        notes: '',
        rating: 5,
        passesAttempted: 0,
        passesCompleted: 0,
        passSuccessRate: 0,
        dribblesAttempted: 0,
        dribblesSuccessful: 0,
        dribbleSuccessRate: 0,
        shotsTotal: 0,
        shotsOnTarget: 0,
        shotsOffTarget: 0,
        shotAccuracy: 0,
        defensiveDuelsTotal: 0,
        defensiveDuelsWon: 0,
        defensiveDuelSuccessRate: 0,
        oneVOneTotal: 0,
        oneVOneWon: 0,
        oneVOneSuccessRate: 0,
        touches: 0,
        ballRecoveries: 0,
        interceptions: 0,
        tackles: 0,
        tackleSuccessRate: 0,
        strengths: [],
        improvements: [],
        keyMoments: []
      });
      queryClient.invalidateQueries({ queryKey: ["/api/player-analysis"] });
    },
    onError: (error) => {
      toast({
        title: "Opslaan mislukt",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addStrength = () => {
    if (newStrength.trim()) {
      setAnalysisData({
        ...analysisData,
        strengths: [...analysisData.strengths, newStrength.trim()]
      });
      setNewStrength('');
    }
  };

  const addImprovement = () => {
    if (newImprovement.trim()) {
      setAnalysisData({
        ...analysisData,
        improvements: [...analysisData.improvements, newImprovement.trim()]
      });
      setNewImprovement('');
    }
  };

  const addKeyMoment = () => {
    if (newMoment.description.trim()) {
      setAnalysisData({
        ...analysisData,
        keyMoments: [...analysisData.keyMoments, { ...newMoment }]
      });
      setNewMoment({ time: 0, description: '' });
    }
  };

  const removeStrength = (index: number) => {
    setAnalysisData({
      ...analysisData,
      strengths: analysisData.strengths.filter((_, i) => i !== index)
    });
  };

  const removeImprovement = (index: number) => {
    setAnalysisData({
      ...analysisData,
      improvements: analysisData.improvements.filter((_, i) => i !== index)
    });
  };

  const removeKeyMoment = (index: number) => {
    setAnalysisData({
      ...analysisData,
      keyMoments: analysisData.keyMoments.filter((_, i) => i !== index)
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!analysisData.videoId || !analysisData.playerId) {
      toast({
        title: "Ontbrekende gegevens",
        description: "Selecteer een video en speler",
        variant: "destructive",
      });
      return;
    }
    createAnalysisMutation.mutate(analysisData);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Helper function to calculate percentage
  const calculatePercentage = (success: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((success / total) * 100);
  };

  // Auto-calculate success rates when values change
  const updateSuccessRates = () => {
    const newData = { ...analysisData };
    
    // Pass success rate
    newData.passSuccessRate = calculatePercentage(newData.passesCompleted, newData.passesAttempted);
    
    // Dribble success rate
    newData.dribbleSuccessRate = calculatePercentage(newData.dribblesSuccessful, newData.dribblesAttempted);
    
    // Shot accuracy
    newData.shotAccuracy = calculatePercentage(newData.shotsOnTarget, newData.shotsTotal);
    
    // Defensive duel success rate
    newData.defensiveDuelSuccessRate = calculatePercentage(newData.defensiveDuelsWon, newData.defensiveDuelsTotal);
    
    // 1v1 success rate
    newData.oneVOneSuccessRate = calculatePercentage(newData.oneVOneWon, newData.oneVOneTotal);
    
    // Tackle success rate
    newData.tackleSuccessRate = calculatePercentage(newData.tackles, newData.defensiveDuelsTotal);
    
    setAnalysisData(newData);
  };

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">Individuele Speler Analyse</h1>
            <p className="text-gray-600">Creëer gedetailleerde analyses van individuele spelers vanuit video materiaal</p>
          </div>
          <BackToMenu />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Video className="w-5 h-5" />
              Video en Speler Selectie
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="video">Video</Label>
                <Select value={analysisData.videoId} onValueChange={(value) => setAnalysisData({ ...analysisData, videoId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer video" />
                  </SelectTrigger>
                  <SelectContent>
                    {videos?.map((video: any) => (
                      <SelectItem key={video.id} value={video.id.toString()}>
                        {video.title} - {video.season}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="player">Speler</Label>
                <Select value={analysisData.playerId} onValueChange={(value) => setAnalysisData({ ...analysisData, playerId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer speler" />
                  </SelectTrigger>
                  <SelectContent>
                    {players?.filter((player: any) => player.role === 'player').map((player: any) => (
                      <SelectItem key={player.id} value={player.id.toString()}>
                        {player.firstName} {player.lastName} #{player.jerseyNumber || player.id}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="analysisType">Type Analyse</Label>
              <Select value={analysisData.analysisType} onValueChange={(value: any) => setAnalysisData({ ...analysisData, analysisType: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technical_skills">Technische vaardigheden</SelectItem>
                  <SelectItem value="tactical_positioning">Tactische positionering</SelectItem>
                  <SelectItem value="physical_performance">Fysieke prestatie</SelectItem>
                  <SelectItem value="decision_making">Besluitvorming</SelectItem>
                  <SelectItem value="overall_performance">Algemene prestatie</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="startTime">Start tijd (minuten)</Label>
                <Input
                  id="startTime"
                  type="number"
                  min="0"
                  value={Math.floor((analysisData.startTime || 0) / 60)}
                  onChange={(e) => setAnalysisData({ ...analysisData, startTime: parseInt(e.target.value) * 60 })}
                />
              </div>
              <div>
                <Label htmlFor="endTime">Eind tijd (minuten)</Label>
                <Input
                  id="endTime"
                  type="number"
                  min="0"
                  value={Math.floor((analysisData.endTime || 0) / 60)}
                  onChange={(e) => setAnalysisData({ ...analysisData, endTime: parseInt(e.target.value) * 60 })}
                />
              </div>
              <div>
                <Label htmlFor="rating">Beoordeling (1-10)</Label>
                <Input
                  id="rating"
                  type="number"
                  min="1"
                  max="10"
                  value={analysisData.rating}
                  onChange={(e) => setAnalysisData({ ...analysisData, rating: parseInt(e.target.value) })}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Performance Statistics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Performance Statistieken
            </CardTitle>
            <CardDescription>
              Voer de prestatie-statistieken in die u hebt geobserveerd in de video
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Pass Statistics */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-600" />
                Passen
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="passesAttempted">Geprobeerd</Label>
                  <Input
                    id="passesAttempted"
                    type="number"
                    min="0"
                    value={analysisData.passesAttempted}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 0;
                      setAnalysisData({ ...analysisData, passesAttempted: value });
                      setTimeout(updateSuccessRates, 100);
                    }}
                  />
                </div>
                <div>
                  <Label htmlFor="passesCompleted">Succesvol</Label>
                  <Input
                    id="passesCompleted"
                    type="number"
                    min="0"
                    max={analysisData.passesAttempted}
                    value={analysisData.passesCompleted}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 0;
                      setAnalysisData({ ...analysisData, passesCompleted: value });
                      setTimeout(updateSuccessRates, 100);
                    }}
                  />
                </div>
                <div>
                  <Label>Succespercentage</Label>
                  <div className="p-2 bg-white rounded border text-center font-semibold text-blue-600">
                    {analysisData.passSuccessRate}%
                  </div>
                </div>
              </div>
            </div>

            {/* Dribbling Statistics */}
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Zap className="w-5 h-5 text-green-600" />
                Dribbels
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="dribblesAttempted">Geprobeerd</Label>
                  <Input
                    id="dribblesAttempted"
                    type="number"
                    min="0"
                    value={analysisData.dribblesAttempted}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 0;
                      setAnalysisData({ ...analysisData, dribblesAttempted: value });
                      setTimeout(updateSuccessRates, 100);
                    }}
                  />
                </div>
                <div>
                  <Label htmlFor="dribblesSuccessful">Succesvol</Label>
                  <Input
                    id="dribblesSuccessful"
                    type="number"
                    min="0"
                    max={analysisData.dribblesAttempted}
                    value={analysisData.dribblesSuccessful}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 0;
                      setAnalysisData({ ...analysisData, dribblesSuccessful: value });
                      setTimeout(updateSuccessRates, 100);
                    }}
                  />
                </div>
                <div>
                  <Label>Succespercentage</Label>
                  <div className="p-2 bg-white rounded border text-center font-semibold text-green-600">
                    {analysisData.dribbleSuccessRate}%
                  </div>
                </div>
              </div>
            </div>

            {/* Shooting Statistics */}
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-600" />
                Schoten
              </h3>
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="shotsTotal">Totaal Schoten</Label>
                  <Input
                    id="shotsTotal"
                    type="number"
                    min="0"
                    value={analysisData.shotsTotal}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 0;
                      setAnalysisData({ ...analysisData, shotsTotal: value });
                      setTimeout(updateSuccessRates, 100);
                    }}
                  />
                </div>
                <div>
                  <Label htmlFor="shotsOnTarget">Op Doel</Label>
                  <Input
                    id="shotsOnTarget"
                    type="number"
                    min="0"
                    max={analysisData.shotsTotal}
                    value={analysisData.shotsOnTarget}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 0;
                      setAnalysisData({ 
                        ...analysisData, 
                        shotsOnTarget: value,
                        shotsOffTarget: analysisData.shotsTotal - value
                      });
                      setTimeout(updateSuccessRates, 100);
                    }}
                  />
                </div>
                <div>
                  <Label>Naast Doel</Label>
                  <div className="p-2 bg-white rounded border text-center">
                    {analysisData.shotsOffTarget}
                  </div>
                </div>
                <div>
                  <Label>Precisie</Label>
                  <div className="p-2 bg-white rounded border text-center font-semibold text-purple-600">
                    {analysisData.shotAccuracy}%
                  </div>
                </div>
              </div>
            </div>

            {/* Defensive Statistics */}
            <div className="bg-red-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-red-600" />
                Verdedigende Acties
              </h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">Verdedigende Duels</h4>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label htmlFor="defensiveDuelsTotal">Totaal</Label>
                      <Input
                        id="defensiveDuelsTotal"
                        type="number"
                        min="0"
                        value={analysisData.defensiveDuelsTotal}
                        onChange={(e) => {
                          const value = parseInt(e.target.value) || 0;
                          setAnalysisData({ ...analysisData, defensiveDuelsTotal: value });
                          setTimeout(updateSuccessRates, 100);
                        }}
                      />
                    </div>
                    <div>
                      <Label htmlFor="defensiveDuelsWon">Gewonnen</Label>
                      <Input
                        id="defensiveDuelsWon"
                        type="number"
                        min="0"
                        max={analysisData.defensiveDuelsTotal}
                        value={analysisData.defensiveDuelsWon}
                        onChange={(e) => {
                          const value = parseInt(e.target.value) || 0;
                          setAnalysisData({ ...analysisData, defensiveDuelsWon: value });
                          setTimeout(updateSuccessRates, 100);
                        }}
                      />
                    </div>
                    <div>
                      <Label>Succes %</Label>
                      <div className="p-2 bg-white rounded border text-center font-semibold text-red-600">
                        {analysisData.defensiveDuelSuccessRate}%
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">1 tegen 1 Situaties</h4>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label htmlFor="oneVOneTotal">Totaal</Label>
                      <Input
                        id="oneVOneTotal"
                        type="number"
                        min="0"
                        value={analysisData.oneVOneTotal}
                        onChange={(e) => {
                          const value = parseInt(e.target.value) || 0;
                          setAnalysisData({ ...analysisData, oneVOneTotal: value });
                          setTimeout(updateSuccessRates, 100);
                        }}
                      />
                    </div>
                    <div>
                      <Label htmlFor="oneVOneWon">Gewonnen</Label>
                      <Input
                        id="oneVOneWon"
                        type="number"
                        min="0"
                        max={analysisData.oneVOneTotal}
                        value={analysisData.oneVOneWon}
                        onChange={(e) => {
                          const value = parseInt(e.target.value) || 0;
                          setAnalysisData({ ...analysisData, oneVOneWon: value });
                          setTimeout(updateSuccessRates, 100);
                        }}
                      />
                    </div>
                    <div>
                      <Label>Succes %</Label>
                      <div className="p-2 bg-white rounded border text-center font-semibold text-red-600">
                        {analysisData.oneVOneSuccessRate}%
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Additional Defensive Metrics */}
              <div className="mt-4 grid grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="tackles">Tackles</Label>
                  <Input
                    id="tackles"
                    type="number"
                    min="0"
                    value={analysisData.tackles}
                    onChange={(e) => setAnalysisData({ ...analysisData, tackles: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label htmlFor="interceptions">Onderscheppingen</Label>
                  <Input
                    id="interceptions"
                    type="number"
                    min="0"
                    value={analysisData.interceptions}
                    onChange={(e) => setAnalysisData({ ...analysisData, interceptions: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label htmlFor="ballRecoveries">Bal Heroveringen</Label>
                  <Input
                    id="ballRecoveries"
                    type="number"
                    min="0"
                    value={analysisData.ballRecoveries}
                    onChange={(e) => setAnalysisData({ ...analysisData, ballRecoveries: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label htmlFor="touches">Bal Contacten</Label>
                  <Input
                    id="touches"
                    type="number"
                    min="0"
                    value={analysisData.touches}
                    onChange={(e) => setAnalysisData({ ...analysisData, touches: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Kwalitatieve Analyse
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="notes">Opmerkingen</Label>
              <Textarea
                id="notes"
                value={analysisData.notes}
                onChange={(e) => setAnalysisData({ ...analysisData, notes: e.target.value })}
                placeholder="Algemene opmerkingen over de prestatie van de speler..."
                rows={4}
              />
            </div>

            <div>
              <Label className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Sterke punten
              </Label>
              <div className="flex gap-2 mt-2">
                <Input
                  value={newStrength}
                  onChange={(e) => setNewStrength(e.target.value)}
                  placeholder="Voeg een sterk punt toe..."
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addStrength())}
                />
                <Button type="button" onClick={addStrength}>Toevoegen</Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {analysisData.strengths.map((strength, index) => (
                  <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeStrength(index)}>
                    {strength} ×
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <Label className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                Verbeterpunten
              </Label>
              <div className="flex gap-2 mt-2">
                <Input
                  value={newImprovement}
                  onChange={(e) => setNewImprovement(e.target.value)}
                  placeholder="Voeg een verbeterpunt toe..."
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addImprovement())}
                />
                <Button type="button" onClick={addImprovement}>Toevoegen</Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {analysisData.improvements.map((improvement, index) => (
                  <Badge key={index} variant="outline" className="cursor-pointer" onClick={() => removeImprovement(index)}>
                    {improvement} ×
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <Label className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Belangrijke momenten
              </Label>
              <div className="grid grid-cols-3 gap-2 mt-2">
                <Input
                  type="number"
                  value={newMoment.time}
                  onChange={(e) => setNewMoment({ ...newMoment, time: parseInt(e.target.value) })}
                  placeholder="Tijd (seconden)"
                />
                <Input
                  value={newMoment.description}
                  onChange={(e) => setNewMoment({ ...newMoment, description: e.target.value })}
                  placeholder="Beschrijving van het moment..."
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addKeyMoment())}
                />
                <Button type="button" onClick={addKeyMoment}>Toevoegen</Button>
              </div>
              <div className="space-y-2 mt-2">
                {analysisData.keyMoments.map((moment, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded cursor-pointer" onClick={() => removeKeyMoment(index)}>
                    <span className="text-sm">
                      <strong>{formatTime(moment.time)}</strong>: {moment.description}
                    </span>
                    <span className="text-xs text-gray-500">×</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={createAnalysisMutation.isPending}>
            {createAnalysisMutation.isPending ? 'Opslaan...' : 'Analyse Opslaan'}
          </Button>
        </div>
      </form>
    </div>
  );
}