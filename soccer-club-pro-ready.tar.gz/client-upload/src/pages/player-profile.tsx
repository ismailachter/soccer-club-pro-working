import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { ArrowLeft, User, Mail, Phone, MapPin, Calendar, Save, Users } from 'lucide-react';

interface PlayerProfile {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: string;
  nickname?: string;
  address?: string;
  nationality?: string;
  joinDate?: string;
  club?: string;
  status?: string;
  position?: string;
  jerseyNumber?: number;
  teamId?: number;
  teamName?: string;
  preferredFoot?: string;
  height?: number;
  weight?: number;
  emergencyContact?: string;
  medicalNotes?: string;
}

export default function PlayerProfile() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);

  const { data: player, isLoading, error } = useQuery<PlayerProfile>({
    queryKey: ['/api/players', id],
  });

  const [formData, setFormData] = useState<Partial<PlayerProfile>>({});

  React.useEffect(() => {
    if (player) {
      setFormData(player);
    }
  }, [player]);

  const updatePlayerMutation = useMutation({
    mutationFn: async (data: Partial<PlayerProfile>) => {
      return await apiRequest(`/api/players/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Profiel bijgewerkt",
        description: "De speler gegevens zijn succesvol opgeslagen.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/players', id] });
      queryClient.invalidateQueries({ queryKey: ['/api/players/database'] });
      setIsEditing(false);
    },
    onError: (error: any) => {
      toast({
        title: "Fout bij opslaan",
        description: error.message || "Er is een fout opgetreden bij het opslaan.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="text-center mt-4">Profiel wordt geladen...</p>
      </div>
    );
  }

  if (error || !player) {
    return (
      <div className="p-6">
        <div className="text-center">
          <p className="text-red-600">Fout bij het laden van het speler profiel</p>
          <Button 
            variant="outline" 
            onClick={() => setLocation('/players-database')}
            className="mt-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Terug naar Database
          </Button>
        </div>
      </div>
    );
  }

  const handleSave = () => {
    updatePlayerMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setLocation('/players-database')}
            className="mr-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Terug
          </Button>
          <div className="flex items-center">
            <User className="h-6 w-6 mr-2" />
            <h1 className="text-2xl font-bold">
              {player.firstName} {player.lastName}
            </h1>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {player.teamName && (
            <Badge variant="outline" className="flex items-center">
              <Users className="h-3 w-3 mr-1" />
              {player.teamName}
            </Badge>
          )}
          {player.jerseyNumber && (
            <Badge variant="secondary">#{player.jerseyNumber}</Badge>
          )}
          {player.status && (
            <Badge variant={player.status === 'active' ? 'default' : 'secondary'}>
              {player.status}
            </Badge>
          )}
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Persoonlijke Gegevens</CardTitle>
            <div className="flex gap-2">
              {isEditing ? (
                <>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setIsEditing(false);
                      setFormData(player);
                    }}
                  >
                    Annuleren
                  </Button>
                  <Button 
                    size="sm"
                    onClick={handleSave}
                    disabled={updatePlayerMutation.isPending}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Opslaan
                  </Button>
                </>
              ) : (
                <Button size="sm" onClick={() => setIsEditing(true)}>
                  Bewerken
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">Voornaam</Label>
                {isEditing ? (
                  <Input
                    id="firstName"
                    value={formData.firstName || ''}
                    onChange={(e) => handleInputChange('firstName', e.target.value)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.firstName}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="lastName">Achternaam</Label>
                {isEditing ? (
                  <Input
                    id="lastName"
                    value={formData.lastName || ''}
                    onChange={(e) => handleInputChange('lastName', e.target.value)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.lastName}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="nickname">Bijnaam</Label>
                {isEditing ? (
                  <Input
                    id="nickname"
                    value={formData.nickname || ''}
                    onChange={(e) => handleInputChange('nickname', e.target.value)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.nickname || '-'}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">Geboortedatum</Label>
                {isEditing ? (
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth?.split('T')[0] || ''}
                    onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">
                    {player.dateOfBirth ? new Date(player.dateOfBirth).toLocaleDateString('nl-NL') : '-'}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="gender">Geslacht</Label>
                {isEditing ? (
                  <Select value={formData.gender || ''} onValueChange={(value) => handleInputChange('gender', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer geslacht" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Man</SelectItem>
                      <SelectItem value="female">Vrouw</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <p className="p-2 bg-gray-50 rounded">
                    {player.gender === 'male' ? 'Man' : player.gender === 'female' ? 'Vrouw' : '-'}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="nationality">Nationaliteit</Label>
                {isEditing ? (
                  <Input
                    id="nationality"
                    value={formData.nationality || ''}
                    onChange={(e) => handleInputChange('nationality', e.target.value)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.nationality || '-'}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Contact Gegevens</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                {isEditing ? (
                  <Input
                    id="email"
                    type="email"
                    value={formData.email || ''}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.email}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefoon</Label>
                {isEditing ? (
                  <Input
                    id="phone"
                    value={formData.phone || ''}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.phone || '-'}</p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Adres</Label>
              {isEditing ? (
                <Textarea
                  id="address"
                  value={formData.address || ''}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  rows={2}
                />
              ) : (
                <p className="p-2 bg-gray-50 rounded min-h-[3rem]">{player.address || '-'}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="emergencyContact">Noodcontact</Label>
              {isEditing ? (
                <Input
                  id="emergencyContact"
                  value={formData.emergencyContact || ''}
                  onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                />
              ) : (
                <p className="p-2 bg-gray-50 rounded">{player.emergencyContact || '-'}</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Speler Informatie</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="position">Positie</Label>
                {isEditing ? (
                  <Select value={formData.position || ''} onValueChange={(value) => handleInputChange('position', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer positie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="goalkeeper">Doelman</SelectItem>
                      <SelectItem value="defender">Verdediger</SelectItem>
                      <SelectItem value="midfielder">Middenvelder</SelectItem>
                      <SelectItem value="forward">Aanvaller</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.position || '-'}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="preferredFoot">Voorkeurvoet</Label>
                {isEditing ? (
                  <Select value={formData.preferredFoot || ''} onValueChange={(value) => handleInputChange('preferredFoot', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer voet" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="left">Links</SelectItem>
                      <SelectItem value="right">Rechts</SelectItem>
                      <SelectItem value="both">Beide</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <p className="p-2 bg-gray-50 rounded">
                    {player.preferredFoot === 'left' ? 'Links' : 
                     player.preferredFoot === 'right' ? 'Rechts' : 
                     player.preferredFoot === 'both' ? 'Beide' : '-'}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                {isEditing ? (
                  <Select value={formData.status || ''} onValueChange={(value) => handleInputChange('status', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Actief</SelectItem>
                      <SelectItem value="inactive">Inactief</SelectItem>
                      <SelectItem value="injured">Geblesseerd</SelectItem>
                      <SelectItem value="suspended">Geschorst</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.status || '-'}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="height">Lengte (cm)</Label>
                {isEditing ? (
                  <Input
                    id="height"
                    type="number"
                    value={formData.height || ''}
                    onChange={(e) => handleInputChange('height', e.target.value ? parseInt(e.target.value) : null)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.height ? `${player.height} cm` : '-'}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="weight">Gewicht (kg)</Label>
                {isEditing ? (
                  <Input
                    id="weight"
                    type="number"
                    value={formData.weight || ''}
                    onChange={(e) => handleInputChange('weight', e.target.value ? parseInt(e.target.value) : null)}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded">{player.weight ? `${player.weight} kg` : '-'}</p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="medicalNotes">Medische Opmerkingen</Label>
              {isEditing ? (
                <Textarea
                  id="medicalNotes"
                  value={formData.medicalNotes || ''}
                  onChange={(e) => handleInputChange('medicalNotes', e.target.value)}
                  rows={3}
                />
              ) : (
                <p className="p-2 bg-gray-50 rounded min-h-[4rem]">{player.medicalNotes || '-'}</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}