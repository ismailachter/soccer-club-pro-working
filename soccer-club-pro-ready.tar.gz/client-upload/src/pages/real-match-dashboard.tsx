import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Play, Video, Activity, MapPin, Clock, Users, TrendingUp } from 'lucide-react';

interface ProcessingStatus {
  status: string;
  totalFrames: number;
  expectedFrames: number;
  progressPercentage: number;
  videosProcessed: number;
  totalVideos: number;
  playersPerTeam: number;
  totalPlayers: number;
  videoStatus: Array<{
    videoId: string;
    framesExtracted: number;
    status: string;
  }>;
}

interface PhysicalData {
  playerId: string;
  team: string;
  jersey: number;
  movement: {
    distance: number;
    speed: { kmh: number; mps: number };
    acceleration: number;
    direction: number;
  };
  intensity: string;
}

export default function RealMatchDashboard() {
  const [processingStatus, setProcessingStatus] = useState<ProcessingStatus | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<string>('');
  const [physicalAnalysis, setPhysicalAnalysis] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    fetchProcessingStatus();
    const interval = setInterval(fetchProcessingStatus, 5000); // Update every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchProcessingStatus = async () => {
    try {
      const response = await fetch('/api/real-video-analysis');
      if (response.ok) {
        const data = await response.json();
        setProcessingStatus({
          status: 'completed',
          totalFrames: data.frameCount,
          expectedFrames: data.frameCount,
          progressPercentage: data.analysisProgress || 100,
          videosProcessed: 1,
          totalVideos: 1,
          playersPerTeam: 14,
          totalPlayers: 28,
          videoStatus: [{
            videoId: 'svelta-vvc-20250625',
            framesExtracted: data.frameCount,
            status: 'completed'
          }]
        });
        setPhysicalAnalysis(data);
        setSelectedVideo('svelta-vvc-20250625');
      }
    } catch (error) {
      console.error('Error fetching match data:', error);
    }
  };

  const analyzePhysicalPerformance = async (videoId: string) => {
    setIsAnalyzing(true);
    try {
      const response = await fetch(`/api/real-match/analyze-physical/${videoId}`, {
        method: 'POST'
      });
      const data = await response.json();
      setPhysicalAnalysis(data);
    } catch (error) {
      console.error('Error analyzing physical performance:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (!processingStatus) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Activity className="w-12 h-12 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-lg">Loading match analysis data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Real Match Analysis</h1>
          <p className="text-gray-600">Svelta Melsele vs VVC Brasschaat - Authentic Video Analysis</p>
        </div>
        <Badge variant="outline" className="text-lg px-4 py-2">
          {processingStatus.totalPlayers} Players ({processingStatus.playersPerTeam} per team)
        </Badge>
      </div>

      {/* Processing Status Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Video className="w-5 h-5" />
            Video Processing Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {processingStatus.totalFrames.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Frames Extracted</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {processingStatus.progressPercentage.toFixed(1)}%
              </div>
              <div className="text-sm text-gray-600">Complete</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {processingStatus.videosProcessed}/{processingStatus.totalVideos}
              </div>
              <div className="text-sm text-gray-600">Videos Processing</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">4.2GB</div>
              <div className="text-sm text-gray-600">Match Footage</div>
            </div>
          </div>

          <Progress 
            value={processingStatus.progressPercentage} 
            className="h-3 mb-4" 
          />
          
          <div className="text-center text-sm text-gray-600">
            Processing authentic match footage frame-by-frame at 1920x1080 resolution
          </div>
        </CardContent>
      </Card>

      {/* Video Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Select Video for Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {processingStatus.videoStatus.map((video, index) => (
              <Card 
                key={video.videoId}
                className={`cursor-pointer transition-all ${
                  selectedVideo === video.videoId 
                    ? 'ring-2 ring-blue-500 bg-blue-50' 
                    : 'hover:bg-gray-50'
                }`}
                onClick={() => setSelectedVideo(video.videoId)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold">Video {index + 1}</h3>
                    <Badge variant={video.status === 'processing' ? 'default' : 'secondary'}>
                      {video.status}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-600 mb-2">
                    {video.framesExtracted.toLocaleString()} frames extracted
                  </div>
                  <Progress 
                    value={(video.framesExtracted / 5522) * 100} 
                    className="h-2" 
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Analysis Actions */}
      <Tabs defaultValue="physical" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="physical">Physical Data</TabsTrigger>
          <TabsTrigger value="clips">Video Clips</TabsTrigger>
          <TabsTrigger value="heatmap">Heat Maps</TabsTrigger>
          <TabsTrigger value="timeline">Match Timeline</TabsTrigger>
        </TabsList>

        <TabsContent value="physical" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Physical Performance Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedVideo && (
                <div className="space-y-4">
                  <Button 
                    onClick={() => analyzePhysicalPerformance(selectedVideo)}
                    disabled={isAnalyzing}
                    className="w-full"
                  >
                    {isAnalyzing ? (
                      <>
                        <Activity className="w-4 h-4 animate-spin mr-2" />
                        Analyzing 28 Players...
                      </>
                    ) : (
                      <>
                        <TrendingUp className="w-4 h-4 mr-2" />
                        Analyze Physical Performance
                      </>
                    )}
                  </Button>

                  {physicalAnalysis && (
                    <div className="mt-6 space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-blue-50 p-4 rounded-lg">
                          <div className="text-lg font-semibold text-blue-700">
                            {physicalAnalysis.playersAnalyzed}
                          </div>
                          <div className="text-sm text-blue-600">Players Analyzed</div>
                        </div>
                        <div className="bg-green-50 p-4 rounded-lg">
                          <div className="text-lg font-semibold text-green-700">
                            {physicalAnalysis.framesAnalyzed}
                          </div>
                          <div className="text-sm text-green-600">Frames Processed</div>
                        </div>
                        <div className="bg-purple-50 p-4 rounded-lg">
                          <div className="text-lg font-semibold text-purple-700">
                            {Math.round(physicalAnalysis.timeRange.end - physicalAnalysis.timeRange.start)}s
                          </div>
                          <div className="text-sm text-purple-600">Time Analyzed</div>
                        </div>
                      </div>

                      <div className="border rounded-lg p-4">
                        <h4 className="font-semibold mb-3">Sample Physical Data</h4>
                        <div className="space-y-2 max-h-64 overflow-y-auto">
                          {physicalAnalysis.physicalData.slice(0, 10).map((data: any, index: number) => (
                            <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                              <div>
                                <span className="font-medium">{data.playerId}</span>
                                <span className="text-sm text-gray-600 ml-2">
                                  {data.movement.speed.kmh.toFixed(1)} km/h
                                </span>
                              </div>
                              <Badge variant={
                                data.intensity === 'SPRINTING' ? 'destructive' :
                                data.intensity === 'RUNNING' ? 'default' :
                                data.intensity === 'JOGGING' ? 'secondary' : 'outline'
                              }>
                                {data.intensity}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="clips">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="w-5 h-5" />
                Generate Video Clips
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Generate specific video clips from key moments in the match
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {['Goals', 'Corners', 'Free Kicks', 'Substitutions'].map((type) => (
                  <Button key={type} variant="outline" className="h-20 flex-col">
                    <Play className="w-6 h-6 mb-2" />
                    {type}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="heatmap">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Player Heat Maps
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                View movement patterns and positioning data for individual players
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timeline">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Match Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Key events and moments detected from video analysis
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}