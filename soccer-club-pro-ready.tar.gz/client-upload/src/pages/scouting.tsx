import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  ArrowLeft,
  Search,
  Plus,
  Eye,
  Edit,
  Star,
  MapPin,
  Calendar,
  Users,
  Target,
  TrendingUp,
  Award,
  Clock,
  Phone,
  Mail,
  User,
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ScoutedPlayer {
  id: number;
  firstName: string;
  lastName: string;
  email?: string;
  phone?: string;
  dateOfBirth: string;
  position: string;
  currentClub?: string;
  scoutedBy: string;
  scoutedDate: string;
  rating: number; // 1-10
  notes: string;
  technicalSkills: number; // 1-10
  physicalAttributes: number; // 1-10
  mentalStrength: number; // 1-10
  tacticalAwareness: number; // 1-10
  potential: number; // 1-10
  status: "interested" | "contacted" | "trial_scheduled" | "trial_completed" | "signed" | "declined";
  followUpDate?: string;
  createdAt: string;
}

interface Team {
  id: number;
  name: string;
  ageGroup: string;
}

export default function Scouting() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPosition, setSelectedPosition] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedRating, setSelectedRating] = useState("all");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<ScoutedPlayer | null>(null);

  const { toast } = useToast();

  const { data: scoutedPlayers = [], isLoading } = useQuery<ScoutedPlayer[]>({
    queryKey: ["/api/scouting"],
  });

  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const addPlayerMutation = useMutation({
    mutationFn: (newPlayer: Partial<ScoutedPlayer>) =>
      apiRequest("/api/scouting", {
        method: "POST",
        body: JSON.stringify(newPlayer),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scouting"] });
      setShowAddDialog(false);
      toast({
        title: "Speler toegevoegd",
        description: "Nieuwe speler is toegevoegd aan de scouting database.",
      });
    },
  });

  const updatePlayerMutation = useMutation({
    mutationFn: ({ id, ...updates }: Partial<ScoutedPlayer> & { id: number }) =>
      apiRequest(`/api/scouting/${id}`, {
        method: "PATCH",
        body: JSON.stringify(updates),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scouting"] });
      setEditingPlayer(null);
      toast({
        title: "Speler bijgewerkt",
        description: "Spelersgegevens zijn succesvol bijgewerkt.",
      });
    },
  });

  const filteredPlayers = scoutedPlayers.filter(player => {
    const matchesSearch = !searchTerm || 
      `${player.firstName} ${player.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      player.currentClub?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPosition = selectedPosition === "all" || player.position === selectedPosition;
    const matchesStatus = selectedStatus === "all" || player.status === selectedStatus;
    const matchesRating = selectedRating === "all" || player.rating >= parseInt(selectedRating);

    return matchesSearch && matchesPosition && matchesStatus && matchesRating;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "interested": return "bg-blue-100 text-blue-800";
      case "contacted": return "bg-yellow-100 text-yellow-800";
      case "trial_scheduled": return "bg-purple-100 text-purple-800";
      case "trial_completed": return "bg-orange-100 text-orange-800";
      case "signed": return "bg-green-100 text-green-800";
      case "declined": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "interested": return "Geïnteresseerd";
      case "contacted": return "Gecontacteerd";
      case "trial_scheduled": return "Proeftraining Gepland";
      case "trial_completed": return "Proeftraining Voltooid";
      case "signed": return "Getekend";
      case "declined": return "Afgewezen";
      default: return status;
    }
  };

  const getRatingStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.floor(rating / 2) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
        }`}
      />
    ));
  };

  const calculateAge = (dateOfBirth: string) => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="h-80 bg-gray-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Terug naar Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-4xl font-bold text-gray-900 flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center text-white">
                  <Search className="h-6 w-6" />
                </div>
                Scouting Database
              </h1>
              <p className="text-gray-600 mt-2">
                Beheer en volg potentiële spelers voor VVC Brasschaat
              </p>
            </div>
          </div>
          
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nieuwe Speler
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Nieuwe Speler Toevoegen</DialogTitle>
                <DialogDescription>
                  Voeg een nieuwe speler toe aan de scouting database
                </DialogDescription>
              </DialogHeader>
              <ScoutingForm 
                onSubmit={(data) => addPlayerMutation.mutate(data)}
                isLoading={addPlayerMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Filters & Zoeken
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div>
                <Label htmlFor="search">Zoeken</Label>
                <div className="relative">
                  <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="Naam of club..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div>
                <Label>Positie</Label>
                <Select value={selectedPosition} onValueChange={setSelectedPosition}>
                  <SelectTrigger>
                    <SelectValue placeholder="Alle posities" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle posities</SelectItem>
                    <SelectItem value="goalkeeper">Doelman</SelectItem>
                    <SelectItem value="defender">Verdediger</SelectItem>
                    <SelectItem value="midfielder">Middenvelder</SelectItem>
                    <SelectItem value="forward">Aanvaller</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Status</Label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Alle statussen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle statussen</SelectItem>
                    <SelectItem value="interested">Geïnteresseerd</SelectItem>
                    <SelectItem value="contacted">Gecontacteerd</SelectItem>
                    <SelectItem value="trial_scheduled">Proeftraining Gepland</SelectItem>
                    <SelectItem value="trial_completed">Proeftraining Voltooid</SelectItem>
                    <SelectItem value="signed">Getekend</SelectItem>
                    <SelectItem value="declined">Afgewezen</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Min. Rating</Label>
                <Select value={selectedRating} onValueChange={setSelectedRating}>
                  <SelectTrigger>
                    <SelectValue placeholder="Alle ratings" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle ratings</SelectItem>
                    <SelectItem value="8">8+ sterren</SelectItem>
                    <SelectItem value="7">7+ sterren</SelectItem>
                    <SelectItem value="6">6+ sterren</SelectItem>
                    <SelectItem value="5">5+ sterren</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("");
                    setSelectedPosition("all");
                    setSelectedStatus("all");
                    setSelectedRating("all");
                  }}
                  className="w-full"
                >
                  Reset Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{scoutedPlayers.length}</div>
              <div className="text-sm text-gray-600">Totaal Spelers</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {scoutedPlayers.filter(p => p.status === "signed").length}
              </div>
              <div className="text-sm text-gray-600">Getekend</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">
                {scoutedPlayers.filter(p => p.status === "trial_scheduled").length}
              </div>
              <div className="text-sm text-gray-600">Proeftraining</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {scoutedPlayers.filter(p => p.status === "contacted").length}
              </div>
              <div className="text-sm text-gray-600">Gecontacteerd</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">
                {Math.round(scoutedPlayers.reduce((acc, p) => acc + p.rating, 0) / scoutedPlayers.length * 10) / 10 || 0}
              </div>
              <div className="text-sm text-gray-600">Gem. Rating</div>
            </CardContent>
          </Card>
        </div>

        {/* Players Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlayers.map(player => (
            <Card key={player.id} className="group hover:shadow-xl transition-all duration-300 border-2 hover:border-purple-300">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg font-bold">
                      {player.firstName} {player.lastName}
                    </CardTitle>
                    <CardDescription className="flex items-center gap-2 mt-1">
                      <User className="h-3 w-3" />
                      {calculateAge(player.dateOfBirth)} jaar • {player.position}
                    </CardDescription>
                  </div>
                  <Badge className={`${getStatusColor(player.status)} text-xs`}>
                    {getStatusText(player.status)}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Rating */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Overall Rating</span>
                  <div className="flex items-center gap-1">
                    {getRatingStars(player.rating)}
                    <span className="text-sm ml-2 font-semibold">{player.rating}/10</span>
                  </div>
                </div>

                {/* Skills Breakdown */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span>Technisch</span>
                    <span className="font-medium">{player.technicalSkills}/10</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div
                      className="bg-blue-500 h-1.5 rounded-full"
                      style={{ width: `${(player.technicalSkills / 10) * 100}%` }}
                    ></div>
                  </div>
                  
                  <div className="flex justify-between text-xs">
                    <span>Fysiek</span>
                    <span className="font-medium">{player.physicalAttributes}/10</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div
                      className="bg-green-500 h-1.5 rounded-full"
                      style={{ width: `${(player.physicalAttributes / 10) * 100}%` }}
                    ></div>
                  </div>
                  
                  <div className="flex justify-between text-xs">
                    <span>Mentaal</span>
                    <span className="font-medium">{player.mentalStrength}/10</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div
                      className="bg-purple-500 h-1.5 rounded-full"
                      style={{ width: `${(player.mentalStrength / 10) * 100}%` }}
                    ></div>
                  </div>
                  
                  <div className="flex justify-between text-xs">
                    <span>Tactisch</span>
                    <span className="font-medium">{player.tacticalAwareness}/10</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div
                      className="bg-orange-500 h-1.5 rounded-full"
                      style={{ width: `${(player.tacticalAwareness / 10) * 100}%` }}
                    ></div>
                  </div>
                </div>

                {/* Additional Info */}
                <div className="pt-2 border-t border-gray-100 space-y-1">
                  {player.currentClub && (
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <MapPin className="h-3 w-3" />
                      {player.currentClub}
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-xs text-gray-600">
                    <Calendar className="h-3 w-3" />
                    Gescout: {new Date(player.scoutedDate).toLocaleDateString('nl-NL')}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-600">
                    <Eye className="h-3 w-3" />
                    Door: {player.scoutedBy}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => setEditingPlayer(player)}
                  >
                    <Edit className="h-3 w-3 mr-1" />
                    Bewerken
                  </Button>
                  <Button variant="outline" size="sm">
                    <Eye className="h-3 w-3 mr-1" />
                    Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredPlayers.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <Search className="h-16 w-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Geen Spelers Gevonden</h3>
              <p className="text-gray-600 mb-6">
                {scoutedPlayers.length === 0 
                  ? "Er zijn nog geen spelers in de scouting database."
                  : "Geen spelers gevonden met de huidige filters."
                }
              </p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Eerste Speler Toevoegen
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Edit Dialog */}
        <Dialog open={!!editingPlayer} onOpenChange={() => setEditingPlayer(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Speler Bewerken</DialogTitle>
              <DialogDescription>
                Wijzig de gegevens van {editingPlayer?.firstName} {editingPlayer?.lastName}
              </DialogDescription>
            </DialogHeader>
            {editingPlayer && (
              <ScoutingForm 
                initialData={editingPlayer}
                onSubmit={(data) => updatePlayerMutation.mutate({ id: editingPlayer.id, ...data })}
                isLoading={updatePlayerMutation.isPending}
              />
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

function ScoutingForm({ 
  initialData, 
  onSubmit, 
  isLoading 
}: { 
  initialData?: ScoutedPlayer;
  onSubmit: (data: Partial<ScoutedPlayer>) => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState({
    firstName: initialData?.firstName || "",
    lastName: initialData?.lastName || "",
    email: initialData?.email || "",
    phone: initialData?.phone || "",
    dateOfBirth: initialData?.dateOfBirth || "",
    position: initialData?.position || "",
    currentClub: initialData?.currentClub || "",
    scoutedBy: initialData?.scoutedBy || "",
    scoutedDate: initialData?.scoutedDate || new Date().toISOString().split('T')[0],
    rating: initialData?.rating || 5,
    notes: initialData?.notes || "",
    technicalSkills: initialData?.technicalSkills || 5,
    physicalAttributes: initialData?.physicalAttributes || 5,
    mentalStrength: initialData?.mentalStrength || 5,
    tacticalAwareness: initialData?.tacticalAwareness || 5,
    potential: initialData?.potential || 5,
    status: initialData?.status || "interested",
    followUpDate: initialData?.followUpDate || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="firstName">Voornaam *</Label>
          <Input
            id="firstName"
            value={formData.firstName}
            onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="lastName">Achternaam *</Label>
          <Input
            id="lastName"
            value={formData.lastName}
            onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="email">E-mail</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />
        </div>
        <div>
          <Label htmlFor="phone">Telefoon</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="dateOfBirth">Geboortedatum *</Label>
          <Input
            id="dateOfBirth"
            type="date"
            value={formData.dateOfBirth}
            onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="position">Positie *</Label>
          <Select value={formData.position} onValueChange={(value) => setFormData({ ...formData, position: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Selecteer positie" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="goalkeeper">Doelman</SelectItem>
              <SelectItem value="defender">Verdediger</SelectItem>
              <SelectItem value="midfielder">Middenvelder</SelectItem>
              <SelectItem value="forward">Aanvaller</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="currentClub">Huidige Club</Label>
          <Input
            id="currentClub"
            value={formData.currentClub}
            onChange={(e) => setFormData({ ...formData, currentClub: e.target.value })}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="scoutedBy">Gescout door *</Label>
          <Input
            id="scoutedBy"
            value={formData.scoutedBy}
            onChange={(e) => setFormData({ ...formData, scoutedBy: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="scoutedDate">Scout datum</Label>
          <Input
            id="scoutedDate"
            type="date"
            value={formData.scoutedDate}
            onChange={(e) => setFormData({ ...formData, scoutedDate: e.target.value })}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="technicalSkills">Technisch (1-10)</Label>
          <Input
            id="technicalSkills"
            type="number"
            min="1"
            max="10"
            value={formData.technicalSkills}
            onChange={(e) => setFormData({ ...formData, technicalSkills: parseInt(e.target.value) })}
          />
        </div>
        <div>
          <Label htmlFor="physicalAttributes">Fysiek (1-10)</Label>
          <Input
            id="physicalAttributes"
            type="number"
            min="1"
            max="10"
            value={formData.physicalAttributes}
            onChange={(e) => setFormData({ ...formData, physicalAttributes: parseInt(e.target.value) })}
          />
        </div>
        <div>
          <Label htmlFor="mentalStrength">Mentaal (1-10)</Label>
          <Input
            id="mentalStrength"
            type="number"
            min="1"
            max="10"
            value={formData.mentalStrength}
            onChange={(e) => setFormData({ ...formData, mentalStrength: parseInt(e.target.value) })}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="tacticalAwareness">Tactisch (1-10)</Label>
          <Input
            id="tacticalAwareness"
            type="number"
            min="1"
            max="10"
            value={formData.tacticalAwareness}
            onChange={(e) => setFormData({ ...formData, tacticalAwareness: parseInt(e.target.value) })}
          />
        </div>
        <div>
          <Label htmlFor="potential">Potentie (1-10)</Label>
          <Input
            id="potential"
            type="number"
            min="1"
            max="10"
            value={formData.potential}
            onChange={(e) => setFormData({ ...formData, potential: parseInt(e.target.value) })}
          />
        </div>
        <div>
          <Label htmlFor="rating">Rating (1-10)</Label>
          <Input
            id="rating"
            type="number"
            min="1"
            max="10"
            value={formData.rating}
            onChange={(e) => setFormData({ ...formData, rating: parseInt(e.target.value) })}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="status">Status</Label>
          <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value as any })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="interested">Geïnteresseerd</SelectItem>
              <SelectItem value="contacted">Gecontacteerd</SelectItem>
              <SelectItem value="trial_scheduled">Proeftraining Gepland</SelectItem>
              <SelectItem value="trial_completed">Proeftraining Voltooid</SelectItem>
              <SelectItem value="signed">Getekend</SelectItem>
              <SelectItem value="declined">Afgewezen</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="followUpDate">Opvolg datum</Label>
          <Input
            id="followUpDate"
            type="date"
            value={formData.followUpDate}
            onChange={(e) => setFormData({ ...formData, followUpDate: e.target.value })}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="notes">Notities</Label>
        <Textarea
          id="notes"
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          rows={3}
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Opslaan..." : initialData ? "Bijwerken" : "Toevoegen"}
        </Button>
      </div>
    </form>
  );
}