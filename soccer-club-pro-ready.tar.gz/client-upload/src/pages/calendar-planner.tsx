import { useState, useEffect } from 'react';
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, Target, Users, MapPin, Star, Plus, Edit, Trash2, Eye, Filter, Search, ChevronLeft, ChevronRight, Zap, Brain, Dumbbell, Trophy, ArrowLeft } from "lucide-react";
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO, addWeeks, subWeeks, addMonths, startOfMonth, endOfMonth, eachWeekOfInterval, getWeek } from 'date-fns';
import { nl } from 'date-fns/locale';
import { Link } from 'wouter';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface TrainingSession {
  id: string;
  planId: number;
  week: number;
  session: number;
  date: string;
  time: string;
  duration: number;
  focusArea: string;
  location: string;
  ageGroup: string;
  assignedElements: string[];
  intensity: 'low' | 'medium' | 'high';
  weather: 'indoor' | 'outdoor';
  notes: string;
  status: 'planned' | 'completed' | 'cancelled';
}

interface CalendarPlannerProps {
  params?: { planId: string };
}

export default function CalendarPlanner(props: any) {
  const planId = props.params?.planId;
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day'>('month');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);
  const [editingSession, setEditingSession] = useState<TrainingSession | null>(null);
  
  // Form states
  const [sessionData, setSessionData] = useState({
    date: '',
    time: '19:00',
    duration: 90,
    focusArea: '',
    location: 'Hoofdveld',
    intensity: 'medium' as 'low' | 'medium' | 'high',
    notes: '',
    assignedElements: [] as string[]
  });

  // IADATABANK state
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubcategory, setSelectedSubcategory] = useState('');
  const [selectedProgression, setSelectedProgression] = useState(1);

  // Fetch data
  const { data: yearPlans = [], isLoading: isLoadingPlans } = useQuery({ queryKey: ['/api/year-plans'] });
  const { data: iaElements = [] } = useQuery({ queryKey: ['/api/iadatabank/elements'] });
  const { data: sessions = [] } = useQuery({ 
    queryKey: ['/api/year-plans', selectedPlan?.id, 'sessions'], 
    enabled: !!selectedPlan 
  });

  // Set initial plan if planId is provided
  useEffect(() => {
    if (planId && yearPlans && Array.isArray(yearPlans) && yearPlans.length > 0) {
      const plan = yearPlans.find((p: any) => p.id === parseInt(planId));
      if (plan) {
        setSelectedPlan(plan);
      }
    }
  }, [planId, yearPlans]);

  // Get categories from IADATABANK
  const getCategories = () => {
    if (!iaElements) return [];
    const elements = Array.isArray(iaElements) ? iaElements : (iaElements as any)?.data || [];
    return Array.from(new Set(elements.map((el: any) => el.topic))).filter(Boolean);
  };

  const getSubcategories = () => {
    if (!iaElements || !selectedCategory) return [];
    const elements = Array.isArray(iaElements) ? iaElements : (iaElements as any)?.data || [];
    return Array.from(new Set(elements.filter((el: any) => el.topic === selectedCategory).map((el: any) => el.subtopic))).filter(Boolean);
  };

  const getProgressionLevels = () => {
    if (!iaElements || !selectedCategory || !selectedSubcategory) return [];
    const elements = Array.isArray(iaElements) ? iaElements : (iaElements as any)?.data || [];
    const matchingElements = elements.filter((el: any) => 
      el.topic === selectedCategory && el.subtopic === selectedSubcategory
    );
    
    if (matchingElements.length === 0) return [];
    const firstElement = matchingElements[0];
    return firstElement.progressions || [];
  };

  // Calendar navigation
  const goToPreviousMonth = () => {
    setCurrentDate(prev => addMonths(prev, -1));
  };

  const goToNextMonth = () => {
    setCurrentDate(prev => addMonths(prev, 1));
  };

  const goToPreviousWeek = () => {
    setCurrentDate(prev => addWeeks(prev, -1));
  };

  const goToNextWeek = () => {
    setCurrentDate(prev => addWeeks(prev, 1));
  };

  // Get calendar days for month view
  const getCalendarDays = () => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    const startWeek = startOfWeek(start, { weekStartsOn: 1 });
    const endWeek = endOfWeek(end, { weekStartsOn: 1 });
    
    return eachDayOfInterval({ start: startWeek, end: endWeek });
  };

  // Get sessions for a specific date
  const getSessionsForDate = (date: Date) => {
    if (!Array.isArray(sessions)) return [];
    return sessions.filter((session: TrainingSession) => 
      isSameDay(parseISO(session.date), date)
    );
  };

  // Check if a date is available for training based on plan settings
  const isDateAvailable = (date: Date) => {
    if (!selectedPlan || !selectedPlan.startDate || !selectedPlan.endDate) return false;
    
    // Check if date is within plan range
    try {
      const planStart = parseISO(selectedPlan.startDate);
      const planEnd = parseISO(selectedPlan.endDate);
      
      if (date < planStart || date > planEnd) {
        return false;
      }
    } catch (error) {
      return false;
    }
    
    // Check if it's a training day
    if (!selectedPlan.trainingDays || !Array.isArray(selectedPlan.trainingDays)) {
      return false;
    }
    
    const dayName = format(date, 'EEEE', { locale: nl });
    const dayMapping: { [key: string]: string } = {
      'maandag': 'Maandag',
      'dinsdag': 'Dinsdag', 
      'woensdag': 'Woensdag',
      'donderdag': 'Donderdag',
      'vrijdag': 'Vrijdag',
      'zaterdag': 'Zaterdag',
      'zondag': 'Zondag'
    };
    
    const dutchDayName = dayMapping[dayName.toLowerCase()];
    return selectedPlan.trainingDays.includes(dutchDayName);
  };

  // Handle session creation/editing
  const handleSaveSession = async () => {
    if (!selectedPlan || !selectedDate) return;
    
    try {
      const sessionPayload = {
        ...sessionData,
        date: format(selectedDate, 'yyyy-MM-dd'),
        planId: selectedPlan.id,
        ageGroup: selectedPlan.ageGroup,
        week: getWeek(selectedDate),
        session: getSessionsForDate(selectedDate).length + 1
      };

      if (editingSession) {
        await apiRequest('PUT', `/api/year-plans/${selectedPlan.id}/sessions/${editingSession.id}`, sessionPayload);
        toast({ title: "Training bijgewerkt", description: "De training is succesvol bijgewerkt." });
      } else {
        await apiRequest('POST', `/api/year-plans/${selectedPlan.id}/sessions`, sessionPayload);
        toast({ title: "Training toegevoegd", description: "De nieuwe training is succesvol toegevoegd." });
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans', selectedPlan.id, 'sessions'] });
      setShowSessionDialog(false);
      setEditingSession(null);
      setSessionData({
        date: '',
        time: '19:00',
        duration: 90,
        focusArea: '',
        location: 'Hoofdveld',
        intensity: 'medium',
        notes: '',
        assignedElements: []
      });
    } catch (error) {
      toast({ title: "Fout", description: "Kon training niet opslaan", variant: "destructive" });
    }
  };

  const handleAddElement = () => {
    if (!selectedCategory || !selectedSubcategory) {
      toast({ title: "Fout", description: "Selecteer eerst een categorie en subcategorie", variant: "destructive" });
      return;
    }

    const progressionLevels = getProgressionLevels();
    if (progressionLevels.length === 0) {
      toast({ title: "Fout", description: "Geen progressie niveaus gevonden", variant: "destructive" });
      return;
    }

    const selectedLevel = progressionLevels[selectedProgression - 1];
    const elementName = `${selectedCategory} - ${selectedSubcategory} - ${selectedLevel}`;
    
    if (!sessionData.assignedElements.includes(elementName)) {
      setSessionData(prev => ({
        ...prev,
        assignedElements: [...prev.assignedElements, elementName]
      }));
      
      toast({ title: "Element toegevoegd", description: `${elementName} is toegevoegd aan de training` });
    } else {
      toast({ title: "Waarschuwing", description: "Dit element is al toegevoegd", variant: "destructive" });
    }
  };

  const removeElement = (elementToRemove: string) => {
    setSessionData(prev => ({
      ...prev,
      assignedElements: prev.assignedElements.filter(el => el !== elementToRemove)
    }));
  };

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    if (category.includes('BASICS')) return '⚽';
    if (category.includes('TEAMTACTISCH')) return '🎯';
    if (category.includes('MENTAAL')) return '🧠';
    if (category.includes('PHYSIEK')) return '💪';
    return '🏃';
  };

  if (isLoadingPlans) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-8 rounded-2xl shadow-xl">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/jaarplanning">
              <Button variant="ghost" className="text-white hover:bg-white/10 p-2">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold mb-2">Kalender Planner</h1>
              <p className="text-blue-100">
                {selectedPlan ? `Planning voor: ${selectedPlan.name}` : 'Selecteer een jaarplanning'}
              </p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button 
              variant={viewMode === 'month' ? 'secondary' : 'outline'} 
              onClick={() => setViewMode('month')}
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              Maand
            </Button>
            <Button 
              variant={viewMode === 'week' ? 'secondary' : 'outline'} 
              onClick={() => setViewMode('week')}
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              Week
            </Button>
          </div>
        </div>

        {/* Stats */}
        {selectedPlan && (
          <div className="grid grid-cols-4 gap-4 mt-6">
            <div className="bg-white/10 rounded-lg p-4">
              <div className="text-2xl font-bold">{Array.isArray(sessions) ? sessions.length : 0}</div>
              <div className="text-sm text-blue-100">Trainingen</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <div className="text-2xl font-bold">{selectedPlan.ageGroup}</div>
              <div className="text-sm text-blue-100">Leeftijdsgroep</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <div className="text-2xl font-bold">
                {Array.isArray(sessions) ? sessions.reduce((acc: number, s: any) => acc + (s.duration || 0), 0) : 0}
              </div>
              <div className="text-sm text-blue-100">Totaal Minuten</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <div className="text-2xl font-bold">
                {Array.isArray(sessions) ? sessions.filter((s: any) => s.assignedElements?.length > 0).length : 0}
              </div>
              <div className="text-sm text-blue-100">Met IADATABANK</div>
            </div>
          </div>
        )}
      </div>

      {/* Plan Selection */}
      {!selectedPlan && (
        <Card>
          <CardHeader>
            <CardTitle>Selecteer Jaarplanning</CardTitle>
            <CardDescription>Kies een jaarplanning om de kalender te bekijken</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {yearPlans && Array.isArray(yearPlans) && yearPlans.map((plan: YearPlan) => (
                <Card 
                  key={plan.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => setSelectedPlan(plan)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold">{plan.name}</h3>
                        <p className="text-sm text-gray-600">{plan.ageGroup} • {plan.season}</p>
                      </div>
                      <Badge variant={plan.status === 'active' ? 'default' : 'secondary'}>
                        {plan.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Calendar View */}
      {selectedPlan && (
        <>
          {/* Calendar Navigation */}
          <Card>
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <Button
                    variant="outline"
                    onClick={viewMode === 'month' ? goToPreviousMonth : goToPreviousWeek}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <h2 className="text-xl font-semibold">
                    {format(currentDate, 'MMMM yyyy', { locale: nl })}
                  </h2>
                  <Button
                    variant="outline"
                    onClick={viewMode === 'month' ? goToNextMonth : goToNextWeek}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                <Button
                  onClick={() => {
                    setSelectedDate(new Date());
                    setShowSessionDialog(true);
                  }}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Nieuwe Training
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Month Calendar */}
          {viewMode === 'month' && (
            <Card>
              <CardContent className="p-6">
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map(day => (
                    <div key={day} className="p-2 text-center font-medium text-gray-600">
                      {day}
                    </div>
                  ))}
                </div>
                
                <div className="grid grid-cols-7 gap-1">
                  {getCalendarDays().map((day, index) => {
                    const daysessions = getSessionsForDate(day);
                    const isCurrentMonth = day.getMonth() === currentDate.getMonth();
                    const isToday = isSameDay(day, new Date());
                    const isAvailable = isDateAvailable(day);
                    
                    return (
                      <div
                        key={index}
                        className={`
                          min-h-24 border rounded-lg p-2 transition-colors
                          ${!isCurrentMonth ? 'bg-gray-50 text-gray-400' :
                            isAvailable ? 'bg-white hover:bg-green-50 cursor-pointer border-green-200' :
                            'bg-gray-100 text-gray-400 cursor-not-allowed'
                          }
                          ${isToday && isAvailable ? 'border-blue-500 bg-blue-50' : ''}
                          ${isToday && !isAvailable ? 'border-gray-400' : ''}
                        `}
                        onClick={() => {
                          if (isAvailable) {
                            setSelectedDate(day);
                            setShowSessionDialog(true);
                          }
                        }}
                      >
                        <div className={`text-sm ${isToday ? 'font-bold text-blue-600' : ''}`}>
                          {day.getDate()}
                        </div>
                        {isAvailable && (
                          <div className="space-y-1 mt-1">
                            {daysessions.slice(0, 2).map((session: TrainingSession) => (
                              <div
                                key={session.id}
                                className={`text-xs px-2 py-1 rounded truncate ${getIntensityColor(session.intensity)}`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedSession(session);
                                }}
                              >
                                {session.time} {getCategoryIcon(session.focusArea)}
                              </div>
                            ))}
                            {daysessions.length > 2 && (
                              <div className="text-xs text-gray-500">
                                +{daysessions.length - 2} meer
                              </div>
                            )}
                            {daysessions.length === 0 && (
                              <div className="text-xs text-green-600 font-medium">
                                + Training toevoegen
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {/* Session Dialog */}
      <Dialog open={showSessionDialog} onOpenChange={setShowSessionDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingSession ? 'Training Bewerken' : 'Nieuwe Training Toevoegen'}
            </DialogTitle>
            <DialogDescription>
              {selectedDate && `Datum: ${format(selectedDate, 'dd MMMM yyyy', { locale: nl })}`}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Basic Session Info */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="time">Tijd</Label>
                <Input
                  id="time"
                  type="time"
                  value={sessionData.time}
                  onChange={(e) => setSessionData(prev => ({ ...prev, time: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="duration">Duur (minuten)</Label>
                <Input
                  id="duration"
                  type="number"
                  value={sessionData.duration}
                  onChange={(e) => setSessionData(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                />
              </div>
              <div>
                <Label htmlFor="location">Locatie</Label>
                <Input
                  id="location"
                  value={sessionData.location}
                  onChange={(e) => setSessionData(prev => ({ ...prev, location: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="intensity">Intensiteit</Label>
                <Select 
                  value={sessionData.intensity} 
                  onValueChange={(value) => setSessionData(prev => ({ ...prev, intensity: value as 'low' | 'medium' | 'high' }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Laag</SelectItem>
                    <SelectItem value="medium">Gemiddeld</SelectItem>
                    <SelectItem value="high">Hoog</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* IADATABANK Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">IADATABANK Elementen Toevoegen</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label>Categorie</Label>
                    <Select 
                      value={selectedCategory} 
                      onValueChange={(value) => {
                        setSelectedCategory(value);
                        setSelectedSubcategory('');
                        setSelectedProgression(1);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer categorie" />
                      </SelectTrigger>
                      <SelectContent>
                        {getCategories().map(category => (
                          <SelectItem key={category} value={category}>
                            {getCategoryIcon(category)} {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Subcategorie</Label>
                    <Select 
                      value={selectedSubcategory} 
                      onValueChange={(value) => {
                        setSelectedSubcategory(value);
                        setSelectedProgression(1);
                      }}
                      disabled={!selectedCategory}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={selectedCategory ? "Selecteer subcategorie" : "Selecteer eerst categorie"} />
                      </SelectTrigger>
                      <SelectContent>
                        {getSubcategories().map(subcategory => (
                          <SelectItem key={subcategory} value={subcategory}>
                            {subcategory}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Progressie Niveau</Label>
                    <Select 
                      value={String(selectedProgression)} 
                      onValueChange={(value) => setSelectedProgression(parseInt(value) || 1)}
                      disabled={getProgressionLevels().length === 0}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={getProgressionLevels().length === 0 ? "Selecteer eerst categorie en subcategorie" : "Selecteer niveau"} />
                      </SelectTrigger>
                      <SelectContent>
                        {getProgressionLevels().map((level: string, index: number) => (
                          <SelectItem key={index + 1} value={String(index + 1)}>
                            {level}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button 
                  onClick={handleAddElement}
                  disabled={!selectedCategory || !selectedSubcategory}
                  className="w-full"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Element Toevoegen
                </Button>

                {/* Assigned Elements */}
                {sessionData.assignedElements.length > 0 && (
                  <div>
                    <Label>Toegevoegde Elementen</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {sessionData.assignedElements.map((element, index) => (
                        <Badge key={index} variant="secondary" className="flex items-center gap-1">
                          {element}
                          <button
                            onClick={() => removeElement(element)}
                            className="ml-1 hover:text-red-600"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Notes */}
            <div>
              <Label htmlFor="notes">Notities</Label>
              <Textarea
                id="notes"
                value={sessionData.notes}
                onChange={(e) => setSessionData(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Voeg notities toe voor deze training..."
              />
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowSessionDialog(false)}>
                Annuleren
              </Button>
              <Button onClick={handleSaveSession}>
                {editingSession ? 'Bijwerken' : 'Opslaan'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Session Detail Dialog */}
      <Dialog open={!!selectedSession} onOpenChange={() => setSelectedSession(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Training Details</DialogTitle>
          </DialogHeader>
          {selectedSession && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Datum & Tijd</Label>
                  <p>{selectedSession.date} om {selectedSession.time}</p>
                </div>
                <div>
                  <Label>Duur</Label>
                  <p>{selectedSession.duration} minuten</p>
                </div>
                <div>
                  <Label>Locatie</Label>
                  <p>{selectedSession.location}</p>
                </div>
                <div>
                  <Label>Intensiteit</Label>
                  <Badge className={getIntensityColor(selectedSession.intensity)}>
                    {selectedSession.intensity.toUpperCase()}
                  </Badge>
                </div>
              </div>
              
              {selectedSession.assignedElements.length > 0 && (
                <div>
                  <Label>IADATABANK Elementen</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedSession.assignedElements.map((element, i) => (
                      <Badge key={i} variant="outline">
                        {element}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedSession.notes && (
                <div>
                  <Label>Notities</Label>
                  <p className="text-sm bg-gray-50 p-3 rounded">{selectedSession.notes}</p>
                </div>
              )}
              
              <div className="flex justify-end gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setEditingSession(selectedSession);
                    setSessionData({
                      date: selectedSession.date,
                      time: selectedSession.time,
                      duration: selectedSession.duration,
                      focusArea: selectedSession.focusArea,
                      location: selectedSession.location,
                      intensity: selectedSession.intensity,
                      notes: selectedSession.notes,
                      assignedElements: selectedSession.assignedElements
                    });
                    setSelectedSession(null);
                    setShowSessionDialog(true);
                  }}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Bewerken
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}