import { useState } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Mail, UserPlus, Send, ArrowLeft, Users, Settings, Trash2, Edit, Phone, Clock, CheckCircle2, XCircle } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";

export default function Invitations() {
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [selectedTeam, setSelectedTeam] = useState<string>("all");
  const [inviteData, setInviteData] = useState({
    email: "",
    firstName: "",
    lastName: "",
    role: "player",
    message: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, hasPermission } = useAuth();

  // Fetch all users
  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ['/api/users'],
  });

  // Fetch all teams
  const { data: teams = [], isLoading: teamsLoading } = useQuery({
    queryKey: ['/api/teams'],
  });

  // Fetch all players with user data
  const { data: players = [], isLoading: playersLoading } = useQuery({
    queryKey: ['/api/players-with-users'],
  });

  // Fetch all parents with user data
  const { data: parents = [], isLoading: parentsLoading } = useQuery({
    queryKey: ['/api/parents-with-users'],
  });

  const sendInviteMutation = useMutation({
    mutationFn: async (data: typeof inviteData) => {
      const response = await apiRequest("/api/invitations/send", {
        method: "POST",
        body: JSON.stringify(data),
      });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Uitnodiging verzonden",
        description: "De uitnodiging is succesvol verzonden via One.com mailserver.",
      });
      setIsInviteOpen(false);
      setInviteData({
        email: "",
        firstName: "",
        lastName: "",
        role: "player",
        message: ""
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/players-with-users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/parents-with-users'] });
    },
    onError: (error) => {
      toast({
        title: "Fout",
        description: "Er is een fout opgetreden bij het verzenden van de uitnodiging.",
        variant: "destructive",
      });
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      const response = await apiRequest(`/api/users/${userData.id}`, {
        method: "PATCH",
        body: JSON.stringify(userData),
      });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Gebruiker bijgewerkt",
        description: "De gebruikersgegevens zijn succesvol bijgewerkt.",
      });
      setIsEditOpen(false);
      setEditingUser(null);
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/players-with-users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/parents-with-users'] });
    },
    onError: (error) => {
      toast({
        title: "Fout",
        description: "Er is een fout opgetreden bij het bijwerken van de gebruiker.",
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest(`/api/users/${userId}`, {
        method: "DELETE",
      });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Gebruiker verwijderd",
        description: "De gebruiker is succesvol verwijderd.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/players-with-users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/parents-with-users'] });
    },
    onError: (error) => {
      toast({
        title: "Fout",
        description: "Er is een fout opgetreden bij het verwijderen van de gebruiker.",
        variant: "destructive",
      });
    },
  });

  const formatLastLogin = (lastLogin: string | null) => {
    if (!lastLogin) return "Nooit ingelogd";
    return new Date(lastLogin).toLocaleDateString('nl-BE', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getConnectionStatus = (lastLogin: string | null) => {
    if (lastLogin) {
      return { connected: true, icon: CheckCircle2, color: "text-green-600" };
    }
    return { connected: false, icon: XCircle, color: "text-red-600" };
  };

  const filteredPlayers = players.filter((player: any) => 
    selectedTeam === "all" || player.teamId?.toString() === selectedTeam
  );

  const roleDisplayMap = {
    'admin': 'Administrator',
    'coach': 'Coach', 
    'player': 'Speelster',
    'parent': 'Ouder',
    'coordinator': 'Coördinator',
    'trainer': 'Trainer'
  };

  const handleSendInvite = () => {
    if (!inviteData.email || !inviteData.firstName || !inviteData.lastName) {
      toast({
        title: "Vereiste velden",
        description: "Voer alle vereiste velden in.",
        variant: "destructive",
      });
      return;
    }
    sendInviteMutation.mutate(inviteData);
  };

  const handleEditUser = (user: any) => {
    setEditingUser(user);
    setIsEditOpen(true);
  };

  const handleUpdateUser = () => {
    if (!editingUser) return;
    updateUserMutation.mutate(editingUser);
  };

  const handleDeleteUser = (userId: number) => {
    if (confirm("Weet je zeker dat je deze gebruiker wilt verwijderen?")) {
      deleteUserMutation.mutate(userId);
    }
  };

  // Group players by team
  const playersByTeam = filteredPlayers.reduce((acc: any, player: any) => {
    const teamName = player.teamName || 'Geen team';
    if (!acc[teamName]) {
      acc[teamName] = [];
    }
    acc[teamName].push(player);
    return acc;
  }, {});

  if (usersLoading || teamsLoading || playersLoading || parentsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-xl">Laden...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Uitnodigingen</h1>
            <p className="text-muted-foreground">Beheer gebruikersuitnodigingen per team</p>
          </div>
        </div>
        <Button onClick={() => setIsInviteOpen(true)}>
          <UserPlus className="h-4 w-4 mr-2" />
          Nieuwe Uitnodiging
        </Button>
      </div>

      <Tabs defaultValue="players" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="players">Speelsters</TabsTrigger>
          <TabsTrigger value="parents">Ouders</TabsTrigger>
          <TabsTrigger value="staff">Staf</TabsTrigger>
          <TabsTrigger value="all">Alle Gebruikers</TabsTrigger>
        </TabsList>

        <TabsContent value="players" className="space-y-6">
          <div className="flex items-center gap-4 mb-4">
            <Select value={selectedTeam} onValueChange={setSelectedTeam}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Selecteer team" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle teams</SelectItem>
                {teams.map((team: any) => (
                  <SelectItem key={team.id} value={team.id.toString()}>
                    {team.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {Object.entries(playersByTeam).map(([teamName, teamPlayers]: [string, any]) => (
            <Card key={teamName}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  {teamName} ({teamPlayers.length} speelsters)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {teamPlayers.map((player: any) => {
                    const status = getConnectionStatus(player.lastLogin);
                    const StatusIcon = status.icon;
                    
                    return (
                      <div key={player.playerId} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                            <span className="text-sm font-medium">
                              {player.firstName?.[0]}{player.lastName?.[0]}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium">{player.firstName} {player.lastName}</p>
                            <p className="text-sm text-muted-foreground">{player.email}</p>
                            {player.phone && (
                              <p className="text-xs text-muted-foreground flex items-center gap-1">
                                <Phone className="h-3 w-3" />
                                {player.phone}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <Badge variant="outline">{player.position || 'Geen positie'}</Badge>
                          <div className={`flex items-center gap-1 ${status.color}`}>
                            <StatusIcon className="h-4 w-4" />
                            <div className="text-xs">
                              <div>{status.connected ? 'Verbonden' : 'Niet verbonden'}</div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {formatLastLogin(player.lastLogin)}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleEditUser({
                                id: player.userId,
                                firstName: player.firstName,
                                lastName: player.lastName,
                                email: player.email,
                                role: 'player'
                              })}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleDeleteUser(player.userId)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                            {!status.connected && (
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => {
                                  setInviteData({
                                    email: player.email || '',
                                    firstName: player.firstName || '',
                                    lastName: player.lastName || '',
                                    role: 'player',
                                    message: ''
                                  });
                                  setIsInviteOpen(true);
                                }}
                              >
                                <Mail className="h-3 w-3 mr-1" />
                                Uitnodigen
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="parents" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Ouders ({parents.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {parents.map((parent: any) => {
                  const status = getConnectionStatus(parent.lastLogin);
                  const StatusIcon = status.icon;
                  
                  return (
                    <div key={parent.parentId} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium">
                            {parent.firstName?.[0]}{parent.lastName?.[0]}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium">{parent.firstName} {parent.lastName}</p>
                          <p className="text-sm text-muted-foreground">{parent.email}</p>
                          {parent.phone && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {parent.phone}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant="outline">{parent.relationship || 'Ouder'}</Badge>
                        <div className={`flex items-center gap-1 ${status.color}`}>
                          <StatusIcon className="h-4 w-4" />
                          <div className="text-xs">
                            <div>{status.connected ? 'Verbonden' : 'Niet verbonden'}</div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {formatLastLogin(parent.lastLogin)}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleEditUser({
                              id: parent.userId,
                              firstName: parent.firstName,
                              lastName: parent.lastName,
                              email: parent.email,
                              role: 'parent'
                            })}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleDeleteUser(parent.userId)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                          {!status.connected && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setInviteData({
                                  email: parent.email || '',
                                  firstName: parent.firstName || '',
                                  lastName: parent.lastName || '',
                                  role: 'parent',
                                  message: ''
                                });
                                setIsInviteOpen(true);
                              }}
                            >
                              <Mail className="h-3 w-3 mr-1" />
                              Uitnodigen
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="staff" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Staf & Beheer
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {users.filter((user: any) => ['admin', 'coach', 'coordinator', 'trainer'].includes(user.role)).map((user: any) => {
                  const status = getConnectionStatus(user.lastLogin);
                  const StatusIcon = status.icon;
                  
                  return (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium">
                            {user.firstName?.[0]}{user.lastName?.[0]}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium">{user.firstName} {user.lastName}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant="outline">{roleDisplayMap[user.role as keyof typeof roleDisplayMap] || user.role}</Badge>
                        <div className={`flex items-center gap-1 ${status.color}`}>
                          <StatusIcon className="h-4 w-4" />
                          <div className="text-xs">
                            <div>{status.connected ? 'Verbonden' : 'Niet verbonden'}</div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {formatLastLogin(user.lastLogin)}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleEditUser(user)}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleDeleteUser(user.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                          {!status.connected && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setInviteData({
                                  email: user.email || '',
                                  firstName: user.firstName || '',
                                  lastName: user.lastName || '',
                                  role: user.role,
                                  message: ''
                                });
                                setIsInviteOpen(true);
                              }}
                            >
                              <Mail className="h-3 w-3 mr-1" />
                              Uitnodigen
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="all" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Alle Gebruikers ({users.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {users.map((user: any) => {
                  const status = getConnectionStatus(user.lastLogin);
                  const StatusIcon = status.icon;
                  
                  return (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium">
                            {user.firstName?.[0]}{user.lastName?.[0]}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium">{user.firstName} {user.lastName}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant="outline">{roleDisplayMap[user.role as keyof typeof roleDisplayMap] || user.role}</Badge>
                        <div className={`flex items-center gap-1 ${status.color}`}>
                          <StatusIcon className="h-4 w-4" />
                          <div className="text-xs">
                            <div>{status.connected ? 'Verbonden' : 'Niet verbonden'}</div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {formatLastLogin(user.lastLogin)}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleEditUser(user)}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleDeleteUser(user.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                          {!status.connected && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setInviteData({
                                  email: user.email || '',
                                  firstName: user.firstName || '',
                                  lastName: user.lastName || '',
                                  role: user.role,
                                  message: ''
                                });
                                setIsInviteOpen(true);
                              }}
                            >
                              <Mail className="h-3 w-3 mr-1" />
                              Uitnodigen
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Nieuwe Uitnodiging Dialog */}
      <Dialog open={isInviteOpen} onOpenChange={setIsInviteOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Nieuwe Uitnodiging Versturen</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">Voornaam</Label>
                <Input
                  id="firstName"
                  value={inviteData.firstName}
                  onChange={(e) => setInviteData({ ...inviteData, firstName: e.target.value })}
                  placeholder="Voornaam"
                />
              </div>
              <div>
                <Label htmlFor="lastName">Achternaam</Label>
                <Input
                  id="lastName"
                  value={inviteData.lastName}
                  onChange={(e) => setInviteData({ ...inviteData, lastName: e.target.value })}
                  placeholder="Achternaam"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="email">E-mailadres</Label>
              <Input
                id="email"
                type="email"
                value={inviteData.email}
                onChange={(e) => setInviteData({ ...inviteData, email: e.target.value })}
                placeholder="email@example.com"
              />
            </div>
            <div>
              <Label htmlFor="role">Rol</Label>
              <Select
                value={inviteData.role}
                onValueChange={(value) => setInviteData({ ...inviteData, role: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecteer een rol" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Administrator</SelectItem>
                  <SelectItem value="coach">Coach</SelectItem>
                  <SelectItem value="player">Speelster</SelectItem>
                  <SelectItem value="parent">Ouder</SelectItem>
                  <SelectItem value="coordinator">Coördinator</SelectItem>
                  <SelectItem value="trainer">Trainer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="message">Persoonlijk bericht (optioneel)</Label>
              <Textarea
                id="message"
                value={inviteData.message}
                onChange={(e) => setInviteData({ ...inviteData, message: e.target.value })}
                placeholder="Voeg een persoonlijk bericht toe..."
                rows={3}
              />
            </div>
            <div className="flex gap-2 pt-4">
              <Button 
                onClick={handleSendInvite}
                disabled={sendInviteMutation.isPending}
                className="flex-1"
              >
                <Send className="h-4 w-4 mr-2" />
                {sendInviteMutation.isPending ? "Versturen..." : "Uitnodiging Versturen"}
              </Button>
              <Button variant="outline" onClick={() => setIsInviteOpen(false)}>
                Annuleren
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bewerk Gebruiker Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Gebruiker Bewerken</DialogTitle>
          </DialogHeader>
          {editingUser && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="editFirstName">Voornaam</Label>
                  <Input
                    id="editFirstName"
                    value={editingUser.firstName}
                    onChange={(e) => setEditingUser({ ...editingUser, firstName: e.target.value })}
                    placeholder="Voornaam"
                  />
                </div>
                <div>
                  <Label htmlFor="editLastName">Achternaam</Label>
                  <Input
                    id="editLastName"
                    value={editingUser.lastName}
                    onChange={(e) => setEditingUser({ ...editingUser, lastName: e.target.value })}
                    placeholder="Achternaam"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="editEmail">E-mailadres</Label>
                <Input
                  id="editEmail"
                  type="email"
                  value={editingUser.email}
                  onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                  placeholder="email@example.com"
                />
              </div>
              <div>
                <Label htmlFor="editRole">Rol</Label>
                <Select
                  value={editingUser.role}
                  onValueChange={(value) => setEditingUser({ ...editingUser, role: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer een rol" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Administrator</SelectItem>
                    <SelectItem value="coach">Coach</SelectItem>
                    <SelectItem value="player">Speelster</SelectItem>
                    <SelectItem value="parent">Ouder</SelectItem>
                    <SelectItem value="coordinator">Coördinator</SelectItem>
                    <SelectItem value="trainer">Trainer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2 pt-4">
                <Button 
                  onClick={handleUpdateUser}
                  disabled={updateUserMutation.isPending}
                  className="flex-1"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  {updateUserMutation.isPending ? "Opslaan..." : "Wijzigingen Opslaan"}
                </Button>
                <Button variant="outline" onClick={() => setIsEditOpen(false)}>
                  Annuleren
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}