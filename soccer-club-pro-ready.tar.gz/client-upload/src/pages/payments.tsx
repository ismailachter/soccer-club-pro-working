import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, Search, Filter, FileText, CreditCard, Calendar, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { 
  FeeCategory, 
  UserFee, 
  Payment,
  PaymentPlan, 
  PaymentPlanInstallment 
} from "@shared/schema";

// Helper function to format currency
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
};

// Helper function to format dates
const formatDate = (dateString: string | Date) => {
  const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
  return new Intl.DateTimeFormat('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  }).format(date);
};

// Component to display a payment status badge
const PaymentStatusBadge = ({ status }: { status: string }) => {
  let variant: "default" | "destructive" | "outline" | "secondary" = "default";
  
  switch (status) {
    case 'paid':
      variant = "default";
      break;
    case 'pending':
      variant = "secondary";
      break;
    case 'partially_paid':
      variant = "secondary";
      break;
    case 'overdue':
      variant = "destructive";
      break;
    case 'cancelled':
      variant = "outline";
      break;
    case 'refunded':
      variant = "outline";
      break;
    default:
      variant = "outline";
  }
  
  return <Badge variant={variant}>{status.replace('_', ' ')}</Badge>;
};

// Component for fee categories list
const FeeCategoriesList = () => {
  const { data: categories, isLoading } = useQuery<FeeCategory[]>({
    queryKey: ['/api/fee-categories'],
  });

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!categories || categories.length === 0) {
    return (
      <div className="text-center p-8 text-muted-foreground">
        No fee categories found. Create your first fee category to get started.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {categories.map((category) => (
        <Card key={category.id}>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>{category.name}</CardTitle>
                <CardDescription>{category.description}</CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant={category.isActive ? "default" : "outline"}>
                  {category.isActive ? "Active" : "Inactive"}
                </Badge>
                <Badge variant="secondary">{category.feeType}</Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Amount</Label>
                <div className="font-medium">{formatCurrency(parseFloat(category.amount))}</div>
              </div>
              <div>
                <Label className="text-muted-foreground">Due Date</Label>
                <div className="font-medium">{category.dueDate ? formatDate(category.dueDate) : "N/A"}</div>
              </div>
              {category.teamId && (
                <div>
                  <Label className="text-muted-foreground">Team</Label>
                  <div className="font-medium">ID: {category.teamId}</div>
                </div>
              )}
              {category.seasonId && (
                <div>
                  <Label className="text-muted-foreground">Season</Label>
                  <div className="font-medium">ID: {category.seasonId}</div>
                </div>
              )}
            </div>
            <div className="flex justify-end mt-4">
              <Button variant="outline" size="sm" className="mr-2">Edit</Button>
              <Button variant="default" size="sm">Assign to Users</Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

// Component for user fees list
const UserFeesList = () => {
  const [selectedFilter, setSelectedFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("");
  
  const { data: userFees, isLoading } = useQuery<any[]>({
    queryKey: ['/api/user-fees'],
    enabled: false, // Disable automatic fetching since we need filters
  });

  // Mock data for now
  const mockUserFees = [
    {
      id: 1,
      userId: 1,
      feeCategoryId: 1,
      amount: 150,
      dueDate: new Date(2023, 5, 15),
      status: 'paid',
      notes: 'Annual membership fee',
      user: { firstName: 'John', lastName: 'Doe' },
      feeCategory: { name: 'Annual Membership' }
    },
    {
      id: 2,
      userId: 2,
      feeCategoryId: 2,
      amount: 75,
      dueDate: new Date(2023, 7, 1),
      status: 'pending',
      notes: 'Tournament registration fee',
      user: { firstName: 'Jane', lastName: 'Smith' },
      feeCategory: { name: 'Tournament Fee' }
    },
    {
      id: 3,
      userId: 3,
      feeCategoryId: 1,
      amount: 150,
      dueDate: new Date(2023, 4, 15),
      status: 'overdue',
      notes: 'Annual membership fee',
      user: { firstName: 'Mike', lastName: 'Johnson' },
      feeCategory: { name: 'Annual Membership' }
    }
  ];

  const displayData = mockUserFees;

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search users..."
              className="pl-8 w-[250px]"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select value={selectedFilter} onValueChange={setSelectedFilter}>
            <SelectTrigger className="w-[180px]">
              <div className="flex items-center">
                <Filter className="mr-2 h-4 w-4" />
                <span>Filter by status</span>
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="partially_paid">Partially paid</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
              <SelectItem value="refunded">Refunded</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Assign New Fee
        </Button>
      </div>
      
      {displayData.length === 0 ? (
        <div className="text-center p-8 text-muted-foreground">
          No user fees found matching your filters.
        </div>
      ) : (
        <div className="space-y-4">
          {displayData.map((userFee) => (
            <Card key={userFee.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{userFee.user.firstName} {userFee.user.lastName}</CardTitle>
                    <CardDescription>{userFee.feeCategory.name}</CardDescription>
                  </div>
                  <PaymentStatusBadge status={userFee.status} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Amount</Label>
                    <div className="font-medium">{formatCurrency(userFee.amount)}</div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Due Date</Label>
                    <div className="font-medium">{formatDate(userFee.dueDate)}</div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Notes</Label>
                    <div className="font-medium">{userFee.notes || 'N/A'}</div>
                  </div>
                </div>
                <div className="flex justify-end mt-4">
                  <Button variant="outline" size="sm" className="mr-2">Payment Plan</Button>
                  <Button variant="default" size="sm">Record Payment</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

// Component for payments list
const PaymentsList = () => {
  const [searchTerm, setSearchTerm] = useState<string>("");
  
  const { data: payments, isLoading } = useQuery<any[]>({
    queryKey: ['/api/payments'],
    enabled: false, // Disable automatic fetching since we need filters
  });

  // Mock data for now
  const mockPayments = [
    {
      id: 1,
      userId: 1,
      userFeeId: 1,
      amount: 150,
      paymentDate: new Date(2023, 5, 10),
      method: 'credit_card',
      status: 'paid',
      transactionId: 'txn_123456',
      user: { firstName: 'John', lastName: 'Doe' },
      userFee: { feeCategory: { name: 'Annual Membership' } }
    },
    {
      id: 2,
      userId: 2,
      userFeeId: 2,
      amount: 25,
      paymentDate: new Date(2023, 6, 15),
      method: 'bank_transfer',
      status: 'paid',
      user: { firstName: 'Jane', lastName: 'Smith' },
      userFee: { feeCategory: { name: 'Tournament Fee' } }
    },
    {
      id: 3,
      userId: 2,
      userFeeId: 2,
      amount: 25,
      paymentDate: new Date(2023, 7, 15),
      method: 'bank_transfer',
      status: 'pending',
      user: { firstName: 'Jane', lastName: 'Smith' },
      userFee: { feeCategory: { name: 'Tournament Fee' } }
    }
  ];

  const displayData = mockPayments;

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search payments..."
            className="pl-8 w-[250px]"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Record New Payment
        </Button>
      </div>
      
      {displayData.length === 0 ? (
        <div className="text-center p-8 text-muted-foreground">
          No payments found matching your search.
        </div>
      ) : (
        <div className="space-y-4">
          {displayData.map((payment) => (
            <Card key={payment.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{payment.user.firstName} {payment.user.lastName}</CardTitle>
                    <CardDescription>
                      {payment.userFee?.feeCategory?.name || 'General Payment'}
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <PaymentStatusBadge status={payment.status} />
                    <Badge variant="outline">{payment.method.replace('_', ' ')}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Amount</Label>
                    <div className="font-medium">{formatCurrency(payment.amount)}</div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Payment Date</Label>
                    <div className="font-medium">{formatDate(payment.paymentDate)}</div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Transaction ID</Label>
                    <div className="font-medium">{payment.transactionId || 'N/A'}</div>
                  </div>
                </div>
                <div className="flex justify-end mt-4">
                  <Button variant="outline" size="sm" className="mr-2">View Details</Button>
                  <Button variant="ghost" size="sm">Print Receipt</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

// Component for payment plans list
const PaymentPlansList = () => {
  const [searchTerm, setSearchTerm] = useState<string>("");
  
  const { data: paymentPlans, isLoading } = useQuery<any[]>({
    queryKey: ['/api/payment-plans'],
    enabled: false, // Disable automatic fetching since we need filters
  });

  // Mock data for now
  const mockPaymentPlans = [
    {
      id: 1,
      name: 'Monthly Membership Plan',
      userId: 3,
      startDate: new Date(2023, 4, 1),
      endDate: new Date(2023, 9, 1),
      totalAmount: 150,
      status: 'active',
      userFeeId: 3,
      user: { firstName: 'Mike', lastName: 'Johnson' },
      userFee: { feeCategory: { name: 'Annual Membership' } },
      installments: [
        {
          id: 1,
          amount: 30,
          dueDate: new Date(2023, 4, 15),
          status: 'paid',
          paymentPlanId: 1,
          paymentId: 4
        },
        {
          id: 2,
          amount: 30,
          dueDate: new Date(2023, 5, 15),
          status: 'paid',
          paymentPlanId: 1,
          paymentId: 5
        },
        {
          id: 3,
          amount: 30,
          dueDate: new Date(2023, 6, 15),
          status: 'pending',
          paymentPlanId: 1
        },
        {
          id: 4,
          amount: 30,
          dueDate: new Date(2023, 7, 15),
          status: 'pending',
          paymentPlanId: 1
        },
        {
          id: 5,
          amount: 30,
          dueDate: new Date(2023, 8, 15),
          status: 'pending',
          paymentPlanId: 1
        }
      ]
    }
  ];

  const displayData = mockPaymentPlans;

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search payment plans..."
            className="pl-8 w-[250px]"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Create Payment Plan
        </Button>
      </div>
      
      {displayData.length === 0 ? (
        <div className="text-center p-8 text-muted-foreground">
          No payment plans found matching your search.
        </div>
      ) : (
        <div className="space-y-6">
          {displayData.map((plan) => (
            <Card key={plan.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{plan.name}</CardTitle>
                    <CardDescription>
                      {plan.user.firstName} {plan.user.lastName} - 
                      {plan.userFee?.feeCategory?.name || 'Custom Payment Plan'}
                    </CardDescription>
                  </div>
                  <Badge variant={plan.status === 'active' ? 'default' : 'outline'}>
                    {plan.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <Label className="text-muted-foreground">Total Amount</Label>
                    <div className="font-medium">{formatCurrency(plan.totalAmount)}</div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Start Date</Label>
                    <div className="font-medium">{formatDate(plan.startDate)}</div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">End Date</Label>
                    <div className="font-medium">{formatDate(plan.endDate)}</div>
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <div className="space-y-2">
                  <h4 className="text-sm font-medium mb-2">Installments</h4>
                  
                  <div className="space-y-2">
                    {plan.installments.map((installment) => (
                      <div 
                        key={installment.id} 
                        className="flex items-center justify-between p-2 rounded-md border"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="font-medium">
                            {formatDate(installment.dueDate)}
                          </div>
                          <div>{formatCurrency(installment.amount)}</div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <PaymentStatusBadge status={installment.status} />
                          {installment.status !== 'paid' && (
                            <Button size="sm">Pay Now</Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default function PaymentsPage() {
  const { toast } = useToast();

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Payments Management</h1>
          <p className="text-muted-foreground">Manage fees, payments, and payment plans</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <FileText className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      <Tabs defaultValue="userfees" className="space-y-4">
        <TabsList>
          <TabsTrigger value="categories" className="flex items-center">
            <CreditCard className="mr-2 h-4 w-4" />
            Fee Categories
          </TabsTrigger>
          <TabsTrigger value="userfees" className="flex items-center">
            <FileText className="mr-2 h-4 w-4" />
            User Fees
          </TabsTrigger>
          <TabsTrigger value="payments" className="flex items-center">
            <CreditCard className="mr-2 h-4 w-4" />
            Payments
          </TabsTrigger>
          <TabsTrigger value="plans" className="flex items-center">
            <Calendar className="mr-2 h-4 w-4" />
            Payment Plans
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="categories" className="space-y-4">
          <FeeCategoriesList />
        </TabsContent>
        
        <TabsContent value="userfees" className="space-y-4">
          <UserFeesList />
        </TabsContent>
        
        <TabsContent value="payments" className="space-y-4">
          <PaymentsList />
        </TabsContent>
        
        <TabsContent value="plans" className="space-y-4">
          <PaymentPlansList />
        </TabsContent>
      </Tabs>
    </div>
  );
}