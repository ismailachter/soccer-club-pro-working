import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Play, Video, Download, UserCircle, FileDown, FileSpreadsheet, Calendar, CalendarDays, Edit, Trash2, Plus, FileText } from "lucide-react";
import { jsPDF } from "jspdf";
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { useTranslation } from "@/lib/i18n";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// Training program type definition
type ProgramDifficulty = "beginner" | "intermediate" | "advanced";

type ProgramData = {
  id: number;
  name: string;
  description: string;
  category: string;
  ageGroup: string;
  focusArea: string;
  duration: number;
  author: string;
  difficulty: ProgramDifficulty;
  createdAt: string;
};

type TrainingPrograms = {
  physical: ProgramData[];
  technical: ProgramData[];
  tactical: ProgramData[];
  mental: ProgramData[];
};

const TrainingProgramsPage = () => {
  const { t } = useTranslation();
  const [addResultOpen, setAddResultOpen] = useState(false);
  const [videoModal, setVideoModal] = useState<{
    open: boolean;
    title: string;
    url: string;
    description?: string;
    exercises?: string[];
  }>({
    open: false,
    title: "",
    url: "",
    description: "",
    exercises: [],
  });
  const [playerDownloadOpen, setPlayerDownloadOpen] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState("");
  const [injuryPreventionOpen, setInjuryPreventionOpen] = useState(false);
  const [selectedPlayerInjury, setSelectedPlayerInjury] = useState("");
  const [selectedInjuryAreas, setSelectedInjuryAreas] = useState<string[]>([]);
  const [programDates, setProgramDates] = useState({
    startDate: "",
    endDate: ""
  });
  const [selectedDays, setSelectedDays] = useState<string[]>(["monday", "wednesday", "friday"]);
  const [customSchema, setCustomSchema] = useState({
    startDate: "",
    endDate: "",
    name: "",
    selectedDays: ["monday", "wednesday", "friday"] as string[],
    inactivePeriods: [
      { start: '2024-12-20', end: '2025-01-03', name: 'Kerstvakantie' }
    ],
    matchDays: [] as { date: string; opponent: string; location: string; time: string }[],
    customTrainings: [] as { date: string; type: string; description: string; time: string; duration: number }[]
  });
  
  // Calendar mode state
  const [calendarMode, setCalendarMode] = useState(false);
  const [calendarEvents, setCalendarEvents] = useState<Array<{
    id: string;
    type: 'training' | 'match';
    date: string;
    time: string;
    title: string;
    description: string;
    location?: string;
    opponent?: string;
  }>>([]);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [eventFormOpen, setEventFormOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<any>(null);
  const [eventForm, setEventForm] = useState({
    type: 'training' as 'training' | 'match',
    date: '',
    time: '18:00',
    title: '',
    description: '',
    location: '',
    opponent: ''
  });

  // Calendar event management functions
  const addCalendarEvent = () => {
    if (!eventForm.date || !eventForm.time || !eventForm.title) {
      alert("Vul alle verplichte velden in.");
      return;
    }

    const newEvent = {
      id: Date.now().toString(),
      type: eventForm.type,
      date: eventForm.date,
      time: eventForm.time,
      title: eventForm.title,
      description: eventForm.description,
      location: eventForm.location,
      opponent: eventForm.opponent
    };

    setCalendarEvents([...calendarEvents, newEvent]);
    setEventFormOpen(false);
    setEventForm({
      type: 'training',
      date: '',
      time: '18:00',
      title: '',
      description: '',
      location: '',
      opponent: ''
    });
  };

  const editCalendarEvent = (event: any) => {
    setEditingEvent(event);
    setEventForm({
      type: event.type,
      date: event.date,
      time: event.time,
      title: event.title,
      description: event.description,
      location: event.location || '',
      opponent: event.opponent || ''
    });
    setEventFormOpen(true);
  };

  const updateCalendarEvent = () => {
    if (!editingEvent) return;

    const updatedEvents = calendarEvents.map(event =>
      event.id === editingEvent.id
        ? {
            ...event,
            type: eventForm.type,
            date: eventForm.date,
            time: eventForm.time,
            title: eventForm.title,
            description: eventForm.description,
            location: eventForm.location,
            opponent: eventForm.opponent
          }
        : event
    );

    setCalendarEvents(updatedEvents);
    setEventFormOpen(false);
    setEditingEvent(null);
    setEventForm({
      type: 'training',
      date: '',
      time: '18:00',
      title: '',
      description: '',
      location: '',
      opponent: ''
    });
  };

  const deleteCalendarEvent = (eventId: string) => {
    setCalendarEvents(calendarEvents.filter(event => event.id !== eventId));
  };

  // Generate calendar for display
  const generateCalendarDays = () => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());
    
    const days = [];
    const current = new Date(startDate);
    
    for (let i = 0; i < 42; i++) {
      const dateStr = current.toISOString().split('T')[0];
      const dayEvents = calendarEvents.filter(event => event.date === dateStr);
      const isCurrentMonth = current.getMonth() === currentMonth;
      const isToday = current.toDateString() === today.toDateString();
      
      days.push({
        date: new Date(current),
        dateStr,
        dayEvents,
        isCurrentMonth,
        isToday
      });
      
      current.setDate(current.getDate() + 1);
    }
    
    return days;
  };

  // Function to generate and download program PDF
  const generateProgramPDF = () => {
    try {
      console.log("Starting PDF generation...");
      
      // Create a new PDF document
      const doc = new jsPDF();
      
      // Simple header
      doc.setFontSize(20);
      doc.setTextColor(0, 51, 102);
      doc.text("VVC Brasschaat", 14, 20);
      
      doc.setFontSize(16);
      doc.text("8-Weken Voorbereiding Trainingsprogramma", 14, 35);
      
      // Program overview with custom dates
      doc.setFontSize(12);
      doc.setTextColor(80, 80, 80);
      doc.text("Samengevatte Periodiserings- en Blessurepreventie Plan", 14, 50);
      
      // Add program dates (use actual dates or calculated ones)
      const startDateToUse = programDates.startDate || (() => {
        const today = new Date();
        const daysUntilMonday = (8 - today.getDay()) % 7;
        const nextMonday = new Date(today);
        nextMonday.setDate(today.getDate() + daysUntilMonday);
        return nextMonday.toISOString().split('T')[0];
      })();
      
      // Always calculate end date as 8 weeks from start date
      const endDateToUse = (() => {
        const start = new Date(startDateToUse);
        const end = new Date(start);
        end.setDate(start.getDate() + (8 * 7) - 1); // 8 weeks minus 1 day
        return end.toISOString().split('T')[0];
      })();

      doc.setFontSize(10);
      doc.setTextColor(0, 51, 102);
      doc.text(`Programma periode: ${startDateToUse} tot ${endDateToUse}`, 14, 60);
      const dayNames = {
        monday: "Maandag", tuesday: "Dinsdag", wednesday: "Woensdag", 
        thursday: "Donderdag", friday: "Vrijdag", saturday: "Zaterdag", sunday: "Zondag"
      };
      const selectedDayNames = selectedDays.map(day => dayNames[day as keyof typeof dayNames]).join(", ");
      doc.text(`Trainingsdagen: ${selectedDayNames} (${selectedDays.length}x per week)`, 14, 70);
      
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("Dit 8-weken voorbereiding programma bereidt spelers voor op het komende seizoen", 14, 85);
      doc.text("met behulp van periodisering principes en HIIT trainingsmethoden.", 14, 95);
      doc.text(`Het programma bevat ${selectedDays.length} sessies per week met blessurepreventie.`, 14, 105);
      
      // Weekly structure
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Weekly Training Structure:", 14, 105);
      
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("Monday: HIIT & Cardio (60-75 min) - Cardiovascular fitness + Core/Hamstring prevention", 14, 120);
      doc.text("Wednesday: Strength & Power (75-90 min) - Strength development + Joint stability", 14, 130);
      doc.text("Friday: HIIT & Cardio (65-75 min) - Speed/Agility + Ankle/Knee stability", 14, 140);
      
      // Periodization
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Program Periodization:", 14, 160);
      
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("Weeks 1-2 (Foundation): 60-70% intensity - Building aerobic base", 14, 175);
      doc.text("Weeks 3-5 (Building): 70-85% intensity - Increasing volume and fitness", 14, 185);
      doc.text("Weeks 6-8 (Peak): 85-100% intensity - Match intensity preparation", 14, 195);
      
      // Add new page for detailed 8-week breakdown
      doc.addPage();
      doc.setFontSize(16);
      doc.setTextColor(0, 51, 102);
      doc.text("WEEK 1-2: FOUNDATION PHASE (60-70% Intensity)", 14, 20);
      
      doc.setFontSize(12);
      doc.text("Monday - HIIT & Cardio + Core/Hamstring Prevention:", 14, 40);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Dynamic warm-up: 10 min (leg swings, hip circles, walking lunges)", 14, 55);
      doc.text("• Sprint intervals: 6×20 sec at 60% max, 2 min recovery", 14, 65);
      doc.text("• Core circuit: 3 rounds - Planks 45s, Dead bugs 10 each, Russian twists 20", 14, 75);
      doc.text("• Hamstring prevention: Nordic curls 3×5 (assisted), RDLs 3×10", 14, 85);
      doc.text("• Cool-down: 10 min light jog + stretching", 14, 95);
      
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Wednesday - Strength & Power + Joint Stability:", 14, 115);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Dynamic warm-up: 15 min", 14, 130);
      doc.text("• Squats: 3×12 (bodyweight to light resistance)", 14, 140);
      doc.text("• Lunges: 3×8 each leg", 14, 150);
      doc.text("• Push-ups: 3×10-15", 14, 160);
      doc.text("• Single-leg balance: 3×30s each leg", 14, 170);
      doc.text("• Calf raises: 3×15", 14, 180);
      
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Friday - HIIT & Cardio + Ankle/Knee Stability:", 14, 200);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Dynamic warm-up: 10 min", 14, 215);
      doc.text("• Agility ladder: 5 patterns × 30s, 60s rest", 14, 225);
      doc.text("• Box jumps: 3×6 (low box, focus on landing)", 14, 235);
      doc.text("• Lateral lunges: 3×8 each side", 14, 245);
      doc.text("• Wall squats: 3×12 (knee alignment focus)", 14, 255);
      doc.text("• Cool-down: stretching + foam rolling", 14, 265);
      
      // Week 3-5
      doc.addPage();
      doc.setFontSize(16);
      doc.setTextColor(0, 51, 102);
      doc.text("WEEK 3-5: BUILDING PHASE (70-85% Intensity)", 14, 20);
      
      doc.setFontSize(12);
      doc.text("Monday - HIIT & Cardio + Core/Hamstring Prevention:", 14, 40);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Dynamic warm-up: 10 min", 14, 55);
      doc.text("• Sprint intervals: 8×25 sec at 75% max, 90s recovery", 14, 65);
      doc.text("• Box-to-box runs: 6 repetitions at 70% effort", 14, 75);
      doc.text("• Core circuit: 4 rounds - Planks 60s, Side planks 30s each, Mountain climbers 30s", 14, 85);
      doc.text("• Nordic curls: 3×6-8, RDLs 3×12 with resistance", 14, 95);
      doc.text("• Cool-down: 10 min + dynamic stretching", 14, 105);
      
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Wednesday - Strength & Power + Joint Stability:", 14, 125);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Dynamic warm-up: 15 min", 14, 140);
      doc.text("• Squats: 4×10 (added resistance)", 14, 150);
      doc.text("• Single-leg squats: 3×6 each leg (assisted)", 14, 160);
      doc.text("• Plyometric box jumps: 3×8", 14, 170);
      doc.text("• Push-ups: 3×15-20", 14, 180);
      doc.text("• Glute bridges: 3×15", 14, 190);
      doc.text("• Wobble board training: 3×45s each leg", 14, 200);
      
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Friday - HIIT & Cardio + Ankle/Knee Stability:", 14, 220);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Dynamic warm-up: 10 min", 14, 235);
      doc.text("• Shuttle runs: 10-20-30m × 6 sets, 60s rest", 14, 245);
      doc.text("• Lateral hops: 3×30s each foot", 14, 255);
      doc.text("• Step-ups: 3×10 each leg (controlled movement)", 14, 265);
      
      // Week 6-8
      doc.addPage();
      doc.setFontSize(16);
      doc.setTextColor(0, 51, 102);
      doc.text("WEEK 6-8: PEAK PHASE (85-100% Intensity)", 14, 20);
      
      doc.setFontSize(12);
      doc.text("Monday - HIIT & Cardio + Core/Hamstring Prevention:", 14, 40);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Dynamic warm-up: 10 min", 14, 55);
      doc.text("• Sprint intervals: 10×30 sec at 90% max, 90s recovery", 14, 65);
      doc.text("• Ball work intervals: 6×45s high intensity dribbling", 14, 75);
      doc.text("• Core circuit: 5 rounds - Advanced planks, Russian twists with ball", 14, 85);
      doc.text("• Nordic curls: 3×8-10 full range, Single-leg RDLs 3×8", 14, 95);
      
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Wednesday - Strength & Power + Match Preparation:", 14, 115);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Sport-specific warm-up: 15 min", 14, 130);
      doc.text("• Explosive squats: 4×8 with speed focus", 14, 140);
      doc.text("• Single-leg squats: 3×8 each leg (unassisted)", 14, 150);
      doc.text("• Box jumps: 4×6 (match-intensity)", 14, 160);
      doc.text("• Reactive agility drills: 15 min", 14, 170);
      doc.text("• Jump landing practice: 3×10 (perfect form)", 14, 180);
      
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Friday - Match Intensity + Final Preparation:", 14, 200);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Match-style warm-up: 15 min", 14, 215);
      doc.text("• Small-sided games: 20 min at match intensity", 14, 225);
      doc.text("• Sprint finish training: 6×40m at 100%", 14, 235);
      doc.text("• Recovery protocols: stretching + hydration", 14, 245);
      
      // Safety and progression notes
      doc.addPage();
      doc.setFontSize(16);
      doc.setTextColor(0, 51, 102);
      doc.text("VEILIGHEIDSRICHTLIJNEN & PROGRESSIE NOTITIES", 14, 20);
      
      doc.setFontSize(12);
      doc.text("Blessurepreventie Richtlijnen:", 14, 40);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Altijd een volledige dynamische warming-up voor training", 14, 55);
      doc.text("• Focus op perfecte vorm boven intensiteit, vooral in week 1-2", 14, 65);
      doc.text("• Verhoog weerstand en intensiteit geleidelijk", 14, 75);
      doc.text("• Stop onmiddellijk als spelers pijn ervaren", 14, 85);
      doc.text("• Zorg voor voldoende herstel tussen sessies", 14, 95);
      
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Belasting Progressie:", 14, 115);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Week 1-2: Focus op bewegingspatronen en basis conditie", 14, 130);
      doc.text("• Week 3-5: Verhoog volume en voeg externe weerstand toe", 14, 140);
      doc.text("• Week 6-8: Wedstrijdspecifieke intensiteit en vaardigheid integratie", 14, 150);
      
      doc.setFontSize(12);
      doc.setTextColor(0, 51, 102);
      doc.text("Benodigde Uitrusting:", 14, 170);
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text("• Behendigheidsladder, pionnen, weerstandsbanden", 14, 185);
      doc.text("• Plyometrische boxen (verschillende hoogtes)", 14, 195);
      doc.text("• Medicine balls, wobble boards", 14, 205);
      doc.text("• Basis gewichten of weerstandsapparatuur", 14, 215);
      
      // Footer
      const today = new Date();
      doc.setFontSize(8);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated: ${today.toLocaleDateString()} | VVC Brasschaat Soccer Club`, 14, 280);
      
      // Add new page with detailed daily training schedule
      doc.addPage();
      doc.setFontSize(16);
      doc.setTextColor(0, 51, 102);
      doc.text("GEDETAILLEERD TRAININGSSCHEMA PER DAG", 14, 20);
      
      let yPosition = 40;
      const trainingTypes = [
        { type: 'HIIT & Cardio', focus: ['Cardiovascular fitness', 'Core strengthening', 'Hamstring injury prevention'], duration: 75 },
        { type: 'Strength & Power', focus: ['Functional strength', 'Explosive power', 'ACL injury prevention'], duration: 90 },
        { type: 'Skills & Conditioning', focus: ['Technical skills', 'Match preparation', 'Load progression'], duration: 75 }
      ];
      
      // Generate detailed schedule for 8 weeks
      for (let week = 0; week < 8; week++) {
        if (yPosition > 240) {
          doc.addPage();
          yPosition = 20;
        }
        
        // Week header
        doc.setFontSize(14);
        doc.setTextColor(0, 51, 102);
        doc.text(`WEEK ${week + 1}`, 14, yPosition);
        yPosition += 15;
        
        // Calculate dates for this week
        const weekStartDate = new Date(startDateToUse);
        weekStartDate.setDate(weekStartDate.getDate() + (week * 7));
        
        // Training sessions for selected days
        const dayToNumber = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
        const trainingDayNumbers = selectedDays.map(day => dayToNumber[day as keyof typeof dayToNumber]).sort();
        
        trainingDayNumbers.forEach((dayNum, index) => {
          const daysFromWeekStart = (dayNum - weekStartDate.getDay() + 7) % 7;
          const trainingDate = new Date(weekStartDate);
          trainingDate.setDate(weekStartDate.getDate() + daysFromWeekStart);
          
          const trainingType = trainingTypes[index % trainingTypes.length];
          const dayName = dayNames[selectedDays[index % selectedDays.length] as keyof typeof dayNames];
          
          doc.setFontSize(12);
          doc.setTextColor(60, 60, 60);
          doc.text(`${dayName} ${trainingDate.toLocaleDateString('nl-NL')} - ${trainingType.type}`, 14, yPosition);
          
          doc.setFontSize(10);
          doc.setTextColor(80, 80, 80);
          doc.text(`Duur: ${trainingType.duration} minuten | 18:00-${Math.floor(18 + trainingType.duration/60)}:${(trainingType.duration%60).toString().padStart(2, '0')}`, 14, yPosition + 10);
          
          trainingType.focus.forEach((focus, focusIndex) => {
            doc.text(`• ${focus}`, 14, yPosition + 20 + (focusIndex * 8));
          });
          
          yPosition += 50;
          
          if (yPosition > 240) {
            doc.addPage();
            yPosition = 20;
          }
        });
        
        yPosition += 10;
      }

      // Save and download
      doc.save("VVC-Brasschaat-8-Weken-Trainingsprogramma.pdf");
      console.log("PDF generated successfully!");
      
    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("There was an error generating the PDF. Please try again.");
    }
  };

  // Function to generate and download Excel file
  const generateExcelFile = () => {
    alert("Excel functie tijdelijk uitgeschakeld - app klaar voor deployment!");
  };

          duration: 75,
          day: 'tuesday'
        },
        { 
          type: 'CONDITIE - Gepolariseerd (Woensdag)', 
          focus: ['EIT/IIT training', 'Lactaat tolerantie', 'VO2max ontwikkeling'], 
          duration: 90,
          day: 'wednesday'
        },
        { 
          type: 'EIT (Extensieve Intervaltraining)', 
          focus: ['85-90% HRmax', '3-8 min intervals', 'Aerobe power'], 
          duration: 75,
          day: 'thursday'
        },
        { 
          type: 'IIT (Intensieve Intervaltraining)', 
          focus: ['90-100% HRmax', '30sec-3min intervals', 'Neuromusculaire power'], 
          duration: 60,
          day: 'friday'
        },
        { 
          type: 'RUST/Regeneratie', 
          focus: ['Actief herstel', 'Mobiliteit', 'Lage intensiteit < 60% HRmax'], 
          duration: 45,
          day: 'saturday'
        },
        { 
          type: 'Techniek & Tactiek', 
          focus: ['Bal techniek', 'Spelvormen', 'Positioneel spel'], 
          duration: 90,
          day: 'sunday'
        }
      ];
      
      // 10-MAANDEN VERHEYEN PERIODISERING - 6 WEKEN BLOKKEN
      const getPeriodizationPhase = (weekNumber: number) => {
        const blockNumber = Math.ceil(weekNumber / 6);
        switch(blockNumber) {
          case 1: return { phase: 'algemeen1', block: '1A', weeks: '1-6', focus: 'Aerobe Basis Opbouw' };
          case 2: return { phase: 'algemeen2', block: '1B', weeks: '7-12', focus: 'Aerobe Capaciteit Ontwikkeling' };
          case 3: return { phase: 'specifiek1', block: '2A', weeks: '13-18', focus: 'Lactaat Drempel Training' };
          case 4: return { phase: 'specifiek2', block: '2B', weeks: '19-24', focus: 'VO2max Ontwikkeling' };
          case 5: return { phase: 'precompetitie', block: '3A', weeks: '25-30', focus: 'Snelheid & Power Piek' };
          case 6: return { phase: 'competitie1', block: '3B', weeks: '31-36', focus: 'Competitie Onderhoud' };
          case 7: return { phase: 'competitie2', block: '3C', weeks: '37-42', focus: 'Piek Prestatie Fase' };
          default: return { phase: 'overgang', block: '4', weeks: '43+', focus: 'Actief Herstel' };
        }
      };

      // Bepaal training type gebaseerd op dag en 6-weken periodisering
      // Geperiodiseerde blessurepreventie oefeningen aangepast aan trainingsintensiteit
      const getInjuryPreventionFocus = (weekNumber: number, trainingIntensity: 'low' | 'medium' | 'high' = 'medium') => {
        const weekInCycle = ((weekNumber - 1) % 8) + 1;
        
        // Intensiteit bepaalt herhalingen en duur
        const intensitySettings = {
          low: { reps: '2x8-10', duration: '5min', focus: 'Mobiliteit' },
          medium: { reps: '3x10-12', duration: '7min', focus: 'Stabiliteit' },
          high: { reps: '3x12-15', duration: '10min', focus: 'Versterking' }
        };
        
        const settings = intensitySettings[trainingIntensity];
        
        switch(weekInCycle) {
          case 1:
          case 2:
            return {
              focus: 'Enkels & Proprioceptie',
              exercises: 'Balans oefeningen, enkelstabiliteit, proprioceptieve training',
              repetitions: settings.reps,
              duration: settings.duration,
              specificExercises: [
                'Eenbeen balans',
                'Tandem walking (hiel-teen lopen)', 
                'Enkelcirkels',
                'Ogen dicht balans challenges'
              ]
            };
          case 3:
          case 4:
            return {
              focus: 'Heup & Core',
              exercises: 'Heup mobiliteit, gluteus activatie, core stabiliteit',
              repetitions: settings.reps,
              duration: settings.duration,
              specificExercises: [
                'Heup flexor stretch',
                'Gluteus bridges',
                'Dead bugs',
                'Side planks'
              ]
            };
          case 5:
          case 6:
            return {
              focus: 'Adductoren & Groin',
              exercises: 'Adductor stretching, groin strengthening, laterale bewegingen',
              repetitions: settings.reps,
              duration: settings.duration,
              specificExercises: [
                'Adductor stretch',
                'Lateral lunges',
                'Groin strengthening',
                'Cossack squats'
              ]
            };
          case 7:
          case 8:
            return {
              focus: 'Hamstrings & Achillespees',
              exercises: 'Hamstring flexibiliteit, achillespees versterking, posterior chain',
              repetitions: settings.reps,
              duration: settings.duration,
              specificExercises: [
                'Nordic hamstrings',
                'Achilles stretches',
                'Romanian deadlifts',
                'Calf raises'
              ]
            };
          default:
            return {
              focus: 'Algemene Preventie',
              exercises: 'Volledige body screening, algemene mobiliteit',
              repetitions: settings.reps,
              duration: settings.duration,
              specificExercises: [
                'Full body mobility',
                'Movement screening',
                'General activation',
                'Dynamic warm-up'
              ]
            };
        }
      };

      const getTrainingForDay = (dayName: string, weekNumber: number) => {
        const periodInfo = getPeriodizationPhase(weekNumber);
        const weekInBlock = ((weekNumber - 1) % 6) + 1; // Week 1-6 binnen blok
        const isDeloadWeek = weekInBlock === 6; // Week 6 = ontlasting week
        // Check for scheduled match on this date
        const currentDateStr = new Date(sessionDate).toISOString().split('T')[0];
        const scheduledMatch = customSchema.matchDays.find(match => match.date === currentDateStr);
        const customTraining = customSchema.customTrainings.find(training => training.date === currentDateStr);
        
        if (scheduledMatch) {
          return {
            type: 'WEDSTRIJD',
            focus: [
              `⚽ ${scheduledMatch.opponent || 'Tegenstander TBA'}`,
              `📍 Locatie: ${scheduledMatch.location || 'TBA'}`,
              `🕐 Aanvang: ${scheduledMatch.time || '15:00'}`,
              'Opwarming: 30min wedstrijd-specifiek',
              'Wedstrijd: 90min competitie',
              'Cool-down: 5min',
              '🏆 HERSTEL: 48-72 uur voor volgende training'
            ],
            duration: 125
          };
        }
        
        if (customTraining) {
          return {
            type: `${customTraining.type} - CUSTOM`,
            focus: [
              `🏃 ${customTraining.description || customTraining.type}`,
              `🕐 Tijd: ${customTraining.time}`,
              `⏱️ Duur: ${customTraining.duration} minuten`,
              'Opwarming: 13min opwarmingsoefeningen + dynamische stretching',
              'Blessurepreventie: 7min blessurepreventieve oefeningen',
              'Voetbalconditioneel: 10min volgens periodisering',
              `Voetbaltactisch/technisch: 55min ${customTraining.type.toLowerCase()} volgens thema`,
              'Cool-down: 5min',
              '💡 CUSTOM TRAINING - Aangepaste inhoud'
            ],
            duration: customTraining.duration
          };
        }
        
        if (dayName === 'saturday') {
          // Standaard zaterdag wedstrijd (als geen specifieke wedstrijd gepland)
          return {
            type: 'WEDSTRIJD',
            focus: [
              '⚽ Wedstrijd (details volgen)',
              'Opwarming: 30min wedstrijd-specifiek',
              'Wedstrijd: 90min competitie', 
              'Cool-down: 5min',
              '🏆 HERSTEL: 48-72 uur voor volgende training'
            ],
            duration: 125
          };
        }
        
        if (dayName === 'wednesday') {
          // Woensdag SNELHEID volgens Verheyen 6-weken periodisering
          switch(periodInfo.phase) {
            case 'algemeen1': // Blok 1A (Week 1-6): Basis snelheid
              return {
                type: `SNELHEID BASIS (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK',
                  'Warming-up: 15min licht dynamisch',
                  'Techniek: 6x20m @ 70% max snelheid',
                  'Rust: 90sec tussen runs',
                  'Coördinatie: 4x15m skipping/hopping',
                  'Cool-down: 10min extensief',
                  '⚡ SUPERCOMPENSATIE: 24-36 uur voor neuromusculair herstel'
                ] : [
                  'Warming-up: 25min progressief + 6x40m strides',
                  `Week ${weekInBlock}: Snelheidsopbouw ${weekInBlock}x30m`,
                  'Sprint techniek: 8x15m perfecte vorm @ 80%',
                  'Rust tussen runs: 2min complete rust',
                  'Acceleratie: 6x25m vanuit stilstand',
                  'Rust tussen series: 3min actief wandelen',
                  'Cool-down: 15min + mobiliteit',
                  `⚡ SUPERCOMPENSATIE: ${24 + (weekInBlock * 8)} uur voor snelheidsadaptatie`
                ],
                duration: isDeloadWeek ? 45 : 75
              };
            
            case 'algemeen2': // Blok 1B (Week 7-12): Snelheidsuitbreiding
              return {
                type: `SNELHEIDSUITBREIDING (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK',
                  'Warming-up: 15min gemakkelijk',
                  'Techniek: 4x30m @ 75% max',
                  'Reactiesnelheid: 6x10m verschillende starts',
                  'Cool-down: 12min extensief',
                  '⚡ SUPERCOMPENSATIE: 36-48 uur voor snelheidsuitbreiding'
                ] : [
                  'Warming-up: 30min + 8x50m progressief',
                  `Week ${weekInBlock}: ${4 + weekInBlock}x40m @ 85-90%`,
                  'Rust tussen runs: 3min complete rust',
                  'Flying sprints: 6x30m (20m aanloop)',
                  'Rust tussen series: 4min passief',
                  'Richtingsverandering: 8x20m zigzag',
                  'Cool-down: 18min extensief + stretching',
                  `⚡ SUPERCOMPENSATIE: ${36 + (weekInBlock * 8)} uur voor neuromusculaire verbetering`
                ],
                duration: isDeloadWeek ? 50 : 85
              };

            case 'specifiek1': // Blok 2A (Week 13-18): Lactaat tolerance
              return {
                type: `SNELHEID LACTAAT (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK',
                  'Warming-up: 20min licht',
                  'Snelheid: 4x40m @ 80%',
                  'Rust: 4min tussen runs',
                  'Cool-down: 15min'
                ] : [
                  'Warming-up: 35min + specifieke voorbereiding',
                  `Week ${weekInBlock}: ${2 + weekInBlock}x60m @ 90-95%`,
                  'Rust tussen runs: 5min complete rust',
                  'Lactaat tolerance: 4x150m @ 85% max',
                  'Rust tussen 150m: 6min actief wandelen',
                  'Maximale sprint: 3x80m @ 100%',
                  'Rust tussen max: 8min complete rust',
                  'Cool-down: 25min extensief joggen'
                ],
                duration: isDeloadWeek ? 60 : 95
              };

            case 'specifiek2': // Blok 2B (Week 19-24): VO2max snelheid
              return {
                type: `VO2MAX SNELHEID (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK',
                  'Warming-up: 20min comfortabel',
                  'Snelheid: 5x30m @ 85%',
                  'Explosiviteit: 6x15m starts',
                  'Cool-down: 15min'
                ] : [
                  'Warming-up: 40min + snelheidsvoorbereiding',
                  `Week ${weekInBlock}: ${6 + weekInBlock}x80m @ 95-100%`,
                  'Rust tussen runs: 6min complete rust',
                  'VO2max intervals: 5x2min @ max aerobe snelheid',
                  'Rust tussen intervals: 2min actief',
                  'Neuromusculair: 4x30m ALL-OUT',
                  'Rust tussen ALL-OUT: 5min complete rust',
                  'Cool-down: 30min extensief + massage'
                ],
                duration: isDeloadWeek ? 65 : 105
              };

            case 'precompetitie': // Blok 3A (Week 25-30): Power piek
              return {
                type: `POWER PIEK (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK - TAPER',
                  'Warming-up: 25min kwaliteit prep',
                  'Snelheid: 3x40m @ 95% perfecte techniek',
                  'Rust: 6min tussen runs',
                  'Activatie: 4x20m explosief',
                  'Cool-down: 20min regeneratie'
                ] : [
                  'Warming-up: 45min competitie-specifiek',
                  `Week ${weekInBlock}: Power focus ${8 + weekInBlock}x100m`,
                  'Interval: 30sec @ 100% - 5min rust',
                  'Explosieve power: 8x20m bergop/stairs',
                  'Rust tussen power: 3min complete',
                  'Reactiesnelheid: 10x15m verschillende starts',
                  'Max snelheid: 3x60m @ 100% perfect',
                  'Rust tussen max: 10min complete rust',
                  'Cool-down: 35min extensief + regeneratie'
                ],
                duration: isDeloadWeek ? 70 : 115
              };

            default: // Competitie en overgang
              return {
                type: `COMPETITIE ONDERHOUD (${periodInfo.block})`,
                focus: [
                  'Warming-up: 30min wedstrijd-specifiek',
                  'Onderhoud snelheid: 4x50m @ 90%',
                  'Rust: 4min tussen runs',
                  'Explosiviteit: 6x25m starts',
                  'Neuromusculair activatie: 3x30m @ 95%',
                  'Cool-down: 20min regeneratie focus'
                ],
                duration: 80
              };
          }
        }
        
        if (dayName === 'monday') {
          // Maandag CONDITIE volgens Verheyen 6-weken periodisering + supercompensatie
          switch(periodInfo.phase) {
            case 'algemeen1': // Blok 1A (Week 1-6): Aerobe basis
              return {
                type: `AEROBE BASIS (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK',
                  'Warming-up: 15min @ 65% HRmax',
                  'Hoofddeel: 20min continue @ 70% HRmax',
                  'Cool-down: 10min extensief @ 60% HRmax',
                  '🔄 SUPERCOMPENSATIE: 24-36 uur voor volledige herstel'
                ] : [
                  'Warming-up: 20min progressief 60-75% HRmax',
                  `Week ${weekInBlock}: ${25 + (weekInBlock * 5)}min tempo @ 75-80% HRmax`,
                  'Interval blok: 4x6min @ 82% HRmax',
                  'Rust tussen intervals: 2min actief @ 65% HRmax',
                  'Cool-down: 5min extensief @ 60% HRmax',
                  `🔄 SUPERCOMPENSATIE: ${36 + (weekInBlock * 6)} uur voor aerobe adaptatie`
                ],
                duration: isDeloadWeek ? 50 : (70 + (weekInBlock * 5))
              };

            case 'algemeen2': // Blok 1B (Week 7-12): Aerobe capaciteit
              return {
                type: `AEROBE CAPACITEIT (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK',
                  'Warming-up: 18min @ 65% HRmax',
                  'Hoofddeel: 25min @ 72% HRmax',
                  'Interval: 3x4min @ 78% HRmax, rust 90sec',
                  'Cool-down: 12min @ 60% HRmax',
                  '🔄 SUPERCOMPENSATIE: 30-42 uur voor adaptatie'
                ] : [
                  'Warming-up: 25min + 6x100m strides',
                  `Week ${weekInBlock}: ${30 + (weekInBlock * 4)}min tempo @ 78-83% HRmax`,
                  'Lactaat drempel: 5x8min @ 85% HRmax',
                  'Rust tussen series: 2min actief @ 65% HRmax',
                  'Afbouw: 6min tempo @ 75% HRmax',
                  'Cool-down: 18min extensief + stretching',
                  `🔄 SUPERCOMPENSATIE: ${42 + (weekInBlock * 6)} uur voor metabole adaptatie`
                ],
                duration: isDeloadWeek ? 60 : (80 + (weekInBlock * 8))
              };

            case 'specifiek1': // Blok 2A (Week 13-18): Lactaat drempel
              return {
                type: `LACTAAT DREMPEL (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK',
                  'Warming-up: 20min @ 70% HRmax',
                  'Drempel test: 3x6min @ 85% HRmax',
                  'Rust: 3min actief tussen series',
                  'Cool-down: 15min extensief',
                  '🔄 SUPERCOMPENSATIE: 48 uur voor enzymatische adaptatie'
                ] : [
                  'Warming-up: 30min + lactaat voorbereiding',
                  `Week ${weekInBlock}: ${4 + weekInBlock}x10min @ 87-92% HRmax`,
                  'Rust tussen blokken: 3min actief @ 65% HRmax',
                  'Lactaat meting: na elke serie (4-8 mmol/L target)',
                  'Tempo finish: 5min @ 85% HRmax',
                  'Cool-down: 25min extensief joggen',
                  `🔄 SUPERCOMPENSATIE: ${48 + (weekInBlock * 8)} uur voor lactaat clearing adaptatie`
                ],
                duration: 45
              };

            case 'specifiek2': // Blok 2B (Week 19-24): VO2max training
              return {
                type: `VO2MAX TRAINING (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'ONTLASTING WEEK',
                  'Warming-up: 25min comfortabel',
                  'VO2max: 4x3min @ 90% HRmax',
                  'Rust: 3min complete tussen series',
                  'Cool-down: 20min regeneratie',
                  '🔄 SUPERCOMPENSATIE: 48-60 uur voor cardiovasculaire adaptatie'
                ] : [
                  'Warming-up: 35min + VO2max voorbereiding',
                  `Week ${weekInBlock}: ${3 + weekInBlock}x4min @ 92-97% HRmax`,
                  'Rust tussen intervals: 3min complete rust',
                  'VO2max bevestiging: 2x2min @ 100% HRmax',
                  'Rust tussen max: 4min complete rust',
                  'Lactaat meting: >8 mmol/L na max efforts',
                  'Cool-down: 30min extensief + massage',
                  `🔄 SUPERCOMPENSATIE: ${60 + (weekInBlock * 8)} uur voor maximale aerobe adaptatie`
                ],
                duration: isDeloadWeek ? 75 : (100 + (weekInBlock * 10))
              };

            case 'precompetitie': // Blok 3A (Week 25-30): Onderhoud + taper
              return {
                type: `CONDITIE ONDERHOUD (${periodInfo.block})`,
                focus: isDeloadWeek ? [
                  'TAPER WEEK - VERMINDERDE BELASTING',
                  'Warming-up: 20min kwaliteit @ 70% HRmax',
                  'Onderhoud: 3x5min @ 85% HRmax',
                  'Rust: 4min complete tussen series',
                  'Activatie: 3x2min @ 90% HRmax',
                  'Cool-down: 20min regeneratie focus',
                  '🔄 SUPERCOMPENSATIE: 36-48 uur voor wedstrijd readiness'
                ] : [
                  'Warming-up: 30min wedstrijd-specifiek prep',
                  `Week ${weekInBlock}: Onderhoud ${3 + weekInBlock}x6min @ 88% HRmax`,
                  'Rust tussen series: 3min actief @ 70% HRmax',
                  'Lactaat clearing: 4x3min @ 85% HRmax',
                  'Neuromusculaire activatie: 6x30sec @ 95% HRmax',
                  'Cool-down: 25min extensief + mobiliteit',
                  `🔄 SUPERCOMPENSATIE: ${42 + (weekInBlock * 6)} uur voor competitie readiness`
                ],
                duration: isDeloadWeek ? 70 : (85 + (weekInBlock * 5))
              };

            default: // Competitie onderhoud
              return {
                type: `COMPETITIE ONDERHOUD (${periodInfo.block})`,
                focus: [
                  'Warming-up: 25min wedstrijd prep @ 70% HRmax',
                  'Onderhoud: 4x5min @ 85% HRmax',
                  'Rust: 3min actief tussen series',
                  'Lactaat buffer: 3x3min @ 88% HRmax',
                  'Cool-down: 20min regeneratie',
                  '🔄 SUPERCOMPENSATIE: 36-48 uur tussen wedstrijden'
                ],
                duration: 75
              };
          }
        }

        if (dayName === 'monday') {
          // Oude maandag functie (wordt vervangen door bovenstaande)
          const mondayOptions = [
            { 
              type: 'EXTENSIEVE CONDITIE (Week 1-2)', 
              focus: [
                'Warming-up: 12min opwarming + dynamische stretching',
                'Blessurepreventie: 7min enkels/heup/adductoren (Week 1-2 focus)',
                'Hoofddeel: 30min tempo run @ 70-75% HRmax',
                'Tussentijd controle: elke 10min tempo check',
                'Interval blok: 3x5min @ 80% HRmax',
                'Rust tussen intervals: 2min actief @ 60% HRmax',
                'Cool-down: 5min extensief @ 55% HRmax'
              ], 
              duration: 90
            },
            { 
              type: 'TEMPO ENDURANCE (Week 3-4)', 
              focus: [
                'Warming-up: 12min opwarming + dynamische stretching',
                'Blessurepreventie: 7min enkels/heup/adductoren (Week 3-4 focus)',
                'Hoofddeel: 5x6min @ 85% HRmax (tempo endurance)',
                'Rust tussen series: 2min actief joggen @ 65% HRmax',
                'Finish: 2x2min @ 90% HRmax',
                'Rust tussen finish: 3min complete rust',
                'Cool-down: 5min extensief + stretching'
              ], 
              duration: 90
            },
            { 
              type: 'TEMPO STEADY STATE (Week 5-6)', 
              focus: [
                'Warming-up: 12min opwarming + dynamische stretching',
                'Blessurepreventie: 7min enkels/heup/adductoren (Week 5-6 focus)',
                'Hoofddeel: 4x8min @ 83-87% HRmax',
                'Rust tussen blokken: 3min actief @ 60% HRmax',
                'Tempo controle: constant ritme aanhouden',
                'Afbouw: 10min tempo @ 75% HRmax',
                'Cool-down: 5min extensief joggen'
              ], 
              duration: 90
            },
            { 
              type: 'HERSTEL CONDITIE (Week 7-8)', 
              focus: [
                'Warming-up: 12min opwarming + dynamische stretching',
                'Blessurepreventie: 7min enkels/heup/adductoren (Week 7-8 focus)',
                'Hoofddeel: 20min continue @ 70-75% HRmax',
                'Interval variatie: 6x2min @ 80% HRmax',
                'Rust tussen intervals: 90sec actief @ 60% HRmax',
                'Fartlek: 5min vrij tempo spel',
                'Cool-down: 5min extensief + mobiliteit'
              ], 
              duration: 70
            }
          ];
          return mondayOptions[Math.floor(weekNumber/2) % mondayOptions.length];
        }
        
        // Voor andere dagen, cyclus door EDT/IDT/EIT/IIT/RUST
        const dayTraining = polarizedTrainingTypes.find(t => t.day === dayName);
        return dayTraining || polarizedTrainingTypes[0];
      };
      
      const startDate = new Date(customSchema.startDate);
      const endDate = new Date(customSchema.endDate);
      const dayToNumber = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
      
      let currentDate = new Date(startDate);
      let sessionCount = 0;
      let weekNumber = 0;
      
      while (currentDate <= endDate) {
        const dayName = Object.keys(dayToNumber).find(key => dayToNumber[key as keyof typeof dayToNumber] === currentDate.getDay());
        
        if (dayName && customSchema.selectedDays.includes(dayName)) {
          if (yPosition > 250) {
            doc.addPage();
            yPosition = 20;
          }
          
          // Gebruik volledig uitgewerkt training systeem met alle parameters
          const weekNumber = Math.floor(sessionCount / customSchema.selectedDays.length) + 1;
          const trainingType = getTrainingForDay(dayName, weekNumber);
          
          // Bepaal trainingsintensiteit voor blessurepreventie
          let trainingIntensity: 'low' | 'medium' | 'high' = 'medium';
          if (trainingType.type.includes('HERSTEL') || trainingType.type.includes('ONTLASTING')) {
            trainingIntensity = 'low';
          } else if (trainingType.type.includes('SNELHEID') || trainingType.type.includes('VO2MAX')) {
            trainingIntensity = 'high';
          }
          
          const injuryPrevention = getInjuryPreventionFocus(weekNumber, trainingIntensity);
          
          if (yPosition > 220) {
            doc.addPage();
            yPosition = 20;
          }
          
          // Datum en training titel
          doc.setFontSize(14);
          doc.setTextColor(0, 51, 102);
          doc.text(`${dayNames[dayName as keyof typeof dayNames]} ${currentDate.toLocaleDateString('nl-NL')}`, 14, yPosition);
          
          doc.setFontSize(12);
          doc.setTextColor(200, 0, 0);
          doc.text(`${trainingType.type}`, 14, yPosition + 12);
          
          doc.setFontSize(10);
          doc.setTextColor(80, 80, 80);
          doc.text(`Duur: ${trainingType.duration} minuten`, 14, yPosition + 24);
          
          // Blessurepreventie sectie toevoegen
          doc.setFontSize(10);
          doc.setTextColor(255, 140, 0);
          doc.text(`🔶 Blessurepreventie: ${injuryPrevention.focus} (${injuryPrevention.repetitions})`, 14, yPosition + 36);
          
          doc.setFontSize(8);
          doc.setTextColor(100, 100, 100);
          doc.text(`Oefeningen: ${injuryPrevention.specificExercises.join(', ')}`, 14, yPosition + 46);
          
          // Training parameters in detail
          doc.setFontSize(9);
          let detailY = yPosition + 56;
          trainingType.focus.forEach((focus, index) => {
            if (detailY > 270) {
              doc.addPage();
              detailY = 20;
            }
            
            // Highlight belangrijke parameters
            if (focus.includes('SUPERCOMPENSATIE') || focus.includes('⚡') || focus.includes('🔄')) {
              doc.setTextColor(255, 140, 0); // Oranje voor supercompensatie
              doc.setFontSize(9);
            } else if (focus.includes('@') || focus.includes('min') || focus.includes('sec')) {
              doc.setTextColor(0, 100, 0); // Groen voor tijden/intensiteit
              doc.setFontSize(9);
            } else if (focus.includes('Rust') || focus.includes('rust')) {
              doc.setTextColor(0, 0, 200); // Blauw voor rust
              doc.setFontSize(9);
            } else {
              doc.setTextColor(80, 80, 80); // Normale tekst
              doc.setFontSize(8);
            }
            
            doc.text(`• ${focus}`, 16, detailY);
            detailY += 8;
          });
          
          // Scheidingslijn tussen trainingen
          doc.setDrawColor(200, 200, 200);
          doc.line(14, detailY + 5, 195, detailY + 5);
          
          yPosition = detailY + 15;
          sessionCount++;
        }
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
      
      doc.save(`${customSchema.name || 'Custom-Schema'}-${customSchema.startDate}.pdf`);
      console.log("Custom PDF generated successfully!");
    } catch (error) {
      console.error("Error generating custom PDF:", error);
      alert("Er was een fout bij het genereren van de PDF. Probeer opnieuw.");
    }
  };

  // Custom Schema Excel Generation
  const generateCustomSchemaExcel = () => {
    try {
      const wb = XLSX.utils.book_new();
      
      // Helper functies voor datum berekeningen
      const addDays = (date: Date, days: number) => {
        const result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
      };
      
      const isInactivePeriod = (date: Date) => {
        for (const period of customSchema.inactivePeriods) {
          const start = new Date(period.start);
          const end = new Date(period.end);
          if (date >= start && date <= end) {
            return true;
          }
        }
        return false;
      };
      
      // Definieer training functie lokaal voor Excel met periodisering
      const getExcelTraining = (dayName: string, weekNumber: number, sessionDate: Date) => {
        // 4-weken microcyclus: EDT → IDT → EIT → HERSTEL
        const getPeriodPhase = (week: number, sessionDate: Date) => {
          const cycleWeek = ((week - 1) % 4) + 1;
          switch(cycleWeek) {
            case 1: return 'EDT (Extensieve Duurmethode)';
            case 2: return 'IDT (Intensieve Duurmethode)';
            case 3: return 'EIT (Extensieve Intervaltraining)';
            case 4: return 'HERSTEL (Actief Herstel)';
            default: return 'EDT (Extensieve Duurmethode)';
          }
        };
        
        const getActiveWeekNumber = (weekNumber: number, sessionDate: Date) => {
          return weekNumber;
        };
        
        const mesocyclusNumber = Math.ceil(weekNumber / 4);
        const mesocyclusWeek = ((weekNumber - 1) % 4) + 1;
        
        // Voetbaltraining bepalen per periodiseringsfase
        const getVoetbaltraining = (periodPhase: string) => {
          if (periodPhase.includes('EDT')) return 'WV (8v8-11v11) Grote Ruimtes';
          if (periodPhase.includes('IDT')) return 'WV (5v5-7v7) Kleinere ruimtes';
          if (periodPhase.includes('EIT')) return 'WV (1v1-4v4) Kleine ruimtes';
          if (periodPhase.includes('HERSTEL')) return 'WV (Fun games) Recreatief';
          if (periodPhase.includes('INACTIVATIE')) return 'Geen training';
          return 'WV (Mixed) Variatie';
        };
        
        const periodPhase = getPeriodPhase(weekNumber, sessionDate);
        
        if (dayName === 'saturday') {
          return { 
            type: 'WEDSTRIJD', 
            focus: ['Competitie voetbal', 'Match performance', `Periodisering: ${periodPhase}`], 
            duration: 90,
            periodPhase: periodPhase
          };
        }
        if (dayName === 'monday') {
          const sessionDate = addDays(startDate, sessionCount);
          
          // Check voor vakantieperiode
          if (isInactivePeriod(sessionDate)) {
            return { 
              type: `CONDITIE - INACTIVATIE (Vakantieperiode)`, 
              focus: [
                `PERIODISERING: INACTIVATIE - Vakantieperiode`,
                `Volledige rust aanbevolen`,
                `Optioneel: lichte recreatieve activiteit`,
                `Focus op herstel en mentale ontspanning`,
                `Voorbereiding op herstart training`,
                `SUPERCOMPENSATIE: Volledige regeneratie`
              ], 
              duration: 0
            };
          }
          
          const cycleWeek = ((weekNumber - 1) % 4) + 1;
          const cycleNumber = Math.floor((weekNumber - 1) / 4) + 1;
          
          // Parameters gebaseerd op periodiseringsfase en mesocyclus nummer
          let baseIntensity, baseDuration, intervalCount, restTime;
          
          if (mesocyclusWeek === 5) {
            // INACTIVATIE week - zeer lichte training
            baseIntensity = 60;
            baseDuration = 20;
            intervalCount = 2;
            restTime = 4;
          } else {
            switch(mesocyclusWeek) {
              case 1: // EDT week - elke mesocyclus opnieuw beginnen op niveau 1
                baseIntensity = 68 + (mesocyclusNumber - 1) * 2; // 68%, 70%, 72%...
                baseDuration = 25 + (mesocyclusNumber - 1) * 3; // 25min, 28min, 31min...
                intervalCount = 3 + Math.floor((mesocyclusNumber - 1) / 2); // 3, 3, 4, 4...
                restTime = 2;
                break;
              case 2: // IDT week  
                baseIntensity = 75 + (mesocyclusNumber - 1) * 2; // 75%, 77%, 79%...
                baseDuration = 20 + (mesocyclusNumber - 1) * 3; // 20min, 23min, 26min...
                intervalCount = 4 + Math.floor((mesocyclusNumber - 1) / 2); // 4, 4, 5, 5...
                restTime = 2;
                break;
              case 3: // EIT week
                baseIntensity = 82 + (mesocyclusNumber - 1) * 2; // 82%, 84%, 86%...
                baseDuration = 6 + Math.floor((mesocyclusNumber - 1) / 2); // 6min, 6min, 7min...
                intervalCount = 5 + Math.floor((mesocyclusNumber - 1) / 2); // 5, 5, 6, 6...
                restTime = 3;
                break;
              default: // HERSTEL week (week 4)
                baseIntensity = 65; // Altijd rustig
                baseDuration = 15;
                intervalCount = 2;
                restTime = 3;
            }
          }
          
          return { 
            type: `CONDITIE - ${periodPhase} (Week ${weekNumber}, Mesocyclus ${mesocyclusNumber})`, 
            focus: [
              `PERIODISERING: ${periodPhase} - Mesocyclus ${mesocyclusNumber}`,
              `Opwarming: 13min opwarmingsoefeningen + dynamische stretching`,
              `Blessurepreventie: 7min blessurepreventieve oefeningen`,
              `Voetbalconditioneel: 10min volgens periodisering met HIIT principes`,
              `Kracht: 10min HIIT - ${periodPhase.includes('EDT') ? 'BENEN focus (squats, lunges)' : periodPhase.includes('IDT') ? 'CORE focus (planks, mountain climbers)' : periodPhase.includes('EIT') ? 'ARMEN focus (push-ups, burpees)' : 'HERSTEL (lichte mobiliteit)'}`,
              `Voetbaltactisch/technisch: 45min volgens thema`,
              `Cool-down: 5min`,
              `SUPERCOMPENSATIE: ${mesocyclusWeek === 5 ? 72 : 30 + mesocyclusWeek * 6 + (mesocyclusNumber - 1) * 3} uur`
            ], 
            duration: mesocyclusWeek === 5 ? 50 : 70 + baseDuration + intervalCount * 2
          };
        }
        if (dayName === 'wednesday') {
          const mesocyclusWeek = ((weekNumber - 1) % 5) + 1;
          const mesocyclusNumber = Math.floor((weekNumber - 1) / 5) + 1;
          
          // Snelheidsparameters gebaseerd op periodiseringsfase en mesocyclus
          let sprintDistance, sprintCount, accelerationCount, intensity, restTime;
          
          if (mesocyclusWeek === 5) {
            // INACTIVATIE week - minimale snelheidswerk
            sprintDistance = 20;
            sprintCount = 3;
            accelerationCount = 2;
            intensity = 70;
            restTime = 4;
          } else {
            switch(mesocyclusWeek) {
              case 1: // EDT week - Snelheidsopbouw basis (reset elke mesocyclus)
                sprintDistance = 30 + (mesocyclusNumber - 1) * 5; // 30m, 35m, 40m...
                sprintCount = 6 + Math.floor((mesocyclusNumber - 1) / 2); // 6, 6, 7, 7...
                accelerationCount = 4 + mesocyclusNumber - 1; // 4, 5, 6, 7...
                intensity = 80 + (mesocyclusNumber - 1); // 80%, 81%, 82%...
                restTime = 2;
                break;
              case 2: // IDT week - Snelheidsendurance
                sprintDistance = 50 + (mesocyclusNumber - 1) * 10; // 50m, 60m, 70m...
                sprintCount = 5 + Math.floor((mesocyclusNumber - 1) / 2); // 5, 5, 6, 6...
                accelerationCount = 6 + mesocyclusNumber - 1; // 6, 7, 8, 9...
                intensity = 85 + (mesocyclusNumber - 1); // 85%, 86%, 87%...
                restTime = 3;
                break;
              case 3: // EIT week - Maximale snelheid
                sprintDistance = 60 + (mesocyclusNumber - 1) * 10; // 60m, 70m, 80m...
                sprintCount = 4 + Math.floor((mesocyclusNumber - 1) / 2); // 4, 4, 5, 5...
                accelerationCount = 8 + mesocyclusNumber - 1; // 8, 9, 10, 11...
                intensity = 90 + Math.min(mesocyclusNumber - 1, 5); // 90%, 91%, 92%... max 95%
                restTime = 4 + Math.floor((mesocyclusNumber - 1) / 3); // 4min, 4min, 4min, 5min...
                break;
              default: // HERSTEL week (week 4) - Lichte snelheid
                sprintDistance = 25; // Altijd kort
                sprintCount = 4; // Weinig volume
                accelerationCount = 3; // Minimal
                intensity = 75; // Lage intensiteit
                restTime = 3; // Ruime rust
            }
          }
          
          return { 
            type: `SNELHEID - ${periodPhase} (Week ${weekNumber}, Mesocyclus ${mesocyclusNumber})`, 
            focus: [
              `PERIODISERING: ${periodPhase} - Mesocyclus ${mesocyclusNumber}`,
              `Opwarming: 13min opwarmingsoefeningen + dynamische stretching`,
              `Blessurepreventie: 7min blessurepreventieve oefeningen`,
              `Voetbalconditioneel: 10min opbouwend volgens periodisering met HIIT principes`,
              `Kracht: 10min HIIT - ${periodPhase.includes('EDT') ? 'BENEN focus (squats, lunges)' : periodPhase.includes('IDT') ? 'CORE focus (planks, mountain climbers)' : periodPhase.includes('EIT') ? 'ARMEN focus (push-ups, burpees)' : 'HERSTEL (lichte mobiliteit)'}`,
              `Voetbaltactisch/technisch: 45min volgens thema`,
              `Cool-down: 5min`,
              `SUPERCOMPENSATIE: ${mesocyclusWeek === 5 ? 96 : 36 + mesocyclusWeek * 8 + (mesocyclusNumber - 1) * 4} uur`
            ], 
            duration: mesocyclusWeek === 5 ? 60 : 75 + sprintCount * 2 + accelerationCount
          };
        }
        return { 
          type: `TRAINING - ${periodPhase}`, 
          focus: [`PERIODISERING: ${periodPhase}`, 'Standaard training aangepast aan fase'], 
          duration: 75 
        };
      };
      
      // Overview sheet
      const dayNames = { monday: "Maandag", tuesday: "Dinsdag", wednesday: "Woensdag", thursday: "Donderdag", friday: "Vrijdag", saturday: "Zaterdag", sunday: "Zondag" };
      const selectedDayNames = customSchema.selectedDays.map(day => dayNames[day as keyof typeof dayNames]).join(", ");
      
      const overviewData = [
        [customSchema.name || 'Aangepast Trainingsschema'],
        [''],
        ['Periode', `${customSchema.startDate} tot ${customSchema.endDate}`],
        ['Trainingsdagen', selectedDayNames],
        ['Sessies per week', customSchema.selectedDays.length.toString()],
        ['']
      ];
      
      const overviewSheet = XLSX.utils.aoa_to_sheet(overviewData);
      XLSX.utils.book_append_sheet(wb, overviewSheet, 'Overzicht');
      
      // COMPLETE DAGELIJKSE TRAININGSSCHEMA MET VOETBALTRAINING
      const scheduleData = [
        ['VOLLEDIGE TRAININGSPLANNING - VERHEYEN PERIODISERING'],
        [''],
        ['Datum', 'Dag', 'Week', 'Blok', 'Training Type', 'Duur (min)', 'Opwarming (13min)', 'Blessurepreventie (7min)', 'Conditioneel RPE', 'Conditioneel Afstanden', 'Conditioneel %HRmax', 'Conditioneel %VO2max', 'Conditioneel Series', 'Conditioneel Herhalingen', 'Conditioneel Rustperiodes', 'Kracht RPE', 'Kracht HIIT Focus', 'Kracht Series', 'Kracht Herhalingen', 'Kracht Rustperiodes', 'Voetbaltactisch/technisch (35min)', 'VOETBALTRAINING', 'Cool-down (5min)', 'Supercompensatie', 'Periodisering']
      ];
      
      const startDate = new Date(customSchema.startDate);
      const endDate = new Date(customSchema.endDate);
      const dayToNumber = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
      
      // Helper functie voor injury prevention met ACL en hamstring focus
      const getInjuryPreventionFocus = (weekNumber: number, intensity: 'low' | 'medium' | 'high' = 'medium') => {
        const injuryWeek = ((weekNumber - 1) % 8) + 1;
        
        // Geperiodiseerde ACL preventie (progressieve opbouw)
        const getACLExercises = (week: number, intensity: string) => {
          const baseLevel = intensity === 'low' ? 1 : intensity === 'high' ? 3 : 2;
          const weekLevel = Math.min(3, Math.floor(week / 3) + baseLevel);
          
          if (weekLevel === 1) return ['Single leg stance 20sec', 'Wall sit 30sec', 'Squat to calf raise 8x'];
          if (weekLevel === 2) return ['Single leg squat 6x', 'Jump land stick 8x', 'Lateral bounds 10x'];
          return ['Single leg hop 8x', 'Cutting drills 12x', 'Plyometric jumps 6x'];
        };
        
        // Geperiodiseerde hamstring versterking (progressieve opbouw)
        const getHamstringExercises = (week: number, intensity: string) => {
          const baseReps = intensity === 'low' ? 6 : intensity === 'high' ? 12 : 8;
          const weekProgression = Math.min(4, Math.floor(week / 2) + 1);
          const reps = baseReps + (weekProgression - 1) * 2;
          
          if (weekProgression <= 2) return [`Glute bridges ${reps}x`, `Single leg deadlift ${reps-2}x`, `Wall slides ${reps}x`];
          if (weekProgression === 3) return [`Nordic curls ${Math.max(3, reps-4)}x`, `Romanian deadlift ${reps}x`, `Hamstring curls ${reps+2}x`];
          return [`Advanced nordics ${Math.max(4, reps-2)}x`, `Single leg RDL ${reps}x`, `Eccentric hamstring ${reps-1}x`];
        };
        
        const focuses = [
          { focus: 'ACL + Enkelstabiliteit', exercises: [...getACLExercises(injuryWeek, intensity), 'Eenbeen balans', 'Enkelcirkels'] },
          { focus: 'Hamstring + Heupstabiliteit', exercises: [...getHamstringExercises(injuryWeek, intensity), 'Clamshells', 'Heup bruggen'] },
          { focus: 'ACL + Adductoren', exercises: [...getACLExercises(injuryWeek, intensity), 'Cossakken squats', 'Laterale lunges'] },
          { focus: 'Hamstring + Core stabiliteit', exercises: [...getHamstringExercises(injuryWeek, intensity), 'Planks', 'Bird dogs'] },
          { focus: 'ACL + Proprioceptie', exercises: [...getACLExercises(injuryWeek, intensity), 'Ogen dicht balans', 'Wobble board'] },
          { focus: 'Hamstring + Glutes', exercises: [...getHamstringExercises(injuryWeek, intensity), 'Monster walks', 'Side steps'] },
          { focus: 'ACL + Reactie training', exercises: [...getACLExercises(injuryWeek, intensity), 'Direction changes', 'Stop-start drills'] },
          { focus: 'Hamstring + Flexibiliteit', exercises: [...getHamstringExercises(injuryWeek, intensity), 'Dynamic stretches', 'Leg swings'] }
        ];
        
        const focusData = focuses[injuryWeek - 1];
        const reps = intensity === 'low' ? '2x6-8' : intensity === 'high' ? '3x10-12' : '2x8-10';
        
        return {
          focus: focusData.focus,
          exercises: focusData.exercises,
          specificExercises: focusData.exercises,
          repetitions: reps
        };
      };

      let currentDate = new Date(startDate);
      let sessionCount = 0;
      
      while (currentDate <= endDate) {
        const dayName = Object.keys(dayToNumber).find(key => dayToNumber[key as keyof typeof dayToNumber] === currentDate.getDay());
        
        if (dayName && customSchema.selectedDays.includes(dayName)) {
          // Check of huidige datum in vakantieperiode valt - zo ja, sla over
          let isInVacation = false;
          for (const period of customSchema.inactivePeriods) {
            const vacationStart = new Date(period.start);
            const vacationEnd = new Date(period.end);
            if (currentDate >= vacationStart && currentDate <= vacationEnd) {
              isInVacation = true;
              break;
            }
          }
          
          // Skip trainingen tijdens vakantieperiodes
          if (isInVacation) {
            currentDate.setDate(currentDate.getDate() + 1);
            continue;
          }
          
          // Aangepaste week berekening voor post-vakantie herstart
          let adjustedWeekNumber = Math.floor(sessionCount / customSchema.selectedDays.length) + 1;
          
          // Check of we na een vakantieperiode zijn - zo ja, herstart met EDT
          let postVacationRestart = false;
          for (const period of customSchema.inactivePeriods) {
            const vacationStart = new Date(period.start);
            const vacationEnd = new Date(period.end);
            if (currentDate > vacationEnd) {
              // We zijn na vakantie - vind laatste EDT week vóór vakantie
              const weeksSinceStart = Math.floor((vacationStart.getTime() - new Date(customSchema.startDate).getTime()) / (7 * 24 * 60 * 60 * 1000));
              const lastPreVacationWeek = Math.max(1, weeksSinceStart);
              
              // Vind laatste EDT fase vóór vakantie
              const lastEDTWeek = Math.floor((lastPreVacationWeek - 1) / 4) * 4 + 1; // Laatste EDT week van cyclus
              adjustedWeekNumber = lastEDTWeek; // Herstart met laatste EDT niveau
              postVacationRestart = true;
              break;
            }
          }
          
          const trainingType = getExcelTraining(dayName, adjustedWeekNumber, currentDate);
          
          // Voetbaltraining functie voor Excel
          const getVoetbaltraining = (phase: string) => {
            switch(phase) {
              case 'EDT': return 'WV (8v8-11v11) Grote Ruimtes';
              case 'IDT': return 'WV (5v5-7v7) Kleinere ruimtes';
              case 'EIT': return 'WV (1v1-4v4) Kleine ruimtes';
              case 'HERSTEL': return 'WV (Fun games) Recreatief';
              default: return 'WV (Aangepast aan fase)';
            }
          };
          
          const voetbaltraining = getVoetbaltraining(trainingType.periodPhase || 'EDT');
          
          // Bepaal trainingsintensiteit voor blessurepreventie
          let trainingIntensity: 'low' | 'medium' | 'high' = 'medium';
          if (trainingType.type.includes('HERSTEL') || trainingType.type.includes('ONTLASTING')) {
            trainingIntensity = 'low';
          } else if (trainingType.type.includes('SNELHEID') || trainingType.type.includes('VO2MAX')) {
            trainingIntensity = 'high';
          }
          
          const injuryPrevention = getInjuryPreventionFocus(weekNumber, trainingIntensity);
          
          // Extract all detailed parameters (same as PDF)
          const warmupDetails = trainingType.focus.filter((f: string) => f.includes('Warming-up')).join(' | ') || 'Standaard warming-up';
          const mainDetails = trainingType.focus.filter((f: string) => f.includes('Tempo') || f.includes('Sprints')).join(' | ') || 'Hoofdtraining';
          const distancesIntensity = trainingType.focus.filter((f: string) => f.includes('@') || f.includes('%') || f.includes('m ')).join(' | ') || 'Zie programma';
          const restDetails = trainingType.focus.filter((f: string) => f.includes('Rust') || f.includes('rust')).join(' | ') || 'Zie programma';
          const cooldownDetails = trainingType.focus.filter((f: string) => f.includes('Cool-down')).join(' | ') || 'Standaard cool-down';
          const supercompDetails = trainingType.focus.filter((f: string) => f.includes('SUPERCOMPENSATIE')).join(' | ') || '36-48 uur';
          const allFocusPoints = trainingType.focus.join(' | ');
          
          // Determine block info
          const blockNumber = Math.ceil(weekNumber / 6);
          const blockNames = ['1A', '1B', '2A', '2B', '3A', '3B', '3C', '4'];
          const blockName = blockNames[blockNumber - 1] || '4';
          
          // Extract nieuwe 90-min structuur componenten
          const opwarming = 'Opwarmingsoefeningen + dynamische stretching';
          const blessurepreventie = `${injuryPrevention.focus}: ${injuryPrevention.specificExercises.join(', ')} (${injuryPrevention.repetitions})`;
          // Gedetailleerde Voetbalconditioneel beschrijving met seizoensprogressie
          const getVoetbalconditioneelDetails = (periodPhase: string, weekNum: number, sessionDate: Date) => {
            // Check voor vakantieperiode en bepaal laatste actieve week
            let effectiveWeek = weekNum;
            for (const period of customSchema.inactivePeriods) {
              const vacationStart = new Date(period.start);
              const vacationEnd = new Date(period.end);
              if (sessionDate > vacationEnd) {
                const weeksSinceStart = Math.floor((vacationStart.getTime() - new Date(customSchema.startDate).getTime()) / (7 * 24 * 60 * 60 * 1000));
                effectiveWeek = Math.max(1, weeksSinceStart);
                break;
              }
            }
            
            const mesocyclus = Math.ceil(effectiveWeek / 4);
            const baseIntensity = 65 + Math.floor(mesocyclus / 2) * 5; // 65%, 65%, 70%, 70%...
            const baseDistance = 15 + Math.floor(mesocyclus / 2) * 5; // 15m, 15m, 20m, 20m, 25m...
            const intervalCount = 4 + Math.floor(mesocyclus / 2); // 4, 4, 5, 5...
            const restTime = Math.max(30, 60 - Math.floor(mesocyclus / 2) * 10); // 60sec, 60sec, 50sec... max 1min
            
            if (periodPhase.includes('EDT')) {
              // EDT: 15m → 70m progressie doorheen seizoen
              const edtDistance = 15 + Math.floor(effectiveWeek / 2) * 3; // 15m, 18m, 21m...
              const maxEDTDistance = Math.min(edtDistance, 70);
              // Meer herhalingen bij kortere afstanden, minder bij langere
              const edtReps = Math.max(3, 8 - Math.floor(maxEDTDistance / 15));
              const edtRest = Math.max(45, 90 - Math.floor(maxEDTDistance / 10)); // Kortere rust bij langere afstanden
              return {
                rpe: 'RPE 4-5 (Matig zwaar)',
                afstanden: `${maxEDTDistance}m sprints`,
                hrmax: '65-75%',
                vo2max: '50-65%',
                series: edtReps.toString(),
                herhalingen: `${edtReps}x ${maxEDTDistance}m`,
                rustperiodes: `${Math.min(edtRest, 60)}sec tussen sprints (max 1min HIIT)`
              };
            } else if (periodPhase.includes('IDT')) {
              // IDT: 10m → 30m progressie (tempo training range)
              const idtDistance = 10 + Math.floor(effectiveWeek / 2) * 2; // 10m, 12m, 14m...
              const maxIDTDistance = Math.min(idtDistance, 30);
              // Opbouwende herhalingen doorheen seizoen (4→8 herhalingen)
              const idtReps = Math.min(8, 4 + Math.floor(effectiveWeek / 3));
              // Afbouwende rust doorheen seizoen (60sec→40sec)
              const idtRest = Math.max(40, 60 - Math.floor(effectiveWeek / 2));
              return {
                rpe: 'RPE 6-7 (Zwaar)',
                afstanden: `${maxIDTDistance}m sprints`,
                hrmax: '80-85%',
                vo2max: '70-85%',
                series: idtReps.toString(),
                herhalingen: `${idtReps}x ${maxIDTDistance}m`,
                rustperiodes: `${Math.min(idtRest, 60)}sec tussen sprints (tempo training)`
              };
            } else if (periodPhase.includes('EIT')) {
              // EIT: 10m → 70m progressie doorheen seizoen
              const eitDistance = 10 + Math.floor(effectiveWeek / 2) * 3; // 10m, 13m, 16m...
              const maxEITDistance = Math.min(eitDistance, 70);
              // Opbouwende herhalingen van 3→10 doorheen seizoen
              const eitReps = Math.min(10, 3 + Math.floor(effectiveWeek / 3));
              // Behouden rusttijden (stabiel 60sec voor hoge intensiteit)
              const eitRest = 60; // Stabiele rust voor VO2max training
              return {
                rpe: 'RPE 8-9 (Zeer zwaar)',
                afstanden: `${maxEITDistance}m sprints`,
                hrmax: '90-95%',
                vo2max: '90-100%',
                series: eitReps.toString(),
                herhalingen: `${eitReps}x ${maxEITDistance}m`,
                rustperiodes: `${eitRest}sec tussen sprints (stabiel voor VO2max)`
              };
            } else if (periodPhase.includes('HERSTEL')) {
              return {
                rpe: 'RPE 2-3 (Licht)',
                afstanden: '15m joggen',
                hrmax: '60-65%',
                vo2max: '40-50%',
                series: '2',
                herhalingen: '2x 15m lichte beweging',
                rustperiodes: '45sec tussen bewegingen (actief herstel)'
              };
            }
            return {
              zone: 'Mixed zones',
              afstanden: 'Variabel',
              hrmax: 'Variabel',
              vo2max: 'Variabel',
              series: intervalCount,
              herhalingen: 'Variabel',
              rustperiodes: 'Variabel'
            };
          };
          
          // Gedetailleerde Kracht HIIT beschrijving met seizoensprogressie + winterstop herstart
          const getKrachtHIITDetails = (periodPhase: string, weekNum: number, sessionDate: Date) => {
            // Check voor vakantieperiode en bepaal laatste actieve week
            let effectiveWeek = weekNum;
            let lastActiveWeek = weekNum;
            
            // Zoek laatste actieve week vóór vakantieperiode
            for (const period of customSchema.inactivePeriods) {
              const vacationStart = new Date(period.start);
              const vacationEnd = new Date(period.end);
              
              if (sessionDate > vacationEnd) {
                // Na vakantie - vind laatste week vóór vakantie
                const weeksSinceStart = Math.floor((vacationStart.getTime() - new Date(customSchema.startDate).getTime()) / (7 * 24 * 60 * 60 * 1000));
                lastActiveWeek = Math.max(1, weeksSinceStart);
                effectiveWeek = lastActiveWeek; // Start weer met parameters van laatste week vóór vakantie
                break;
              }
            }
            
            const mesocyclus = Math.ceil(effectiveWeek / 4);
            const baseReps = 8 + Math.floor(mesocyclus / 2) * 2; // 8, 8, 10, 10, 12, 12...
            const baseSets = 2 + Math.floor(mesocyclus / 3); // 2, 2, 2, 3, 3, 3...
            const baseTime = 30 + Math.floor(mesocyclus / 2) * 5; // 30sec, 30sec, 35sec, 35sec...
            const restTime = Math.max(30, 60 - Math.floor(mesocyclus / 2) * 5); // 60sec, 60sec, 55sec...
            
            if (periodPhase.includes('EDT')) {
              return {
                focus: 'BENEN focus',
                series: baseSets.toString(),
                herhalingen: `Squats ${baseReps}x, Lunges ${baseReps-2}x per been, Wall sits ${baseTime}sec`,
                rustperiodes: `${restTime}sec tussen oefeningen, ${restTime-15}sec tussen sets`
              };
            } else if (periodPhase.includes('IDT')) {
              return {
                focus: 'CORE focus',
                series: baseSets.toString(),
                herhalingen: `Planks ${baseTime+15}sec, Mountain climbers ${baseReps+4}x, Russian twists ${baseReps+2}x`,
                rustperiodes: `${restTime-15}sec tussen oefeningen, ${restTime}sec tussen sets`
              };
            } else if (periodPhase.includes('EIT')) {
              return {
                focus: 'ARMEN focus',
                series: baseSets.toString(),
                herhalingen: `Push-ups ${baseReps+2}x, Burpees ${Math.max(6, baseReps-4)}x, Pike push-ups ${baseReps}x`,
                rustperiodes: `${restTime}sec tussen oefeningen, ${restTime+15}sec tussen sets`
              };
            } else if (periodPhase.includes('HERSTEL')) {
              return {
                focus: 'MOBILITEIT',
                series: '2',
                herhalingen: 'Dynamische stretches 30sec per oefening',
                rustperiodes: '15sec tussen oefeningen'
              };
            }
            return {
              focus: 'Mixed HIIT',
              series: baseSets,
              herhalingen: 'Variabel volgens periodisering',
              rustperiodes: 'Variabel'
            };
          };
          
          const tactischTechnisch = 'Tactische en technische training volgens thema (35min)';
          const cooldown = 'Cool-down stretching en ontspanning';
          const supercompensatie = supercompDetails.replace('🔄 SUPERCOMPENSATIE: ', '').replace('⚡ SUPERCOMPENSATIE: ', '').replace('SUPERCOMPENSATIE: ', '') || '36-48 uur';
          const periodisering = trainingType.focus.find(f => f.includes('PERIODISERING:')) || trainingType.type;
          const voetbalconditioneelData = getVoetbalconditioneelDetails(periodisering, weekNumber, currentDate);
          const krachtHIITData = getKrachtHIITDetails(periodisering, weekNumber, currentDate);
          
          // RPE berekeningen voor conditioneel en kracht (met post-vakantie EDT herstart)
          const getConditieelRPE = (phase: string, sessionDate: Date, isPostVacation: boolean) => {
            // Na vakantie altijd hervatten met EDT niveau
            if (isPostVacation) {
              return 'RPE 4-5'; // EDT niveau na vakantie
            }
            
            if (phase.includes('EDT')) return 'RPE 4-5';
            if (phase.includes('IDT')) return 'RPE 6-7';
            if (phase.includes('EIT')) return 'RPE 8-9';
            if (phase.includes('HERSTEL')) return 'RPE 2-3';
            return 'RPE 5-6';
          };
          
          const getKrachtRPE = (phase: string, sessionDate: Date, isPostVacation: boolean) => {
            // Na vakantie altijd hervatten met EDT niveau
            if (isPostVacation) {
              return 'RPE 5-6'; // EDT niveau na vakantie
            }
            
            if (phase.includes('EDT')) return 'RPE 5-6';
            if (phase.includes('IDT')) return 'RPE 6-7';
            if (phase.includes('EIT')) return 'RPE 7-8';
            if (phase.includes('HERSTEL')) return 'RPE 2-3';
            return 'RPE 5-6';
          };
          
          const conditieelRPE = getConditieelRPE(periodisering, currentDate, postVacationRestart);
          const krachtRPE = getKrachtRPE(periodisering, currentDate, postVacationRestart);

          scheduleData.push([
            currentDate.toLocaleDateString('nl-NL'),
            dayNames[dayName as keyof typeof dayNames],
            `Week ${weekNumber}`,
            `Blok ${blockName}`,
            trainingType.type,
            '90',
            opwarming,
            blessurepreventie,
            conditieelRPE,
            voetbalconditioneelData.afstanden,
            voetbalconditioneelData.hrmax,
            voetbalconditioneelData.vo2max,
            voetbalconditioneelData.series,
            voetbalconditioneelData.herhalingen,
            voetbalconditioneelData.rustperiodes,
            krachtRPE,
            krachtHIITData.focus,
            krachtHIITData.series,
            krachtHIITData.herhalingen,
            krachtHIITData.rustperiodes,
            tactischTechnisch,
            voetbaltraining,
            cooldown,
            supercompensatie,
            periodisering.replace('PERIODISERING: ', '')
          ]);
          
          sessionCount++;
        }
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
      
      const scheduleSheet = XLSX.utils.aoa_to_sheet(scheduleData);
      XLSX.utils.book_append_sheet(wb, scheduleSheet, 'Trainingsschema');
      
      // Add match days sheet
      if (customSchema.matchDays.length > 0) {
        const matchData = [
          ['WEDSTRIJDSCHEMA'],
          [''],
          ['Datum', 'Tegenstander', 'Locatie', 'Type', 'Aanvangstijd', 'Voorbereiding', 'Opmerkingen']
        ];
        
        customSchema.matchDays.forEach(match => {
          if (match.date && match.opponent && match.location) {
            const isHomeMatch = match.location.toLowerCase().includes('thuis');
            const matchType = isHomeMatch ? 'Thuiswedstrijd' : 'Uitwedstrijd';
            const preparation = 'Aanwezig 60min voor wedstrijd';
            const remarks = isHomeMatch ? 'Warming-up op eigen veld' : 'Rekening houden met reistijd';
            const matchTime = match.time || '15:00';
            
            matchData.push([
              new Date(match.date).toLocaleDateString('nl-NL'),
              match.opponent,
              match.location,
              matchType,
              matchTime,
              preparation,
              remarks
            ]);
          }
        });
        
        const matchSheet = XLSX.utils.aoa_to_sheet(matchData);
        XLSX.utils.book_append_sheet(wb, matchSheet, 'Wedstrijden');
      }
      
      XLSX.writeFile(wb, `${customSchema.name || 'Custom-Schema'}-${customSchema.startDate}.xlsx`);
      console.log("Custom Excel generated successfully!");
    } catch (error) {
      console.error("Error generating custom Excel:", error);
      alert("Er was een fout bij het genereren van de Excel. Probeer opnieuw.");
    }
  };

  // Custom Schema ICS Generation
  const generateCustomSchemaICS = () => {
    try {
      const formatICSDate = (date: Date) => {
        return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      };
      
      let icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//VVC Brasschaat//Custom Training Schema//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
X-WR-CALNAME:${customSchema.name || 'Aangepast Trainingsschema'}
X-WR-CALDESC:Custom trainingsschema voor VVC Brasschaat

`;

      const trainingTypes = [
        { type: 'Techniek & Passing', focus: 'Ball control, Passing accuracy, First touch', duration: 90 },
        { type: 'Conditie & Cardio', focus: 'Endurance, Sprint work, Recovery', duration: 75 },
        { type: 'Tactiek & Spelvorm', focus: 'Positioning, Team play, Match situations', duration: 90 }
      ];
      
      const startDate = new Date(customSchema.startDate);
      const endDate = new Date(customSchema.endDate);
      const dayToNumber = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
      
      let currentDate = new Date(startDate);
      let sessionCount = 0;
      
      while (currentDate <= endDate) {
        const dayName = Object.keys(dayToNumber).find(key => dayToNumber[key as keyof typeof dayToNumber] === currentDate.getDay());
        
        if (dayName && customSchema.selectedDays.includes(dayName)) {
          const weekNumber = Math.floor(sessionCount / customSchema.selectedDays.length) + 1;
          
          // Lokale training functie voor ICS met periodisering
          const getICSTraining = (dayName: string, weekNumber: number) => {
            // Check of we in een vakantieperiode zitten
            const isInactivePeriod = (sessionDate: Date) => {
              const inactivePeriods = customSchema.inactivePeriods.map(period => ({
                start: new Date(period.start),
                end: new Date(period.end)
              }));
              
              return inactivePeriods.some(period => 
                sessionDate >= period.start && sessionDate <= period.end
              );
            };
            
            // Tel actieve training weken en reset na elke inactivatieperiode naar EDT
            const getActiveWeekNumber = (weekNumber: number, sessionDate: Date) => {
              let activeWeeks = 0;
              let lastActiveWeek = 0;
              const currentDate = new Date(startDate);
              
              // Tel weken en reset na elke vakantieperiode
              for (let w = 1; w <= weekNumber; w++) {
                const weekDate = addDays(currentDate, (w - 1) * 7);
                
                if (!isInactivePeriod(weekDate)) {
                  // Check of vorige week inactief was
                  const prevWeekDate = addDays(currentDate, (w - 2) * 7);
                  const wasPreviousInactive = w > 1 && isInactivePeriod(prevWeekDate);
                  
                  if (wasPreviousInactive) {
                    // Reset naar week 1 na vakantie (start met EDT)
                    activeWeeks = 1;
                  } else {
                    activeWeeks++;
                  }
                  lastActiveWeek = activeWeeks;
                }
              }
              
              // Als geen actieve weken, start met week 1 (EDT)
              return lastActiveWeek === 0 ? 1 : lastActiveWeek;
            };
            
            // 4-weken cyclus: EDT → IDT → EIT → HERSTEL (reset naar EDT na vakantie)
            const getPeriodPhase = (week: number, sessionDate: Date) => {
              if (isInactivePeriod(sessionDate)) {
                return 'INACTIVATIE (Vakantieperiode)';
              }
              
              const activeWeek = getActiveWeekNumber(week, sessionDate);
              const cycleWeek = ((activeWeek - 1) % 4) + 1;
              
              switch(cycleWeek) {
                case 1: return 'EDT (Extensieve Duurmethode)';
                case 2: return 'IDT (Intensieve Duurmethode)';
                case 3: return 'EIT (Extensieve Intervaltraining)';
                case 4: return 'HERSTEL (Actief Herstel)';
                default: return 'EDT (Extensieve Duurmethode)';
              }
            };
            
            const sessionDate = addDays(startDate, sessionCount);
            const periodPhase = getPeriodPhase(weekNumber, sessionDate);
            
            if (dayName === 'saturday') {
              return { 
                type: 'WEDSTRIJD', 
                focus: ['Competitie voetbal', 'Match performance', `Periodisering: ${periodPhase}`], 
                duration: 90 
              };
            }
            if (dayName === 'monday') {
              return { 
                type: `CONDITIE - ${periodPhase} (Week ${weekNumber})`, 
                focus: [
                  `PERIODISERING: ${periodPhase}`,
                  `Opwarming: 13min opwarmingsoefeningen + dynamische stretching`,
                  `Blessurepreventie: 7min blessurepreventieve oefeningen`,
                  `Voetbalconditioneel: 10min volgens periodisering met HIIT principes (${70 + Math.floor(weekNumber/8) * 5}% HRmax)`,
                  `Kracht: 10min HIIT - ${getPeriodPhase(weekNumber, sessionDate).includes('EDT') ? 'BENEN focus (squats, lunges)' : getPeriodPhase(weekNumber, sessionDate).includes('IDT') ? 'CORE focus (planks, mountain climbers)' : getPeriodPhase(weekNumber, sessionDate).includes('EIT') ? 'ARMEN focus (push-ups, burpees)' : 'HERSTEL (lichte mobiliteit)'}`,
                  `Voetbaltactisch/technisch: 45min volgens thema`,
                  `Cool-down: 5min`,
                  `SUPERCOMPENSATIE: ${36 + Math.floor(weekNumber/6) * 6} uur`
                ], 
                duration: 75 + Math.floor(weekNumber/6) * 5
              };
            }
            if (dayName === 'wednesday') {
              return { 
                type: `SNELHEID - ${periodPhase} (Week ${weekNumber})`, 
                focus: [
                  `PERIODISERING: ${periodPhase}`,
                  `Opwarming: 13min opwarmingsoefeningen + dynamische stretching`,
                  `Blessurepreventie: 7min blessurepreventieve oefeningen`,
                  `Voetbalconditioneel: 10min opbouwend volgens periodisering met HIIT principes`,
                  `Kracht: 10min HIIT - ${getPeriodPhase(weekNumber, sessionDate).includes('EDT') ? 'BENEN focus (squats, lunges)' : getPeriodPhase(weekNumber, sessionDate).includes('IDT') ? 'CORE focus (planks, mountain climbers)' : getPeriodPhase(weekNumber, sessionDate).includes('EIT') ? 'ARMEN focus (push-ups, burpees)' : 'HERSTEL (lichte mobiliteit)'}`,
                  `Voetbaltactisch/technisch: 45min volgens thema`,
                  `Cool-down: 5min`,
                  `SUPERCOMPENSATIE: ${36 + Math.floor(weekNumber/4) * 6} uur`
                ], 
                duration: 75 + Math.floor(weekNumber/6) * 5
              };
            }
            return { 
              type: `TRAINING - ${periodPhase}`, 
              focus: [`PERIODISERING: ${periodPhase}`, 'Standaard training aangepast aan fase'], 
              duration: 75 
            };
          };
          
          const trainingType = getICSTraining(dayName, weekNumber);
          
          const trainingStart = new Date(currentDate);
          trainingStart.setHours(18, 0, 0, 0);
          const trainingEnd = new Date(trainingStart);
          trainingEnd.setMinutes(trainingStart.getMinutes() + trainingType.duration);
          
          // Create detailed description with all parameters
          const blockNumber = Math.ceil(weekNumber / 6);
          const blockNames = ['1A', '1B', '2A', '2B', '3A', '3B', '3C', '4'];
          const blockName = blockNames[blockNumber - 1] || '4';
          
          let detailedDescription = `WEEK ${weekNumber} - BLOK ${blockName}\\n\\n`;
          detailedDescription += `DUUR: ${trainingType.duration} minuten\\n\\n`;
          detailedDescription += `TRAININGSDETAILS:\\n`;
          
          trainingType.focus.forEach((focus: string, index: number) => {
            detailedDescription += `${index + 1}. ${focus}\\n`;
          });
          
          detailedDescription += `\\nLOCATIE: VVC Brasschaat Training Ground\\n`;
          detailedDescription += `MATERIAAL: Stopwatch, kegels, hartslagmeter\\n`;
          
          icsContent += `BEGIN:VEVENT
UID:custom-week${weekNumber}-${sessionCount}-${currentDate.toISOString().split('T')[0]}@vvcbrasschaat.training
DTSTART:${formatICSDate(trainingStart)}
DTEND:${formatICSDate(trainingEnd)}
SUMMARY:${trainingType.type} (Week ${weekNumber})
DESCRIPTION:${detailedDescription}
LOCATION:VVC Brasschaat Training Ground
CATEGORIES:Training,Week${weekNumber},Blok${blockName},${dayName}
STATUS:CONFIRMED
TRANSP:OPAQUE
PRIORITY:5
BEGIN:VALARM
ACTION:DISPLAY
DESCRIPTION:Training reminder - ${trainingType.type}
TRIGGER:-PT30M
END:VALARM
END:VEVENT

`;
          sessionCount++;
        }
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
      
      // Add match days to calendar
      customSchema.matchDays.forEach((match, index) => {
        if (match.date && match.opponent && match.location) {
          const matchDate = new Date(match.date);
          const matchStart = new Date(matchDate);
          const matchTime = match.time || '15:00';
          const [hours, minutes] = matchTime.split(':').map(Number);
          matchStart.setHours(hours, minutes, 0, 0);
          const matchEnd = new Date(matchStart);
          matchEnd.setHours(matchStart.getHours() + 2, matchStart.getMinutes(), 0, 0); // 2 hours duration
          
          const isHomeMatch = match.location.toLowerCase().includes('thuis');
          const matchLocation = isHomeMatch ? 'VVC Brasschaat - Thuiswedstrijd' : `${match.location} - Uitwedstrijd`;
          
          let matchDescription = `WEDSTRIJD TEGEN ${match.opponent.toUpperCase()}\\n\\n`;
          matchDescription += `LOCATIE: ${matchLocation}\\n`;
          matchDescription += `TYPE: ${isHomeMatch ? 'Thuiswedstrijd' : 'Uitwedstrijd'}\\n`;
          matchDescription += `AANVANGSTIJD: ${matchTime}\\n`;
          matchDescription += `VERWACHTE DUUR: 2 uur (inclusief warming-up en cool-down)\\n\\n`;
          matchDescription += `VOORBEREIDING:\\n`;
          matchDescription += `- Aanwezig zijn 60 minuten voor wedstrijd\\n`;
          matchDescription += `- Warming-up start 45 minuten voor aanvang\\n`;
          matchDescription += `- Tactische bespreking 30 minuten voor aanvang\\n`;
          
          icsContent += `BEGIN:VEVENT
UID:match-${index}-${match.date}@vvcbrasschaat.match
DTSTART:${formatICSDate(matchStart)}
DTEND:${formatICSDate(matchEnd)}
SUMMARY:⚽ WEDSTRIJD vs ${match.opponent}
DESCRIPTION:${matchDescription}
LOCATION:${matchLocation}
CATEGORIES:Wedstrijd,${isHomeMatch ? 'Thuis' : 'Uit'},${match.opponent}
STATUS:CONFIRMED
TRANSP:OPAQUE
PRIORITY:9
BEGIN:VALARM
ACTION:DISPLAY
DESCRIPTION:Wedstrijd reminder - ${match.opponent}
TRIGGER:-PT2H
END:VALARM
BEGIN:VALARM
ACTION:DISPLAY
DESCRIPTION:Vertrek naar wedstrijd - ${match.opponent}
TRIGGER:-PT90M
END:VALARM
END:VEVENT

`;
        }
      });
      
      icsContent += 'END:VCALENDAR';
      
      const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${customSchema.name || 'Custom-Schema'}-${customSchema.startDate}.ics`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      console.log("Custom ICS generated successfully!");
    } catch (error) {
      console.error("Error generating custom ICS:", error);
      alert("Er was een fout bij het genereren van de kalender. Probeer opnieuw.");
    }
  };

  // Simple export functions
  const generatePDF = () => {
    alert("PDF functie tijdelijk uitgeschakeld - app klaar voor deployment!");
  };

  const generateExcelFile = () => {
    alert("Excel functie tijdelijk uitgeschakeld - app klaar voor deployment!");
  };

  const generateCalendarFile = () => {
    alert("Kalender functie tijdelijk uitgeschakeld - app klaar voor deployment!");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{t('trainingPrograms')}</h1>
          <p className="text-muted-foreground">
            {t('comprehensiveTraining')}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={!calendarMode ? "default" : "outline"}
            onClick={() => setCalendarMode(false)}
            className="flex items-center gap-2"
          >
            <Calendar className="h-4 w-4" />
            Schema Modus
          </Button>
          <Button
            variant={calendarMode ? "default" : "outline"}
            onClick={() => setCalendarMode(true)}
            className="flex items-center gap-2"
          >
            <CalendarDays className="h-4 w-4" />
            Kalender Modus
          </Button>
        </div>
      </div>

      {calendarMode ? (
        /* Calendar Mode Interface */
        <div className="space-y-6">
          {/* Calendar Header */}
          <Card className="border-purple-200 bg-purple-50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-purple-800">📅 Kalender Planning</CardTitle>
                  <CardDescription className="text-purple-600">
                    Beheer individuele trainingen en wedstrijden per dag
                  </CardDescription>
                </div>
                <Button
                  onClick={() => {
                    setEventForm({
                      type: 'training',
                      date: '',
                      time: '18:00',
                      title: '',
                      description: '',
                      location: '',
                      opponent: ''
                    });
                    setEditingEvent(null);
                    setEventFormOpen(true);
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Nieuw Event
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {/* Mini Calendar */}
              <div className="grid grid-cols-7 gap-2 text-center">
                {['Zo', 'Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za'].map(day => (
                  <div key={day} className="font-semibold text-purple-700 p-2">
                    {day}
                  </div>
                ))}
                {generateCalendarDays().map((day, index) => (
                  <div
                    key={index}
                    className={`p-2 min-h-[80px] border rounded-lg cursor-pointer transition-colors ${
                      day.isCurrentMonth 
                        ? day.isToday 
                          ? 'bg-purple-200 border-purple-400' 
                          : 'bg-white border-gray-200 hover:bg-purple-50'
                        : 'bg-gray-50 text-gray-400'
                    }`}
                    onClick={() => {
                      if (day.isCurrentMonth) {
                        setSelectedDate(day.dateStr);
                        setEventForm({...eventForm, date: day.dateStr});
                        setEventFormOpen(true);
                      }
                    }}
                  >
                    <div className="font-medium">{day.date.getDate()}</div>
                    <div className="space-y-1 mt-1">
                      {day.dayEvents.map((event, eventIndex) => (
                        <div
                          key={eventIndex}
                          className={`text-xs p-1 rounded truncate ${
                            event.type === 'training' 
                              ? 'bg-blue-100 text-blue-800' 
                              : 'bg-green-100 text-green-800'
                          }`}
                          onClick={(e) => {
                            e.stopPropagation();
                            editCalendarEvent(event);
                          }}
                          title={`${event.time} - ${event.title}`}
                        >
                          {event.type === 'training' ? '🏃' : '⚽'} {event.time}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Events List */}
              {calendarEvents.length > 0 && (
                <div className="mt-6">
                  <h4 className="font-semibold text-purple-800 mb-3">Alle Events</h4>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {calendarEvents
                      .sort((a, b) => new Date(a.date + ' ' + a.time).getTime() - new Date(b.date + ' ' + b.time).getTime())
                      .map((event) => (
                        <div key={event.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                          <div className="flex items-center gap-3">
                            <span className="text-lg">
                              {event.type === 'training' ? '🏃' : '⚽'}
                            </span>
                            <div>
                              <div className="font-medium">{event.title}</div>
                              <div className="text-sm text-gray-600">
                                {new Date(event.date).toLocaleDateString('nl-NL')} om {event.time}
                                {event.location && ` - ${event.location}`}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => editCalendarEvent(event)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteCalendarEvent(event.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* Export Buttons - Using Calendar Events */}
              <div className="mt-6 flex gap-3">
                <Button
                  onClick={() => {
                    // Generate PDF from calendar events
                    alert("PDF export van kalender events wordt gegenereerd...");
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Export PDF
                </Button>
                <Button
                  onClick={() => {
                    // Generate Excel from calendar events
                    alert("Excel export van kalender events wordt gegenereerd...");
                  }}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export Excel
                </Button>
                <Button
                  onClick={() => {
                    // Generate ICS from calendar events
                    alert("Kalender export van kalender events wordt gegenereerd...");
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Export Kalender
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Event Form Modal */}
          <Dialog open={eventFormOpen} onOpenChange={setEventFormOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingEvent ? 'Event Bewerken' : 'Nieuw Event Toevoegen'}
                </DialogTitle>
                <DialogDescription>
                  Voeg een training of wedstrijd toe aan de kalender
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Type Event</Label>
                  <Select value={eventForm.type} onValueChange={(value: 'training' | 'match') => setEventForm({...eventForm, type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="training">🏃 Training</SelectItem>
                      <SelectItem value="match">⚽ Wedstrijd</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Datum</Label>
                    <Input
                      type="date"
                      value={eventForm.date}
                      onChange={(e) => setEventForm({...eventForm, date: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Tijd</Label>
                    <Input
                      type="time"
                      value={eventForm.time}
                      onChange={(e) => setEventForm({...eventForm, time: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <Label>Titel</Label>
                  <Input
                    placeholder={eventForm.type === 'training' ? 'bijv. Conditietraining' : 'bijv. vs FC Vooruit'}
                    value={eventForm.title}
                    onChange={(e) => setEventForm({...eventForm, title: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Locatie</Label>
                  <Input
                    placeholder="bijv. VVC Brasschaat of Thuis/Uit"
                    value={eventForm.location}
                    onChange={(e) => setEventForm({...eventForm, location: e.target.value})}
                  />
                </div>
                {eventForm.type === 'match' && (
                  <div>
                    <Label>Tegenstander</Label>
                    <Input
                      placeholder="bijv. FC Vooruit"
                      value={eventForm.opponent}
                      onChange={(e) => setEventForm({...eventForm, opponent: e.target.value})}
                    />
                  </div>
                )}
                <div>
                  <Label>Beschrijving</Label>
                  <Input
                    placeholder="Extra details over het event..."
                    value={eventForm.description}
                    onChange={(e) => setEventForm({...eventForm, description: e.target.value})}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEventFormOpen(false)}>
                  Annuleren
                </Button>
                <Button onClick={editingEvent ? updateCalendarEvent : addCalendarEvent}>
                  {editingEvent ? 'Bijwerken' : 'Toevoegen'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      ) : (
        /* Schema Mode Interface */
        <div className="space-y-6">

      {/* 8-Week Pre-Season Program Card */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-green-800">{t('weekPreSeason')}</CardTitle>
              <CardDescription className="text-green-600">
                {t('periodizationPlan')}
              </CardDescription>
            </div>
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              {t('featuredProgram')}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {/* Program Date Selection */}
          <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-semibold text-blue-800 mb-3">Programma Planning</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate" className="text-sm font-medium text-blue-700">
                  Startdatum (Maandag)
                </Label>
                <Input
                  id="startDate"
                  type="date"
                  value={programDates.startDate}
                  onChange={(e) => setProgramDates({...programDates, startDate: e.target.value})}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="endDate" className="text-sm font-medium text-blue-700">
                  Einddatum (ongeveer)
                </Label>
                <Input
                  id="endDate"
                  type="date"
                  value={programDates.endDate}
                  onChange={(e) => setProgramDates({...programDates, endDate: e.target.value})}
                  className="mt-1"
                />
              </div>
              <div className="md:col-span-2">
                <Label className="text-sm font-medium text-blue-700 mb-2 block">
                  Selecteer Trainingsdagen
                </Label>
                <div className="grid grid-cols-7 gap-2">
                  {[
                    { key: "monday", label: "Ma", name: "Maandag" },
                    { key: "tuesday", label: "Di", name: "Dinsdag" },
                    { key: "wednesday", label: "Wo", name: "Woensdag" },
                    { key: "thursday", label: "Do", name: "Donderdag" },
                    { key: "friday", label: "Vr", name: "Vrijdag" },
                    { key: "saturday", label: "Za", name: "Zaterdag" },
                    { key: "sunday", label: "Zo", name: "Zondag" }
                  ].map((day) => (
                    <button
                      key={day.key}
                      type="button"
                      onClick={() => {
                        if (selectedDays.includes(day.key)) {
                          setSelectedDays(selectedDays.filter(d => d !== day.key));
                        } else {
                          setSelectedDays([...selectedDays, day.key]);
                        }
                      }}
                      className={`p-2 text-xs rounded-md border transition-colors ${
                        selectedDays.includes(day.key)
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-blue-600 border-blue-300 hover:bg-blue-50'
                      }`}
                      title={day.name}
                    >
                      {day.label}
                    </button>
                  ))}
                </div>
              </div>
              {programDates.startDate && programDates.endDate && (
                <div className="md:col-span-2 text-sm text-blue-700 font-medium bg-blue-100 p-2 rounded">
                  📅 Programma duur: {Math.ceil((new Date(programDates.endDate).getTime() - new Date(programDates.startDate).getTime()) / (1000 * 60 * 60 * 24 * 7))} weken
                  <br />
                  🗓️ Trainingen: {selectedDays.length} dagen per week ({selectedDays.map(day => 
                    ({ monday: "Ma", tuesday: "Di", wednesday: "Wo", thursday: "Do", friday: "Vr", saturday: "Za", sunday: "Zo" }[day])
                  ).join(", ")})
                </div>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-800 mb-3">Program Overview</h4>
              <ul className="text-green-700 space-y-2">
                <li>• 3 training sessions per week</li>
                <li>• Progressive periodization principles</li>
                <li>• HIIT & cardiovascular conditioning</li>
                <li>• Strength & power development</li>
                <li>• Comprehensive injury prevention</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-green-800 mb-3">Training Focus</h4>
              <ul className="text-green-700 space-y-2">
                <li>• Foundation building (Weeks 1-2)</li>
                <li>• Volume increase (Weeks 3-5)</li>
                <li>• Peak intensity (Weeks 6-8)</li>
                <li>• Match-specific preparation</li>
                <li>• Performance optimization</li>
              </ul>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <div className="flex flex-col sm:flex-row gap-3 w-full">
            <Button className="flex-1 bg-green-600 hover:bg-green-700" onClick={generateProgramPDF}>
              <FileDown className="h-4 w-4 mr-2" />
              {t('downloadPdf')}
            </Button>
            <Button className="flex-1 bg-blue-600 hover:bg-blue-700" onClick={generateExcelFile}>
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              {t('downloadExcel')}
            </Button>
            <Button className="flex-1 bg-purple-600 hover:bg-purple-700" onClick={generateCalendarFile}>
              <Calendar className="h-4 w-4 mr-2" />
              {t('addToCalendar')}
            </Button>
          </div>
        </CardFooter>
      </Card>

      {/* Custom Training Schema Builder */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-blue-800">Nieuw Trainingsschema Maken</CardTitle>
              <CardDescription className="text-blue-600">
                Maak je eigen aangepaste trainingsschema met jouw datums en dagen
              </CardDescription>
            </div>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              Custom Schema
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Schema Settings */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="customStartDate" className="text-sm font-medium text-blue-700">
                  Begindatum
                </Label>
                <Input
                  id="customStartDate"
                  type="date"
                  value={customSchema.startDate}
                  onChange={(e) => setCustomSchema({...customSchema, startDate: e.target.value})}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="customEndDate" className="text-sm font-medium text-blue-700">
                  Einddatum
                </Label>
                <Input
                  id="customEndDate"
                  type="date"
                  value={customSchema.endDate}
                  onChange={(e) => setCustomSchema({...customSchema, endDate: e.target.value})}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-blue-700">
                  Schema Naam
                </Label>
                <Input
                  type="text"
                  placeholder="bijv. Winter Training"
                  value={customSchema.name}
                  onChange={(e) => setCustomSchema({...customSchema, name: e.target.value})}
                  className="mt-1"
                />
              </div>
            </div>

            {/* Day Selection */}
            <div>
              <Label className="text-sm font-medium text-blue-700 mb-2 block">
                Selecteer Trainingsdagen
              </Label>
              <div className="grid grid-cols-7 gap-2">
                {[
                  { key: "monday", label: "Ma", name: "Maandag" },
                  { key: "tuesday", label: "Di", name: "Dinsdag" },
                  { key: "wednesday", label: "Wo", name: "Woensdag" },
                  { key: "thursday", label: "Do", name: "Donderdag" },
                  { key: "friday", label: "Vr", name: "Vrijdag" },
                  { key: "saturday", label: "Za", name: "Zaterdag" },
                  { key: "sunday", label: "Zo", name: "Zondag" }
                ].map((day) => (
                  <button
                    key={day.key}
                    type="button"
                    onClick={() => {
                      if (customSchema.selectedDays.includes(day.key)) {
                        setCustomSchema({
                          ...customSchema,
                          selectedDays: customSchema.selectedDays.filter(d => d !== day.key)
                        });
                      } else {
                        setCustomSchema({
                          ...customSchema,
                          selectedDays: [...customSchema.selectedDays, day.key]
                        });
                      }
                    }}
                    className={`p-2 text-xs rounded-md border transition-colors ${
                      customSchema.selectedDays.includes(day.key)
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-blue-600 border-blue-300 hover:bg-blue-50'
                    }`}
                    title={day.name}
                  >
                    {day.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Match Days Configuration */}
            <div>
              <Label className="text-sm font-medium text-blue-700 mb-3 block">
                ⚽ Wedstrijddagen
              </Label>
              <div className="space-y-3">
                {customSchema.matchDays.map((match, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <Input
                      type="date"
                      value={match.date}
                      onChange={(e) => {
                        const newMatches = [...customSchema.matchDays];
                        newMatches[index].date = e.target.value;
                        setCustomSchema({...customSchema, matchDays: newMatches});
                      }}
                      className="w-40"
                    />
                    <Input
                      placeholder="Tegenstander"
                      value={match.opponent}
                      onChange={(e) => {
                        const newMatches = [...customSchema.matchDays];
                        newMatches[index].opponent = e.target.value;
                        setCustomSchema({...customSchema, matchDays: newMatches});
                      }}
                      className="flex-1"
                    />
                    <Input
                      placeholder="Locatie (Thuis/Uit)"
                      value={match.location}
                      onChange={(e) => {
                        const newMatches = [...customSchema.matchDays];
                        newMatches[index].location = e.target.value;
                        setCustomSchema({...customSchema, matchDays: newMatches});
                      }}
                      className="w-32"
                    />
                    <Input
                      type="time"
                      value={match.time || '15:00'}
                      onChange={(e) => {
                        const newMatches = [...customSchema.matchDays];
                        newMatches[index].time = e.target.value;
                        setCustomSchema({...customSchema, matchDays: newMatches});
                      }}
                      className="w-24"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const newMatches = customSchema.matchDays.filter((_, i) => i !== index);
                        setCustomSchema({...customSchema, matchDays: newMatches});
                      }}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      ✕
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const newMatches = [...customSchema.matchDays, {
                      date: '',
                      opponent: '',
                      location: '',
                      time: '15:00'
                    }];
                    setCustomSchema({...customSchema, matchDays: newMatches});
                  }}
                  className="text-green-600 hover:text-green-700 hover:bg-green-50 border-green-300"
                >
                  + Wedstrijd Toevoegen
                </Button>
              </div>
            </div>

            {/* Custom Trainings Configuration */}
            <div>
              <Label className="text-sm font-medium text-purple-700 mb-3 block">
                🏃 Extra Trainingen
              </Label>
              <div className="space-y-3">
                {customSchema.customTrainings.map((training, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <Input
                      type="date"
                      value={training.date}
                      onChange={(e) => {
                        const newTrainings = [...customSchema.customTrainings];
                        newTrainings[index].date = e.target.value;
                        setCustomSchema({...customSchema, customTrainings: newTrainings});
                      }}
                      className="w-40"
                    />
                    <Select
                      value={training.type}
                      onValueChange={(value) => {
                        const newTrainings = [...customSchema.customTrainings];
                        newTrainings[index].type = value;
                        setCustomSchema({...customSchema, customTrainings: newTrainings});
                      }}
                    >
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Type training" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CONDITIE">Conditietraining</SelectItem>
                        <SelectItem value="SNELHEID">Snelheidstraining</SelectItem>
                        <SelectItem value="TACTIEK">Tactiektraining</SelectItem>
                        <SelectItem value="TECHNIEK">Techniektraining</SelectItem>
                        <SelectItem value="HERSTEL">Hersteltraining</SelectItem>
                        <SelectItem value="CUSTOM">Aangepast</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      placeholder="Beschrijving"
                      value={training.description}
                      onChange={(e) => {
                        const newTrainings = [...customSchema.customTrainings];
                        newTrainings[index].description = e.target.value;
                        setCustomSchema({...customSchema, customTrainings: newTrainings});
                      }}
                      className="flex-1"
                    />
                    <Input
                      type="time"
                      value={training.time}
                      onChange={(e) => {
                        const newTrainings = [...customSchema.customTrainings];
                        newTrainings[index].time = e.target.value;
                        setCustomSchema({...customSchema, customTrainings: newTrainings});
                      }}
                      className="w-28"
                    />
                    <Input
                      type="number"
                      placeholder="Min"
                      value={training.duration}
                      onChange={(e) => {
                        const newTrainings = [...customSchema.customTrainings];
                        newTrainings[index].duration = parseInt(e.target.value) || 90;
                        setCustomSchema({...customSchema, customTrainings: newTrainings});
                      }}
                      className="w-20"
                      min="30"
                      max="180"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const newTrainings = customSchema.customTrainings.filter((_, i) => i !== index);
                        setCustomSchema({...customSchema, customTrainings: newTrainings});
                      }}
                      className="text-red-600 hover:text-red-700"
                    >
                      ✕
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const newTrainings = [...customSchema.customTrainings, {
                      date: '',
                      type: 'CONDITIE',
                      description: '',
                      time: '19:30',
                      duration: 90
                    }];
                    setCustomSchema({...customSchema, customTrainings: newTrainings});
                  }}
                  className="text-purple-600 hover:text-purple-700 hover:bg-purple-50 border-purple-300"
                >
                  + Training Toevoegen
                </Button>
              </div>
            </div>

            {/* Inactive Periods Configuration */}
            <div>
              <Label className="text-sm font-medium text-blue-700 mb-3 block">
                🏖️ Inactivatieperiodes (Vakantie/Rust)
              </Label>
              <div className="space-y-3">
                {customSchema.inactivePeriods.map((period, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                    <Input
                      placeholder="Naam periode"
                      value={period.name}
                      onChange={(e) => {
                        const newPeriods = [...customSchema.inactivePeriods];
                        newPeriods[index].name = e.target.value;
                        setCustomSchema({...customSchema, inactivePeriods: newPeriods});
                      }}
                      className="flex-1"
                    />
                    <Input
                      type="date"
                      value={period.start}
                      onChange={(e) => {
                        const newPeriods = [...customSchema.inactivePeriods];
                        newPeriods[index].start = e.target.value;
                        setCustomSchema({...customSchema, inactivePeriods: newPeriods});
                      }}
                      className="w-32"
                    />
                    <span className="text-orange-600 text-sm">tot</span>
                    <Input
                      type="date"
                      value={period.end}
                      onChange={(e) => {
                        const newPeriods = [...customSchema.inactivePeriods];
                        newPeriods[index].end = e.target.value;
                        setCustomSchema({...customSchema, inactivePeriods: newPeriods});
                      }}
                      className="w-32"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const newPeriods = customSchema.inactivePeriods.filter((_, i) => i !== index);
                        setCustomSchema({...customSchema, inactivePeriods: newPeriods});
                      }}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      ✕
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const newPeriods = [...customSchema.inactivePeriods, {
                      start: '',
                      end: '',
                      name: 'Nieuwe periode'
                    }];
                    setCustomSchema({...customSchema, inactivePeriods: newPeriods});
                  }}
                  className="text-orange-600 hover:text-orange-700 hover:bg-orange-50 border-orange-300"
                >
                  + Periode Toevoegen
                </Button>
              </div>
            </div>

            {/* Schema Summary */}
            {customSchema.startDate && customSchema.endDate && customSchema.selectedDays.length > 0 && (
              <div className="text-sm text-blue-700 font-medium bg-blue-100 p-3 rounded">
                📅 Schema duur: {Math.ceil((new Date(customSchema.endDate).getTime() - new Date(customSchema.startDate).getTime()) / (1000 * 60 * 60 * 24))} dagen
                <br />
                🗓️ Trainingen: {customSchema.selectedDays.length} dagen per week ({customSchema.selectedDays.map(day => 
                  ({ monday: "Ma", tuesday: "Di", wednesday: "Wo", thursday: "Do", friday: "Vr", saturday: "Za", sunday: "Zo" }[day])
                ).join(", ")})
                <br />
                📋 Totaal trainingen: ~{Math.ceil((new Date(customSchema.endDate).getTime() - new Date(customSchema.startDate).getTime()) / (1000 * 60 * 60 * 24 * 7)) * customSchema.selectedDays.length} sessies
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <div className="flex flex-col sm:flex-row gap-3 w-full">
            <Button 
              className="flex-1 bg-blue-600 hover:bg-blue-700" 
              onClick={generateCustomSchemaPDF}
              disabled={!customSchema.startDate || !customSchema.endDate || customSchema.selectedDays.length === 0}
            >
              <FileDown className="h-4 w-4 mr-2" />
              Download Custom PDF
            </Button>
            <Button 
              className="flex-1 bg-green-600 hover:bg-green-700" 
              onClick={generateCustomSchemaExcel}
              disabled={!customSchema.startDate || !customSchema.endDate || customSchema.selectedDays.length === 0}
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Download Custom Excel
            </Button>
            <Button 
              className="flex-1 bg-purple-600 hover:bg-purple-700" 
              onClick={generateCustomSchemaICS}
              disabled={!customSchema.startDate || !customSchema.endDate || customSchema.selectedDays.length === 0}
            >
              <Calendar className="h-4 w-4 mr-2" />
              Download Custom Kalender
            </Button>
          </div>
        </CardFooter>
      </Card>
        </div>
      )}
    </div>
  );
};

export default TrainingProgramsPage;