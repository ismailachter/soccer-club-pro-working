import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Calendar, Clock, Target, Users, MapPin, Star, Plus, Edit, Trash2, Eye } from "lucide-react";

interface ModernTrainingSession {
  id: string;
  week: number;
  session: number;
  date: string;
  time: string;
  duration: number;
  focusArea: string;
  location: string;
  ageGroup: string;
  assignedElements: string[];
  intensity: 'low' | 'medium' | 'high';
  weather: 'indoor' | 'outdoor';
  notes: string;
}

interface CalendarProps {
  sessions: ModernTrainingSession[];
  onSessionClick: (session: ModernTrainingSession) => void;
}

export default function ModernCalendar({ sessions, onSessionClick }: CalendarProps) {
  const [selectedWeek, setSelectedWeek] = useState(1);
  const [viewMode, setViewMode] = useState<'week' | 'month' | 'timeline'>('week');
  const [selectedSession, setSelectedSession] = useState<ModernTrainingSession | null>(null);

  // Get unique weeks from sessions
  const weeks = Array.from(new Set(sessions.map(s => s.week))).sort((a, b) => a - b);
  
  // Filter sessions for selected week
  const weekSessions = sessions.filter(s => s.week === selectedWeek);

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getFocusAreaIcon = (focusArea: string) => {
    if (focusArea.includes('BASICS')) return '⚽';
    if (focusArea.includes('TEAMTACTICS')) return '🎯';
    if (focusArea.includes('MENTAAL')) return '🧠';
    if (focusArea.includes('FYSIEK')) return '💪';
    return '🏃';
  };

  return (
    <div className="space-y-6">
      {/* Modern Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-8 rounded-2xl shadow-xl">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold mb-2">Trainingskalender</h1>
            <p className="text-blue-100">Professionele trainingsplanning en -beheer</p>
          </div>
          <div className="flex gap-3">
            <Button 
              variant={viewMode === 'week' ? 'secondary' : 'outline'} 
              onClick={() => setViewMode('week')}
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              Week Overzicht
            </Button>
            <Button 
              variant={viewMode === 'timeline' ? 'secondary' : 'outline'} 
              onClick={() => setViewMode('timeline')}
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              Tijdlijn
            </Button>
          </div>
        </div>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-4 mt-6">
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-2xl font-bold">{sessions.length}</div>
            <div className="text-sm text-blue-100">Totaal Trainingen</div>
          </div>
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-2xl font-bold">{weeks.length}</div>
            <div className="text-sm text-blue-100">Weken Gepland</div>
          </div>
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-2xl font-bold">{sessions.reduce((acc, s) => acc + s.duration, 0)}</div>
            <div className="text-sm text-blue-100">Totaal Minuten</div>
          </div>
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-2xl font-bold">{sessions.filter(s => s.assignedElements.length > 0).length}</div>
            <div className="text-sm text-blue-100">Met IADATABANK</div>
          </div>
        </div>
      </div>

      {/* Week Navigation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Week Navigatie
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 flex-wrap">
            {weeks.map(week => (
              <Button
                key={week}
                variant={selectedWeek === week ? 'default' : 'outline'}
                onClick={() => setSelectedWeek(week)}
                className={`${selectedWeek === week ? 'bg-blue-600' : ''}`}
              >
                Week {week}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Week View */}
      {viewMode === 'week' && (
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Week {selectedWeek} Trainingen</CardTitle>
              <CardDescription>
                {weekSessions.length} trainingen gepland deze week
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {weekSessions.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Geen trainingen gepland voor week {selectedWeek}</p>
                  </div>
                ) : (
                  weekSessions.map(session => (
                    <div
                      key={session.id}
                      className="group bg-gradient-to-r from-white to-blue-50 border-2 border-blue-200 rounded-xl p-6 hover:shadow-lg transition-all duration-300 cursor-pointer hover:scale-[1.02]"
                      onClick={() => {
                        setSelectedSession(session);
                        onSessionClick(session);
                      }}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="text-3xl">{getFocusAreaIcon(session.focusArea)}</div>
                            <div>
                              <h3 className="text-xl font-semibold text-gray-800">
                                Training {session.session}
                              </h3>
                              <p className="text-blue-600 font-medium">{session.date}</p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 mb-4">
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-blue-500" />
                              <span className="text-sm">{session.time} • {session.duration} min</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4 text-green-500" />
                              <span className="text-sm">{session.location}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Target className="h-4 w-4 text-purple-500" />
                              <span className="text-sm">{session.focusArea}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4 text-orange-500" />
                              <span className="text-sm">{session.ageGroup}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex flex-col items-end gap-2">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getIntensityColor(session.intensity)}`}>
                            {session.intensity.toUpperCase()} INTENSITEIT
                          </span>
                          {session.assignedElements.length > 0 && (
                            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                              ✅ {session.assignedElements.length} IADATABANK elementen
                            </span>
                          )}
                          <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs group-hover:bg-blue-200 transition-colors">
                            Klik voor details →
                          </span>
                        </div>
                      </div>
                      
                      {/* IADATABANK Elements Preview */}
                      {session.assignedElements.length > 0 && (
                        <div className="mt-4 pt-4 border-t border-blue-200">
                          <p className="text-xs font-medium text-gray-600 mb-2">
                            🎯 IADATABANK Elementen:
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {session.assignedElements.slice(0, 3).map((element, i) => (
                              <span key={i} className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs border">
                                {element}
                              </span>
                            ))}
                            {session.assignedElements.length > 3 && (
                              <span className="px-2 py-1 bg-gray-200 text-gray-700 rounded text-xs border">
                                +{session.assignedElements.length - 3} meer...
                              </span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Timeline View */}
      {viewMode === 'timeline' && (
        <Card>
          <CardHeader>
            <CardTitle>Trainings Tijdlijn</CardTitle>
            <CardDescription>Chronologisch overzicht van alle trainingen</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sessions.map((session, index) => (
                <div key={session.id} className="flex items-center gap-4">
                  <div className="flex-shrink-0 w-24 text-center">
                    <div className="text-sm font-medium text-blue-600">Week {session.week}</div>
                    <div className="text-xs text-gray-500">{session.date}</div>
                  </div>
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    {session.session}
                  </div>
                  <div className="flex-1 bg-white border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                       onClick={() => {
                         setSelectedSession(session);
                         onSessionClick(session);
                       }}>
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-medium">{session.focusArea}</h4>
                        <p className="text-sm text-gray-500">{session.duration} min • {session.location}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${getIntensityColor(session.intensity)}`}>
                          {session.intensity}
                        </span>
                        {session.assignedElements.length > 0 && (
                          <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                            {session.assignedElements.length} elementen
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Session Detail Dialog */}
      <Dialog open={!!selectedSession} onOpenChange={() => setSelectedSession(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedSession && getFocusAreaIcon(selectedSession.focusArea)}
              Training Details - Week {selectedSession?.week}
            </DialogTitle>
          </DialogHeader>
          {selectedSession && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Datum & Tijd</label>
                  <p className="text-lg">{selectedSession.date} om {selectedSession.time}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Duur</label>
                  <p className="text-lg">{selectedSession.duration} minuten</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Locatie</label>
                  <p className="text-lg">{selectedSession.location}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Intensiteit</label>
                  <span className={`inline-block px-3 py-1 rounded-full text-sm ${getIntensityColor(selectedSession.intensity)}`}>
                    {selectedSession.intensity.toUpperCase()}
                  </span>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-600">Focus Gebied</label>
                <p className="text-lg">{selectedSession.focusArea}</p>
              </div>
              
              {selectedSession.assignedElements.length > 0 && (
                <div>
                  <label className="text-sm font-medium text-gray-600">IADATABANK Elementen</label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedSession.assignedElements.map((element, i) => (
                      <span key={i} className="px-3 py-1 bg-blue-100 text-blue-800 rounded border">
                        {element}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedSession.notes && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Notities</label>
                  <p className="text-gray-800 bg-gray-50 p-3 rounded">{selectedSession.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}