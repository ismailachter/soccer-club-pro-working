import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Mail, Phone, Eye, Edit, MoreHorizontal, Plus, Award, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Coach } from "@/types";
import { AvatarUpload } from "@/components/ui/avatar-upload";

export default function Coaches() {
  const [isAddCoachOpen, setIsAddCoachOpen] = useState(false);
  const [viewCoach, setViewCoach] = useState<Coach | null>(null);
  
  // Fetch coaches data
  const { data: coaches, isLoading, error } = useQuery<Coach[]>({
    queryKey: ['/api/coaches'],
  });

  // Define columns for data table
  const columns = [
    {
      header: "Name",
      accessorKey: "user",
      cell: (coach: Coach) => (
        <div className="flex items-center">
          <div className="h-10 w-10 flex-shrink-0 rounded-full bg-secondary-200">
            {coach.user?.profileImage && (
              <img 
                src={coach.user.profileImage} 
                alt={`${coach.user?.firstName} ${coach.user?.lastName}`}
                className="h-full w-full rounded-full object-cover"
              />
            )}
          </div>
          <div className="ml-4">
            <div className="font-medium text-foreground">
              {coach.user?.firstName} {coach.user?.lastName}
            </div>
            <div className="text-muted-foreground">{coach.specialization || ''}</div>
          </div>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Contact",
      accessorKey: "user.email",
      cell: (coach: Coach) => (
        <div>
          <div className="flex items-center text-foreground">
            <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
            {coach.user?.email}
          </div>
          {coach.user?.phone && (
            <div className="flex items-center text-foreground mt-1">
              <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
              {coach.user.phone}
            </div>
          )}
        </div>
      ),
      sortable: true,
    },
    {
      header: "Qualifications",
      accessorKey: "qualifications",
      cell: (coach: Coach) => coach.qualifications || 'N/A',
      sortable: true,
    },
    {
      header: "Experience",
      accessorKey: "experience",
      cell: (coach: Coach) => coach.experience || 'N/A',
      sortable: true,
    },
    {
      header: "Assigned Teams",
      accessorKey: "teams",
      cell: (coach: Coach) => {
        // In a real implementation, we would fetch teams assigned to this coach
        // For now, return a placeholder
        return (
          <div className="flex flex-wrap gap-1">
            {coach.user?.id === 1 && (
              <Badge variant="outline">U14 Lions</Badge>
            )}
            {coach.user?.id === 2 && (
              <Badge variant="outline">U16 Eagles</Badge>
            )}
            {coach.user?.id === 3 && (
              <Badge variant="outline">U12 Tigers</Badge>
            )}
            {coach.user?.id === 4 && (
              <Badge variant="outline">U10 Panthers</Badge>
            )}
            {coach.user?.id === undefined && (
              <span className="text-muted-foreground">No teams assigned</span>
            )}
          </div>
        );
      },
    },
    {
      header: "Actions",
      accessorKey: "id",
      cell: (coach: Coach) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => setViewCoach(coach)}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  if (isLoading) {
    return <div className="p-8 text-center">Loading coaches...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading coaches.</div>;
  }

  return (
    <div className="py-6">
      <div className="flex items-center gap-3 mb-4">
        <Link href="/">
          <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 hover:bg-gray-100">
            <ArrowLeft size={18} />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Trainers</h1>
      </div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Coaches Management</h2>
        <Dialog open={isAddCoachOpen} onOpenChange={setIsAddCoachOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Coach
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Coach</DialogTitle>
              <DialogDescription>
                Enter the coach details below to create a new coach record.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
              <div className="flex flex-col items-center justify-center">
                <AvatarUpload 
                  onUpload={(file) => console.log('File uploaded:', file)}
                  size="lg"
                />
              </div>
              <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" placeholder="First Name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" placeholder="Last Name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="Email" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" placeholder="Phone" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input id="dateOfBirth" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="qualifications">Qualifications</Label>
                  <Input id="qualifications" placeholder="e.g. UEFA B License" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="experience">Experience</Label>
                  <Input id="experience" placeholder="e.g. 5 years" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="specialization">Specialization</Label>
                  <Input id="specialization" placeholder="e.g. Youth development" />
                </div>
                <div className="space-y-2 col-span-full">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea id="bio" placeholder="Brief biography" rows={3} />
                </div>
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsAddCoachOpen(false)}>
                Cancel
              </Button>
              <Button>Save Coach</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Coaches grid view (alternative to table) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {coaches?.slice(0, 3).map((coach) => (
          <Card key={coach.id} className="overflow-hidden">
            <CardContent className="p-5">
              <div className="flex flex-col items-center text-center mb-4">
                <div className="h-24 w-24 rounded-full bg-secondary-200 overflow-hidden mb-4">
                  {coach.user?.profileImage && (
                    <img 
                      src={coach.user.profileImage} 
                      alt={`${coach.user?.firstName} ${coach.user?.lastName}`}
                      className="h-full w-full object-cover"
                    />
                  )}
                </div>
                <h3 className="text-lg font-semibold text-foreground">
                  {coach.user?.firstName} {coach.user?.lastName}
                </h3>
                <p className="text-sm text-primary soccer-text-gradient font-medium">
                  {coach.specialization || 'Coach'}
                </p>
              </div>

              <div className="space-y-2 text-sm mb-4">
                <div className="flex items-center">
                  <Award className="h-4 w-4 text-muted-foreground mr-2" />
                  <span>{coach.qualifications || 'No qualifications specified'}</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-time-line text-base text-muted-foreground mr-2"></i>
                  <span>{coach.experience || 'Experience not specified'}</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-4 w-4 text-muted-foreground mr-2" />
                  <span>{coach.user?.email}</span>
                </div>
                {coach.user?.phone && (
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 text-muted-foreground mr-2" />
                    <span>{coach.user.phone}</span>
                  </div>
                )}
              </div>
              
              <div className="flex justify-end">
                <Button size="sm" onClick={() => setViewCoach(coach)}>View Profile</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Coaches table */}
      <h3 className="text-lg font-medium mb-4">All Coaches</h3>
      <DataTable
        data={coaches || []}
        columns={columns}
        searchable={true}
        searchKey="user.lastName"
      />

      {/* Coach detail dialog */}
      {viewCoach && (
        <Dialog open={!!viewCoach} onOpenChange={() => setViewCoach(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Coach Profile</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
              <div className="flex flex-col items-center space-y-4">
                <div className="h-32 w-32 rounded-full bg-secondary-200 overflow-hidden">
                  {viewCoach.user?.profileImage && (
                    <img 
                      src={viewCoach.user.profileImage} 
                      alt={`${viewCoach.user?.firstName} ${viewCoach.user?.lastName}`}
                      className="h-full w-full object-cover"
                    />
                  )}
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-semibold">
                    {viewCoach.user?.firstName} {viewCoach.user?.lastName}
                  </h3>
                  <p className="text-primary soccer-text-gradient font-medium">
                    {viewCoach.specialization || 'Coach'}
                  </p>
                </div>
              </div>
              <div className="md:col-span-2 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Email</h4>
                    <p>{viewCoach.user?.email}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Phone</h4>
                    <p>{viewCoach.user?.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Qualifications</h4>
                    <p>{viewCoach.qualifications || 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Experience</h4>
                    <p>{viewCoach.experience || 'N/A'}</p>
                  </div>
                </div>

                {viewCoach.bio && (
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Biography</h4>
                    <p className="text-sm">{viewCoach.bio}</p>
                  </div>
                )}

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Assigned Teams</h4>
                  <div className="flex flex-wrap gap-2">
                    {viewCoach.user?.id === 1 && (
                      <Badge className="bg-primary text-primary-foreground">U14 Lions</Badge>
                    )}
                    {viewCoach.user?.id === 2 && (
                      <Badge className="bg-primary text-primary-foreground">U16 Eagles</Badge>
                    )}
                    {viewCoach.user?.id === 3 && (
                      <Badge className="bg-primary text-primary-foreground">U12 Tigers</Badge>
                    )}
                    {viewCoach.user?.id === 4 && (
                      <Badge className="bg-primary text-primary-foreground">U10 Panthers</Badge>
                    )}
                    {viewCoach.user?.id === undefined && (
                      <span className="text-muted-foreground">No teams assigned</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline">Edit Coach</Button>
              <Button onClick={() => setViewCoach(null)}>Close</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
