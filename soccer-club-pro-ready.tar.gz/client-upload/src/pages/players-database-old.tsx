import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useForm } from "react-hook-form";
import { 
  Users, 
  UserPlus, 
  Edit, 
  Search, 
  Filter, 
  Save,
  Trash2,
  Eye,
  Mail,
  Phone,
  Calendar,
  MapPin,
  Shield,
  Trophy,
  Activity,
  Star,
  Target,
  Clock,
  CheckCircle,
  AlertTriangle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Player {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other';
  position?: 'goalkeeper' | 'defender' | 'midfielder' | 'forward';
  jerseyNumber?: number;
  status: 'active' | 'inactive' | 'injured' | 'suspended';
  teamName: string;
  teamId: number;
  profileImage?: string;
  address?: string;
  nationality?: string;
  joinDate?: string;
  club?: string;
  nickname?: string;
  // Scout functionality
  isScoutCandidate?: boolean;
  scoutNotes?: string;
  scoutPriority?: 'low' | 'medium' | 'high' | 'urgent';
  scoutStatus?: 'prospect' | 'contacted' | 'interested' | 'declined' | 'signed';
  scoutedBy?: number;
  scoutedAt?: string;
}

interface Team {
  id: number;
  name: string;
  ageGroup: string;
}

interface PlayerFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: string;
  position?: string;
  jerseyNumber?: number;
  status: string;
  teamId?: number;
  address?: string;
  nationality?: string;
  nickname?: string;
  // Scout fields
  isScoutCandidate?: boolean;
  scoutNotes?: string;
  scoutPriority?: string;
  scoutStatus?: string;
}

function PlayerCard({ player, onEdit, onView }: { 
  player: Player; 
  onEdit: (player: Player) => void;
  onView: (player: Player) => void;
}) {
  const getPositionColor = (position?: string) => {
    switch (position) {
      case 'goalkeeper': return 'bg-yellow-100 text-yellow-800';
      case 'defender': return 'bg-blue-100 text-blue-800';
      case 'midfielder': return 'bg-green-100 text-green-800';
      case 'forward': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'injured': return 'bg-orange-100 text-orange-800';
      case 'suspended': return 'bg-red-100 text-red-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center space-x-3">
          <Avatar className="h-12 w-12">
            <AvatarImage src={player.profileImage} />
            <AvatarFallback className="bg-blue-100 text-blue-600">
              {player.firstName?.[0]}{player.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <CardTitle className="text-lg">
              {player.firstName} {player.lastName}
              {player.nickname && <span className="text-sm text-gray-500 ml-2">"{player.nickname}"</span>}
            </CardTitle>
            <CardDescription className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              {player.teamName}
              {player.jerseyNumber && <span className="ml-2">#{player.jerseyNumber}</span>}
            </CardDescription>
          </div>
          <div className="flex gap-1">
            <Button variant="outline" size="sm" onClick={() => onView(player)}>
              <Eye className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => onEdit(player)}>
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex flex-wrap gap-2 mb-3">
          <Badge className={getStatusColor(player.status)}>
            {player.status}
          </Badge>
          {player.position && (
            <Badge variant="outline" className={getPositionColor(player.position)}>
              {player.position}
            </Badge>
          )}
          {player.gender && (
            <Badge variant="secondary">
              {player.gender}
            </Badge>
          )}
        </div>
        
        <div className="space-y-2 text-sm text-gray-600">
          {player.email && (
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4" />
              <span className="truncate">{player.email}</span>
            </div>
          )}
          {player.phone && (
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              <span>{player.phone}</span>
            </div>
          )}
          {player.dateOfBirth && (
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>{new Date(player.dateOfBirth).toLocaleDateString('nl-NL')}</span>
            </div>
          )}
          {player.nationality && (
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              <span>{player.nationality}</span>
            </div>
          )}
        </div>
        
        {/* Scout Information */}
        {player.isScoutCandidate && (
          <div className="mt-3 pt-3 border-t border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-500 fill-current" />
                <span className="text-sm font-medium text-yellow-700">Scout Kandidaat</span>
              </div>
              {player.scoutPriority && (
                <Badge variant="outline" className={
                  player.scoutPriority === 'urgent' ? 'border-red-500 text-red-700' :
                  player.scoutPriority === 'high' ? 'border-orange-500 text-orange-700' :
                  player.scoutPriority === 'medium' ? 'border-blue-500 text-blue-700' :
                  'border-gray-500 text-gray-700'
                }>
                  {player.scoutPriority === 'urgent' ? 'Urgent' :
                   player.scoutPriority === 'high' ? 'Hoog' :
                   player.scoutPriority === 'medium' ? 'Middel' : 'Laag'}
                </Badge>
              )}
            </div>
            {player.scoutStatus && (
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Target className="h-3 w-3" />
                <span>Status: {
                  player.scoutStatus === 'prospect' ? 'Prospect' :
                  player.scoutStatus === 'contacted' ? 'Gecontacteerd' :
                  player.scoutStatus === 'interested' ? 'Geïnteresseerd' :
                  player.scoutStatus === 'declined' ? 'Afgewezen' :
                  player.scoutStatus === 'signed' ? 'Getekend' : player.scoutStatus
                }</span>
              </div>
            )}
            {player.scoutNotes && (
              <p className="text-xs text-gray-600 mt-1 line-clamp-2">{player.scoutNotes}</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function PlayerForm({ 
  player, 
  teams, 
  onSubmit, 
  onCancel 
}: { 
  player?: Player; 
  teams: Team[]; 
  onSubmit: (data: PlayerFormData) => void;
  onCancel: () => void;
}) {
  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm<PlayerFormData>({
    defaultValues: player ? {
      firstName: player.firstName,
      lastName: player.lastName,
      email: player.email,
      phone: player.phone || '',
      dateOfBirth: player.dateOfBirth || '',
      gender: player.gender || '',
      position: player.position || '',
      jerseyNumber: player.jerseyNumber || undefined,
      status: player.status,
      teamId: player.teamId,
      address: player.address || '',
      nationality: player.nationality || '',
      nickname: player.nickname || '',
      isScoutCandidate: player.isScoutCandidate || false,
      scoutNotes: player.scoutNotes || '',
      scoutPriority: player.scoutPriority || '',
      scoutStatus: player.scoutStatus || '',
    } : {
      status: 'active',
      isScoutCandidate: false
    }
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="firstName">Voornaam *</Label>
          <Input
            id="firstName"
            {...register("firstName", { required: "Voornaam is verplicht" })}
          />
          {errors.firstName && (
            <p className="text-sm text-red-600 mt-1">{errors.firstName.message}</p>
          )}
        </div>
        
        <div>
          <Label htmlFor="lastName">Achternaam *</Label>
          <Input
            id="lastName"
            {...register("lastName", { required: "Achternaam is verplicht" })}
          />
          {errors.lastName && (
            <p className="text-sm text-red-600 mt-1">{errors.lastName.message}</p>
          )}
        </div>
      </div>

      <div>
        <Label htmlFor="nickname">Bijnaam</Label>
        <Input
          id="nickname"
          placeholder="Optionele bijnaam"
          {...register("nickname")}
        />
      </div>

      <div>
        <Label htmlFor="email">Email *</Label>
        <Input
          id="email"
          type="email"
          {...register("email", { 
            required: "Email is verplicht",
            pattern: {
              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
              message: "Ongeldig email adres"
            }
          })}
        />
        {errors.email && (
          <p className="text-sm text-red-600 mt-1">{errors.email.message}</p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="phone">Telefoon</Label>
          <Input
            id="phone"
            placeholder="+32 xxx xx xx xx"
            {...register("phone")}
          />
        </div>
        
        <div>
          <Label htmlFor="dateOfBirth">Geboortedatum</Label>
          <Input
            id="dateOfBirth"
            type="date"
            {...register("dateOfBirth")}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="gender">Geslacht</Label>
          <Select onValueChange={(value) => setValue("gender", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Selecteer geslacht" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Man</SelectItem>
              <SelectItem value="female">Vrouw</SelectItem>
              <SelectItem value="other">Andere</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="nationality">Nationaliteit</Label>
          <Input
            id="nationality"
            placeholder="België"
            {...register("nationality")}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="address">Adres</Label>
        <Textarea
          id="address"
          placeholder="Straat, nummer, postcode, stad"
          {...register("address")}
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="teamId">Team</Label>
          <Select onValueChange={(value) => setValue("teamId", parseInt(value))}>
            <SelectTrigger>
              <SelectValue placeholder="Selecteer team" />
            </SelectTrigger>
            <SelectContent>
              {teams.map((team) => (
                <SelectItem key={team.id} value={team.id.toString()}>
                  {team.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="position">Positie</Label>
          <Select onValueChange={(value) => setValue("position", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Selecteer positie" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="goalkeeper">Doelman</SelectItem>
              <SelectItem value="defender">Verdediger</SelectItem>
              <SelectItem value="midfielder">Middenvelder</SelectItem>
              <SelectItem value="forward">Aanvaller</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="jerseyNumber">Rugnummer</Label>
          <Input
            id="jerseyNumber"
            type="number"
            min="1"
            max="99"
            {...register("jerseyNumber", { 
              valueAsNumber: true,
              min: { value: 1, message: "Minimum nummer is 1" },
              max: { value: 99, message: "Maximum nummer is 99" }
            })}
          />
          {errors.jerseyNumber && (
            <p className="text-sm text-red-600 mt-1">{errors.jerseyNumber.message}</p>
          )}
        </div>
      </div>

      <div>
        <Label htmlFor="status">Status *</Label>
        <Select onValueChange={(value) => setValue("status", value)}>
          <SelectTrigger>
            <SelectValue placeholder="Selecteer status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="active">Actief</SelectItem>
            <SelectItem value="inactive">Inactief</SelectItem>
            <SelectItem value="injured">Geblesseerd</SelectItem>
            <SelectItem value="suspended">Geschorst</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Scout Information Section */}
      <div className="space-y-4 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
        <div className="flex items-center gap-2">
          <Star className="h-5 w-5 text-yellow-500" />
          <h3 className="font-medium text-yellow-800">Scout Informatie</h3>
        </div>
        
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="isScoutCandidate"
            {...register("isScoutCandidate")}
            className="rounded border-gray-300 text-yellow-600 focus:ring-yellow-500"
          />
          <Label htmlFor="isScoutCandidate" className="text-sm font-medium">
            Markeer als scout kandidaat
          </Label>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="scoutPriority">Scout Prioriteit</Label>
            <Select onValueChange={(value) => setValue("scoutPriority", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecteer prioriteit" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Laag</SelectItem>
                <SelectItem value="medium">Middel</SelectItem>
                <SelectItem value="high">Hoog</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="scoutStatus">Scout Status</Label>
            <Select onValueChange={(value) => setValue("scoutStatus", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecteer status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="prospect">Prospect</SelectItem>
                <SelectItem value="contacted">Gecontacteerd</SelectItem>
                <SelectItem value="interested">Geïnteresseerd</SelectItem>
                <SelectItem value="declined">Afgewezen</SelectItem>
                <SelectItem value="signed">Getekend</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label htmlFor="scoutNotes">Scout Notities</Label>
          <Textarea
            id="scoutNotes"
            placeholder="Notities over de speler, sterke punten, aandachtspunten..."
            {...register("scoutNotes")}
            rows={3}
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Annuleren
        </Button>
        <Button type="submit">
          <Save className="h-4 w-4 mr-2" />
          {player ? 'Bijwerken' : 'Opslaan'}
        </Button>
      </div>
    </form>
  );
}

export default function PlayersDatabase() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterTeam, setFilterTeam] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [viewingPlayer, setViewingPlayer] = useState<Player | null>(null);
  const [isAddingPlayer, setIsAddingPlayer] = useState(false);
  const [showScoutsOnly, setShowScoutsOnly] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch players data
  const { data: playersData = [], isLoading: playersLoading } = useQuery({
    queryKey: ["/api/players/database"],
    retry: false,
  });

  // Fetch teams data
  const { data: teamsData = [] } = useQuery({
    queryKey: ["/api/teams"],
    retry: false,
  });

  // Create player mutation
  const createPlayerMutation = useMutation({
    mutationFn: async (playerData: PlayerFormData) => {
      return await apiRequest("/api/players", {
        method: "POST",
        body: JSON.stringify(playerData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/players/database"] });
      setIsAddingPlayer(false);
      toast({
        title: "Speler toegevoegd",
        description: "De nieuwe speler is succesvol toegevoegd aan de database.",
      });
    },
    onError: (error) => {
      toast({
        title: "Fout bij toevoegen",
        description: "Er is een fout opgetreden bij het toevoegen van de speler.",
        variant: "destructive",
      });
    },
  });

  // Update player mutation
  const updatePlayerMutation = useMutation({
    mutationFn: async (playerData: PlayerFormData & { id: number }) => {
      return await apiRequest(`/api/players/${playerData.id}`, {
        method: "PUT",
        body: JSON.stringify(playerData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/players/database"] });
      setEditingPlayer(null);
      toast({
        title: "Speler bijgewerkt",
        description: "De spelergegevens zijn succesvol bijgewerkt.",
      });
    },
    onError: (error) => {
      toast({
        title: "Fout bij bijwerken",
        description: "Er is een fout opgetreden bij het bijwerken van de speler.",
        variant: "destructive",
      });
    },
  });

  // Delete player mutation
  const deletePlayerMutation = useMutation({
    mutationFn: async (playerId: number) => {
      return await apiRequest(`/api/players/${playerId}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/players/database"] });
      toast({
        title: "Speler verwijderd",
        description: "De speler is succesvol verwijderd uit de database.",
      });
    },
    onError: (error) => {
      toast({
        title: "Fout bij verwijderen",
        description: "Er is een fout opgetreden bij het verwijderen van de speler.",
        variant: "destructive",
      });
    },
  });

  // Filter players based on search and filters
  const filteredPlayers = playersData.filter((player: Player) => {
    const matchesSearch = 
      `${player.firstName} ${player.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      player.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (player.nickname && player.nickname.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesTeam = filterTeam === "all" || player.teamName === filterTeam;
    const matchesStatus = filterStatus === "all" || player.status === filterStatus;
    const matchesScout = !showScoutsOnly || player.isScoutCandidate;
    
    return matchesSearch && matchesTeam && matchesStatus && matchesScout;
  });

  // Get team statistics for scout candidates
  const scoutStats = {
    total: playersData.filter((p: Player) => p.isScoutCandidate).length,
    urgent: playersData.filter((p: Player) => p.isScoutCandidate && p.scoutPriority === 'urgent').length,
    high: playersData.filter((p: Player) => p.isScoutCandidate && p.scoutPriority === 'high').length,
    contacted: playersData.filter((p: Player) => p.isScoutCandidate && p.scoutStatus === 'contacted').length,
    interested: playersData.filter((p: Player) => p.isScoutCandidate && p.scoutStatus === 'interested').length,
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Users className="h-8 w-8 mr-3 text-blue-600" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Spelers Database</h1>
            <p className="text-gray-600">
              {filteredPlayers.length} van {playersData.length} spelers
              {showScoutsOnly && (
                <span className="ml-2 text-yellow-600">
                  • {scoutStats.total} scout kandidaten
                </span>
              )}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {/* Scout Statistics */}
          {scoutStats.total > 0 && (
            <div className="flex items-center gap-2 px-3 py-2 bg-yellow-50 rounded-lg border border-yellow-200">
              <Star className="h-4 w-4 text-yellow-500" />
              <span className="text-sm font-medium text-yellow-700">
                {scoutStats.total} scouts
              </span>
              {scoutStats.urgent > 0 && (
                <Badge variant="outline" className="border-red-500 text-red-700 text-xs">
                  {scoutStats.urgent} urgent
                </Badge>
              )}
            </div>
          )}
          
          <Dialog open={isAddingPlayer} onOpenChange={setIsAddingPlayer}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="h-4 w-4 mr-2" />
                Nieuwe Speler
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Nieuwe Speler Toevoegen</DialogTitle>
                <DialogDescription>
                  Voer de spelergegevens in om een nieuwe speler toe te voegen aan de database.
                </DialogDescription>
              </DialogHeader>
              <PlayerForm 
                teams={teamsData}
                onSubmit={(data) => createPlayerMutation.mutate(data)}
                onCancel={() => setIsAddingPlayer(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-wrap items-center gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-2 flex-1 min-w-64">
          <Search className="h-4 w-4 text-gray-400" />
          <Input
            placeholder="Zoek op naam, email of bijnaam..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
        </div>
        
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-400" />
          <Select value={filterTeam} onValueChange={setFilterTeam}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter op team" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle teams</SelectItem>
              {Array.from(new Set(playersData.map((p: Player) => p.teamName))).map((team) => (
                <SelectItem key={team} value={team}>{team}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center gap-2">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter op status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle statussen</SelectItem>
              <SelectItem value="active">Actief</SelectItem>
              <SelectItem value="inactive">Inactief</SelectItem>
              <SelectItem value="injured">Geblesseerd</SelectItem>
              <SelectItem value="suspended">Geschorst</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Scout Filter Toggle */}
        <Button
          variant={showScoutsOnly ? "default" : "outline"}
          size="sm"
          onClick={() => setShowScoutsOnly(!showScoutsOnly)}
          className={showScoutsOnly ? "bg-yellow-500 hover:bg-yellow-600" : ""}
        >
          <Star className="h-4 w-4 mr-2" />
          Scout Kandidaten
          {scoutStats.total > 0 && (
            <Badge variant="secondary" className="ml-2">
              {scoutStats.total}
            </Badge>
          )}
        </Button>

        <div className="flex items-center gap-1 ml-auto">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('grid')}
          >
            Grid
          </Button>
          <Button
            variant={viewMode === 'table' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('table')}
          >
            Tabel
          </Button>
        </div>
      </div>

      {/* Players Grid/Table */}
      {playersLoading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Spelers worden geladen...</span>
        </div>
      ) : filteredPlayers.length === 0 ? (
        <div className="text-center py-12">
          <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Geen spelers gevonden</h3>
          <p className="text-gray-600 mb-4">
            {playersData.length === 0 
              ? "Er zijn nog geen spelers toegevoegd aan de database."
              : "Geen spelers voldoen aan de huidige filters."
            }
          </p>
          {playersData.length === 0 && (
            <Button onClick={() => setIsAddingPlayer(true)}>
              <UserPlus className="h-4 w-4 mr-2" />
              Eerste Speler Toevoegen
            </Button>
          )}
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredPlayers.map((player: Player) => (
            <PlayerCard
              key={player.id}
              player={player}
              onEdit={setEditingPlayer}
              onView={setViewingPlayer}
            />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Naam</TableHead>
                  <TableHead>Team</TableHead>
                  <TableHead>Positie</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Scout</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead className="text-right">Acties</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPlayers.map((player: Player) => (
                  <TableRow key={player.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={player.profileImage} />
                          <AvatarFallback className="bg-blue-100 text-blue-600 text-xs">
                            {player.firstName?.[0]}{player.lastName?.[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">
                            {player.firstName} {player.lastName}
                          </div>
                          {player.nickname && (
                            <div className="text-sm text-gray-500">"{player.nickname}"</div>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-gray-400" />
                        {player.teamName}
                        {player.jerseyNumber && (
                          <span className="text-sm text-gray-500">#{player.jerseyNumber}</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {player.position && (
                        <Badge variant="outline" className={
                          player.position === 'goalkeeper' ? 'border-yellow-500 text-yellow-700' :
                          player.position === 'defender' ? 'border-blue-500 text-blue-700' :
                          player.position === 'midfielder' ? 'border-green-500 text-green-700' :
                          player.position === 'forward' ? 'border-red-500 text-red-700' :
                          'border-gray-500 text-gray-700'
                        }>
                          {player.position === 'goalkeeper' ? 'Doelman' :
                           player.position === 'defender' ? 'Verdediger' :
                           player.position === 'midfielder' ? 'Middenvelder' :
                           player.position === 'forward' ? 'Aanvaller' : player.position}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={
                        player.status === 'active' ? 'bg-green-100 text-green-800' :
                        player.status === 'injured' ? 'bg-orange-100 text-orange-800' :
                        player.status === 'suspended' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }>
                        {player.status === 'active' ? 'Actief' :
                         player.status === 'injured' ? 'Geblesseerd' :
                         player.status === 'suspended' ? 'Geschorst' :
                         player.status === 'inactive' ? 'Inactief' : player.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {player.isScoutCandidate ? (
                        <div className="flex items-center gap-2">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          {player.scoutPriority && (
                            <Badge variant="outline" size="sm" className={
                              player.scoutPriority === 'urgent' ? 'border-red-500 text-red-700' :
                              player.scoutPriority === 'high' ? 'border-orange-500 text-orange-700' :
                              player.scoutPriority === 'medium' ? 'border-blue-500 text-blue-700' :
                              'border-gray-500 text-gray-700'
                            }>
                              {player.scoutPriority === 'urgent' ? 'Urgent' :
                               player.scoutPriority === 'high' ? 'Hoog' :
                               player.scoutPriority === 'medium' ? 'Middel' : 'Laag'}
                            </Badge>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm">
                        <Mail className="h-3 w-3 text-gray-400" />
                        <span className="truncate max-w-32">{player.email}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setViewingPlayer(player)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setEditingPlayer(player)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
                            <Badge variant="outline" size="sm" className={
                              player.scoutPriority === 'urgent' ? 'border-red-500 text-red-700' :
                              player.scoutPriority === 'high' ? 'border-orange-500 text-orange-700' :
                              player.scoutPriority === 'medium' ? 'border-blue-500 text-blue-700' :
                              'border-gray-500 text-gray-700'
                            }>
                              {player.scoutPriority === 'urgent' ? 'Urgent' :
                               player.scoutPriority === 'high' ? 'Hoog' :
                               player.scoutPriority === 'medium' ? 'Middel' : 'Laag'}
                            </Badge>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm">
                        <Mail className="h-3 w-3 text-gray-400" />
                        <span className="truncate max-w-32">{player.email}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setViewingPlayer(player)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setEditingPlayer(player)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setViewingPlayer(player)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setEditingPlayer(player)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Edit Player Dialog */}
      <Dialog open={!!editingPlayer} onOpenChange={() => setEditingPlayer(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Speler Bewerken</DialogTitle>
            <DialogDescription>
              Bewerk de gegevens van {editingPlayer?.firstName} {editingPlayer?.lastName}.
            </DialogDescription>
          </DialogHeader>
          {editingPlayer && (
            <PlayerForm 
              player={editingPlayer}
              teams={teamsData}
              onSubmit={(data) => updatePlayerMutation.mutate({ ...data, id: editingPlayer.id })}
              onCancel={() => setEditingPlayer(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Player Dialog */}
      <Dialog open={!!viewingPlayer} onOpenChange={() => setViewingPlayer(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              {viewingPlayer?.firstName} {viewingPlayer?.lastName}
              {viewingPlayer?.isScoutCandidate && (
                <Star className="h-4 w-4 text-yellow-500 fill-current" />
              )}
            </DialogTitle>
            <DialogDescription>
              Volledige spelersinformatie en statistieken
            </DialogDescription>
          </DialogHeader>
          {viewingPlayer && (
            <div className="space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">Team</Label>
                  <p className="text-sm">{viewingPlayer.teamName}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Rugnummer</Label>
                  <p className="text-sm">{viewingPlayer.jerseyNumber || '-'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Positie</Label>
                  <p className="text-sm">{viewingPlayer.position || '-'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Status</Label>
                  <p className="text-sm">{viewingPlayer.status}</p>
                </div>
              </div>

              {/* Scout Information */}
              {viewingPlayer.isScoutCandidate && (
                <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex items-center gap-2 mb-3">
                    <Star className="h-5 w-5 text-yellow-500 fill-current" />
                    <h3 className="font-medium text-yellow-800">Scout Informatie</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Prioriteit</Label>
                      <p className="text-sm">{
                        viewingPlayer.scoutPriority === 'urgent' ? 'Urgent' :
                        viewingPlayer.scoutPriority === 'high' ? 'Hoog' :
                        viewingPlayer.scoutPriority === 'medium' ? 'Middel' :
                        viewingPlayer.scoutPriority === 'low' ? 'Laag' : '-'
                      }</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Status</Label>
                      <p className="text-sm">{
                        viewingPlayer.scoutStatus === 'prospect' ? 'Prospect' :
                        viewingPlayer.scoutStatus === 'contacted' ? 'Gecontacteerd' :
                        viewingPlayer.scoutStatus === 'interested' ? 'Geïnteresseerd' :
                        viewingPlayer.scoutStatus === 'declined' ? 'Afgewezen' :
                        viewingPlayer.scoutStatus === 'signed' ? 'Getekend' : '-'
                      }</p>
                    </div>
                  </div>
                  {viewingPlayer.scoutNotes && (
                    <div className="mt-3">
                      <Label className="text-sm font-medium text-gray-500">Notities</Label>
                      <p className="text-sm mt-1">{viewingPlayer.scoutNotes}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Contact Info */}
              <div>
                <h3 className="font-medium mb-3">Contact Informatie</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Email</Label>
                    <p>{viewingPlayer.email}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Telefoon</Label>
                    <p>{viewingPlayer.phone || '-'}</p>
                  </div>
                  <div className="col-span-2">
                    <Label className="text-sm font-medium text-gray-500">Adres</Label>
                    <p>{viewingPlayer.address || '-'}</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-2 pt-4 border-t">
                <Button variant="outline" onClick={() => setViewingPlayer(null)}>
                  Sluiten
                </Button>
                <Button onClick={() => {
                  setEditingPlayer(viewingPlayer);
                  setViewingPlayer(null);
                }}>
                  <Edit className="h-4 w-4 mr-2" />
                  Bewerken
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
} = filterTeam === "all" || player.teamId.toString() === filterTeam;
    const matchesStatus = filterStatus === "all" || player.status === filterStatus;
    
    return matchesSearch && matchesTeam && matchesStatus;
  });

  const handleSubmitPlayer = (data: PlayerFormData) => {
    if (editingPlayer) {
      updatePlayerMutation.mutate({ ...data, id: editingPlayer.id });
    } else {
      createPlayerMutation.mutate(data);
    }
  };

  const playerStats = {
    total: playersData.length,
    active: playersData.filter((p: Player) => p.status === 'active').length,
    injured: playersData.filter((p: Player) => p.status === 'injured').length,
    suspended: playersData.filter((p: Player) => p.status === 'suspended').length,
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Spelers Database</h1>
          <p className="text-gray-600 mt-1">
            Volledig overzicht en beheer van alle spelergegevens
          </p>
        </div>
        <Button onClick={() => setIsAddingPlayer(true)}>
          <UserPlus className="h-4 w-4 mr-2" />
          Nieuwe Speler
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Totaal Spelers</p>
                <p className="text-2xl font-bold">{playerStats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Actief</p>
                <p className="text-2xl font-bold text-green-600">{playerStats.active}</p>
              </div>
              <Activity className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Geblesseerd</p>
                <p className="text-2xl font-bold text-orange-600">{playerStats.injured}</p>
              </div>
              <Trophy className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Geschorst</p>
                <p className="text-2xl font-bold text-red-600">{playerStats.suspended}</p>
              </div>
              <Shield className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Zoek spelers op naam, email of bijnaam..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <Select value={filterTeam} onValueChange={setFilterTeam}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Filter op team" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle teams</SelectItem>
                {teamsData.map((team: Team) => (
                  <SelectItem key={team.id} value={team.id.toString()}>
                    {team.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Filter op status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle statussen</SelectItem>
                <SelectItem value="active">Actief</SelectItem>
                <SelectItem value="inactive">Inactief</SelectItem>
                <SelectItem value="injured">Geblesseerd</SelectItem>
                <SelectItem value="suspended">Geschorst</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                Grid
              </Button>
              <Button
                variant={viewMode === 'table' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('table')}
              >
                Tabel
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results Info */}
      <div className="flex justify-between items-center">
        <p className="text-sm text-gray-600">
          {filteredPlayers.length} van {playersData.length} spelers getoond
        </p>
      </div>

      {/* Players Display */}
      {playersLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPlayers.map((player: Player) => (
            <PlayerCard
              key={player.id}
              player={player}
              onEdit={setEditingPlayer}
              onView={setViewingPlayer}
            />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Naam</TableHead>
                  <TableHead>Team</TableHead>
                  <TableHead>Positie</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Acties</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPlayers.map((player: Player) => (
                  <TableRow key={player.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={player.profileImage} />
                          <AvatarFallback>
                            {player.firstName?.[0]}{player.lastName?.[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">
                            {player.firstName} {player.lastName}
                          </div>
                          {player.nickname && (
                            <div className="text-sm text-gray-500">"{player.nickname}"</div>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{player.teamName}</TableCell>
                    <TableCell>
                      {player.position && (
                        <Badge variant="outline">
                          {player.position}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={
                        player.status === 'active' ? 'bg-green-100 text-green-800' :
                        player.status === 'injured' ? 'bg-orange-100 text-orange-800' :
                        player.status === 'suspended' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }>
                        {player.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {player.email}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setViewingPlayer(player)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEditingPlayer(player)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Add Player Dialog */}
      <Dialog open={isAddingPlayer} onOpenChange={setIsAddingPlayer}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nieuwe Speler Toevoegen</DialogTitle>
            <DialogDescription>
              Vul alle benodigde gegevens in voor de nieuwe speler.
            </DialogDescription>
          </DialogHeader>
          <PlayerForm
            teams={teamsData}
            onSubmit={handleSubmitPlayer}
            onCancel={() => setIsAddingPlayer(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Player Dialog */}
      <Dialog open={!!editingPlayer} onOpenChange={() => setEditingPlayer(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Speler Bewerken</DialogTitle>
            <DialogDescription>
              Wijzig de gegevens van {editingPlayer?.firstName} {editingPlayer?.lastName}.
            </DialogDescription>
          </DialogHeader>
          {editingPlayer && (
            <PlayerForm
              player={editingPlayer}
              teams={teamsData}
              onSubmit={handleSubmitPlayer}
              onCancel={() => setEditingPlayer(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Player Dialog */}
      <Dialog open={!!viewingPlayer} onOpenChange={() => setViewingPlayer(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Speler Details</DialogTitle>
          </DialogHeader>
          {viewingPlayer && (
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={viewingPlayer.profileImage} />
                  <AvatarFallback className="text-2xl">
                    {viewingPlayer.firstName?.[0]}{viewingPlayer.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-2xl font-bold">
                    {viewingPlayer.firstName} {viewingPlayer.lastName}
                  </h3>
                  {viewingPlayer.nickname && (
                    <p className="text-gray-600">"{viewingPlayer.nickname}"</p>
                  )}
                  <div className="flex gap-2 mt-2">
                    <Badge className={
                      viewingPlayer.status === 'active' ? 'bg-green-100 text-green-800' :
                      viewingPlayer.status === 'injured' ? 'bg-orange-100 text-orange-800' :
                      viewingPlayer.status === 'suspended' ? 'bg-red-100 text-red-800' :
                      'bg-gray-100 text-gray-800'
                    }>
                      {viewingPlayer.status}
                    </Badge>
                    {viewingPlayer.position && (
                      <Badge variant="outline">
                        {viewingPlayer.position}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Persoonlijke Gegevens</h4>
                  <div className="space-y-2 text-sm">
                    <div><strong>Email:</strong> {viewingPlayer.email}</div>
                    {viewingPlayer.phone && <div><strong>Telefoon:</strong> {viewingPlayer.phone}</div>}
                    {viewingPlayer.dateOfBirth && (
                      <div><strong>Geboortedatum:</strong> {new Date(viewingPlayer.dateOfBirth).toLocaleDateString('nl-NL')}</div>
                    )}
                    {viewingPlayer.gender && <div><strong>Geslacht:</strong> {viewingPlayer.gender}</div>}
                    {viewingPlayer.nationality && <div><strong>Nationaliteit:</strong> {viewingPlayer.nationality}</div>}
                    {viewingPlayer.address && <div><strong>Adres:</strong> {viewingPlayer.address}</div>}
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Voetbal Gegevens</h4>
                  <div className="space-y-2 text-sm">
                    <div><strong>Team:</strong> {viewingPlayer.teamName}</div>
                    {viewingPlayer.position && <div><strong>Positie:</strong> {viewingPlayer.position}</div>}
                    {viewingPlayer.jerseyNumber && <div><strong>Rugnummer:</strong> #{viewingPlayer.jerseyNumber}</div>}
                    {viewingPlayer.joinDate && (
                      <div><strong>Aangesloten:</strong> {new Date(viewingPlayer.joinDate).toLocaleDateString('nl-NL')}</div>
                    )}
                    {viewingPlayer.club && <div><strong>Club:</strong> {viewingPlayer.club}</div>}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setViewingPlayer(null)}>
                  Sluiten
                </Button>
                <Button onClick={() => {
                  setEditingPlayer(viewingPlayer);
                  setViewingPlayer(null);
                }}>
                  <Edit className="h-4 w-4 mr-2" />
                  Bewerken
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}