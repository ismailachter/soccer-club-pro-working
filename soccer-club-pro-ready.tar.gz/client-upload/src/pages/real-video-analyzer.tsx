import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Play, Video, FileVideo, Zap, Clock, HardDrive } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface VideoFile {
  filename: string;
  path: string;
  size: number;
  sizeGB: string;
  uploadDate: string;
  metadata?: {
    duration: number;
    width: number;
    height: number;
    fps: string;
  };
  frameCount?: number;
  analysisReady?: boolean;
}

interface FrameData {
  filename: string;
  path: string;
  timestamp: string;
}

export default function RealVideoAnalyzer() {
  const [videos, setVideos] = useState<VideoFile[]>([]);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [frames, setFrames] = useState<FrameData[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<string>("");
  const { toast } = useToast();

  useEffect(() => {
    fetchVideoStatus();
  }, []);

  const fetchVideoStatus = async () => {
    try {
      const response = await fetch('/api/video-analysis/status');
      const data = await response.json();
      
      setVideos(data.uploadedVideos || []);
      
      toast({
        title: "Video Status",
        description: `${data.totalVideos} videos found (${data.totalSizeGB}GB total)`,
      });
    } catch (error) {
      console.error('Error fetching video status:', error);
      toast({
        title: "Error",
        description: "Failed to fetch video status",
        variant: "destructive"
      });
    }
  };

  const processVideos = async () => {
    setProcessing(true);
    setProgress(0);
    
    try {
      const response = await fetch('/api/video-analysis/process', {
        method: 'POST'
      });
      const data = await response.json();
      
      setProgress(100);
      
      toast({
        title: "Processing Complete",
        description: `${data.successCount}/${data.processedCount} videos processed successfully`,
      });
      
      // Refresh video status
      await fetchVideoStatus();
      
    } catch (error) {
      console.error('Error processing videos:', error);
      toast({
        title: "Processing Failed",
        description: "Failed to process videos",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };

  const fetchFrames = async (videoName: string) => {
    try {
      const response = await fetch(`/api/video-analysis/frames/${videoName}`);
      const data = await response.json();
      
      setFrames(data.frames || []);
      setSelectedVideo(videoName);
      
      toast({
        title: "Frames Loaded",
        description: `${data.frameCount} frames extracted from ${videoName}`,
      });
    } catch (error) {
      console.error('Error fetching frames:', error);
      toast({
        title: "Error",
        description: "Failed to load frames",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Real Video Analysis System
          </h1>
          <p className="text-lg text-gray-600">
            Authentic frame extraction and video processing
          </p>
        </div>

        {/* Processing Control */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-600" />
              Video Processing Engine
            </CardTitle>
            <CardDescription>
              Extract frames from uploaded match videos for analysis
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Button 
                  onClick={processVideos} 
                  disabled={processing || videos.length === 0}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {processing ? "Processing..." : "Process All Videos"}
                </Button>
                
                <Button 
                  onClick={fetchVideoStatus} 
                  variant="outline"
                >
                  Refresh Status
                </Button>
              </div>
              
              {processing && (
                <div className="space-y-2">
                  <Progress value={progress} className="w-full" />
                  <p className="text-sm text-gray-600">Extracting frames...</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Video Files */}
        <div className="grid gap-6 mb-6">
          {videos.map((video, index) => (
            <Card key={index} className="border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileVideo className="h-5 w-5 text-green-600" />
                    {video.filename}
                  </div>
                  <Badge variant={video.analysisReady ? "default" : "secondary"}>
                    {video.analysisReady ? "Ready" : "Pending"}
                  </Badge>
                </CardTitle>
                <CardDescription>
                  Size: {video.sizeGB}GB • Uploaded: {new Date(video.uploadDate).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <HardDrive className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">File: {video.filename}</span>
                    </div>
                    
                    {video.metadata && (
                      <>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-gray-500" />
                          <span className="text-sm">
                            Duration: {Math.round(video.metadata.duration / 60)} minutes
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Video className="h-4 w-4 text-gray-500" />
                          <span className="text-sm">
                            Resolution: {video.metadata.width}x{video.metadata.height}
                          </span>
                        </div>
                      </>
                    )}
                    
                    {video.frameCount && (
                      <div className="flex items-center gap-2">
                        <Play className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">
                          Frames extracted: {video.frameCount}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-end">
                    {video.analysisReady && (
                      <Button
                        onClick={() => fetchFrames(video.filename.replace(/\.[^/.]+$/, ""))}
                        variant="outline"
                        size="sm"
                      >
                        View Frames
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Frame Display */}
        {frames.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Extracted Frames - {selectedVideo}</CardTitle>
              <CardDescription>
                {frames.length} frames extracted for analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {frames.slice(0, 24).map((frame, index) => (
                  <div key={index} className="relative">
                    <img
                      src={frame.path}
                      alt={`Frame ${frame.timestamp}`}
                      className="w-full h-24 object-cover rounded border hover:border-blue-400 cursor-pointer"
                      onClick={() => window.open(frame.path, '_blank')}
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs p-1 rounded-b">
                      Frame {frame.timestamp}
                    </div>
                  </div>
                ))}
              </div>
              {frames.length > 24 && (
                <p className="text-center text-gray-500 mt-4">
                  Showing first 24 frames of {frames.length} total
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {videos.length === 0 && (
          <Card>
            <CardContent className="text-center py-8">
              <Video className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No video files found</p>
              <p className="text-sm text-gray-500">Upload videos to start analysis</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}