import { useState, useEffect } from 'react';
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, startOfWeek, endOfWeek, isSameDay, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  season: string;
  startDate: string;
  endDate: string;
  trainingDays: string[];
  status: "draft" | "active" | "completed";
}

function CalendarWorking(props: any) {
  const planId = props.params?.planId;
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [currentDate, setCurrentDate] = useState(new Date());

  // Fetch data
  const { data: yearPlans = [], isLoading: isLoadingPlans } = useQuery({ 
    queryKey: ['/api/year-plans']
  });
  
  const { data: sessions = [] } = useQuery({ 
    queryKey: ['/api/year-plans', selectedPlan?.id, 'sessions'], 
    enabled: !!selectedPlan
  });

  // Set initial plan if planId is provided
  useEffect(() => {
    if (planId && yearPlans && Array.isArray(yearPlans) && yearPlans.length > 0) {
      const plan = yearPlans.find((p: any) => p.id === parseInt(planId));
      if (plan) {
        setSelectedPlan(plan);
      }
    }
  }, [planId, yearPlans]);

  // Check if date is available for training
  const isDateAvailable = (date: Date) => {
    if (!selectedPlan || !selectedPlan.startDate || !selectedPlan.endDate) return false;
    
    try {
      const planStart = parseISO(selectedPlan.startDate);
      const planEnd = parseISO(selectedPlan.endDate);
      
      if (date < planStart || date > planEnd) return false;
      
      if (!selectedPlan.trainingDays || !Array.isArray(selectedPlan.trainingDays)) return false;
      
      const dayName = format(date, 'EEEE', { locale: nl });
      const dayMapping: { [key: string]: string } = {
        'maandag': 'Maandag',
        'dinsdag': 'Dinsdag', 
        'woensdag': 'Woensdag',
        'donderdag': 'Donderdag',
        'vrijdag': 'Vrijdag',
        'zaterdag': 'Zaterdag',
        'zondag': 'Zondag'
      };
      
      const dutchDayName = dayMapping[dayName.toLowerCase()];
      return selectedPlan.trainingDays.includes(dutchDayName);
    } catch (error) {
      return false;
    }
  };

  // Get calendar days
  const getCalendarDays = () => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    const startWeek = startOfWeek(start, { weekStartsOn: 1 });
    const endWeek = endOfWeek(end, { weekStartsOn: 1 });
    
    return eachDayOfInterval({ start: startWeek, end: endWeek });
  };

  // Get sessions for a specific date
  const getSessionsForDate = (date: Date) => {
    if (!Array.isArray(sessions)) return [];
    return sessions.filter((session: any) => {
      try {
        return isSameDay(parseISO(session.date), date);
      } catch {
        return false;
      }
    });
  };

  // Export handlers
  const handlePlanExtras = (plan: YearPlan) => {
    toast({
      title: "Plan Extra's",
      description: "Extra activiteiten planner wordt binnenkort beschikbaar.",
    });
  };

  const exportToPDF = async (plan: YearPlan) => {
    try {
      const response = await fetch(`/api/year-plans/${plan.id}/export/pdf`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `jaarplanning-${plan.name.replace(/\s+/g, '-')}.pdf`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        toast({
          title: "PDF Export Succesvol",
          description: "Jaarplanning is geëxporteerd naar PDF.",
        });
      } else {
        throw new Error('Export failed');
      }
    } catch (error) {
      toast({
        title: "Export Fout",
        description: "Er is een fout opgetreden bij het exporteren naar PDF.",
        variant: "destructive",
      });
    }
  };

  const exportToExcel = async (plan: YearPlan) => {
    try {
      const response = await fetch(`/api/year-plans/${plan.id}/export/excel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `jaarplanning-${plan.name.replace(/\s+/g, '-')}.xlsx`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        toast({
          title: "Excel Export Succesvol",
          description: "Jaarplanning is geëxporteerd naar Excel.",
        });
      } else {
        throw new Error('Export failed');
      }
    } catch (error) {
      toast({
        title: "Export Fout",
        description: "Er is een fout opgetreden bij het exporteren naar Excel.",
        variant: "destructive",
      });
    }
  };

  if (isLoadingPlans) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-gray-500 mt-2">Jaarplanningen laden...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {!selectedPlan ? (
          // Plan selection screen
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Selecteer Jaarplanning</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {yearPlans && Array.isArray(yearPlans) && yearPlans.map((plan: YearPlan) => (
                  <Card 
                    key={plan.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedPlan(plan)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold">{plan.name}</h3>
                          <p className="text-sm text-gray-600">{plan.description}</p>
                          <div className="flex space-x-4 mt-2 text-xs text-gray-500">
                            <span>Leeftijd: {plan.ageGroup}</span>
                            <span>Seizoen: {plan.season}</span>
                          </div>
                        </div>
                        <Button size="sm">
                          <Calendar className="h-4 w-4 mr-2" />
                          Kalender
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        ) : (
          // Calendar view
          <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold">{selectedPlan.name}</h1>
                  <p className="text-blue-100">{selectedPlan.ageGroup} • {selectedPlan.season}</p>
                </div>
                <Button 
                  variant="secondary" 
                  onClick={() => setSelectedPlan(null)}
                  className="bg-white/20 hover:bg-white/30 text-white border-white/20"
                >
                  Terug naar Overzicht
                </Button>
              </div>
            </div>

            {/* Calendar */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentDate(subMonths(currentDate, 1))}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  <CardTitle className="text-xl">
                    {format(currentDate, 'MMMM yyyy', { locale: nl })}
                  </CardTitle>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentDate(addMonths(currentDate, 1))}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-6">
                {/* Week headers */}
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map((day) => (
                    <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
                      {day}
                    </div>
                  ))}
                </div>
                
                {/* Calendar grid */}
                <div className="grid grid-cols-7 gap-1">
                  {getCalendarDays().map((day, index) => {
                    const daySessions = getSessionsForDate(day);
                    const isCurrentMonth = day.getMonth() === currentDate.getMonth();
                    const isToday = isSameDay(day, new Date());
                    const isAvailable = isDateAvailable(day);
                    
                    return (
                      <div
                        key={index}
                        className={`
                          min-h-24 border rounded-lg p-2 transition-colors
                          ${!isCurrentMonth ? 'bg-gray-50 text-gray-400' :
                            isAvailable ? 'bg-white hover:bg-green-50 cursor-pointer border-green-200' :
                            'bg-gray-100 text-gray-400 cursor-not-allowed'
                          }
                          ${isToday && isAvailable ? 'border-blue-500 bg-blue-50' : ''}
                          ${isToday && !isAvailable ? 'border-gray-400' : ''}
                        `}
                      >
                        <div className={`text-sm ${isToday ? 'font-bold text-blue-600' : ''}`}>
                          {day.getDate()}
                        </div>
                        
                        {isAvailable && (
                          <div className="space-y-1 mt-1">
                            {daySessions.slice(0, 2).map((session: any) => (
                              <div
                                key={session.id}
                                className="text-xs p-1 rounded truncate bg-blue-100 text-blue-800 border-l-2 border-blue-500"
                              >
                                <div className="font-medium">{session.time || '19:00'}</div>
                                {session.assignedElements && session.assignedElements.length > 0 && (
                                  <div className="text-xs text-blue-600 truncate">
                                    {session.assignedElements.slice(0, 2).join(', ')}
                                  </div>
                                )}
                                {session.focusArea && (
                                  <div className="text-xs text-blue-600 truncate">
                                    {session.focusArea}
                                  </div>
                                )}
                              </div>
                            ))}
                            
                            {daySessions.length > 2 && (
                              <div className="text-xs text-gray-500 p-1">
                                +{daySessions.length - 2} meer
                              </div>
                            )}
                            
                            {daySessions.length === 0 && (
                              <div className="text-xs text-green-600 font-medium p-1">
                                + Training toevoegen
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Export Section */}
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-red-50 hover:bg-red-100 text-red-700 border-red-200"
                        onClick={() => handlePlanExtras(selectedPlan)}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Plan Extra's
                      </Button>
                    </div>
                    <div className="text-center flex-1">
                      <h3 className="text-lg font-semibold text-gray-800">Export Jaarplanning</h3>
                      <p className="text-sm text-gray-600">Download de volledige jaarplanning inclusief alle trainingen</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                        onClick={() => exportToPDF(selectedPlan)}
                      >
                        PDF Export
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                        onClick={() => exportToExcel(selectedPlan)}
                      >
                        Excel Export
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

export default CalendarWorking;