import { useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Shield, Lock, Ban, Gavel, Eye } from 'lucide-react';

export default function TermsOfService() {
  
  useEffect(() => {
    // Additional client-side protection for terms page
    const handleCopy = (e: Event) => {
      e.preventDefault();
      alert('Het kopiëren van deze content is niet toegestaan.');
      return false;
    };

    const handlePrint = (e: Event) => {
      e.preventDefault();
      alert('Het printen van deze pagina is niet toegestaan.');
      return false;
    };

    document.addEventListener('copy', handleCopy);
    document.addEventListener('beforeprint', handlePrint);

    return () => {
      document.removeEventListener('copy', handleCopy);
      document.removeEventListener('beforeprint', handlePrint);
    };
  }, []);

  return (
    <div className="space-y-6 max-w-4xl mx-auto p-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900">Algemene Voorwaarden</h1>
        <Badge variant="destructive" className="text-lg px-4 py-2">
          <Shield className="w-5 h-5 mr-2" />
          Strikt Beveiligd Platform
        </Badge>
        <p className="text-gray-600">Laatst bijgewerkt: 24 juni 2025</p>
      </div>

      {/* Critical Warning */}
      <Card className="border-red-500 bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center text-red-700">
            <AlertTriangle className="w-6 h-6 mr-2" />
            KRITIEKE WAARSCHUWING
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-red-800">
            <p className="font-semibold text-lg">
              HET KOPIËREN, DOWNLOADEN OF EXTRAHEREN VAN CONTENT IS STRIKT VERBODEN
            </p>
            <p>
              Ook als betalende klant heeft u GEEN recht om intellectuele eigendom van Soccer Club Pro te kopiëren. 
              Overtreding leidt tot onmiddellijke beëindiging en juridische stappen.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Section 1: Copy Prohibition */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Ban className="w-6 h-6 mr-2 text-red-600" />
            1. ABSOLUUT VERBOD OP KOPIËREN
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <h4 className="font-semibold text-red-600">VERBODEN ACTIVITEITEN:</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <Ban className="w-4 h-4 mt-0.5 mr-2 text-red-500 flex-shrink-0" />
                  Screenshots of schermopnames maken
                </li>
                <li className="flex items-start">
                  <Ban className="w-4 h-4 mt-0.5 mr-2 text-red-500 flex-shrink-0" />
                  Content kopiëren via copy-paste
                </li>
                <li className="flex items-start">
                  <Ban className="w-4 h-4 mt-0.5 mr-2 text-red-500 flex-shrink-0" />
                  Data downloaden of exporteren (behalve eigen spelers)
                </li>
                <li className="flex items-start">
                  <Ban className="w-4 h-4 mt-0.5 mr-2 text-red-500 flex-shrink-0" />
                  Reverse-engineering van software
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-semibold text-red-600">AUTOMATISCH GEBLOKKEERD:</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <Shield className="w-4 h-4 mt-0.5 mr-2 text-blue-500 flex-shrink-0" />
                  Developer tools en console
                </li>
                <li className="flex items-start">
                  <Shield className="w-4 h-4 mt-0.5 mr-2 text-blue-500 flex-shrink-0" />
                  Right-click context menu
                </li>
                <li className="flex items-start">
                  <Shield className="w-4 h-4 mt-0.5 mr-2 text-blue-500 flex-shrink-0" />
                  Keyboard shortcuts (Ctrl+C, F12, etc.)
                </li>
                <li className="flex items-start">
                  <Shield className="w-4 h-4 mt-0.5 mr-2 text-blue-500 flex-shrink-0" />
                  Geautomatiseerde tools en bots
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Section 2: Intellectual Property */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Lock className="w-6 h-6 mr-2 text-blue-600" />
            2. EIGENDOMSRECHTEN SOCCER CLUB PRO
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <h4 className="font-semibold">Software & Code</h4>
              <ul className="text-sm space-y-1">
                <li>• Volledige applicatie code</li>
                <li>• Database structuren</li>
                <li>• API endpoints</li>
                <li>• Business logic</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">IADATABANK Content</h4>
              <ul className="text-sm space-y-1">
                <li>• 196+ trainingselementen</li>
                <li>• Oefenbeschrijvingen</li>
                <li>• Methodiek en progressies</li>
                <li>• PDF export templates</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Design & UX</h4>
              <ul className="text-sm space-y-1">
                <li>• User interface ontwerp</li>
                <li>• Layout en styling</li>
                <li>• Gebruikerservaring</li>
                <li>• Branding elementen</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Section 3: Allowed Usage */}
      <Card className="border-green-500 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center text-green-700">
            <Shield className="w-6 h-6 mr-2" />
            3. WAT MAG WEL (BEPERKTE RECHTEN)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-green-800">
            <p>Als betalende klant krijgt u ALLEEN deze beperkte rechten:</p>
            <ul className="space-y-2">
              <li className="flex items-start">
                <Shield className="w-4 h-4 mt-0.5 mr-2 text-green-600 flex-shrink-0" />
                Software gebruiken voor eigen clubmanagement
              </li>
              <li className="flex items-start">
                <Shield className="w-4 h-4 mt-0.5 mr-2 text-green-600 flex-shrink-0" />
                Eigen spelersdata exporteren in Excel (ENIGE gratis export)
              </li>
              <li className="flex items-start">
                <Shield className="w-4 h-4 mt-0.5 mr-2 text-green-600 flex-shrink-0" />
                Betaalde export functies gebruiken (PDF, PowerPoint, ICS)
              </li>
              <li className="flex items-start">
                <Shield className="w-4 h-4 mt-0.5 mr-2 text-green-600 flex-shrink-0" />
                Virtuele assistant raadplegen voor ondersteuning
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Section 4: Security Monitoring */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Eye className="w-6 h-6 mr-2 text-purple-600" />
            4. ACTIEVE BEVEILIGING & MONITORING
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h4 className="font-semibold mb-2">Real-time Monitoring:</h4>
              <ul className="text-sm space-y-1">
                <li>• Alle gebruikersacties worden gelogd</li>
                <li>• Verdachte activiteit detectie</li>
                <li>• Automatische blokkering van overtredingen</li>
                <li>• IP-adres tracking en rate limiting</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Content Bescherming:</h4>
              <ul className="text-sm space-y-1">
                <li>• Watermarks op alle exports</li>
                <li>• Beveiligde download tokens</li>
                <li>• Tijdelijke toegang tot bestanden</li>
                <li>• Geëncrypteerde data transmissie</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Section 5: Penalties */}
      <Card className="border-red-500 bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center text-red-700">
            <Gavel className="w-6 h-6 mr-2" />
            5. SANCTIES BIJ OVERTREDING
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-red-800">
            <p className="font-semibold">Bij elke vorm van overtreding:</p>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <h4 className="font-semibold mb-2">Onmiddellijke Maatregelen:</h4>
                <ul className="text-sm space-y-1">
                  <li>• Directe beëindiging van toegang</li>
                  <li>• Geen terugbetaling van kosten</li>
                  <li>• Permanente blokkering account</li>
                  <li>• Melding aan andere SaaS providers</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Juridische Gevolgen:</h4>
                <ul className="text-sm space-y-1">
                  <li>• Schadevergoeding vanaf €10.000</li>
                  <li>• Juridische procedure wegens auteursrecht inbreuk</li>
                  <li>• Kosten voor juridische bijstand</li>
                  <li>• Mogelijke strafrechtelijke vervolging</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* VVC Special Status */}
      <Card className="border-blue-500 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-blue-700">6. SPECIALE STATUS VVC BRASSCHAAT</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-blue-800">
            VVC Brasschaat heeft als pilootproject volledige gratis toegang tot alle modules en functionaliteiten. 
            Deze speciale status is persoonlijk en niet overdraagbaar aan andere clubs.
          </p>
        </CardContent>
      </Card>

      {/* Contact */}
      <Card>
        <CardHeader>
          <CardTitle>7. CONTACT EN ONDERSTEUNING</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p>Voor vragen over deze voorwaarden of licenties:</p>
            <p><strong>Email:</strong> <a href="mailto:info@soccerclubpro.com" className="text-blue-600 hover:underline">info@soccerclubpro.com</a></p>
            <p><strong>Website:</strong> <a href="https://soccerclubpro.com" className="text-blue-600 hover:underline">www.soccerclubpro.com</a></p>
          </div>
        </CardContent>
      </Card>

      {/* Final Agreement */}
      <Card className="border-gray-500 bg-gray-50">
        <CardContent className="pt-6">
          <p className="text-center font-semibold text-gray-800">
            Door gebruik te maken van Soccer Club Pro accepteert u deze voorwaarden volledig en onvoorwaardelijk.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}