import { useState } from 'react';
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, Calendar, FileText, Globe, AlertCircle, CheckCircle } from "lucide-react";
import { Link } from 'wouter';

interface ImportResult {
  success: boolean;
  message: string;
  sessionsCreated?: number;
  errors?: string[];
}

export default function CalendarImport() {
  const { toast } = useToast();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [icsUrl, setIcsUrl] = useState('');
  const [csvText, setCsvText] = useState('');
  const [targetPlanId, setTargetPlanId] = useState<string>('');
  const [importResult, setImportResult] = useState<ImportResult | null>(null);

  // Get year plans for target selection
  const { data: yearPlans } = useQuery({
    queryKey: ['/api/year-plans'],
  });

  // File upload import mutation
  const fileImportMutation = useMutation({
    mutationFn: async ({ file, planId }: { file: File, planId: string }) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('planId', planId);
      
      const response = await fetch('/api/calendar/import/file', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Import failed');
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      setImportResult(result);
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      toast({
        title: "Import Succesvol",
        description: `${result.sessionsCreated} trainingen geïmporteerd`,
      });
    },
    onError: (error) => {
      toast({
        title: "Import Mislukt",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // URL import mutation
  const urlImportMutation = useMutation({
    mutationFn: async ({ url, planId }: { url: string, planId: string }) => {
      return apiRequest('/api/calendar/import/url', {
        method: 'POST',
        body: { url, planId },
      });
    },
    onSuccess: (result) => {
      setImportResult(result);
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      toast({
        title: "Import Succesvol",
        description: `${result.sessionsCreated} trainingen geïmporteerd`,
      });
    },
    onError: (error) => {
      toast({
        title: "Import Mislukt",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // CSV text import mutation
  const csvImportMutation = useMutation({
    mutationFn: async ({ csvData, planId }: { csvData: string, planId: string }) => {
      return apiRequest('/api/calendar/import/csv', {
        method: 'POST',
        body: { csvData, planId },
      });
    },
    onSuccess: (result) => {
      setImportResult(result);
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      toast({
        title: "Import Succesvol",
        description: `${result.sessionsCreated} trainingen geïmporteerd`,
      });
    },
    onError: (error) => {
      toast({
        title: "Import Mislukt",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleFileImport = () => {
    if (!selectedFile || !targetPlanId) {
      toast({
        title: "Ontbrekende gegevens",
        description: "Selecteer een bestand en jaarplanning",
        variant: "destructive",
      });
      return;
    }

    fileImportMutation.mutate({ file: selectedFile, planId: targetPlanId });
  };

  const handleUrlImport = () => {
    if (!icsUrl || !targetPlanId) {
      toast({
        title: "Ontbrekende gegevens",
        description: "Voer een URL en jaarplanning in",
        variant: "destructive",
      });
      return;
    }

    urlImportMutation.mutate({ url: icsUrl, planId: targetPlanId });
  };

  const handleCsvImport = () => {
    if (!csvText || !targetPlanId) {
      toast({
        title: "Ontbrekende gegevens",
        description: "Voer CSV data en jaarplanning in",
        variant: "destructive",
      });
      return;
    }

    csvImportMutation.mutate({ csvData: csvText, planId: targetPlanId });
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Kalender Import</h1>
          <p className="text-gray-600 mt-2">Importeer externe kalenders als jaarplanning</p>
        </div>
        <Link href="/jaarplanning">
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Terug naar Jaarplanning
          </Button>
        </Link>
      </div>

      {/* Year Plan Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Doeljaarplanning Selecteren</CardTitle>
          <CardDescription>
            Kies de jaarplanning waar de geïmporteerde trainingen toegevoegd moeten worden
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Select value={targetPlanId} onValueChange={setTargetPlanId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Selecteer een jaarplanning" />
            </SelectTrigger>
            <SelectContent>
              {yearPlans?.map((plan: any) => (
                <SelectItem key={plan.id} value={plan.id.toString()}>
                  {plan.name} ({plan.ageGroup}) - {plan.season}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Import Options */}
      <Tabs defaultValue="file" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="file" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Bestand Upload
          </TabsTrigger>
          <TabsTrigger value="url" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            Online URL
          </TabsTrigger>
          <TabsTrigger value="csv" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            CSV Data
          </TabsTrigger>
        </TabsList>

        {/* File Upload Tab */}
        <TabsContent value="file">
          <Card>
            <CardHeader>
              <CardTitle>Bestand Uploaden</CardTitle>
              <CardDescription>
                Upload een .ics kalenderbestand of Excel/CSV bestand met trainingsdata
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="file-upload">Selecteer Bestand</Label>
                <Input
                  id="file-upload"
                  type="file"
                  accept=".ics,.csv,.xlsx,.xls"
                  onChange={handleFileSelect}
                  className="mt-2"
                />
                {selectedFile && (
                  <p className="text-sm text-gray-600 mt-2">
                    Geselecteerd: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
                  </p>
                )}
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Ondersteunde Formaten:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• <strong>.ics</strong> - iCalendar bestanden (Google Calendar, Outlook, Apple Calendar)</li>
                  <li>• <strong>.csv</strong> - Komma-gescheiden waarden met datum, tijd, beschrijving kolommen</li>
                  <li>• <strong>.xlsx/.xls</strong> - Excel bestanden met trainingsschema</li>
                </ul>
              </div>

              <Button 
                onClick={handleFileImport}
                disabled={!selectedFile || !targetPlanId || fileImportMutation.isPending}
                className="w-full"
              >
                {fileImportMutation.isPending ? "Importeren..." : "Bestand Importeren"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* URL Import Tab */}
        <TabsContent value="url">
          <Card>
            <CardHeader>
              <CardTitle>Online Kalender URL</CardTitle>
              <CardDescription>
                Importeer direct van een online kalender URL (Google Calendar, Office 365, etc.)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="ics-url">Kalender URL</Label>
                <Input
                  id="ics-url"
                  type="url"
                  placeholder="https://calendar.google.com/calendar/ical/.../.../basic.ics"
                  value={icsUrl}
                  onChange={(e) => setIcsUrl(e.target.value)}
                  className="mt-2"
                />
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-medium text-green-900 mb-2">Hoe verkrijg je een kalender URL?</h4>
                <ul className="text-sm text-green-800 space-y-1">
                  <li>• <strong>Google Calendar:</strong> Instellingen → Kalender → Integreren → Openbare URL</li>
                  <li>• <strong>Outlook:</strong> Kalender → Delen → ICS link kopiëren</li>
                  <li>• <strong>Apple iCloud:</strong> Kalender app → Delen → Openbare kalender</li>
                </ul>
              </div>

              <Button 
                onClick={handleUrlImport}
                disabled={!icsUrl || !targetPlanId || urlImportMutation.isPending}
                className="w-full"
              >
                {urlImportMutation.isPending ? "Importeren..." : "URL Importeren"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* CSV Data Tab */}
        <TabsContent value="csv">
          <Card>
            <CardHeader>
              <CardTitle>CSV Data Plakken</CardTitle>
              <CardDescription>
                Plak CSV data direct in het tekstveld (formaat: datum,tijd,beschrijving)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="csv-data">CSV Data</Label>
                <Textarea
                  id="csv-data"
                  placeholder="2025-08-01,19:00,BASICS Training Passing&#10;2025-08-03,19:00,TEAMTACTISCH B+ Opbouwen&#10;2025-08-05,19:00,FYSIEK Conditietraining"
                  value={csvText}
                  onChange={(e) => setCsvText(e.target.value)}
                  className="mt-2 h-32"
                />
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg">
                <h4 className="font-medium text-yellow-900 mb-2">CSV Formaat Voorbeeld:</h4>
                <code className="text-sm text-yellow-800 block">
                  datum,tijd,beschrijving<br/>
                  2025-08-01,19:00,BASICS Training<br/>
                  2025-08-03,20:00,TEAMTACTISCH Opbouwen<br/>
                  2025-08-05,19:30,FYSIEK Conditie
                </code>
              </div>

              <Button 
                onClick={handleCsvImport}
                disabled={!csvText || !targetPlanId || csvImportMutation.isPending}
                className="w-full"
              >
                {csvImportMutation.isPending ? "Importeren..." : "CSV Importeren"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Import Result */}
      {importResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {importResult.success ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-600" />
              )}
              Import Resultaat
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className={`text-sm ${importResult.success ? 'text-green-800' : 'text-red-800'}`}>
              {importResult.message}
            </p>
            {importResult.sessionsCreated && (
              <p className="text-sm text-gray-600 mt-2">
                Trainingen toegevoegd: {importResult.sessionsCreated}
              </p>
            )}
            {importResult.errors && importResult.errors.length > 0 && (
              <div className="mt-4">
                <h4 className="font-medium text-red-900 mb-2">Fouten:</h4>
                <ul className="text-sm text-red-800 space-y-1">
                  {importResult.errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Help Section */}
      <Card>
        <CardHeader>
          <CardTitle>Import Instructies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-2">Voor Trainers:</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Gebruik je bestaande trainingskalender</li>
                <li>• Exporteer als .ics uit je kalender app</li>
                <li>• Upload hier om automatisch te importeren</li>
                <li>• Thema's worden herkend uit de beschrijving</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Voor Clubbeheerders:</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Sync met centrale clubkalender</li>
                <li>• Bulk import van seizoensplanning</li>
                <li>• Automatische IADATABANK koppeling</li>
                <li>• Validatie van trainingsschema</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}