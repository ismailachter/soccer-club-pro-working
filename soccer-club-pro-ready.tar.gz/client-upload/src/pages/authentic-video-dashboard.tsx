import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, Video, FileText, Users } from 'lucide-react';
import { Link } from 'wouter';

export default function AuthenticVideoDashboard() {
  const [frameCount, setFrameCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFrameCount();
    const interval = setInterval(fetchFrameCount, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchFrameCount = async () => {
    try {
      const response = await fetch('/api/frame-count');
      const data = await response.json();
      setFrameCount(data.count || 0);
      setLoading(false);
    } catch (error) {
      console.error('Error:', error);
      setLoading(false);
    }
  };

  const analysisProgress = Math.round((frameCount / 3180) * 100);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <Link href="/">
        <Button variant="outline" className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Terug naar Menu
        </Button>
      </Link>

      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6 rounded-lg">
        <h1 className="text-3xl font-bold mb-2">Authentieke Video Analyse</h1>
        <p className="text-blue-100">Svelta Melsele vs VVC Brasschaat - 25 juni 2025</p>
        <p className="text-blue-200 text-sm">Eindstand: 5-1</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Video Extractie</CardTitle>
            <Video className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{frameCount}</div>
            <p className="text-xs text-muted-foreground">van 3180 frames</p>
            <Progress value={analysisProgress} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">{analysisProgress}% voltooid</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Status</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-semibold text-orange-600">Wacht op Data</div>
            <p className="text-xs text-muted-foreground mt-2">
              Officiële spelerslijsten vereist voor analyse
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vereisten</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div>• Svelta Melsele opstelling</div>
              <div>• VVC Brasschaat opstelling</div>
              <div>• Rugnummers per speler</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Systeem Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Video Upload</span>
              <span className="text-green-600 font-semibold">✓ Voltooid</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Frame Extractie</span>
              <span className="text-blue-600 font-semibold">⏳ {analysisProgress}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Spelersdata</span>
              <span className="text-orange-600 font-semibold">⏳ Wachtend</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Analyse</span>
              <span className="text-gray-400">⏳ Niet gestart</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <h3 className="font-semibold text-yellow-800 mb-2">Alleen Authentieke Data</h3>
        <p className="text-yellow-700 text-sm">
          Dit systeem analyseert uitsluitend echte wedstrijdbeelden. 
          Voor speleranalyse zijn officiële opstelformulieren vereist van beide teams.
        </p>
      </div>
    </div>
  );
}