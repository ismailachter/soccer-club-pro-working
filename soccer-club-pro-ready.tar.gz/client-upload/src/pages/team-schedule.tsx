import { useState, useEffect } from 'react';
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, MapPin, Users, ChevronLeft, ChevronRight, Target, Star } from "lucide-react";
import { format, addWeeks, subWeeks, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';

interface Team {
  id: number;
  name: string;
  ageGroup: string;
  description?: string;
}

interface ScheduleEntry {
  id: number;
  teamId: number;
  yearPlanSessionId?: number;
  date: string;
  startTime: string;
  duration: number;
  eventType: string;
  title: string;
  location: string;
  notes?: string;
  status: string;
}

interface TeamSchedule {
  team: Team;
  yearPlans: any[];
  schedule: ScheduleEntry[];
}

export default function TeamSchedule() {
  const { toast } = useToast();
  const [selectedTeam, setSelectedTeam] = useState<number | null>(null);
  const [currentWeek, setCurrentWeek] = useState(new Date());

  // Get all teams data first
  const { data: teamsOverview, isLoading: teamsLoading } = useQuery({
    queryKey: ['/api/teams-overview'],
    retry: false,
  });

  // Extract teams from the overview data - they're already sorted correctly
  const sortedTeams = teamsOverview?.teams?.map(teamData => teamData.team) || [];

  // Auto-select first team if available (will be Dames IP)
  useEffect(() => {
    if (sortedTeams && sortedTeams.length > 0 && !selectedTeam) {
      setSelectedTeam(sortedTeams[0].id);
    }
  }, [sortedTeams, selectedTeam]);

  // Get selected team's schedule using the correct API route
  const { data: teamSchedule, isLoading: scheduleLoading } = useQuery({
    queryKey: [`/api/teams/${selectedTeam}/schedule`],
    enabled: !!selectedTeam,
    retry: false,
  });

  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 }); // Monday
  const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 }); // Sunday
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });

  const getScheduleForDay = (date: Date) => {
    if (!teamSchedule?.schedule || !Array.isArray(teamSchedule.schedule)) return [];
    const dateStr = format(date, 'yyyy-MM-dd');
    return teamSchedule.schedule.filter(entry => entry && entry.date === dateStr);
  };

  const getEventTypeIcon = (eventType: string) => {
    switch (eventType) {
      case 'training': return <Target className="h-4 w-4" />;
      case 'match': return <Star className="h-4 w-4" />;
      case 'event': return <Calendar className="h-4 w-4" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  const getEventTypeColor = (eventType: string) => {
    switch (eventType) {
      case 'training': return 'bg-blue-500';
      case 'match': return 'bg-red-500';
      case 'event': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Team Schema</h1>
            <p className="text-gray-600">Bekijk trainingen en wedstrijden per week</p>
          </div>
          
          {/* Team Selector */}
          <div className="w-64">
            <Select value={selectedTeam?.toString() || ''} onValueChange={(value) => setSelectedTeam(parseInt(value))}>
              <SelectTrigger>
                <SelectValue placeholder="Selecteer team" />
              </SelectTrigger>
              <SelectContent>
                {sortedTeams && sortedTeams.map((team: Team) => (
                  <SelectItem key={team.id} value={team.id.toString()}>
                    {team.name} ({team.ageGroup})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {selectedTeam && (
          <Card className="border-0 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl flex items-center gap-3">
                    <Users className="h-6 w-6" />
                    {teamSchedule?.team?.name || sortedTeams?.find(t => t.id === selectedTeam)?.name || 'Team Schema'}
                  </CardTitle>
                  <CardDescription className="text-blue-100">
                    {teamSchedule?.team?.ageGroup || sortedTeams?.find(t => t.id === selectedTeam)?.ageGroup || 'Leeftijdsgroep'} • {teamSchedule?.totalSessions || 0} totale sessies
                  </CardDescription>
                </div>
                
                {/* Week Navigation */}
                <div className="flex items-center gap-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentWeek(subWeeks(currentWeek, 1))}
                    className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  <div className="text-center">
                    <div className="text-lg font-semibold">
                      Week {format(currentWeek, 'I', { locale: nl })}
                    </div>
                    <div className="text-sm text-blue-100">
                      {format(weekStart, 'd MMM', { locale: nl })} - {format(weekEnd, 'd MMM yyyy', { locale: nl })}
                    </div>
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentWeek(addWeeks(currentWeek, 1))}
                    className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="p-0">
              {/* Week Grid */}
              <div className="grid grid-cols-7 gap-0">
                {weekDays.map((day, dayIndex) => {
                  const daySchedule = getScheduleForDay(day);
                  const isToday = isSameDay(day, new Date());
                  
                  return (
                    <div
                      key={dayIndex}
                      className={`min-h-[300px] border-r border-b border-gray-200 p-4 ${
                        isToday ? 'bg-blue-50' : 'bg-white'
                      }`}
                    >
                      {/* Day Header */}
                      <div className="text-center mb-4">
                        <div className="text-sm font-medium text-gray-500 uppercase">
                          {format(day, 'EEE', { locale: nl })}
                        </div>
                        <div className={`text-2xl font-bold ${
                          isToday ? 'text-blue-600' : 'text-gray-900'
                        }`}>
                          {format(day, 'd')}
                        </div>
                      </div>
                      
                      {/* Schedule Entries */}
                      <div className="space-y-2">
                        {daySchedule.map((entry) => (
                          <Card
                            key={entry.id}
                            className="p-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                          >
                            <div className="flex items-start gap-2">
                              <div className={`w-3 h-3 rounded-full mt-1 ${getEventTypeColor(entry.eventType)}`} />
                              <div className="flex-1 min-w-0">
                                <div className="font-medium text-sm truncate">
                                  {entry.title}
                                </div>
                                <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                                  <Clock className="h-3 w-3" />
                                  {entry.startTime} - {entry.endTime}
                                </div>
                                {entry.mainTheme && (
                                  <div className="text-xs text-blue-600 font-medium mt-1">
                                    {entry.mainTheme}
                                  </div>
                                )}
                                {entry.fullDetails && (
                                  <div className="text-xs text-gray-600 mt-1 truncate">
                                    {entry.fullDetails}
                                  </div>
                                )}
                                {entry.selectedItems && entry.selectedItems.length > 0 && (
                                  <div className="text-xs text-gray-700 mt-1">
                                    <div className="font-medium">Elementen:</div>
                                    <div className="space-y-1 mt-1">
                                      {entry.selectedItems.slice(0, 3).map((item, idx) => (
                                        <div key={idx} className="bg-gray-50 p-1 rounded text-xs">
                                          {typeof item === 'string' ? item : (item.name || item.elementId || 'Element')}
                                          {typeof item === 'object' && item.theme && (
                                            <span className="text-gray-500 ml-1">({item.theme})</span>
                                          )}
                                        </div>
                                      ))}
                                      {entry.selectedItems.length > 3 && (
                                        <div className="text-xs text-gray-500">
                                          +{entry.selectedItems.length - 3} meer...
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                                {entry.opponent && (
                                  <div className="text-xs text-orange-600 font-medium mt-1">
                                    vs {entry.opponent}
                                  </div>
                                )}
                                {entry.notes && entry.notes !== entry.mainTheme && (
                                  <div className="text-xs text-gray-500 mt-1 italic">
                                    {entry.notes}
                                  </div>
                                )}
                                {entry.location && (
                                  <div className="flex items-center gap-1 text-xs text-gray-500">
                                    <MapPin className="h-3 w-3" />
                                    {entry.location}
                                  </div>
                                )}
                                <Badge
                                  variant="outline"
                                  className="mt-1 text-xs"
                                >
                                  {entry.eventType === 'training' ? 'Training' : 
                                   entry.eventType === 'match' ? 'Wedstrijd' : 'Event'}
                                </Badge>
                              </div>
                            </div>
                          </Card>
                        ))}
                        
                        {(!daySchedule || daySchedule.length === 0) && (
                          <div className="text-center text-gray-400 text-sm py-8">
                            Geen activiteiten
                          </div>
                        )}
                        
                        {/* Debug info */}
                        {selectedTeam && (
                          <div className="text-xs text-gray-400 mt-2">
                            Team ID: {selectedTeam} | Schedule items: {teamSchedule?.schedule?.length || 0}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {!selectedTeam && (
          <Card className="text-center py-12">
            <CardContent>
              <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Selecteer een team
              </h3>
              <p className="text-gray-600">
                Kies een team om hun weekschema te bekijken
              </p>
            </CardContent>
          </Card>
        )}

        {teamsLoading && (
          <Card className="text-center py-12">
            <CardContent>
              <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-gray-600">Teams laden...</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}