import { useState, useEffect } from 'react';
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, Target, Users, MapPin, Star, Plus, Edit, Trash2, Eye, Filter, Search, ChevronLeft, ChevronRight, Zap, Brain, Dumbbell, Trophy, ArrowLeft, Video, Heart, FileText, FileSpreadsheet, Monitor, Upload, Copy, ArrowRight, Presentation, Activity, TrendingUp, BarChart3, Calendar as CalendarIcon, Download, Upload as UploadIcon, Settings, PlayCircle, PauseCircle, CheckCircle2, XCircle } from "lucide-react";
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO, addWeeks, subWeeks, addMonths, startOfMonth, endOfMonth, eachWeekOfInterval, getWeek, startOfYear, endOfYear } from 'date-fns';
import { nl } from 'date-fns/locale';
import { Link } from 'wouter';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface TrainingSession {
  id: number;
  yearPlanId: number;
  date: string;
  themes: string[];
  notes: string;
  duration: number;
  location: string;
  isCompleted: boolean;
  createdAt: string;
}

const statusColors = {
  draft: "bg-gray-100 text-gray-800 border-gray-300",
  active: "bg-green-100 text-green-800 border-green-300",
  completed: "bg-blue-100 text-blue-800 border-blue-300"
};

const statusIcons = {
  draft: Edit,
  active: PlayCircle,
  completed: CheckCircle2
};

export default function UltraModernJaarplanning() {
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'calendar' | 'timeline'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterAgeGroup, setFilterAgeGroup] = useState<string>('all');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());

  // Fetch year plans
  const { data: yearPlans = [], isLoading: plansLoading } = useQuery({
    queryKey: ['/api/year-plans'],
  });

  // Fetch sessions for selected plan
  const { data: sessions = [] } = useQuery({
    queryKey: selectedPlan ? [`/api/year-plans/${selectedPlan.id}/sessions`] : [],
    enabled: !!selectedPlan,
  });

  // Filter plans based on search and filters
  const filteredPlans = yearPlans.filter((plan: YearPlan) => {
    const matchesSearch = plan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         plan.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || plan.status === filterStatus;
    const matchesAgeGroup = filterAgeGroup === 'all' || plan.ageGroup === filterAgeGroup;
    return matchesSearch && matchesStatus && matchesAgeGroup;
  });

  // Get unique age groups for filter
  const ageGroups = [...new Set(yearPlans.map((plan: YearPlan) => plan.ageGroup))];

  // Calculate statistics
  const totalPlans = yearPlans.length;
  const activePlans = yearPlans.filter((p: YearPlan) => p.status === 'active').length;
  const completedPlans = yearPlans.filter((p: YearPlan) => p.status === 'completed').length;
  const totalSessions = sessions.length;
  const completedSessions = sessions.filter((s: TrainingSession) => s.isCompleted).length;

  if (plansLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Modern Header with Glassmorphism */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 opacity-90" />
        <div className="absolute inset-0 bg-black/10" />
        
        <div className="relative px-6 py-12">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-4xl font-bold text-white mb-3">
                  Jaarplanning Dashboard
                </h1>
                <p className="text-blue-100 text-lg">
                  Professionele trainingsplanning voor moderne voetbalclubs
                </p>
              </div>
              
              <div className="flex gap-3">
                <Button 
                  variant="secondary" 
                  className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30"
                  onClick={() => setShowCreateDialog(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Nieuw Plan
                </Button>
                
                <div className="flex bg-white/20 backdrop-blur-sm rounded-lg p-1">
                  {[
                    { mode: 'grid', icon: BarChart3, label: 'Overzicht' },
                    { mode: 'calendar', icon: CalendarIcon, label: 'Kalender' },
                    { mode: 'timeline', icon: Activity, label: 'Tijdlijn' }
                  ].map(({ mode, icon: Icon, label }) => (
                    <Button
                      key={mode}
                      variant={viewMode === mode ? "default" : "ghost"}
                      size="sm"
                      className={viewMode === mode ? 
                        "bg-white text-blue-600 shadow-sm" : 
                        "text-white hover:bg-white/20"
                      }
                      onClick={() => setViewMode(mode as any)}
                    >
                      <Icon className="w-4 h-4 mr-2" />
                      {label}
                    </Button>
                  ))}
                </div>
              </div>
            </div>

            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              {[
                {
                  title: "Totaal Plannen",
                  value: totalPlans,
                  icon: FileText,
                  color: "from-blue-500 to-blue-600",
                  change: "+12%"
                },
                {
                  title: "Actieve Plannen", 
                  value: activePlans,
                  icon: PlayCircle,
                  color: "from-green-500 to-green-600",
                  change: "+8%"
                },
                {
                  title: "Voltooide Plannen",
                  value: completedPlans,
                  icon: CheckCircle2,
                  color: "from-purple-500 to-purple-600", 
                  change: "+15%"
                },
                {
                  title: "Training Sessies",
                  value: selectedPlan ? `${completedSessions}/${totalSessions}` : totalSessions,
                  icon: Target,
                  color: "from-orange-500 to-orange-600",
                  change: "+5%"
                }
              ].map((stat, index) => (
                <Card key={index} className="bg-white/20 backdrop-blur-sm border-white/30 text-white">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-100 text-sm font-medium">{stat.title}</p>
                        <p className="text-3xl font-bold mt-2">{stat.value}</p>
                        <p className="text-green-300 text-xs mt-1">
                          {stat.change} vs vorige maand
                        </p>
                      </div>
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${stat.color} flex items-center justify-center`}>
                        <stat.icon className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Filters and Search */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Zoek plannen..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle statussen</SelectItem>
                  <SelectItem value="draft">Concept</SelectItem>
                  <SelectItem value="active">Actief</SelectItem>
                  <SelectItem value="completed">Voltooid</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterAgeGroup} onValueChange={setFilterAgeGroup}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Leeftijdsgroep" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle groepen</SelectItem>
                  {ageGroups.map((group) => (
                    <SelectItem key={group} value={group}>{group}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Content based on view mode */}
        {viewMode === 'grid' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredPlans.map((plan: YearPlan) => {
              const StatusIcon = statusIcons[plan.status];
              return (
                <Card 
                  key={plan.id} 
                  className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 bg-white border-gray-200 overflow-hidden"
                >
                  <div className="relative">
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className={`${statusColors[plan.status]} shadow-sm`}>
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {plan.status === 'draft' && 'Concept'}
                        {plan.status === 'active' && 'Actief'}
                        {plan.status === 'completed' && 'Voltooid'}
                      </Badge>
                    </div>
                    
                    <div className="h-32 bg-gradient-to-br from-blue-500 to-purple-600 relative overflow-hidden">
                      <div className="absolute inset-0 bg-black/20" />
                      <div className="absolute bottom-4 left-4 text-white">
                        <h3 className="font-bold text-lg">{plan.name}</h3>
                        <p className="text-blue-100 text-sm">{plan.ageGroup}</p>
                      </div>
                    </div>
                  </div>

                  <CardContent className="p-6">
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                      {plan.description}
                    </p>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center text-sm text-gray-600">
                        <Users className="w-4 h-4 mr-2 text-blue-500" />
                        {plan.teamName || 'Geen team toegewezen'}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="w-4 h-4 mr-2 text-green-500" />
                        {plan.season}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="w-4 h-4 mr-2 text-orange-500" />
                        {plan.totalWeeks} weken • {plan.sessionsPerWeek}x/week
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        onClick={() => setSelectedPlan(plan)}
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        Bekijken
                      </Button>
                      <Link href={`/calendar/${plan.id}`}>
                        <Button size="sm" variant="outline">
                          <CalendarIcon className="w-4 h-4" />
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Empty State */}
        {filteredPlans.length === 0 && (
          <div className="text-center py-12">
            <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
              <FileText className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Geen plannen gevonden
            </h3>
            <p className="text-gray-500 mb-6">
              {searchTerm || filterStatus !== 'all' || filterAgeGroup !== 'all' ? 
                'Probeer je filters aan te passen.' : 
                'Maak je eerste jaarplanning aan om te beginnen.'}
            </p>
            <Button onClick={() => setShowCreateDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Eerste Plan Maken
            </Button>
          </div>
        )}
      </div>

      {/* Selected Plan Detail Panel */}
      {selectedPlan && (
        <Dialog open={!!selectedPlan} onOpenChange={() => setSelectedPlan(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    {selectedPlan.name}
                    <Badge className={statusColors[selectedPlan.status]}>
                      {selectedPlan.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-500 font-normal">
                    {selectedPlan.ageGroup} • {selectedPlan.season}
                  </p>
                </div>
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-6">
              {/* Plan Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Beschrijving</Label>
                    <p className="text-sm text-gray-600 mt-1">{selectedPlan.description}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Team</Label>
                    <p className="text-sm text-gray-600 mt-1">{selectedPlan.teamName || 'Niet toegewezen'}</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Periode</Label>
                    <p className="text-sm text-gray-600 mt-1">
                      {format(parseISO(selectedPlan.startDate), 'dd MMM yyyy', { locale: nl })} - {' '}
                      {format(parseISO(selectedPlan.endDate), 'dd MMM yyyy', { locale: nl })}
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Trainingsdagen</Label>
                    <div className="flex gap-1 mt-1">
                      {selectedPlan.trainingDays.map((day) => (
                        <Badge key={day} variant="outline" className="text-xs">
                          {day}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Training Sessions */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Training Sessies ({sessions.length})</h3>
                  <div className="flex gap-2">
                    <Link href={`/calendar/${selectedPlan.id}`}>
                      <Button size="sm" variant="outline">
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        Kalender
                      </Button>
                    </Link>
                    <Button size="sm" variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>

                <div className="max-h-60 overflow-y-auto space-y-2">
                  {sessions.map((session: TrainingSession) => (
                    <div 
                      key={session.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${session.isCompleted ? 'bg-green-500' : 'bg-gray-300'}`} />
                        <div>
                          <p className="font-medium text-sm">
                            {format(parseISO(session.date), 'dd MMM yyyy', { locale: nl })}
                          </p>
                          <p className="text-xs text-gray-500">
                            {session.themes.join(', ') || 'Geen thema\'s'} • {session.duration}min
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {session.location && (
                          <Badge variant="outline" className="text-xs">
                            <MapPin className="w-3 h-3 mr-1" />
                            {session.location}
                          </Badge>
                        )}
                        <Button size="sm" variant="ghost">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}