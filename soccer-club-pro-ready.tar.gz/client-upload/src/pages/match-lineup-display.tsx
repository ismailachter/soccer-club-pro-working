import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BackToMenu } from "@/components/ui/back-to-menu";

export default function MatchLineupDisplay() {
  // VVC BRASSCHAAT A - Complete opstelling uit wedstrijddocument
  const vvcPlayers = [
    { name: "Marjake Van Ammers", position: "GK", number: 1 },
    { name: "Laura Michielsen", position: "Defender", number: 4 },
    { name: "Sien Schepens", position: "Defender", number: 6 },
    { name: "Jorien Dictus", position: "Midfielder", number: 7 },
    { name: "Eline Bultje", position: "Midfielder", number: 8 },
    { name: "Melissa Vinckx", position: "Forward", number: 9 },
    { name: "Arianna De Maeyer", position: "Forward", number: 10 },
    { name: "Julie Luyten", position: "Defender", number: 14 },
    { name: "Emily Van Rooy", position: "Substitute", number: 15 },
    { name: "Ine Denhartinne", position: "Substitute", number: 16 },
    { name: "Louise Creemers", position: "Midfielder", number: 17 },
    { name: "Ginger Brichoven", position: "Substitute", number: 19 },
    { name: "Sophie Van Parys", position: "Defender", number: 21 },
    { name: "Maud Bastiaensen", position: "Defender", number: 22 }
  ];

  // KVKS MELSELE A - Complete opstelling uit wedstrijddocument
  const melseleSpelers = [
    { name: "Joni Billen", position: "GK", number: 71 },
    { name: "Kirsten Van Dassel", position: "Defender", number: 2 },
    { name: "Amber Verlies", position: "Defender", number: 3 },
    { name: "Ana Lucia Claricka", position: "Defender", number: 4 },
    { name: "Femke Verdonck", position: "Substitute", number: 6 },
    { name: "Amelie Stansaert", position: "Substitute", number: 7 },
    { name: "Sandy De Schepper", position: "Midfielder", number: 8 },
    { name: "Emily Maria Coenen", position: "Substitute", number: 9 },
    { name: "Senne Mertens", position: "Midfielder", number: 10 },
    { name: "Jolien De Laet", position: "Forward", number: 11 },
    { name: "Julie Cour", position: "Forward", number: 13 },
    { name: "Anouk Verhiest", position: "Forward", number: 14 },
    { name: "Ellen Van Bockhaven", position: "Midfielder", number: 15 },
    { name: "Sofia Van Royen", position: "Midfielder", number: 17 },
    { name: "Lien Wyndale", position: "Substitute", number: 20 }
  ];

  return (
    <div className="space-y-6 p-6">
      <BackToMenu />
      
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Wedstrijdopstelling</h1>
        <div className="text-6xl font-bold">
          <span className="text-red-600">1</span>
          <span className="text-gray-400 mx-4">-</span>
          <span className="text-blue-600">5</span>
        </div>
        <div className="text-xl">
          <span className="font-semibold">KVKS MELSELE A</span>
          <span className="mx-2">vs</span>
          <span className="font-semibold">VVC BRASSCHAAT A</span>
        </div>
        <Badge variant="secondary" className="text-lg px-4 py-2">
          za 08 maart 2025 - 15:00
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600">VVC BRASSCHAAT A (Winnaar 5-1)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {vvcPlayers.map(player => (
                <div key={player.number} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div>
                    <div className="font-medium">{player.name}</div>
                    <div className="text-sm text-gray-600">{player.position}</div>
                  </div>
                  <Badge variant="outline">#{player.number}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">KVKS MELSELE A</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {melseleSpelers.map(player => (
                <div key={player.number} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                  <div>
                    <div className="font-medium">{player.name}</div>
                    <div className="text-sm text-gray-600">{player.position}</div>
                  </div>
                  <Badge variant="outline">#{player.number}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}