import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  MessageSquare, 
  Send, 
  Users, 
  Bell, 
  Calendar, 
  Mail, 
  Phone, 
  Settings,
  Plus,
  Filter,
  Search,
  Clock,
  CheckCircle,
  AlertCircle,
  UserPlus
} from "lucide-react";

interface Message {
  id: number;
  title: string;
  content: string;
  sender: string;
  recipients: string[];
  type: 'announcement' | 'reminder' | 'update' | 'urgent';
  status: 'draft' | 'sent' | 'scheduled';
  createdAt: string;
  scheduledFor?: string;
  readBy: string[];
}

interface CommunicationStats {
  totalMessages: number;
  sentToday: number;
  pendingMessages: number;
  activeRecipients: number;
}

const CommunicationDashboard = () => {
  const [selectedTab, setSelectedTab] = useState("messages");
  const [newMessage, setNewMessage] = useState({
    title: '',
    content: '',
    type: 'announcement' as const,
    recipients: [] as string[],
    scheduledFor: ''
  });
  const [isCreateMessageOpen, setIsCreateMessageOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock data voor demonstratie
  const mockStats: CommunicationStats = {
    totalMessages: 45,
    sentToday: 8,
    pendingMessages: 3,
    activeRecipients: 127
  };

  const mockMessages: Message[] = [
    {
      id: 1,
      title: "Training Cancelled - Weather Conditions",
      content: "Due to heavy rain, tonight's training session (20:00-21:30) has been cancelled. We'll reschedule for tomorrow.",
      sender: "Ismail Achter",
      recipients: ["Dames IP", "Coaches"],
      type: "urgent",
      status: "sent",
      createdAt: "2025-06-25T14:30:00Z",
      readBy: ["john.doe@example.com", "jane.smith@example.com"]
    },
    {
      id: 2,
      title: "Match Schedule Update",
      content: "Next weekend's match against KVC Borsbeke has been moved to Sunday 15:00 instead of Saturday.",
      sender: "Team Manager",
      recipients: ["Dames Provinciaal", "Parents"],
      type: "announcement",
      status: "sent",
      createdAt: "2025-06-25T10:15:00Z",
      readBy: []
    },
    {
      id: 3,
      title: "Equipment Check Reminder",
      content: "Please bring your training equipment for inspection this Friday. Missing items need to be replaced before next week.",
      sender: "Equipment Manager",
      recipients: ["All Players"],
      type: "reminder",
      status: "scheduled",
      createdAt: "2025-06-25T09:00:00Z",
      scheduledFor: "2025-06-26T18:00:00Z",
      readBy: []
    }
  ];

  const mockRecipientGroups = [
    "All Players",
    "All Coaches", 
    "All Parents",
    "Dames IP",
    "Dames Provinciaal", 
    "MU20",
    "Coordinators",
    "Board Members"
  ];

  const getMessageTypeColor = (type: string) => {
    switch (type) {
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      case 'announcement': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'reminder': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'update': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'scheduled': return <Clock className="h-4 w-4 text-blue-500" />;
      case 'draft': return <AlertCircle className="h-4 w-4 text-orange-500" />;
      default: return null;
    }
  };

  const handleSendMessage = () => {
    console.log('Sending message:', newMessage);
    toast({
      title: "Bericht Verzonden",
      description: `Bericht "${newMessage.title}" is succesvol verzonden.`,
    });
    setIsCreateMessageOpen(false);
    setNewMessage({
      title: '',
      content: '',
      type: 'announcement',
      recipients: [],
      scheduledFor: ''
    });
  };

  const filteredMessages = mockMessages.filter(message => {
    const matchesSearch = message.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'all' || message.type === filterType;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Communication Dashboard</h1>
          <p className="text-muted-foreground">Beheer team communicatie en berichten</p>
        </div>
        <Dialog open={isCreateMessageOpen} onOpenChange={setIsCreateMessageOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Nieuw Bericht
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Nieuw Bericht Maken</DialogTitle>
              <DialogDescription>
                Verstuur berichten naar teams, coaches of ouders
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Titel</Label>
                <Input
                  id="title"
                  value={newMessage.title}
                  onChange={(e) => setNewMessage({...newMessage, title: e.target.value})}
                  placeholder="Voer berichttitel in..."
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Type Bericht</Label>
                  <Select value={newMessage.type} onValueChange={(value: any) => setNewMessage({...newMessage, type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="announcement">Aankondiging</SelectItem>
                      <SelectItem value="reminder">Herinnering</SelectItem>
                      <SelectItem value="update">Update</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="recipients">Ontvangers</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer groep..." />
                    </SelectTrigger>
                    <SelectContent>
                      {mockRecipientGroups.map(group => (
                        <SelectItem key={group} value={group}>{group}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">Bericht</Label>
                <Textarea
                  id="content"
                  value={newMessage.content}
                  onChange={(e) => setNewMessage({...newMessage, content: e.target.value})}
                  placeholder="Voer uw bericht in..."
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="scheduled">Inplannen (optioneel)</Label>
                <Input
                  id="scheduled"
                  type="datetime-local"
                  value={newMessage.scheduledFor}
                  onChange={(e) => setNewMessage({...newMessage, scheduledFor: e.target.value})}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsCreateMessageOpen(false)}>
                  Annuleren
                </Button>
                <Button onClick={handleSendMessage}>
                  <Send className="h-4 w-4 mr-2" />
                  Versturen
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totaal Berichten</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalMessages}</div>
            <p className="text-xs text-muted-foreground">Alle tijd</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vandaag Verzonden</CardTitle>
            <Send className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.sentToday}</div>
            <p className="text-xs text-muted-foreground">+2 vanaf gisteren</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ingepland</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.pendingMessages}</div>
            <p className="text-xs text-muted-foreground">Wachtend op verzending</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Actieve Ontvangers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.activeRecipients}</div>
            <p className="text-xs text-muted-foreground">Spelers, coaches, ouders</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="messages">Berichten</TabsTrigger>
          <TabsTrigger value="groups">Groepen</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="settings">Instellingen</TabsTrigger>
        </TabsList>

        <TabsContent value="messages" className="space-y-4">
          {/* Search and Filter */}
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Zoek berichten..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Types</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
                <SelectItem value="announcement">Aankondigingen</SelectItem>
                <SelectItem value="reminder">Herinneringen</SelectItem>
                <SelectItem value="update">Updates</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Messages List */}
          <div className="space-y-3">
            {filteredMessages.map((message) => (
              <Card key={message.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{message.title}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge className={getMessageTypeColor(message.type)}>
                          {message.type}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          door {message.sender}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          • {new Date(message.createdAt).toLocaleDateString('nl-NL')}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(message.status)}
                      <span className="text-sm text-muted-foreground capitalize">
                        {message.status}
                      </span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-3">{message.content}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        Naar: {message.recipients.join(', ')}
                      </span>
                    </div>
                    {message.status === 'sent' && (
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm text-muted-foreground">
                          {message.readBy.length} gelezen
                        </span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="groups" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Communicatie Groepen</CardTitle>
              <CardDescription>
                Beheer groepen voor gerichte communicatie
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {mockRecipientGroups.map((group) => (
                  <Card key={group} className="border-2">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">{group}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          {Math.floor(Math.random() * 50) + 5} leden
                        </span>
                        <Button variant="outline" size="sm">
                          <Settings className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bericht Templates</CardTitle>
              <CardDescription>
                Vooraf gemaakte berichten voor veelgebruikte situaties
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: "Training Geannuleerd", type: "urgent" },
                  { name: "Match Herinnering", type: "reminder" },
                  { name: "Seizoen Update", type: "announcement" },
                  { name: "Equipment Check", type: "reminder" }
                ].map((template, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <MessageSquare className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{template.name}</p>
                        <p className="text-sm text-muted-foreground">{template.type}</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Gebruiken
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Communicatie Instellingen</CardTitle>
              <CardDescription>
                Configureer notificaties en communicatie voorkeuren
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Email Notificaties</p>
                    <p className="text-sm text-muted-foreground">Ontvang email bij nieuwe berichten</p>
                  </div>
                  <Button variant="outline">Configureren</Button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">SMS Notificaties</p>
                    <p className="text-sm text-muted-foreground">Urgente berichten via SMS</p>
                  </div>
                  <Button variant="outline">Instellen</Button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Automatische Antwoorden</p>
                    <p className="text-sm text-muted-foreground">Standaard reacties configureren</p>
                  </div>
                  <Button variant="outline">Beheren</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CommunicationDashboard;