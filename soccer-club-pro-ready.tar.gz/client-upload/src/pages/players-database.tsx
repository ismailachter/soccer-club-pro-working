import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Search, Edit, Star, Grid, List, Eye, UserPlus, Trash2, Camera, Upload, User, Download, FileText, AlertTriangle, Users, ArrowLeft } from "lucide-react";
import { BackToMenu } from "@/components/ui/back-to-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import type { Player, InsertPlayer } from "@shared/schema";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function PlayersDatabase() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTeam, setSelectedTeam] = useState("all");
  const [selectedPosition, setSelectedPosition] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [viewMode, setViewMode] = useState<"grid" | "table">("grid");
  const [showScoutOnly, setShowScoutOnly] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [viewingPlayer, setViewingPlayer] = useState<Player | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  const [deletingPlayer, setDeletingPlayer] = useState<Player | null>(null);
  const [isDuplicateManagerOpen, setIsDuplicateManagerOpen] = useState(false);
  const [duplicates, setDuplicates] = useState<Array<Array<any>>>([]);
  
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isViewer, canEdit } = useAuth();

  const { data: players = [], isLoading } = useQuery({
    queryKey: ["/api/players"],
  });

  const { data: teams = [] } = useQuery({
    queryKey: ["/api/teams"],
  });

  const filteredPlayers = players.filter((player: any) => {
    const searchLower = searchTerm.toLowerCase();
    const firstName = player.user?.firstName || '';
    const lastName = player.user?.lastName || '';
    const email = player.user?.email || '';
    
    const matchesSearch = 
      firstName.toLowerCase().includes(searchLower) ||
      lastName.toLowerCase().includes(searchLower) ||
      email.toLowerCase().includes(searchLower);
    
    const matchesTeam = selectedTeam === "all" || player.teamId?.toString() === selectedTeam;
    const matchesPosition = selectedPosition === "all" || player.position === selectedPosition;
    const matchesStatus = selectedStatus === "all" || player.status === selectedStatus;
    const matchesScout = !showScoutOnly || (player.user && player.user.isScoutCandidate);
    
    return matchesSearch && matchesTeam && matchesPosition && matchesStatus && matchesScout;
  });

  const scoutCandidatesCount = players.filter((p: any) => p.user && p.user.isScoutCandidate).length;

  // Photo upload mutations
  const uploadPhotoMutation = useMutation({
    mutationFn: async ({ playerId, file }: { playerId: number; file: File }) => {
      const formData = new FormData();
      formData.append('photo', file);
      const response = await fetch(`/api/players/${playerId}/photo`, {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) {
        throw new Error('Foto upload mislukt');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      toast({
        title: "Succes",
        description: "Foto succesvol geüpload",
      });
    },
    onError: (error) => {
      toast({
        title: "Fout",
        description: error.message || "Er is iets misgegaan bij het uploaden van de foto",
        variant: "destructive",
      });
    },
  });

  const handlePhotoUpload = (playerId: number, file: File) => {
    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Ongeldige bestandstype",
        description: "Alleen JPG, JPEG en PNG bestanden zijn toegestaan",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Bestand te groot",
        description: "Maximale bestandsgrootte is 5MB",
        variant: "destructive",
      });
      return;
    }

    uploadPhotoMutation.mutate({ playerId, file });
  };

  // Form mutations
  const createPlayerMutation = useMutation({
    mutationFn: async (data: InsertPlayer) => {
      return apiRequest("/api/players", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      setIsFormOpen(false);
      toast({
        title: "Succes",
        description: "Speler succesvol toegevoegd",
      });
    },
    onError: (error) => {
      toast({
        title: "Fout",
        description: "Er is iets misgegaan bij het toevoegen van de speler",
        variant: "destructive",
      });
    },
  });

  // Sync to teams mutation
  const syncToTeams = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/teams/sync-rosters", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (!response.ok) {
        throw new Error("Sync failed");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams-overview"] });
      toast({
        title: "Succes",
        description: "Team rosters succesvol gesynchroniseerd met Players Database",
      });
    },
    onError: (error) => {
      toast({
        title: "Fout",
        description: `Synchronisatie mislukt: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const updatePlayerMutation = useMutation({
    mutationFn: async (data: any) => {
      const playerId = editingPlayer?.id;
      if (!playerId) throw new Error("Geen speler ID gevonden");
      
      console.log("Updating player:", playerId, data);
      
      // Check if player is being assigned to Scouting team (id 4)
      const isAssignedToScouting = parseInt(data.teamId) === 4;
      const previousTeam = editingPlayer?.teamId;
      
      const response = await fetch(`/api/players/${playerId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("Update failed:", response.status, errorText);
        throw new Error(`Update failed: ${response.status}`);
      }
      
      const updatedPlayer = await response.json();
      
      // If assigned to Scouting team for the first time, create scout entry
      if (isAssignedToScouting && previousTeam !== 4) {
        try {
          const scoutResponse = await fetch("/api/scout-database", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              firstName: data.firstName || editingPlayer?.firstName,
              lastName: data.lastName || editingPlayer?.lastName,
              email: data.email || editingPlayer?.email,
              phone: data.phone || editingPlayer?.phone,
              nationality: data.nationality || editingPlayer?.nationality,
              currentClub: "VVC Brasschaat",
              position: data.position || editingPlayer?.position,
              address: data.address || editingPlayer?.address,
              originalPlayerId: playerId,
              scoutPriority: "medium",
              scoutStatus: "prospect",
              scoutNotes: "Automatisch toegevoegd via team toewijzing naar Scouting team",
            }),
          });
          
          if (scoutResponse.ok) {
            toast({
              title: "Scout Entry Aangemaakt",
              description: "Speler is automatisch toegevoegd aan Scout Database",
            });
          }
        } catch (error) {
          console.error('Failed to create scout entry:', error);
        }
      }
      
      return updatedPlayer;
    },
    onSuccess: (updatedPlayer) => {
      console.log("Player updated successfully:", updatedPlayer);
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scout-database"] });
      setEditingPlayer(null);
      toast({
        title: "Succes",
        description: "Speler succesvol bijgewerkt",
      });
    },
    onError: (error) => {
      console.error("Update error:", error);
      toast({
        title: "Fout",
        description: `Er ging iets mis bij het bijwerken: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Bulk upload mutation with column mapping
  const bulkUploadMutation = useMutation({
    mutationFn: async ({ file, columnMapping }: { file: File; columnMapping: Record<string, string> }) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('columnMapping', JSON.stringify(columnMapping));
      
      const response = await fetch('/api/players/bulk-upload', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Upload failed: ${errorText}`);
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      setIsBulkUploadOpen(false);
      toast({
        title: "Bulk upload succesvol",
        description: `${result.imported} spelers geïmporteerd, ${result.errors || 0} fouten`,
      });
    },
    onError: (error) => {
      toast({
        title: "Upload mislukt",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deletePlayerMutation = useMutation({
    mutationFn: async (playerId: number) => {
      console.log(`Attempting to delete player with ID: ${playerId}`);
      
      const response = await fetch(`/api/players/${playerId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
        }
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Delete failed: ${response.status} - ${errorText}`);
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }
      
      console.log(`Successfully deleted player ${playerId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      setDeletingPlayer(null);
      toast({
        title: "Succes",
        description: "Speler succesvol verwijderd",
      });
    },
    onError: (error) => {
      console.error('Delete player error:', error);
      toast({
        title: "Fout",
        description: error.message || "Er is iets misgegaan bij het verwijderen van de speler",
        variant: "destructive",
      });
    },
  });

  // Duplicate detection function
  const findDuplicates = () => {
    if (!players) return;
    
    const duplicateGroups: Array<Array<any>> = [];
    const processed = new Set();

    players.forEach((player, index) => {
      if (processed.has(index)) return;
      
      const similarPlayers = [player];
      processed.add(index);

      players.forEach((otherPlayer, otherIndex) => {
        if (otherIndex === index || processed.has(otherIndex)) return;
        
        const name1 = `${player.firstName} ${player.lastName}`.toLowerCase();
        const name2 = `${otherPlayer.firstName} ${otherPlayer.lastName}`.toLowerCase();
        
        if (name1 === name2 || 
            (player.firstName?.toLowerCase() === otherPlayer.firstName?.toLowerCase() && 
             player.lastName?.toLowerCase() === otherPlayer.lastName?.toLowerCase()) ||
            (player.email && otherPlayer.email && player.email === otherPlayer.email)) {
          similarPlayers.push(otherPlayer);
          processed.add(otherIndex);
        }
      });

      if (similarPlayers.length > 1) {
        duplicateGroups.push(similarPlayers);
      }
    });

    setDuplicates(duplicateGroups);
    setIsDuplicateManagerOpen(true);
    
    if (duplicateGroups.length === 0) {
      toast({
        title: "Geen duplicaten gevonden",
        description: "Er zijn geen mogelijke duplicaten gedetecteerd.",
      });
    }
  };

  // Merge players function
  const mergePlayers = async (playersToMerge: any[], keepPlayer: any) => {
    try {
      console.log('Starting merge process:', { 
        playersToMerge: playersToMerge.length, 
        keepPlayerId: keepPlayer.id 
      });

      // Delete all players except the one to keep
      const deletePromises = playersToMerge
        .filter(player => player.id !== keepPlayer.id)
        .map(async (player) => {
          console.log(`Deleting player ${player.id}: ${player.firstName} ${player.lastName}`);
          try {
            const response = await fetch(`/api/players/${player.id}`, { 
              method: 'DELETE',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`
              }
            });
            
            if (!response.ok) {
              const errorText = await response.text();
              throw new Error(`HTTP ${response.status}: ${errorText}`);
            }
            console.log(`Successfully deleted player ${player.id}`);
            return response;
          } catch (deleteError) {
            console.error(`Failed to delete player ${player.id}:`, deleteError);
            throw new Error(`Kon speler ${player.firstName} ${player.lastName} niet verwijderen: ${deleteError.message}`);
          }
        });

      await Promise.all(deletePromises);

      // Refresh the players list
      await queryClient.invalidateQueries({ queryKey: ['/api/players'] });
      
      toast({
        title: "Spelers samengevoegd",
        description: `${playersToMerge.length - 1} duplicaten verwijderd. ${keepPlayer.firstName} ${keepPlayer.lastName} behouden.`,
      });
      
      setIsDuplicateManagerOpen(false);
      
    } catch (error) {
      console.error('Merge error:', error);
      toast({
        title: "Fout bij samenvoegen",
        description: error.message || "Er ging iets mis bij het samenvoegen van de spelers.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center gap-3 mb-4">
        <Link href="/">
          <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 hover:bg-gray-100">
            <ArrowLeft size={18} />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Players Database</h1>
      </div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Players Database</h1>
          <p className="text-muted-foreground">
            Beheer alle spelers in de database ({players.length} spelers totaal)
          </p>
        </div>
        <div className="flex gap-2">
          <BackToMenu />
          <Button 
            onClick={() => syncToTeams.mutate()}
            variant="outline"
            className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 flex items-center gap-2"
            disabled={syncToTeams.isPending}
          >
            <Users className="h-4 w-4" />
            {syncToTeams.isPending ? "Synchroniseren..." : "Sync naar Teams"}
          </Button>
          <Button 
            onClick={() => setLocation("/player-to-scout")}
            variant="outline"
            className="flex items-center gap-2"
          >
            <UserPlus className="h-4 w-4" />
            Naar Scout Database
          </Button>
          <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Nieuwe Speler
          </Button>
          <Button variant="outline" onClick={() => setIsBulkUploadOpen(true)} className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Bulk Upload
          </Button>
          <Button 
            variant="outline" 
            onClick={findDuplicates}
            className="bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100 flex items-center gap-2"
          >
            <Users className="h-4 w-4" />
            Zoek Duplicaten
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Zoek spelers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={selectedTeam} onValueChange={setSelectedTeam}>
              <SelectTrigger>
                <SelectValue placeholder="Team" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle teams</SelectItem>
                {teams.map((team: any) => (
                  <SelectItem key={team.id} value={team.id.toString()}>
                    {team.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedPosition} onValueChange={setSelectedPosition}>
              <SelectTrigger>
                <SelectValue placeholder="Positie" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle posities</SelectItem>
                <SelectItem value="goalkeeper">Keeper</SelectItem>
                <SelectItem value="defender">Verdediger</SelectItem>
                <SelectItem value="midfielder">Middenvelder</SelectItem>
                <SelectItem value="forward">Aanvaller</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle statussen</SelectItem>
                <SelectItem value="active">Actief</SelectItem>
                <SelectItem value="inactive">Inactief</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center space-x-2">
              <Switch
                id="scout-filter"
                checked={showScoutOnly}
                onCheckedChange={setShowScoutOnly}
              />
              <Label htmlFor="scout-filter" className="text-sm">
                Scout kandidaten ({scoutCandidatesCount})
              </Label>
            </div>

            <div className="flex gap-2">
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("grid")}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "table" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("table")}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Players Display */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : viewMode === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlayers.map((player: Player) => (
            <Card key={player.id} className="relative group hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setEditingPlayer(player)}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    {/* Player Photo */}
                    <div className="relative">
                      <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-100 border-2 border-gray-200">
                        {player.user?.profileImage ? (
                          <img 
                            src={player.user.profileImage} 
                            alt={`${player.user?.firstName || ''} ${player.user?.lastName || ''}`}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-400">
                            <User className="w-8 h-8" />
                          </div>
                        )}
                      </div>
                      
                      {/* Photo Upload Button - Only in Grid View */}
                      <div className="absolute -bottom-1 -right-1">
                        <input
                          type="file"
                          accept="image/jpeg,image/jpg,image/png"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              handlePhotoUpload(player.id, file);
                            }
                          }}
                          className="hidden"
                          id={`photo-upload-${player.id}`}
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-6 h-6 p-0 rounded-full bg-white border shadow-sm hover:bg-gray-50"
                          onClick={() => document.getElementById(`photo-upload-${player.id}`)?.click()}
                          disabled={uploadPhotoMutation.isPending}
                        >
                          {uploadPhotoMutation.isPending ? (
                            <div className="w-3 h-3 border border-gray-300 border-t-gray-600 rounded-full animate-spin" />
                          ) : (
                            <Camera className="w-3 h-3" />
                          )}
                        </Button>
                      </div>
                    </div>

                    <div>
                      <CardTitle className="text-lg">
                        {player.user?.firstName || 'Onbekend'} {player.user?.lastName || ''}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">{player.user?.email || 'Geen email'}</p>
                    </div>
                  </div>
                  {player.user?.isScoutCandidate && (
                    <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                      <Star className="h-3 w-3 mr-1" />
                      Scout
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <Label className="text-xs text-muted-foreground">Team</Label>
                    <p>{player.team?.name || teams.find((t: any) => t.id === player.teamId)?.name || 'Geen team'}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Positie</Label>
                    <p>{player.position || 'Niet ingevuld'}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Rugnummer</Label>
                    <p>{player.jerseyNumber || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Status</Label>
                    <Badge variant={player.status === 'active' ? 'default' : 'secondary'}>
                      {player.status}
                    </Badge>
                  </div>
                </div>

                <div className="flex gap-2 pt-2 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingPlayer(player);
                    }}
                    className="flex-1"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Bewerken
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeletingPlayer(player);
                    }}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left p-3 w-48">Code & Naam</th>
                    <th className="text-left p-3 w-64">Adres</th>
                    <th className="text-left p-3 w-32">Team</th>
                    <th className="text-left p-3 w-28">Geb.datum</th>
                    <th className="text-left p-3 w-32">GSM 1</th>
                    <th className="text-left p-3 w-32">GSM 2</th>
                    <th className="text-left p-3 w-56">Email 1</th>
                    <th className="text-left p-3 w-20">Scout</th>
                    <th className="text-left p-3 w-32">Acties</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPlayers.map((player: Player) => (
                    <tr key={player.id} className="border-t hover:bg-muted/25">
                      <td className="p-3 text-sm">
                        <div className="font-medium text-blue-600">{player.playerCode || `10${String(player.id).padStart(3, '0')}`}</div>
                        <div className="text-gray-800 truncate">{player.user?.firstName || ''} {player.user?.lastName || ''}</div>
                      </td>
                      <td className="p-3 text-sm truncate max-w-64">{player.user?.address || '-'}</td>
                      <td className="p-3 text-sm truncate">{player.team?.name || '-'}</td>
                      <td className="p-3 text-sm text-center">
                        {player.user?.dateOfBirth ? new Date(player.user.dateOfBirth).toLocaleDateString('nl-BE') : '-'}
                      </td>
                      <td className="p-3 text-sm">{player.user?.phone || '-'}</td>
                      <td className="p-3 text-sm">{player.user?.phone2 || '-'}</td>
                      <td className="p-3 text-sm truncate max-w-56">{player.user?.email || '-'}</td>
                      <td className="p-3">
                        {player.teamId === 4 && (
                          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                            <Star className="h-3 w-3 mr-1" />
                            Scout
                          </Badge>
                        )}
                      </td>
                      <td className="p-3">
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setEditingPlayer(player)}
                            title="Bewerken"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setDeletingPlayer(player)}
                            className="text-red-600 hover:text-red-700"
                            title="Verwijderen"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {filteredPlayers.length === 0 && !isLoading && (
        <Card>
          <CardContent className="text-center py-12">
            <p className="text-muted-foreground mb-4">
              Geen spelers gevonden met de huidige filters.
            </p>
            <Button onClick={() => {
              setSearchTerm("");
              setSelectedTeam("all");
              setSelectedPosition("all");
              setShowScoutOnly(false);
            }}>
              Filters wissen
            </Button>
          </CardContent>
        </Card>
      )}

      {/* View Player Dialog */}
      <Dialog open={!!viewingPlayer} onOpenChange={() => setViewingPlayer(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              Speler Details - {viewingPlayer?.firstName} {viewingPlayer?.lastName}
            </DialogTitle>
          </DialogHeader>
          {viewingPlayer && (
            <div className="space-y-6">
              <div>
                <h3 className="font-medium mb-3">Basis Informatie</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Voornaam</Label>
                    <p>{viewingPlayer.firstName}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Achternaam</Label>
                    <p>{viewingPlayer.lastName}</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-3">Contact Informatie</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Adres</Label>
                    <p>{viewingPlayer.address || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Geboortedatum</Label>
                    <p>{viewingPlayer.dateOfBirth ? new Date(viewingPlayer.dateOfBirth).toLocaleDateString('nl-BE') : '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">GSM 1</Label>
                    <p>{viewingPlayer.phone || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">GSM 2</Label>
                    <p>{viewingPlayer.phone2 || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">GSM 3</Label>
                    <p>{viewingPlayer.phone3 || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Email 1</Label>
                    <p>{viewingPlayer.email || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Email 2</Label>
                    <p>{viewingPlayer.email2 || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Email 3</Label>
                    <p>{viewingPlayer.email3 || '-'}</p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t">
                <Button variant="outline" onClick={() => setViewingPlayer(null)}>
                  Sluiten
                </Button>
                <Button onClick={() => {
                  setEditingPlayer(viewingPlayer);
                  setViewingPlayer(null);
                }}>
                  <Edit className="h-4 w-4 mr-2" />
                  Bewerken
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Player Dialog */}
      {editingPlayer && (
        <Dialog open={!!editingPlayer} onOpenChange={() => setEditingPlayer(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <div className="flex items-center justify-between">
                <div>
                  <DialogTitle>Speler Bewerken - {editingPlayer.firstName} {editingPlayer.lastName}</DialogTitle>
                  <DialogDescription>Wijzig de gegevens van deze speler</DialogDescription>
                </div>
                <Button 
                  type="button"
                  onClick={() => {
                    const form = document.querySelector('form[data-player-edit-form]') as HTMLFormElement;
                    if (form) {
                      const submitEvent = new Event('submit', { bubbles: true, cancelable: true });
                      form.dispatchEvent(submitEvent);
                    }
                  }}
                  disabled={updatePlayerMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {updatePlayerMutation.isPending ? "Opslaan..." : "Opslaan"}
                </Button>
              </div>
            </DialogHeader>
            <PlayerEditForm 
              player={editingPlayer}
              teams={teams}
              onSubmit={(data) => updatePlayerMutation.mutate(data)}
              onCancel={() => setEditingPlayer(null)}
              isLoading={updatePlayerMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Bulk Upload Dialog */}
      {isBulkUploadOpen && (
        <Dialog open={isBulkUploadOpen} onOpenChange={setIsBulkUploadOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Bulk Upload Spelers</DialogTitle>
              <DialogDescription>Upload meerdere spelers tegelijk via Excel of CSV bestand</DialogDescription>
            </DialogHeader>
            <BulkUploadForm 
              onSubmit={(file, columnMapping) => bulkUploadMutation.mutate({ file, columnMapping })}
              onCancel={() => setIsBulkUploadOpen(false)}
              isLoading={bulkUploadMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Duplicate Manager Dialog */}
      {isDuplicateManagerOpen && (
        <Dialog open={isDuplicateManagerOpen} onOpenChange={setIsDuplicateManagerOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Duplicaten Beheren</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {duplicates.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Geen duplicaten gevonden.</p>
                </div>
              ) : (
                duplicates.map((group, groupIndex) => (
                  <Card key={groupIndex} className="border-orange-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-orange-800">
                        Duplicaat Groep {groupIndex + 1} - {group.length} spelers
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-4">
                        {group.map((player) => (
                          <div key={player.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex-1">
                              <div className="font-medium">
                                {player.firstName} {player.lastName}
                              </div>
                              <div className="text-sm text-muted-foreground space-y-1">
                                {player.email && <div>Email: {player.email}</div>}
                                {player.phone && <div>Telefoon: {player.phone}</div>}
                                {player.teamName && <div>Team: {player.teamName}</div>}
                                {player.dateOfBirth && <div>Geboortedatum: {new Date(player.dateOfBirth).toLocaleDateString('nl-BE')}</div>}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Badge variant={player.status === 'active' ? 'default' : 'secondary'}>
                                {player.status || 'active'}
                              </Badge>
                              <Button
                                size="sm"
                                onClick={() => mergePlayers(group, player)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                Behouden
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                          <div>
                            <p className="font-medium text-yellow-800">Let op!</p>
                            <p className="text-sm text-yellow-700">
                              Klik op "Behouden" bij de speler die u wilt bewaren. 
                              De andere duplicaten worden verwijderd.
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Duplicate Manager Dialog */}
      {isDuplicateManagerOpen && (
        <Dialog open={isDuplicateManagerOpen} onOpenChange={setIsDuplicateManagerOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Duplicaten Beheren</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {duplicates.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Geen duplicaten gevonden.</p>
                </div>
              ) : (
                duplicates.map((group, groupIndex) => (
                  <Card key={groupIndex} className="border-orange-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-orange-800">
                        Duplicaat Groep {groupIndex + 1} - {group.length} spelers
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-4">
                        {group.map((player, playerIndex) => (
                          <div key={player.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex-1">
                              <div className="font-medium">
                                {player.firstName} {player.lastName}
                              </div>
                              <div className="text-sm text-muted-foreground space-y-1">
                                {player.email && <div>Email: {player.email}</div>}
                                {player.phone && <div>Telefoon: {player.phone}</div>}
                                {player.teamName && <div>Team: {player.teamName}</div>}
                                {player.dateOfBirth && <div>Geboortedatum: {new Date(player.dateOfBirth).toLocaleDateString('nl-BE')}</div>}
                                {player.address && <div>Adres: {player.address}</div>}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Badge variant={player.status === 'active' ? 'default' : 'secondary'}>
                                {player.status || 'active'}
                              </Badge>
                              <Button
                                size="sm"
                                onClick={() => mergePlayers(group, player)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                Behouden
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                          <div>
                            <p className="font-medium text-yellow-800">Let op!</p>
                            <p className="text-sm text-yellow-700">
                              Klik op "Behouden" bij de speler die u wilt bewaren. 
                              De gegevens van alle spelers worden samengevoegd en de andere duplicaten worden verwijderd.
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Confirmation Dialog */}
      {deletingPlayer && (
        <Dialog open={!!deletingPlayer} onOpenChange={() => setDeletingPlayer(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                Speler Verwijderen
              </DialogTitle>
              <DialogDescription>
                Deze actie verwijdert de speler permanent uit de database.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <p>
                Weet u zeker dat u <strong>{deletingPlayer.firstName} {deletingPlayer.lastName}</strong> wilt verwijderen?
              </p>
              <p className="text-sm text-muted-foreground">
                Deze actie kan niet ongedaan worden gemaakt. Alle gegevens van deze speler worden permanent verwijderd.
              </p>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setDeletingPlayer(null)}>
                  Annuleren
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={() => {
                    deletePlayerMutation.mutate(deletingPlayer.id);
                    setDeletingPlayer(null);
                  }}
                  disabled={deletePlayerMutation.isPending}
                >
                  {deletePlayerMutation.isPending ? 'Verwijderen...' : 'Definitief Verwijderen'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// Bulk Upload Form Component
function BulkUploadForm({ 
  onSubmit, 
  onCancel,
  isLoading 
}: { 
  onSubmit: (file: File, columnMapping: Record<string, string>) => void;
  onCancel: () => void;
  isLoading: boolean;
}) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [fileColumns, setFileColumns] = useState<string[]>([]);
  const [columnMapping, setColumnMapping] = useState<Record<string, string>>({});
  const [showMapping, setShowMapping] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [mappingPreview, setMappingPreview] = useState<Array<{fileColumn: string, dbField: string}>>([]);

  const handleFileSelect = async (file: File) => {
    if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
        file.type === 'application/vnd.ms-excel' ||
        file.type === 'text/csv') {
      setSelectedFile(file);
      
      // Parse file to get column headers
      try {
        const formData = new FormData();
        formData.append('file', file);
        
        console.log('Sending file to parse columns API');
        const response = await fetch('/api/players/parse-columns', {
          method: 'POST',
          body: formData,
        });
        
        console.log('Parse columns response status:', response.status);
        console.log('Parse columns response headers:', Object.fromEntries(response.headers.entries()));
        
        if (response.ok) {
          try {
            const data = await response.json();
            console.log('Parsed columns:', data.columns);
            setFileColumns(data.columns || []);
            setShowMapping(true);
          } catch (parseError) {
            console.error('JSON parse error:', parseError);
            const responseText = await response.text();
            console.error('Response text:', responseText);
            alert('Server gaf een onverwacht antwoord terug. Check de console voor details.');
          }
        } else {
          const errorText = await response.text();
          console.error('Failed to parse columns - response not ok:', errorText);
          alert(`Upload mislukt: ${response.status} - ${errorText}`);
        }
      } catch (error) {
        console.error('Failed to parse columns:', error);
        alert('Fout bij het lezen van het bestand. Controleer of het een geldig Excel of CSV bestand is.');
      }
    } else {
      alert('Alleen Excel (.xlsx, .xls) en CSV bestanden zijn toegestaan');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files[0]) {
      handleFileSelect(files[0]);
    }
  };

  const handleSubmit = () => {
    if (selectedFile) {
      onSubmit(selectedFile, columnMapping);
    }
  };

  const databaseFields = [
    { value: 'firstName', label: 'Voornaam' },
    { value: 'lastName', label: 'Achternaam' },
    { value: 'email', label: 'Email' },
    { value: 'phone', label: 'Telefoon' },
    { value: 'phone2', label: 'Telefoon 2' },
    { value: 'phone3', label: 'Telefoon 3' },
    { value: 'email2', label: 'Email 2' },
    { value: 'address', label: 'Adres' },
    { value: 'clubName', label: 'Clubnaam' },
    { value: 'dateOfBirth', label: 'Geboortedatum' },
    { value: 'position', label: 'Positie' },
    { value: 'jerseyNumber', label: 'Rugnummer' },
    { value: 'teamName', label: 'Team' },
    { value: 'skip', label: '-- Overslaan --' }
  ];

  const downloadTemplate = () => {
    // Create a template CSV
    const headers = [
      'Voornaam', 'Achternaam', 'Email', 'Telefoon', 'Telefoon 2', 'Telefoon 3',
      'Email 2', 'Adres', 'Clubnaam', 'Geboortedatum', 'Positie', 'Rugnummer', 'Team'
    ];
    
    const csvContent = headers.join(',') + '\n' +
      'Jan,Janssen,jan.janssen@example.com,+32 123 456 789,,,jan2@example.com,Hoofdstraat 123 Antwerpen,VVC Brasschaat,01/01/2000,midfielder,10,Dames IP';
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'spelers_template.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  if (showMapping && fileColumns.length > 0) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Kolommen Toewijzen</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Wijs de kolommen uit uw bestand toe aan de database velden:
            </p>
            <div className="space-y-3">
              {fileColumns.map((column, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className="w-1/3">
                    <Label className="font-medium">{column}</Label>
                  </div>
                  <div className="w-1/3">
                    <Select 
                      value={columnMapping[column] || 'skip'} 
                      onValueChange={(value) => 
                        setColumnMapping(prev => ({ ...prev, [column]: value }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer veld" />
                      </SelectTrigger>
                      <SelectContent>
                        {databaseFields.map(field => (
                          <SelectItem key={field.value} value={field.value}>
                            {field.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <Button variant="outline" onClick={() => {
                setShowMapping(false);
                setSelectedFile(null);
                setFileColumns([]);
              }}>
                Terug
              </Button>
              <Button onClick={handleSubmit} disabled={isLoading}>
                {isLoading ? 'Importeren...' : 'Import Starten'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Template Download */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Template Downloaden
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Download eerst de template om de juiste kolomstructuur te krijgen.
          </p>
          <Button variant="outline" onClick={downloadTemplate}>
            <FileText className="h-4 w-4 mr-2" />
            Download Template
          </Button>
        </CardContent>
      </Card>

      {/* File Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Bestand Uploaden
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div 
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive ? 'border-primary bg-primary/5' : 'border-muted-foreground/25'
            }`}
            onDragEnter={(e) => { e.preventDefault(); setDragActive(true); }}
            onDragLeave={(e) => { e.preventDefault(); setDragActive(false); }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
          >
            {selectedFile ? (
              <div className="space-y-2">
                <FileText className="h-12 w-12 mx-auto text-green-500" />
                <p className="font-medium">{selectedFile.name}</p>
                <p className="text-sm text-muted-foreground">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedFile(null)}
                >
                  Verwijderen
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <Upload className="h-12 w-12 mx-auto text-muted-foreground" />
                <div>
                  <p className="text-lg font-medium">Sleep uw bestand hier</p>
                  <p className="text-sm text-muted-foreground">of klik om te selecteren</p>
                </div>
                <Input
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileSelect(file);
                  }}
                  className="hidden"
                  id="file-upload"
                />
                <Label htmlFor="file-upload">
                  <Button variant="outline" asChild>
                    <span>Bestand Selecteren</span>
                  </Button>
                </Label>
              </div>
            )}
          </div>

          {/* Required Format Info */}
          <div className="mt-4 p-4 bg-muted/50 rounded-lg">
            <h4 className="font-medium mb-2">Vereiste Kolommen:</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>• Voornaam (verplicht)</div>
              <div>• Achternaam (verplicht)</div>
              <div>• Email</div>
              <div>• Telefoon</div>
              <div>• Adres</div>
              <div>• Clubnaam</div>
              <div>• Geboortedatum (DD/MM/YYYY)</div>
              <div>• Positie (optioneel)</div>
              <div>• Rugnummer (optioneel)</div>
              <div>• Team (Dames IP/U20/Beloften)</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel} disabled={isLoading}>
          Annuleren
        </Button>
        <Button 
          onClick={handleSubmit} 
          disabled={!selectedFile || isLoading}
        >
          {isLoading ? 'Uploaden...' : 'Upload Starten'}
        </Button>
      </div>
    </div>
  );
}

// Player Edit Form Component
function PlayerEditForm({ 
  player, 
  teams, 
  onSubmit, 
  onCancel,
  isLoading 
}: { 
  player: any; 
  teams: any[]; 
  onSubmit: (data: any) => void;
  onCancel: () => void;
  isLoading: boolean;
}) {
  const form = useForm({
    defaultValues: {
      firstName: player.user?.firstName || '',
      lastName: player.user?.lastName || '',
      email: player.user?.email || '',
      phone: player.user?.phone || '',
      phone2: player.user?.phone2 || '',
      phone3: player.user?.phone3 || '',
      email2: player.user?.email2 || '',
      address: player.user?.address || '',
      clubName: player.user?.clubName || '',
      dateOfBirth: player.user?.dateOfBirth || '',
      teamId: player.teamId || '',
      position: player.position || '',
      jerseyNumber: player.jerseyNumber || '',
      status: player.status || 'active'
    }
  });

  const handleSubmit = (data: any) => {
    // Convert teamId to number if provided
    if (data.teamId) {
      data.teamId = parseInt(data.teamId);
    }
    
    // Handle date formatting - remove empty strings
    if (data.dateOfBirth === '') {
      data.dateOfBirth = null;
    }
    
    // Handle empty strings for numeric fields
    if (data.jerseyNumber === '') {
      data.jerseyNumber = null;
    }
    
    // Add the player ID to the data
    const submitData = {
      ...data,
      id: player.id
    };
    
    console.log("Form submit data:", submitData);
    onSubmit(submitData);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6" data-player-edit-form>
        {/* Basic Information */}
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="firstName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Voornaam *</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="lastName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Achternaam *</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Contact Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Contact Gegevens</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email 1 *</FormLabel>
                  <FormControl>
                    <Input type="email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email2"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email 2</FormLabel>
                  <FormControl>
                    <Input type="email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Telefoon 1</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="+32 xxx xx xx xx" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone2"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Telefoon 2</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="+32 xxx xx xx xx" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone3"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Telefoon 3</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="+32 xxx xx xx xx" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="address"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Adres</FormLabel>
                <FormControl>
                  <Textarea {...field} placeholder="Straat, nummer, postcode, stad" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Player Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Speler Gegevens</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="dateOfBirth"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Geboortedatum</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="clubName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Clubnaam</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Voer clubnaam in..." />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 gap-4">
            <FormField
              control={form.control}
              name="teamId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Team</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer team" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {teams.map((team) => (
                        <SelectItem key={team.id} value={team.id.toString()}>
                          {team.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <FormField
              control={form.control}
              name="position"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Positie</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer positie" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="goalkeeper">Goalkeeper</SelectItem>
                      <SelectItem value="defender">Verdediger</SelectItem>
                      <SelectItem value="midfielder">Middenvelder</SelectItem>
                      <SelectItem value="forward">Aanvaller</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="jerseyNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rugnummer</FormLabel>
                  <FormControl>
                    <Input type="number" min="1" max="99" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="active">Actief</SelectItem>
                      <SelectItem value="inactive">Inactief</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex justify-between gap-2 pt-4 border-t">
          <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Terug
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Opslaan..." : "Opslaan"}
          </Button>
        </div>
      </form>
    </Form>
  );
}