import React, { useState, useEffect } from 'react';
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, Target, Users, MapPin, Star, Plus, Edit, Trash2, Eye, Filter, Search, ChevronLeft, ChevronRight } from "lucide-react";
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';

interface YearPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface TrainingSession {
  id: string;
  planId: number;
  week: number;
  session: number;
  date: string;
  time: string;
  duration: number;
  focusArea: string;
  location: string;
  ageGroup: string;
  assignedElements: string[];
  intensity: 'low' | 'medium' | 'high';
  weather: 'indoor' | 'outdoor';
  notes: string;
  status: 'planned' | 'completed' | 'cancelled';
}

interface IAElement {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  description: string;
  ageGroups: string[];
  progressions: string[];
}

export default function ModernJaarplanning() {
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [viewMode, setViewMode] = useState<'week' | 'month'>('week');
  const [filterAgeGroup, setFilterAgeGroup] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);
  const [showPlanDialog, setShowPlanDialog] = useState(false);

  // Fetch year plans
  const { data: yearPlans = [] } = useQuery({
    queryKey: ['/api/year-plans'],
  });

  // Fetch IA Databank elements
  const { data: iaElements = [] } = useQuery({
    queryKey: ['/api/iadatabank/elements'],
  });

  // Fetch teams
  const { data: teams = [] } = useQuery({
    queryKey: ['/api/teams'],
  });

  const getWeekDays = (date: Date) => {
    const start = startOfWeek(date, { weekStartsOn: 1 });
    const end = endOfWeek(date, { weekStartsOn: 1 });
    return eachDayOfInterval({ start, end });
  };

  // Generate realistic training sessions for the current week
  const [trainingSessions] = useState<TrainingSession[]>(() => {
    const sessions: TrainingSession[] = [];
    const today = new Date();
    const currentWeekDays = getWeekDays(today);
    
    // Generate sessions for Mon, Wed, Fri
    [0, 2, 4].forEach((dayIndex, sessionIndex) => {
      const sessionDate = currentWeekDays[dayIndex];
      sessions.push({
        id: `session-${sessionIndex + 1}`,
        planId: 1,
        week: 1,
        session: sessionIndex + 1,
        date: format(sessionDate, 'yyyy-MM-dd'),
        time: '19:00',
        duration: 90,
        focusArea: ['BASICS - Passing', 'TEAMTACTICS - Positiespel', 'FYSIEK - Conditie'][sessionIndex],
        location: 'Hoofdveld',
        ageGroup: 'U15',
        assignedElements: [
          ['bas-b-plus-3', 'bas-b-plus-4'],
          ['tt-b-plus-1', 'tt-b-plus-2'], 
          ['fys-b-plus-1', 'fys-b-plus-2']
        ][sessionIndex],
        intensity: ['medium', 'high', 'low'][sessionIndex] as 'low' | 'medium' | 'high',
        weather: 'outdoor',
        notes: [
          'Focus op korte passing en balcontrole',
          'Oefenen met driehoeken vormen en ruimte creëren',
          'Intervaltraining en uithoudingsvermogen'
        ][sessionIndex],
        status: sessionDate < today ? 'completed' : 'planned'
      });
    });
    
    // Add U12 sessions on Tue, Thu
    [1, 3].forEach((dayIndex, sessionIndex) => {
      const sessionDate = currentWeekDays[dayIndex];
      sessions.push({
        id: `u12-session-${sessionIndex + 1}`,
        planId: 2,
        week: 1,
        session: sessionIndex + 1,
        date: format(sessionDate, 'yyyy-MM-dd'),
        time: '18:00',
        duration: 75,
        focusArea: ['BASICS - Dribbelen', 'TEAMTACTICS - Aanval'][sessionIndex],
        location: 'Veld 2',
        ageGroup: 'U12',
        assignedElements: [
          ['bas-b-plus-1', 'bas-b-plus-2'],
          ['tt-b-plus-3', 'tt-b-plus-4']
        ][sessionIndex],
        intensity: 'medium',
        weather: 'outdoor',
        notes: [
          'Individuele technieken en creativiteit',
          'Eenvoudige combinaties en doelgericht spel'
        ][sessionIndex],
        status: sessionDate < today ? 'completed' : 'planned'
      });
    });
    
    return sessions;
  });

  const getSessionsForDate = (date: Date) => {
    return trainingSessions.filter(session => 
      isSameDay(parseISO(session.date), date) &&
      (filterAgeGroup === 'all' || session.ageGroup === filterAgeGroup) &&
      (filterStatus === 'all' || session.status === filterStatus) &&
      (searchTerm === '' || 
        session.focusArea.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.notes.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  };

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planned': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getFocusAreaIcon = (focusArea: string) => {
    if (focusArea.includes('BASICS')) return '⚽';
    if (focusArea.includes('TEAMTACTICS')) return '🎯';
    if (focusArea.includes('MENTAAL')) return '🧠';
    if (focusArea.includes('FYSIEK')) return '💪';
    return '📋';
  };

  const weekDays = getWeekDays(currentWeek);
  const weekNumber = Math.ceil(
    (currentWeek.getTime() - new Date(currentWeek.getFullYear(), 0, 1).getTime()) / 
    (7 * 24 * 60 * 60 * 1000)
  );

  return (
    <div className="h-full flex flex-col space-y-6 p-6" data-component="modern-jaarplanning">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">🗓️ Moderne Jaarplanning Kalender</h1>
          <p className="text-gray-600 mt-1">
            Week {weekNumber} • {format(weekDays[0], 'd MMM', { locale: nl })} - {format(weekDays[6], 'd MMM yyyy', { locale: nl })}
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Dialog open={showPlanDialog} onOpenChange={setShowPlanDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nieuwe Training
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Nieuwe Training Sessie</DialogTitle>
                <DialogDescription>
                  Plan een nieuwe training sessie met IADATABANK elementen
                </DialogDescription>
              </DialogHeader>
              {/* Session form would go here */}
              <div className="grid gap-4 py-4">
                <div className="text-center text-gray-500">
                  Training sessie formulier komt hier...
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center space-x-2">
              <Search className="h-4 w-4 text-gray-400" />
              <Input
                placeholder="Zoek trainingen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
            </div>
            
            <Select value={filterAgeGroup} onValueChange={setFilterAgeGroup}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Leeftijdsgroep" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle groepen</SelectItem>
                <SelectItem value="U8">U8</SelectItem>
                <SelectItem value="U10">U10</SelectItem>
                <SelectItem value="U12">U12</SelectItem>
                <SelectItem value="U15">U15</SelectItem>
                <SelectItem value="U17">U17</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle status</SelectItem>
                <SelectItem value="planned">Gepland</SelectItem>
                <SelectItem value="completed">Voltooid</SelectItem>
                <SelectItem value="cancelled">Geannuleerd</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center space-x-1 ml-auto">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentWeek(addDays(currentWeek, -7))}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentWeek(new Date())}
              >
                Vandaag
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentWeek(addDays(currentWeek, 7))}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Calendar Grid */}
      <div className="flex-1 grid grid-cols-7 gap-4">
        {weekDays.map((day, index) => {
          const sessionsForDay = getSessionsForDate(day);
          const isToday = isSameDay(day, new Date());
          
          return (
            <Card key={index} className={`min-h-[400px] ${isToday ? 'ring-2 ring-blue-500' : ''}`}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-gray-600">
                      {format(day, 'EEEE', { locale: nl })}
                    </div>
                    <div className={`text-lg font-bold ${isToday ? 'text-blue-600' : 'text-gray-900'}`}>
                      {format(day, 'd', { locale: nl })}
                    </div>
                  </div>
                  {sessionsForDay.length > 0 && (
                    <Badge variant="secondary">{sessionsForDay.length}</Badge>
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-2">
                {sessionsForDay.length === 0 ? (
                  <div className="text-center text-gray-400 py-8">
                    <Calendar className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Geen trainingen</p>
                  </div>
                ) : (
                  sessionsForDay.map((session) => (
                    <Card
                      key={session.id}
                      className={`p-3 cursor-pointer hover:shadow-md transition-all duration-200 border-l-4 hover:scale-105 ${
                        session.ageGroup === 'U15' ? 'border-l-blue-500' : 
                        session.ageGroup === 'U12' ? 'border-l-green-500' : 'border-l-purple-500'
                      } ${session.status === 'completed' ? 'bg-gray-50' : 'bg-white'}`}
                      onClick={() => {
                        setSelectedSession(session);
                        setShowSessionDialog(true);
                      }}
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{getFocusAreaIcon(session.focusArea)}</span>
                            <Badge className={getIntensityColor(session.intensity)}>
                              {session.intensity}
                            </Badge>
                          </div>
                          <Badge className={getStatusColor(session.status)}>
                            {session.status}
                          </Badge>
                        </div>
                        
                        <div>
                          <div className="font-medium text-sm text-gray-900">
                            {session.focusArea}
                          </div>
                          <div className="text-xs text-gray-600 flex items-center space-x-2">
                            <Clock className="h-3 w-3" />
                            <span>{session.time} ({session.duration}min)</span>
                          </div>
                          <div className="text-xs text-gray-600 flex items-center space-x-2">
                            <Users className="h-3 w-3" />
                            <span>{session.ageGroup}</span>
                          </div>
                          <div className="text-xs text-gray-600 flex items-center space-x-2">
                            <MapPin className="h-3 w-3" />
                            <span>{session.location}</span>
                          </div>
                        </div>
                        
                        {session.notes && (
                          <div className="text-xs text-gray-500 truncate">
                            {session.notes}
                          </div>
                        )}
                      </div>
                    </Card>
                  ))
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Session Detail Dialog */}
      <Dialog open={showSessionDialog} onOpenChange={setShowSessionDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <span className="text-2xl">{selectedSession && getFocusAreaIcon(selectedSession.focusArea)}</span>
              <span>{selectedSession?.focusArea}</span>
            </DialogTitle>
            <DialogDescription>
              {selectedSession && format(parseISO(selectedSession.date), 'EEEE d MMMM yyyy', { locale: nl })} • {selectedSession?.time}
            </DialogDescription>
          </DialogHeader>
          
          {selectedSession && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Leeftijdsgroep</label>
                  <p className="text-sm text-gray-900">{selectedSession.ageGroup}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Locatie</label>
                  <p className="text-sm text-gray-900">{selectedSession.location}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Duur</label>
                  <p className="text-sm text-gray-900">{selectedSession.duration} minuten</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Intensiteit</label>
                  <Badge className={getIntensityColor(selectedSession.intensity)}>
                    {selectedSession.intensity}
                  </Badge>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-600">Toegewezen Elementen</label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedSession.assignedElements.map((elementId) => (
                    <Badge key={elementId} variant="outline">
                      {elementId}
                    </Badge>
                  ))}
                </div>
              </div>
              
              {selectedSession.notes && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Notities</label>
                  <p className="text-sm text-gray-900 mt-1">{selectedSession.notes}</p>
                </div>
              )}
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowSessionDialog(false)}>
                  Sluiten
                </Button>
                <Button>
                  <Edit className="h-4 w-4 mr-2" />
                  Bewerken
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}