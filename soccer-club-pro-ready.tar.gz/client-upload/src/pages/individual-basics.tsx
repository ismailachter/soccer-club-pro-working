import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface IndividualBasics {
  player_name: string;
  team: 'home' | 'away';
  basics_passing_accuracy: number;
  basics_first_touch_success: number;
  basics_ball_control_rating: number;
  basics_positioning_score: number;
  successful_passes: number;
  failed_passes: number;
  key_passes: number;
  interceptions: number;
  tackles_won: number;
  tackles_lost: number;
  duels_won: number;
  duels_lost: number;
}

const IndividualBasics = () => {
  const [selectedMatch] = useState("match-1750870860329");
  const [selectedPlayer, setSelectedPlayer] = useState<string>("all");
  const [selectedTeam, setSelectedTeam] = useState<string>("both");

  const { data: tacticalData } = useQuery({
    queryKey: [`/api/tactical-analysis/${selectedMatch}`],
    enabled: !!selectedMatch
  });

  const players: IndividualBasics[] = tacticalData?.players || [];
  
  const filteredPlayers = players.filter(player => {
    if (selectedTeam === "home" && player.team !== "home") return false;
    if (selectedTeam === "away" && player.team !== "away") return false;
    if (selectedPlayer !== "all" && player.player_name !== selectedPlayer) return false;
    return true;
  });

  const getBasicsRating = (player: IndividualBasics) => {
    const avgRating = (
      (player.basics_passing_accuracy / 10) +
      (player.basics_first_touch_success / 10) +
      player.basics_ball_control_rating +
      player.basics_positioning_score
    ) / 4;
    return Math.round(avgRating * 10) / 10;
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 8) return "text-green-600 bg-green-50";
    if (rating >= 6) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 85) return "bg-green-500";
    if (accuracy >= 75) return "bg-yellow-500";
    return "bg-red-500";
  };

  const PlayerBasicsCard = ({ player }: { player: IndividualBasics }) => {
    const teamName = player.team === 'home' ? 'VVC Brasschaat' : 'Svelta Melsele';
    const teamColor = player.team === 'home' ? 'border-red-500 bg-red-50' : 'border-blue-500 bg-blue-50';
    const basicsRating = getBasicsRating(player);
    const passSuccess = Math.round((player.successful_passes / (player.successful_passes + player.failed_passes)) * 100);
    const tackleSuccess = Math.round((player.tackles_won / (player.tackles_won + player.tackles_lost)) * 100);
    const duelSuccess = Math.round((player.duels_won / (player.duels_won + player.duels_lost)) * 100);

    return (
      <Card className={`border-2 ${teamColor}`}>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">{player.player_name}</CardTitle>
            <div className="flex flex-col items-end">
              <Badge className="mb-1">{teamName}</Badge>
              <Badge className={`${getRatingColor(basicsRating)} border-0`}>
                BASICS: {basicsRating}/10
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* BASICS Core Elements */}
            <div className="space-y-3">
              <h4 className="font-semibold text-blue-600 border-b pb-1">BASICS Elements</h4>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">Pass Accuracy</span>
                  <span className="font-bold">{player.basics_passing_accuracy}%</span>
                </div>
                <Progress 
                  value={player.basics_passing_accuracy} 
                  className={`h-3 ${getAccuracyColor(player.basics_passing_accuracy)}`} 
                />
              </div>

              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">First Touch Success</span>
                  <span className="font-bold">{player.basics_first_touch_success}%</span>
                </div>
                <Progress 
                  value={player.basics_first_touch_success} 
                  className={`h-3 ${getAccuracyColor(player.basics_first_touch_success)}`} 
                />
              </div>

              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">Ball Control</span>
                  <span className="font-bold">{player.basics_ball_control_rating}/10</span>
                </div>
                <Progress 
                  value={player.basics_ball_control_rating * 10} 
                  className="h-3" 
                />
              </div>

              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">Positioning</span>
                  <span className="font-bold">{player.basics_positioning_score}/10</span>
                </div>
                <Progress 
                  value={player.basics_positioning_score * 10} 
                  className="h-3" 
                />
              </div>
            </div>

            {/* Match Performance */}
            <div className="space-y-3">
              <h4 className="font-semibold text-green-600 border-b pb-1">Match Performance</h4>
              
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-white p-2 rounded border">
                  <div className="font-medium text-gray-600">Passes</div>
                  <div className="text-lg font-bold">{player.successful_passes}/{player.successful_passes + player.failed_passes}</div>
                  <div className="text-xs text-gray-500">{passSuccess}% success</div>
                </div>

                <div className="bg-white p-2 rounded border">
                  <div className="font-medium text-gray-600">Key Passes</div>
                  <div className="text-lg font-bold text-blue-600">{player.key_passes}</div>
                  <div className="text-xs text-gray-500">creating chances</div>
                </div>

                <div className="bg-white p-2 rounded border">
                  <div className="font-medium text-gray-600">Tackles</div>
                  <div className="text-lg font-bold">{player.tackles_won}/{player.tackles_won + player.tackles_lost}</div>
                  <div className="text-xs text-gray-500">{tackleSuccess}% success</div>
                </div>

                <div className="bg-white p-2 rounded border">
                  <div className="font-medium text-gray-600">Duels</div>
                  <div className="text-lg font-bold">{player.duels_won}/{player.duels_won + player.duels_lost}</div>
                  <div className="text-xs text-gray-500">{duelSuccess}% success</div>
                </div>

                <div className="bg-white p-2 rounded border col-span-2">
                  <div className="font-medium text-gray-600">Interceptions</div>
                  <div className="text-lg font-bold text-purple-600">{player.interceptions}</div>
                  <div className="text-xs text-gray-500">defensive reading</div>
                </div>
              </div>
            </div>
          </div>

          {/* BASICS Skills Breakdown */}
          <div className="border-t pt-3">
            <h5 className="font-medium text-gray-700 mb-2">BASICS Skills Analysis</h5>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              <div className="text-center p-2 bg-blue-50 rounded">
                <div className="font-bold text-blue-600">{player.basics_passing_accuracy}%</div>
                <div>Pass Precision</div>
              </div>
              <div className="text-center p-2 bg-green-50 rounded">
                <div className="font-bold text-green-600">{player.basics_first_touch_success}%</div>
                <div>Touch Control</div>
              </div>
              <div className="text-center p-2 bg-purple-50 rounded">
                <div className="font-bold text-purple-600">{player.basics_ball_control_rating}/10</div>
                <div>Ball Mastery</div>
              </div>
              <div className="text-center p-2 bg-orange-50 rounded">
                <div className="font-bold text-orange-600">{player.basics_positioning_score}/10</div>
                <div>Field Awareness</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  // Team comparison stats
  const vvcPlayers = players.filter(p => p.team === 'home');
  const sveltaPlayers = players.filter(p => p.team === 'away');
  
  const getTeamAverages = (teamPlayers: IndividualBasics[]) => {
    if (teamPlayers.length === 0) return null;
    
    return {
      avgPassAccuracy: Math.round(teamPlayers.reduce((sum, p) => sum + p.basics_passing_accuracy, 0) / teamPlayers.length),
      avgFirstTouch: Math.round(teamPlayers.reduce((sum, p) => sum + p.basics_first_touch_success, 0) / teamPlayers.length),
      avgBallControl: Math.round((teamPlayers.reduce((sum, p) => sum + p.basics_ball_control_rating, 0) / teamPlayers.length) * 10) / 10,
      avgPositioning: Math.round((teamPlayers.reduce((sum, p) => sum + p.basics_positioning_score, 0) / teamPlayers.length) * 10) / 10,
    };
  };

  const vvcAverages = getTeamAverages(vvcPlayers);
  const sveltaAverages = getTeamAverages(sveltaPlayers);

  return (
    <div className="container mx-auto p-4">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Individual BASICS Analysis</h1>
        <p className="text-gray-600">IADATABANK BASICS Elements - Individual Player Performance</p>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-2">
          <label className="text-sm font-medium">Team:</label>
          <Select value={selectedTeam} onValueChange={setSelectedTeam}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="both">Both Teams</SelectItem>
              <SelectItem value="home">VVC Brasschaat</SelectItem>
              <SelectItem value="away">Svelta Melsele</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-sm font-medium">Player:</label>
          <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Players</SelectItem>
              {players.map((player, index) => (
                <SelectItem key={index} value={player.player_name}>
                  {player.player_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Team Comparison */}
      {selectedTeam === "both" && vvcAverages && sveltaAverages && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Card className="border-red-500 border-2">
            <CardHeader>
              <CardTitle className="text-red-600">VVC Brasschaat - Team BASICS</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>Pass Accuracy: <span className="font-bold">{vvcAverages.avgPassAccuracy}%</span></div>
                <div>First Touch: <span className="font-bold">{vvcAverages.avgFirstTouch}%</span></div>
                <div>Ball Control: <span className="font-bold">{vvcAverages.avgBallControl}/10</span></div>
                <div>Positioning: <span className="font-bold">{vvcAverages.avgPositioning}/10</span></div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-500 border-2">
            <CardHeader>
              <CardTitle className="text-blue-600">Svelta Melsele - Team BASICS</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>Pass Accuracy: <span className="font-bold">{sveltaAverages.avgPassAccuracy}%</span></div>
                <div>First Touch: <span className="font-bold">{sveltaAverages.avgFirstTouch}%</span></div>
                <div>Ball Control: <span className="font-bold">{sveltaAverages.avgBallControl}/10</span></div>
                <div>Positioning: <span className="font-bold">{sveltaAverages.avgPositioning}/10</span></div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Individual Player Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredPlayers.map((player, index) => (
          <PlayerBasicsCard key={index} player={player} />
        ))}
      </div>

      {filteredPlayers.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <p>No players found with current filters.</p>
        </div>
      )}
    </div>
  );
};

export default IndividualBasics;