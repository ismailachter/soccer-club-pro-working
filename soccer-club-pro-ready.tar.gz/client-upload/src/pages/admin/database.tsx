import { useState, useRef, ChangeEvent } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, RefreshCw, Database, ArrowUpCircle, Upload, FileUp, Download, AlertTriangle, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

export default function DatabaseAdmin() {
  const [sqlQuery, setSqlQuery] = useState("");
  const [activeTab, setActiveTab] = useState("execute");
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [pushLoading, setPushLoading] = useState(false);
  const [selectedTable, setSelectedTable] = useState("");
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [csvData, setCsvData] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { user, hasPermission } = useAuth();

  // Execute custom SQL query
  const executeMutation = useMutation({
    mutationFn: async (query: string) => {
      const response = await apiRequest<any>('/api/admin/database/execute', {
        method: 'POST',
        body: JSON.stringify({ query }),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Query executed successfully",
        description: "The SQL query has been executed successfully.",
        variant: "default",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error executing query",
        description: error.message || "An error occurred while executing the query.",
        variant: "destructive",
      });
    },
  });

  // Push schema changes to database
  const handlePushSchema = async () => {
    setPushLoading(true);
    try {
      await apiRequest('/api/admin/database/push', {
        method: 'POST',
      });
      toast({
        title: "Schema updated",
        description: "The database schema has been updated successfully.",
        variant: "default",
      });
      setIsConfirmDialogOpen(false);
    } catch (error: any) {
      toast({
        title: "Error updating schema",
        description: error.message || "An error occurred while updating the schema.",
        variant: "destructive",
      });
    } finally {
      setPushLoading(false);
    }
  };

  // Get database schema information
  const { data: schemaInfo, isLoading: schemaLoading, refetch: refetchSchema } = useQuery({
    queryKey: ['/api/admin/database/schema'],
    refetchOnWindowFocus: false,
  });

  // Get database tables and counts
  const { data: tablesData, isLoading: tablesLoading, refetch: refetchTables } = useQuery({
    queryKey: ['/api/admin/database/tables'],
    refetchOnWindowFocus: false,
  });

  // Handle CSV import
  const importMutation = useMutation({
    mutationFn: async ({ table, csvData }: { table: string; csvData: string }) => {
      const response = await apiRequest('/api/admin/database/import', {
        method: 'POST',
        body: JSON.stringify({ table, csvData }),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Data imported successfully",
        description: "The CSV data has been imported into the table.",
        variant: "default",
      });
      setImportDialogOpen(false);
      handleRefresh();
    },
    onError: (error: any) => {
      toast({
        title: "Error importing data",
        description: error.message || "An error occurred while importing the data.",
        variant: "destructive",
      });
    },
  });

  // Handle CSV export
  const exportMutation = useMutation({
    mutationFn: async (table: string) => {
      const response = await apiRequest<{ csv: string }>('/api/admin/database/export', {
        method: 'POST',
        body: JSON.stringify({ table }),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return response;
    },
    onSuccess: (data) => {
      // Trigger download
      const blob = new Blob([data.csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.setAttribute('hidden', '');
      a.setAttribute('href', url);
      a.setAttribute('download', `${selectedTable}.csv`);
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setExportDialogOpen(false);
      
      toast({
        title: "Data exported successfully",
        description: `The table data has been exported to ${selectedTable}.csv`,
        variant: "default",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error exporting data",
        description: error.message || "An error occurred while exporting the data.",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setCsvData(event.target.result as string);
      }
    };
    reader.readAsText(file);
  };

  const handleImport = () => {
    if (!selectedTable || !csvData) {
      toast({
        title: "Missing information",
        description: "Please select a table and upload a CSV file.",
        variant: "destructive",
      });
      return;
    }

    importMutation.mutate({ table: selectedTable, csvData });
  };

  const handleExport = () => {
    if (!selectedTable) {
      toast({
        title: "Missing table",
        description: "Please select a table to export.",
        variant: "destructive",
      });
      return;
    }

    exportMutation.mutate(selectedTable);
  };

  const handleRefresh = () => {
    refetchSchema();
    refetchTables();
  };

  const handleExecuteQuery = () => {
    if (!sqlQuery.trim()) {
      toast({
        title: "Empty query",
        description: "Please enter a SQL query to execute.",
        variant: "destructive",
      });
      return;
    }
    executeMutation.mutate(sqlQuery);
  };

  // Check permission for database access
  const canAccessDatabase = user && hasPermission('database', 'admin');
  const canImportExport = user && hasPermission('database', 'write');
  const canViewSchema = user && hasPermission('database', 'read');
  
  if (!canViewSchema) {
    return (
      <div className="container p-6 mx-auto">
        <div className="flex flex-col items-center justify-center h-96 text-center">
          <Lock className="h-16 w-16 text-muted-foreground mb-4" />
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-muted-foreground">
            You don't have permission to access the database administration area.
            Please contact your administrator for assistance.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="container p-6 mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Database Administration</h1>
        <div className="flex gap-2">
          {canImportExport && (
            <>
              <Button 
                onClick={() => setImportDialogOpen(true)} 
                variant="outline" 
                className="flex gap-2"
              >
                <Upload className="h-4 w-4" />
                Import CSV
              </Button>
              <Button 
                onClick={() => setExportDialogOpen(true)} 
                variant="outline" 
                className="flex gap-2"
              >
                <Download className="h-4 w-4" />
                Export CSV
              </Button>
            </>
          )}
          {canAccessDatabase && (
            <Button 
              onClick={() => window.open('/api/admin/export/excel', '_blank')} 
              variant="outline" 
              className="flex gap-2"
            >
              <Download className="h-4 w-4" />
              Export Excel
            </Button>
          )}
          {canAccessDatabase && (
            <Button 
              onClick={() => window.open('/api/admin/export/json', '_blank')} 
              variant="outline" 
              className="flex gap-2"
            >
              <Download className="h-4 w-4" />
              Export JSON
            </Button>
          )}
          {canAccessDatabase && (
            <Button 
              onClick={() => window.open('/api/admin/export/xml', '_blank')} 
              variant="outline" 
              className="flex gap-2"
            >
              <Download className="h-4 w-4" />
              Export XML
            </Button>
          )}
          {canAccessDatabase && (
            <Button 
              onClick={() => window.open('/api/admin/export/sql', '_blank')} 
              variant="outline" 
              className="flex gap-2"
            >
              <Download className="h-4 w-4" />
              Export SQL
            </Button>
          )}
          <Button onClick={handleRefresh} variant="outline" className="flex gap-2">
            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          {canAccessDatabase && <TabsTrigger value="execute">Execute SQL</TabsTrigger>}
          <TabsTrigger value="schema">Schema Information</TabsTrigger>
          <TabsTrigger value="tables">Tables</TabsTrigger>
        </TabsList>

        {canAccessDatabase && (
          <TabsContent value="execute" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Execute SQL Query</CardTitle>
                <CardDescription>
                  Enter a SQL query to execute directly on the database. Use with caution.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="SELECT * FROM users LIMIT 10;"
                  className="font-mono h-40"
                  value={sqlQuery}
                  onChange={(e) => setSqlQuery(e.target.value)}
                />
                <div className="flex justify-end">
                  <Button 
                    onClick={handleExecuteQuery}
                    disabled={executeMutation.isPending}
                    className="flex gap-2"
                  >
                    {executeMutation.isPending && (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    )}
                    Execute Query
                  </Button>
                </div>

                {executeMutation.isSuccess && (
                  <div className="mt-4">
                    <h3 className="font-medium mb-2">Results:</h3>
                    <div className="bg-muted p-4 rounded-md overflow-auto max-h-80">
                      <pre className="text-sm font-mono">
                        {typeof executeMutation.data === 'object' 
                          ? JSON.stringify(executeMutation.data, null, 2)
                          : String(executeMutation.data)}
                      </pre>
                    </div>
                  </div>
                )}

                {executeMutation.isError && (
                  <div className="mt-4 p-4 bg-destructive/10 text-destructive rounded-md">
                    <h3 className="font-medium mb-2">Error:</h3>
                    <p className="font-mono text-sm">{String(executeMutation.error)}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Push Schema Changes</CardTitle>
                <CardDescription>
                  Update the database schema to match the current code definition.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => setIsConfirmDialogOpen(true)}
                  className="flex gap-2"
                  variant="outline"
                >
                  <ArrowUpCircle className="h-4 w-4" />
                  Push Schema Changes
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        <TabsContent value="schema" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Schema Information</CardTitle>
              <CardDescription>
                Current database schema information and structure.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {schemaLoading ? (
                <div className="flex justify-center py-10">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : schemaInfo ? (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-2">Database Type:</h3>
                    <p className="text-muted-foreground">{schemaInfo.type || 'PostgreSQL'}</p>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Tables:</h3>
                    <div className="bg-muted p-4 rounded-md overflow-auto max-h-96">
                      <pre className="text-sm font-mono">
                        {JSON.stringify(schemaInfo.tables, null, 2)}
                      </pre>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground">No schema information available.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tables" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Database Tables</CardTitle>
              <CardDescription>
                List of tables and record counts in the database.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {tablesLoading ? (
                <div className="flex justify-center py-10">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : tablesData?.tables?.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Table Name</TableHead>
                      <TableHead className="text-right">Row Count</TableHead>
                      {canImportExport && <TableHead className="text-right">Actions</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tablesData.tables.map((table: any) => (
                      <TableRow key={table.name}>
                        <TableCell className="font-medium">{table.name}</TableCell>
                        <TableCell className="text-right">{table.count}</TableCell>
                        {canImportExport && (
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                onClick={() => {
                                  setSelectedTable(table.name);
                                  setExportDialogOpen(true);
                                }}
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0"
                                title="Export Data"
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                              <Button
                                onClick={() => {
                                  setSelectedTable(table.name);
                                  setImportDialogOpen(true);
                                }}
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0"
                                title="Import Data"
                              >
                                <Upload className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-muted-foreground">No tables found in database.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Push Schema Changes Dialog */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Push Schema Changes</DialogTitle>
            <DialogDescription>
              This will update the database schema to match the current code definition. 
              This operation might alter or drop tables. Make sure you have a backup before proceeding.
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handlePushSchema} disabled={pushLoading} className="flex gap-2">
              {pushLoading && <Loader2 className="h-4 w-4 animate-spin" />}
              Push Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import CSV Dialog */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import CSV Data</DialogTitle>
            <DialogDescription>
              Import data from a CSV file into the selected table.
              Make sure the CSV file columns match the table structure.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {!selectedTable && (
              <div className="space-y-2">
                <Label htmlFor="table-select">Select Table</Label>
                <Select value={selectedTable} onValueChange={setSelectedTable}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a table" />
                  </SelectTrigger>
                  <SelectContent>
                    {tablesData?.tables?.map((table: any) => (
                      <SelectItem key={table.name} value={table.name}>
                        {table.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="csv-file">Upload CSV File</Label>
              <Input
                id="csv-file"
                type="file"
                accept=".csv"
                ref={fileInputRef}
                onChange={handleFileUpload}
              />
            </div>

            {csvData && (
              <div className="space-y-2">
                <Label>CSV Preview</Label>
                <div className="bg-muted p-2 rounded-md overflow-auto max-h-40">
                  <pre className="text-xs font-mono">
                    {csvData.substring(0, 500)}
                    {csvData.length > 500 && '...'}
                  </pre>
                </div>
              </div>
            )}

            <Alert className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Warning</AlertTitle>
              <AlertDescription>
                Importing data may overwrite existing records. 
                Make sure you have a backup of your data before proceeding.
              </AlertDescription>
            </Alert>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setImportDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleImport} 
              disabled={importMutation.isPending || !csvData || !selectedTable}
              className="flex gap-2"
            >
              {importMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Import Data
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Export CSV Dialog */}
      <Dialog open={exportDialogOpen} onOpenChange={setExportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Export CSV Data</DialogTitle>
            <DialogDescription>
              Export data from the selected table to a CSV file.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {!selectedTable && (
              <div className="space-y-2">
                <Label htmlFor="export-table-select">Select Table</Label>
                <Select value={selectedTable} onValueChange={setSelectedTable}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a table" />
                  </SelectTrigger>
                  <SelectContent>
                    {tablesData?.tables?.map((table: any) => (
                      <SelectItem key={table.name} value={table.name}>
                        {table.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setExportDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleExport} 
              disabled={exportMutation.isPending || !selectedTable}
              className="flex gap-2"
            >
              {exportMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Export Data
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}