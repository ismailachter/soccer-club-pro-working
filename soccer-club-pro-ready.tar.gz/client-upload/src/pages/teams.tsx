import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft,
  Users,
  Calendar,
  FileText,
  BarChart3,
  Trophy,
  Target,
  Clock,
  MapPin,
  UserCheck,
  ChevronRight,
} from "lucide-react";

interface Team {
  id: number;
  name: string;
  ageGroup: string;
  description: string;
  foundedDate: string | null;
  logo: string | null;
  primaryCoachId: number | null;
  createdAt: string;
}

interface TrainingPlan {
  id: number;
  name: string;
  description: string;
  ageGroup: string;
  teamId?: number;
  teamName?: string;
  season: string;
  startDate: string;
  endDate: string;
  totalWeeks: number;
  sessionsPerWeek: number;
  trainingDays: string[];
  created: string;
  status: "draft" | "active" | "completed";
}

interface Player {
  id: number;
  teamId: number;
  user?: {
    firstName: string;
    lastName: string;
    email: string;
  };
}

export default function Teams() {
  const [selectedTeamId, setSelectedTeamId] = useState<number | null>(null);

  const { data: teams = [], isLoading: teamsLoading } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: trainingPlans = [], isLoading: plansLoading } = useQuery<TrainingPlan[]>({
    queryKey: ["/api/jaarplanning"],
  });

  const { data: players = [], isLoading: playersLoading } = useQuery<Player[]>({
    queryKey: ["/api/players"],
  });

  const getAgeGroupColor = (ageGroup: string) => {
    switch (ageGroup.toLowerCase()) {
      case 'u20':
      case 'u19':
      case 'u18':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'senior-a':
      case 'senior-b':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'mixed':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTeamPlayers = (teamId: number) => {
    return players.filter(player => player.teamId === teamId);
  };

  const getTeamPlans = (teamId: number) => {
    return trainingPlans.filter(plan => plan.teamId === teamId);
  };

  if (teamsLoading || plansLoading || playersLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="h-64 bg-gray-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Terug naar Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-4xl font-bold text-gray-900 flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center text-white">
                  <Users className="h-6 w-6" />
                </div>
                Teams Beheer
              </h1>
              <p className="text-gray-600 mt-2">
                Overzicht van alle teams met directe toegang tot roosters en jaarplanningen
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Link href="/jaarplanning">
              <Button>
                <Calendar className="h-4 w-4 mr-2" />
                Jaarplanning Beheer
              </Button>
            </Link>
            <Link href="/players-database">
              <Button variant="outline">
                <Users className="h-4 w-4 mr-2" />
                Spelers Database
              </Button>
            </Link>
            <Link href="/scout-database">
              <Button variant="outline">
                <Users className="h-4 w-4 mr-2" />
                Scouting Database
              </Button>
            </Link>
          </div>
        </div>

        {/* Teams Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teams.map(team => {
            const teamPlayers = getTeamPlayers(team.id);
            const teamPlans = getTeamPlans(team.id);
            const activePlans = teamPlans.filter(plan => plan.status === 'active');
            
            return (
              <Card key={team.id} className="group hover:shadow-xl transition-all duration-300 border-2 hover:border-blue-300 bg-white">
                <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl font-bold flex items-center gap-2">
                        <Trophy className="h-5 w-5" />
                        {team.name}
                      </CardTitle>
                      <CardDescription className="text-blue-100 mt-1">
                        {team.description || 'Geen beschrijving'}
                      </CardDescription>
                    </div>
                    <Badge className={`${getAgeGroupColor(team.ageGroup)} font-medium`}>
                      {team.ageGroup.toUpperCase()}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="p-6 space-y-4">
                  {/* Team Statistics */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{teamPlayers.length}</div>
                      <div className="text-xs text-gray-600">Spelers</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{activePlans.length}</div>
                      <div className="text-xs text-gray-600">Actieve Plannen</div>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">{teamPlans.length}</div>
                      <div className="text-xs text-gray-600">Totaal Plannen</div>
                    </div>
                  </div>

                  {/* Team Kalender Widget */}
                  <div className="space-y-2">
                    <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Deze Week
                    </h4>
                    <div className="bg-gray-50 rounded-lg p-3 space-y-2">
                      {(() => {
                        const now = new Date();
                        const weekStart = new Date(now);
                        weekStart.setDate(now.getDate() - now.getDay() + 1); // Monday
                        const weekEnd = new Date(weekStart);
                        weekEnd.setDate(weekStart.getDate() + 6); // Sunday

                        const weekSessions = teamPlans.flatMap(plan => 
                          plan.trainingDays?.map((day: string, index: number) => {
                            const dayIndex = ['maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag', 'zondag'].indexOf(day.toLowerCase());
                            if (dayIndex === -1) return null;
                            
                            const sessionDate = new Date(weekStart);
                            sessionDate.setDate(weekStart.getDate() + dayIndex);
                            
                            return {
                              date: sessionDate,
                              day: day,
                              time: '20:00', // Default time
                              type: 'training',
                              location: 'VVC Brasschaat'
                            };
                          }).filter(Boolean) || []
                        );

                        if (weekSessions.length === 0) {
                          return (
                            <div className="text-center text-sm text-gray-500 py-2">
                              Geen trainingen deze week
                            </div>
                          );
                        }

                        return weekSessions.slice(0, 3).map((session: any, index: number) => (
                          <div key={index} className="flex items-center justify-between text-sm bg-white rounded p-2">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                              <span className="font-medium capitalize">{session.day}</span>
                            </div>
                            <div className="text-gray-600 flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {session.time}
                            </div>
                          </div>
                        ));
                      })()}
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="space-y-2">
                    <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      Snelle Acties
                    </h4>
                    
                    {/* Roster Link */}
                    <Link href={`/spelers?team=${team.id}`}>
                      <Button variant="outline" className="w-full justify-between group-hover:bg-blue-50">
                        <span className="flex items-center gap-2">
                          <UserCheck className="h-4 w-4" />
                          Team Roster ({teamPlayers.length} spelers)
                        </span>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </Link>

                    {/* Team Planning Links */}
                    {activePlans.length > 0 ? (
                      <div className="space-y-1">
                        {activePlans.slice(0, 2).map(plan => (
                          <Link key={plan.id} href={`/jaarplanning?team=${team.id}&plan=${plan.id}`}>
                            <Button variant="outline" className="w-full justify-between text-left group-hover:bg-green-50">
                              <span className="flex items-center gap-2">
                                <Calendar className="h-4 w-4" />
                                <div className="text-left">
                                  <div className="font-medium truncate">{plan.name}</div>
                                  <div className="text-xs text-gray-500">{plan.season}</div>
                                </div>
                              </span>
                              <ChevronRight className="h-4 w-4" />
                            </Button>
                          </Link>
                        ))}
                        {activePlans.length > 2 && (
                          <Link href={`/jaarplanning?team=${team.id}`}>
                            <Button variant="ghost" className="w-full text-sm text-blue-600">
                              +{activePlans.length - 2} meer plannen bekijken
                            </Button>
                          </Link>
                        )}
                      </div>
                    ) : (
                      <Link href={`/jaarplanning?team=${team.id}`}>
                        <Button variant="outline" className="w-full justify-between group-hover:bg-yellow-50">
                          <span className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            Nieuwe Jaarplanning Maken
                          </span>
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </Link>
                    )}

                    {/* Team Week Overview */}
                    <Link href={`/calendar?team=${team.id}`}>
                      <Button variant="outline" className="w-full justify-between group-hover:bg-purple-50">
                        <span className="flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          Team Weekoverzicht
                        </span>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  </div>

                  {/* Team Details */}
                  <div className="pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        Opgericht: {team.foundedDate ? new Date(team.foundedDate).toLocaleDateString('nl-NL') : 'Onbekend'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Empty State */}
        {teams.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <Users className="h-16 w-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Geen Teams Gevonden</h3>
              <p className="text-gray-600 mb-6">
                Er zijn nog geen teams aangemaakt in het systeem.
              </p>
              <Button>
                <Users className="h-4 w-4 mr-2" />
                Nieuw Team Toevoegen
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Summary Statistics */}
        <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <BarChart3 className="h-6 w-6" />
              Club Overzicht
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold">{teams.length}</div>
                <div className="text-blue-100">Totaal Teams</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold">{players.length}</div>
                <div className="text-blue-100">Totaal Spelers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold">{trainingPlans.length}</div>
                <div className="text-blue-100">Jaarplanningen</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold">
                  {trainingPlans.filter(plan => plan.status === 'active').length}
                </div>
                <div className="text-blue-100">Actieve Plannen</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}