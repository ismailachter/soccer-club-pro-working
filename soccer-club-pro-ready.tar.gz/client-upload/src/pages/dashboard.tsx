import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  User, 
  ShieldCheck, 
  CalendarRange, 
  MapPin,
  Download,
  FileText
} from "lucide-react";
import { StatsCard } from "@/components/dashboard/stats-card";
import { RecentActivity } from "@/components/dashboard/recent-activity";
import { UpcomingMatches } from "@/components/dashboard/upcoming-matches";
import { TeamPerformance } from "@/components/dashboard/team-performance";
import { FieldStatus } from "@/components/dashboard/field-status";
import { DashboardStats, ActivityItem, UpcomingMatchData, TeamPerformanceData, FieldStatusData } from "@/types";
import { queryClient } from "@/lib/queryClient";

export default function Dashboard() {
  // Fetch dashboard stats
  const { 
    data: stats,
    isLoading: isLoadingStats,
    error: statsError
  } = useQuery<DashboardStats>({
    queryKey: ['/api/stats/dashboard'],
  });

  // Fetch upcoming matches
  const {
    data: matches,
    isLoading: isLoadingMatches,
    error: matchesError
  } = useQuery<UpcomingMatchData[]>({
    queryKey: ['/api/matches?status=scheduled'],
  });

  // Sample team performance data
  const teamPerformance: TeamPerformanceData[] = [
    { id: 1, name: 'U14 Lions', performance: 85 },
    { id: 2, name: 'U16 Eagles', performance: 72 },
    { id: 3, name: 'U12 Tigers', performance: 65 },
    { id: 4, name: 'U10 Panthers', performance: 58 }
  ];

  // Sample recent activities
  const recentActivities: ActivityItem[] = [
    {
      id: 1,
      type: 'new_player',
      content: 'was added to U14 Lions',
      timestamp: new Date(Date.now() - 10 * 60 * 1000).toISOString(), // 10 minutes ago
      entities: [{ name: 'Alex Johnson' }]
    },
    {
      id: 2,
      type: 'match_result',
      content: 'won their match against Riverside FC (3-1)',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
      entities: [{ name: 'U16 Eagles' }]
    },
    {
      id: 3,
      type: 'training_scheduled',
      content: 'scheduled a new training session for U12 Tigers',
      timestamp: new Date(Date.now() - 25 * 60 * 60 * 1000).toISOString(), // 25 hours ago
      entities: [{ name: 'Coach Sarah' }]
    },
    {
      id: 4,
      type: 'field_maintenance',
      content: 'maintenance scheduled for next Monday',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
      entities: [{ name: 'Main Field' }]
    }
  ];

  // Fetch field status
  const { 
    data: pitches,
    isLoading: isLoadingPitches, 
    error: pitchesError
  } = useQuery<FieldStatusData[]>({
    queryKey: ['/api/pitches'], 
    select: (data) => data.map(pitch => ({
      id: pitch.id,
      name: pitch.name,
      status: pitch.status
    }))
  });

  if (isLoadingStats || isLoadingMatches || isLoadingPitches) {
    return <div className="p-8 text-center">Loading dashboard data...</div>;
  }

  if (statsError || matchesError || pitchesError) {
    return <div className="p-8 text-center text-red-500">Error loading dashboard data.</div>;
  }

  return (
    <>
      {/* Stats overview */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mt-5">
        <StatsCard
          title="Total Players"
          value={stats?.totalPlayers || 0}
          subtitle="Ready to play"
          icon={<User className="h-5 w-5" />}
          trend={{ value: "8% increase", positive: true }}
        />
        <StatsCard
          title="Active Teams"
          value={stats?.activeTeams || 0}
          subtitle="All teams active"
          icon={<ShieldCheck className="h-5 w-5" />}
          iconColorClass="bg-blue-100 text-blue-600"
        />
        <StatsCard
          title="Upcoming Matches"
          value={stats?.upcomingMatches || 0}
          subtitle="Next: Saturday 10:00"
          icon={<CalendarRange className="h-5 w-5" />}
          iconColorClass="bg-amber-100 text-amber-600"
        />
        <StatsCard
          title="Field Utilization"
          value={`${stats?.fieldUtilization || 0}%`}
          subtitle={`${stats?.availableFields || 0} fields available now`}
          icon={<MapPin className="h-5 w-5" />}
          iconColorClass="bg-purple-100 text-purple-600"
        />
      </div>

      {/* Professional Training Quick Access */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg p-6 text-white mt-8">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
              <FileText className="h-6 w-6" />
              Professionele Training Ready
            </h3>
            <p className="text-blue-100 mb-4">
              Je 3-4-3 opbouw training (90 min, 16 speelsters) met veldtekeningen is klaar
            </p>
          </div>
          <Link href="/training-pdf">
            <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors flex items-center gap-2">
              <Download className="h-5 w-5" />
              Download PDF Training
            </button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
        {/* Left column */}
        <div className="col-span-2 space-y-6">
          {/* Recent activity */}
          <RecentActivity activities={recentActivities} />

          {/* Upcoming matches */}
          <UpcomingMatches matches={matches || []} />
        </div>

        {/* Right column */}
        <div className="space-y-6">
          {/* Team performance */}
          <TeamPerformance teams={teamPerformance} />

          {/* Field status */}
          <FieldStatus fields={pitches || []} />
        </div>
      </div>
    </>
  );
}
