import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar, Plus, Edit, Trash2, Download, FileText, Calendar as CalendarIcon, Users, Clock, MapPin, AlertTriangle, CalendarCheck } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths } from "date-fns";
import { nl } from "date-fns/locale";

const weekdays = [
  { value: 'monday', label: 'Maandag' },
  { value: 'tuesday', label: 'Dinsdag' },
  { value: 'wednesday', label: 'Woensdag' },
  { value: 'thursday', label: 'Donderdag' },
  { value: 'friday', label: 'Vrijdag' },
  { value: 'saturday', label: 'Zaterdag' },
  { value: 'sunday', label: 'Zondag' }
];

const yearPlanSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  description: z.string().optional(),
  teamId: z.number().optional(),
  ageGroup: z.string().optional(),
  startDate: z.string().min(1, "Startdatum is verplicht"),
  endDate: z.string().min(1, "Einddatum is verplicht"),
  trainingDays: z.array(z.string()).min(1, "Selecteer minimaal één trainingsdag"),
  status: z.enum(['draft', 'active', 'completed', 'archived']).default('draft')
});

const periodSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  description: z.string().optional(),
  startDate: z.string().min(1, "Startdatum is verplicht"),
  endDate: z.string().min(1, "Einddatum is verplicht"),
  focusThemes: z.array(z.string()).default([]),
  color: z.string().default('#3B82F6'),
  sortOrder: z.number().default(0)
});

type YearPlanFormData = z.infer<typeof yearPlanSchema>;
type PeriodFormData = z.infer<typeof periodSchema>;

interface YearPlan {
  id: number;
  name: string;
  description?: string;
  teamId?: number;
  ageGroup?: string;
  startDate: string;
  endDate: string;
  status: string;
  trainingDays: string[];
  team?: { id: number; name: string; };
  periods?: Period[];
  sessions?: Session[];
}

interface Period {
  id: number;
  yearPlanId: number;
  name: string;
  description?: string;
  startDate: string;
  endDate: string;
  focusThemes: string[];
  color: string;
  sortOrder: number;
}

interface Session {
  id: number;
  yearPlanId: number;
  periodId?: number;
  date: string;
  themes: string[];
  notes?: string;
  duration?: number;
  location?: string;
  isCompleted: boolean;
}

export default function YearPlanningPage() {
  const [selectedPlan, setSelectedPlan] = useState<YearPlan | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPeriodDialogOpen, setIsPeriodDialogOpen] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState<number | null>(null);
  const [isCalendarPlannerOpen, setIsCalendarPlannerOpen] = useState(false);
  const [selectedPlanForCalendar, setSelectedPlanForCalendar] = useState<YearPlan | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch year plans
  const { data: yearPlans = [], isLoading } = useQuery<YearPlan[]>({
    queryKey: ['/api/year-plans'],
  });

  // Fetch teams
  const { data: teams = [] } = useQuery<any[]>({
    queryKey: ['/api/teams'],
  });

  // Fetch IADATABANK elements for themes
  const { data: iadatabank } = useQuery<{ data: any[] }>({
    queryKey: ['/api/iadatabank/elements'],
  });
  
  const iadatabankElements = iadatabank?.data || [];

  // Form for creating/editing year plans
  const form = useForm<YearPlanFormData>({
    resolver: zodResolver(yearPlanSchema),
    defaultValues: {
      name: "",
      description: "",
      ageGroup: "",
      startDate: "",
      endDate: "",
      trainingDays: [],
      status: 'draft'
    }
  });

  // Form for creating periods
  const periodForm = useForm<PeriodFormData>({
    resolver: zodResolver(periodSchema),
    defaultValues: {
      name: "",
      description: "",
      startDate: "",
      endDate: "",
      focusThemes: [],
      color: '#3B82F6',
      sortOrder: 0
    }
  });

  // Create year plan mutation
  const createYearPlan = useMutation({
    mutationFn: (data: YearPlanFormData) => apiRequest('POST', '/api/year-plans', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({ title: "Jaarplanning aangemaakt", description: "De nieuwe jaarplanning is succesvol aangemaakt." });
    },
    onError: (error) => {
      console.error('Year plan creation error:', error);
      toast({ title: "Fout", description: `Er is een fout opgetreden: ${error.message}`, variant: "destructive" });
    }
  });

  // Update year plan mutation
  const updateYearPlan = useMutation({
    mutationFn: ({ id, data }: { id: number; data: YearPlanFormData }) => 
      apiRequest('PUT', `/api/year-plans/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setIsEditDialogOpen(false);
      setSelectedPlan(null);
      form.reset();
      toast({ title: "Jaarplanning bijgewerkt", description: "De jaarplanning is succesvol bijgewerkt." });
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het bijwerken.", variant: "destructive" });
    }
  });

  // Delete year plan mutation with double confirmation
  const deleteYearPlan = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/year-plans/${id}`, {
      method: 'DELETE',
      headers: { 'x-confirm-delete': 'true' }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setDeleteConfirmation(null);
      toast({ title: "Jaarplanning verwijderd", description: "De jaarplanning is permanent verwijderd." });
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het verwijderen.", variant: "destructive" });
    }
  });

  // Create period mutation
  const createPeriod = useMutation({
    mutationFn: ({ planId, data }: { planId: number; data: PeriodFormData }) =>
      apiRequest(`/api/year-plans/${planId}/periods`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans'] });
      setIsPeriodDialogOpen(false);
      periodForm.reset();
      toast({ title: "Periode toegevoegd", description: "De nieuwe periode is toegevoegd aan de jaarplanning." });
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het toevoegen van de periode.", variant: "destructive" });
    }
  });

  const handleCreateSubmit = (data: YearPlanFormData) => {
    console.log('Submitting year plan data:', data);
    
    // Transform teamId to ensure proper format
    const transformedData = {
      ...data,
      teamId: data.teamId && data.teamId !== 'none' ? Number(data.teamId) : undefined
    };
    
    console.log('Transformed data:', transformedData);
    createYearPlan.mutate(transformedData, {
      onSuccess: () => {
        form.reset();
        setIsCreateDialogOpen(false);
      }
    });
  };

  const handleEditSubmit = (data: YearPlanFormData) => {
    if (selectedPlan) {
      updateYearPlan.mutate({ id: selectedPlan.id, data });
    }
  };

  const handlePeriodSubmit = (data: PeriodFormData) => {
    if (selectedPlan) {
      createPeriod.mutate({ planId: selectedPlan.id, data });
    }
  };

  const handleEdit = (plan: YearPlan) => {
    setSelectedPlan(plan);
    form.reset({
      name: plan.name,
      description: plan.description || "",
      teamId: plan.teamId,
      ageGroup: plan.ageGroup || "",
      startDate: plan.startDate,
      endDate: plan.endDate,
      trainingDays: plan.trainingDays || [],
      status: plan.status as any
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (deleteConfirmation === id) {
      deleteYearPlan.mutate(id);
    } else {
      setDeleteConfirmation(id);
      // Reset confirmation after 5 seconds
      setTimeout(() => setDeleteConfirmation(null), 5000);
    }
  };

  const handleExport = async (planId: number, format: 'pdf' | 'csv' | 'ics') => {
    try {
      const response = await fetch(`/api/year-plans/${planId}/export/${format}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
        }
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = response.headers.get('Content-Disposition')?.split('filename=')[1]?.replace(/"/g, '') || `jaarplanning.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({ title: "Export succesvol", description: `Jaarplanning geëxporteerd als ${format.toUpperCase()}` });
      } else {
        throw new Error('Export failed');
      }
    } catch (error) {
      toast({ title: "Export fout", description: "Er is een fout opgetreden bij het exporteren.", variant: "destructive" });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      default: return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Actief';
      case 'completed': return 'Voltooid';
      case 'archived': return 'Gearchiveerd';
      default: return 'Concept';
    }
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Laden...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Kalender Planning</h1>
          <p className="text-muted-foreground">
            Beheer training jaarplanningen met periodes en trainingsweekdagen
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => {
              console.log('Button clicked, opening dialog');
              setIsCreateDialogOpen(true);
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Nieuwe Jaarplanning
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Nieuwe Jaarplanning Maken</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleCreateSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Naam</FormLabel>
                      <FormControl>
                        <Input placeholder="bijv. Seizoen 2024-2025 U12" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Beschrijving</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Korte beschrijving van de jaarplanning..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="teamId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Team (optioneel)</FormLabel>
                        <Select onValueChange={(value) => field.onChange(value === 'none' ? undefined : parseInt(value))} value={field.value?.toString() || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecteer team" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">Geen specifiek team</SelectItem>
                            {teams.map((team: any) => (
                              <SelectItem key={team.id} value={team.id.toString()}>
                                {team.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="ageGroup"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Leeftijdsgroep</FormLabel>
                        <FormControl>
                          <Input placeholder="bijv. U12, U15, Senior" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Startdatum</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Einddatum</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="trainingDays"
                  render={() => (
                    <FormItem>
                      <FormLabel>Trainingsdagen</FormLabel>
                      <div className="grid grid-cols-3 gap-2">
                        {weekdays.map((day) => (
                          <FormField
                            key={day.value}
                            control={form.control}
                            name="trainingDays"
                            render={({ field }) => {
                              return (
                                <FormItem
                                  key={day.value}
                                  className="flex flex-row items-start space-x-3 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(day.value)}
                                      onCheckedChange={(checked) => {
                                        return checked
                                          ? field.onChange([...field.value, day.value])
                                          : field.onChange(
                                              field.value?.filter(
                                                (value) => value !== day.value
                                              )
                                            )
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal">
                                    {day.label}
                                  </FormLabel>
                                </FormItem>
                              )
                            }}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="draft">Concept</SelectItem>
                          <SelectItem value="active">Actief</SelectItem>
                          <SelectItem value="completed">Voltooid</SelectItem>
                          <SelectItem value="archived">Gearchiveerd</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Annuleren
                  </Button>
                  <Button type="submit" disabled={createYearPlan.isPending}>
                    {createYearPlan.isPending ? "Maken..." : "Jaarplanning Maken"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Year Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {yearPlans.map((plan) => (
          <Card key={plan.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge className={getStatusColor(plan.status)}>
                      {getStatusLabel(plan.status)}
                    </Badge>
                    {plan.team && (
                      <Badge variant="outline" className="text-xs">
                        <Users className="h-3 w-3 mr-1" />
                        {plan.team.name}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {plan.description && (
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              )}
              
              <div className="flex items-center gap-2 text-sm">
                <CalendarIcon className="h-4 w-4" />
                {format(new Date(plan.startDate), 'dd MMM yyyy', { locale: nl })} - {format(new Date(plan.endDate), 'dd MMM yyyy', { locale: nl })}
              </div>
              
              {plan.ageGroup && (
                <div className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4" />
                  {plan.ageGroup}
                </div>
              )}
              
              {plan.trainingDays && plan.trainingDays.length > 0 && (
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4" />
                  {plan.trainingDays.map(day => weekdays.find(w => w.value === day)?.label).join(', ')}
                </div>
              )}

              <div className="flex justify-between items-center pt-3 border-t">
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(plan)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant={deleteConfirmation === plan.id ? "destructive" : "outline"}
                    onClick={() => handleDelete(plan.id)}
                  >
                    {deleteConfirmation === plan.id ? (
                      <AlertTriangle className="h-3 w-3" />
                    ) : (
                      <Trash2 className="h-3 w-3" />
                    )}
                  </Button>
                </div>
                
                <div className="flex gap-1">
                  <Button 
                    size="sm" 
                    variant="default" 
                    onClick={() => {
                      setSelectedPlanForCalendar(plan);
                      setIsCalendarPlannerOpen(true);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <CalendarCheck className="h-3 w-3 mr-1" />
                    PLAN
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleExport(plan.id, 'pdf')}>
                    <FileText className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleExport(plan.id, 'csv')}>
                    <Download className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleExport(plan.id, 'ics')}>
                    <Calendar className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {yearPlans.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Geen jaarplanningen</h3>
          <p className="text-muted-foreground mb-4">Maak uw eerste jaarplanning om te beginnen.</p>
          <Button onClick={() => {
            console.log('Bottom button clicked, opening dialog');
            setIsCreateDialogOpen(true);
          }}>
            <Plus className="h-4 w-4 mr-2" />
            Nieuwe Jaarplanning
          </Button>
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Jaarplanning Bewerken</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleEditSubmit)} className="space-y-4">
              {/* Same form fields as create dialog */}
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naam</FormLabel>
                    <FormControl>
                      <Input placeholder="bijv. Seizoen 2024-2025 U12" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Beschrijving</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Korte beschrijving van de jaarplanning..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="teamId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team (optioneel)</FormLabel>
                      <Select onValueChange={(value) => field.onChange(value === 'none' ? undefined : parseInt(value))} value={field.value?.toString() || ""}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecteer team" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">Geen specifiek team</SelectItem>
                          {teams.map((team: any) => (
                            <SelectItem key={team.id} value={team.id.toString()}>
                              {team.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="ageGroup"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Leeftijdsgroep</FormLabel>
                      <FormControl>
                        <Input placeholder="bijv. U12, U15, Senior" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Startdatum</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Einddatum</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="trainingDays"
                render={() => (
                  <FormItem>
                    <FormLabel>Trainingsdagen</FormLabel>
                    <div className="grid grid-cols-3 gap-2">
                      {weekdays.map((day) => (
                        <FormField
                          key={day.value}
                          control={form.control}
                          name="trainingDays"
                          render={({ field }) => {
                            return (
                              <FormItem
                                key={day.value}
                                className="flex flex-row items-start space-x-3 space-y-0"
                              >
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(day.value)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, day.value])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== day.value
                                            )
                                          )
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal">
                                  {day.label}
                                </FormLabel>
                              </FormItem>
                            )
                          }}
                        />
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="draft">Concept</SelectItem>
                        <SelectItem value="active">Actief</SelectItem>
                        <SelectItem value="completed">Voltooid</SelectItem>
                        <SelectItem value="archived">Gearchiveerd</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Annuleren
                </Button>
                <Button type="submit" disabled={updateYearPlan.isPending}>
                  {updateYearPlan.isPending ? "Bijwerken..." : "Wijzigingen Opslaan"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Calendar Planner Dialog */}
      <Dialog open={isCalendarPlannerOpen} onOpenChange={setIsCalendarPlannerOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Kalender Planning - {selectedPlanForCalendar?.name}
            </DialogTitle>
          </DialogHeader>
          <CalendarPlanner 
            plan={selectedPlanForCalendar}
            iadatabankElements={iadatabankElements}
            onClose={() => setIsCalendarPlannerOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Calendar Planner Component
interface CalendarPlannerProps {
  plan: YearPlan | null;
  iadatabankElements: any[];
  onClose: () => void;
}

function CalendarPlanner({ plan, iadatabankElements, onClose }: CalendarPlannerProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [sessionNotes, setSessionNotes] = useState('');
  const [sessionDuration, setSessionDuration] = useState(90);
  const [sessionLocation, setSessionLocation] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get existing sessions for this plan
  const { data: sessions = [] } = useQuery<Session[]>({
    queryKey: ['/api/year-plans', plan?.id, 'sessions'],
    enabled: !!plan?.id,
  });

  // Save session mutation
  const saveSession = useMutation({
    mutationFn: (sessionData: any) => 
      apiRequest('POST', `/api/year-plans/${plan?.id}/sessions`, sessionData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/year-plans', plan?.id, 'sessions'] });
      toast({ title: "Training opgeslagen", description: "De training is succesvol toegevoegd aan de planning." });
      setSelectedDate(null);
      setSelectedThemes([]);
      setSessionNotes('');
      setSessionDuration(90);
      setSessionLocation('');
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het opslaan.", variant: "destructive" });
    }
  });

  if (!plan) return null;

  const startDate = new Date(plan.startDate);
  const endDate = new Date(plan.endDate);
  
  // Get days in current month view
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Filter training days based on plan settings
  const isTrainingDay = (date: Date) => {
    const dayName = format(date, 'EEEE').toLowerCase();
    const dayMapping: { [key: string]: string } = {
      'monday': 'monday',
      'tuesday': 'tuesday', 
      'wednesday': 'wednesday',
      'thursday': 'thursday',
      'friday': 'friday',
      'saturday': 'saturday',
      'sunday': 'sunday',
      'maandag': 'monday',
      'dinsdag': 'tuesday',
      'woensdag': 'wednesday',
      'donderdag': 'thursday',
      'vrijdag': 'friday',
      'zaterdag': 'saturday',
      'zondag': 'sunday'
    };
    return plan.trainingDays?.includes(dayMapping[dayName]) || false;
  };

  // Get session for a specific date
  const getSessionForDate = (date: Date) => {
    return sessions.find(session => 
      isSameDay(new Date(session.date), date)
    );
  };

  // Group IADATABANK elements by category
  const groupedElements = iadatabankElements.reduce((acc, element) => {
    if (!acc[element.topic]) {
      acc[element.topic] = [];
    }
    acc[element.topic].push(element);
    return acc;
  }, {} as { [key: string]: any[] });

  const handleSaveSession = () => {
    if (!selectedDate || selectedThemes.length === 0) {
      toast({ title: "Incomplete gegevens", description: "Selecteer een datum en minimaal één thema.", variant: "destructive" });
      return;
    }

    const sessionData = {
      date: format(selectedDate, 'yyyy-MM-dd'),
      themes: selectedThemes,
      notes: sessionNotes,
      duration: sessionDuration,
      location: sessionLocation,
      isCompleted: false
    };

    saveSession.mutate(sessionData);
  };

  return (
    <div className="space-y-6">
      {/* Calendar Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">
            {format(currentDate, 'MMMM yyyy', { locale: nl })}
          </h3>
          <p className="text-sm text-gray-600">
            {format(startDate, 'dd MMM yyyy', { locale: nl })} - {format(endDate, 'dd MMM yyyy', { locale: nl })}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setCurrentDate(subMonths(currentDate, 1))}
          >
            ← Vorige
          </Button>
          <Button
            variant="outline"
            onClick={() => setCurrentDate(addMonths(currentDate, 1))}
          >
            Volgende →
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Calendar Grid */}
        <div className="space-y-4">
          <div className="grid grid-cols-7 gap-1 text-sm">
            {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map(day => (
              <div key={day} className="p-2 text-center font-medium text-gray-500">
                {day}
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 gap-1">
            {daysInMonth.map(date => {
              const isInPlanPeriod = date >= startDate && date <= endDate;
              const isTraining = isTrainingDay(date);
              const hasSession = getSessionForDate(date);
              const isSelected = selectedDate && isSameDay(date, selectedDate);
              
              return (
                <button
                  key={date.toISOString()}
                  onClick={() => {
                    if (isInPlanPeriod && isTraining) {
                      setSelectedDate(date);
                      const existingSession = hasSession;
                      if (existingSession) {
                        setSelectedThemes(existingSession.themes || []);
                        setSessionNotes(existingSession.notes || '');
                        setSessionDuration(existingSession.duration || 90);
                        setSessionLocation(existingSession.location || '');
                      } else {
                        setSelectedThemes([]);
                        setSessionNotes('');
                        setSessionDuration(90);
                        setSessionLocation('');
                      }
                    }
                  }}
                  className={`
                    p-2 text-sm h-12 rounded-lg border transition-colors
                    ${!isSameMonth(date, currentDate) ? 'text-gray-300 bg-gray-50' : ''}
                    ${isSelected ? 'bg-blue-500 text-white' : ''}
                    ${!isSelected && isInPlanPeriod && isTraining ? 'bg-green-50 border-green-200 hover:bg-green-100' : ''}
                    ${!isSelected && hasSession ? 'bg-blue-50 border-blue-200' : ''}
                    ${!isInPlanPeriod || !isTraining ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}
                  `}
                  disabled={!isInPlanPeriod || !isTraining}
                >
                  <div className="font-medium">{format(date, 'd')}</div>
                  {hasSession && (
                    <div className="text-xs text-blue-600 mt-1">●</div>
                  )}
                </button>
              );
            })}
          </div>
          
          <div className="text-xs text-gray-500 space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-100 border border-green-200 rounded"></div>
              <span>Trainingsdag</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-100 border border-blue-200 rounded"></div>
              <span>Training gepland</span>
            </div>
          </div>
        </div>

        {/* Session Details */}
        <div className="space-y-4">
          {selectedDate ? (
            <>
              <div className="border rounded-lg p-4">
                <h4 className="font-semibold mb-2">
                  Training voor {format(selectedDate, 'dd MMMM yyyy', { locale: nl })}
                </h4>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Duur (minuten)</label>
                      <Input
                        type="number"
                        value={sessionDuration}
                        onChange={(e) => setSessionDuration(Number(e.target.value))}
                        min="30"
                        max="180"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Locatie</label>
                      <Input
                        value={sessionLocation}
                        onChange={(e) => setSessionLocation(e.target.value)}
                        placeholder="Trainingsveld"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Notities</label>
                    <Textarea
                      value={sessionNotes}
                      onChange={(e) => setSessionNotes(e.target.value)}
                      placeholder="Opmerkingen over de training..."
                      rows={3}
                    />
                  </div>
                </div>
              </div>

              {/* IADATABANK Theme Selection */}
              <div className="border rounded-lg p-4 max-h-96 overflow-y-auto">
                <h4 className="font-semibold mb-3">IADATABANK Thema's</h4>
                
                {Object.entries(groupedElements).map(([topic, elements]) => (
                  <div key={topic} className="mb-4">
                    <h5 className="font-medium text-sm text-gray-700 mb-2 uppercase tracking-wide">
                      {topic}
                    </h5>
                    <div className="space-y-1">
                      {elements.map((element) => (
                        <label key={element.id} className="flex items-center space-x-2 cursor-pointer p-2 rounded hover:bg-gray-50">
                          <Checkbox
                            checked={selectedThemes.includes(element.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedThemes([...selectedThemes, element.id]);
                              } else {
                                setSelectedThemes(selectedThemes.filter(id => id !== element.id));
                              }
                            }}
                          />
                          <div className="flex-1">
                            <div className="text-sm font-medium">{element.name}</div>
                            <div className="text-xs text-gray-500">{element.description}</div>
                          </div>
                          <Badge variant={element.level === 'B+' ? 'default' : 'secondary'}>
                            {element.level}
                          </Badge>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setSelectedDate(null)}>
                  Annuleren
                </Button>
                <Button onClick={handleSaveSession} disabled={saveSession.isPending}>
                  {saveSession.isPending ? 'Opslaan...' : 'Training Opslaan'}
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <CalendarIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Selecteer een trainingsdag om de planning te maken</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}