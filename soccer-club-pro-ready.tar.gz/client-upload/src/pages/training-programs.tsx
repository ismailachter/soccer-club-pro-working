import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, FileText, Download, Calendar, Upload } from "lucide-react";
import { jsPDF } from "jspdf";
import * as XLSX from 'xlsx';
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface TrainingProgram {
  id: number;
  name: string;
  startDate: string;
  endDate: string;
  trainingDays: string[];
  created: string;
}

interface FormData {
  name: string;
  startDate: string;
  endDate: string;
  trainingDays: string[];
}

export default function TrainingProgramsPage() {
  const trainingDayOptions = [
    { value: "monday", label: "Maandag" },
    { value: "tuesday", label: "Dinsdag" },
    { value: "wednesday", label: "Woensdag" },
    { value: "thursday", label: "Donderdag" },
    { value: "friday", label: "Vrijdag" },
    { value: "saturday", label: "Zaterdag" },
    { value: "sunday", label: "Zondag" }
  ];

  // Detailed training content
  const trainingDetails = {
    opwarming: [
      { naam: "Inlopen", duur: "5 min", beschrijving: "Rustig tempo, 60-65% max HR" },
      { naam: "Dynamische stretching", duur: "3 min", beschrijving: "Leg swings, arm circles, torso twists" },
      { naam: "Activatie", duur: "2 min", beschrijving: "High knees, butt kicks, side shuffles" }
    ],
    conditie: {
      foundation: {
        werk: 15, rust: 30, series: 8, intensiteit: "60% max HR",
        oefeningen: ["Joggen op plaats", "Lichte high knees", "Jumping jacks", "Walking lunges"]
      },
      building: {
        werk: 30, rust: 60, series: 12, intensiteit: "60-75% max HR", 
        oefeningen: ["Shuttle runs", "Mountain climbers", "Burpees", "Step-ups"]
      },
      work: {
        werk: 10, rust: 45, series: 8, intensiteit: "100% max HR",
        oefeningen: ["All-out sprints", "Explosive burpees", "Jump squats", "Battle ropes"]
      }
    },
    kracht: {
      core: [
        { naam: "Plank", series: 3, reps: "30-60s", rust: "30s" },
        { naam: "Russian twists", series: 3, reps: "20/kant", rust: "30s" },
        { naam: "Dead bug", series: 3, reps: "10/kant", rust: "30s" }
      ],
      arms: [
        { naam: "Push-ups", series: 3, reps: "8-15", rust: "45s" },
        { naam: "Pike push-ups", series: 3, reps: "8-12", rust: "45s" },
        { naam: "Tricep dips", series: 3, reps: "10-15", rust: "45s" }
      ],
      legs: [
        { naam: "Squats", series: 4, reps: "15-20", rust: "60s" },
        { naam: "Lunges", series: 3, reps: "12/been", rust: "45s" },
        { naam: "Calf raises", series: 3, reps: "20-25", rust: "30s" }
      ]
    },
    cooldown: [
      { naam: "Hamstring stretch", duur: "2x30s/been", type: "Statisch" },
      { naam: "Hip flexor stretch", duur: "2x30s/kant", type: "Statisch" },
      { naam: "Calf stretch", duur: "2x30s/been", type: "Statisch" },
      { naam: "Shoulder stretch", duur: "2x30s/arm", type: "Statisch" },
      { naam: "Ademhaling", duur: "10 cycli", type: "Ontspanning" }
    ]
  };

  const [programs, setPrograms] = useState<TrainingProgram[]>([
    {
      id: 1,
      name: "Pre Season",
      startDate: "2025-01-15",
      endDate: "2025-03-15", 
      trainingDays: ["monday", "wednesday", "friday"],
      created: "15/01/2025"
    }
  ]);

  const [showDialog, setShowDialog] = useState(false);
  const [editingProgram, setEditingProgram] = useState<TrainingProgram | null>(null);
  const [formData, setFormData] = useState<FormData>({
    name: "",
    startDate: "",
    endDate: "",
    trainingDays: []
  });

  const resetForm = () => {
    setFormData({ name: "", startDate: "", endDate: "", trainingDays: [] });
    setEditingProgram(null);
  };

  const handleCreate = () => {
    setShowDialog(true);
    resetForm();
  };

  const handleEdit = (program: TrainingProgram) => {
    setEditingProgram(program);
    setFormData({
      name: program.name,
      startDate: program.startDate,
      endDate: program.endDate,
      trainingDays: program.trainingDays
    });
    setShowDialog(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.startDate || !formData.endDate || formData.trainingDays.length === 0) {
      alert("Vul alle velden in en selecteer minimaal één trainingsdag.");
      return;
    }

    const newProgram: TrainingProgram = {
      id: editingProgram ? editingProgram.id : Date.now(),
      name: formData.name,
      startDate: formData.startDate,
      endDate: formData.endDate,
      trainingDays: formData.trainingDays,
      created: new Date().toLocaleDateString('nl-NL')
    };

    if (editingProgram) {
      setPrograms(programs.map(p => p.id === editingProgram.id ? newProgram : p));
    } else {
      setPrograms([...programs, newProgram]);
    }

    setShowDialog(false);
    resetForm();
  };

  const handleDelete = (programId: number) => {
    if (confirm("Weet je zeker dat je dit programma wilt verwijderen?")) {
      setPrograms(programs.filter(p => p.id !== programId));
    }
  };

  const handleDayToggle = (dayValue: string, checked: boolean) => {
    if (checked) {
      setFormData({ ...formData, trainingDays: [...formData.trainingDays, dayValue] });
    } else {
      setFormData({ ...formData, trainingDays: formData.trainingDays.filter(day => day !== dayValue) });
    }
  };

  const exportToPDF = (program: TrainingProgram) => {
    try {
      const doc = new jsPDF();
      let y = 20;

      // Title
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text(`TRAINING PROGRAMMA: ${program.name}`, 10, y);
      y += 15;

      // Program info
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text(`Periode: ${program.startDate} tot ${program.endDate}`, 10, y);
      y += 8;
      doc.text(`Dagen: ${program.trainingDays.map(day => trainingDayOptions.find(opt => opt.value === day)?.label).join(", ")}`, 10, y);
      y += 15;

      // 1. Opwarming
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('1. OPWARMING (10 minuten)', 10, y);
      y += 10;

      trainingDetails.opwarming.forEach(oef => {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${oef.naam} (${oef.duur})`, 15, y);
        y += 6;
        doc.setFont('helvetica', 'normal');
        doc.text(`  ${oef.beschrijving}`, 20, y);
        y += 8;
      });

      // 2. Conditie HIIT
      doc.addPage();
      y = 20;
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('2. CONDITIE HIIT (30 minuten)', 10, y);
      y += 12;

      // Foundation
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('FOUNDATION FASE (Week 1-3):', 15, y);
      y += 8;
      doc.setFont('helvetica', 'normal');
      doc.text(`${trainingDetails.conditie.foundation.werk}s werk / ${trainingDetails.conditie.foundation.rust}s rust × ${trainingDetails.conditie.foundation.series} series`, 20, y);
      y += 6;
      trainingDetails.conditie.foundation.oefeningen.forEach(oef => {
        doc.text(`• ${oef}`, 25, y);
        y += 5;
      });
      y += 10;

      // Building  
      doc.setFont('helvetica', 'bold');
      doc.text('BUILDING FASE (Week 4-6):', 15, y);
      y += 8;
      doc.setFont('helvetica', 'normal'); 
      doc.text(`${trainingDetails.conditie.building.werk}s werk / ${trainingDetails.conditie.building.rust}s rust × ${trainingDetails.conditie.building.series} series`, 20, y);
      y += 6;
      trainingDetails.conditie.building.oefeningen.forEach(oef => {
        doc.text(`• ${oef}`, 25, y);
        y += 5;
      });
      y += 10;

      // Work
      doc.setFont('helvetica', 'bold');
      doc.text('WORK FASE (Week 7-8):', 15, y);
      y += 8;
      doc.setFont('helvetica', 'normal');
      doc.text(`${trainingDetails.conditie.work.werk}s werk / ${trainingDetails.conditie.work.rust}s rust × ${trainingDetails.conditie.work.series} series`, 20, y);
      y += 6;
      trainingDetails.conditie.work.oefeningen.forEach(oef => {
        doc.text(`• ${oef}`, 25, y);
        y += 5;
      });

      // 3. Kracht
      doc.addPage();
      y = 20;
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('3. KRACHT TRAINING (15 minuten)', 10, y);
      y += 12;

      // Core
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('CORE (5 minuten):', 15, y);
      y += 8;
      trainingDetails.kracht.core.forEach(oef => {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${oef.naam}`, 20, y);
        y += 6;
        doc.setFont('helvetica', 'normal');
        doc.text(`  ${oef.series} series × ${oef.reps}, rust ${oef.rust}`, 25, y);
        y += 8;
      });

      // Arms
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('ARMEN (5 minuten):', 15, y);
      y += 8;
      trainingDetails.kracht.arms.forEach(oef => {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${oef.naam}`, 20, y);
        y += 6;
        doc.setFont('helvetica', 'normal');
        doc.text(`  ${oef.series} series × ${oef.reps}, rust ${oef.rust}`, 25, y);
        y += 8;
      });

      // Legs
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('BENEN (5 minuten):', 15, y);
      y += 8;
      trainingDetails.kracht.legs.forEach(oef => {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${oef.naam}`, 20, y);
        y += 6;
        doc.setFont('helvetica', 'normal');
        doc.text(`  ${oef.series} series × ${oef.reps}, rust ${oef.rust}`, 25, y);
        y += 8;
      });

      // 4. Cool-down
      doc.addPage();
      y = 20;
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('4. COOL-DOWN (5 minuten)', 10, y);
      y += 12;

      trainingDetails.cooldown.forEach(oef => {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${oef.naam} (${oef.duur})`, 15, y);
        y += 6;
        doc.setFont('helvetica', 'normal');
        doc.text(`  Type: ${oef.type}`, 20, y);
        y += 8;
      });

      const fileName = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_training_program.pdf`;
      doc.save(fileName);
      alert(`PDF "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('PDF Export Error:', error);
      alert('Fout bij PDF export');
    }
  };

  const exportToExcel = (program: TrainingProgram) => {
    try {
      const wb = XLSX.utils.book_new();

      // Overview sheet
      const overview = [
        ['TRAINING PROGRAMMA'],
        ['Naam', program.name],
        ['Periode', `${program.startDate} tot ${program.endDate}`],
        ['Dagen', program.trainingDays.map(day => trainingDayOptions.find(opt => opt.value === day)?.label).join(', ')],
        [''],
        ['STRUCTUUR'],
        ['Onderdeel', 'Duur'],
        ['Opwarming', '10 min'],
        ['Conditie HIIT', '30 min'],
        ['Kracht', '15 min'],
        ['Cool-down', '5 min']
      ];
      const ws1 = XLSX.utils.aoa_to_sheet(overview);
      XLSX.utils.book_append_sheet(wb, ws1, 'Overzicht');

      // Opwarming sheet
      const opwarmingData = [
        ['OPWARMING', '', ''],
        ['Oefening', 'Duur', 'Beschrijving'],
        ...trainingDetails.opwarming.map(oef => [oef.naam, oef.duur, oef.beschrijving])
      ];
      const ws2 = XLSX.utils.aoa_to_sheet(opwarmingData);
      XLSX.utils.book_append_sheet(wb, ws2, 'Opwarming');

      // Conditie sheet
      const conditieData = [
        ['CONDITIE HIIT', '', '', ''],
        [''],
        ['FOUNDATION', '', '', ''],
        ['Werk/Rust/Series', `${trainingDetails.conditie.foundation.werk}s/${trainingDetails.conditie.foundation.rust}s/${trainingDetails.conditie.foundation.series}x`, '', ''],
        ['Oefeningen:', '', '', ''],
        ...trainingDetails.conditie.foundation.oefeningen.map(oef => [oef, '', '', '']),
        [''],
        ['BUILDING', '', '', ''],
        ['Werk/Rust/Series', `${trainingDetails.conditie.building.werk}s/${trainingDetails.conditie.building.rust}s/${trainingDetails.conditie.building.series}x`, '', ''],
        ['Oefeningen:', '', '', ''],
        ...trainingDetails.conditie.building.oefeningen.map(oef => [oef, '', '', '']),
        [''],
        ['WORK', '', '', ''],
        ['Werk/Rust/Series', `${trainingDetails.conditie.work.werk}s/${trainingDetails.conditie.work.rust}s/${trainingDetails.conditie.work.series}x`, '', ''],
        ['Oefeningen:', '', '', ''],
        ...trainingDetails.conditie.work.oefeningen.map(oef => [oef, '', '', ''])
      ];
      const ws3 = XLSX.utils.aoa_to_sheet(conditieData);
      XLSX.utils.book_append_sheet(wb, ws3, 'Conditie');

      // Kracht sheet
      const krachtData = [
        ['KRACHT TRAINING', '', '', ''],
        [''],
        ['CORE', '', '', ''],
        ['Oefening', 'Series', 'Reps', 'Rust'],
        ...trainingDetails.kracht.core.map(oef => [oef.naam, oef.series, oef.reps, oef.rust]),
        [''],
        ['ARMEN', '', '', ''],
        ['Oefening', 'Series', 'Reps', 'Rust'],
        ...trainingDetails.kracht.arms.map(oef => [oef.naam, oef.series, oef.reps, oef.rust]),
        [''],
        ['BENEN', '', '', ''],
        ['Oefening', 'Series', 'Reps', 'Rust'],
        ...trainingDetails.kracht.legs.map(oef => [oef.naam, oef.series, oef.reps, oef.rust])
      ];
      const ws4 = XLSX.utils.aoa_to_sheet(krachtData);
      XLSX.utils.book_append_sheet(wb, ws4, 'Kracht');

      // Cool-down sheet
      const cooldownData = [
        ['COOL-DOWN', '', ''],
        ['Oefening', 'Duur', 'Type'],
        ...trainingDetails.cooldown.map(oef => [oef.naam, oef.duur, oef.type])
      ];
      const ws5 = XLSX.utils.aoa_to_sheet(cooldownData);
      XLSX.utils.book_append_sheet(wb, ws5, 'Cool-down');

      const fileName = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_training_program.xlsx`;
      XLSX.writeFile(wb, fileName);
      alert(`Excel "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('Excel Export Error:', error);
      alert('Fout bij Excel export');
    }
  };

  const exportToICS = (program: TrainingProgram) => {
    try {
      const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Soccer Club//Training Program//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
X-WR-CALNAME:${program.name}
X-WR-CALDESC:Training Programma ${program.startDate} - ${program.endDate}
END:VCALENDAR`;

      const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${program.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_calendar.ics`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      alert(`ICS kalender "${program.name}" succesvol gedownload!`);
    } catch (error) {
      console.error('ICS Export Error:', error);
      alert('Fout bij ICS export');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Trainingsprogramma's</h1>
          <p className="text-muted-foreground">Beheer training programma's met gedetailleerde export</p>
        </div>
        <Button onClick={handleCreate} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Nieuw Programma
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {programs.map((program) => (
          <Card key={program.id} className="border-2 hover:border-blue-300 transition-colors">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{program.name}</CardTitle>
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(program)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(program.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="font-medium">Start:</span><br />
                  {program.startDate}
                </div>
                <div>
                  <span className="font-medium">Eind:</span><br />
                  {program.endDate}
                </div>
              </div>
              
              <div className="text-sm">
                <span className="font-medium">Training dagen:</span><br />
                {program.trainingDays.map(day => trainingDayOptions.find(opt => opt.value === day)?.label).join(", ")}
              </div>
              
              <div className="flex gap-2 mt-4">
                <Button variant="outline" size="sm" className="flex-1" onClick={() => exportToPDF(program)}>
                  <FileText className="h-4 w-4 mr-1" />
                  PDF
                </Button>
                <Button variant="outline" size="sm" className="flex-1" onClick={() => exportToExcel(program)}>
                  <Download className="h-4 w-4 mr-1" />
                  Excel
                </Button>
                <Button variant="outline" size="sm" className="flex-1" onClick={() => exportToICS(program)}>
                  <Calendar className="h-4 w-4 mr-1" />
                  ICS
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {editingProgram ? "Programma Bewerken" : "Nieuw Training Programma"}
            </DialogTitle>
            <DialogDescription>
              Vul de gegevens in voor je training programma
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Programma Naam</Label>
              <Input
                id="name"
                placeholder="bijv. Pre Season 2025"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="startDate">Start Datum</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="endDate">Eind Datum</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label>Training Dagen</Label>
              <div className="grid grid-cols-2 gap-2">
                {trainingDayOptions.map((day) => (
                  <div key={day.value} className="flex items-center space-x-2">
                    <Checkbox
                      id={day.value}
                      checked={formData.trainingDays.includes(day.value)}
                      onCheckedChange={(checked) => handleDayToggle(day.value, !!checked)}
                    />
                    <Label htmlFor={day.value} className="text-sm font-normal">
                      {day.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Annuleren
            </Button>
            <Button onClick={handleSave}>
              {editingProgram ? "Opslaan" : "Aanmaken"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}