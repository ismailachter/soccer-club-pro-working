import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BackToMenu } from "@/components/ui/back-to-menu";
import { 
  Upload, 
  Play, 
  BarChart3, 
  Users, 
  User, 
  TrendingUp, 
  Shield, 
  Activity,
  FileVideo,
  CheckCircle,
  Clock,
  AlertCircle,
  ArrowLeft
} from "lucide-react";
import { Link } from "wouter";

interface Team {
  id: number;
  name: string;
  age_group: string;
  player_count: number;
}

interface Video {
  id: number;
  title: string;
  filename: string;
  team_id: number;
  teamName?: string;
  match_date: string;
  opponent?: string;
  home_away?: string;
  analysis_status: string;
  uploaded_at: string;
  notes?: string;
}

interface Player {
  id: number;
  firstName: string;
  lastName: string;
  jerseyNumber?: number;
  teamId: number;
}

interface AnalysisResult {
  category: string;
  subcategory: string;
  element: string;
  totalCount: number;
  successCount: number;
  failureCount: number;
  successPercentage: number;
}

interface PhysicalAnalysis {
  id: number;
  player_id: number;
  jersey_number: number;
  first_name: string;
  last_name: string;
  total_distance: number;
  max_speed: number;
  average_speed: number;
  accelerations_count: number;
  decelerations_count: number;
  sprints_0_5_kmh: number;
  sprints_5_10_kmh: number;
  sprints_10_15_kmh: number;
  sprints_15_20_kmh: number;
  sprints_20_25_kmh: number;
  sprints_25_30_kmh: number;
  sprints_above_30_kmh: number;
  distance_q1: number;
  distance_q2: number;
  distance_q3: number;
  distance_q4: number;
  distance_first_half: number;
  distance_second_half: number;
  zone_defensive_third_time: number;
  zone_middle_third_time: number;
  zone_attacking_third_time: number;
  duels_won: number;
  duels_lost: number;
}

interface TeamMatchStats {
  goals_scored: number;
  goals_conceded: number;
  chances_created: number;
  chances_conceded: number;
  possession_percentage: number;
  total_passes: number;
  successful_passes: number;
  pass_accuracy: number;
}

function VideoAnalysisWorkflow() {
  const [selectedTab, setSelectedTab] = useState("upload");
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch teams and videos
  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"]
  });

  const { data: videos = [] } = useQuery<Video[]>({
    queryKey: ["/api/videos"]
  });

  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/players"]
  });

  // Upload video mutation
  const uploadVideoMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      return apiRequest("/api/videos/upload", {
        method: "POST",
        body: formData
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({
        title: "Video Uploaded",
        description: "Video is successfully uploaded and ready for analysis"
      });
      setSelectedTab("analysis");
    }
  });

  // Team analysis mutation
  const teamAnalysisMutation = useMutation({
    mutationFn: async (videoId: number) => {
      return apiRequest(`/api/videos/${videoId}/analyze-team`, {
        method: "POST"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({
        title: "Team Analysis Complete",
        description: "Team tactical analysis has been completed and saved"
      });
    }
  });

  // Player analysis mutation
  const playerAnalysisMutation = useMutation({
    mutationFn: async (videoId: number) => {
      return apiRequest(`/api/videos/${videoId}/analyze-players`, {
        method: "POST"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({
        title: "Player Analysis Complete",
        description: "Individual player analysis has been completed and saved"
      });
    }
  });

  const handleVideoUpload = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    uploadVideoMutation.mutate(formData);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "analyzing":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case "failed":
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <FileVideo className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "analyzing":
        return "bg-yellow-100 text-yellow-800";
      case "failed":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3 mb-4">
        <Link href="/">
          <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 hover:bg-gray-100">
            <ArrowLeft size={18} />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold text-gray-900">Video Analysis Workflow</h1>
      </div>
      
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-600 mt-2">Upload → Team Analysis → Individual Analysis → Evolutie Dashboard</p>
        </div>
        <Activity className="h-8 w-8 text-primary" />
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="upload" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            1. Upload Video
          </TabsTrigger>
          <TabsTrigger value="analysis" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            2. Analysis
          </TabsTrigger>
          <TabsTrigger value="players" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            3. Player Mapping
          </TabsTrigger>
          <TabsTrigger value="results" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            4. Resultaten
          </TabsTrigger>
        </TabsList>

        {/* Step 1: Video Upload */}
        <TabsContent value="upload">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Video Upload & Team Assignment
              </CardTitle>
              <CardDescription>
                Upload een wedstrijd video en koppel deze aan een team voor analyse
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleVideoUpload} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Video Titel</Label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="VVC Brasschaat vs Tegenstander"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="teamId">Team</Label>
                    <Select name="teamId" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer team..." />
                      </SelectTrigger>
                      <SelectContent>
                        {teams.map((team) => (
                          <SelectItem key={team.id} value={team.id.toString()}>
                            {team.name} ({team.player_count} spelers)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="matchDate">Wedstrijd Datum</Label>
                    <Input
                      id="matchDate"
                      name="matchDate"
                      type="datetime-local"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="opponent">Tegenstander</Label>
                    <Input
                      id="opponent"
                      name="opponent"
                      placeholder="Naam tegenstander"
                    />
                  </div>
                  <div>
                    <Label htmlFor="homeAway">Thuis/Uit</Label>
                    <Select name="homeAway">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecteer..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="home">Thuis</SelectItem>
                        <SelectItem value="away">Uit</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="video">Video Bestand</Label>
                  <Input
                    id="video"
                    name="video"
                    type="file"
                    accept="video/*"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="notes">Opmerkingen</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    placeholder="Extra opmerkingen over de wedstrijd..."
                  />
                </div>

                <Button
                  type="submit"
                  disabled={uploadVideoMutation.isPending}
                  className="w-full"
                >
                  {uploadVideoMutation.isPending ? "Uploading..." : "Upload Video"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 2: Analysis */}
        <TabsContent value="analysis">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Video Analysis Dashboard
                </CardTitle>
                <CardDescription>
                  Beschikbare videos en analyse status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {videos.map((video) => (
                    <div key={video.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-lg">{video.title}</h4>
                          <p className="text-sm text-gray-600">
                            {video.opponent && `vs ${video.opponent}`} • {new Date(video.matchDate).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(video.analysisStatus)}
                          <Badge className={getStatusColor(video.analysisStatus)}>
                            {video.analysisStatus}
                          </Badge>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          onClick={() => teamAnalysisMutation.mutate(video.id)}
                          disabled={teamAnalysisMutation.isPending}
                          variant="outline"
                          className="flex items-center gap-2"
                        >
                          <Shield className="h-4 w-4" />
                          Team Analysis (B+/B-/Omschakelingen)
                        </Button>
                        <Button
                          onClick={() => playerAnalysisMutation.mutate(video.id)}
                          disabled={playerAnalysisMutation.isPending}
                          variant="outline"
                          className="flex items-center gap-2"
                        >
                          <User className="h-4 w-4" />
                          Player Analysis (Individueel)
                        </Button>
                        <Button
                          onClick={() => setSelectedVideo(video)}
                          variant="default"
                          className="flex items-center gap-2"
                        >
                          <Play className="h-4 w-4" />
                          View Results
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Step 3: Player Mapping */}
        <TabsContent value="players">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Player Jersey Number Mapping
              </CardTitle>
              <CardDescription>
                Koppel spelers aan rugnummers voor individuele analyse
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Label htmlFor="teamSelect">Selecteer Team</Label>
                <Select value={selectedTeam} onValueChange={setSelectedTeam}>
                  <SelectTrigger>
                    <SelectValue placeholder="Kies een team..." />
                  </SelectTrigger>
                  <SelectContent>
                    {teams.map((team) => (
                      <SelectItem key={team.id} value={team.id.toString()}>
                        {team.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedTeam && (
                <div className="grid gap-4">
                  {players
                    .filter(player => player.teamId.toString() === selectedTeam)
                    .map((player) => (
                      <div key={player.id} className="flex items-center justify-between border rounded-lg p-3">
                        <div>
                          <span className="font-medium">{player.firstName} {player.lastName}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Label htmlFor={`jersey-${player.id}`}>Rugnummer:</Label>
                          <Input
                            id={`jersey-${player.id}`}
                            type="number"
                            min="1"
                            max="99"
                            defaultValue={player.jerseyNumber || ""}
                            className="w-20"
                            placeholder="Nr"
                          />
                          <Button size="sm" variant="outline">
                            Save
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 4: Results */}
        <TabsContent value="results">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Analysis Results & Evolution Dashboard
                </CardTitle>
                <CardDescription>
                  Team en individuele prestatie evolutie met statistieken
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-6">
                  {/* Team B+ Stats */}
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold text-green-700 mb-3">TEAMTACTISCH B+</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Opbouwen</span>
                        <span className="text-sm font-medium">78%</span>
                      </div>
                      <Progress value={78} className="h-2" />
                      <div className="flex justify-between">
                        <span className="text-sm">Aanvallen</span>
                        <span className="text-sm font-medium">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                  </div>

                  {/* Team B- Stats */}
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold text-red-700 mb-3">TEAMTACTISCH B-</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Druk Zetten</span>
                        <span className="text-sm font-medium">72%</span>
                      </div>
                      <Progress value={72} className="h-2" />
                      <div className="flex justify-between">
                        <span className="text-sm">Compact Verdedigen</span>
                        <span className="text-sm font-medium">88%</span>
                      </div>
                      <Progress value={88} className="h-2" />
                    </div>
                  </div>

                  {/* Omschakelingen Stats */}
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold text-blue-700 mb-3">OMSCHAKELINGEN</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Naar Aanval</span>
                        <span className="text-sm font-medium">81%</span>
                      </div>
                      <Progress value={81} className="h-2" />
                      <div className="flex justify-between">
                        <span className="text-sm">Naar Verdediging</span>
                        <span className="text-sm font-medium">75%</span>
                      </div>
                      <Progress value={75} className="h-2" />
                    </div>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Workflow Status</h4>
                  <p className="text-sm text-gray-600">
                    ✅ Video Upload System gereed<br />
                    ✅ Database schema voor team & player analyse<br />
                    🔄 AI Analysis Engine wordt geïmplementeerd<br />
                    🔄 Jersey number mapping systeem<br />
                    🔄 Evolution tracking met historische data
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Tactical Analysis Tab Component
function TacticalAnalysisTab({ teamResults, playerResults }: { teamResults: any[], playerResults: any[] }) {
  if (!teamResults && !playerResults) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Start eerst een team of speler analyse om resultaten te zien.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {teamResults && teamResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Team Analyse Resultaten</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {teamResults.map((result: AnalysisResult, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-semibold">{result.element}</h4>
                    <span className="text-sm text-gray-500">
                      {result.category} - {result.subcategory}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Totaal: </span>
                      <span className="font-medium">{result.totalCount}</span>
                    </div>
                    <div>
                      <span className="text-green-600">Succesvol: </span>
                      <span className="font-medium">{result.successCount}</span>
                    </div>
                    <div>
                      <span className="text-red-600">Gefaald: </span>
                      <span className="font-medium">{result.failureCount}</span>
                    </div>
                  </div>
                  <div className="mt-2">
                    <div className="flex justify-between text-sm">
                      <span>Slaagpercentage</span>
                      <span className="font-medium">{result.successPercentage.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${result.successPercentage}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {playerResults && playerResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Speler Analyse Resultaten</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(
                playerResults.reduce((acc: any, result: any) => {
                  const key = `${result.first_name} ${result.last_name} (#${result.jersey_number})`;
                  if (!acc[key]) acc[key] = [];
                  acc[key].push(result);
                  return acc;
                }, {})
              ).map(([playerName, results]: [string, any]) => (
                <div key={playerName} className="border rounded-lg p-4">
                  <h4 className="font-semibold mb-3">{playerName}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {results.slice(0, 6).map((result: AnalysisResult, index: number) => (
                      <div key={index} className="text-sm">
                        <div className="font-medium">{result.element}</div>
                        <div className="text-gray-600">
                          {result.successCount}/{result.totalCount} ({result.successPercentage.toFixed(1)}%)
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Physical Analysis Tab Component
function PhysicalAnalysisTab({ videoId }: { videoId: number }) {
  const { data: physicalData, isLoading } = useQuery({
    queryKey: [`/api/videos/${videoId}/physical-results`],
    enabled: !!videoId
  });

  if (isLoading) {
    return <div className="text-center py-8">Fysieke data laden...</div>;
  }

  if (!physicalData || physicalData.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Geen fysieke analyse data beschikbaar.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {physicalData.map((player: PhysicalAnalysis) => (
          <Card key={player.id}>
            <CardHeader>
              <CardTitle className="text-base">
                {player.first_name} {player.last_name} (#{player.jersey_number})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Distance Metrics */}
              <div>
                <h4 className="font-semibold text-sm mb-2">Afstand</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Totaal:</span>
                    <span className="font-medium">{Math.round(player.total_distance)}m</span>
                  </div>
                  <div className="flex justify-between">
                    <span>1e Helft:</span>
                    <span>{Math.round(player.distance_first_half)}m</span>
                  </div>
                  <div className="flex justify-between">
                    <span>2e Helft:</span>
                    <span>{Math.round(player.distance_second_half)}m</span>
                  </div>
                </div>
              </div>

              {/* Speed Metrics */}
              <div>
                <h4 className="font-semibold text-sm mb-2">Snelheid</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Max:</span>
                    <span className="font-medium">{player.max_speed.toFixed(1)} km/h</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Gemiddeld:</span>
                    <span>{player.average_speed.toFixed(1)} km/h</span>
                  </div>
                </div>
              </div>

              {/* Sprint Categories */}
              <div>
                <h4 className="font-semibold text-sm mb-2">Sprints</h4>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span>20-25 km/h:</span>
                    <span>{player.sprints_20_25_kmh}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>25-30 km/h:</span>
                    <span>{player.sprints_25_30_kmh}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>30+ km/h:</span>
                    <span className="font-medium">{player.sprints_above_30_kmh}</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div>
                <h4 className="font-semibold text-sm mb-2">Acties</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Start/Stops:</span>
                    <span>{player.accelerations_count + player.decelerations_count}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Duels:</span>
                    <span>{player.duels_won}/{player.duels_won + player.duels_lost}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// Team Stats Tab Component  
function TeamStatsTab({ videoId }: { videoId: number }) {
  const { data: teamStats, isLoading } = useQuery({
    queryKey: [`/api/videos/${videoId}/team-stats`],
    enabled: !!videoId
  });

  if (isLoading) {
    return <div className="text-center py-8">Team statistieken laden...</div>;
  }

  if (!teamStats) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Geen team statistieken beschikbaar.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Doelpunten</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">
                {teamStats.goals_scored}
              </div>
              <div className="text-sm text-gray-500">Voor</div>
              <div className="text-2xl font-bold text-red-600 mt-2">
                {teamStats.goals_conceded}
              </div>
              <div className="text-sm text-gray-500">Tegen</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Kansen</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">
                {teamStats.chances_created}
              </div>
              <div className="text-sm text-gray-500">Gecreëerd</div>
              <div className="text-2xl font-bold text-orange-600 mt-2">
                {teamStats.chances_conceded}
              </div>
              <div className="text-sm text-gray-500">Weggegeven</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Balbezit</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">
                {teamStats.possession_percentage.toFixed(1)}%
              </div>
              <div className="text-sm text-gray-500">Balbezit</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Passes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-2xl font-bold text-indigo-600">
                {teamStats.successful_passes}/{teamStats.total_passes}
              </div>
              <div className="text-sm text-gray-500">Succesvol</div>
              <div className="text-lg font-bold text-indigo-600 mt-1">
                {teamStats.pass_accuracy.toFixed(1)}%
              </div>
              <div className="text-sm text-gray-500">Nauwkeurigheid</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Heatmap Tab Component
function HeatmapTab({ videoId }: { videoId: number }) {
  const { data: teamHeatmap, isLoading } = useQuery({
    queryKey: [`/api/videos/${videoId}/team-heatmap`],
    enabled: !!videoId
  });

  if (isLoading) {
    return <div className="text-center py-8">Heatmap data laden...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Team Heatmap</CardTitle>
          <p className="text-sm text-gray-600">
            Gemiddelde positie van alle spelers over de gehele wedstrijd
          </p>
        </CardHeader>
        <CardContent>
          <div className="relative bg-green-100 rounded-lg p-4" style={{ aspectRatio: '3/2' }}>
            {/* Soccer field visualization */}
            <div className="absolute inset-0 border-2 border-white rounded-lg">
              {/* Generate 6x4 grid for 24 zones */}
              <div className="grid grid-cols-6 grid-rows-4 h-full gap-1">
                {Array.from({ length: 24 }, (_, i) => {
                  const zoneKey = `avg_zone_${i + 1}_time`;
                  const intensity = teamHeatmap?.[zoneKey] ? Math.min(teamHeatmap[zoneKey] / 600, 1) : 0;
                  return (
                    <div
                      key={i}
                      className="border border-white/30 rounded flex items-center justify-center text-xs text-white font-bold"
                      style={{
                        backgroundColor: `rgba(239, 68, 68, ${intensity * 0.8})`,
                      }}
                    >
                      {Math.round(intensity * 100)}%
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default VideoAnalysisWorkflow;