import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  User, 
  Target, 
  Zap, 
  Brain, 
  Timer, 
  MapPin, 
  TrendingUp, 
  Activity,
  BarChart3,
  Play
} from 'lucide-react';

interface PlayerAnalysis {
  playerId: number;
  playerName: string;
  position: string;
  jerseyNumber: number;
  matchId: string;
  
  // BASICS Analysis
  basics: {
    ballControl: number;
    passing: number;
    receiving: number;
    dribbling: number;
    shooting: number;
    heading: number;
    overallRating: number;
  };
  
  // TACTISCH Analysis  
  tactical: {
    positioning: number;
    decisionMaking: number;
    teamwork: number;
    pressing: number;
    defending: number;
    attacking: number;
    overallRating: number;
  };
  
  // FYSIEK Analysis
  physical: {
    distance: number; // meters
    topSpeed: number; // km/h
    sprints: number;
    accelerations: number;
    decelerations: number;
    intensity: number; // percentage
    overallRating: number;
  };
  
  // Video Clips
  videoClips: {
    highlights: string[];
    tacticalMoments: string[];
    physicalPeaks: string[];
  };
}

interface Props {
  matchId: string;
  playerId?: number;
}

export default function IndividualPlayerAnalysis({ matchId, playerId }: Props) {
  const [playerAnalysis, setPlayerAnalysis] = useState<PlayerAnalysis | null>(null);
  const [allPlayers, setAllPlayers] = useState<PlayerAnalysis[]>([]);
  const [selectedPlayer, setSelectedPlayer] = useState<number | null>(playerId || null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('basics');

  useEffect(() => {
    fetchPlayerAnalysis();
  }, [matchId, selectedPlayer]);

  const fetchPlayerAnalysis = async () => {
    try {
      const response = await fetch(`/api/match-analysis/${matchId}/players`);
      const data = await response.json();
      setAllPlayers(data);
      
      if (selectedPlayer) {
        const playerData = data.find((p: PlayerAnalysis) => p.playerId === selectedPlayer);
        setPlayerAnalysis(playerData || null);
      }
    } catch (error) {
      console.error('Error fetching player analysis:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 8) return 'text-green-600 bg-green-100';
    if (rating >= 6) return 'text-yellow-600 bg-yellow-100';
    if (rating >= 4) return 'text-orange-600 bg-orange-100';
    return 'text-red-600 bg-red-100';
  };

  const formatDistance = (meters: number) => {
    return (meters / 1000).toFixed(1) + ' km';
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Laden speler analyse...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      {/* Player Selection */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Individuele Speler Analyse
        </h1>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {allPlayers.map((player) => (
            <Button
              key={player.playerId}
              variant={selectedPlayer === player.playerId ? "default" : "outline"}
              onClick={() => setSelectedPlayer(player.playerId)}
              className="flex flex-col items-center p-3 h-auto"
            >
              <User className="h-4 w-4 mb-1" />
              <span className="text-xs">{player.playerName}</span>
              <span className="text-xs text-gray-500">#{player.jerseyNumber}</span>
            </Button>
          ))}
        </div>
      </div>

      {playerAnalysis && (
        <div className="space-y-6">
          {/* Player Header */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl">
                    {playerAnalysis.playerName}
                  </CardTitle>
                  <div className="flex items-center gap-4 text-gray-600">
                    <span>#{playerAnalysis.jerseyNumber}</span>
                    <span>{playerAnalysis.position}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-blue-600">
                    {((playerAnalysis.basics.overallRating + 
                       playerAnalysis.tactical.overallRating + 
                       playerAnalysis.physical.overallRating) / 3).toFixed(1)}
                  </div>
                  <div className="text-sm text-gray-500">Totaal Rating</div>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Analysis Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basics" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                BASICS
              </TabsTrigger>
              <TabsTrigger value="tactical" className="flex items-center gap-2">
                <Brain className="h-4 w-4" />
                TACTISCH
              </TabsTrigger>
              <TabsTrigger value="physical" className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                FYSIEK
              </TabsTrigger>
            </TabsList>

            {/* BASICS Analysis */}
            <TabsContent value="basics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Balcontrole</h3>
                      <Badge className={getRatingColor(playerAnalysis.basics.ballControl)}>
                        {playerAnalysis.basics.ballControl.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.basics.ballControl * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Passing</h3>
                      <Badge className={getRatingColor(playerAnalysis.basics.passing)}>
                        {playerAnalysis.basics.passing.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.basics.passing * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Aannemen</h3>
                      <Badge className={getRatingColor(playerAnalysis.basics.receiving)}>
                        {playerAnalysis.basics.receiving.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.basics.receiving * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Dribbelen</h3>
                      <Badge className={getRatingColor(playerAnalysis.basics.dribbling)}>
                        {playerAnalysis.basics.dribbling.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.basics.dribbling * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Schieten</h3>
                      <Badge className={getRatingColor(playerAnalysis.basics.shooting)}>
                        {playerAnalysis.basics.shooting.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.basics.shooting * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Koppen</h3>
                      <Badge className={getRatingColor(playerAnalysis.basics.heading)}>
                        {playerAnalysis.basics.heading.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.basics.heading * 10} className="h-2" />
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    BASICS Overzicht
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-lg font-semibold">Totaal BASICS Rating</span>
                    <div className="text-3xl font-bold text-blue-600">
                      {playerAnalysis.basics.overallRating.toFixed(1)}
                    </div>
                  </div>
                  <Progress value={playerAnalysis.basics.overallRating * 10} className="h-4" />
                </CardContent>
              </Card>
            </TabsContent>

            {/* TACTICAL Analysis */}
            <TabsContent value="tactical" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Positionering</h3>
                      <Badge className={getRatingColor(playerAnalysis.tactical.positioning)}>
                        {playerAnalysis.tactical.positioning.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.tactical.positioning * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Besluitvorming</h3>
                      <Badge className={getRatingColor(playerAnalysis.tactical.decisionMaking)}>
                        {playerAnalysis.tactical.decisionMaking.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.tactical.decisionMaking * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Teamwork</h3>
                      <Badge className={getRatingColor(playerAnalysis.tactical.teamwork)}>
                        {playerAnalysis.tactical.teamwork.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.tactical.teamwork * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Druk Zetten</h3>
                      <Badge className={getRatingColor(playerAnalysis.tactical.pressing)}>
                        {playerAnalysis.tactical.pressing.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.tactical.pressing * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Verdedigen</h3>
                      <Badge className={getRatingColor(playerAnalysis.tactical.defending)}>
                        {playerAnalysis.tactical.defending.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.tactical.defending * 10} className="h-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Aanvallen</h3>
                      <Badge className={getRatingColor(playerAnalysis.tactical.attacking)}>
                        {playerAnalysis.tactical.attacking.toFixed(1)}
                      </Badge>
                    </div>
                    <Progress value={playerAnalysis.tactical.attacking * 10} className="h-2" />
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5" />
                    TACTISCH Overzicht
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-lg font-semibold">Totaal TACTISCH Rating</span>
                    <div className="text-3xl font-bold text-blue-600">
                      {playerAnalysis.tactical.overallRating.toFixed(1)}
                    </div>
                  </div>
                  <Progress value={playerAnalysis.tactical.overallRating * 10} className="h-4" />
                </CardContent>
              </Card>
            </TabsContent>

            {/* PHYSICAL Analysis */}
            <TabsContent value="physical" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">Afstand Gelopen</h3>
                      <MapPin className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="text-2xl font-bold text-blue-600">
                      {formatDistance(playerAnalysis.physical.distance)}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">Topsnelheid</h3>
                      <TrendingUp className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      {playerAnalysis.physical.topSpeed.toFixed(1)} km/h
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">Sprints</h3>
                      <Activity className="h-5 w-5 text-orange-600" />
                    </div>
                    <div className="text-2xl font-bold text-orange-600">
                      {playerAnalysis.physical.sprints}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">Acceleraties</h3>
                      <TrendingUp className="h-5 w-5 text-purple-600" />
                    </div>
                    <div className="text-2xl font-bold text-purple-600">
                      {playerAnalysis.physical.accelerations}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">Deceleraties</h3>
                      <Activity className="h-5 w-5 text-red-600" />
                    </div>
                    <div className="text-2xl font-bold text-red-600">
                      {playerAnalysis.physical.decelerations}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">Intensiteit</h3>
                      <Timer className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="text-2xl font-bold text-blue-600">
                      {playerAnalysis.physical.intensity.toFixed(1)}%
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    FYSIEK Overzicht
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-lg font-semibold">Totaal FYSIEK Rating</span>
                    <div className="text-3xl font-bold text-blue-600">
                      {playerAnalysis.physical.overallRating.toFixed(1)}
                    </div>
                  </div>
                  <Progress value={playerAnalysis.physical.overallRating * 10} className="h-4" />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Video Clips Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="h-5 w-5" />
                Video Fragmenten
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Hoogtepunten</h4>
                  <div className="space-y-2">
                    {playerAnalysis.videoClips.highlights.map((clip, index) => (
                      <Button key={index} variant="outline" size="sm" className="w-full">
                        <Play className="h-4 w-4 mr-2" />
                        Hoogtepunt {index + 1}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Tactische Momenten</h4>
                  <div className="space-y-2">
                    {playerAnalysis.videoClips.tacticalMoments.map((clip, index) => (
                      <Button key={index} variant="outline" size="sm" className="w-full">
                        <Brain className="h-4 w-4 mr-2" />
                        Tactisch {index + 1}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Fysieke Pieken</h4>
                  <div className="space-y-2">
                    {playerAnalysis.videoClips.physicalPeaks.map((clip, index) => (
                      <Button key={index} variant="outline" size="sm" className="w-full">
                        <Zap className="h-4 w-4 mr-2" />
                        Fysiek {index + 1}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}