import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { 
  Plus, 
  Clock, 
  Users, 
  Target, 
  Edit, 
  Trash2, 
  Save, 
  Play, 
  CalendarCheck,
  FileText,
  MapPin,
  Timer,
  Zap,
  Trophy,
  Settings
} from "lucide-react";
import { MaterialSelector } from "@/components/training/modern-training-materials";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

// Schema definitions
const sessionSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  description: z.string().optional(),
  date: z.string(),
  startTime: z.string(),
  duration: z.number().min(30).max(180),
  teamId: z.number().optional(),
  location: z.string().optional(),
  objectives: z.string().optional(),
  notes: z.string().optional(),
  intensity: z.enum(["low", "medium", "high"]),
  difficulty: z.enum(["beginner", "intermediate", "advanced"]),
  equipment: z.string().optional(),
  weatherConditions: z.string().optional()
});

const exerciseBlockSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  description: z.string().optional(),
  duration: z.number().min(1).max(60),
  intensity: z.enum(["low", "medium", "high"]),
  equipment: z.string().optional(),
  objectives: z.string().optional(),
  instructions: z.string().optional(),
  iadatabankElements: z.array(z.string()).default([]),
  players: z.number().min(1).max(30).default(10),
  space: z.string().optional()
});

type SessionFormData = z.infer<typeof sessionSchema>;
type ExerciseBlockFormData = z.infer<typeof exerciseBlockSchema>;



interface TrainingSession {
  id: number;
  name: string;
  description?: string;
  date: string;
  startTime: string;
  duration: number;
  teamId?: number;
  location?: string;
  objectives?: string;
  notes?: string;
  intensity: string;
  difficulty: string;
  equipment?: string;
  weatherConditions?: string;
  exerciseBlocks: ExerciseBlock[];
  team?: { id: number; name: string; };
}

interface ExerciseBlock {
  id: number;
  sessionId: number;
  name: string;
  description?: string;
  duration: number;
  intensity: string;
  equipment?: string;
  objectives?: string;
  instructions?: string;
  iadatabankElements: string[];
  players: number;
  space?: string;
  sortOrder: number;
}

export default function TrainingSessionMaker() {
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);
  const [isCreateSessionOpen, setIsCreateSessionOpen] = useState(false);
  const [isEditSessionOpen, setIsEditSessionOpen] = useState(false);
  const [isExerciseBlockOpen, setIsExerciseBlockOpen] = useState(false);
  const [selectedExerciseBlock, setSelectedExerciseBlock] = useState<ExerciseBlock | null>(null);
  const [isIadataBankOpen, setIsIadataBankOpen] = useState(false);
  const [selectedIadataElements, setSelectedIadataElements] = useState<string[]>([]);
  const [previewMode, setPreviewMode] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch training sessions
  const { data: sessions = [], isLoading } = useQuery<TrainingSession[]>({
    queryKey: ['/api/training-sessions'],
  });

  // Fetch teams
  const { data: teams = [] } = useQuery<any[]>({
    queryKey: ['/api/teams'],
  });

  // Fetch IADATABANK elements
  const { data: iadatabank } = useQuery<{ data: any[] }>({
    queryKey: ['/api/iadatabank/elements'],
  });
  
  const iadatabankElements = iadatabank?.data || [];

  // Session form
  const sessionForm = useForm<SessionFormData>({
    resolver: zodResolver(sessionSchema),
    defaultValues: {
      name: '',
      description: '',
      date: format(new Date(), 'yyyy-MM-dd'),
      startTime: '19:00',
      duration: 90,
      intensity: 'medium',
      difficulty: 'intermediate',
      equipment: 'Voetballen, pionnen, hesjes',
      location: 'Hoofdveld'
    }
  });

  // Exercise block form
  const exerciseForm = useForm<ExerciseBlockFormData>({
    resolver: zodResolver(exerciseBlockSchema),
    defaultValues: {
      name: '',
      description: '',
      duration: 15,
      intensity: 'medium',
      equipment: '',
      objectives: '',
      instructions: '',
      iadatabankElements: [],
      players: 10,
      space: '20x30m'
    }
  });

  // Create session mutation
  const createSession = useMutation({
    mutationFn: (data: SessionFormData) => apiRequest('POST', '/api/training-sessions', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/training-sessions'] });
      toast({ title: "Trainingsessie aangemaakt", description: "De sessie is succesvol aangemaakt." });
      setIsCreateSessionOpen(false);
      sessionForm.reset();
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het aanmaken.", variant: "destructive" });
    }
  });

  // Update session mutation
  const updateSession = useMutation({
    mutationFn: ({ id, data }: { id: number; data: SessionFormData }) => 
      apiRequest('PATCH', `/api/training-sessions/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/training-sessions'] });
      toast({ title: "Trainingsessie bijgewerkt", description: "De wijzigingen zijn opgeslagen." });
      setIsEditSessionOpen(false);
      setSelectedSession(null);
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het bijwerken.", variant: "destructive" });
    }
  });

  // Create exercise block mutation
  const createExerciseBlock = useMutation({
    mutationFn: (data: ExerciseBlockFormData & { sessionId: number }) => 
      apiRequest('POST', '/api/exercise-blocks', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/training-sessions'] });
      toast({ title: "Oefenblok toegevoegd", description: "Het oefenblok is toegevoegd aan de sessie." });
      setIsExerciseBlockOpen(false);
      exerciseForm.reset();
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het toevoegen.", variant: "destructive" });
    }
  });

  // Delete session mutation
  const deleteSession = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/training-sessions/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/training-sessions'] });
      toast({ title: "Trainingsessie verwijderd", description: "De sessie is succesvol verwijderd." });
      setSelectedSession(null);
    },
    onError: () => {
      toast({ title: "Fout", description: "Er is een fout opgetreden bij het verwijderen.", variant: "destructive" });
    }
  });

  const handleCreateSession = (data: SessionFormData) => {
    createSession.mutate(data);
  };

  const handleEditSession = (data: SessionFormData) => {
    if (selectedSession) {
      updateSession.mutate({ id: selectedSession.id, data });
    }
  };

  const handleAddExerciseBlock = (data: ExerciseBlockFormData) => {
    if (selectedSession) {
      createExerciseBlock.mutate({
        ...data,
        sessionId: selectedSession.id,
        iadatabankElements: selectedIadataElements
      });
    }
  };

  const openEditSession = (session: TrainingSession) => {
    setSelectedSession(session);
    sessionForm.reset({
      name: session.name,
      description: session.description || '',
      date: session.date,
      startTime: session.startTime,
      duration: session.duration,
      teamId: session.teamId,
      location: session.location || '',
      objectives: session.objectives || '',
      notes: session.notes || '',
      intensity: session.intensity as any,
      difficulty: session.difficulty as any,
      equipment: session.equipment || '',
      weatherConditions: session.weatherConditions || ''
    });
    setIsEditSessionOpen(true);
  };

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-blue-100 text-blue-800';
      case 'intermediate': return 'bg-orange-100 text-orange-800';
      case 'advanced': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const calculateTotalDuration = (session: TrainingSession) => {
    return session.exerciseBlocks?.reduce((total, block) => total + block.duration, 0) || 0;
  };

  // Group IADATABANK elements by topic
  const groupedIadataElements = iadatabankElements.reduce((acc, element) => {
    if (!acc[element.topic]) {
      acc[element.topic] = [];
    }
    acc[element.topic].push(element);
    return acc;
  }, {} as { [key: string]: any[] });

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Trainingsessies laden...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Trainingsessie Maker</h1>
          <p className="text-gray-600">Creëer gedetailleerde trainingen met IADATABANK elementen</p>
        </div>
        <Button onClick={() => setIsCreateSessionOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Nieuwe Trainingsessie
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sessions List */}
        <div className="lg:col-span-1 space-y-4">
          <h2 className="text-lg font-semibold">Trainingsessies</h2>
          {sessions.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <CalendarCheck className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600">Geen trainingsessies</p>
                <p className="text-sm text-gray-500 mt-2">Maak je eerste training</p>
              </CardContent>
            </Card>
          ) : (
            sessions.map((session) => (
              <Card 
                key={session.id} 
                className={`cursor-pointer transition-colors hover:bg-gray-50 ${
                  selectedSession?.id === session.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedSession(session)}
              >
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium text-sm">{session.name}</h3>
                    <div className="flex gap-1">
                      <Badge variant="outline" className={getIntensityColor(session.intensity)}>
                        {session.intensity}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="space-y-1 text-xs text-gray-600">
                    <div className="flex items-center gap-1">
                      <CalendarCheck className="h-3 w-3" />
                      {format(new Date(session.date), 'dd MMM yyyy', { locale: nl })} om {session.startTime}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {session.duration} min ({calculateTotalDuration(session)} min geplanned)
                    </div>
                    {session.team && (
                      <div className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {session.team.name}
                      </div>
                    )}
                    {session.location && (
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {session.location}
                      </div>
                    )}
                    <div className="flex items-center gap-1">
                      <Target className="h-3 w-3" />
                      {session.exerciseBlocks?.length || 0} oefenblokken
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Session Details */}
        <div className="lg:col-span-2">
          {selectedSession ? (
            <div className="space-y-6">
              {/* Session Header */}
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {selectedSession.name}
                        <Badge className={getDifficultyColor(selectedSession.difficulty)}>
                          {selectedSession.difficulty}
                        </Badge>
                        <Badge className={getIntensityColor(selectedSession.intensity)}>
                          {selectedSession.intensity}
                        </Badge>
                      </CardTitle>
                      <p className="text-gray-600 mt-1">{selectedSession.description}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => setPreviewMode(!previewMode)}>
                        <FileText className="h-4 w-4 mr-1" />
                        {previewMode ? 'Bewerken' : 'Voorbeeld'}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => openEditSession(selectedSession)}>
                        <Edit className="h-4 w-4 mr-1" />
                        Bewerk
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive" 
                        onClick={() => deleteSession.mutate(selectedSession.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Verwijder
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <div className="flex items-center gap-1 text-gray-600 mb-1">
                        <CalendarCheck className="h-4 w-4" />
                        Datum & Tijd
                      </div>
                      <p className="font-medium">
                        {format(new Date(selectedSession.date), 'dd MMM yyyy', { locale: nl })}
                      </p>
                      <p className="text-gray-600">{selectedSession.startTime}</p>
                    </div>
                    <div>
                      <div className="flex items-center gap-1 text-gray-600 mb-1">
                        <Clock className="h-4 w-4" />
                        Duur
                      </div>
                      <p className="font-medium">{selectedSession.duration} min</p>
                      <p className="text-gray-600">{calculateTotalDuration(selectedSession)} min geplanned</p>
                    </div>
                    {selectedSession.team && (
                      <div>
                        <div className="flex items-center gap-1 text-gray-600 mb-1">
                          <Users className="h-4 w-4" />
                          Team
                        </div>
                        <p className="font-medium">{selectedSession.team.name}</p>
                      </div>
                    )}
                    {selectedSession.location && (
                      <div>
                        <div className="flex items-center gap-1 text-gray-600 mb-1">
                          <MapPin className="h-4 w-4" />
                          Locatie
                        </div>
                        <p className="font-medium">{selectedSession.location}</p>
                      </div>
                    )}
                  </div>
                  
                  {selectedSession.objectives && (
                    <div className="mt-4">
                      <h4 className="font-medium text-sm text-gray-700 mb-2">Doelstellingen</h4>
                      <p className="text-sm text-gray-600">{selectedSession.objectives}</p>
                    </div>
                  )}

                  {selectedSession.equipment && (
                    <div className="mt-4">
                      <h4 className="font-medium text-sm text-gray-700 mb-2">Materiaal</h4>
                      <p className="text-sm text-gray-600">{selectedSession.equipment}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Exercise Blocks */}
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Oefenblokken</CardTitle>
                    <Button 
                      size="sm" 
                      onClick={() => {
                        setSelectedExerciseBlock(null);
                        setSelectedIadataElements([]);
                        exerciseForm.reset();
                        setIsExerciseBlockOpen(true);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Oefenblok Toevoegen
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {selectedSession.exerciseBlocks?.length === 0 || !selectedSession.exerciseBlocks ? (
                    <div className="text-center py-8">
                      <Target className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                      <p className="text-gray-600">Geen oefenblokken</p>
                      <p className="text-sm text-gray-500 mt-2">Voeg oefeningen toe aan deze training</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {selectedSession.exerciseBlocks.map((block, index) => (
                        <Card key={block.id} className="border-l-4 border-l-blue-500">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <h4 className="font-medium">{index + 1}. {block.name}</h4>
                                <p className="text-sm text-gray-600 mt-1">{block.description}</p>
                              </div>
                              <div className="flex gap-2">
                                <Badge variant="outline" className={getIntensityColor(block.intensity)}>
                                  {block.intensity}
                                </Badge>
                                <Badge variant="outline">
                                  {block.duration} min
                                </Badge>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                              <div>
                                <div className="flex items-center gap-1 text-gray-600 mb-1">
                                  <Users className="h-3 w-3" />
                                  Spelers
                                </div>
                                <p className="font-medium">{block.players}</p>
                              </div>
                              {block.space && (
                                <div>
                                  <div className="flex items-center gap-1 text-gray-600 mb-1">
                                    <MapPin className="h-3 w-3" />
                                    Ruimte
                                  </div>
                                  <p className="font-medium">{block.space}</p>
                                </div>
                              )}
                              {block.equipment && (
                                <div>
                                  <div className="flex items-center gap-1 text-gray-600 mb-1">
                                    <Settings className="h-3 w-3" />
                                    Materiaal
                                  </div>
                                  <p className="font-medium">{block.equipment}</p>
                                </div>
                              )}
                              <div>
                                <div className="flex items-center gap-1 text-gray-600 mb-1">
                                  <Target className="h-3 w-3" />
                                  IADATABANK
                                </div>
                                <p className="font-medium">{block.iadatabankElements?.length || 0} elementen</p>
                              </div>
                            </div>

                            {block.iadatabankElements && block.iadatabankElements.length > 0 && (
                              <div className="mt-3">
                                <h5 className="text-xs font-medium text-gray-700 mb-2">IADATABANK Elementen</h5>
                                <div className="flex flex-wrap gap-1">
                                  {block.iadatabankElements.map((elementId) => {
                                    const element = iadatabankElements.find(el => el.id === elementId);
                                    return element ? (
                                      <Badge key={elementId} variant="secondary" className="text-xs">
                                        {element.name}
                                      </Badge>
                                    ) : null;
                                  })}
                                </div>
                              </div>
                            )}

                            {block.objectives && (
                              <div className="mt-3">
                                <h5 className="text-xs font-medium text-gray-700 mb-1">Doelstellingen</h5>
                                <p className="text-xs text-gray-600">{block.objectives}</p>
                              </div>
                            )}

                            {block.instructions && (
                              <div className="mt-3">
                                <h5 className="text-xs font-medium text-gray-700 mb-1">Uitvoering</h5>
                                <p className="text-xs text-gray-600">{block.instructions}</p>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Play className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Selecteer een trainingsessie</h3>
                <p className="text-gray-600">Kies een sessie uit de lijst om details te bekijken en te bewerken</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Create Session Dialog */}
      <Dialog open={isCreateSessionOpen} onOpenChange={setIsCreateSessionOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nieuwe Trainingsessie</DialogTitle>
          </DialogHeader>
          <Form {...sessionForm}>
            <form onSubmit={sessionForm.handleSubmit(handleCreateSession)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={sessionForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Naam</FormLabel>
                      <FormControl>
                        <Input placeholder="bijv. Techniektraining" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={sessionForm.control}
                  name="teamId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team (optioneel)</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(value === "none" ? undefined : Number(value))} 
                        value={field.value?.toString() || "none"}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">Geen team</SelectItem>
                          {teams.map((team) => (
                            <SelectItem key={team.id} value={team.id.toString()}>
                              {team.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={sessionForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Beschrijving</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Korte beschrijving van de training..."
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={sessionForm.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Datum</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={sessionForm.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Starttijd</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={sessionForm.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duur (minuten)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="30" 
                          max="180" 
                          {...field} 
                          onChange={(e) => field.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={sessionForm.control}
                  name="intensity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Intensiteit</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Laag</SelectItem>
                          <SelectItem value="medium">Gemiddeld</SelectItem>
                          <SelectItem value="high">Hoog</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={sessionForm.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Moeilijkheidsgraad</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner</SelectItem>
                          <SelectItem value="intermediate">Gemiddeld</SelectItem>
                          <SelectItem value="advanced">Gevorderd</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={sessionForm.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Locatie</FormLabel>
                    <FormControl>
                      <Input placeholder="bijv. Hoofdveld, Kunstgrasveld A" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={sessionForm.control}
                name="objectives"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Doelstellingen</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Wat wil je bereiken met deze training?"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={sessionForm.control}
                name="equipment"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Materiaal</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="bijv. Voetballen, pionnen, hesjes, doelen"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsCreateSessionOpen(false)}
                >
                  Annuleren
                </Button>
                <Button type="submit" disabled={createSession.isPending}>
                  {createSession.isPending ? "Aanmaken..." : "Sessie Aanmaken"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Session Dialog */}
      <Dialog open={isEditSessionOpen} onOpenChange={setIsEditSessionOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Trainingsessie Bewerken</DialogTitle>
          </DialogHeader>
          <Form {...sessionForm}>
            <form onSubmit={sessionForm.handleSubmit(handleEditSession)} className="space-y-4">
              {/* Same form fields as create dialog */}
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={sessionForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Naam</FormLabel>
                      <FormControl>
                        <Input placeholder="bijv. Techniektraining" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={sessionForm.control}
                  name="teamId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team (optioneel)</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(value === "none" ? undefined : Number(value))} 
                        value={field.value?.toString() || "none"}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">Geen team</SelectItem>
                          {teams.map((team) => (
                            <SelectItem key={team.id} value={team.id.toString()}>
                              {team.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={sessionForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Beschrijving</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Korte beschrijving van de training..."
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={sessionForm.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Datum</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={sessionForm.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Starttijd</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={sessionForm.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duur (minuten)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="30" 
                          max="180" 
                          {...field} 
                          onChange={(e) => field.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={sessionForm.control}
                  name="intensity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Intensiteit</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Laag</SelectItem>
                          <SelectItem value="medium">Gemiddeld</SelectItem>
                          <SelectItem value="high">Hoog</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={sessionForm.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Moeilijkheidsgraad</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner</SelectItem>
                          <SelectItem value="intermediate">Gemiddeld</SelectItem>
                          <SelectItem value="advanced">Gevorderd</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={sessionForm.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Locatie</FormLabel>
                    <FormControl>
                      <Input placeholder="bijv. Hoofdveld, Kunstgrasveld A" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={sessionForm.control}
                name="objectives"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Doelstellingen</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Wat wil je bereiken met deze training?"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={sessionForm.control}
                name="equipment"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Materiaal</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="bijv. Voetballen, pionnen, hesjes, doelen"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditSessionOpen(false)}
                >
                  Annuleren
                </Button>
                <Button type="submit" disabled={updateSession.isPending}>
                  {updateSession.isPending ? "Bijwerken..." : "Wijzigingen Opslaan"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Exercise Block Dialog */}
      <Dialog open={isExerciseBlockOpen} onOpenChange={setIsExerciseBlockOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Oefenblok Toevoegen</DialogTitle>
          </DialogHeader>
          <Form {...exerciseForm}>
            <form onSubmit={exerciseForm.handleSubmit(handleAddExerciseBlock)} className="space-y-4">
              <FormField
                control={exerciseForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naam Oefening</FormLabel>
                    <FormControl>
                      <Input placeholder="bijv. 1v1 Duel, Passing in Vierkant" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={exerciseForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Beschrijving</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Korte beschrijving van de oefening..."
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={exerciseForm.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duur (minuten)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="1" 
                          max="60" 
                          {...field} 
                          onChange={(e) => field.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={exerciseForm.control}
                  name="players"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Aantal Spelers</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="1" 
                          max="30" 
                          {...field} 
                          onChange={(e) => field.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={exerciseForm.control}
                  name="intensity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Intensiteit</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Laag</SelectItem>
                          <SelectItem value="medium">Gemiddeld</SelectItem>
                          <SelectItem value="high">Hoog</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={exerciseForm.control}
                  name="space"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ruimte</FormLabel>
                      <FormControl>
                        <Input placeholder="bijv. 20x30m, Half veld" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={exerciseForm.control}
                  name="equipment"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Materiaal</FormLabel>
                      <FormControl>
                        <Input placeholder="bijv. 4 pionnen, 2 doelen" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={exerciseForm.control}
                name="objectives"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Doelstellingen</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Wat wil je bereiken met deze oefening?"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={exerciseForm.control}
                name="instructions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Uitvoering</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Hoe wordt de oefening uitgevoerd?"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* IADATABANK Elements Selection */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <FormLabel>IADATABANK Elementen</FormLabel>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={() => setIsIadataBankOpen(true)}
                  >
                    <Target className="h-4 w-4 mr-1" />
                    Selecteer Elementen
                  </Button>
                </div>
                
                {selectedIadataElements.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {selectedIadataElements.map((elementId) => {
                      const element = iadatabankElements.find(el => el.id === elementId);
                      return element ? (
                        <Badge key={elementId} variant="secondary">
                          {element.name}
                          <button
                            type="button"
                            onClick={() => setSelectedIadataElements(prev => 
                              prev.filter(id => id !== elementId)
                            )}
                            className="ml-2 hover:bg-gray-300 rounded-full w-4 h-4 flex items-center justify-center"
                          >
                            ×
                          </button>
                        </Badge>
                      ) : null;
                    })}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">Geen elementen geselecteerd</p>
                )}
              </div>

              <div className="flex justify-end gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsExerciseBlockOpen(false)}
                >
                  Annuleren
                </Button>
                <Button type="submit" disabled={createExerciseBlock.isPending}>
                  {createExerciseBlock.isPending ? "Toevoegen..." : "Oefenblok Toevoegen"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* IADATABANK Selection Dialog */}
      <Dialog open={isIadataBankOpen} onOpenChange={setIsIadataBankOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>IADATABANK Elementen Selecteren</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {Object.entries(groupedIadataElements).map(([topic, elements]) => (
              <div key={topic} className="space-y-3">
                <h3 className="font-semibold text-lg text-gray-800 uppercase tracking-wide">
                  {topic}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {elements.map((element) => (
                    <label 
                      key={element.id} 
                      className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                    >
                      <Checkbox
                        checked={selectedIadataElements.includes(element.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedIadataElements([...selectedIadataElements, element.id]);
                          } else {
                            setSelectedIadataElements(selectedIadataElements.filter(id => id !== element.id));
                          }
                        }}
                      />
                      <div className="flex-1">
                        <div className="font-medium text-sm">{element.name}</div>
                        <div className="text-xs text-gray-500">{element.theme}</div>
                        <Badge variant={element.level === 'B+' ? 'default' : 'secondary'} className="mt-1">
                          {element.subtopic}
                        </Badge>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={() => setIsIadataBankOpen(false)}>
              Sluiten
            </Button>
            <Button onClick={() => setIsIadataBankOpen(false)}>
              Elementen Toevoegen ({selectedIadataElements.length})
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}