import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Upload, Play, Settings } from 'lucide-react';

export default function FrameExtractor() {
  const [extractionSettings, setExtractionSettings] = useState({
    frameRate: '0.5',
    format: 'jpg',
    quality: 'high'
  });
  const [isExtracting, setIsExtracting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [extractedFrames, setExtractedFrames] = useState(0);

  const frameRateOptions = [
    { value: '0.5', label: '0.5 FPS - 1 frame per 2 seconds (Recommended for match analysis)' },
    { value: '1', label: '1 FPS - 1 frame per second' },
    { value: '2', label: '2 FPS - 2 frames per second' },
    { value: '5', label: '5 FPS - 5 frames per second' },
    { value: '10', label: '10 FPS - 10 frames per second' }
  ];

  const startExtraction = async () => {
    setIsExtracting(true);
    setProgress(0);
    setExtractedFrames(0);

    try {
      // Start extraction process
      const response = await fetch('/api/extract-frames', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          frameRate: parseFloat(extractionSettings.frameRate),
          format: extractionSettings.format,
          quality: extractionSettings.quality,
          videoFile: 'match-video-1750870860329-999699725.mp4'
        })
      });

      if (response.ok) {
        // Monitor extraction progress
        const interval = setInterval(async () => {
          try {
            const statusResponse = await fetch('/api/extraction-status');
            const status = await statusResponse.json();
            
            setProgress(status.progress || 0);
            setExtractedFrames(status.framesExtracted || 0);
            
            if (status.completed) {
              clearInterval(interval);
              setIsExtracting(false);
              setProgress(100);
            }
          } catch (error) {
            console.error('Status check failed:', error);
          }
        }, 2000);
      }
    } catch (error) {
      console.error('Extraction failed:', error);
      setIsExtracting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Frame Extraction Tool</h1>
        <p className="text-gray-600">Extract frames from your Svelta VVC vs Melsele match video</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Extraction Settings
          </CardTitle>
          <CardDescription>
            Configure how you want to extract frames from your video
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <Label htmlFor="frameRate">Frame Rate</Label>
              <Select 
                value={extractionSettings.frameRate} 
                onValueChange={(value) => setExtractionSettings(prev => ({ ...prev, frameRate: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select frame rate" />
                </SelectTrigger>
                <SelectContent>
                  {frameRateOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="format">Image Format</Label>
              <Select 
                value={extractionSettings.format} 
                onValueChange={(value) => setExtractionSettings(prev => ({ ...prev, format: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="jpg">JPG (Recommended)</SelectItem>
                  <SelectItem value="png">PNG (Higher quality)</SelectItem>
                  <SelectItem value="bmp">BMP (Uncompressed)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="quality">Quality</Label>
              <Select 
                value={extractionSettings.quality} 
                onValueChange={(value) => setExtractionSettings(prev => ({ ...prev, quality: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High (1920x1080)</SelectItem>
                  <SelectItem value="medium">Medium (1280x720)</SelectItem>
                  <SelectItem value="low">Low (640x480)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-medium mb-2">Current Settings:</h3>
            <ul className="text-sm space-y-1">
              <li>• Frame Rate: <strong>{extractionSettings.frameRate} FPS</strong></li>
              <li>• Expected frames for 3:04:04 video: <strong>{Math.ceil(11044 * parseFloat(extractionSettings.frameRate))} frames</strong></li>
              <li>• Format: <strong>{extractionSettings.format.toUpperCase()}</strong></li>
              <li>• Quality: <strong>{extractionSettings.quality}</strong></li>
            </ul>
          </div>

          <Button 
            onClick={startExtraction} 
            disabled={isExtracting}
            className="w-full"
            size="lg"
          >
            {isExtracting ? (
              <>
                <Play className="mr-2 h-4 w-4 animate-spin" />
                Extracting Frames...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Start Frame Extraction
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {isExtracting && (
        <Card>
          <CardHeader>
            <CardTitle>Extraction Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Progress value={progress} className="w-full" />
            <div className="flex justify-between text-sm">
              <span>Progress: {progress.toFixed(1)}%</span>
              <span>Frames extracted: {extractedFrames}</span>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-green-50">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <div className="bg-green-100 p-2 rounded-full">
              <Settings className="h-4 w-4 text-green-600" />
            </div>
            <div>
              <h3 className="font-medium text-green-800">Why 0.5 FPS?</h3>
              <p className="text-sm text-green-700 mt-1">
                For soccer match analysis, extracting 1 frame every 2 seconds (0.5 FPS) provides excellent coverage 
                of player movements and tactics without overwhelming storage. This gives you approximately 5,522 frames 
                from your 3:04:04 match video - perfect for comprehensive analysis.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}