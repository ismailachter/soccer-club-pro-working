import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { 
  Check, 
  X, 
  Euro, 
  Settings, 
  Users, 
  Calendar, 
  Trophy, 
  BarChart3, 
  Shield,
  CreditCard,
  Building
} from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface Module {
  id: string;
  name: string;
  displayName: string;
  description: string;
  price: string;
  category: string;
  features: string[];
  isCore: boolean;
  isActive: boolean;
}

interface ClubModuleAccess {
  module: Module;
  access: {
    isEnabled: boolean;
  } | null;
}

const categoryIcons = {
  core: Settings,
  player: Users,
  training: Calendar,
  team: Shield,
  match: Trophy,
  facility: Building,
  finance: CreditCard,
  communication: Users,
  analytics: BarChart3
};

const categoryColors = {
  core: "bg-blue-100 text-blue-800 border-blue-200",
  player: "bg-green-100 text-green-800 border-green-200", 
  training: "bg-purple-100 text-purple-800 border-purple-200",
  team: "bg-orange-100 text-orange-800 border-orange-200",
  match: "bg-red-100 text-red-800 border-red-200",
  facility: "bg-gray-100 text-gray-800 border-gray-200",
  finance: "bg-yellow-100 text-yellow-800 border-yellow-200",
  communication: "bg-pink-100 text-pink-800 border-pink-200",
  analytics: "bg-indigo-100 text-indigo-800 border-indigo-200"
};

export default function SubscriptionManagement() {
  const [totalCost, setTotalCost] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: clubModules, isLoading } = useQuery({
    queryKey: ['/api/subscription/modules'],
  });

  const { data: currentCost } = useQuery({
    queryKey: ['/api/subscription/cost'],
  });

  const toggleModuleMutation = useMutation({
    mutationFn: async ({ moduleId, enabled }: { moduleId: string; enabled: boolean }) => {
      const endpoint = enabled ? 'enable' : 'disable';
      return await apiRequest('POST', `/api/subscription/modules/${moduleId}/${endpoint}`);
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/subscription/modules'] });
      queryClient.invalidateQueries({ queryKey: ['/api/subscription/cost'] });
      
      toast({
        title: variables.enabled ? "Module Enabled" : "Module Disabled",
        description: `${variables.moduleId} has been ${variables.enabled ? 'enabled' : 'disabled'}`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update module access",
        variant: "destructive"
      });
    }
  });

  useEffect(() => {
    if (currentCost) {
      setTotalCost(currentCost.total);
    }
  }, [currentCost]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const groupedModules = clubModules?.reduce((acc: Record<string, ClubModuleAccess[]>, item: ClubModuleAccess) => {
    const category = item.module.category;
    if (!acc[category]) acc[category] = [];
    acc[category].push(item);
    return acc;
  }, {}) || {};

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Subscription Management</h1>
          <p className="text-muted-foreground">
            Manage your Soccer Club Pro modules and subscription
          </p>
        </div>
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Euro className="w-5 h-5 text-blue-600" />
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Monthly Cost</p>
                <p className="text-2xl font-bold text-blue-600">€{totalCost}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {Object.entries(groupedModules).map(([category, modules]) => {
        const IconComponent = categoryIcons[category as keyof typeof categoryIcons] || Settings;
        const colorClass = categoryColors[category as keyof typeof categoryColors] || categoryColors.core;
        
        return (
          <div key={category}>
            <div className="flex items-center space-x-3 mb-4">
              <IconComponent className="w-6 h-6 text-gray-600" />
              <h2 className="text-xl font-semibold capitalize">{category} Modules</h2>
              <Badge className={colorClass}>
                {modules.length} module{modules.length !== 1 ? 's' : ''}
              </Badge>
            </div>
            
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {modules.map((item) => {
                const isEnabled = item.access?.isEnabled || false;
                const isCore = item.module.isCore;
                
                return (
                  <Card key={item.module.id} className={`relative ${isEnabled ? 'ring-2 ring-blue-200' : ''}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{item.module.displayName}</CardTitle>
                          <CardDescription className="mt-1">
                            {item.module.description}
                          </CardDescription>
                        </div>
                        <div className="flex flex-col items-end space-y-2">
                          <Badge variant={isCore ? "default" : "secondary"}>
                            {isCore ? "Core" : "Optional"}
                          </Badge>
                          <div className="text-right">
                            <span className="text-2xl font-bold text-blue-600">€{item.module.price}</span>
                            <span className="text-sm text-muted-foreground">/month</span>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Features:</p>
                        <ul className="space-y-1">
                          {item.module.features?.map((feature, index) => (
                            <li key={index} className="flex items-center text-sm text-muted-foreground">
                              <Check className="w-3 h-3 text-green-600 mr-2 flex-shrink-0" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <Separator />
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">
                          {isEnabled ? 'Enabled' : 'Disabled'}
                        </span>
                        <Switch
                          checked={isEnabled}
                          disabled={isCore || toggleModuleMutation.isPending}
                          onCheckedChange={(checked) => {
                            if (!isCore) {
                              toggleModuleMutation.mutate({
                                moduleId: item.module.id,
                                enabled: checked
                              });
                            }
                          }}
                        />
                      </div>
                      
                      {isCore && (
                        <p className="text-xs text-muted-foreground bg-blue-50 p-2 rounded">
                          Core modules are required and cannot be disabled
                        </p>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            
            <Separator className="mt-6" />
          </div>
        );
      })}

      <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5" />
            <span>Billing Information</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="text-sm text-muted-foreground">Current Plan Status</p>
              <p className="font-semibold text-green-600">Active</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Next Billing Date</p>
              <p className="font-semibold">{new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Payment Method</p>
              <p className="font-semibold">•••• •••• •••• 4242</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Monthly Total</p>
              <p className="font-semibold text-2xl text-blue-600">€{totalCost}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}