import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { AvatarUpload } from "@/components/ui/avatar-upload";
import { User } from "@/types";
import { Lock, Save, BellRing, User as UserIcon, Shield, UserPlus, KeyRound, BellOff, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("account");
  
  // Fetch current user data
  const { data: currentUser, isLoading, error } = useQuery<User>({
    queryKey: ['/api/users/1'], // Assuming the logged-in user has ID 1 for demonstration
  });

  // State for notification settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(true);
  const [matchReminders, setMatchReminders] = useState(true);
  const [trainingReminders, setTrainingReminders] = useState(true);
  const [appNotifications, setAppNotifications] = useState(true);

  if (isLoading) {
    return <div className="p-8 text-center">Loading settings...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading settings.</div>;
  }

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Settings</h2>
      </div>

      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="account" className="flex items-center gap-2">
            <UserIcon className="h-4 w-4" />
            Account
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <BellRing className="h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Lock className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="permissions" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Permissions
          </TabsTrigger>
        </TabsList>

        {/* Account Settings */}
        <TabsContent value="account" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                Update your account profile information and personal details.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <div className="md:col-span-2 flex flex-col items-center space-y-3">
                <AvatarUpload 
                  firstName={currentUser?.firstName}
                  lastName={currentUser?.lastName}
                  currentAvatar={currentUser?.profileImage}
                  onUpload={(file) => console.log('Profile photo uploaded:', file)}
                  size="xl"
                />
                
                <Badge variant="outline" className="text-primary capitalize">
                  {currentUser?.role || 'User'}
                </Badge>
              </div>
              
              <div className="md:col-span-3 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input 
                      id="firstName" 
                      defaultValue={currentUser?.firstName} 
                      placeholder="First Name" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input 
                      id="lastName" 
                      defaultValue={currentUser?.lastName} 
                      placeholder="Last Name" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      defaultValue={currentUser?.email} 
                      placeholder="Email" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input 
                      id="phone" 
                      defaultValue={currentUser?.phone} 
                      placeholder="Phone Number" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date of Birth</Label>
                    <Input 
                      id="dateOfBirth" 
                      type="date" 
                      defaultValue={currentUser?.dateOfBirth ? new Date(currentUser.dateOfBirth).toISOString().split('T')[0] : ''} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input 
                      id="username" 
                      defaultValue={currentUser?.username} 
                      placeholder="Username" 
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea 
                    id="address" 
                    rows={3}
                    defaultValue={currentUser?.address} 
                    placeholder="Your address" 
                  />
                </div>
                
                <div className="flex justify-end">
                  <Button className="flex items-center gap-2">
                    <Save className="h-4 w-4" />
                    Save Changes
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>
                Customize how you receive notifications from the platform.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Communication Channels</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                    <div className="space-y-0.5">
                      <Label className="text-base">Email Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive notifications via email
                      </p>
                    </div>
                    <Switch 
                      checked={emailNotifications} 
                      onCheckedChange={setEmailNotifications} 
                    />
                  </div>
                  <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                    <div className="space-y-0.5">
                      <Label className="text-base">SMS Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive notifications via text message
                      </p>
                    </div>
                    <Switch 
                      checked={smsNotifications} 
                      onCheckedChange={setSmsNotifications} 
                    />
                  </div>
                  <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                    <div className="space-y-0.5">
                      <Label className="text-base">In-App Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive notifications within the application
                      </p>
                    </div>
                    <Switch 
                      checked={appNotifications} 
                      onCheckedChange={setAppNotifications} 
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Notification Types</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                    <div className="space-y-0.5">
                      <Label className="text-base">Match Reminders</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive reminders for upcoming matches
                      </p>
                    </div>
                    <Switch 
                      checked={matchReminders} 
                      onCheckedChange={setMatchReminders} 
                    />
                  </div>
                  <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                    <div className="space-y-0.5">
                      <Label className="text-base">Training Reminders</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive reminders for training sessions
                      </p>
                    </div>
                    <Switch 
                      checked={trainingReminders} 
                      onCheckedChange={setTrainingReminders} 
                    />
                  </div>
                  <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                    <div className="space-y-0.5">
                      <Label className="text-base">Team Updates</Label>
                      <p className="text-sm text-muted-foreground">
                        Notifications for team roster changes
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                    <div className="space-y-0.5">
                      <Label className="text-base">Field Status</Label>
                      <p className="text-sm text-muted-foreground">
                        Updates about field availability and maintenance
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <Button variant="outline" className="flex items-center gap-2">
                  <BellOff className="h-4 w-4" />
                  Disable All
                </Button>
                <Button className="flex items-center gap-2">
                  <Save className="h-4 w-4" />
                  Save Preferences
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Manage your account security and authentication methods.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Password</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <Input 
                      id="currentPassword" 
                      type="password" 
                      placeholder="Enter your current password" 
                    />
                  </div>
                  <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">New Password</Label>
                      <Input 
                        id="newPassword" 
                        type="password" 
                        placeholder="Enter new password" 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input 
                        id="confirmPassword" 
                        type="password" 
                        placeholder="Confirm new password" 
                      />
                    </div>
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button className="flex items-center gap-2">
                    <KeyRound className="h-4 w-4" />
                    Change Password
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
                <div className="border p-4 rounded-md space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Two-Factor Authentication</p>
                      <p className="text-sm text-muted-foreground">
                        Add an extra layer of security to your account
                      </p>
                    </div>
                    <Switch defaultChecked={false} />
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <p>When two-factor authentication is enabled, you'll be prompted for a secure, random code during authentication. You can get this code from your phone's authenticator app.</p>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Login Sessions</h3>
                <div className="border p-4 rounded-md space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Currently Logged In</p>
                      <p className="text-sm text-muted-foreground">
                        Last activity: Right now
                      </p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Current Session</Badge>
                  </div>

                  <div className="text-sm">
                    <p><span className="font-medium">Device:</span> Chrome on Windows</p>
                    <p><span className="font-medium">IP Address:</span> 192.168.1.1</p>
                    <p><span className="font-medium">Location:</span> New York, USA</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Permissions Settings */}
        <TabsContent value="permissions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Role & Permissions</CardTitle>
              <CardDescription>
                Manage user roles and access permissions.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Current Role</h3>
                <div className="flex items-center space-x-4 p-4 border rounded-md">
                  <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                    <Shield className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-medium capitalize">{currentUser?.role || 'User'}</p>
                    <p className="text-sm text-muted-foreground">
                      {currentUser?.role === 'admin' ? 'Full access to all resources and settings' :
                       currentUser?.role === 'coach' ? 'Manage team, players, and training sessions' :
                       currentUser?.role === 'player' ? 'View personal data and team information' :
                       currentUser?.role === 'parent' ? 'View child data and team information' :
                       'Limited access to system features'}
                    </p>
                  </div>
                </div>
              </div>

              {currentUser?.role === 'admin' && (
                <>
                  <Separator />
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">User Management</h3>
                    <div className="flex justify-between">
                      <Button variant="outline" className="flex items-center gap-2">
                        <UserPlus className="h-4 w-4" />
                        Invite User
                      </Button>
                      <Button variant="outline" className="flex items-center gap-2">
                        <UserIcon className="h-4 w-4" />
                        Manage Users
                      </Button>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Role Assignment</h3>
                    <div className="space-y-2">
                      <Label htmlFor="assignRole">Assign Role To User</Label>
                      <div className="flex space-x-2">
                        <Select>
                          <SelectTrigger className="w-[250px]">
                            <SelectValue placeholder="Select user" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="john_doe">John Doe</SelectItem>
                            <SelectItem value="jane_smith">Jane Smith</SelectItem>
                            <SelectItem value="bob_johnson">Bob Johnson</SelectItem>
                          </SelectContent>
                        </Select>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select role" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="admin">Administrator</SelectItem>
                            <SelectItem value="coach">Coach</SelectItem>
                            <SelectItem value="player">Player</SelectItem>
                            <SelectItem value="parent">Parent</SelectItem>
                            <SelectItem value="coordinator">Coordinator</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button variant="secondary">Assign</Button>
                      </div>
                    </div>
                  </div>
                </>
              )}
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Data Privacy</h3>
                <div className="space-y-2 border p-4 rounded-md">
                  <div className="flex items-center justify-between space-x-2">
                    <div className="space-y-0.5">
                      <Label className="text-base">Profile Visibility</Label>
                      <p className="text-sm text-muted-foreground">
                        Control who can see your profile information
                      </p>
                    </div>
                    <Select defaultValue="team">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select visibility" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public</SelectItem>
                        <SelectItem value="club">Club Members Only</SelectItem>
                        <SelectItem value="team">Team Members Only</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                  <div className="space-y-0.5">
                    <Label className="text-base">Download Personal Data</Label>
                    <p className="text-sm text-muted-foreground">
                      Get a copy of all your personal data
                    </p>
                  </div>
                  <Button variant="outline">Download</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
