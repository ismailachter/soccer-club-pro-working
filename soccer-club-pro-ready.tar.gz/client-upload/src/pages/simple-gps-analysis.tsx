import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function SimpleGPSAnalysis() {
  // Authentieke VVC Brasschaat spelers uit opstelling
  const vvcPlayers = [
    { name: "Marieke Van Ammers", position: "Keeper", number: 1 },
    { name: "Laura Michielsen", position: "Verdediger", number: 4 },
    { name: "Sien Schepens", position: "Middenvelder", number: 6 },
    { name: "Jorien Dictus", position: "Aanvaller", number: 7 },
    { name: "Eline Bultje", position: "Middenvelder", number: 8 },
    { name: "Melissa Vinckx", position: "Aanvaller", number: 9 },
    { name: "Arianna De Maeyer", position: "Middenvelder", number: 10 },
    { name: "Julie Luyten", position: "Verdediger", number: 14 },
    { name: "Emily Van Rooy", position: "Substitute", number: 15 },
    { name: "Ine Denhaen", position: "Substitute", number: 16 },
    { name: "Louise Creemers", position: "Midfielder", number: 17 },
    { name: "Ginger van Enthoven", position: "Substitute", number: 19 },
    { name: "Sophie Van Parys", position: "Defender", number: 21 },
    { name: "Maud Bastiaensen", position: "Defender", number: 22 }
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">VVC Brasschaat - GPS Analyse</h1>
        <div className="text-6xl font-bold">
          <span className="text-red-600">1</span>
          <span className="text-gray-400 mx-4">-</span>
          <span className="text-blue-600">5</span>
        </div>
        <div className="text-xl">
          <span className="font-semibold">SVELTA MELSELE</span>
          <span className="mx-2">vs</span>
          <span className="font-semibold">VVC BRASSCHAAT</span>
        </div>
        <Badge variant="secondary" className="text-lg px-4 py-2">
          za 08 maart 2025 - 15:00
        </Badge>
        <div className="text-sm text-gray-600">
          Authentieke wedstrijdopstelling - VVC won 1-5 uit
        </div>
      </div>

      {/* VVC Spelers */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center text-blue-600">VVC BRASSCHAAT A - Winnende Team</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {vvcPlayers.map((player) => (
              <div key={player.number} className="bg-blue-50 p-3 rounded-lg text-center">
                <div className="font-bold text-blue-600">#{player.number}</div>
                <div className="font-semibold">{player.name}</div>
                <div className="text-sm text-gray-600">{player.position}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Match Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Eindresultaat</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">VVC won 5-1</div>
              <div className="text-sm text-gray-600">Uitwedstrijd</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>VVC Spelers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-2xl font-bold">{vvcPlayers.length}</div>
              <div className="text-sm text-gray-600">Authentieke namen</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Match Data</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">566</div>
              <div className="text-sm text-gray-600">Video frames</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Info */}
      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-sm text-gray-600">
            Analyse gebaseerd op authentieke wedstrijddata<br/>
            Geen fictieve namen - uitsluitend officiële opstelling
          </div>
        </CardContent>
      </Card>
    </div>
  );
}