import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MoreHorizontal, Edit, Plus, Calendar, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Match } from "@/types";
import { formatDate, formatTime, getStatusColor, cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

export default function Matches() {
  const [isAddMatchOpen, setIsAddMatchOpen] = useState(false);
  
  // Fetch matches data
  const { data: matches, isLoading, error } = useQuery<Match[]>({
    queryKey: ['/api/matches'],
  });

  // Define columns for data table
  const columns = [
    {
      header: "Date & Time",
      accessorKey: "date",
      cell: (match: Match) => (
        <div>
          <div>{formatDate(match.date)}</div>
          <div className="text-xs text-muted-foreground">{formatTime(match.date)}</div>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Match",
      accessorKey: "team",
      cell: (match: Match) => (
        <div>
          <div className="font-medium">{match.team?.name} vs {match.opponentName}</div>
          <div className="text-xs text-muted-foreground">{match.matchType}</div>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Location",
      accessorKey: "location",
      cell: (match: Match) => (
        <div>
          <div>{match.pitch?.name || (match.location === 'away' ? match.opponentName + ' Ground' : 'Home Field')}</div>
          <div className={cn(
            "text-xs",
            match.location === 'home' ? "text-green-600" : "text-amber-600"
          )}>
            {match.location === 'home' ? 'Home' : 'Away'}
          </div>
        </div>
      ),
      sortable: true,
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (match: Match) => (
        <Badge variant="outline" className={cn(
          "capitalize",
          getStatusColor(match.status).bg,
          getStatusColor(match.status).text
        )}>
          {match.status}
        </Badge>
      ),
      sortable: true,
    },
    {
      header: "Score",
      accessorKey: "homeScore",
      cell: (match: Match) => {
        if (match.status !== 'completed') return '-';
        
        const homeScore = match.homeScore || 0;
        const awayScore = match.awayScore || 0;
        let result;
        
        if (match.location === 'home') {
          if (homeScore > awayScore) result = "Won";
          else if (homeScore < awayScore) result = "Lost";
          else result = "Draw";
        } else {
          if (homeScore < awayScore) result = "Won";
          else if (homeScore > awayScore) result = "Lost";
          else result = "Draw";
        }
        
        const resultColor = result === "Won" ? "text-green-600" : 
                           result === "Lost" ? "text-red-600" : 
                           "text-amber-600";
        
        return (
          <div>
            <div className="font-medium">{match.homeScore} - {match.awayScore}</div>
            <div className={cn("text-xs", resultColor)}>{result}</div>
          </div>
        );
      },
      sortable: true,
    },
    {
      header: "Actions",
      accessorKey: "id",
      cell: (match: Match) => (
        <div className="flex space-x-2">
          <Button variant="outline" size="sm">
            Details
          </Button>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  if (isLoading) {
    return <div className="p-8 text-center">Loading matches...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading matches.</div>;
  }

  return (
    <div className="py-6">
      <div className="flex items-center gap-3 mb-4">
        <Link href="/">
          <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 hover:bg-gray-100">
            <ArrowLeft size={18} />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Wedstrijden</h1>
      </div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Match Schedule</h2>
        <Dialog open={isAddMatchOpen} onOpenChange={setIsAddMatchOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Schedule Match
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Schedule New Match</DialogTitle>
              <DialogDescription>
                Enter the match details below to schedule a new match.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="team">Team</Label>
                <Select>
                  <SelectTrigger id="team">
                    <SelectValue placeholder="Select team" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">U14 Lions</SelectItem>
                    <SelectItem value="2">U16 Eagles</SelectItem>
                    <SelectItem value="3">U12 Tigers</SelectItem>
                    <SelectItem value="4">U10 Panthers</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="opponentName">Opponent Name</Label>
                <Input id="opponentName" placeholder="Opponent Team Name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="matchDate">Match Date</Label>
                <Input id="matchDate" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="matchTime">Match Time</Label>
                <Input id="matchTime" type="time" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Select>
                  <SelectTrigger id="location">
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="home">Home</SelectItem>
                    <SelectItem value="away">Away</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pitch">Pitch (for home matches)</Label>
                <Select>
                  <SelectTrigger id="pitch">
                    <SelectValue placeholder="Select pitch" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Main Field</SelectItem>
                    <SelectItem value="2">Training Field 1</SelectItem>
                    <SelectItem value="3">Training Field 2</SelectItem>
                    <SelectItem value="4">Indoor Facility</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="matchType">Match Type</Label>
                <Select>
                  <SelectTrigger id="matchType">
                    <SelectValue placeholder="Select match type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="league">League Match</SelectItem>
                    <SelectItem value="friendly">Friendly</SelectItem>
                    <SelectItem value="tournament">Tournament</SelectItem>
                    <SelectItem value="cup">Cup</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 col-span-full">
                <Label htmlFor="notes">Notes</Label>
                <Textarea id="notes" placeholder="Any additional information about the match" rows={3} />
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsAddMatchOpen(false)}>
                Cancel
              </Button>
              <Button>Schedule Match</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Match filters */}
      <Card className="mb-6 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div>
            <Label htmlFor="match-team-filter" className="mb-1 block">Team</Label>
            <Select>
              <SelectTrigger id="match-team-filter">
                <SelectValue placeholder="All Teams" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Teams</SelectItem>
                <SelectItem value="1">U14 Lions</SelectItem>
                <SelectItem value="2">U16 Eagles</SelectItem>
                <SelectItem value="3">U12 Tigers</SelectItem>
                <SelectItem value="4">U10 Panthers</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="match-date-filter" className="mb-1 block">Date Range</Label>
            <Select>
              <SelectTrigger id="match-date-filter">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="upcoming">Upcoming</SelectItem>
                <SelectItem value="this_week">This Week</SelectItem>
                <SelectItem value="this_month">This Month</SelectItem>
                <SelectItem value="previous">Previous Matches</SelectItem>
                <SelectItem value="all">All Matches</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="match-location-filter" className="mb-1 block">Location</Label>
            <Select>
              <SelectTrigger id="match-location-filter">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                <SelectItem value="home">Home</SelectItem>
                <SelectItem value="away">Away</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* Matches table */}
      <DataTable
        data={matches || []}
        columns={columns}
        searchable={false}
      />
    </div>
  );
}
