import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface TacticalPlayer {
  player_name: string;
  team: 'home' | 'away';
  basics_passing_accuracy: number;
  basics_first_touch_success: number;
  basics_ball_control_rating: number;
  basics_positioning_score: number;
  successful_passes: number;
  failed_passes: number;
  key_passes: number;
  interceptions: number;
  tackles_won: number;
  tackles_lost: number;
  duels_won: number;
  duels_lost: number;
  pressing_actions: number;
  defensive_actions: number;
  attacking_actions: number;
  transition_actions: number;
}

interface TeamTactical {
  team: 'home' | 'away';
  possession_percentage: number;
  passing_accuracy: number;
  pressing_intensity: number;
  defensive_compactness: number;
  attacking_width: number;
  transition_speed: number;
  formation_used: string;
  buildup_actions: number;
  pressing_actions: number;
  defensive_actions: number;
  counter_attacks: number;
}

const TacticalAnalysis = () => {
  const [selectedMatch] = useState("match-1750870860329"); // Your 4.2GB video

  const { data: tacticalData } = useQuery({
    queryKey: [`/api/tactical-analysis/${selectedMatch}`],
    enabled: !!selectedMatch
  });

  const { data: teamTacticalData } = useQuery({
    queryKey: [`/api/team-tactical/${selectedMatch}`],
    enabled: !!selectedMatch
  });

  const players: TacticalPlayer[] = tacticalData?.players || [];
  const teams: TeamTactical[] = teamTacticalData?.teams || [];

  const vvcPlayers = players.filter(p => p.team === 'home');
  const sveltaPlayers = players.filter(p => p.team === 'away');
  const vvcTeam = teams.find(t => t.team === 'home');
  const sveltaTeam = teams.find(t => t.team === 'away');

  const getRatingColor = (rating: number, max: number = 100) => {
    const percentage = (rating / max) * 100;
    if (percentage >= 80) return "bg-green-500";
    if (percentage >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };

  const PlayerCard = ({ player }: { player: TacticalPlayer }) => {
    const teamName = player.team === 'home' ? 'VVC Brasschaat' : 'Svelta Melsele';
    const teamColor = player.team === 'home' ? 'text-red-600' : 'text-blue-600';
    
    return (
      <Card className="mb-4">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">{player.player_name}</CardTitle>
            <Badge className={teamColor}>{teamName}</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold mb-2 text-blue-600">BASICS Elements</h4>
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Pass Accuracy</span>
                    <span>{player.basics_passing_accuracy}%</span>
                  </div>
                  <Progress value={player.basics_passing_accuracy} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm">
                    <span>First Touch Success</span>
                    <span>{player.basics_first_touch_success}%</span>
                  </div>
                  <Progress value={player.basics_first_touch_success} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Ball Control</span>
                    <span>{player.basics_ball_control_rating}/10</span>
                  </div>
                  <Progress value={player.basics_ball_control_rating * 10} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Positioning</span>
                    <span>{player.basics_positioning_score}/10</span>
                  </div>
                  <Progress value={player.basics_positioning_score * 10} className="h-2" />
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-2 text-green-600">Individual Actions</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>Passes: {player.successful_passes}/{player.successful_passes + player.failed_passes}</div>
                <div>Key Passes: {player.key_passes}</div>
                <div>Tackles: {player.tackles_won}/{player.tackles_won + player.tackles_lost}</div>
                <div>Duels: {player.duels_won}/{player.duels_won + player.duels_lost}</div>
                <div>Interceptions: {player.interceptions}</div>
                <div>Pressing: {player.pressing_actions}</div>
                <div>Defensive: {player.defensive_actions}</div>
                <div>Attacking: {player.attacking_actions}</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const TeamCard = ({ team }: { team: TeamTactical }) => {
    const teamName = team.team === 'home' ? 'VVC Brasschaat' : 'Svelta Melsele';
    const teamColor = team.team === 'home' ? 'border-red-500' : 'border-blue-500';
    
    return (
      <Card className={`border-2 ${teamColor}`}>
        <CardHeader>
          <CardTitle className="text-xl">{teamName}</CardTitle>
          <p className="text-sm text-gray-600">Formation: {team.formation_used}</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold mb-2">Team Statistics</h4>
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Possession</span>
                    <span>{team.possession_percentage}%</span>
                  </div>
                  <Progress value={team.possession_percentage} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Pass Accuracy</span>
                    <span>{team.passing_accuracy}%</span>
                  </div>
                  <Progress value={team.passing_accuracy} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Pressing Intensity</span>
                    <span>{team.pressing_intensity}/10</span>
                  </div>
                  <Progress value={team.pressing_intensity * 10} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Defensive Compactness</span>
                    <span>{team.defensive_compactness}/10</span>
                  </div>
                  <Progress value={team.defensive_compactness * 10} className="h-2" />
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-2">Team Actions</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>Buildup: {team.buildup_actions}</div>
                <div>Pressing: {team.pressing_actions}</div>
                <div>Defensive: {team.defensive_actions}</div>
                <div>Counter Attacks: {team.counter_attacks}</div>
                <div>Attack Width: {team.attacking_width}/10</div>
                <div>Transition Speed: {team.transition_speed}/10</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="container mx-auto p-4">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Tactical Analysis</h1>
        <p className="text-gray-600">IADATABANK Tactical Elements - Svelta Melsele vs VVC Brasschaat</p>
      </div>

      <Tabs defaultValue="team" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="team">Team Analysis</TabsTrigger>
          <TabsTrigger value="individual">Individual Players</TabsTrigger>
          <TabsTrigger value="basics">BASICS Elements</TabsTrigger>
        </TabsList>
        
        <TabsContent value="team" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {vvcTeam && <TeamCard team={vvcTeam} />}
            {sveltaTeam && <TeamCard team={sveltaTeam} />}
          </div>
        </TabsContent>
        
        <TabsContent value="individual" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <h3 className="text-xl font-semibold mb-4 text-red-600">VVC Brasschaat Players</h3>
              {vvcPlayers.slice(0, 6).map((player, index) => (
                <PlayerCard key={index} player={player} />
              ))}
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-600">Svelta Melsele Players</h3>
              {sveltaPlayers.slice(0, 6).map((player, index) => (
                <PlayerCard key={index} player={player} />
              ))}
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="basics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {players.slice(0, 12).map((player, index) => (
              <Card key={index} className="p-4">
                <h4 className="font-semibold mb-2">{player.player_name}</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Pass Accuracy:</span>
                    <Badge>{player.basics_passing_accuracy}%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Ball Control:</span>
                    <Badge>{player.basics_ball_control_rating}/10</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Positioning:</span>
                    <Badge>{player.basics_positioning_score}/10</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>First Touch:</span>
                    <Badge>{player.basics_first_touch_success}%</Badge>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TacticalAnalysis;