import { useState } from "react";
import { Check, Palette } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const themes = [
  {
    id: "blue",
    name: "Blauw Klassiek",
    primary: "#4a90e2",
    secondary: "#6c5ce7",
    description: "Professioneel blauw thema",
    categories: ["all"]
  },
  {
    id: "green",
    name: "Gras Groen",
    primary: "#27ae60",
    secondary: "#2ecc71",
    description: "Voetbalveld groen thema",
    categories: ["all"]
  },
  {
    id: "orange",
    name: "Oranje Power",
    primary: "#e67e22",
    secondary: "#f39c12",
    description: "Energiek oranje thema",
    categories: ["all"]
  },
  {
    id: "purple",
    name: "Paars Elite",
    primary: "#8e44ad",
    secondary: "#9b59b6",
    description: "Luxe paars thema",
    categories: ["all"]
  },
  {
    id: "red",
    name: "Rood Passie",
    primary: "#e74c3c",
    secondary: "#c0392b",
    description: "Krachtig rood thema",
    categories: ["all"]
  },
  {
    id: "dark",
    name: "Donker Professioneel",
    primary: "#232e5d",
    secondary: "#ffffff",
    description: "Moderne donkere look",
    categories: ["all"]
  },
  {
    id: "gold",
    name: "Goud B+",
    primary: "#FFD700",
    secondary: "#FFA500",
    description: "Premium goudkleurig thema",
    categories: ["BASICS", "TEAMTACTISCH"]
  },
  {
    id: "silver",
    name: "Zilver B-",
    primary: "#C0C0C0",
    secondary: "#808080",
    description: "Elegant zilverkleurig thema",
    categories: ["BASICS", "TEAMTACTISCH"]
  }
];

interface ThemeSelectorProps {
  currentCategory?: string;
}

export function ThemeSelector({ currentCategory = "all" }: ThemeSelectorProps) {
  const [currentTheme, setCurrentTheme] = useState("blue");

  // Filter themes based on current category
  const availableThemes = themes.filter(theme => 
    theme.categories.includes("all") || 
    theme.categories.includes(currentCategory)
  );

  const applyTheme = (theme: typeof themes[0]) => {
    const root = document.documentElement;
    
    console.log("Setting primary color:", theme.primary);
    console.log("Setting secondary color:", theme.secondary);
    
    // Convert hex to HSL for CSS custom properties
    const primaryHsl = hexToHsl(theme.primary);
    const secondaryHsl = hexToHsl(theme.secondary);
    
    console.log("Primary HSL:", primaryHsl);
    
    // Apply CSS custom properties
    root.style.setProperty('--primary', primaryHsl);
    root.style.setProperty('--secondary', secondaryHsl);
    
    // Store theme preference
    localStorage.setItem('selected-theme', theme.id);
    setCurrentTheme(theme.id);
  };

  const hexToHsl = (hex: string): string => {
    const r = parseInt(hex.slice(1, 3), 16) / 255;
    const g = parseInt(hex.slice(3, 5), 16) / 255;
    const b = parseInt(hex.slice(5, 7), 16) / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }

    return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
  };

  // Load saved theme on component mount
  useState(() => {
    const savedTheme = localStorage.getItem('selected-theme') || 'blue';
    const theme = themes.find(t => t.id === savedTheme) || themes[0];
    applyTheme(theme);
    setCurrentTheme(savedTheme);
  });

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Palette className="h-4 w-4" />
          Thema
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        {availableThemes.map((theme) => (
          <DropdownMenuItem
            key={theme.id}
            className="flex items-center justify-between cursor-pointer"
            onClick={() => applyTheme(theme)}
          >
            <div className="flex items-center gap-3">
              <div 
                className="w-4 h-4 rounded-full border border-gray-300"
                style={{ backgroundColor: theme.primary }}
              />
              <div>
                <div className="font-medium">{theme.name}</div>
                <div className="text-xs text-muted-foreground">{theme.description}</div>
              </div>
            </div>
            {currentTheme === theme.id && (
              <Check className="h-4 w-4 text-primary" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}