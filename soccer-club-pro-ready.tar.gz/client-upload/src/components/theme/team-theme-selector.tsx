import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Palette, Check, Save } from 'lucide-react';
import { useTeamTheme } from '@/hooks/use-team-theme';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

export function TeamThemeSelector() {
  const { currentTheme, applyTheme, generateThemeFromColors, teamColorPresets, userTeam, isTeamThemeAvailable } = useTeamTheme();
  const { toast } = useToast();
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null);
  const [customColors, setCustomColors] = useState({
    primaryColor: currentTheme.primaryColor,
    secondaryColor: currentTheme.secondaryColor,
    accentColor: currentTheme.accentColor,
    textColor: currentTheme.textColor
  });

  const handlePresetSelect = (preset: typeof teamColorPresets[0]) => {
    setSelectedPreset(preset.name);
    const newTheme = generateThemeFromColors(
      preset.primaryColor,
      preset.secondaryColor,
      preset.accentColor,
      preset.textColor
    );
    applyTheme(newTheme);
    setCustomColors({
      primaryColor: preset.primaryColor,
      secondaryColor: preset.secondaryColor,
      accentColor: preset.accentColor,
      textColor: preset.textColor
    });
  };

  const handleCustomColorChange = (colorType: keyof typeof customColors, value: string) => {
    const newCustomColors = { ...customColors, [colorType]: value };
    setCustomColors(newCustomColors);
    
    const newTheme = generateThemeFromColors(
      newCustomColors.primaryColor,
      newCustomColors.secondaryColor,
      newCustomColors.accentColor,
      newCustomColors.textColor
    );
    applyTheme(newTheme);
    setSelectedPreset(null); // Clear preset selection when using custom colors
  };

  const saveTeamColors = async () => {
    if (!userTeam?.id) {
      toast({
        title: "Geen team gevonden",
        description: "Je moet lid zijn van een team om kleuren op te slaan.",
        variant: "destructive"
      });
      return;
    }

    try {
      await apiRequest(`/api/teams/${userTeam.id}/colors`, {
        method: 'PUT',
        body: customColors
      });

      toast({
        title: "Team kleuren opgeslagen",
        description: "De teamkleuren zijn succesvol bijgewerkt voor alle teamleden."
      });
    } catch (error) {
      toast({
        title: "Fout bij opslaan",
        description: "Er is een fout opgetreden bij het opslaan van de teamkleuren.",
        variant: "destructive"
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Palette className="h-5 w-5" />
          <span>Team Kleur Thema</span>
        </CardTitle>
        {isTeamThemeAvailable && (
          <Badge variant="secondary" className="w-fit">
            {userTeam?.name} Kleuren Actief
          </Badge>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Preset Color Themes */}
        <div>
          <Label className="text-sm font-medium mb-3 block">Vooraf Ingestelde Thema's</Label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {teamColorPresets.map((preset) => (
              <Button
                key={preset.name}
                variant="outline"
                className={`h-16 p-2 ${selectedPreset === preset.name ? 'ring-2 ring-blue-500' : ''}`}
                onClick={() => handlePresetSelect(preset)}
                style={{
                  background: `linear-gradient(135deg, ${preset.primaryColor} 0%, ${preset.secondaryColor} 100%)`
                }}
              >
                <div className="flex flex-col items-center space-y-1">
                  {selectedPreset === preset.name && (
                    <Check className="h-4 w-4" style={{ color: preset.textColor }} />
                  )}
                  <span className="text-xs font-medium" style={{ color: preset.textColor }}>
                    {preset.name}
                  </span>
                </div>
              </Button>
            ))}
          </div>
        </div>

        {/* Custom Color Picker */}
        <div>
          <Label className="text-sm font-medium mb-3 block">Aangepaste Kleuren</Label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="primary-color" className="text-xs text-gray-600">Hoofdkleur</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="primary-color"
                  type="color"
                  value={customColors.primaryColor}
                  onChange={(e) => handleCustomColorChange('primaryColor', e.target.value)}
                  className="w-12 h-8 p-1 border rounded"
                />
                <Input
                  type="text"
                  value={customColors.primaryColor}
                  onChange={(e) => handleCustomColorChange('primaryColor', e.target.value)}
                  className="flex-1 text-xs"
                  placeholder="#3b82f6"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="secondary-color" className="text-xs text-gray-600">Secundaire kleur</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="secondary-color"
                  type="color"
                  value={customColors.secondaryColor}
                  onChange={(e) => handleCustomColorChange('secondaryColor', e.target.value)}
                  className="w-12 h-8 p-1 border rounded"
                />
                <Input
                  type="text"
                  value={customColors.secondaryColor}
                  onChange={(e) => handleCustomColorChange('secondaryColor', e.target.value)}
                  className="flex-1 text-xs"
                  placeholder="#1e40af"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="accent-color" className="text-xs text-gray-600">Accent kleur</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="accent-color"
                  type="color"
                  value={customColors.accentColor}
                  onChange={(e) => handleCustomColorChange('accentColor', e.target.value)}
                  className="w-12 h-8 p-1 border rounded"
                />
                <Input
                  type="text"
                  value={customColors.accentColor}
                  onChange={(e) => handleCustomColorChange('accentColor', e.target.value)}
                  className="flex-1 text-xs"
                  placeholder="#60a5fa"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="text-color" className="text-xs text-gray-600">Tekstkleur</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="text-color"
                  type="color"
                  value={customColors.textColor}
                  onChange={(e) => handleCustomColorChange('textColor', e.target.value)}
                  className="w-12 h-8 p-1 border rounded"
                />
                <Input
                  type="text"
                  value={customColors.textColor}
                  onChange={(e) => handleCustomColorChange('textColor', e.target.value)}
                  className="flex-1 text-xs"
                  placeholder="#ffffff"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Theme Preview */}
        <div>
          <Label className="text-sm font-medium mb-3 block">Voorbeeld</Label>
          <div 
            className="p-4 rounded-lg border"
            style={{
              background: `linear-gradient(135deg, ${currentTheme.primaryColor} 0%, ${currentTheme.secondaryColor} 100%)`
            }}
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold" style={{ color: currentTheme.textColor }}>
                  Dashboard Header
                </h3>
                <p className="text-sm opacity-90" style={{ color: currentTheme.textColor }}>
                  Dit is hoe je dashboard eruit ziet met deze kleuren
                </p>
              </div>
              <div 
                className="px-3 py-1 rounded text-xs font-medium"
                style={{ 
                  backgroundColor: currentTheme.accentColor,
                  color: currentTheme.textColor 
                }}
              >
                Accent Badge
              </div>
            </div>
          </div>
        </div>

        {/* Save Button */}
        {userTeam && (
          <Button onClick={saveTeamColors} className="w-full">
            <Save className="h-4 w-4 mr-2" />
            Opslaan voor {userTeam.name}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}