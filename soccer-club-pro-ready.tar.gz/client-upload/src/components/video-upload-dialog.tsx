import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Upload, Video, Play, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface VideoUploadDialogProps {
  trigger: React.ReactNode;
}

export default function VideoUploadDialog({ trigger }: VideoUploadDialogProps) {
  const [open, setOpen] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [analysisStatus, setAnalysisStatus] = useState<'idle' | 'uploading' | 'processing' | 'completed' | 'error'>('idle');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [analysisResults, setAnalysisResults] = useState<any>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: '',
    team: '',
    matchType: '',
    opponent: '',
    date: '',
    description: ''
  });

  const teams = [
    { id: 'dames-ip', name: 'Dames IP' },
    { id: 'dames-provinciaal', name: 'Dames Provinciaal' },
    { id: 'mu20', name: 'MU20' }
  ];

  const matchTypes = [
    { id: 'match', name: 'Competition Match' },
    { id: 'friendly', name: 'Friendly Match' },
    { id: 'training', name: 'Training Session' },
    { id: 'scrimmage', name: 'Scrimmage' }
  ];

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setFormData(prev => ({
        ...prev,
        title: prev.title || file.name.replace(/\.[^/.]+$/, "")
      }));
    }
  };

  const simulateAnalysis = async () => {
    setAnalysisStatus('uploading');
    
    // Simulate upload progress
    for (let i = 0; i <= 100; i += 10) {
      setUploadProgress(i);
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    setAnalysisStatus('processing');
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Generate mock analysis results
    const mockResults = {
      buildUpSuccess: Math.floor(Math.random() * 20) + 70, // 70-90%
      passAccuracy: Math.floor(Math.random() * 15) + 75, // 75-90%
      pressureRecovery: Math.floor(Math.random() * 25) + 60, // 60-85%
      ballPossession: Math.floor(Math.random() * 20) + 45, // 45-65%
      shotsOnTarget: Math.floor(Math.random() * 6) + 3, // 3-8
      cornerKicks: Math.floor(Math.random() * 8) + 2, // 2-10
      offsides: Math.floor(Math.random() * 3) + 1, // 1-4
      fouls: Math.floor(Math.random() * 8) + 12, // 12-20
      playerPerformance: [
        { name: 'Sarah Van Der Berg', technical: 8.5, tactical: 7.8, physical: 8.2, mental: 8.0 },
        { name: 'Lisa Janssens', technical: 7.9, tactical: 8.3, physical: 7.5, mental: 8.1 },
        { name: 'Emma De Smet', technical: 8.1, tactical: 7.6, physical: 8.8, mental: 7.9 },
        { name: 'Sofie Peeters', technical: 7.7, tactical: 8.0, physical: 7.8, mental: 8.2 },
        { name: 'Anna Mertens', technical: 8.3, tactical: 7.9, physical: 8.0, mental: 7.7 }
      ],
      tacticalInsights: [
        'Build-up play most effective through the left flank',
        'High pressing resulted in 3 turnovers leading to scoring chances',
        'Midfield dominance in central areas during first half',
        'Defensive line maintained good compactness throughout'
      ]
    };
    
    setAnalysisResults(mockResults);
    setAnalysisStatus('completed');
    
    toast({
      title: "Analysis Complete",
      description: "Video analysis has been completed successfully. Results are now available.",
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a video file to upload.",
        variant: "destructive"
      });
      return;
    }

    if (!formData.team || !formData.matchType) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    await simulateAnalysis();
  };

  const resetForm = () => {
    setSelectedFile(null);
    setUploadProgress(0);
    setAnalysisStatus('idle');
    setAnalysisResults(null);
    setFormData({
      title: '',
      team: '',
      matchType: '',
      opponent: '',
      date: '',
      description: ''
    });
  };

  const handleClose = () => {
    setOpen(false);
    setTimeout(resetForm, 300); // Reset after dialog closes
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Video className="w-5 h-5" />
            Video Upload & Analysis
          </DialogTitle>
          <DialogDescription>
            Upload your Veo camera footage for comprehensive soccer analysis
          </DialogDescription>
        </DialogHeader>

        {analysisStatus === 'idle' && (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="file-upload">Video File *</Label>
                <div className="mt-1">
                  <Input
                    id="file-upload"
                    type="file"
                    accept="video/*"
                    onChange={handleFileSelect}
                    className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                  />
                </div>
                {selectedFile && (
                  <div className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                    <Video className="w-4 h-4" />
                    <span>{selectedFile.name}</span>
                    <Badge variant="secondary">{(selectedFile.size / 1024 / 1024).toFixed(1)} MB</Badge>
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="title">Analysis Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g., Dames IP vs KRC Gent"
                />
              </div>

              <div>
                <Label htmlFor="team">Team *</Label>
                <Select value={formData.team} onValueChange={(value) => setFormData(prev => ({ ...prev, team: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select team" />
                  </SelectTrigger>
                  <SelectContent>
                    {teams.map((team) => (
                      <SelectItem key={team.id} value={team.id}>
                        {team.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="matchType">Type *</Label>
                <Select value={formData.matchType} onValueChange={(value) => setFormData(prev => ({ ...prev, matchType: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {matchTypes.map((type) => (
                      <SelectItem key={type.id} value={type.id}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="opponent">Opponent</Label>
                <Input
                  id="opponent"
                  value={formData.opponent}
                  onChange={(e) => setFormData(prev => ({ ...prev, opponent: e.target.value }))}
                  placeholder="e.g., KRC Gent"
                />
              </div>

              <div>
                <Label htmlFor="date">Match Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Additional Notes</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Any specific aspects to focus on during analysis..."
                rows={3}
              />
            </div>

            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancel
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                <Upload className="w-4 h-4 mr-2" />
                Start Analysis
              </Button>
            </div>
          </form>
        )}

        {analysisStatus === 'uploading' && (
          <div className="space-y-6 text-center py-8">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
              <Upload className="w-8 h-8 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Uploading Video</h3>
              <p className="text-gray-600">Preparing your footage for analysis...</p>
            </div>
            <div className="max-w-md mx-auto">
              <Progress value={uploadProgress} className="h-3" />
              <p className="text-sm text-gray-500 mt-2">{uploadProgress}% complete</p>
            </div>
          </div>
        )}

        {analysisStatus === 'processing' && (
          <div className="space-y-6 text-center py-8">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto">
              <Clock className="w-8 h-8 text-purple-600 animate-spin" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Analyzing Video</h3>
              <p className="text-gray-600">AI is processing your footage and generating insights...</p>
            </div>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span>Player tracking</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span>Ball movement</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-600" />
                <span>Tactical analysis</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-600" />
                <span>Performance metrics</span>
              </div>
            </div>
          </div>
        )}

        {analysisStatus === 'completed' && analysisResults && (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold">Analysis Complete!</h3>
              <p className="text-gray-600">Your video has been analyzed successfully</p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-700">{analysisResults.buildUpSuccess}%</div>
                <div className="text-sm text-blue-600">Build-up Success</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-green-700">{analysisResults.passAccuracy}%</div>
                <div className="text-sm text-green-600">Pass Accuracy</div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-purple-700">{analysisResults.pressureRecovery}%</div>
                <div className="text-sm text-purple-600">Pressure Recovery</div>
              </div>
              <div className="bg-orange-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-orange-700">{analysisResults.ballPossession}%</div>
                <div className="text-sm text-orange-600">Ball Possession</div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">Top Player Performances</h4>
                <div className="space-y-2">
                  {analysisResults.playerPerformance.slice(0, 3).map((player: any, index: number) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <span className="font-medium">{player.name}</span>
                      <div className="flex gap-2 text-sm">
                        <span className="text-blue-600">T: {player.technical}</span>
                        <span className="text-green-600">Tac: {player.tactical}</span>
                        <span className="text-purple-600">P: {player.physical}</span>
                        <span className="text-orange-600">M: {player.mental}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-3">Tactical Insights</h4>
                <div className="space-y-2">
                  {analysisResults.tacticalInsights.map((insight: string, index: number) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span>{insight}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={handleClose}>
                Close
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Play className="w-4 h-4 mr-2" />
                View Full Analysis
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}