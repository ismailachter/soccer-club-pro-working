import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  trend?: {
    value: string;
    positive?: boolean;
  };
  className?: string;
  iconColorClass?: string;
}

export function StatsCard({
  title,
  value,
  subtitle,
  icon,
  trend,
  className,
  iconColorClass = "bg-primary-100 text-primary-600"
}: StatsCardProps) {
  return (
    <Card className={cn("", className)}>
      <CardContent className="p-5">
        <div className="flex items-center">
          <div className={cn("flex-shrink-0 rounded-md p-3", iconColorClass)}>
            {icon}
          </div>
          <div className="ml-5">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-semibold text-foreground">{value}</p>
          </div>
        </div>
        
        {(trend || subtitle) && (
          <div className="mt-4 flex items-center text-sm">
            {trend && (
              <div className={cn(
                "flex items-center",
                trend.positive ? "text-green-600" : "text-red-600"
              )}>
                <i className={cn(
                  "ri-arrow-up-line mr-2",
                  !trend.positive && "transform rotate-180"
                )}></i>
                <span>{trend.value}</span>
              </div>
            )}
            
            {subtitle && (
              <span className={cn("text-muted-foreground", trend && "ml-auto")}>
                {subtitle}
              </span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
