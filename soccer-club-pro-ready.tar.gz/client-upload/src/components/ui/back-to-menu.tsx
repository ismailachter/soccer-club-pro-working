import { Button } from "@/components/ui/button";
import { ArrowLeft, Home } from "lucide-react";
import { useLocation } from "wouter";

interface BackToMenuProps {
  className?: string;
  variant?: "default" | "outline" | "ghost";
  size?: "default" | "sm" | "lg";
}

export function BackToMenu({ className = "", variant = "outline", size = "sm" }: BackToMenuProps) {
  const [, setLocation] = useLocation();

  return (
    <Button
      variant={variant}
      size={size}
      onClick={() => setLocation("/")}
      className={`flex items-center gap-2 ${className}`}
    >
      <ArrowLeft className="h-4 w-4" />
      <Home className="h-4 w-4" />
      Terug naar Menu
    </Button>
  );
}