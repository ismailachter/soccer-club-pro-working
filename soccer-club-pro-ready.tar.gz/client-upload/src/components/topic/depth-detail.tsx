import { useState } from "react";
import { ChevronRight, Target, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { basicsDepth } from "@/data/basics-depth";
import { teamtactischDepth } from "@/data/teamtactisch-depth";
import { mentaalDepth } from "@/data/mentaal-depth";

interface DepthDetailProps {
  elementName: string;
  topic?: string;
  subtopic?: string;
  subcategory?: string;
  children?: React.ReactNode;
}

export function DepthDetail({ elementName, topic, subtopic, subcategory, children }: DepthDetailProps) {
  const [selectedLevel, setSelectedLevel] = useState<string>("");
  
  // Convert element name to key format for different topics
  const getElementKey = (name: string, currentTopic?: string): string => {
    // TEAMTACTISCH mappings
    if (currentTopic === "TEAMTACTISCH") {
      const teamTactischMappings: { [key: string]: string } = {
        "Creeer ruimte": "CREEER_RUIMTE",
        "Creeer hoogte, diepte": "CREEER_HOOGTE_DIEPTE", 
        "Creeer meerderheidssituaties": "CREEER_MEERDERHEIDSSITUATIES",
        "Driekhoeksspel": "DRIEKHOEKSSPEL",
        "Creeer 3 x aanspeelbaarheid": "CREEER_3X_AANSPEELBAARHEID",
        "Vlotte eficiënte balcirculatie": "BALBEZIT",
        "Hoog tempo balbezit": "HOOG_TEMPO_BALBEZIT",
        "Diagonal in & uit": "DIAGONAL_IN_UIT",
        "Linie overslaan": "LINIE_OVERSLAAN",
        // VOORUITGANG & INFILTRATIE elements
        "Positie tussen de linies": "POSITIE_TUSSEN_DE_LINIES",
        "Diepgaande infiltraties": "DIEPGAANDE_INFILTRATIES",
        "Interacties 2, 3 linies": "INTERACTIES_2_3_LINIES",
        "Vermijd onnodig balverlies": "VERMIJD_ONNODIG_BALVERLIES",
        "Individuele actie": "INDIVIDUELE_ACTIE",
        "Subtiele laatste pass": "SUBTIELE_LAATSTE_PASS",
        "Voorzet": "VOORZET",
        "Vroege voorzet": "VROEGE_VOORZET",
        // DOELPUNTEN MAKEN elements
        "4 in de 16": "VIER_IN_DE_16",
        "Aanvallen van de blinde zijde verdediging": "AANVALLEN_BLINDE_ZIJDE",
        "Kordate afwerking": "KORDATE_AFWERKING",
        "Posities innemen in de 16": "POSITIES_INNEMEN_16",
        "Flankvoorzetten": "FLANKVOORZETTEN"
      };
      
      if (teamTactischMappings[name]) {
        return teamTactischMappings[name];
      }
    }
    
    // BASICS mappings - improved mapping for B- elements
    // Special mappings for B- elements with special characters
    const specialMappings: { [key: string]: string } = {
      "1v1 Druk zetten, Tackle, Remmen": "DRUK_ZETTEN_TACKLE_REMMEN",
      "Interceptie voor balcontrole op korte passing": "INTERCEPTIE_BALCONTROLE_KORTE_PASSING",
      "Interceptie voor balcontrole op middellange passing": "INTERCEPTIE_BALCONTROLE_MIDDELLANGE_PASSING",
      "Interceptie voor balcontrole op lange passing": "INTERCEPTIE_BALCONTROLE_LANGE_PASSING",
      "Interceptie voor balcontrole op kopbal": "INTERCEPTIE_BALCONTROLE_KOPBAL",
      "Interceptie voor balcontrole op kaatsbal": "INTERCEPTIE_BALCONTROLE_KAATSBAL",
      "Interceptie na balcontrole korte pass": "INTERCEPTIE_NA_BALCONTROLE_KORTE_PASS",
      "Interceptie na balcontrole middellange pass": "INTERCEPTIE_NA_BALCONTROLE_MIDDELLANGE_PASS",
      "Interceptie na balcontrole lange pass": "INTERCEPTIE_NA_BALCONTROLE_LANGE_PASS",
      "Afweren, Schieten op doel beletten": "AFWEREN_SCHIETEN_BELETTEN",
      "Afweren, Scoren met de voet beletten": "AFWEREN_SCOREN_VOET_BELETTEN",
      "Afweren, Scoren met het hoofd beletten": "AFWEREN_SCOREN_HOOFD_BELETTEN",
      "Afweren, Scoren na invididuele actie, tricks beletten": "AFWEREN_SCOREN_INDIVIDUELE_ACTIE_BELETTEN",
      "Speelhoeken afsluiten": "SPEELHOEKEN_AFSLUITEN",
      "Strikte dekking": "STRIKTE_DEKKING",
      "Rugdekking": "RUGDEKKING",
      // OMSCH B-/B+ TEGENAANVAL elements
      "5S in de 16": "VIJF_S_IN_DE_16",
      "Schuif mee in": "SCHUIF_MEE_IN",
      "Loop in de ruimte": "LOOP_IN_DE_RUIMTE",
      "Speel diep": "SPEEL_DIEP",
      // OMSCH B-/B+ OP BALBEZIT SPELEN elements
      "Speel uit de druk van het blok": "SPEEL_UIT_DE_DRUK_VAN_HET_BLOK",
      "Verander van zijde": "VERANDER_VAN_ZIJDE",
      "Verleng het veld": "VERLENG_HET_VELD",
      // OMSCH B+/B- TEGEN DRUK ZETTEN elements
      "1 tik verdedigend": "EEN_TIK_VERDEDIGEND", 
      "Onderbreek en herover de bal": "ONDERBREEK_EN_HEROVER_DE_BAL",
      // OMSCH B+/B- HERVORMEN OPSTELLING elements
      "Bescherm de ruimte": "BESCHERM_DE_RUIMTE",
      "Hou de bal voor je": "HOU_DE_BAL_VOOR_JE",
      "Doel afschermen": "DOEL_AFSCHERMEN",
      // MENTAAL elements
      "Concentratie": "CONCENTRATIE",
      "Rustig vs onrustig": "RUSTIG_VS_ONRUSTIG",
      "Spontaniteit": "SPONTANITEIT",
      "Egoistisch": "EGOISTISCH",
      "Afleiding": "AFLEIDING",
      "Nabootsen": "NABOOTSEN",
      "Zelfvertrouwen": "ZELFVERTROUWEN",
      "Zoeken naar bevestiging": "ZOEKEN_NAAR_BEVESTIGING",
      "Inlevingsvermogen": "INLEVINGSVERMOGEN",
      "Winnaarsmentaliteit": "WINNAARSMENTALITEIT",
      "Emotionele weerbaarheid/stabiliteit": "EMOTIONELE_WEERBAARHEID_STABILITEIT",
      "Leergierig": "LEERGIERIG",
      "Doorzettingsvermogen": "DOORZETTINGSVERMOGEN",
      "Omkadering": "OMKADERING",
      "Motivatie": "MOTIVATIE",
      "Inzet": "INZET",
      "Ambitie": "AMBITIE",
      "Zelfregulering": "ZELFREGULERING",
      "Volharding": "VOLHARDING",
      "Zelfbeeld": "ZELFBEELD",
      "Leersnelheid": "LEERSNELHEID",
      "Inzicht": "INZICHT",
      "Besluitvaardigheid": "BESLUITVAARDIGHEID",
      "Leervermogen": "LEERVERMOGEN",
      "Persoonlijkheid": "PERSOONLIJKHEID",
      "Leiderschap": "LEIDERSCHAP",
      "Betrokken": "BETROKKEN",
      "Focus": "FOCUS",
      "Respectvol": "RESPECTVOL",
      // BASICS B+ elements
      "Leiden van de bal": "LEIDEN_VAN_DE_BAL",
      "Dribbelen met de bal": "DRIBBELEN_MET_DE_BAL",
      "Korte Passing": "KORTE_PASSING",
      "Middellange Passing": "MIDDELLANGE_PASSING",
      "Lange Passing": "LANGE_PASSING",
      "Passing met het Hoofd": "PASSING_MET_HET_HOOFD",
      "1 tijd Passing, Kaatsen": "1_TIJD_PASSING_KAATSEN",
      "Balcontrole Korte Pass": "BALCONTROLE_KORTE_PASS",
      "Balcontrole Middellange Pass": "BALCONTROLE_MIDDELLANGE_PASS",
      "Balcontrole Lange Pass": "BALCONTROLE_LANGE_PASS",
      "Schieten op doel": "SCHIETEN_OP_DOEL",
      "Scoren met de voet": "SCOREN_MET_DE_VOET",
      "Scoren met het hoofd": "SCOREN_MET_HET_HOOFD",
      "Scoren na individuele actie, trucks": "SCOREN_NA_INDIVIDUELE_ACTIE_TRUCKS",
      "Vrijlopen - Aanspeelbaar zijn": "VRIJLOPEN_AANSPEELBAAR_ZIJN",
      "Goed ingedraaid staan": "GOED_INGEDRAAID_STAAN",
      "Steun je teamgenoot": "STEUN_JE_TEAMGENOOT"
    };

    // Check if there's a special mapping
    if (specialMappings[name]) {
      return specialMappings[name];
    }

    // Default conversion for other elements
    return name.toUpperCase().replace(/\s+/g, "_").replace(/[^A-Z_]/g, "");
  };

  const elementKey = getElementKey(elementName, topic);
  
  // Get element data based on topic
  let elementData;
  if (topic === "TEAMTACTISCH") {
    elementData = teamtactischDepth[elementKey as keyof typeof teamtactischDepth];
  } else if (topic === "MENTAAL") {
    elementData = mentaalDepth[elementKey as keyof typeof mentaalDepth];
  } else {
    elementData = basicsDepth[elementKey as keyof typeof basicsDepth];
  }

  if (!elementData) {
    // Fallback rendering for elements without depth data
    if ((topic === "TEAMTACTISCH" || topic === "MENTAAL") && !children) {
      const bgColor = topic === "MENTAAL" ? "bg-purple-50" : "bg-yellow-50";
      const borderColor = topic === "MENTAAL" ? "border-purple-200" : "border-yellow-200";
      const textColor = topic === "MENTAAL" ? "text-purple-800" : "text-yellow-800";
      const subtextColor = topic === "MENTAAL" ? "text-purple-600" : "text-yellow-600";
      
      return (
        <Button
          variant="outline"
          className={`p-3 ${bgColor} ${borderColor} rounded-lg text-sm h-auto flex flex-col items-start justify-start hover:shadow-md transition-shadow`}
          onClick={() => {
            // Simple alert for now - can be expanded later
            alert(`${elementName} - Diepgang niveaus worden binnenkort toegevoegd`);
          }}
        >
          <div className={`font-medium ${textColor}`}>{elementName}</div>
          <div className={`text-xs ${subtextColor} mt-1`}>Klik voor details</div>
        </Button>
      );
    }
    return <>{children}</>;
  }

  const getDifficultyColor = (difficulty: number) => {
    const colors = [
      "bg-green-100 text-green-800 border-green-200", // 1
      "bg-blue-100 text-blue-800 border-blue-200",    // 2
      "bg-yellow-100 text-yellow-800 border-yellow-200", // 3
      "bg-orange-100 text-orange-800 border-orange-200", // 4
      "bg-red-100 text-red-800 border-red-200",       // 5
      "bg-purple-100 text-purple-800 border-purple-200" // 6
    ];
    return colors[difficulty - 1] || colors[0];
  };

  const getDifficultyStars = (difficulty: number) => {
    return Array.from({ length: 6 }, (_, index) => (
      <Star 
        key={index} 
        className={`h-3 w-3 ${
          index < difficulty ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`} 
      />
    ));
  };

  // For all elements, render as clickable element card
  const renderTrigger = () => {
    return (
      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm cursor-pointer hover:bg-blue-100 transition-colors">
        <div className="font-medium text-blue-800">{elementName}</div>
        <div className="text-xs text-blue-600 mt-1">Klik voor 6 diepgang niveaus</div>
      </div>
    );
  };

  const [isOpen, setIsOpen] = useState(false);

  const handleElementClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    console.log("Element clicked:", elementName);
    setIsOpen(true);
  };

  return (
    <>
      <div onClick={handleElementClick}>
        {renderTrigger()}
      </div>
      
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-yellow-600" />
              {elementData.name} - Diepgang Niveaus
            </DialogTitle>
          </DialogHeader>
        
        <div className="space-y-4">
          <p className="text-muted-foreground">
            Klik op een niveau om meer details te bekijken en de progressie te volgen.
          </p>
          
          <div className="grid gap-3">
            {elementData.levels.map((level, index) => (
              <div
                key={level.id}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedLevel === level.id 
                    ? 'border-primary bg-primary/5' 
                    : 'border-gray-200 hover:border-gray-300 hover:shadow-sm'
                }`}
                onClick={() => setSelectedLevel(selectedLevel === level.id ? "" : level.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div className={`px-2 py-1 rounded text-xs font-medium border ${getDifficultyColor(level.difficulty)}`}>
                      Niveau {level.difficulty}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{level.name}</h4>
                      <p className="text-sm text-muted-foreground">{level.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex gap-0.5">
                      {getDifficultyStars(level.difficulty)}
                    </div>
                    <ChevronRight className={`h-4 w-4 transition-transform ${
                      selectedLevel === level.id ? 'rotate-90' : ''
                    }`} />
                  </div>
                </div>
                
                {selectedLevel === level.id && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h5 className="font-medium mb-2">Training Focus:</h5>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Herhaalde oefening van deze specifieke techniek</li>
                          <li>• Progressieve moeilijkheidsgraad opbouw</li>
                          <li>• Focus op precisie en timing</li>
                          {level.difficulty >= 4 && <li>• Besluitvorming onder druk</li>}
                          {level.difficulty >= 5 && <li>• Multitasking vaardigheden</li>}
                        </ul>
                      </div>
                      <div>
                        <h5 className="font-medium mb-2">Vereisten:</h5>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          {index > 0 && <li>• Vorig niveau beheersen</li>}
                          <li>• Basis bal controle</li>
                          {level.difficulty >= 3 && <li>• Snelheid en precisie</li>}
                          {level.difficulty >= 4 && <li>• Perifeer zicht</li>}
                          {level.difficulty >= 5 && <li>• Druk weerstand</li>}
                        </ul>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 className="font-medium text-yellow-800 mb-2">Progressie Aanpak</h4>
            <p className="text-sm text-yellow-700">
              Begin met niveau 1 en werk systematisch door naar niveau 6. 
              Elke speler moet een niveau volledig beheersen voordat naar het volgende niveau wordt gegaan.
              De diepgang zorgt voor continue uitdaging en ontwikkeling.
            </p>
          </div>
        </div>
        </DialogContent>
      </Dialog>
    </>
  );
}