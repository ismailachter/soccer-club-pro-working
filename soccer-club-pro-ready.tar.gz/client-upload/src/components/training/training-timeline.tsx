import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { 
  Plus,
  Clock,
  Play,
  Pause,
  Settings,
  Trash2,
  ChevronUp,
  ChevronDown,
  Timer,
  Users,
  Target,
  Zap,
  Edit,
  Copy,
  Video,
  Square
} from "lucide-react";

interface TrainingPhase {
  id: string;
  name: string;
  duration: number; // in minutes
  type: 'warming-up' | 'techniek' | 'tactiek' | 'fysiek' | 'spelvorm' | 'cooling-down';
  description: string;
  intensity: 'laag' | 'medium' | 'hoog';
  materials: string[];
  players: number;
}

interface TrainingTimelineProps {
  onSave?: (phases: TrainingPhase[]) => void;
  initialPhases?: TrainingPhase[];
}

const phaseTypes = [
  { value: 'warming-up', label: 'Warming-up', icon: Play, color: 'bg-green-500' },
  { value: 'techniek', label: 'Techniek', icon: Target, color: 'bg-blue-500' },
  { value: 'tactiek', label: 'Tactiek', icon: Users, color: 'bg-purple-500' },
  { value: 'fysiek', label: 'Fysiek', icon: Zap, color: 'bg-red-500' },
  { value: 'spelvorm', label: 'Spelvorm', icon: Play, color: 'bg-orange-500' },
  { value: 'cooling-down', label: 'Cooling-down', icon: Pause, color: 'bg-gray-500' }
];

const intensityColors = {
  'laag': 'bg-green-100 text-green-800',
  'medium': 'bg-yellow-100 text-yellow-800',
  'hoog': 'bg-red-100 text-red-800'
};

export const TrainingTimeline: React.FC<TrainingTimelineProps> = ({ 
  onSave, 
  initialPhases = [] 
}) => {
  const [phases, setPhases] = useState<TrainingPhase[]>(initialPhases);
  const [editingPhase, setEditingPhase] = useState<TrainingPhase | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPhaseIndex, setCurrentPhaseIndex] = useState(0);

  const [newPhase, setNewPhase] = useState<Partial<TrainingPhase>>({
    name: '',
    duration: 10,
    type: 'warming-up',
    description: '',
    intensity: 'medium',
    materials: [],
    players: 11
  });

  const addPhase = () => {
    if (!newPhase.name) return;
    
    const phase: TrainingPhase = {
      id: `phase-${Date.now()}`,
      name: newPhase.name || '',
      duration: newPhase.duration || 10,
      type: newPhase.type as TrainingPhase['type'] || 'warming-up',
      description: newPhase.description || '',
      intensity: newPhase.intensity as TrainingPhase['intensity'] || 'medium',
      materials: newPhase.materials || [],
      players: newPhase.players || 11
    };

    setPhases(prev => [...prev, phase]);
    setNewPhase({
      name: '',
      duration: 10,
      type: 'warming-up',
      description: '',
      intensity: 'medium',
      materials: [],
      players: 11
    });
    setShowAddForm(false);
  };

  const removePhase = (id: string) => {
    setPhases(prev => prev.filter(p => p.id !== id));
  };

  const editPhase = (phase: TrainingPhase) => {
    setEditingPhase(phase);
    setNewPhase(phase);
    setShowAddForm(true);
  };

  const updatePhase = () => {
    if (!editingPhase || !newPhase.name) return;
    
    const updatedPhase: TrainingPhase = {
      ...editingPhase,
      name: newPhase.name || '',
      duration: newPhase.duration || 10,
      type: newPhase.type as TrainingPhase['type'] || 'warming-up',
      description: newPhase.description || '',
      intensity: newPhase.intensity as TrainingPhase['intensity'] || 'medium',
      materials: newPhase.materials || [],
      players: newPhase.players || 11
    };

    setPhases(prev => prev.map(p => p.id === editingPhase.id ? updatedPhase : p));
    setEditingPhase(null);
    setNewPhase({
      name: '',
      duration: 10,
      type: 'warming-up',
      description: '',
      intensity: 'medium',
      materials: [],
      players: 11
    });
    setShowAddForm(false);
  };

  const cancelEdit = () => {
    setEditingPhase(null);
    setNewPhase({
      name: '',
      duration: 10,
      type: 'warming-up',
      description: '',
      intensity: 'medium',
      materials: [],
      players: 11
    });
    setShowAddForm(false);
  };

  const duplicatePhase = (phase: TrainingPhase) => {
    const duplicatedPhase: TrainingPhase = {
      ...phase,
      id: `phase-${Date.now()}`,
      name: `${phase.name} (kopie)`
    };
    setPhases(prev => [...prev, duplicatedPhase]);
  };

  const playAnimation = () => {
    setIsPlaying(true);
    setCurrentPhaseIndex(0);
    
    // Simulate animation through phases
    const animatePhases = () => {
      setCurrentPhaseIndex(prev => {
        const next = prev + 1;
        if (next >= phases.length) {
          setIsPlaying(false);
          return 0;
        }
        setTimeout(animatePhases, 2000); // 2 seconds per phase
        return next;
      });
    };
    
    if (phases.length > 0) {
      setTimeout(animatePhases, 2000);
    }
  };

  const stopAnimation = () => {
    setIsPlaying(false);
    setCurrentPhaseIndex(0);
  };

  const movePhase = (id: string, direction: 'up' | 'down') => {
    setPhases(prev => {
      const index = prev.findIndex(p => p.id === id);
      if (index === -1) return prev;
      
      const newIndex = direction === 'up' ? index - 1 : index + 1;
      if (newIndex < 0 || newIndex >= prev.length) return prev;
      
      const newPhases = [...prev];
      [newPhases[index], newPhases[newIndex]] = [newPhases[newIndex], newPhases[index]];
      return newPhases;
    });
  };

  const getTotalDuration = () => {
    return phases.reduce((total, phase) => total + phase.duration, 0);
  };

  const saveTimeline = () => {
    if (onSave) {
      onSave(phases);
    }
  };

  const PhaseTypeIcon = ({ type }: { type: TrainingPhase['type'] }) => {
    const phaseType = phaseTypes.find(pt => pt.value === type);
    const Icon = phaseType?.icon || Clock;
    return <Icon className="w-4 h-4" />;
  };

  return (
    <div className="space-y-6">
      {/* Timeline Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Timer className="w-5 h-5" />
              Trainings Tijdslijn
            </CardTitle>
            <div className="flex gap-2">
              <Badge variant="outline" className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {getTotalDuration()} min totaal
              </Badge>
              <Badge variant="secondary">
                {phases.length} fasen
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Timeline */}
      <div className="space-y-4">
        {phases.map((phase, index) => {
          const phaseType = phaseTypes.find(pt => pt.value === phase.type);
          const isActive = isPlaying && index === currentPhaseIndex;
          const isCompleted = isPlaying && index < currentPhaseIndex;
          
          return (
            <Card key={phase.id} className={`relative transition-all duration-500 ${
              isActive ? 'ring-2 ring-blue-500 shadow-lg scale-[1.02]' : 
              isCompleted ? 'opacity-75' : ''
            }`}>
              {/* Timeline connector */}
              {index < phases.length - 1 && (
                <div className={`absolute left-8 bottom-0 w-0.5 h-4 transform translate-y-full transition-colors ${
                  isCompleted ? 'bg-blue-500' : 'bg-gray-300'
                }`}></div>
              )}
              
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  {/* Phase Icon */}
                  <div className={`w-12 h-12 ${phaseType?.color} rounded-full flex items-center justify-center text-white font-bold relative z-10`}>
                    <PhaseTypeIcon type={phase.type} />
                  </div>

                  {/* Phase Content */}
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-lg">{phase.name}</h3>
                        <Badge variant="outline" className={intensityColors[phase.intensity]}>
                          {phase.intensity}
                        </Badge>
                        <Badge variant="secondary" className="capitalize">
                          {phaseType?.label}
                        </Badge>
                      </div>
                      
                      {/* Controls */}
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => editPhase(phase)}
                          title="Bewerken"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => duplicatePhase(phase)}
                          title="Dupliceren"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => movePhase(phase.id, 'up')}
                          disabled={index === 0}
                          title="Omhoog"
                        >
                          <ChevronUp className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => movePhase(phase.id, 'down')}
                          disabled={index === phases.length - 1}
                          title="Omlaag"
                        >
                          <ChevronDown className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removePhase(phase.id)}
                          title="Verwijderen"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{phase.duration} minuten</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        <span>{phase.players} spelers</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Settings className="w-3 h-3" />
                        <span>{phase.materials.length} materialen</span>
                      </div>
                    </div>

                    {phase.description && (
                      <p className="text-sm text-muted-foreground">{phase.description}</p>
                    )}

                    {/* Time Progress Bar */}
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div 
                        className={`h-1.5 rounded-full ${phaseType?.color}`}
                        style={{ 
                          width: `${getTotalDuration() > 0 ? (phase.duration / getTotalDuration()) * 100 : 0}%` 
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Add Phase Form */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Nieuwe Fase Toevoegen</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Fase Naam</Label>
                <Input
                  value={newPhase.name}
                  onChange={(e) => setNewPhase(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Bijv. Warming-up"
                />
              </div>
              <div className="space-y-2">
                <Label>Type</Label>
                <Select
                  value={newPhase.type}
                  onValueChange={(value) => setNewPhase(prev => ({ ...prev, type: value as TrainingPhase['type'] }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {phaseTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2">
                          <type.icon className="w-4 h-4" />
                          {type.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Duur (min)</Label>
                <Input
                  type="number"
                  value={newPhase.duration}
                  onChange={(e) => setNewPhase(prev => ({ ...prev, duration: parseInt(e.target.value) || 0 }))}
                  min="1"
                  max="120"
                />
              </div>
              <div className="space-y-2">
                <Label>Intensiteit</Label>
                <Select
                  value={newPhase.intensity}
                  onValueChange={(value) => setNewPhase(prev => ({ ...prev, intensity: value as TrainingPhase['intensity'] }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="laag">Laag</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="hoog">Hoog</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Aantal Spelers</Label>
                <Input
                  type="number"
                  value={newPhase.players}
                  onChange={(e) => setNewPhase(prev => ({ ...prev, players: parseInt(e.target.value) || 0 }))}
                  min="1"
                  max="22"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Beschrijving</Label>
              <Textarea
                value={newPhase.description}
                onChange={(e) => setNewPhase(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Beschrijf wat er in deze fase gebeurt..."
                rows={3}
              />
            </div>

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={cancelEdit}>
                Annuleren
              </Button>
              <Button onClick={editingPhase ? updatePhase : addPhase}>
                {editingPhase ? 'Bijwerken' : 'Fase Toevoegen'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex gap-2 justify-between">
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowAddForm(true)}
            disabled={showAddForm}
          >
            <Plus className="w-4 h-4 mr-2" />
            Fase Toevoegen
          </Button>
          
          {phases.length > 0 && (
            <>
              <Button
                variant="outline"
                onClick={isPlaying ? stopAnimation : playAnimation}
                disabled={phases.length === 0}
              >
                {isPlaying ? (
                  <>
                    <Square className="w-4 h-4 mr-2" />
                    Stop Preview
                  </>
                ) : (
                  <>
                    <Video className="w-4 h-4 mr-2" />
                    Preview Animatie
                  </>
                )}
              </Button>
            </>
          )}
        </div>
        
        <Button onClick={saveTimeline}>
          Tijdslijn Opslaan
        </Button>
      </div>
    </div>
  );
};

export default TrainingTimeline;