import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FormControl } from "@/components/ui/form";
import { 
  Circle,
  Square,
  Triangle,
  Flag,
  Cone
} from "lucide-react";

// Uitgebreide trainingsmaterialen voor voetbaltraining
export const trainingMaterials = {
  ballen: [
    { id: 'voetballen-maat5', name: 'Voetballen (maat 5)', icon: Circle, color: 'bg-orange-500' },
    { id: 'voetballen-maat4', name: 'Voetballen (maat 4)', icon: Circle, color: 'bg-orange-400' },
    { id: 'voetballen-maat3', name: 'Voetballen (maat 3)', icon: Circle, color: 'bg-orange-300' },
    { id: 'tennis-ballen', name: 'Tennisballen', icon: Circle, color: 'bg-yellow-500' },
    { id: 'medicijn-ballen', name: 'Medicijnballen', icon: Circle, color: 'bg-blue-500' },
    { id: 'reactie-ballen', name: 'Reactieballen', icon: Circle, color: 'bg-purple-400' },
    { id: 'foam-ballen', name: 'Foam ballen', icon: Circle, color: 'bg-pink-400' }
  ],
  doelen: [
    { id: 'grote-doelen', name: 'Grote doelen (7.32x2.44m)', icon: Square, color: 'bg-blue-600' },
    { id: 'jeugd-doelen', name: 'Jeugddoelen (5x2m)', icon: Square, color: 'bg-blue-500' },
    { id: 'mini-doelen', name: 'Mini doelen (1.2x0.8m)', icon: Square, color: 'bg-blue-400' },
    { id: 'pop-up-doelen', name: 'Pop-up doelen', icon: Triangle, color: 'bg-cyan-500' },
    { id: 'target-doelen', name: 'Target doelen', icon: Square, color: 'bg-teal-500' },
    { id: 'rebounder', name: 'Rebounder', icon: Square, color: 'bg-slate-500' }
  ],
  markeringen: [
    { id: 'pionnen-oranje', name: 'Pionnen (oranje)', icon: Cone, color: 'bg-orange-500' },
    { id: 'pionnen-geel', name: 'Pionnen (geel)', icon: Cone, color: 'bg-yellow-500' },
    { id: 'pionnen-rood', name: 'Pionnen (rood)', icon: Cone, color: 'bg-red-500' },
    { id: 'pionnen-blauw', name: 'Pionnen (blauw)', icon: Cone, color: 'bg-blue-500' },
    { id: 'hoepels', name: 'Hoepels', icon: Circle, color: 'bg-purple-500' },
    { id: 'markers-plat', name: 'Platte markers', icon: Circle, color: 'bg-pink-500' },
    { id: 'slalom-stokken', name: 'Slalom stokken', icon: Flag, color: 'bg-yellow-600' },
    { id: 'vlaggen', name: 'Hoek vlaggen', icon: Flag, color: 'bg-red-600' }
  ],
  coordinatie: [
    { id: 'ladders', name: 'Coördinatie ladders', icon: Square, color: 'bg-gray-500' },
    { id: 'hurdles', name: 'Mini hurdles', icon: Square, color: 'bg-orange-600' },
    { id: 'agility-rings', name: 'Agility ringen', icon: Circle, color: 'bg-purple-600' },
    { id: 'speed-chute', name: 'Parachute', icon: Triangle, color: 'bg-blue-700' },
    { id: 'resistance-bands', name: 'Weerstandsbanden', icon: Square, color: 'bg-green-700' }
  ],
  hesjes: [
    { id: 'hesjes-rood', name: 'Hesjes (rood)', icon: Square, color: 'bg-red-500' },
    { id: 'hesjes-blauw', name: 'Hesjes (blauw)', icon: Square, color: 'bg-blue-500' },
    { id: 'hesjes-geel', name: 'Hesjes (geel)', icon: Square, color: 'bg-yellow-500' },
    { id: 'hesjes-groen', name: 'Hesjes (groen)', icon: Square, color: 'bg-green-500' },
    { id: 'hesjes-oranje', name: 'Hesjes (oranje)', icon: Square, color: 'bg-orange-500' },
    { id: 'hesjes-wit', name: 'Hesjes (wit)', icon: Square, color: 'bg-gray-300' }
  ],
  scheidingsmaterialen: [
    { id: 'linten', name: 'Afbakening lint', icon: Square, color: 'bg-yellow-400' },
    { id: 'netten', name: 'Scheidingsnetten', icon: Square, color: 'bg-gray-600' },
    { id: 'hekjes', name: 'Mini hekjes', icon: Square, color: 'bg-brown-500' },
    { id: 'kwart-cirkels', name: 'Kwart cirkels', icon: Circle, color: 'bg-indigo-400' }
  ],
  keepersmateriaal: [
    { id: 'keeper-handschoenen', name: 'Keepershandschoenen', icon: Square, color: 'bg-black' },
    { id: 'keeper-muts', name: 'Keepersmuts', icon: Circle, color: 'bg-gray-700' },
    { id: 'duik-matten', name: 'Duikmatten', icon: Square, color: 'bg-blue-800' },
    { id: 'reactie-bord', name: 'Reactiebord', icon: Square, color: 'bg-red-700' }
  ],
  techniek: [
    { id: 'pass-arc', name: 'Pass boog', icon: Circle, color: 'bg-cyan-600' },
    { id: 'juggle-up', name: 'Juggle-up', icon: Triangle, color: 'bg-green-600' },
    { id: 'balance-pads', name: 'Balance pads', icon: Circle, color: 'bg-purple-700' },
    { id: 'tactiek-bord', name: 'Tactiekbord', icon: Square, color: 'bg-slate-700' }
  ]
};

// Football field component
export const FootballField = ({ selectedMaterials = [] }: { 
  selectedMaterials: string[]
}) => {
  return (
    <div className="relative bg-green-500 rounded-lg p-4 aspect-[3/2] max-w-md mx-auto border-4 border-white">
      {/* Field markings */}
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 300 200">
        {/* Outer boundary */}
        <rect x="10" y="10" width="280" height="180" fill="none" stroke="white" strokeWidth="2"/>
        
        {/* Center circle */}
        <circle cx="150" cy="100" r="30" fill="none" stroke="white" strokeWidth="2"/>
        <circle cx="150" cy="100" r="2" fill="white"/>
        
        {/* Center line */}
        <line x1="150" y1="10" x2="150" y2="190" stroke="white" strokeWidth="2"/>
        
        {/* Goal areas */}
        <rect x="10" y="70" width="20" height="60" fill="none" stroke="white" strokeWidth="2"/>
        <rect x="270" y="70" width="20" height="60" fill="none" stroke="white" strokeWidth="2"/>
        
        {/* Penalty areas */}
        <rect x="10" y="50" width="40" height="100" fill="none" stroke="white" strokeWidth="2"/>
        <rect x="250" y="50" width="40" height="100" fill="none" stroke="white" strokeWidth="2"/>
        
        {/* Goals */}
        <rect x="5" y="85" width="5" height="30" fill="white"/>
        <rect x="290" y="85" width="5" height="30" fill="white"/>
      </svg>
      
      {/* Field label */}
      <div className="absolute top-2 left-2 text-white text-sm font-bold bg-green-700 px-2 py-1 rounded">
        Voetbalveld
      </div>
      
      {/* Material indicators on field */}
      {selectedMaterials.length > 0 && (
        <div className="absolute bottom-2 right-2 text-white text-xs bg-green-700 px-2 py-1 rounded">
          {selectedMaterials.length} materialen geselecteerd
        </div>
      )}
    </div>
  );
};

// Material selector component
export const MaterialSelector = ({ 
  value, 
  onChange 
}: { 
  value?: string; 
  onChange: (value: string) => void;
}) => {
  return (
    <div className="space-y-4">
      {/* Material Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {Object.entries(trainingMaterials).map(([category, materials]) => (
          <div key={category} className="space-y-2">
            <h4 className="font-medium text-sm capitalize">{category}</h4>
            <div className="grid grid-cols-2 gap-2">
              {materials.map((material) => {
                const Icon = material.icon;
                const isSelected = value?.includes(material.name);
                return (
                  <Button
                    key={material.id}
                    type="button"
                    variant={isSelected ? "default" : "outline"}
                    size="sm"
                    className="h-auto p-2 flex flex-col items-center gap-1"
                    onClick={() => {
                      const currentMaterials = value ? value.split(', ') : [];
                      if (isSelected) {
                        const newMaterials = currentMaterials.filter(m => m !== material.name);
                        onChange(newMaterials.join(', '));
                      } else {
                        const newMaterials = [...currentMaterials, material.name];
                        onChange(newMaterials.join(', '));
                      }
                    }}
                  >
                    <div className={`w-6 h-6 rounded-full ${material.color} flex items-center justify-center`}>
                      <Icon className="w-3 h-3 text-white" />
                    </div>
                    <span className="text-xs text-center">{material.name}</span>
                  </Button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      
      {/* Football Field Visualization */}
      <div className="mt-6">
        <h4 className="font-medium text-sm mb-2">Veldvisualisatie</h4>
        <FootballField selectedMaterials={value ? value.split(', ') : []} />
      </div>
      
      {/* Manual input for additional materials */}
      <FormControl>
        <Input 
          placeholder="Extra materiaal (optioneel)"
          value={value || ''}
          onChange={(e) => onChange(e.target.value)}
        />
      </FormControl>
    </div>
  );
};