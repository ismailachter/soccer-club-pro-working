import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Mail, UserPlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface InvitationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function InvitationDialog({ open, onOpenChange }: InvitationDialogProps) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [inviterName, setInviterName] = useState('Ismail Achter');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const generateTempPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    let password = '';
    for (let i = 0; i < 8; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  };

  const handleSendInvitation = async () => {
    if (!email || !role) {
      toast({
        title: "Ontbrekende gegevens",
        description: "Vul alle velden in",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsLoading(true);
      
      const tempPassword = generateTempPassword();
      
      const response = await fetch('/api/email/send-invitation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email,
          inviterName,
          clubName: 'VVC Brasschaat',
          role
        })
      });
      
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Uitnodiging Verzonden!",
          description: `Uitnodiging succesvol verstuurd naar ${email}`,
        });
        
        // Reset form
        setEmail('');
        setRole('');
        onOpenChange(false);
      } else {
        toast({
          title: "Uitnodiging Error",
          description: result.error || "Er ging iets mis bij het verzenden",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Uitnodiging Error", 
        description: "Netwerkfout bij uitnodiging verzending",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5" />
            Gebruiker Uitnodigen
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="email">E-mail Adres</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="trainer@example.com"
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="role">Rol</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Selecteer rol..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="coach">Coach</SelectItem>
                <SelectItem value="trainer">Trainer</SelectItem>
                <SelectItem value="coordinator">Coördinator</SelectItem>
                <SelectItem value="player">Speler</SelectItem>
                <SelectItem value="parent">Ouder</SelectItem>
                <SelectItem value="admin">Administrator</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="inviter">Uitnodiger</Label>
            <Input
              id="inviter"
              value={inviterName}
              onChange={(e) => setInviterName(e.target.value)}
              className="mt-1"
            />
          </div>

          <div className="border border-blue-200 rounded-lg p-3 bg-blue-50">
            <div className="flex items-center gap-2 mb-2">
              <Mail className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">Automatische uitnodiging</span>
            </div>
            <p className="text-xs text-blue-600">
              Er wordt automatisch een tijdelijk wachtwoord gegenereerd en verstuurd.
              De gebruiker kan dit wijzigen na de eerste login.
            </p>
          </div>

          <div className="flex gap-2 pt-4">
            <Button 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Annuleren
            </Button>
            <Button 
              onClick={handleSendInvitation}
              disabled={isLoading || !email || !role}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? 'Versturen...' : 'Uitnodiging Versturen'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}