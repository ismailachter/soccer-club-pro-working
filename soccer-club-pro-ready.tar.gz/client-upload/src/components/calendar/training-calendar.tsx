import { useState, useEffect } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2, Calendar as CalendarIcon, Clock, Target, Star } from "lucide-react";
import { format, isSameDay, parseISO, addDays } from "date-fns";
import { nl } from "date-fns/locale";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { TrainingSession, InsertTrainingSession, TrainingPlan } from "@shared/schema";

interface TrainingCalendarProps {
  selectedPlan: TrainingPlan;
  iadatabankElements: any[];
  onMonthChange: (date: Date) => void;
  onDateClick: (date: string, isTraining: boolean, isCurrentMonth: boolean) => void;
}

interface CalendarEvent {
  id: number;
  date: Date;
  title: string;
  description?: string;
  type: 'training' | 'match' | 'event';
  duration: number;
  focus?: string;
  notes?: string;
  iadataBankElements?: any[];
  mainTopic?: string;
  subTopic?: string;
  planId?: number;
}

interface IadataBankElement {
  id: number;
  name: string;
  mainTopic: string;
  subTopic: string;
  description?: string;
  difficulty: string;
  starRating: number;
}

export function TrainingCalendar({ selectedPlan, iadatabankElements, onMonthChange, onDateClick }: TrainingCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false);
  const [isIadataBankOpen, setIsIadataBankOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [selectedMainTopic, setSelectedMainTopic] = useState<string>('');
  const [selectedSubTopic, setSelectedSubTopic] = useState<string>('');
  const [selectedElements, setSelectedElements] = useState<IadataBankElement[]>([]);
  const [eventForm, setEventForm] = useState({
    title: '',
    description: '',
    type: 'training' as const,
    duration: 90,
    focus: '',
    notes: ''
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch training sessions for this plan
  const { data: trainingSessions = [], isLoading } = useQuery({
    queryKey: ['/api/training-sessions', selectedPlan?.id],
    queryFn: async () => {
      if (!selectedPlan?.id) return [];
      const response = await apiRequest('GET', `/api/training-sessions?planId=${selectedPlan.id}`);
      return await response.json();
    },
    enabled: !!selectedPlan?.id
  });

  // Use passed IADATABANK elements
  const iadataBankElements = iadatabankElements || [];

  // Create training session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      const response = await apiRequest('POST', '/api/training-sessions', sessionData);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/training-sessions'] });
      toast({ title: "Training sessie toegevoegd", description: "De sessie is succesvol aangemaakt." });
      setIsEventDialogOpen(false);
      setIsIadataBankOpen(false);
      resetForm();
    },
    onError: () => {
      toast({ title: "Fout", description: "Er ging iets mis bij het aanmaken van de sessie.", variant: "destructive" });
    }
  });

  // Update training session mutation
  const updateSessionMutation = useMutation({
    mutationFn: async ({ id, ...sessionData }: { id: number } & any) => {
      const response = await apiRequest('PATCH', `/api/training-sessions/${id}`, sessionData);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/training-sessions'] });
      toast({ title: "Training sessie bijgewerkt", description: "De wijzigingen zijn opgeslagen." });
      setIsEventDialogOpen(false);
      setIsIadataBankOpen(false);
      setEditingEvent(null);
      resetForm();
    }
  });

  // Delete training session mutation
  const deleteSessionMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/training-sessions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/training-sessions'] });
      toast({ title: "Training sessie verwijderd", description: "De sessie is succesvol verwijderd." });
    }
  });

  // Convert training sessions to calendar events
  const calendarEvents: CalendarEvent[] = trainingSessions.map((session: any) => ({
    id: session.id || Date.now(),
    date: session.date ? parseISO(session.date) : new Date(),
    title: session.focus || 'Training Sessie',
    description: session.notes || '',
    type: 'training' as const,
    duration: session.duration || 90,
    focus: session.focus || '',
    notes: session.notes || '',
    iadataBankElements: session.iadataBankElements || [],
    mainTopic: session.mainTopic || '',
    subTopic: session.subTopic || '',
    planId: selectedPlan?.id || 0
  }));

  // Get events for selected date
  const selectedDateEvents = calendarEvents.filter(event => 
    isSameDay(event.date, selectedDate)
  );

  // Filter IADATABANK elements by selected topic
  const filteredElements = iadataBankElements.filter((element: any) => {
    if (!selectedMainTopic) return true;
    if (selectedMainTopic && !selectedSubTopic) {
      return element.mainTopic === selectedMainTopic;
    }
    return element.mainTopic === selectedMainTopic && element.subTopic === selectedSubTopic;
  });

  // Available main topics
  const mainTopics = ['BASICS', 'TEAMTACTISCH', 'MENTAAL', 'FYSIEK', 'OMSCHAKELING'];
  
  // Available sub topics based on selected main topic
  const getSubTopics = (mainTopic: string) => {
    if (mainTopic === 'BASICS') return ['B+', 'B-'];
    if (mainTopic === 'TEAMTACTISCH') return ['Aanvallen', 'Verdedigen', 'Omschakeling'];
    if (mainTopic === 'MENTAAL') return ['Concentratie', 'Zelfvertrouwen', 'Motivatie'];
    if (mainTopic === 'FYSIEK') return ['Kracht', 'Snelheid', 'Uithoudingsvermogen'];
    if (mainTopic === 'OMSCHAKELING') return ['Bal winst', 'Bal verlies'];
    return [];
  };

  const resetForm = () => {
    setEventForm({
      title: '',
      description: '',
      type: 'training',
      duration: 90,
      focus: '',
      notes: ''
    });
    setSelectedElements([]);
    setSelectedMainTopic('');
    setSelectedSubTopic('');
  };

  const handleCreateEvent = () => {
    const sessionData = {
      teamId: selectedPlan?.teamId || null,
      planId: selectedPlan?.id || 0,
      date: selectedDate.toISOString().split('T')[0], // Format as YYYY-MM-DD
      startTime: selectedDate.toISOString(),
      endTime: new Date(selectedDate.getTime() + (eventForm.duration * 60000)).toISOString(),
      duration: eventForm.duration || 90,
      focus: eventForm.focus || eventForm.title,
      notes: eventForm.notes || eventForm.description || '',
      mainTopic: selectedMainTopic || null,
      subTopic: selectedSubTopic || null,
      iadataBankElements: JSON.stringify(selectedElements),
      pitchId: null,
      coachId: null
    };

    if (editingEvent) {
      updateSessionMutation.mutate({ id: editingEvent.id, ...sessionData });
    } else {
      createSessionMutation.mutate(sessionData);
    }
  };

  const handleEditEvent = (event: CalendarEvent) => {
    setEditingEvent(event);
    setEventForm({
      title: event.title,
      description: event.description || '',
      type: event.type,
      duration: event.duration,
      focus: event.focus || '',
      notes: event.notes || ''
    });
    setSelectedMainTopic(event.mainTopic || '');
    setSelectedSubTopic(event.subTopic || '');
    setSelectedElements(event.iadataBankElements || []);
    setIsEventDialogOpen(true);
  };

  const handleDeleteEvent = (eventId: number) => {
    if (confirm('Weet je zeker dat je deze training sessie wilt verwijderen?')) {
      deleteSessionMutation.mutate(eventId);
    }
  };

  const handleElementToggle = (element: IadataBankElement) => {
    setSelectedElements(prev => {
      const exists = prev.find(e => e.id === element.id);
      if (exists) {
        return prev.filter(e => e.id !== element.id);
      } else {
        return [...prev, element];
      }
    });
  };

  const openIadataBank = () => {
    setIsIadataBankOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Calendar View */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              Training Kalender - {selectedPlan?.name || 'Trainingsplan'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              modifiers={{
                hasEvent: calendarEvents.map(e => e.date)
              }}
              modifiersStyles={{
                hasEvent: { backgroundColor: '#3b82f6', color: 'white', fontWeight: 'bold' }
              }}
              locale={nl}
              className="rounded-md border"
            />
          </CardContent>
        </Card>

        {/* Selected Date Events */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>
                {format(selectedDate, 'dd MMMM yyyy', { locale: nl })}
              </span>
              <Dialog open={isEventDialogOpen} onOpenChange={setIsEventDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" onClick={() => {
                    setEditingEvent(null);
                    resetForm();
                  }}>
                    <Plus className="h-4 w-4 mr-2" />
                    Training toevoegen
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingEvent ? 'Bewerk Training Sessie' : 'Nieuwe Training Sessie'}
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="title">Titel</Label>
                        <Input
                          id="title"
                          value={eventForm.title}
                          onChange={(e) => setEventForm(prev => ({ ...prev, title: e.target.value }))}
                          placeholder="Bijv. Techniek training"
                        />
                      </div>
                      <div>
                        <Label htmlFor="duration">Duur (minuten)</Label>
                        <Input
                          id="duration"
                          type="number"
                          value={eventForm.duration}
                          onChange={(e) => setEventForm(prev => ({ ...prev, duration: parseInt(e.target.value) || 90 }))}
                          min={30}
                          max={180}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="focus">Focus</Label>
                      <Input
                        id="focus"
                        value={eventForm.focus}
                        onChange={(e) => setEventForm(prev => ({ ...prev, focus: e.target.value }))}
                        placeholder="Bijv. Passing, Schieten"
                      />
                    </div>

                    {/* IADATABANK Selectie */}
                    <div className="border rounded-lg p-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold">IADATABANK Elementen</h3>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={openIadataBank}
                        >
                          <Target className="h-4 w-4 mr-2" />
                          Selecteer elementen
                        </Button>
                      </div>

                      {selectedElements.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="text-sm font-medium">Geselecteerde elementen:</h4>
                          <div className="flex flex-wrap gap-2">
                            {selectedElements.map((element) => (
                              <Badge key={element.id} variant="secondary" className="flex items-center gap-1">
                                {element.name}
                                <div className="flex">
                                  {[...Array(element.starRating)].map((_, i) => (
                                    <Star key={i} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                  ))}
                                </div>
                                <button
                                  onClick={() => handleElementToggle(element)}
                                  className="ml-1 hover:text-red-500"
                                >
                                  ×
                                </button>
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="notes">Notities</Label>
                      <Textarea
                        id="notes"
                        value={eventForm.notes}
                        onChange={(e) => setEventForm(prev => ({ ...prev, notes: e.target.value }))}
                        placeholder="Aanvullende opmerkingen..."
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        onClick={handleCreateEvent} 
                        disabled={!eventForm.title || createSessionMutation.isPending || updateSessionMutation.isPending}
                        className="flex-1"
                      >
                        {editingEvent ? 'Bijwerken' : 'Toevoegen'}
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setIsEventDialogOpen(false);
                          setEditingEvent(null);
                          resetForm();
                        }}
                      >
                        Annuleren
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedDateEvents.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <CalendarIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Geen training sessies gepland voor deze datum</p>
              </div>
            ) : (
              <div className="space-y-3">
                {selectedDateEvents.map((event) => (
                  <Card key={event.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold">{event.title}</h4>
                          <Badge variant={event.type === 'training' ? 'default' : 'secondary'}>
                            {event.type === 'training' ? 'Training' : event.type}
                          </Badge>
                          {event.mainTopic && (
                            <Badge variant="outline" className="text-xs">
                              {event.mainTopic}
                            </Badge>
                          )}
                        </div>
                        {event.focus && (
                          <p className="text-sm text-muted-foreground mb-1">
                            Focus: {event.focus}
                          </p>
                        )}
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {event.duration} min
                          </span>
                          {event.iadataBankElements && event.iadataBankElements.length > 0 && (
                            <span className="flex items-center gap-1">
                              <Target className="h-4 w-4" />
                              {event.iadataBankElements.length} elementen
                            </span>
                          )}
                        </div>
                        {event.description && (
                          <p className="text-sm text-muted-foreground mt-2">
                            {event.description}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditEvent(event)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteEvent(event.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* IADATABANK Element Selection Dialog */}
      <Dialog open={isIadataBankOpen} onOpenChange={setIsIadataBankOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>IADATABANK Element Selectie</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 overflow-y-auto max-h-[70vh]">
            {/* Topic Selection */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Hoofdtopic</Label>
                <Select value={selectedMainTopic} onValueChange={setSelectedMainTopic}>
                  <SelectTrigger>
                    <SelectValue placeholder="Kies hoofdtopic" />
                  </SelectTrigger>
                  <SelectContent>
                    {mainTopics.map((topic) => (
                      <SelectItem key={topic} value={topic}>
                        {topic}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Subtopic</Label>
                <Select 
                  value={selectedSubTopic} 
                  onValueChange={setSelectedSubTopic}
                  disabled={!selectedMainTopic}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Kies subtopic" />
                  </SelectTrigger>
                  <SelectContent>
                    {getSubTopics(selectedMainTopic).map((topic) => (
                      <SelectItem key={topic} value={topic}>
                        {topic}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Elements Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredElements.map((element: any) => {
                const isSelected = selectedElements.some(e => e.id === element.id);
                return (
                  <Card 
                    key={element.id}
                    className={`cursor-pointer transition-colors ${isSelected ? 'bg-blue-50 border-blue-300' : 'hover:bg-gray-50'}`}
                    onClick={() => handleElementToggle(element)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{element.name}</h4>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {element.mainTopic}
                            </Badge>
                            {element.subTopic && (
                              <Badge variant="outline" className="text-xs">
                                {element.subTopic}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-1 mt-2">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`h-3 w-3 ${i < element.starRating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} 
                                />
                              ))}
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {element.difficulty}
                            </span>
                          </div>
                        </div>
                        {isSelected && (
                          <div className="text-blue-600 text-xl">✓</div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="flex justify-between items-center pt-4 border-t">
              <span className="text-sm text-muted-foreground">
                {selectedElements.length} elementen geselecteerd
              </span>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsIadataBankOpen(false)}>
                  Sluiten
                </Button>
                <Button onClick={() => setIsIadataBankOpen(false)}>
                  Selectie bevestigen
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}