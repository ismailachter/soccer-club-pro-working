import { createContext, ReactNode, useContext, useState, useEffect } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { User } from "@/types/index";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export type UserRole = "admin" | "coach" | "player" | "parent" | "sportive_director" | "trainer" | "coordinator";

export type PermissionLevel = "none" | "read" | "write" | "admin";

type UserWithPermissions = User & {
  permissions: {
    database: PermissionLevel;
    users: PermissionLevel;
    teams: PermissionLevel;
    matches: PermissionLevel;
    training: PermissionLevel;
    settings: PermissionLevel;
    players: PermissionLevel;
    pitches: PermissionLevel;
    parents: PermissionLevel;
    export: PermissionLevel;
    import: PermissionLevel;
  };
};

export const getDefaultPermissions = (role: UserRole): UserWithPermissions["permissions"] => {
  switch (role) {
    case "admin":
      return {
        database: "admin",
        users: "admin",
        teams: "admin",
        matches: "admin",
        training: "admin",
        settings: "admin",
        players: "admin",
        pitches: "admin",
        parents: "admin",
        export: "admin",
        import: "admin"
      };
    case "sportive_director":
      return {
        database: "write",
        users: "write",
        teams: "admin",
        matches: "admin",
        training: "admin",
        settings: "write",
        players: "admin",
        pitches: "admin",
        parents: "write",
        export: "admin",
        import: "admin"
      };
    case "coordinator":
      return {
        database: "read",
        users: "write",
        teams: "write",
        matches: "write",
        training: "write",
        settings: "read",
        players: "write",
        pitches: "write",
        parents: "write",
        export: "write",
        import: "write"
      };
    case "coach":
      return {
        database: "read",
        users: "read",
        teams: "write",
        matches: "write",
        training: "admin",
        settings: "read",
        players: "write",
        pitches: "read",
        parents: "read",
        export: "read",
        import: "none"
      };
    case "trainer":
      return {
        database: "none",
        users: "read",
        teams: "read",
        matches: "read",
        training: "write",
        settings: "none",
        players: "read",
        pitches: "read",
        parents: "read",
        export: "none",
        import: "none"
      };
    case "parent":
      return {
        database: "none", 
        users: "read",
        teams: "read",
        matches: "read",
        training: "read",
        settings: "none",
        players: "read",
        pitches: "read",
        parents: "read",
        export: "none",
        import: "none"
      };
    case "player":
      return {
        database: "none",
        users: "read",
        teams: "read",
        matches: "read",
        training: "read",
        settings: "none",
        players: "read",
        pitches: "read",
        parents: "none",
        export: "none",
        import: "none"
      };
    default:
      return {
        database: "none",
        users: "read",
        teams: "read",
        matches: "read",
        training: "read",
        settings: "none",
        players: "read",
        pitches: "read",
        parents: "none",
        export: "none",
        import: "none"
      };
  }
};

type AuthContextType = {
  user: UserWithPermissions | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<UserWithPermissions, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<UserWithPermissions, Error, RegisterData>;
  hasPermission: (resource: keyof UserWithPermissions["permissions"], level: PermissionLevel) => boolean;
};

type LoginData = {
  username: string;
  password: string;
};

type RegisterData = {
  username: string;
  password: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
};

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [userWithPermissions, setUserWithPermissions] = useState<UserWithPermissions | null>(null);

  const {
    data: user,
    error,
    isLoading,
  } = useQuery<User | null, Error>({
    queryKey: ["/api/auth/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  useEffect(() => {
    if (user) {
      // Apply permissions based on role
      setUserWithPermissions({
        ...user,
        permissions: getDefaultPermissions(user.role as UserRole),
      });
    } else {
      setUserWithPermissions(null);
    }
  }, [user]);

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/auth/login", credentials);
      const userData = await res.json();
      return {
        ...userData,
        permissions: getDefaultPermissions(userData.role as UserRole),
      };
    },
    onSuccess: (data: any) => {
      // Save token in localStorage
      if (data.token) {
        localStorage.setItem('token', data.token);
      }
      
      // Use user data from response
      const userWithPerms = {
        ...data.user,
        permissions: getDefaultPermissions(data.user.role as UserRole),
      };
      
      queryClient.setQueryData(["/api/auth/user"], userWithPerms);
      setUserWithPermissions(userWithPerms);
      
      toast({
        title: "Login successful",
        description: `Welcome back, ${userWithPerms.firstName}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (userData: RegisterData) => {
      const res = await apiRequest("POST", "/api/auth/register", userData);
      const data = await res.json();
      return data; // Return the raw data which includes both token and user
    },
    onSuccess: (data: any) => {
      // Save token in localStorage
      if (data.token) {
        localStorage.setItem('token', data.token);
      }
      
      // Use user data from response
      const userWithPerms = {
        ...data.user,
        permissions: getDefaultPermissions(data.user.role as UserRole),
      };
      
      queryClient.setQueryData(["/api/auth/user"], userWithPerms);
      setUserWithPermissions(userWithPerms);
      
      toast({
        title: "Registration successful",
        description: `Welcome, ${userWithPerms.firstName}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/auth/logout");
    },
    onSuccess: () => {
      // Clear token from localStorage
      localStorage.removeItem('authToken');
      
      // Clear user data from state and cache
      queryClient.setQueryData(["/api/auth/user"], null);
      setUserWithPermissions(null);
      
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const hasPermission = (
    resource: keyof UserWithPermissions["permissions"],
    level: PermissionLevel
  ): boolean => {
    if (!userWithPermissions) return false;

    const userPermission = userWithPermissions.permissions[resource];
    
    // Order of permission strength (none is lowest at 0)
    const permissionStrength: Record<PermissionLevel, number> = {
      none: 0,
      read: 1,
      write: 2,
      admin: 3,
    };

    // Check if the user's permission level is >= the required level
    return permissionStrength[userPermission] >= permissionStrength[level];
  };

  return (
    <AuthContext.Provider
      value={{
        user: userWithPermissions,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
        hasPermission,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}