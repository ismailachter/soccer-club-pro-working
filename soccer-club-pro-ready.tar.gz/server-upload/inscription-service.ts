import { db } from './db';
import { inscriptions, clubs } from '@shared/schema';
import { eq, desc, and, like } from 'drizzle-orm';

export class InscriptionService {
  
  // Generate 5-digit unique ID
  private async generateInscriptionId(): Promise<string> {
    let attempts = 0;
    const maxAttempts = 100;
    
    while (attempts < maxAttempts) {
      // Generate random 5-digit number (10000-99999)
      const id = Math.floor(Math.random() * 90000) + 10000;
      const idString = id.toString();
      
      // Check if ID already exists
      const existing = await db.select()
        .from(inscriptions)
        .where(eq(inscriptions.id, idString));
      
      if (existing.length === 0) {
        return idString;
      }
      
      attempts++;
    }
    
    throw new Error('Unable to generate unique inscription ID after maximum attempts');
  }

  // Create new inscription
  async createInscription(inscriptionData: any, clubId: number) {
    // Get club name
    const [club] = await db.select()
      .from(clubs)
      .where(eq(clubs.id, clubId));
    
    if (!club) {
      throw new Error('Club not found');
    }

    // Generate unique 5-digit ID
    const inscriptionId = await this.generateInscriptionId();
    
    // Create inscription
    const [inscription] = await db.insert(inscriptions).values({
      id: inscriptionId,
      clubId,
      clubName: club.name,
      ...inscriptionData,
      submittedAt: new Date(),
      status: 'pending'
    }).returning();

    console.log(`✅ Inscription ${inscriptionId} created for ${inscriptionData.playerName} at ${club.name}`);
    return inscription;
  }

  // Get all inscriptions for club
  async getClubInscriptions(clubId: number, filters?: {
    status?: string;
    seasonYear?: string;
    teamCategory?: string;
    search?: string;
  }) {
    let query = db.select()
      .from(inscriptions)
      .where(eq(inscriptions.clubId, clubId))
      .orderBy(desc(inscriptions.submittedAt));

    // Apply filters if provided
    if (filters?.status) {
      query = query.where(and(
        eq(inscriptions.clubId, clubId),
        eq(inscriptions.status, filters.status)
      ));
    }

    if (filters?.seasonYear) {
      query = query.where(and(
        eq(inscriptions.clubId, clubId),
        eq(inscriptions.seasonYear, filters.seasonYear)
      ));
    }

    if (filters?.teamCategory) {
      query = query.where(and(
        eq(inscriptions.clubId, clubId),
        eq(inscriptions.teamCategory, filters.teamCategory)
      ));
    }

    if (filters?.search) {
      query = query.where(and(
        eq(inscriptions.clubId, clubId),
        like(inscriptions.playerName, `%${filters.search}%`)
      ));
    }

    return await query;
  }

  // Get inscription by ID
  async getInscriptionById(inscriptionId: string) {
    const [inscription] = await db.select()
      .from(inscriptions)
      .where(eq(inscriptions.id, inscriptionId));
    
    return inscription;
  }

  // Update inscription status
  async updateInscriptionStatus(inscriptionId: string, status: string, approvedBy?: number) {
    const updateData: any = {
      status,
      updatedAt: new Date()
    };

    if (status === 'approved' && approvedBy) {
      updateData.approvedAt = new Date();
      updateData.approvedBy = approvedBy;
    }

    const [updated] = await db.update(inscriptions)
      .set(updateData)
      .where(eq(inscriptions.id, inscriptionId))
      .returning();

    console.log(`✅ Inscription ${inscriptionId} status updated to ${status}`);
    return updated;
  }

  // Update inscription details
  async updateInscription(inscriptionId: string, updateData: any) {
    const [updated] = await db.update(inscriptions)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(inscriptions.id, inscriptionId))
      .returning();

    console.log(`✅ Inscription ${inscriptionId} updated`);
    return updated;
  }

  // Delete inscription
  async deleteInscription(inscriptionId: string) {
    await db.delete(inscriptions)
      .where(eq(inscriptions.id, inscriptionId));
    
    console.log(`🗑️ Inscription ${inscriptionId} deleted`);
  }

  // Get inscription statistics for club
  async getInscriptionStats(clubId: number, seasonYear?: string) {
    let query = db.select()
      .from(inscriptions)
      .where(eq(inscriptions.clubId, clubId));

    if (seasonYear) {
      query = query.where(and(
        eq(inscriptions.clubId, clubId),
        eq(inscriptions.seasonYear, seasonYear)
      ));
    }

    const allInscriptions = await query;
    
    const stats = {
      total: allInscriptions.length,
      pending: allInscriptions.filter(i => i.status === 'pending').length,
      approved: allInscriptions.filter(i => i.status === 'approved').length,
      rejected: allInscriptions.filter(i => i.status === 'rejected').length,
      byTeamCategory: {} as Record<string, number>,
      byGender: {
        male: allInscriptions.filter(i => i.gender === 'male').length,
        female: allInscriptions.filter(i => i.gender === 'female').length,
        other: allInscriptions.filter(i => i.gender === 'other').length
      },
      totalFees: allInscriptions
        .filter(i => i.registrationFee)
        .reduce((sum, i) => sum + parseFloat(i.registrationFee!), 0)
    };

    // Group by team category
    allInscriptions.forEach(inscription => {
      const category = inscription.teamCategory || 'Unassigned';
      stats.byTeamCategory[category] = (stats.byTeamCategory[category] || 0) + 1;
    });

    return stats;
  }

  // Bulk approve inscriptions
  async bulkApproveInscriptions(inscriptionIds: string[], approvedBy: number) {
    const updateData = {
      status: 'approved',
      approvedAt: new Date(),
      approvedBy,
      updatedAt: new Date()
    };

    await db.update(inscriptions)
      .set(updateData)
      .where(inscriptions.id.in ? inscriptions.id.in(inscriptionIds) : eq(inscriptions.id, inscriptionIds[0]));

    console.log(`✅ Bulk approved ${inscriptionIds.length} inscriptions`);
  }
}