import IncrementalVideoExtractor from './incremental-extractor.js';

const extractor = new IncrementalVideoExtractor();

console.log('Starting complete video extraction for Svelta Melsele vs VVC...');
console.log('Target: 3180 frames (106 minutes at 0.5 FPS)');

// Start extraction to 100% completion
extractor.extractToCompletion()
  .then(() => {
    const progress = extractor.getProgress();
    console.log(`Final result: ${progress.currentFrames}/${progress.targetFrames} frames (${progress.percentage.toFixed(1)}%)`);
    process.exit(0);
  })
  .catch(error => {
    console.error('Extraction failed:', error);
    process.exit(1);
  });

// Progress monitoring
const progressInterval = setInterval(() => {
  const progress = extractor.getProgress();
  console.log(`Current progress: ${progress.currentFrames}/${progress.targetFrames} frames (${progress.percentage.toFixed(1)}%)`);
  
  if (progress.isComplete) {
    console.log('Extraction completed successfully!');
    clearInterval(progressInterval);
  }
}, 30000); // Log progress every 30 seconds