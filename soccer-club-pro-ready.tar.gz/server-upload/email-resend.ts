import { Resend } from 'resend';

export class OneComEmailService {
  private transporter: any;

  constructor() {
    const nodemailer = require('nodemailer');
    this.transporter = nodemailer.createTransporter({
      host: 'send.one.com',
      port: 465,
      secure: true,
      auth: {
        user: 'info@soccerclubpro.com',
        pass: 'Qunoot135!'
      },
      tls: {
        rejectUnauthorized: false
      }
    });
  }

  async sendTrainingPDF(recipientEmail: string, pdfBuffer: Buffer, planTitle: string) {
    try {
      console.log(`Sending training PDF via Resend to ${recipientEmail}`);
      
      const result = await this.transporter.sendMail({
        from: 'Soccer Club Pro <info@soccerclubpro.com>',
        to: recipientEmail,
        cc: ['admin@soccerclubpro.com', 'ismail.achter@gmail.com'],
        subject: `⚽ ${planTitle} - Soccer Club Pro Professional Training`,
        html: this.generateHTMLContent(planTitle),
        text: this.generateTextContent(planTitle),
        attachments: [
          {
            filename: `${planTitle.replace(/\s+/g, '_')}.pdf`,
            content: pdfBuffer,
            contentType: 'application/pdf'
          }
        ]
      });

      console.log('Email sent successfully via One.com:', result.messageId);
      return { 
        success: true, 
        messageId: result.messageId,
        service: 'onecom'
      };

    } catch (error: any) {
      console.error('Resend email error:', error);
      return { 
        success: false, 
        error: error.message,
        service: 'resend'
      };
    }
  }

  private generateHTMLContent(planTitle: string): string {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); border-radius: 15px; overflow: hidden;">
        <div style="background: rgba(255,255,255,0.1); color: white; padding: 30px 20px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px;">VVC BRASSCHAAT</h1>
          <p style="margin: 10px 0 0 0; font-size: 18px;">${planTitle}</p>
        </div>
        
        <div style="background: white; color: #1e40af; padding: 30px;">
          <h2>Je Complete Jaarplan is Klaar!</h2>
          <p>In bijlage vind je het volledige jaarplan met alle verbeteringen:</p>
          
          <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #1e40af;">
            <strong>Plan Details:</strong>
            <ul>
              <li><strong>Complete thema weergave</strong> (geen elementen meer)</li>
              <li><strong>Exacte tijden:</strong> 20:00 - 21:45</li>
              <li><strong>VARIA opmerkingen volledig zichtbaar</strong></li>
              <li><strong>Professionele training boxes</strong> met nummering</li>
              <li><strong>Chronologische sortering</strong></li>
            </ul>
          </div>
          
          <p style="text-align: center; margin: 25px 0;">
            <strong>Volledige jaarplanning PDF is bijgevoegd</strong>
          </p>
        </div>
        
        <div style="background: rgba(255,255,255,0.1); color: white; padding: 20px; text-align: center; font-size: 12px;">
          <p style="margin: 0;"><strong>Soccer Club Pro</strong> - Professionele Voetbal Training Management</p>
        </div>
      </div>
    `;
  }

  private generateTextContent(planTitle: string): string {
    return `
VVC BRASSCHAAT - ${planTitle.toUpperCase()}

Je complete jaarplan is klaar!

PLAN DETAILS:
• Complete thema weergave (geen elementen meer)
• Exacte tijden: 20:00 - 21:45
• VARIA opmerkingen volledig zichtbaar
• Professionele training boxes met nummering
• Chronologische sortering

Met sportieve groet,
Soccer Club Pro Team
    `.trim();
  }
}

// Alternative Gmail SMTP service as backup
export class GmailSMTPService {
  private transporter: any;

  constructor(gmailEmail: string, gmailPassword: string) {
    const nodemailer = require('nodemailer');
    
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: gmailEmail,
        pass: gmailPassword // App-specific password
      }
    });
  }

  async sendTrainingPDF(recipientEmail: string, pdfBuffer: Buffer, planTitle: string) {
    try {
      const mailOptions = {
        from: 'Soccer Club Pro',
        to: recipientEmail,
        subject: `⚽ ${planTitle} - VVC Brasschaat`,
        html: this.generateHTMLContent(planTitle),
        attachments: [
          {
            filename: `${planTitle.replace(/\s+/g, '_')}.pdf`,
            content: pdfBuffer,
            contentType: 'application/pdf'
          }
        ]
      };

      const result = await this.transporter.sendMail(mailOptions);
      return { 
        success: true, 
        messageId: result.messageId,
        service: 'gmail'
      };

    } catch (error: any) {
      return { 
        success: false, 
        error: error.message,
        service: 'gmail'
      };
    }
  }

  private generateHTMLContent(planTitle: string): string {
    return `
      <h1>VVC Brasschaat - ${planTitle}</h1>
      <p>Je complete jaarplan is bijgevoegd met alle verbeteringen:</p>
      <ul>
        <li>Complete thema weergave (geen elementen meer)</li>
        <li>Exacte tijden: 20:00 - 21:45</li>
        <li>VARIA opmerkingen volledig zichtbaar</li>
        <li>Professionele training boxes met nummering</li>
      </ul>
      <p>Met sportieve groet,<br>Soccer Club Pro</p>
    `;
  }
}