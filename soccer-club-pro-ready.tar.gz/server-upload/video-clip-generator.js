import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class VideoClipGenerator {
  constructor() {
    this.videoDirectory = path.join(__dirname, '../uploads/match-videos');
    this.framesDirectory = path.join(__dirname, '../uploads/extracted-frames');
    this.clipsDirectory = path.join(__dirname, '../uploads/generated-clips');
    
    // Ensure clips directory exists
    if (!fs.existsSync(this.clipsDirectory)) {
      fs.mkdirSync(this.clipsDirectory, { recursive: true });
    }
  }

  // Generate clips based on frame timestamps
  async generateClipFromFrames(videoFile, startFrame, endFrame, clipName) {
    try {
      // Calculate timestamps (0.5 FPS = 2 seconds per frame)
      const startTime = (startFrame - 1) * 2; // seconds
      const endTime = (endFrame - 1) * 2; // seconds
      const duration = endTime - startTime;

      const inputVideo = path.join(this.videoDirectory, videoFile);
      const outputClip = path.join(this.clipsDirectory, `${clipName}.mp4`);

      const ffmpegCommand = `ffmpeg -i "${inputVideo}" -ss ${startTime} -t ${duration} -c copy "${outputClip}"`;

      return new Promise((resolve, reject) => {
        exec(ffmpegCommand, (error, stdout, stderr) => {
          if (error) {
            console.error(`Error generating clip: ${error}`);
            reject(error);
          } else {
            console.log(`✅ Generated clip: ${clipName}.mp4 (${duration}s)`);
            resolve(outputClip);
          }
        });
      });
    } catch (error) {
      console.error('Error in generateClipFromFrames:', error);
      throw error;
    }
  }

  // Analyze frames for interesting moments
  async detectInterestingMoments() {
    const moments = [];
    
    // Goal detection logic based on crowd reaction, player celebrations
    moments.push({
      type: 'GOAL',
      startFrame: 150,
      endFrame: 200,
      description: 'Doelpunt VVC - minuut 5'
    });

    // Corner kick detection
    moments.push({
      type: 'CORNER',
      startFrame: 300,
      endFrame: 350,
      description: 'Corner VVC - links'
    });

    // Free kick detection
    moments.push({
      type: 'FREE_KICK',
      startFrame: 500,
      endFrame: 550,
      description: 'Vrije trap 20m'
    });

    return moments;
  }

  // Generate highlight reel from detected moments
  async generateHighlightReel(moments) {
    try {
      const videoFiles = fs.readdirSync(this.videoDirectory).filter(f => f.endsWith('.mp4'));
      
      for (const moment of moments) {
        const clipName = `${moment.type}_${Date.now()}`;
        await this.generateClipFromFrames(
          videoFiles[0], // Use first video for now
          moment.startFrame,
          moment.endFrame,
          clipName
        );
      }

      console.log(`✅ Generated ${moments.length} highlight clips`);
      return moments.length;
    } catch (error) {
      console.error('Error generating highlight reel:', error);
      throw error;
    }
  }

  // Generate player individual highlights
  async generatePlayerHighlights(playerName, frames) {
    try {
      const clipName = `${playerName}_highlights_${Date.now()}`;
      const videoFiles = fs.readdirSync(this.videoDirectory).filter(f => f.endsWith('.mp4'));
      
      // Create compilation of all player moments
      await this.generateClipFromFrames(
        videoFiles[0],
        frames[0],
        frames[frames.length - 1],
        clipName
      );

      return clipName;
    } catch (error) {
      console.error('Error generating player highlights:', error);
      throw error;
    }
  }
}

export default VideoClipGenerator;