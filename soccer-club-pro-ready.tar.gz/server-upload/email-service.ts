import nodemailer from 'nodemailer';

export class SMTPEmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    // Direct SMTP configuration without authentication issues
    this.transporter = nodemailer.createTransport({
      host: 'send.one.com',
      port: 465,
      secure: true,
      auth: {
        user: 'info@soccerclubpro.com',
        pass: 'Qunoot136!'
      },
      tls: {
        rejectUnauthorized: false
      }
    });
  }

  async sendTrainingPDF(recipientEmail: string, pdfBuffer: Buffer, trainingTitle: string = "3-4-3 Opbouw Training") {
    try {
      console.log(`📧 Preparing mailserver email to ${recipientEmail}`);
      console.log(`📧 PDF Buffer size: ${pdfBuffer.length} bytes`);

      const mailOptions = {
        from: {
          name: 'Soccer Club Pro',
          address: 'info@soccerclubpro.com'
        },
        to: recipientEmail,
        cc: ['admin@soccerclubpro.com', 'ismail.achter@gmail.com'],
        subject: `Soccer Club Pro - ${trainingTitle}`,
        html: this.generateHTMLContent(trainingTitle),
        text: this.generateTextContent(trainingTitle),
        attachments: [
          {
            filename: 'Soccer-Club-Pro-Professional-Training.pdf',
            content: pdfBuffer,
            contentType: 'application/pdf'
          }
        ]
      };

      console.log('📧 Sending email via mailserver...');
      const result = await this.transporter.sendMail(mailOptions);
      
      console.log("✅ Email sent successfully via mailserver:", result.messageId);
      return { 
        success: true, 
        messageId: result.messageId,
        response: result 
      };

    } catch (error: any) {
      console.error("❌ Failed to send training PDF email via SMTP:");
      console.error("Error message:", error.message);
      console.error("Error code:", error.code);
      
      return { 
        success: false, 
        error: error.message || 'SMTP error occurred',
        errorCode: error.code,
        details: error
      };
    }
  }

  private generateHTMLContent(trainingTitle: string): string {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
        body { 
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
          line-height: 1.6; 
          color: #333; 
          margin: 0; 
          padding: 0;
          background-color: #f8fafc;
        }
        .container { 
          max-width: 600px; 
          margin: 0 auto; 
          background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
          border-radius: 15px;
          overflow: hidden;
          box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .header { 
          background: rgba(255,255,255,0.1); 
          color: white; 
          padding: 30px 20px; 
          text-align: center; 
        }
        .header h1 { 
          margin: 0; 
          font-size: 28px; 
          font-weight: bold;
        }
        .content { 
          background: white; 
          color: #1e40af; 
          padding: 30px; 
          margin: 0;
        }
        .features { 
          background: #f8fafc; 
          padding: 20px; 
          border-radius: 8px; 
          margin: 20px 0;
          border-left: 4px solid #1e40af;
        }
        .features ul { 
          margin: 10px 0; 
          padding-left: 20px; 
        }
        .features li { 
          margin: 8px 0; 
          font-size: 14px;
        }
        .highlight { 
          background: linear-gradient(45deg, #fef3c7, #fde68a); 
          padding: 15px; 
          border-radius: 8px; 
          margin: 20px 0;
          border: 1px solid #f59e0b;
        }
        .footer { 
          background: rgba(255,255,255,0.1); 
          color: white; 
          padding: 20px; 
          text-align: center; 
          font-size: 12px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>⚽ PROFESSIONELE VOETBALTRAINING</h1>
          <p style="margin: 10px 0 0 0; font-size: 18px; opacity: 0.9;">${trainingTitle}</p>
        </div>
        
        <div class="content">
          <h2>Je Complete Training is Klaar!</h2>
          <p style="font-size: 16px; margin-bottom: 20px;">
            Deze professionele PDF bevat alles wat je nodig hebt voor een succesvolle training:
          </p>
          
          <div class="features">
            <strong>📋 Complete Training Inhoud:</strong>
            <ul>
              <li><strong>90 minuten gestructureerde training</strong> voor 16 speelsters</li>
              <li><strong>Professionele veldtekeningen</strong> voor elke oefening</li>
              <li><strong>3-4-3 formatie diagrammen</strong> met exacte speler posities</li>
              <li><strong>Decision making elementen</strong> per game situatie</li>
              <li><strong>Coaching woorden</strong> voor elke trainingsfase</li>
              <li><strong>Exacte veldafmetingen</strong> en materiaallijsten</li>
            </ul>
          </div>

          <div class="features">
            <strong>🎯 6 Gedetailleerde Oefeningen:</strong>
            <ul>
              <li><strong>3v2 Opbouwen Centraal</strong> - Opbouw onder druk</li>
              <li><strong>4v3 Middenveld Connectie</strong> - Box middenveld spel</li>
              <li><strong>3v2+1 Aanval Afwerking</strong> - Numeriek voordeel</li>
              <li><strong>8v8 Complete Opbouw</strong> - Volledige wedstrijdvorm</li>
              <li><strong>Zones Voetbal 3-4-3</strong> - Positioneel spel</li>
              <li><strong>Eindzones Voetbal</strong> - Doelgericht opbouwen</li>
            </ul>
          </div>
          
          <div class="highlight">
            <strong>💡 Focus op Decision Making</strong><br>
            Elke oefening bevat specifieke decision making elementen om spelers te leren kiezen onder druk en de juiste keuzes te maken in game situaties.
          </div>
          
          <p style="text-align: center; margin: 25px 0;">
            <strong>📎 Training PDF is bijgevoegd als attachment</strong>
          </p>
        </div>
        
        <div class="footer">
          <p style="margin: 0;">
            <strong>Soccer Club Pro</strong> - Professionele Voetbal Training Management
          </p>
          <p style="margin: 5px 0 0 0;">
            VVC Brasschaat - Passie, Prestatie & Plezier - Samen Sterk!
          </p>
        </div>
      </div>
    </body>
    </html>
    `;
  }

  async sendInvitationEmail(recipientEmail: string, inviterName: string, role: string, tempPassword: string, clubName: string = "VVC Brasschaat"): Promise<any> {
    try {
      console.log(`📧 Sending invitation email to ${recipientEmail} for role: ${role}`);

      const mailOptions = {
        from: 'Soccer Club Pro <info@soccerclubpro.com>',
        cc: 'ismail.achter@gmail.com',
        to: recipientEmail,
        subject: `Uitnodiging voor ${clubName} - Soccer Club Pro`,
        html: this.generateInvitationHTML(recipientEmail, inviterName, role, tempPassword, clubName),
        text: this.generateInvitationText(recipientEmail, inviterName, role, tempPassword, clubName)
      };

      const result = await this.transporter.sendMail(mailOptions);
      
      console.log("✅ Invitation email sent successfully:", result.messageId);
      return { 
        success: true, 
        messageId: result.messageId,
        response: result 
      };

    } catch (error: any) {
      console.error("❌ Failed to send invitation email:", error.message);
      return { 
        success: false, 
        error: error.message || 'Invitation email failed',
        details: error
      };
    }
  }

  private generateInvitationHTML(email: string, inviterName: string, role: string, tempPassword: string, clubName: string): string {
    const baseUrl = process.env.BASE_URL || 'https://professional-tactical-pad.replit.app';
    
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f8fafc; }
        .container { max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .header { background: rgba(255,255,255,0.1); color: white; padding: 30px 20px; text-align: center; }
        .header h1 { margin: 0; font-size: 28px; font-weight: bold; }
        .content { background: white; color: #1e40af; padding: 30px; margin: 0; }
        .credentials { background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #1e40af; }
        .button { display: inline-block; background: #1e40af; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; margin: 20px 0; }
        .footer { background: rgba(255,255,255,0.1); color: white; padding: 20px; text-align: center; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>⚽ Welkom bij ${clubName}</h1>
          <p>Je bent uitgenodigd voor Soccer Club Pro</p>
        </div>
        
        <div class="content">
          <h2>Uitnodiging voor ${role}</h2>
          <p>Beste,</p>
          <p><strong>${inviterName}</strong> heeft je uitgenodigd om deel te nemen aan ${clubName} via Soccer Club Pro als <strong>${role}</strong>.</p>
          
          <div class="credentials">
            <h3>Je login gegevens:</h3>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Tijdelijk wachtwoord:</strong> <code>${tempPassword}</code></p>
          </div>
          
          <p>Log in en wijzig je wachtwoord bij je eerste bezoek.</p>
          
          <div style="text-align: center;">
            <a href="${baseUrl}/auth" class="button">Inloggen op Soccer Club Pro</a>
          </div>
          
          <h3>Wat kun je verwachten:</h3>
          <ul>
            <li>Professionele trainingsplanning en IADATABANK</li>
            <li>Complete jaarplanning met kalender functionaliteit</li>
            <li>Team management en speler ontwikkeling</li>
            <li>Match planning en resultaten bijhouden</li>
            <li>Communicatie tools voor club organisatie</li>
          </ul>
        </div>
        
        <div class="footer">
          <p><strong>Soccer Club Pro</strong> - Professionele Voetbal Club Management</p>
          <p>${clubName} - Samen Sterker</p>
        </div>
      </div>
    </body>
    </html>
    `;
  }

  private generateInvitationText(email: string, inviterName: string, role: string, tempPassword: string, clubName: string): string {
    const baseUrl = process.env.BASE_URL || 'https://professional-tactical-pad.replit.app';
    
    return `
Welkom bij ${clubName} - Soccer Club Pro

Beste,

${inviterName} heeft je uitgenodigd om deel te nemen aan ${clubName} via Soccer Club Pro als ${role}.

JE LOGIN GEGEVENS:
Email: ${email}
Tijdelijk wachtwoord: ${tempPassword}

Log in op: ${baseUrl}/auth

Wijzig je wachtwoord bij je eerste bezoek.

WAT KUN JE VERWACHTEN:
• Professionele trainingsplanning en IADATABANK
• Complete jaarplanning met kalender functionaliteit  
• Team management en speler ontwikkeling
• Match planning en resultaten bijhouden
• Communicatie tools voor club organisatie

Met sportieve groet,
Soccer Club Pro Team
${clubName} - Samen Sterker
    `;
  }

  private generateTextContent(trainingTitle: string): string {
    return `
PROFESSIONELE VOETBALTRAINING - ${trainingTitle}

Beste Trainer,

Je complete training is klaar! Deze PDF bevat:

COMPLETE TRAINING INHOUD:
• 90 minuten gestructureerde training voor 16 speelsters
• Professionele veldtekeningen voor elke oefening
• 3-4-3 formatie diagrammen met exacte speler posities
• Decision making elementen per game situatie
• Coaching woorden voor elke trainingsfase
• Exacte veldafmetingen en materiaallijsten

6 GEDETAILLEERDE OEFENINGEN:
1. 3v2 Opbouwen Centraal - Opbouw onder druk
2. 4v3 Middenveld Connectie - Box middenveld spel
3. 3v2+1 Aanval Afwerking - Numeriek voordeel
4. 8v8 Complete Opbouw - Volledige wedstrijdvorm
5. Zones Voetbal 3-4-3 - Positioneel spel
6. Eindzones Voetbal - Doelgericht opbouwen

FOCUS OP DECISION MAKING:
Elke oefening bevat specifieke decision making elementen om spelers te leren kiezen onder druk en de juiste keuzes te maken in game situaties.

De training PDF is bijgevoegd als attachment.

Met sportieve groet,
Soccer Club Pro Team
VVC Brasschaat - Passie, Prestatie & Plezier - Samen Sterk!
    `;
  }
}