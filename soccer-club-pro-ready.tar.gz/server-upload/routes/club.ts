import { Router } from 'express';
import { db } from '../db';
import { clubs } from '@shared/schema';
import { eq } from 'drizzle-orm';
import { isAuthenticated } from '../auth';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

// ES Modules replacement for __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
import express from 'express';

// Configure multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadsDir = path.join(__dirname, '../../uploads');
    
    // Ensure the uploads directory exists
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }
    
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    // Generate a unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const extension = path.extname(file.originalname);
    cb(null, 'club-logo-' + uniqueSuffix + extension);
  }
});

// File filter to only allow certain image types
const fileFilter = (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  // Accept only jpeg and png
  if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
    cb(null, true);
  } else {
    cb(null, false); // reject the file
    // @ts-ignore
    cb(new Error('Only .jpeg and .png files are allowed'));
  }
};

const upload = multer({ 
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

const router = Router();

// Get club information
router.get('/info', async (req, res) => {
  try {
    // First try to get the club information from the database
    const clubsList = await db.select().from(clubs);
    
    // If there's a club, return it
    if (clubsList.length > 0) {
      return res.json(clubsList[0]);
    }
    
    // If no club exists yet, return a default object
    return res.json({
      id: 0,
      name: 'Club Information',
      fullName: '',
      shortName: '',
      status: 'active'
    });
  } catch (error) {
    console.error('Error fetching club info:', error);
    res.status(500).json({ message: 'Error fetching club information' });
  }
});

// Update club information
router.patch('/info', isAuthenticated, async (req, res) => {
  try {
    const updateData = req.body;
    
    // Check if club exists
    const clubsList = await db.select().from(clubs);
    
    if (clubsList.length > 0) {
      // Update existing club
      const [updated] = await db.update(clubs)
        .set({
          ...updateData,
          updatedAt: new Date(),
          updatedBy: req.user?.id
        })
        .where(eq(clubs.id, clubsList[0].id))
        .returning();
      
      return res.json(updated);
    } else {
      // Create new club
      const [created] = await db.insert(clubs)
        .values({
          ...updateData,
          createdAt: new Date(),
          createdBy: req.user?.id
        })
        .returning();
      
      return res.status(201).json(created);
    }
  } catch (error) {
    console.error('Error updating club info:', error);
    res.status(500).json({ message: 'Error updating club information' });
  }
});

// Upload club logo - temporarily remove authentication for testing
router.post('/logo-upload', upload.single('logo'), async (req, res) => {
  try {
    console.log('Logo upload request received');
    if (!req.file) {
      console.log('No file in request', req.body);
      return res.status(400).json({ message: 'No file uploaded or invalid file type' });
    }
    console.log('File received:', req.file.filename);

    // Get the relative path to serve the image
    const relativePath = path.relative(path.join(__dirname, '../..'), req.file.path);
    const serverUrl = `/${relativePath.replace(/\\/g, '/')}`;
    
    // Check if club exists
    const clubsList = await db.select().from(clubs);
    
    if (clubsList.length > 0) {
      // Update existing club with new logo path
      const [updated] = await db.update(clubs)
        .set({
          logo: serverUrl,
          updatedAt: new Date(),
          updatedBy: null // Temporary: no user ID available without authentication
        })
        .where(eq(clubs.id, clubsList[0].id))
        .returning();
      
      return res.json(updated);
    } else {
      // Create new club if it doesn't exist yet
      const [created] = await db.insert(clubs)
        .values({
          name: 'Club Information',
          logo: serverUrl,
          createdAt: new Date(),
          createdBy: null // Temporary: no user ID available without authentication
        })
        .returning();
      
      return res.status(201).json(created);
    }
  } catch (error) {
    console.error('Error uploading logo:', error);
    res.status(500).json({ message: 'Error uploading club logo' });
  }
});

// Serve static files from the uploads directory
router.use('/uploads', express.static(path.join(__dirname, '../../uploads')));

export default router;