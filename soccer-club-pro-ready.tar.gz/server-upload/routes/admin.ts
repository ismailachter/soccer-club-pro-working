import express, { Router, Request, Response } from 'express';
import { db } from '../db';
import { sql } from 'drizzle-orm';
import { exec } from 'child_process';
import { promisify } from 'util';
import { createObjectCsvStringifier } from 'csv-writer';
import { parse } from 'csv-parse/sync';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const execAsync = promisify(exec);

const adminRouter = Router();

// Middleware to check if user has required permissions
const checkPermission = (permission: 'read' | 'write' | 'admin') => {
  return (req: Request, res: Response, next: express.NextFunction) => {
    // Get user from session
    const user = req.user;
    
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized: You must be logged in' });
    }

    // Check if user has required permission
    // This assumes user object has a permissions.database property with values 'none', 'read', 'write', or 'admin'
    const permissionLevels: Record<string, number> = {
      'none': 0,
      'read': 1,
      'write': 2,
      'admin': 3
    };

    // Get the user's permission level for database
    let userPermission = 'none';
    if (user.role === 'admin') {
      userPermission = 'admin';
    } else if (['sportive_director', 'coordinator'].includes(user.role)) {
      userPermission = 'write';
    } else if (['coach', 'trainer'].includes(user.role)) {
      userPermission = 'read';
    }

    // Check if user has sufficient permission
    if (permissionLevels[userPermission] >= permissionLevels[permission]) {
      return next();
    }
    
    return res.status(403).json({
      error: 'Forbidden: Insufficient permissions',
      requiredPermission: permission,
      userPermission
    });
  };
};

// Apply permission checks to specific endpoints based on their required permission level
// SQL query execution and schema changes require admin permission
adminRouter.post('/database/execute', checkPermission('admin'));
adminRouter.post('/database/push', checkPermission('admin'));

// CSV imports require write permission
adminRouter.post('/database/import', checkPermission('write'));

// CSV exports, schema info, and table lists only require read permission
adminRouter.post('/database/export', checkPermission('read'));
adminRouter.get('/database/schema', checkPermission('read'));
adminRouter.get('/database/tables', checkPermission('read'));

// Execute arbitrary SQL query (admin only)
adminRouter.post('/database/execute', async (req, res) => {
  try {
    const { query } = req.body;
    
    if (!query) {
      return res.status(400).json({ error: 'No SQL query provided' });
    }

    const result = await db.execute(sql.raw(query));
    
    return res.json(result);
  } catch (error) {
    console.error('Error executing SQL query:', error);
    return res.status(500).json({ error: String(error) });
  }
});

// Get database schema information
adminRouter.get('/database/schema', async (req, res) => {
  try {
    // Get table names
    const tableQuery = `
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
      ORDER BY table_name;
    `;
    
    const tables = await db.execute(sql.raw(tableQuery));
    
    // Get column information for each table
    const tablesInfo: any = {};
    
    for (const row of tables.rows) {
      const tableName = row.table_name as string;
      
      const columnQuery = `
        SELECT column_name, data_type, is_nullable, column_default
        FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = '${tableName}'
        ORDER BY ordinal_position;
      `;
      
      const columns = await db.execute(sql.raw(columnQuery));
      tablesInfo[tableName] = columns.rows;
    }
    
    return res.json({
      type: 'PostgreSQL',
      tables: tablesInfo
    });
  } catch (error) {
    console.error('Error getting schema info:', error);
    return res.status(500).json({ error: String(error) });
  }
});

// Get tables list with row counts
adminRouter.get('/database/tables', async (req, res) => {
  try {
    // First get table names
    const tableQuery = `
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
      ORDER BY table_name;
    `;
    
    const tables = await db.execute(sql.raw(tableQuery));
    
    // Then get count for each table
    const tablesWithCounts = [];
    
    for (const row of tables.rows) {
      const tableName = row.table_name as string;
      const countQuery = `SELECT COUNT(*) as count FROM "${tableName}";`;
      const countResult = await db.execute(sql.raw(countQuery));
      
      tablesWithCounts.push({
        name: tableName,
        count: parseInt(countResult.rows[0].count as string, 10)
      });
    }
    
    return res.json({ tables: tablesWithCounts });
  } catch (error) {
    console.error('Error getting tables info:', error);
    return res.status(500).json({ error: String(error) });
  }
});

// Push schema changes to database
adminRouter.post('/database/push', async (req, res) => {
  try {
    // Execute drizzle-kit push
    const { stdout, stderr } = await execAsync('npm run db:push');
    
    if (stderr && !stderr.includes('Warn')) {
      throw new Error(stderr);
    }
    
    return res.json({ 
      message: 'Database schema updated successfully',
      details: stdout
    });
  } catch (error) {
    console.error('Error pushing schema:', error);
    return res.status(500).json({ error: String(error) });
  }
});

// Export table data to CSV
adminRouter.post('/database/export', async (req, res) => {
  try {
    const { table } = req.body;
    
    if (!table) {
      return res.status(400).json({ error: 'No table specified' });
    }
    
    // Check if table exists
    const tableCheckQuery = `
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = '${table}'
      );
    `;
    
    const tableExistsResult = await db.execute(sql.raw(tableCheckQuery));
    const tableExists = tableExistsResult.rows[0].exists === true;
    
    if (!tableExists) {
      return res.status(404).json({ error: 'Table not found' });
    }
    
    // Get table data
    const dataQuery = `SELECT * FROM "${table}";`;
    const result = await db.execute(sql.raw(dataQuery));
    
    if (!result.rows || result.rows.length === 0) {
      return res.json({ csv: '' });
    }
    
    // Get column headers
    const headers = Object.keys(result.rows[0]).map(key => ({
      id: key,
      title: key
    }));
    
    // Create CSV
    const csvStringifier = createObjectCsvStringifier({
      header: headers
    });
    
    const headerString = csvStringifier.getHeaderString();
    const recordsString = csvStringifier.stringifyRecords(result.rows);
    const csv = headerString + recordsString;
    
    return res.json({ csv });
  } catch (error) {
    console.error('Error exporting CSV:', error);
    return res.status(500).json({ error: String(error) });
  }
});

// Import CSV data into a table
adminRouter.post('/database/import', async (req, res) => {
  try {
    const { table, csvData } = req.body;
    
    if (!table) {
      return res.status(400).json({ error: 'No table specified' });
    }
    
    if (!csvData) {
      return res.status(400).json({ error: 'No CSV data provided' });
    }
    
    // Check if table exists
    const tableCheckQuery = `
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = '${table}'
      );
    `;
    
    const tableExistsResult = await db.execute(sql.raw(tableCheckQuery));
    const tableExists = tableExistsResult.rows[0].exists === true;
    
    if (!tableExists) {
      return res.status(404).json({ error: 'Table not found' });
    }
    
    // Get column information
    const columnQuery = `
      SELECT column_name, data_type
      FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = '${table}'
      ORDER BY ordinal_position;
    `;
    
    const columnsResult = await db.execute(sql.raw(columnQuery));
    const columns = columnsResult.rows.map((row: any) => ({
      name: row.column_name as string,
      type: row.data_type as string
    }));
    
    // Parse CSV data
    const records = parse(csvData, {
      columns: true,
      skip_empty_lines: true
    });
    
    if (records.length === 0) {
      return res.status(400).json({ error: 'No records found in CSV data' });
    }
    
    // Validate and prepare records for insertion
    const columnNames = columns.map(col => col.name);
    const recordKeys = Object.keys(records[0]);
    
    // Check if CSV headers match table columns (at least some intersection)
    const validKeys = recordKeys.filter(key => columnNames.includes(key));
    if (validKeys.length === 0) {
      return res.status(400).json({ 
        error: 'CSV headers do not match any columns in the table',
        expectedColumns: columnNames,
        csvColumns: recordKeys
      });
    }
    
    // Prepare batch insert query
    const columnsList = validKeys.map(key => `"${key}"`).join(', ');
    let valuesList = '';
    
    let insertCount = 0;
    for (const record of records) {
      // Skip if ID is provided and trying to modify system tables
      if (record.id && ['users', 'sessions'].includes(table)) {
        continue;
      }
      
      const values = validKeys.map(key => {
        const value = record[key];
        if (value === null || value === undefined || value === '') {
          return 'NULL';
        }
        // Handle different data types
        if (typeof value === 'number') {
          return value;
        }
        return `'${String(value).replace(/'/g, "''")}'`;
      }).join(', ');
      
      if (valuesList.length > 0) {
        valuesList += ', ';
      }
      valuesList += `(${values})`;
      insertCount++;
    }
    
    if (insertCount === 0) {
      return res.status(400).json({ error: 'No valid records found for insertion' });
    }
    
    // Execute the insert statement
    const insertQuery = `INSERT INTO "${table}" (${columnsList}) VALUES ${valuesList};`;
    await db.execute(sql.raw(insertQuery));
    
    return res.json({ 
      message: `Successfully imported ${insertCount} records into ${table}`,
      importedRecords: insertCount
    });
  } catch (error) {
    console.error('Error importing CSV:', error);
    return res.status(500).json({ error: String(error) });
  }
});

// IADATABANK PDF Export route
adminRouter.get('/export/iadatabank/pdf', checkPermission('read'), async (req: Request, res: Response) => {
  try {
    // Get all IADATABANK elements from database
    const basicElements = await db.execute(sql`
      SELECT be.*, dl.name as level_name, dl.description as level_description, dl.difficulty, dl.sort_order as level_order
      FROM basic_elements be
      LEFT JOIN depth_levels dl ON be.id = dl.element_id
      WHERE be.is_active = true
      ORDER BY be.subtopic, be.sort_order, dl.sort_order
    `);

    const teamElements = await db.execute(sql`
      SELECT te.*, tl.name as level_name, tl.description as level_description, tl.difficulty, tl.sort_order as level_order
      FROM teamtactisch_elements te
      LEFT JOIN teamtactisch_levels tl ON te.id = tl.element_id
      WHERE te.is_active = true
      ORDER BY te.subtopic, te.sort_order, tl.sort_order
    `);

    const mentaalElements = await db.execute(sql`
      SELECT me.*, ml.name as level_name, ml.description as level_description, ml.difficulty, ml.sort_order as level_order
      FROM mentaal_elements me
      LEFT JOIN mentaal_levels ml ON me.id = ml.element_id
      WHERE me.is_active = true
      ORDER BY me.sort_order, ml.sort_order
    `);

    // Create PDF document
    const doc = new jsPDF();
    let yPosition = 20;
    
    // Add title
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('IADATABANK - Volledige Training Database', 20, yPosition);
    yPosition += 15;
    
    // Add subtitle and timestamp
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Gegenereerd op: ${new Date().toLocaleDateString('nl-NL')}`, 20, yPosition);
    yPosition += 10;
    doc.text('Soccer Club Management System - Uitgebreide Training Elementen', 20, yPosition);
    yPosition += 20;

    // BASICS Section
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('1. BASICS - Fundamentele Voetbalvaardigheden', 20, yPosition);
    yPosition += 15;

    // Group BASICS elements by subtopic
    const basicsGrouped: any = {};
    basicElements.rows.forEach((element: any) => {
      if (!basicsGrouped[element.subtopic]) {
        basicsGrouped[element.subtopic] = [];
      }
      basicsGrouped[element.subtopic].push(element);
    });

    // Process each BASICS subtopic
    Object.keys(basicsGrouped).forEach(subtopic => {
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 20;
      }
      
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(`BASICS ${subtopic}:`, 25, yPosition);
      yPosition += 10;

      // Group elements by name for progressive levels
      const elementsGrouped: any = {};
      basicsGrouped[subtopic].forEach((element: any) => {
        if (!elementsGrouped[element.name]) {
          elementsGrouped[element.name] = [];
        }
        elementsGrouped[element.name].push(element);
      });

      Object.keys(elementsGrouped).forEach(elementName => {
        if (yPosition > 240) {
          doc.addPage();
          yPosition = 20;
        }

        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${elementName}`, 30, yPosition);
        yPosition += 8;

        // Sort levels by difficulty and add them
        elementsGrouped[elementName]
          .sort((a: any, b: any) => a.level_order - b.level_order)
          .forEach((level: any, index: number) => {
            if (level.level_name) {
              if (yPosition > 260) {
                doc.addPage();
                yPosition = 20;
              }
              
              const stars = '★'.repeat(level.difficulty) + '☆'.repeat(6 - level.difficulty);
              doc.setFont('helvetica', 'normal');
              doc.text(`   ${stars} ${level.level_name}`, 35, yPosition);
              yPosition += 6;
              doc.setFontSize(10);
              doc.text(`     ${level.level_description}`, 35, yPosition);
              yPosition += 8;
              doc.setFontSize(12);
            }
          });
        yPosition += 5;
      });
      yPosition += 10;
    });

    // TEAMTACTISCH Section
    if (yPosition > 200) {
      doc.addPage();
      yPosition = 20;
    }
    
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('2. TEAMTACTISCH - Tactische Aspecten', 20, yPosition);
    yPosition += 15;

    // Group TEAMTACTISCH elements by subtopic
    const teamGrouped: any = {};
    teamElements.rows.forEach((element: any) => {
      if (!teamGrouped[element.subtopic]) {
        teamGrouped[element.subtopic] = [];
      }
      teamGrouped[element.subtopic].push(element);
    });

    Object.keys(teamGrouped).forEach(subtopic => {
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 20;
      }
      
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(`${subtopic}:`, 25, yPosition);
      yPosition += 10;

      const elementsGrouped: any = {};
      teamGrouped[subtopic].forEach((element: any) => {
        if (!elementsGrouped[element.name]) {
          elementsGrouped[element.name] = [];
        }
        elementsGrouped[element.name].push(element);
      });

      Object.keys(elementsGrouped).forEach(elementName => {
        if (yPosition > 240) {
          doc.addPage();
          yPosition = 20;
        }

        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(`• ${elementName}`, 30, yPosition);
        yPosition += 8;

        elementsGrouped[elementName]
          .sort((a: any, b: any) => a.level_order - b.level_order)
          .forEach((level: any) => {
            if (level.level_name) {
              if (yPosition > 260) {
                doc.addPage();
                yPosition = 20;
              }
              
              const stars = '★'.repeat(level.difficulty) + '☆'.repeat(6 - level.difficulty);
              doc.setFont('helvetica', 'normal');
              doc.text(`   ${stars} ${level.level_name}`, 35, yPosition);
              yPosition += 6;
              doc.setFontSize(10);
              doc.text(`     ${level.level_description}`, 35, yPosition);
              yPosition += 8;
              doc.setFontSize(12);
            }
          });
        yPosition += 5;
      });
      yPosition += 10;
    });

    // MENTAAL Section
    if (yPosition > 200) {
      doc.addPage();
      yPosition = 20;
    }
    
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('3. MENTAAL - Mentale Aspecten', 20, yPosition);
    yPosition += 15;

    // Group MENTAAL elements
    const mentaalGrouped: any = {};
    mentaalElements.rows.forEach((element: any) => {
      if (!mentaalGrouped[element.name]) {
        mentaalGrouped[element.name] = [];
      }
      mentaalGrouped[element.name].push(element);
    });

    Object.keys(mentaalGrouped).forEach(elementName => {
      if (yPosition > 240) {
        doc.addPage();
        yPosition = 20;
      }

      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text(`• ${elementName}`, 25, yPosition);
      yPosition += 8;

      mentaalGrouped[elementName]
        .sort((a: any, b: any) => a.level_order - b.level_order)
        .forEach((level: any) => {
          if (level.level_name) {
            if (yPosition > 260) {
              doc.addPage();
              yPosition = 20;
            }
            
            const stars = '★'.repeat(level.difficulty) + '☆'.repeat(6 - level.difficulty);
            doc.setFont('helvetica', 'normal');
            doc.text(`   ${stars} ${level.level_name}`, 30, yPosition);
            yPosition += 6;
            doc.setFontSize(10);
            doc.text(`     ${level.level_description}`, 30, yPosition);
            yPosition += 8;
            doc.setFontSize(12);
          }
        });
      yPosition += 5;
    });

    // Add footer with summary
    doc.addPage();
    yPosition = 20;
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('IADATABANK Samenvatting', 20, yPosition);
    yPosition += 15;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Totaal aantal BASICS elementen: ${Object.keys(basicsGrouped).reduce((acc, key) => acc + Object.keys(basicsGrouped[key].reduce((grp: any, el: any) => {
      grp[el.name] = true; return grp;
    }, {})).length, 0)}`, 20, yPosition);
    yPosition += 8;
    
    doc.text(`Totaal aantal TEAMTACTISCH elementen: ${Object.keys(teamGrouped).reduce((acc, key) => acc + Object.keys(teamGrouped[key].reduce((grp: any, el: any) => {
      grp[el.name] = true; return grp;
    }, {})).length, 0)}`, 20, yPosition);
    yPosition += 8;
    
    doc.text(`Totaal aantal MENTAAL elementen: ${Object.keys(mentaalGrouped).length}`, 20, yPosition);
    yPosition += 15;
    
    doc.text('6-staps progressiesysteem: ★☆☆☆☆☆ tot ★★★★★★', 20, yPosition);
    yPosition += 8;
    doc.text('Van kinderlijke fase tot professionele meesterschap', 20, yPosition);

    // Generate PDF buffer
    const pdfBuffer = Buffer.from(doc.output('arraybuffer'));
    
    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="iadatabank-volledig-rapport-${new Date().toISOString().slice(0, 10)}.pdf"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    
    // Send PDF
    res.end(pdfBuffer);
    
  } catch (error) {
    console.error('Error generating IADATABANK PDF:', error);
    res.status(500).json({ error: 'Failed to generate PDF export' });
  }
});

export default adminRouter;