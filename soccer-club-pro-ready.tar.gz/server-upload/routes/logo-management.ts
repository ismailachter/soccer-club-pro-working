import express from 'express';
import { LogoManager } from '../utils/logo-manager';

const logoRouter = express.Router();

// Get all available logos with team assignments
logoRouter.get('/logos', async (req, res) => {
  try {
    const logos = await LogoManager.getAvailableLogos();
    res.json(logos);
  } catch (error) {
    console.error('Error fetching logos:', error);
    res.status(500).json({ message: 'Failed to fetch logos' });
  }
});

// Get organized logos for teams
logoRouter.get('/logos/organization', async (req, res) => {
  try {
    const organization = await LogoManager.organizeLogosForTeams();
    res.json(organization);
  } catch (error) {
    console.error('Error organizing logos:', error);
    res.status(500).json({ message: 'Failed to organize logos' });
  }
});

// Get logo for specific team
logoRouter.get('/logos/team/:ageGroup', async (req, res) => {
  try {
    const ageGroup = req.params.ageGroup;
    const logoPath = await LogoManager.getLogoForTeam(ageGroup);
    
    if (!logoPath) {
      return res.status(404).json({ message: 'No logo found for this team' });
    }
    
    res.json({ logoPath, team: ageGroup });
  } catch (error) {
    console.error('Error getting team logo:', error);
    res.status(500).json({ message: 'Failed to get team logo' });
  }
});

export default logoRouter;