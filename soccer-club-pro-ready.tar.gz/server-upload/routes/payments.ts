import { Router, Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { db } from '../db';
import { 
  feeCategories, 
  userFees, 
  payments,
  paymentPlans,
  paymentPlanInstallments,
  users,
  teams
} from '@shared/schema';
import { eq, and, inArray, desc, sql } from 'drizzle-orm';
import { sendPaymentReminderEmail } from '../utils/resend-mail';

// Import User type to properly type the Request interface
import { User } from '@shared/schema';

// Extend Express Request to include user and authentication methods
declare global {
  namespace Express {
    interface Request {
      user?: User;
      isAuthenticated(): boolean;
    }
  }
}

const router = Router();

// Middleware to check admin or coordinator permissions
const checkPaymentPermissions = (req: Request, res: Response, next: NextFunction) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Authentication required' });
  }
  
  // Check if user has permission to manage payments (admin, coordinator, or specific payment role)
  const allowedRoles = ['admin', 'coordinator'];
  if (req.user && !allowedRoles.includes(req.user.role)) {
    return res.status(403).json({ message: 'Insufficient permissions' });
  }
  
  next();
};

/**
 * FEE CATEGORIES ROUTES
 */

// Get all fee categories
router.get('/fee-categories', async (req: Request, res: Response) => {
  try {
    const allCategories = await db.select().from(feeCategories).orderBy(desc(feeCategories.createdAt));
    
    // Enhance with team name if teamId is provided
    const enhancedCategories = await Promise.all(
      allCategories.map(async (category) => {
        if (category.teamId) {
          const team = await db.select().from(teams).where(eq(teams.id, category.teamId)).limit(1);
          return {
            ...category,
            teamName: team.length > 0 ? team[0].name : 'Unknown'
          };
        }
        return category;
      })
    );
    
    res.json(enhancedCategories);
  } catch (error) {
    console.error('Error fetching fee categories:', error);
    res.status(500).json({ message: 'Failed to fetch fee categories' });
  }
});

// Get a specific fee category
router.get('/fee-categories/:id', async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid fee category ID' });
    }
    
    const [category] = await db.select().from(feeCategories).where(eq(feeCategories.id, id));
    
    if (!category) {
      return res.status(404).json({ message: 'Fee category not found' });
    }
    
    res.json(category);
  } catch (error) {
    console.error('Error fetching fee category:', error);
    res.status(500).json({ message: 'Failed to fetch fee category' });
  }
});

// Create a new fee category
router.post('/fee-categories', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const schema = z.object({
      name: z.string().min(1, 'Name is required'),
      description: z.string().optional().nullable(),
      feeType: z.enum(['membership', 'registration', 'tournament', 'equipment', 'training', 'travel', 'event', 'other']),
      amount: z.number().positive('Amount must be positive'),
      discount: z.number().min(0).default(0),
      dueDate: z.string().optional().nullable(),
      teamId: z.number().optional().nullable(),
      ageGroup: z.string().optional().nullable(),
      seasonId: z.number().optional().nullable(),
      isActive: z.boolean().default(true),
    });

    const validatedData = schema.parse(req.body);
    
    const [newCategory] = await db.insert(feeCategories).values({
      name: validatedData.name,
      description: validatedData.description,
      feeType: validatedData.feeType,
      amount: validatedData.amount.toString(),
      discount: validatedData.discount.toString(),
      dueDate: validatedData.dueDate ? validatedData.dueDate : null, // Date is already formatted in the schema
      teamId: validatedData.teamId,
      ageGroup: validatedData.ageGroup,
      seasonId: validatedData.seasonId,
      isActive: validatedData.isActive,
    }).returning();
    
    res.status(201).json(newCategory);
  } catch (error) {
    console.error('Error creating fee category:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to create fee category' });
  }
});

// Update a fee category
router.put('/fee-categories/:id', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid fee category ID' });
    }
    
    const schema = z.object({
      name: z.string().min(1, 'Name is required'),
      description: z.string().optional().nullable(),
      feeType: z.enum(['membership', 'registration', 'tournament', 'equipment', 'training', 'travel', 'event', 'other']),
      amount: z.number().positive('Amount must be positive'),
      discount: z.number().min(0).default(0),
      dueDate: z.string().optional().nullable(),
      teamId: z.number().optional().nullable(),
      ageGroup: z.string().optional().nullable(),
      seasonId: z.number().optional().nullable(),
      isActive: z.boolean().default(true),
    });

    const validatedData = schema.parse(req.body);
    
    const [updatedCategory] = await db.update(feeCategories)
      .set({
        name: validatedData.name,
        description: validatedData.description,
        feeType: validatedData.feeType,
        amount: validatedData.amount.toString(),
        discount: validatedData.discount.toString(),
        dueDate: validatedData.dueDate ? new Date(validatedData.dueDate) : null,
        teamId: validatedData.teamId,
        ageGroup: validatedData.ageGroup,
        seasonId: validatedData.seasonId,
        isActive: validatedData.isActive,
      })
      .where(eq(feeCategories.id, id))
      .returning();
    
    if (!updatedCategory) {
      return res.status(404).json({ message: 'Fee category not found' });
    }
    
    res.json(updatedCategory);
  } catch (error) {
    console.error('Error updating fee category:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to update fee category' });
  }
});

// Delete a fee category
router.delete('/fee-categories/:id', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid fee category ID' });
    }
    
    // Check if the fee category is used in user fees
    const [usedInUserFees] = await db.select({ count: sql<number>`count(*)` })
      .from(userFees)
      .where(eq(userFees.feeCategoryId, id));
    
    if (usedInUserFees.count > 0) {
      return res.status(400).json({ 
        message: 'Cannot delete fee category because it is assigned to users',
        count: usedInUserFees.count
      });
    }
    
    const [deletedCategory] = await db.delete(feeCategories)
      .where(eq(feeCategories.id, id))
      .returning();
    
    if (!deletedCategory) {
      return res.status(404).json({ message: 'Fee category not found' });
    }
    
    res.json({ message: 'Fee category deleted successfully' });
  } catch (error) {
    console.error('Error deleting fee category:', error);
    res.status(500).json({ message: 'Failed to delete fee category' });
  }
});

/**
 * USER FEES ROUTES
 */

// Get all user fees
router.get('/user-fees', async (req: Request, res: Response) => {
  try {
    const allUserFees = await db.select().from(userFees).orderBy(desc(userFees.createdAt));
    
    // Enhance with user and fee category data
    const enhancedUserFees = await Promise.all(
      allUserFees.map(async (userFee) => {
        const [user] = await db.select({
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email
        }).from(users).where(eq(users.id, userFee.userId));
        
        const [category] = await db.select({
          id: feeCategories.id,
          name: feeCategories.name,
          feeType: feeCategories.feeType
        }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
        
        return {
          ...userFee,
          user: user || { firstName: 'Unknown', lastName: 'User' },
          feeCategory: category || { name: 'Unknown Fee' }
        };
      })
    );
    
    res.json(enhancedUserFees);
  } catch (error) {
    console.error('Error fetching user fees:', error);
    res.status(500).json({ message: 'Failed to fetch user fees' });
  }
});

// Get a specific user fee
router.get('/user-fees/:id', async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid user fee ID' });
    }
    
    const [userFee] = await db.select().from(userFees).where(eq(userFees.id, id));
    
    if (!userFee) {
      return res.status(404).json({ message: 'User fee not found' });
    }
    
    // Add user and fee category information
    const [user] = await db.select({
      id: users.id,
      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email
    }).from(users).where(eq(users.id, userFee.userId));
    
    const [category] = await db.select({
      id: feeCategories.id,
      name: feeCategories.name,
      feeType: feeCategories.feeType
    }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
    
    const enhancedUserFee = {
      ...userFee,
      user: user || { firstName: 'Unknown', lastName: 'User' },
      feeCategory: category || { name: 'Unknown Fee' }
    };
    
    res.json(enhancedUserFee);
  } catch (error) {
    console.error('Error fetching user fee:', error);
    res.status(500).json({ message: 'Failed to fetch user fee' });
  }
});

// Create a new user fee
router.post('/user-fees', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const schema = z.object({
      userId: z.number().int().positive('User ID is required'),
      feeCategoryId: z.number().int().positive('Fee category ID is required'),
      amount: z.number().positive('Amount must be positive'),
      discountApplied: z.number().min(0).default(0),
      dueDate: z.string().min(1, 'Due date is required'),
      status: z.enum(['pending', 'paid', 'partially_paid', 'overdue', 'cancelled', 'refunded']).default('pending'),
      notes: z.string().optional().nullable(),
      seasonId: z.number().optional().nullable(),
      teamId: z.number().optional().nullable(),
    });

    const validatedData = schema.parse(req.body);
    
    // Calculate final amount (amount - discount)
    const finalAmount = validatedData.amount - validatedData.discountApplied;
    
    const [newUserFee] = await db.insert(userFees).values({
      userId: validatedData.userId,
      feeCategoryId: validatedData.feeCategoryId,
      amount: validatedData.amount.toString(),
      discountApplied: validatedData.discountApplied.toString(),
      finalAmount: finalAmount.toString(),
      dueDate: new Date(validatedData.dueDate),
      status: validatedData.status,
      notes: validatedData.notes,
      seasonId: validatedData.seasonId,
      teamId: validatedData.teamId,
    }).returning();
    
    res.status(201).json(newUserFee);
  } catch (error) {
    console.error('Error creating user fee:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to create user fee' });
  }
});

// Update a user fee
router.put('/user-fees/:id', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid user fee ID' });
    }
    
    const schema = z.object({
      amount: z.number().positive('Amount must be positive'),
      discountApplied: z.number().min(0).default(0),
      dueDate: z.string().min(1, 'Due date is required'),
      status: z.enum(['pending', 'paid', 'partially_paid', 'overdue', 'cancelled', 'refunded']),
      notes: z.string().optional().nullable(),
      seasonId: z.number().optional().nullable(),
      teamId: z.number().optional().nullable(),
    });

    const validatedData = schema.parse(req.body);
    
    // Calculate final amount (amount - discount)
    const finalAmount = validatedData.amount - validatedData.discountApplied;
    
    const [updatedUserFee] = await db.update(userFees)
      .set({
        amount: validatedData.amount.toString(),
        discountApplied: validatedData.discountApplied.toString(),
        finalAmount: finalAmount.toString(),
        dueDate: new Date(validatedData.dueDate),
        status: validatedData.status,
        notes: validatedData.notes,
        seasonId: validatedData.seasonId,
        teamId: validatedData.teamId,
        updatedAt: new Date(),
      })
      .where(eq(userFees.id, id))
      .returning();
    
    if (!updatedUserFee) {
      return res.status(404).json({ message: 'User fee not found' });
    }
    
    res.json(updatedUserFee);
  } catch (error) {
    console.error('Error updating user fee:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to update user fee' });
  }
});

// Delete a user fee
router.delete('/user-fees/:id', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid user fee ID' });
    }
    
    // Check if the user fee has associated payments
    const [paymentsCount] = await db.select({ count: sql<number>`count(*)` })
      .from(payments)
      .where(eq(payments.userFeeId, id));
    
    if (paymentsCount.count > 0) {
      return res.status(400).json({ 
        message: 'Cannot delete user fee because it has associated payments',
        count: paymentsCount.count
      });
    }
    
    // Check if the user fee has associated payment plans
    const [plansCount] = await db.select({ count: sql<number>`count(*)` })
      .from(paymentPlans)
      .where(eq(paymentPlans.userFeeId, id));
    
    if (plansCount.count > 0) {
      return res.status(400).json({ 
        message: 'Cannot delete user fee because it has associated payment plans',
        count: plansCount.count
      });
    }
    
    const [deletedUserFee] = await db.delete(userFees)
      .where(eq(userFees.id, id))
      .returning();
    
    if (!deletedUserFee) {
      return res.status(404).json({ message: 'User fee not found' });
    }
    
    res.json({ message: 'User fee deleted successfully' });
  } catch (error) {
    console.error('Error deleting user fee:', error);
    res.status(500).json({ message: 'Failed to delete user fee' });
  }
});

// Send payment reminder for a specific user fee
router.post('/user-fees/:id/send-reminder', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid user fee ID' });
    }
    
    // Get the user fee
    const [userFee] = await db.select().from(userFees).where(eq(userFees.id, id));
    
    if (!userFee) {
      return res.status(404).json({ message: 'User fee not found' });
    }
    
    // Get the user
    const [user] = await db.select().from(users).where(eq(users.id, userFee.userId));
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Get the fee category
    const [category] = await db.select().from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
    if (!category) {
      return res.status(404).json({ message: 'Fee category not found' });
    }
    
    // Only send reminder if fee is pending or overdue
    if (!['pending', 'partially_paid', 'overdue'].includes(userFee.status)) {
      return res.status(400).json({ 
        message: 'Cannot send reminder for fees that are paid, cancelled, or refunded' 
      });
    }
    
    // Send the email reminder
    const amount = parseFloat(userFee.finalAmount);
    const dueDate = new Date(userFee.dueDate);
    const feeDescription = category.name;
    
    const emailSent = await sendPaymentReminderEmail(
      user.email,
      user.firstName,
      user.lastName,
      amount,
      dueDate,
      feeDescription
    );
    
    if (!emailSent) {
      return res.status(500).json({ message: 'Failed to send payment reminder email' });
    }
    
    // Update the userFee to track that a reminder was sent
    await db.update(userFees)
      .set({
        lastReminderSent: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(userFees.id, id));
    
    res.json({ 
      message: 'Payment reminder sent successfully',
      email: user.email,
      feeId: userFee.id,
      feeName: category.name,
      amount: userFee.finalAmount,
      dueDate: userFee.dueDate
    });
  } catch (error) {
    console.error('Error sending payment reminder:', error);
    res.status(500).json({ message: 'Failed to send payment reminder', error: (error as Error).message });
  }
});

// Send payment reminders for all overdue fees
router.post('/send-payment-reminders', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    // Find all overdue fees (due date is in the past and status is pending or partially_paid)
    const today = new Date();
    const overdueFees = await db.select().from(userFees)
      .where(
        and(
          sql`${userFees.dueDate} < ${today}`,
          inArray(userFees.status, ['pending', 'partially_paid', 'overdue'])
        )
      );
    
    if (overdueFees.length === 0) {
      return res.json({ message: 'No overdue fees found' });
    }
    
    const results = {
      total: overdueFees.length,
      sent: 0,
      failed: 0,
      details: [] as Array<{userId: number, email: string, success: boolean, error?: string}>
    };
    
    // Send reminder for each overdue fee
    for (const fee of overdueFees) {
      try {
        // Get the user
        const [user] = await db.select().from(users).where(eq(users.id, fee.userId));
        if (!user) {
          results.failed++;
          results.details.push({
            userId: fee.userId,
            email: 'unknown',
            success: false,
            error: 'User not found'
          });
          continue;
        }
        
        // Get the fee category
        const [category] = await db.select().from(feeCategories).where(eq(feeCategories.id, fee.feeCategoryId));
        if (!category) {
          results.failed++;
          results.details.push({
            userId: fee.userId,
            email: user.email,
            success: false,
            error: 'Fee category not found'
          });
          continue;
        }
        
        // Send the reminder
        const amount = parseFloat(fee.finalAmount);
        const dueDate = new Date(fee.dueDate);
        const feeDescription = category.name;
        
        const emailSent = await sendPaymentReminderEmail(
          user.email,
          user.firstName,
          user.lastName,
          amount,
          dueDate,
          feeDescription
        );
        
        if (emailSent) {
          results.sent++;
          results.details.push({
            userId: user.id,
            email: user.email,
            success: true
          });
          
          // Update the userFee to track that a reminder was sent
          await db.update(userFees)
            .set({
              lastReminderSent: new Date(),
              status: 'overdue', // Mark as overdue if it wasn't already
              updatedAt: new Date(),
            })
            .where(eq(userFees.id, fee.id));
        } else {
          results.failed++;
          results.details.push({
            userId: user.id,
            email: user.email,
            success: false,
            error: 'Failed to send email'
          });
        }
      } catch (error) {
        results.failed++;
        results.details.push({
          userId: fee.userId,
          email: 'error',
          success: false,
          error: (error as Error).message
        });
      }
    }
    
    res.json({
      message: `Payment reminders sent: ${results.sent} succeeded, ${results.failed} failed`,
      results
    });
  } catch (error) {
    console.error('Error sending payment reminders:', error);
    res.status(500).json({ message: 'Failed to send payment reminders', error: (error as Error).message });
  }
});

// Get user fees for a specific user
router.get('/users/:userId/fees', async (req: Request, res: Response) => {
  try {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const userFeeList = await db.select().from(userFees).where(eq(userFees.userId, userId));
    
    // Enhance with fee category data
    const enhancedUserFees = await Promise.all(
      userFeeList.map(async (userFee) => {
        const [category] = await db.select({
          id: feeCategories.id,
          name: feeCategories.name,
          feeType: feeCategories.feeType
        }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
        
        return {
          ...userFee,
          feeCategory: category || { name: 'Unknown Fee' }
        };
      })
    );
    
    res.json(enhancedUserFees);
  } catch (error) {
    console.error('Error fetching user fees for user:', error);
    res.status(500).json({ message: 'Failed to fetch user fees' });
  }
});

/**
 * PAYMENTS ROUTES
 */

// Get all payments
router.get('/payments', async (req: Request, res: Response) => {
  try {
    const allPayments = await db.select().from(payments).orderBy(desc(payments.paymentDate));
    
    // Enhance with user data
    const enhancedPayments = await Promise.all(
      allPayments.map(async (payment) => {
        const [user] = await db.select({
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email
        }).from(users).where(eq(users.id, payment.userId));
        
        // If there's a user fee ID, get the fee category info
        let userFeeInfo = null;
        if (payment.userFeeId) {
          const [userFee] = await db.select().from(userFees).where(eq(userFees.id, payment.userFeeId));
          if (userFee) {
            const [category] = await db.select({
              id: feeCategories.id,
              name: feeCategories.name,
              feeType: feeCategories.feeType
            }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
            
            userFeeInfo = {
              ...userFee,
              feeCategory: category || { name: 'Unknown Fee' }
            };
          }
        }
        
        return {
          ...payment,
          user: user || { firstName: 'Unknown', lastName: 'User' },
          userFee: userFeeInfo
        };
      })
    );
    
    res.json(enhancedPayments);
  } catch (error) {
    console.error('Error fetching payments:', error);
    res.status(500).json({ message: 'Failed to fetch payments' });
  }
});

// Get a specific payment
router.get('/payments/:id', async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid payment ID' });
    }
    
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    
    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }
    
    // Add user and fee information
    const [user] = await db.select({
      id: users.id,
      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email
    }).from(users).where(eq(users.id, payment.userId));
    
    // If there's a user fee ID, get the fee category info
    let userFeeInfo = null;
    if (payment.userFeeId) {
      const [userFee] = await db.select().from(userFees).where(eq(userFees.id, payment.userFeeId));
      if (userFee) {
        const [category] = await db.select({
          id: feeCategories.id,
          name: feeCategories.name,
          feeType: feeCategories.feeType
        }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
        
        userFeeInfo = {
          ...userFee,
          feeCategory: category || { name: 'Unknown Fee' }
        };
      }
    }
    
    const enhancedPayment = {
      ...payment,
      user: user || { firstName: 'Unknown', lastName: 'User' },
      userFee: userFeeInfo
    };
    
    res.json(enhancedPayment);
  } catch (error) {
    console.error('Error fetching payment:', error);
    res.status(500).json({ message: 'Failed to fetch payment' });
  }
});

// Create a new payment
router.post('/payments', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const schema = z.object({
      userId: z.number().int().positive('User ID is required'),
      userFeeId: z.number().int().optional().nullable(),
      amount: z.number().positive('Amount must be positive'),
      paymentDate: z.string().min(1, 'Payment date is required'),
      paymentMethod: z.enum(['cash', 'bank_transfer', 'credit_card', 'debit_card', 'check', 'online', 'other']),
      reference: z.string().optional().nullable(),
      notes: z.string().optional().nullable(),
      receivedBy: z.number().int().optional().nullable(),
      attachments: z.array(z.string()).optional().nullable(),
    });

    const validatedData = schema.parse(req.body);
    
    // Set receivedBy to the current user if not provided
    if (!validatedData.receivedBy && req.user) {
      validatedData.receivedBy = req.user.id;
    }
    
    const [newPayment] = await db.insert(payments).values({
      userId: validatedData.userId,
      userFeeId: validatedData.userFeeId,
      amount: validatedData.amount.toString(),
      paymentDate: new Date(validatedData.paymentDate),
      paymentMethod: validatedData.paymentMethod,
      reference: validatedData.reference,
      notes: validatedData.notes,
      receivedBy: validatedData.receivedBy,
      attachments: validatedData.attachments,
    }).returning();
    
    // If this payment is for a user fee, update the user fee status
    if (validatedData.userFeeId) {
      const [userFee] = await db.select().from(userFees).where(eq(userFees.id, validatedData.userFeeId));
      
      if (userFee) {
        // Get all payments for this user fee
        const userFeePayments = await db.select().from(payments).where(eq(payments.userFeeId, userFee.id));
        
        // Calculate total paid amount
        const totalPaid = userFeePayments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
        const finalAmount = parseFloat(userFee.finalAmount);
        
        // Determine the new status based on the total paid amount
        let newStatus = userFee.status;
        if (totalPaid >= finalAmount) {
          newStatus = 'paid';
        } else if (totalPaid > 0) {
          newStatus = 'partially_paid';
        }
        
        // Update the user fee status
        await db.update(userFees)
          .set({
            status: newStatus,
            updatedAt: new Date(),
          })
          .where(eq(userFees.id, userFee.id));
      }
    }
    
    res.status(201).json(newPayment);
  } catch (error) {
    console.error('Error creating payment:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to create payment' });
  }
});

// Update a payment
router.put('/payments/:id', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid payment ID' });
    }
    
    const schema = z.object({
      amount: z.number().positive('Amount must be positive'),
      paymentDate: z.string().min(1, 'Payment date is required'),
      paymentMethod: z.enum(['cash', 'bank_transfer', 'credit_card', 'debit_card', 'check', 'online', 'other']),
      reference: z.string().optional().nullable(),
      notes: z.string().optional().nullable(),
      attachments: z.array(z.string()).optional().nullable(),
    });

    const validatedData = schema.parse(req.body);
    
    const [updatedPayment] = await db.update(payments)
      .set({
        amount: validatedData.amount.toString(),
        paymentDate: new Date(validatedData.paymentDate),
        paymentMethod: validatedData.paymentMethod,
        reference: validatedData.reference,
        notes: validatedData.notes,
        attachments: validatedData.attachments,
      })
      .where(eq(payments.id, id))
      .returning();
    
    if (!updatedPayment) {
      return res.status(404).json({ message: 'Payment not found' });
    }
    
    // If this payment is for a user fee, update the user fee status
    if (updatedPayment.userFeeId) {
      const [userFee] = await db.select().from(userFees).where(eq(userFees.id, updatedPayment.userFeeId));
      
      if (userFee) {
        // Get all payments for this user fee
        const userFeePayments = await db.select().from(payments).where(eq(payments.userFeeId, userFee.id));
        
        // Calculate total paid amount
        const totalPaid = userFeePayments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
        const finalAmount = parseFloat(userFee.finalAmount);
        
        // Determine the new status based on the total paid amount
        let newStatus = userFee.status;
        if (totalPaid >= finalAmount) {
          newStatus = 'paid';
        } else if (totalPaid > 0) {
          newStatus = 'partially_paid';
        } else {
          newStatus = 'pending';
        }
        
        // Update the user fee status
        await db.update(userFees)
          .set({
            status: newStatus,
            updatedAt: new Date(),
          })
          .where(eq(userFees.id, userFee.id));
      }
    }
    
    res.json(updatedPayment);
  } catch (error) {
    console.error('Error updating payment:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to update payment' });
  }
});

// Delete a payment
router.delete('/payments/:id', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid payment ID' });
    }
    
    // First retrieve the payment to capture the userFeeId if present
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    
    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }
    
    // Check if the payment is used in payment plan installments
    const [installmentsCount] = await db.select({ count: sql<number>`count(*)` })
      .from(paymentPlanInstallments)
      .where(eq(paymentPlanInstallments.paymentId, id));
    
    if (installmentsCount.count > 0) {
      return res.status(400).json({ 
        message: 'Cannot delete payment because it is linked to payment plan installments',
        count: installmentsCount.count
      });
    }
    
    // Delete the payment
    const [deletedPayment] = await db.delete(payments)
      .where(eq(payments.id, id))
      .returning();
    
    // If this payment was for a user fee, update the user fee status
    if (payment.userFeeId) {
      const [userFee] = await db.select().from(userFees).where(eq(userFees.id, payment.userFeeId));
      
      if (userFee) {
        // Get all remaining payments for this user fee
        const userFeePayments = await db.select().from(payments).where(eq(payments.userFeeId, userFee.id));
        
        // Calculate total paid amount
        const totalPaid = userFeePayments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
        const finalAmount = parseFloat(userFee.finalAmount);
        
        // Determine the new status based on the total paid amount
        let newStatus = userFee.status;
        if (totalPaid >= finalAmount) {
          newStatus = 'paid';
        } else if (totalPaid > 0) {
          newStatus = 'partially_paid';
        } else {
          newStatus = 'pending';
        }
        
        // Update the user fee status
        await db.update(userFees)
          .set({
            status: newStatus,
            updatedAt: new Date(),
          })
          .where(eq(userFees.id, userFee.id));
      }
    }
    
    res.json({ message: 'Payment deleted successfully' });
  } catch (error) {
    console.error('Error deleting payment:', error);
    res.status(500).json({ message: 'Failed to delete payment' });
  }
});

// Get payments for a specific user
router.get('/users/:userId/payments', async (req: Request, res: Response) => {
  try {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const userPayments = await db.select().from(payments)
      .where(eq(payments.userId, userId))
      .orderBy(desc(payments.paymentDate));
    
    // Enhance with fee information if applicable
    const enhancedPayments = await Promise.all(
      userPayments.map(async (payment) => {
        let userFeeInfo = null;
        if (payment.userFeeId) {
          const [userFee] = await db.select().from(userFees).where(eq(userFees.id, payment.userFeeId));
          if (userFee) {
            const [category] = await db.select({
              id: feeCategories.id,
              name: feeCategories.name,
              feeType: feeCategories.feeType
            }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
            
            userFeeInfo = {
              ...userFee,
              feeCategory: category || { name: 'Unknown Fee' }
            };
          }
        }
        
        return {
          ...payment,
          userFee: userFeeInfo
        };
      })
    );
    
    res.json(enhancedPayments);
  } catch (error) {
    console.error('Error fetching payments for user:', error);
    res.status(500).json({ message: 'Failed to fetch payments' });
  }
});

/**
 * PAYMENT PLANS ROUTES
 */

// Get all payment plans
router.get('/payment-plans', async (req: Request, res: Response) => {
  try {
    const allPaymentPlans = await db.select().from(paymentPlans).orderBy(desc(paymentPlans.createdAt));
    
    // Enhance with user data and installments
    const enhancedPaymentPlans = await Promise.all(
      allPaymentPlans.map(async (plan) => {
        const [user] = await db.select({
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email
        }).from(users).where(eq(users.id, plan.userId));
        
        // Get user fee information if applicable
        let userFeeInfo = null;
        if (plan.userFeeId) {
          const [userFee] = await db.select().from(userFees).where(eq(userFees.id, plan.userFeeId));
          if (userFee) {
            const [category] = await db.select({
              id: feeCategories.id,
              name: feeCategories.name,
              feeType: feeCategories.feeType
            }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
            
            userFeeInfo = {
              ...userFee,
              feeCategory: category || { name: 'Unknown Fee' }
            };
          }
        }
        
        // Get installments
        const installments = await db.select().from(paymentPlanInstallments)
          .where(eq(paymentPlanInstallments.paymentPlanId, plan.id))
          .orderBy(paymentPlanInstallments.installmentNumber);
        
        // Enhance installments with payment data if available
        const enhancedInstallments = await Promise.all(
          installments.map(async (installment) => {
            if (installment.paymentId) {
              const [payment] = await db.select().from(payments).where(eq(payments.id, installment.paymentId));
              return {
                ...installment,
                payment: payment || null
              };
            }
            return installment;
          })
        );
        
        return {
          ...plan,
          user: user || { firstName: 'Unknown', lastName: 'User' },
          userFee: userFeeInfo,
          installments: enhancedInstallments
        };
      })
    );
    
    res.json(enhancedPaymentPlans);
  } catch (error) {
    console.error('Error fetching payment plans:', error);
    res.status(500).json({ message: 'Failed to fetch payment plans' });
  }
});

// Get a specific payment plan
router.get('/payment-plans/:id', async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid payment plan ID' });
    }
    
    const [plan] = await db.select().from(paymentPlans).where(eq(paymentPlans.id, id));
    
    if (!plan) {
      return res.status(404).json({ message: 'Payment plan not found' });
    }
    
    // Add user information
    const [user] = await db.select({
      id: users.id,
      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email
    }).from(users).where(eq(users.id, plan.userId));
    
    // Get user fee information if applicable
    let userFeeInfo = null;
    if (plan.userFeeId) {
      const [userFee] = await db.select().from(userFees).where(eq(userFees.id, plan.userFeeId));
      if (userFee) {
        const [category] = await db.select({
          id: feeCategories.id,
          name: feeCategories.name,
          feeType: feeCategories.feeType
        }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
        
        userFeeInfo = {
          ...userFee,
          feeCategory: category || { name: 'Unknown Fee' }
        };
      }
    }
    
    // Get installments
    const installments = await db.select().from(paymentPlanInstallments)
      .where(eq(paymentPlanInstallments.paymentPlanId, plan.id))
      .orderBy(paymentPlanInstallments.installmentNumber);
    
    // Enhance installments with payment data if available
    const enhancedInstallments = await Promise.all(
      installments.map(async (installment) => {
        if (installment.paymentId) {
          const [payment] = await db.select().from(payments).where(eq(payments.id, installment.paymentId));
          return {
            ...installment,
            payment: payment || null
          };
        }
        return installment;
      })
    );
    
    const enhancedPlan = {
      ...plan,
      user: user || { firstName: 'Unknown', lastName: 'User' },
      userFee: userFeeInfo,
      installments: enhancedInstallments
    };
    
    res.json(enhancedPlan);
  } catch (error) {
    console.error('Error fetching payment plan:', error);
    res.status(500).json({ message: 'Failed to fetch payment plan' });
  }
});

// Create a new payment plan
router.post('/payment-plans', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const schema = z.object({
      userId: z.number().int().positive('User ID is required'),
      userFeeId: z.number().int().optional().nullable(),
      name: z.string().min(1, 'Name is required'),
      description: z.string().optional().nullable(),
      totalAmount: z.number().positive('Total amount must be positive'),
      numberOfInstallments: z.number().int().positive('Number of installments must be a positive integer'),
      startDate: z.string().min(1, 'Start date is required'),
      frequency: z.string().min(1, 'Frequency is required'),
      notes: z.string().optional().nullable(),
    });

    const validatedData = schema.parse(req.body);
    
    // Calculate installment amount and end date
    const installmentAmount = validatedData.totalAmount / validatedData.numberOfInstallments;
    const startDate = new Date(validatedData.startDate);
    let endDate = new Date(startDate);
    
    // Set end date based on frequency and number of installments
    if (validatedData.frequency === 'monthly') {
      endDate.setMonth(startDate.getMonth() + validatedData.numberOfInstallments - 1);
    } else if (validatedData.frequency === 'weekly') {
      endDate.setDate(startDate.getDate() + (validatedData.numberOfInstallments - 1) * 7);
    } else if (validatedData.frequency === 'quarterly') {
      endDate.setMonth(startDate.getMonth() + (validatedData.numberOfInstallments - 1) * 3);
    } else {
      // Default to monthly if frequency is not recognized
      endDate.setMonth(startDate.getMonth() + validatedData.numberOfInstallments - 1);
    }
    
    // Insert new payment plan
    const [newPlan] = await db.insert(paymentPlans).values({
      userId: validatedData.userId,
      userFeeId: validatedData.userFeeId,
      name: validatedData.name,
      description: validatedData.description,
      totalAmount: validatedData.totalAmount.toString(),
      numberOfInstallments: validatedData.numberOfInstallments,
      installmentAmount: installmentAmount.toString(),
      startDate: startDate,
      endDate: endDate,
      frequency: validatedData.frequency,
      status: 'active',
      notes: validatedData.notes,
    }).returning();
    
    // Create installments
    for (let i = 0; i < validatedData.numberOfInstallments; i++) {
      let dueDate = new Date(startDate);
      
      if (validatedData.frequency === 'monthly') {
        dueDate.setMonth(startDate.getMonth() + i);
      } else if (validatedData.frequency === 'weekly') {
        dueDate.setDate(startDate.getDate() + i * 7);
      } else if (validatedData.frequency === 'quarterly') {
        dueDate.setMonth(startDate.getMonth() + i * 3);
      }
      
      await db.insert(paymentPlanInstallments).values({
        paymentPlanId: newPlan.id,
        installmentNumber: i + 1,
        amount: installmentAmount.toString(),
        dueDate: dueDate,
        status: 'pending',
        notes: `Installment ${i + 1} of ${validatedData.numberOfInstallments}`,
      });
    }
    
    // Update user fee status if applicable
    if (validatedData.userFeeId) {
      await db.update(userFees)
        .set({
          status: 'partially_paid',
          updatedAt: new Date(),
        })
        .where(eq(userFees.id, validatedData.userFeeId));
    }
    
    // Get a complete plan with installments to return
    const installments = await db.select().from(paymentPlanInstallments)
      .where(eq(paymentPlanInstallments.paymentPlanId, newPlan.id))
      .orderBy(paymentPlanInstallments.installmentNumber);
    
    const completePlan = {
      ...newPlan,
      installments
    };
    
    res.status(201).json(completePlan);
  } catch (error) {
    console.error('Error creating payment plan:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to create payment plan' });
  }
});

// Update a payment plan
router.put('/payment-plans/:id', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid payment plan ID' });
    }
    
    const schema = z.object({
      name: z.string().min(1, 'Name is required'),
      description: z.string().optional().nullable(),
      status: z.string().min(1, 'Status is required'),
      notes: z.string().optional().nullable(),
    });

    const validatedData = schema.parse(req.body);
    
    const [updatedPlan] = await db.update(paymentPlans)
      .set({
        name: validatedData.name,
        description: validatedData.description,
        status: validatedData.status,
        notes: validatedData.notes,
      })
      .where(eq(paymentPlans.id, id))
      .returning();
    
    if (!updatedPlan) {
      return res.status(404).json({ message: 'Payment plan not found' });
    }
    
    res.json(updatedPlan);
  } catch (error) {
    console.error('Error updating payment plan:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to update payment plan' });
  }
});

// Record a payment for an installment
router.post('/payment-plans/:planId/installments/:installmentId/pay', checkPaymentPermissions, async (req: Request, res: Response) => {
  try {
    const planId = parseInt(req.params.planId);
    const installmentId = parseInt(req.params.installmentId);
    
    if (isNaN(planId) || isNaN(installmentId)) {
      return res.status(400).json({ message: 'Invalid payment plan or installment ID' });
    }
    
    // Get the plan and installment
    const [plan] = await db.select().from(paymentPlans).where(eq(paymentPlans.id, planId));
    const [installment] = await db.select().from(paymentPlanInstallments)
      .where(and(
        eq(paymentPlanInstallments.id, installmentId),
        eq(paymentPlanInstallments.paymentPlanId, planId)
      ));
    
    if (!plan || !installment) {
      return res.status(404).json({ message: 'Payment plan or installment not found' });
    }
    
    // Check if the installment is already paid
    if (installment.status === 'paid' && installment.paymentId) {
      return res.status(400).json({ message: 'This installment is already paid' });
    }
    
    const schema = z.object({
      paymentMethod: z.enum(['cash', 'bank_transfer', 'credit_card', 'debit_card', 'check', 'online', 'other']),
      paymentDate: z.string().min(1, 'Payment date is required'),
      reference: z.string().optional().nullable(),
      notes: z.string().optional().nullable(),
      attachments: z.array(z.string()).optional().nullable(),
    });

    const validatedData = schema.parse(req.body);
    
    // Create a payment record
    const [payment] = await db.insert(payments).values({
      userId: plan.userId,
      userFeeId: plan.userFeeId,
      amount: installment.amount,
      paymentDate: new Date(validatedData.paymentDate),
      paymentMethod: validatedData.paymentMethod,
      reference: validatedData.reference,
      notes: `Payment for installment ${installment.installmentNumber} of plan ${plan.name}. ${validatedData.notes || ''}`.trim(),
      receivedBy: req.user?.id || null,
      attachments: validatedData.attachments,
    }).returning();
    
    // Update the installment status and link to the payment
    const [updatedInstallment] = await db.update(paymentPlanInstallments)
      .set({
        status: 'paid',
        paymentId: payment.id,
        notes: installment.notes 
          ? `${installment.notes} - Paid on ${new Date(validatedData.paymentDate).toLocaleDateString()}`
          : `Paid on ${new Date(validatedData.paymentDate).toLocaleDateString()}`
      })
      .where(eq(paymentPlanInstallments.id, installmentId))
      .returning();
    
    // Check if all installments are paid
    const allInstallments = await db.select().from(paymentPlanInstallments)
      .where(eq(paymentPlanInstallments.paymentPlanId, planId));
    
    const allPaid = allInstallments.every(inst => inst.status === 'paid');
    
    if (allPaid) {
      // Update the plan status to completed
      await db.update(paymentPlans)
        .set({
          status: 'completed',
        })
        .where(eq(paymentPlans.id, planId));
      
      // If this plan is for a user fee, update the user fee status to paid
      if (plan.userFeeId) {
        await db.update(userFees)
          .set({
            status: 'paid',
            updatedAt: new Date(),
          })
          .where(eq(userFees.id, plan.userFeeId));
      }
    } else {
      // Update user fee to partially paid if applicable
      if (plan.userFeeId) {
        await db.update(userFees)
          .set({
            status: 'partially_paid',
            updatedAt: new Date(),
          })
          .where(eq(userFees.id, plan.userFeeId));
      }
    }
    
    res.json({
      message: 'Payment recorded successfully',
      payment,
      installment: updatedInstallment
    });
  } catch (error) {
    console.error('Error recording payment for installment:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Failed to record payment' });
  }
});

// Get payment plans for a specific user
router.get('/users/:userId/payment-plans', async (req: Request, res: Response) => {
  try {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const userPaymentPlans = await db.select().from(paymentPlans)
      .where(eq(paymentPlans.userId, userId))
      .orderBy(desc(paymentPlans.createdAt));
    
    // Enhance with installments and fee information
    const enhancedPlans = await Promise.all(
      userPaymentPlans.map(async (plan) => {
        // Get user fee information if applicable
        let userFeeInfo = null;
        if (plan.userFeeId) {
          const [userFee] = await db.select().from(userFees).where(eq(userFees.id, plan.userFeeId));
          if (userFee) {
            const [category] = await db.select({
              id: feeCategories.id,
              name: feeCategories.name,
              feeType: feeCategories.feeType
            }).from(feeCategories).where(eq(feeCategories.id, userFee.feeCategoryId));
            
            userFeeInfo = {
              ...userFee,
              feeCategory: category || { name: 'Unknown Fee' }
            };
          }
        }
        
        // Get installments
        const installments = await db.select().from(paymentPlanInstallments)
          .where(eq(paymentPlanInstallments.paymentPlanId, plan.id))
          .orderBy(paymentPlanInstallments.installmentNumber);
        
        return {
          ...plan,
          userFee: userFeeInfo,
          installments
        };
      })
    );
    
    res.json(enhancedPlans);
  } catch (error) {
    console.error('Error fetching payment plans for user:', error);
    res.status(500).json({ message: 'Failed to fetch payment plans' });
  }
});

export default router;