import { Router } from "express";
import { z } from "zod";
import { db } from "../db";
import { playerVideoAnalysisTable, videosTable, usersTable } from "../../shared/schema";
import { authenticateUser } from "../auth";
import { eq, and, desc } from "drizzle-orm";

const router = Router();

const createAnalysisSchema = z.object({
  videoId: z.string(),
  playerId: z.string(),
  analysisType: z.enum(['technical_skills', 'tactical_positioning', 'physical_performance', 'decision_making', 'overall_performance']),
  startTime: z.number().optional(),
  endTime: z.number().optional(),
  notes: z.string().optional(),
  rating: z.number().min(1).max(10),
  // Pass Statistics
  passesAttempted: z.number().default(0),
  passesCompleted: z.number().default(0),
  passSuccessRate: z.number().default(0),
  // Dribbling Statistics
  dribblesAttempted: z.number().default(0),
  dribblesSuccessful: z.number().default(0),
  dribbleSuccessRate: z.number().default(0),
  // Shooting Statistics
  shotsTotal: z.number().default(0),
  shotsOnTarget: z.number().default(0),
  shotsOffTarget: z.number().default(0),
  shotAccuracy: z.number().default(0),
  // Defensive Statistics
  defensiveDuelsTotal: z.number().default(0),
  defensiveDuelsWon: z.number().default(0),
  defensiveDuelSuccessRate: z.number().default(0),
  // 1v1 Situations
  oneVOneTotal: z.number().default(0),
  oneVOneWon: z.number().default(0),
  oneVOneSuccessRate: z.number().default(0),
  // Additional Metrics
  touches: z.number().default(0),
  ballRecoveries: z.number().default(0),
  interceptions: z.number().default(0),
  tackles: z.number().default(0),
  tackleSuccessRate: z.number().default(0),
  strengths: z.array(z.string()),
  improvements: z.array(z.string()),
  keyMoments: z.array(z.object({
    time: z.number(),
    description: z.string()
  }))
});

// Create player analysis
router.post("/", authenticateUser, async (req, res) => {
  try {
    const data = createAnalysisSchema.parse(req.body);
    
    const analysis = await db.insert(playerVideoAnalysisTable).values({
      videoId: parseInt(data.videoId),
      playerId: parseInt(data.playerId),
      analysisType: data.analysisType,
      startTime: data.startTime,
      endTime: data.endTime,
      notes: data.notes || '',
      rating: data.rating,
      // Pass Statistics
      passesAttempted: data.passesAttempted,
      passesCompleted: data.passesCompleted,
      passSuccessRate: data.passSuccessRate.toString(),
      // Dribbling Statistics
      dribblesAttempted: data.dribblesAttempted,
      dribblesSuccessful: data.dribblesSuccessful,
      dribbleSuccessRate: data.dribbleSuccessRate.toString(),
      // Shooting Statistics
      shotsTotal: data.shotsTotal,
      shotsOnTarget: data.shotsOnTarget,
      shotsOffTarget: data.shotsOffTarget,
      shotAccuracy: data.shotAccuracy.toString(),
      // Defensive Statistics
      defensiveDuelsTotal: data.defensiveDuelsTotal,
      defensiveDuelsWon: data.defensiveDuelsWon,
      defensiveDuelSuccessRate: data.defensiveDuelSuccessRate.toString(),
      // 1v1 Situations
      oneVOneTotal: data.oneVOneTotal,
      oneVOneWon: data.oneVOneWon,
      oneVOneSuccessRate: data.oneVOneSuccessRate.toString(),
      // Additional Metrics
      touches: data.touches,
      ballRecoveries: data.ballRecoveries,
      interceptions: data.interceptions,
      tackles: data.tackles,
      tackleSuccessRate: data.tackleSuccessRate.toString(),
      strengths: data.strengths,
      improvements: data.improvements,
      keyMoments: data.keyMoments,
      analysedBy: req.user!.id,
    }).returning();

    res.json({ analysis: analysis[0] });
  } catch (error) {
    console.error("Create analysis error:", error);
    res.status(400).json({ error: "Failed to create analysis" });
  }
});

// Get all analyses for a video
router.get("/video/:videoId", authenticateUser, async (req, res) => {
  try {
    const videoId = parseInt(req.params.videoId);
    
    const analyses = await db
      .select({
        analysis: playerVideoAnalysisTable,
        player: {
          id: usersTable.id,
          firstName: usersTable.firstName,
          lastName: usersTable.lastName,
          jerseyNumber: usersTable.jerseyNumber,
        },
        analysedBy: {
          id: usersTable.id,
          firstName: usersTable.firstName,
          lastName: usersTable.lastName,
        }
      })
      .from(playerVideoAnalysisTable)
      .leftJoin(usersTable, eq(playerVideoAnalysisTable.playerId, usersTable.id))
      .where(eq(playerVideoAnalysisTable.videoId, videoId))
      .orderBy(desc(playerVideoAnalysisTable.createdAt));

    res.json(analyses);
  } catch (error) {
    console.error("Get video analyses error:", error);
    res.status(500).json({ error: "Failed to get analyses" });
  }
});

// Get all analyses for a player
router.get("/player/:playerId", authenticateUser, async (req, res) => {
  try {
    const playerId = parseInt(req.params.playerId);
    
    const analyses = await db
      .select({
        analysis: playerVideoAnalysisTable,
        video: {
          id: videosTable.id,
          title: videosTable.title,
          season: videosTable.season,
          opponent: videosTable.opponent,
        },
        analysedBy: {
          id: usersTable.id,
          firstName: usersTable.firstName,
          lastName: usersTable.lastName,
        }
      })
      .from(playerVideoAnalysisTable)
      .leftJoin(videosTable, eq(playerVideoAnalysisTable.videoId, videosTable.id))
      .leftJoin(usersTable, eq(playerVideoAnalysisTable.analysedBy, usersTable.id))
      .where(eq(playerVideoAnalysisTable.playerId, playerId))
      .orderBy(desc(playerVideoAnalysisTable.createdAt));

    res.json(analyses);
  } catch (error) {
    console.error("Get player analyses error:", error);
    res.status(500).json({ error: "Failed to get analyses" });
  }
});

// Get specific analysis
router.get("/:id", authenticateUser, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    const analysis = await db
      .select({
        analysis: playerVideoAnalysisTable,
        player: {
          id: usersTable.id,
          firstName: usersTable.firstName,
          lastName: usersTable.lastName,
          jerseyNumber: usersTable.jerseyNumber,
        },
        video: {
          id: videosTable.id,
          title: videosTable.title,
          season: videosTable.season,
          opponent: videosTable.opponent,
        }
      })
      .from(playerVideoAnalysisTable)
      .leftJoin(usersTable, eq(playerVideoAnalysisTable.playerId, usersTable.id))
      .leftJoin(videosTable, eq(playerVideoAnalysisTable.videoId, videosTable.id))
      .where(eq(playerVideoAnalysisTable.id, id))
      .limit(1);

    if (analysis.length === 0) {
      return res.status(404).json({ error: "Analysis not found" });
    }

    res.json(analysis[0]);
  } catch (error) {
    console.error("Get analysis error:", error);
    res.status(500).json({ error: "Failed to get analysis" });
  }
});

// Update analysis
router.put("/:id", authenticateUser, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const data = createAnalysisSchema.partial().parse(req.body);
    
    const updatedAnalysis = await db
      .update(playerVideoAnalysisTable)
      .set({
        ...data,
        videoId: data.videoId ? parseInt(data.videoId) : undefined,
        playerId: data.playerId ? parseInt(data.playerId) : undefined,
        updatedAt: new Date(),
      })
      .where(eq(playerVideoAnalysisTable.id, id))
      .returning();

    if (updatedAnalysis.length === 0) {
      return res.status(404).json({ error: "Analysis not found" });
    }

    res.json({ analysis: updatedAnalysis[0] });
  } catch (error) {
    console.error("Update analysis error:", error);
    res.status(400).json({ error: "Failed to update analysis" });
  }
});

// Delete analysis
router.delete("/:id", authenticateUser, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    const deletedAnalysis = await db
      .delete(playerVideoAnalysisTable)
      .where(eq(playerVideoAnalysisTable.id, id))
      .returning();

    if (deletedAnalysis.length === 0) {
      return res.status(404).json({ error: "Analysis not found" });
    }

    res.json({ message: "Analysis deleted successfully" });
  } catch (error) {
    console.error("Delete analysis error:", error);
    res.status(500).json({ error: "Failed to delete analysis" });
  }
});

export default router;