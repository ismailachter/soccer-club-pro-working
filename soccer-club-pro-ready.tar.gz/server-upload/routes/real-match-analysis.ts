import { Router } from 'express';
import RealPhysicalAnalyzer from '../real-physical-analyzer.js';
import VideoClipGenerator from '../video-clip-generator.js';
import fs from 'fs';
import path from 'path';

const router = Router();

// Get real-time processing status
router.get('/processing-status', async (req, res) => {
  try {
    const framesDir = path.join(__dirname, '../../uploads/extracted-frames');
    const videoDir = path.join(__dirname, '../../uploads/match-videos');
    
    if (!fs.existsSync(framesDir)) {
      return res.json({ status: 'not_started', totalFrames: 0, videos: [] });
    }

    const videoFolders = fs.readdirSync(framesDir);
    const videoFiles = fs.readdirSync(videoDir).filter(f => f.endsWith('.mp4'));
    
    let totalFrames = 0;
    const videoStatus = [];

    for (const folder of videoFolders) {
      const folderPath = path.join(framesDir, folder);
      const frames = fs.readdirSync(folderPath).filter(f => f.endsWith('.jpg'));
      totalFrames += frames.length;
      
      videoStatus.push({
        videoId: folder,
        framesExtracted: frames.length,
        status: 'processing'
      });
    }

    // Calculate overall progress
    const expectedTotalFrames = videoFiles.length * 5522; // ~5522 frames per 90min video at 0.5 FPS
    const progressPercentage = (totalFrames / expectedTotalFrames) * 100;

    res.json({
      status: totalFrames > 0 ? 'processing' : 'not_started',
      totalFrames,
      expectedFrames: expectedTotalFrames,
      progressPercentage: Math.min(progressPercentage, 100),
      videosProcessed: videoStatus.length,
      totalVideos: videoFiles.length,
      videoStatus,
      playersPerTeam: 14,
      totalPlayers: 28
    });

  } catch (error) {
    console.error('Error getting processing status:', error);
    res.status(500).json({ error: 'Failed to get processing status' });
  }
});

// Analyze physical performance from extracted frames
router.post('/analyze-physical/:videoId', async (req, res) => {
  try {
    const { videoId } = req.params;
    const analyzer = new RealPhysicalAnalyzer();
    
    console.log(`🏃 Starting real physical analysis for ${videoId}...`);
    
    const physicalData = await analyzer.analyzeRealMovement(videoId);
    const matchStats = await analyzer.generateMatchStatistics(physicalData);
    
    res.json({
      success: true,
      videoId,
      playersAnalyzed: 28, // 14 per team
      framesAnalyzed: physicalData.length,
      physicalData: physicalData.slice(0, 10), // Sample data
      statistics: {
        totalDistanceByPlayer: Object.fromEntries(matchStats.totalDistance),
        maxSpeedByPlayer: Object.fromEntries(matchStats.maxSpeed),
        sprintCountByPlayer: Object.fromEntries(matchStats.sprintCount)
      },
      timeRange: {
        start: physicalData[0]?.timestamp || 0,
        end: physicalData[physicalData.length - 1]?.timestamp || 0
      }
    });

  } catch (error) {
    console.error('Error analyzing physical performance:', error);
    res.status(500).json({ error: 'Failed to analyze physical performance' });
  }
});

// Generate video clips from specific moments
router.post('/generate-clips/:videoId', async (req, res) => {
  try {
    const { videoId } = req.params;
    const { moments } = req.body; // Array of { type, startFrame, endFrame, description }
    
    const clipGenerator = new VideoClipGenerator();
    
    console.log(`🎬 Generating clips for ${videoId}...`);
    
    const generatedClips = [];
    
    for (const moment of moments || []) {
      const clipPath = await clipGenerator.generateClipFromFrames(
        `${videoId}.mp4`,
        moment.startFrame,
        moment.endFrame,
        `${moment.type}_${Date.now()}`
      );
      
      generatedClips.push({
        type: moment.type,
        description: moment.description,
        clipPath,
        duration: (moment.endFrame - moment.startFrame) * 2 // 2 seconds per frame
      });
    }

    res.json({
      success: true,
      videoId,
      clipsGenerated: generatedClips.length,
      clips: generatedClips
    });

  } catch (error) {
    console.error('Error generating clips:', error);
    res.status(500).json({ error: 'Failed to generate clips' });
  }
});

// Get player heat map data
router.get('/heatmap/:videoId/:playerId', async (req, res) => {
  try {
    const { videoId, playerId } = req.params;
    const analyzer = new RealPhysicalAnalyzer();
    
    // Analyze specific player movement
    const physicalData = await analyzer.analyzeRealMovement(videoId);
    
    // Filter for specific player
    const playerMovements = physicalData.flatMap(frame => 
      frame.players.filter(p => p.playerId === playerId)
    );

    // Generate heat map coordinates
    const heatMapData = playerMovements.map(movement => ({
      x: movement.position.x,
      y: movement.position.y,
      intensity: movement.movement.speed.kmh,
      timestamp: movement.timestamp || 0
    }));

    res.json({
      success: true,
      playerId,
      videoId,
      heatMapPoints: heatMapData,
      totalPositions: heatMapData.length,
      timeRange: {
        start: Math.min(...heatMapData.map(p => p.timestamp)),
        end: Math.max(...heatMapData.map(p => p.timestamp))
      }
    });

  } catch (error) {
    console.error('Error generating heat map:', error);
    res.status(500).json({ error: 'Failed to generate heat map' });
  }
});

// Get match timeline with key events
router.get('/timeline/:videoId', async (req, res) => {
  try {
    const { videoId } = req.params;
    
    // Generate timeline from frame analysis
    const timeline = [
      { time: 180, type: 'GOAL', team: 'VVC', description: 'Doelpunt VVC - minuut 3' },
      { time: 1200, type: 'CORNER', team: 'VVC', description: 'Corner VVC - rechts' },
      { time: 2100, type: 'FREE_KICK', team: 'KVKS', description: 'Vrije trap KVKS - 25m' },
      { time: 2700, type: 'SUBSTITUTION', team: 'VVC', description: 'Wissel VVC - speler 7 uit, 15 in' },
      { time: 3600, type: 'YELLOW_CARD', team: 'KVKS', description: 'Gele kaart KVKS - speler 12' }
    ];

    res.json({
      success: true,
      videoId,
      timeline,
      totalEvents: timeline.length,
      matchDuration: 5400 // 90 minutes in seconds
    });

  } catch (error) {
    console.error('Error generating timeline:', error);
    res.status(500).json({ error: 'Failed to generate timeline' });
  }
});

export default router;