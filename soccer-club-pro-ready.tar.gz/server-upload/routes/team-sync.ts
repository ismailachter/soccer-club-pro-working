import { Router } from "express";
import { db } from "../db";
import { players, users, teams } from "@shared/schema";
import { eq } from "drizzle-orm";

const router = Router();

// Sync team rosters with Players Database
router.post('/sync-rosters', async (req, res) => {
  try {
    console.log('Starting team roster synchronization...');
    
    // Get all players with their current team assignments
    const allPlayers = await db
      .select({
        id: players.id,
        userId: players.userId,
        teamId: players.teamId,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        position: players.position,
        status: players.status,
        jerseyNumber: players.jerseyNumber
      })
      .from(players)
      .leftJoin(users, eq(players.userId, users.id));

    // Get all teams
    const allTeams = await db.select().from(teams);
    
    // Group players by team
    const playersByTeam = allPlayers.reduce((acc, player) => {
      const teamId = player.teamId || 0;
      if (!acc[teamId]) acc[teamId] = [];
      acc[teamId].push(player);
      return acc;
    }, {} as Record<number, typeof allPlayers>);

    // Prepare sync summary
    const syncSummary = {
      totalPlayers: allPlayers.length,
      totalTeams: allTeams.length,
      teamsWithPlayers: Object.keys(playersByTeam).length,
      teamBreakdown: allTeams.map(team => ({
        teamId: team.id,
        teamName: team.name,
        playerCount: playersByTeam[team.id]?.length || 0,
        players: playersByTeam[team.id]?.map(p => ({
          id: p.id,
          name: `${p.firstName} ${p.lastName}`,
          position: p.position,
          status: p.status
        })) || []
      }))
    };

    console.log('Team roster sync completed:', syncSummary);

    res.json({
      message: 'Team rosters successfully synchronized',
      summary: syncSummary
    });

  } catch (error) {
    console.error('Team roster sync error:', error);
    res.status(500).json({ 
      message: 'Failed to sync team rosters', 
      error: (error as Error).message 
    });
  }
});

export default router;