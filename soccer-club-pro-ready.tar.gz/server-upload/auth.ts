import { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { insertUserSchema, User } from "@shared/schema";
import bcrypt from "bcryptjs";
import { z } from "zod";
import jwt from "jsonwebtoken";

// Generate a random JWT secret if not provided in environment
const JWT_SECRET = process.env.JWT_SECRET || "soccer-club-pro-secret-key";
const JWT_EXPIRES_IN = "7d"; // Token expires in 7 days

// Create tokens for users
const generateToken = (user: User) => {
  return jwt.sign(
    { id: user.id, role: user.role },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
};

// Compare password with hashed password
const comparePassword = async (password: string, hashedPassword: string): Promise<boolean> => {
  return await bcrypt.compare(password, hashedPassword);
};

// Hash password
const hashPassword = async (password: string): Promise<string> => {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
};

// Middleware to check if user is authenticated
export const isAuthenticated = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Get token from Authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    const token = authHeader.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number, role: string };
    
    // Get user
    const user = await storage.getUser(decoded.id);
    
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    
    // Add user to request
    req.user = user;
    next();
  } catch (error) {
    console.error("Auth error:", error);
    return res.status(401).json({ message: 'Invalid token' });
  }
};

// Middleware to check if user has admin role
export const isAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ message: 'Admin access required' });
  }
};

// Setup authentication routes
export const setupAuthRoutes = (app: Express) => {
  // Login route
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }
      
      // Find user by username
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Check password
      const isPasswordValid = await comparePassword(password, user.password);
      
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Generate token
      const token = generateToken(user);
      
      // Return user data and token
      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: 'An error occurred during login' });
    }
  });
  
  // Register route - restricted to invitations only
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      // Validate input
      const validateUser = insertUserSchema.safeParse(req.body);
      
      if (!validateUser.success) {
        return res.status(400).json({ message: 'Invalid user data', errors: validateUser.error.errors });
      }
      
      const { username, email, password, role } = req.body;
      
      // Only allow registration for invited users (default behavior)
      // Administrator self-registration is handled in a separate route below
      if (role !== 'admin') {
        return res.status(403).json({ message: 'Registration is by invitation only' });
      }
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ message: 'Username already exists' });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: 'Email already exists' });
      }
      
      // Check if any admin exists already
      const admins = await storage.getUsers('admin');
      if (admins.length > 0) {
        return res.status(403).json({ message: 'Administrator already exists. New administrators must be invited by an existing administrator.' });
      }
      
      // Hash password
      const hashedPassword = await hashPassword(password);
      
      // Create admin user with hashed password (only for the first admin)
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
        emailVerified: true, // First admin is auto-verified
      });
      
      // Generate token
      const token = generateToken(user);
      
      // Return user data and token
      res.status(201).json({
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        }
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: 'An error occurred during registration' });
    }
  });
  
  // Get current user route
  app.get("/api/auth/user", isAuthenticated, (req: Request, res: Response) => {
    const user = req.user;
    
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    
    // Return user data without sensitive information
    res.json({
      id: user.id,
      username: user.username,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
    });
  });
  
  // Logout route
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    // Since we're using JWT, we can't invalidate the token on the server side
    // The client is responsible for removing the token
    res.json({ message: 'Logged out successfully' });
  });
  
  // Request password reset route
  app.post("/api/auth/forgot-password", async (req: Request, res: Response) => {
    try {
      // Import the sendPasswordResetEmail function from resend-mail
      const { sendPasswordResetEmail } = await import('./utils/resend-mail');
      
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: 'Email is required' });
      }
      
      // Find user by email
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        // For security reasons, don't reveal that the email doesn't exist
        return res.status(200).json({ message: 'If the email exists, a password reset link will be sent' });
      }
      
      // Generate reset token
      const resetToken = Math.random().toString(36).substring(2, 15) + 
                        Math.random().toString(36).substring(2, 15);
      
      // Set token expiration (1 hour)
      const expires = new Date();
      expires.setHours(expires.getHours() + 1);
      
      // Save token to user
      await storage.updateUserResetToken(email, resetToken, expires);
      
      // Send password reset email
      const emailSent = await sendPasswordResetEmail(
        email,
        resetToken,
        user.firstName
      );
      
      if (!emailSent && process.env.RESEND_API_KEY) {
        // If email failed to send and Resend API key is set, it's a real error
        return res.status(500).json({ message: 'Failed to send password reset email' });
      }
      
      // Don't reveal if email was actually sent or not for security
      res.status(200).json({ 
        message: 'If the email exists, a password reset link will be sent',
        token: !emailSent ? resetToken : undefined // Only for development when Resend is not configured
      });
    } catch (error) {
      console.error("Password reset error:", error);
      res.status(500).json({ message: 'An error occurred during password reset request' });
    }
  });
  
  // Reset password route
  app.post("/api/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { token, password } = req.body;
      
      if (!token || !password) {
        return res.status(400).json({ message: 'Token and password are required' });
      }
      
      // Find user by reset token
      const user = await storage.getUserByResetToken(token);
      
      if (!user) {
        return res.status(400).json({ message: 'Invalid or expired password reset token' });
      }
      
      // Hash new password
      const hashedPassword = await hashPassword(password);
      
      // Update user password
      await storage.updateUserPassword(user.id, hashedPassword);
      
      // Clear reset token
      await storage.updateUserResetToken(user.email, "", new Date(0));
      
      res.status(200).json({ message: 'Password has been reset successfully' });
    } catch (error) {
      console.error("Password reset error:", error);
      res.status(500).json({ message: 'An error occurred during password reset' });
    }
  });
  
  // User invite route
  app.post("/api/auth/invite", isAuthenticated, isAdmin, async (req: Request, res: Response) => {
    try {
      // Import the appropriate invitation email function from resend-mail
      const { sendInvitationEmail } = await import('./utils/resend-mail');
      console.log("Loaded Resend email function for user invites");
      
      const inviteSchema = z.object({
        email: z.string().email(),
        role: z.enum(['coach', 'player', 'parent', 'coordinator', 'trainer']),
        firstName: z.string(),
        lastName: z.string(),
        teamId: z.number().optional(),
      });
      
      const validateInvite = inviteSchema.safeParse(req.body);
      
      if (!validateInvite.success) {
        return res.status(400).json({ message: 'Invalid invite data', errors: validateInvite.error.errors });
      }
      
      const { email, role, firstName, lastName, teamId } = req.body;
      
      // Allow shared email addresses for families
      console.log('Allowing shared email for family members...');
      
      // Generate random password
      const tempPassword = Math.random().toString(36).slice(-8);
      const hashedPassword = await hashPassword(tempPassword);
      
      // Create username from first and last name
      const baseUsername = `${firstName.toLowerCase()}.${lastName.toLowerCase()}`;
      let username = baseUsername;
      let counter = 1;
      
      // Check if username exists, if so, add a number to it
      while (await storage.getUserByUsername(username)) {
        username = `${baseUsername}${counter}`;
        counter++;
      }
      
      // Create verification token
      const verificationToken = Math.random().toString(36).substring(2, 15) + 
                              Math.random().toString(36).substring(2, 15);
      
      // Create user with temporary password
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        firstName,
        lastName,
        role,
        status: 'active',
        isInvited: true,
        invitedBy: req.user?.id, // Add optional chaining to prevent errors
        invitedAt: new Date(),
        verificationToken,
        emailVerified: false
      });
      
      // If teamId is provided, assign user to team
      if (teamId && user) {
        try {
          await storage.createUserTeam({
            userId: user.id,
            teamId,
            roleType: role,
            isActive: true,
          });
        } catch (error) {
          console.error("Error assigning user to team:", error);
          // Continue even if team assignment fails
        }
      }
      
      // Send invitation email using Resend
      const emailSent = await sendInvitationEmail(
        email,
        role,
        tempPassword,
        firstName,
        lastName
      );
      
      if (!emailSent) {
        // If email failed to send, it's an error but we'll continue
        console.error('Failed to send invitation email with Resend');
      }
      
      // Only return temporary password if email couldn't be sent (for development purposes)
      const responseData: any = {
        message: emailSent 
          ? 'Invitation email sent successfully' 
          : 'User created but invitation email could not be sent',
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        }
      };
      
      // Only include the tempPassword in the response if email couldn't be sent
      if (!emailSent) {
        responseData.tempPassword = tempPassword;
      }
      
      res.status(201).json(responseData);
    } catch (error) {
      console.error("Invite error:", error);
      res.status(500).json({ message: 'An error occurred while sending invitation' });
    }
  });
};

// Add user type to Express Request
declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}