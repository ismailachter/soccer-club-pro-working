const { jsPDF } = require('jspdf');
require('jspdf-autotable');

function generateYearPlanPDF(planData, periods, sessions) {
  const doc = new jsPDF();
  
  // Title - "JAARPLAN" as requested by user
  doc.setFontSize(20);
  doc.text('JAARPLAN', 20, 20);
  
  doc.setFontSize(14);
  doc.text(`${planData.name}`, 20, 35);
  
  if (planData.teamName) {
    doc.text(`Team: ${planData.teamName}`, 20, 50);
  }
  
  // Periods table
  if (periods.length > 0) {
    const finalY = 65;
    doc.text('Periodes:', 20, finalY);
    
    const periodData = periods.map(p => [
      p.name,
      p.startDate || '',
      p.endDate || '',
      p.themes?.join(', ') || ''
    ]);
    
    doc.autoTable({
      head: [['Periode', 'Start', 'Eind', 'Thema\'s']],
      body: periodData,
      startY: 85
    });
  }
  
  // Sessions table
  if (sessions.length > 0) {
    const finalY = doc.lastAutoTable?.finalY || 100;
    doc.text('Trainingen:', 20, finalY + 15);
    
    const sessionData = sessions.map(s => [
      s.date,
      s.themes?.length || 0,
      s.duration || '',
      s.location || ''
    ]);
    
    doc.autoTable({
      head: [['Datum', 'Thema\'s', 'Duur', 'Locatie']],
      body: sessionData,
      startY: finalY + 20
    });
  }
  
  return doc.output('arraybuffer');
}

module.exports = { generateYearPlanPDF };