import { db } from './db';
import fs from 'fs';
import path from 'path';

interface BenchmarkMatch {
  id: string;
  date: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  venue: 'home' | 'away';
  competition: string;
  season: string;
  videoUploaded: boolean;
  analysisComplete: boolean;
  frameCount?: number;
  playerData?: any[];
}

export class MatchBenchmarkService {
  private benchmarkMatches: BenchmarkMatch[] = [
    {
      id: 'vvc-veltem-20250412',
      date: '2025-04-12',
      homeTeam: 'VVC Brasschaat A',
      awayTeam: 'Miecroo Veltem A',
      homeScore: 3,
      awayScore: 1,
      venue: 'home',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'svelta-vvc-20250405',
      date: '2025-04-05',
      homeTeam: 'Svelta Melsele',
      awayTeam: 'VVC Brasschaat A',
      homeScore: 0,
      awayScore: 0,
      venue: 'away',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: true,
      analysisComplete: false,
      frameCount: 566
    },
    {
      id: 'vvc-hasselt-20250329',
      date: '2025-03-29',
      homeTeam: 'VVC Brasschaat A',
      awayTeam: 'Sporting Hasselt',
      homeScore: 4,
      awayScore: 4,
      venue: 'home',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'kontich-vvc-20250322',
      date: '2025-03-22',
      homeTeam: 'K. Kontich FC A',
      awayTeam: 'VVC Brasschaat A',
      homeScore: 1,
      awayScore: 3,
      venue: 'away',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'vvc-wijgmaal-20250315',
      date: '2025-03-15',
      homeTeam: 'VVC Brasschaat A',
      awayTeam: 'K.Ol Wijgmaal A',
      homeScore: 1,
      awayScore: 2,
      venue: 'home',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'loenhout-vvc-20250301',
      date: '2025-03-01',
      homeTeam: 'Loenhout SK A',
      awayTeam: 'VVC Brasschaat A',
      homeScore: 2,
      awayScore: 0,
      venue: 'away',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'vvc-patro-20250215',
      date: '2025-02-15',
      homeTeam: 'VVC Brasschaat A',
      awayTeam: 'Patro Eisden Maasmechelen A',
      homeScore: 0,
      awayScore: 1,
      venue: 'home',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'mechelen-vvc-20250209',
      date: '2025-02-09',
      homeTeam: 'YKRV Mechelen B',
      awayTeam: 'VVC Brasschaat A',
      homeScore: 0,
      awayScore: 5,
      venue: 'away',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'lierse-vvc-20250125',
      date: '2025-01-25',
      homeTeam: 'K Lierse SK',
      awayTeam: 'VVC Brasschaat A',
      homeScore: 0,
      awayScore: 3,
      venue: 'away',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'veltem-vvc-20241208',
      date: '2024-12-08',
      homeTeam: 'Miecroo Veltem A',
      awayTeam: 'VVC Brasschaat A',
      homeScore: 2,
      awayScore: 3,
      venue: 'away',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'vvc-moldavo-20241130',
      date: '2024-11-30',
      homeTeam: 'VVC Brasschaat A',
      awayTeam: 'VC Moldavo B',
      homeScore: 5,
      awayScore: 0,
      venue: 'home',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    },
    {
      id: 'herent-vvc-20241018',
      date: '2024-10-18',
      homeTeam: 'KFC Herent A',
      awayTeam: 'VVC Brasschaat A',
      homeScore: 5,
      awayScore: 0,
      venue: 'away',
      competition: 'Dames IP',
      season: '2024-2025',
      videoUploaded: false,
      analysisComplete: false
    }
  ];

  async getAllBenchmarkMatches() {
    return this.benchmarkMatches;
  }

  async getBenchmarkMatchById(id: string) {
    return this.benchmarkMatches.find(match => match.id === id);
  }

  async updateMatchVideoStatus(id: string, videoUploaded: boolean) {
    const match = this.benchmarkMatches.find(m => m.id === id);
    if (match) {
      match.videoUploaded = videoUploaded;
      return match;
    }
    return null;
  }

  async updateMatchAnalysisStatus(id: string, analysisComplete: boolean, frameCount?: number) {
    const match = this.benchmarkMatches.find(m => m.id === id);
    if (match) {
      match.analysisComplete = analysisComplete;
      if (frameCount) match.frameCount = frameCount;
      return match;
    }
    return null;
  }

  async getBenchmarkStatistics() {
    const total = this.benchmarkMatches.length;
    const uploaded = this.benchmarkMatches.filter(m => m.videoUploaded).length;
    const analyzed = this.benchmarkMatches.filter(m => m.analysisComplete).length;
    const homeGames = this.benchmarkMatches.filter(m => m.venue === 'home').length;
    const awayGames = this.benchmarkMatches.filter(m => m.venue === 'away').length;
    
    const totalGoalsFor = this.benchmarkMatches.reduce((sum, match) => {
      return sum + (match.venue === 'home' ? match.homeScore : match.awayScore);
    }, 0);
    
    const totalGoalsAgainst = this.benchmarkMatches.reduce((sum, match) => {
      return sum + (match.venue === 'home' ? match.awayScore : match.homeScore);
    }, 0);

    return {
      totalMatches: total,
      videosUploaded: uploaded,
      analysisComplete: analyzed,
      homeGames,
      awayGames,
      totalGoalsFor,
      totalGoalsAgainst,
      uploadProgress: (uploaded / total) * 100,
      analysisProgress: (analyzed / total) * 100
    };
  }

  async createUploadDirectoryStructure() {
    const baseDir = path.join(process.cwd(), 'uploads', 'benchmark-matches');
    
    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true });
    }

    for (const match of this.benchmarkMatches) {
      const matchDir = path.join(baseDir, match.id);
      const framesDir = path.join(matchDir, 'frames');
      const clipsDir = path.join(matchDir, 'clips');
      const analysisDir = path.join(matchDir, 'analysis');

      [matchDir, framesDir, clipsDir, analysisDir].forEach(dir => {
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
      });
    }

    return true;
  }
}

export const matchBenchmarkService = new MatchBenchmarkService();