import { db } from './db';
import { modules, clubModules, clubSubscriptions } from '@shared/schema';
import { eq, and } from 'drizzle-orm';

const AVAILABLE_MODULES = {
  CORE: {
    id: "core",
    name: "Core Module",
    price: 29,
    features: ["Dashboard", "Club Info", "User Management", "Email System"],
    isCore: true,
    category: "core"
  },
  PLAYER_MANAGEMENT: {
    id: "player_management", 
    name: "Speler Management",
    price: 19,
    features: ["Players Database", "Scout Database", "Team Assignments"],
    category: "player"
  },
  TRAINING_PLANNING: {
    id: "training_planning",
    name: "Training & Planning", 
    price: 24,
    features: ["IADATABANK", "Jaarplanning", "Training Maker", "PDF Export"],
    category: "training"
  },
  TEAM_MANAGEMENT: {
    id: "team_management",
    name: "Team Management",
    price: 16, 
    features: ["Teams Dashboard", "Team Selection", "Team Scheduling"],
    category: "team"
  },
  MATCH_MANAGEMENT: {
    id: "match_management",
    name: "Wedstrijd Management",
    price: 14,
    features: ["Match Planning", "Results Tracking", "Opponent Database"],
    category: "match"
  },
  FACILITIES: {
    id: "facilities",
    name: "Facilitair",
    price: 12,
    features: ["Pitches Management", "Equipment Tracking"],
    category: "facility"
  },
  FINANCIAL: {
    id: "financial", 
    name: "Financieel",
    price: 18,
    features: ["Payment Management", "Fee Tracking", "Financial Reports"],
    category: "finance"
  },
  COMMUNICATION: {
    id: "communication",
    name: "Communicatie", 
    price: 15,
    features: ["Parent Communication", "Invitations", "Notifications"],
    category: "communication"
  },
  ANALYTICS: {
    id: "analytics",
    name: "Advanced Analytics",
    price: 22,
    features: ["Performance Analytics", "Player Development", "Custom Reports"],
    category: "analytics"
  }
};

export class SubscriptionService {
  
  // Initialize default modules in database
  async initializeModules() {
    console.log('🔧 Initializing SaaS modules...');
    
    for (const [key, moduleData] of Object.entries(AVAILABLE_MODULES)) {
      await db.insert(modules).values({
        id: moduleData.id,
        name: moduleData.name,
        displayName: moduleData.name,
        description: `${moduleData.name} module for Soccer Club Pro`,
        price: moduleData.price.toString(),
        category: moduleData.category,
        features: moduleData.features,
        isCore: moduleData.isCore || false,
        isActive: true,
        sortOrder: Object.keys(AVAILABLE_MODULES).indexOf(key)
      }).onConflictDoUpdate({
        target: modules.id,
        set: {
          price: moduleData.price.toString(),
          features: moduleData.features,
          updatedAt: new Date()
        }
      });
    }
    
    console.log('✅ SaaS modules initialized');
  }

  // Check if club has access to specific module
  async hasModuleAccess(clubId: number, moduleId: string): Promise<boolean> {
    const [clubModule] = await db
      .select()
      .from(clubModules)
      .where(
        and(
          eq(clubModules.clubId, clubId),
          eq(clubModules.moduleName, moduleId),
          eq(clubModules.isEnabled, true)
        )
      );
    
    return !!clubModule;
  }

  // Enable module for club
  async enableModule(clubId: number, moduleId: string) {
    const existing = await db.select()
      .from(clubModules)
      .where(and(
        eq(clubModules.clubId, clubId),
        eq(clubModules.moduleName, moduleId)
      ));

    if (existing.length > 0) {
      await db.update(clubModules)
        .set({
          isEnabled: true,
          enabledAt: new Date(),
          disabledAt: null
        })
        .where(and(
          eq(clubModules.clubId, clubId),
          eq(clubModules.moduleName, moduleId)
        ));
    } else {
      await db.insert(clubModules).values({
        clubId,
        moduleName: moduleId,
        isEnabled: true,
        enabledAt: new Date()
      });
    }
    
    console.log(`✅ Module ${moduleId} enabled for club ${clubId}`);
  }

  // Disable module for club  
  async disableModule(clubId: number, moduleId: string) {
    await db.update(clubModules)
      .set({
        isEnabled: false,
        disabledAt: new Date()
      })
      .where(
        and(
          eq(clubModules.clubId, clubId),
          eq(clubModules.moduleName, moduleId)
        )
      );
    
    console.log(`❌ Module ${moduleId} disabled for club ${clubId}`);
  }

  // Get all modules for club
  async getClubModules(clubId: number) {
    return await db
      .select({
        module: modules,
        access: clubModules
      })
      .from(modules)
      .leftJoin(
        clubModules,
        and(
          eq(clubModules.moduleName, modules.id),
          eq(clubModules.clubId, clubId),
          eq(clubModules.isEnabled, true)
        )
      )
      .where(eq(modules.isActive, true));
  }

  // Enable VVC Brasschaat with all modules (founding partner)
  async enableVVCBrasschaatModules() {
    const vvcClubId = 1; // VVC Brasschaat club ID
    
    console.log('🎯 Enabling all modules for VVC Brasschaat (founding partner)...');
    
    for (const moduleData of Object.values(AVAILABLE_MODULES)) {
      await this.enableModule(vvcClubId, moduleData.id);
    }
    
    console.log('✅ All modules enabled for VVC Brasschaat');
  }

  // Calculate monthly cost for club
  async calculateMonthlyCost(clubId: number): Promise<number> {
    const clubModuleList = await db
      .select({
        module: modules
      })
      .from(clubModules)
      .leftJoin(modules, eq(modules.id, clubModules.moduleName))
      .where(
        and(
          eq(clubModules.clubId, clubId),
          eq(clubModules.isEnabled, true)
        )
      );

    let totalCost = 0;
    for (const item of clubModuleList) {
      if (item.module) {
        totalCost += parseFloat(item.module.price);
      }
    }

    return totalCost;
  }
}