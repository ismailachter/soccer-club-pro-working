import nodemailer from 'nodemailer';
import { storage } from '../storage';
import bcrypt from 'bcryptjs';

// One.com SMTP configuration
const transporter = nodemailer.createTransport({
  host: 'send.one.com',
  port: 465,
  secure: true,
  auth: {
    user: 'info@soccerclubpro.com',
    pass: 'Qunoot135!'
  }
});

export async function sendGeoffreyInvitation() {
  try {
    // Generate temporary password for Geoffrey
    const tempPassword = 'Geoffrey2025!';
    const hashedPassword = await bcrypt.hash(tempPassword, 10);
    
    // Create Geoffrey's user account with limited permissions
    const geoffreyUser = await storage.createUser({
      username: 'geoffrey.vdvoorde',
      email: 'geoffrey.vdv3@hotmail.com',
      password: hashedPassword,
      firstName: 'Geoffrey',
      lastName: 'van de Voorde',
      role: 'admin', // Full admin access as requested
      isEmailVerified: true,
      createdAt: new Date(),
      updatedAt: new Date()
    });

    console.log('Geoffrey user created:', geoffreyUser.id);

    // Email content
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Uitnodiging U20 Jaarplanning - VVC Brasschaat</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: #4a90e2; color: white; padding: 20px; text-align: center;">
              <h1 style="margin: 0;">VVC Brasschaat</h1>
              <p style="margin: 5px 0 0 0;">Jaarplanning Module Toegang</p>
            </div>
            
            <div style="padding: 30px; background: #f9f9f9;">
              <h2>Welkom Geoffrey!</h2>
              
              <p>Je hebt toegang gekregen tot de <strong>U20 Jaarplanning Module</strong> van VVC Brasschaat via Soccer Club Pro.</p>
              
              <div style="background: white; padding: 20px; border-left: 4px solid #4a90e2; margin: 20px 0;">
                <h3>Toegangsgegevens:</h3>
                <p><strong>Website:</strong> <a href="https://soccerclubpro.com">https://soccerclubpro.com</a></p>
                <p><strong>Email:</strong> geoffrey.vdv3@hotmail.com</p>
                <p><strong>Tijdelijk wachtwoord:</strong> Geoffrey2025!</p>
              </div>
              
              <div style="background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h4>Volledige toegang tot:</h4>
                <ul>
                  <li>✅ Alle jaarplanningen (Dames IP, Dames Provinciaal, U20)</li>
                  <li>✅ Trainingen bewerken en plannen</li>
                  <li>✅ IADATABANK elementen gebruiken</li>
                  <li>✅ PDF/Excel exports downloaden</li>
                  <li>✅ Spelers en teams beheren</li>
                  <li>✅ Volledige admin rechten</li>
                </ul>
              </div>
              
              <div style="background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #ffc107;">
                <h4>📄 Jaarplanning PDFs:</h4>
                <p>Direct download links voor huidige jaarplanningen:</p>
                <ul>
                  <li><a href="https://soccerclubpro.com/api/year-plans/17/export/pdf" style="color: #4a90e2;">📥 Dames IP Jaarplanning</a></li>
                  <li><a href="https://soccerclubpro.com/api/year-plans/18/export/pdf" style="color: #4a90e2;">📥 Dames Provinciaal Jaarplanning</a></li>
                  <li><a href="https://soccerclubpro.com/api/year-plans/19/export/pdf" style="color: #4a90e2;">📥 U20 Jaarplanning</a></li>
                </ul>
              </div>
              
              <p><strong>Let op:</strong> Wijzig je wachtwoord na eerste inlog voor beveiliging.</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="https://soccerclubpro.com/auth" style="background: #4a90e2; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
                  Nu Inloggen
                </a>
              </div>
              
              <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
              
              <p style="font-size: 12px; color: #666;">
                Dit account is speciaal aangemaakt voor U20 jaarplanning toegang.<br>
                Voor vragen, neem contact op met ismail.achter@gmail.com
              </p>
            </div>
            
            <div style="background: #333; color: white; padding: 15px; text-align: center; font-size: 12px;">
              <p style="margin: 0;">Powered by Soccer Club Pro | Professional Club Management</p>
            </div>
          </div>
        </body>
      </html>
    `;

    // Send email with CC to ismail.achter@gmail.com
    const mailOptions = {
      from: '"VVC Brasschaat" <info@soccerclubpro.com>',
      to: 'geoffrey.vdv3@hotmail.com',
      cc: 'ismail.achter@gmail.com', // CC to you as requested
      subject: 'Toegang U20 Jaarplanning - VVC Brasschaat',
      html: htmlContent
    };

    const result = await transporter.sendMail(mailOptions);
    console.log('Geoffrey invitation email sent successfully:', result.messageId);
    
    return {
      success: true,
      userId: geoffreyUser.id,
      email: geoffreyUser.email,
      messageId: result.messageId,
      tempPassword: tempPassword
    };
    
  } catch (error) {
    console.error('Error sending Geoffrey invitation:', error);
    throw error;
  }
}