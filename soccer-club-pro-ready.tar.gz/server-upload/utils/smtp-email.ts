import nodemailer from 'nodemailer';

// Create SMTP transporter using Gmail
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_EMAIL,
    pass: process.env.GMAIL_PASSWORD
  }
});

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(options: EmailOptions): Promise<boolean> {
  try {
    const { to, subject, html, text } = options;
    
    const mailOptions = {
      from: process.env.GMAIL_EMAIL,
      to: to,
      subject: subject,
      html: html,
      text: text
    };

    const result = await transporter.sendMail(mailOptions);
    console.log('Email sent successfully:', result.messageId);
    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
}

export async function sendWelcomeEmailSMTP(data: {
  to: string;
  playerName: string;
  clubName: string;
  teamName: string;
  username: string;
  temporaryPassword: string;
}): Promise<boolean> {
  const { to, playerName, clubName, teamName, username, temporaryPassword } = data;

  const subject = `🏆 Welcome to ${clubName} - ${teamName}!`;
  
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 0 auto; background: #ffffff; }
        .header { background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color: white; padding: 40px 30px; text-align: center; }
        .header h1 { margin: 0; font-size: 32px; font-weight: bold; }
        .header p { margin: 15px 0 0 0; font-size: 18px; opacity: 0.9; }
        .content { padding: 40px 30px; }
        .welcome-box { background: #f8fafc; padding: 25px; border-radius: 12px; border-left: 5px solid #2563eb; margin: 25px 0; }
        .welcome-box h2 { color: #1e40af; margin: 0 0 15px 0; font-size: 24px; }
        .credentials { background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .credentials h3 { color: #1e40af; margin: 0 0 15px 0; font-size: 18px; }
        .credentials p { margin: 8px 0; font-size: 16px; }
        .credentials strong { color: #1e40af; }
        .features { margin: 25px 0; }
        .features ul { list-style: none; padding: 0; }
        .features li { padding: 8px 0; font-size: 16px; }
        .features li:before { content: "✅ "; color: #10b981; font-weight: bold; }
        .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 14px; }
        .logo { font-size: 24px; margin-bottom: 10px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">⚽</div>
          <h1>Welcome to ${clubName}!</h1>
          <p>You've joined ${teamName}</p>
        </div>
        
        <div class="content">
          <div class="welcome-box">
            <h2>Hello ${playerName}! 👋</h2>
            <p>We're absolutely thrilled to welcome you to <strong>${teamName}</strong> at <strong>${clubName}</strong>!</p>
            <p>Your player account has been created and you now have full access to our club management system.</p>
          </div>

          <div class="credentials">
            <h3>🔐 Your Login Details</h3>
            <p><strong>Username:</strong> ${username}</p>
            <p><strong>Temporary Password:</strong> ${temporaryPassword}</p>
            <p><em>Please change your password after your first login for security.</em></p>
          </div>

          <div class="features">
            <p><strong>With your account, you can:</strong></p>
            <ul>
              <li>View your team roster and upcoming matches</li>
              <li>Access training schedules and programs</li>
              <li>Stay updated with club announcements</li>
              <li>Track your performance and statistics</li>
              <li>Connect with teammates and coaches</li>
            </ul>
          </div>

          <div class="footer">
            <p><strong>${clubName}</strong> Soccer Club Management System</p>
            <p>If you have any questions, please contact your team coordinator.</p>
            <p>Welcome to the team! Let's achieve great things together! 🎯⚽</p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  const text = `
    Welcome to ${clubName} - ${teamName}!
    
    Hello ${playerName}!
    
    We're excited to welcome you to ${teamName} at ${clubName}!
    Your player account has been created and you now have access to our club management system.
    
    Login Details:
    Username: ${username}
    Temporary Password: ${temporaryPassword}
    
    Please change your password after your first login for security.
    
    With your account, you can:
    - View your team roster and upcoming matches
    - Access training schedules and programs  
    - Stay updated with club announcements
    - Track your performance and statistics
    - Connect with teammates and coaches
    
    Welcome to the team!
    ${clubName}
  `;

  return await sendEmail({ to, subject, html, text });
}