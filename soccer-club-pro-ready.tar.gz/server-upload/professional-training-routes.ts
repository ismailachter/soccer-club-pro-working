import { Router } from 'express';
import PDFDocument from 'pdfkit';

const router = Router();

interface TrainingPhase {
  name: string;
  duration: number;
  exercises: Exercise[];
}

interface Exercise {
  name: string;
  duration: number;
  setup: string;
  description: string;
  objectives: string[];
  coaching_points: string[];
  progression: string[];
  equipment: string[];
  players: number;
  field_size: string;
}

// Generate professional 3-4-3 build-up training
router.post('/generate-343-buildup-training', async (req, res) => {
  try {
    const training = {
      name: "Opbouwen van achteruit - 3-4-3 Formatie",
      description: "Professionele training voor het aanleren van opbouwen vanaf de keeper en verdediging in een 3-4-3 systeem",
      duration: 90,
      players: 16,
      ageGroup: "Dames",
      intensity: "medium",
      focusAreas: ["TEAMTACTISCH", "BASICS"],
      
      phases: [
        // OPWARMING (15 minuten)
        {
          name: "OPWARMING",
          duration: 15,
          exercises: [
            {
              name: "Activerende Opwarming met Bal",
              duration: 8,
              setup: "16 speelsters in een 30x20m veld, elk met een bal",
              description: "Vrije beweging met bal, focus op eerste aanraking en oriëntatie",
              objectives: [
                "Activeren van spieren en gewrichten",
                "Balgevoel ontwikkelen",
                "Eerste aanraking verbeteren"
              ],
              coaching_points: [
                "Hoofd omhoog, kijk rond je",
                "Zachte eerste aanraking",
                "Gebruik beide voeten",
                "Varieer in tempo en richting"
              ],
              progression: [
                "Start met lopen en bal raken",
                "Voeg dribbels toe",
                "Combineer met kleine wendingen"
              ],
              equipment: ["16 ballen", "4 pionnen"],
              players: 16,
              field_size: "30x20m"
            },
            {
              name: "Passing in Beweging - Driehoekvorm",
              duration: 7,
              setup: "4 groepen van 4 speelsters, driehoekvorm 15m zijden",
              description: "Passing en bewegen in driehoeken, focus op aanbieden en oriëntatie",
              objectives: [
                "Passing techniek onder druk",
                "Aanbieden en vrijlopen",
                "Communicatie ontwikkelen"
              ],
              coaching_points: [
                "Aanbieden met lichaam open naar spel",
                "Pass en ga - altijd bewegen",
                "Praat met je medespelers",
                "Juiste moment van aanbieden"
              ],
              progression: [
                "2 aanrakingen",
                "1 aanraking",
                "Voeg druk toe met passieve verdediger"
              ],
              equipment: ["4 ballen", "12 pionnen"],
              players: 16,
              field_size: "15x15m per groep"
            }
          ]
        },
        
        // TUSSENVORMEN (45 minuten)
        {
          name: "TUSSENVORMEN",
          duration: 45,
          exercises: [
            {
              name: "Tussenvorm 1: 3v2 Opbouwen Centraal",
              duration: 15,
              setup: "3 verdedigers tegen 2 aanvallers in 30x20m zone",
              description: "3 verdedigers bouwen op tegen 2 verdedigers, focus op lijnbreking en switching",
              objectives: [
                "Opbouwen onder druk",
                "Lijnbreking door passing",
                "Switching van spel left-right"
              ],
              coaching_points: [
                "Centrale verdediger dirigeert - 'Links!', 'Rechts!', 'Centraal!'",
                "Buitenverdedigers: 'Ik ben vrij!' als je aanspeelbaar bent",
                "Bij druk: 'Switch!' en verleg het spel",
                "Keeper: 'Tijd!' of 'Druk!' om situatie aan te geven"
              ],
              progression: [
                "Start zonder tijdsdruk",
                "Voeg 8-seconden regel toe",
                "Verdedigers mogen scoren op minitaken"
              ],
              equipment: ["2 ballen", "8 pionnen", "2 minitaken"],
              players: 10,
              field_size: "30x20m"
            },
            {
              name: "Tussenvorm 2: 4v3 Middenveld Connectie",
              duration: 15,
              setup: "4 middenvelders tegen 3 verdedigers in 40x30m zone",
              description: "Middenvelders ontvangen van achteren en spelen door naar aanval",
              objectives: [
                "Connectie verdediging-middenveld",
                "Onder druk spelen in box-vorm",
                "Doorspelen naar aanval"
              ],
              coaching_points: [
                "Box middenvelders: 'Geef en ga!' na elke pass",
                "Centrale middenvelders: 'Draai!' bij ontvangen met rug naar doel",
                "Buitenmiddenvelders: 'Breed!' om veld groot te maken",
                "Bij verovering: 'Pressure!' - direct druk zetten"
              ],
              progression: [
                "Vrij spel met afronden op doel",
                "Maximaal 3 aanrakingen",
                "Tel aantal geslaagde doorspelingen"
              ],
              equipment: ["2 ballen", "12 pionnen", "1 doel"],
              players: 14,
              field_size: "40x30m"
            },
            {
              name: "Tussenvorm 3: 3v2+1 Aanval Afwerking",
              duration: 15,
              setup: "3 aanvallers tegen 2 verdedigers + keeper in 30x20m + 16m zone",
              description: "Aanvallers ontvangen van middenveld en werken af met numeriek voordeel",
              objectives: [
                "Afwerken onder druk",
                "Gebruik van diepte en breedte",
                "Timing van loopacties"
              ],
              coaching_points: [
                "Spits: 'Kom!' voor aanspeelbaar zijn of 'Loop!' voor diepgang",
                "Vleugelaanvallers: 'Overlap!' bij steunmomenten",
                "Bij shooting moment: 'Schiet!' van medespelers",
                "Gebruik '1-2 combinatie' om verdediging te passeren"
              ],
              progression: [
                "Start met aanspelen vanuit rust",
                "Voeg loopacties toe",
                "Tijdslimiet van 6 seconden voor afwerking"
              ],
              equipment: ["3 ballen", "8 pionnen", "1 doel"],
              players: 12,
              field_size: "30x36m"
            }
          ]
        },
        
        // WEDSTRIJDVORMEN (25 minuten)
        {
          name: "WEDSTRIJDVORMEN",
          duration: 25,
          exercises: [
            {
              name: "Wedstrijdvorm 1: 8v8 Complete Opbouw",
              duration: 8,
              setup: "Volledig veld, beide teams 3-4-1 formatie",
              description: "Complete wedstrijdvorm met focus op opbouwen vanaf keeper",
              objectives: [
                "Toepassen 3-4-3 systeem",
                "Opbouwen onder wedstrijddruk",
                "Positioneel spel uitvoeren"
              ],
              coaching_points: [
                "Keeper: 'Lijn!' om verdediging op lijn te krijgen",
                "Centrale verdediger: 'Ik heb tijd!' of 'Druk komt!'",
                "Middenvelders: 'Drop!' om bal op te halen",
                "Hele team: 'Hoog druk!' bij balverlies voor pressure"
              ],
              progression: [
                "Vrij spel",
                "Verplicht via alle 3 verdedigers",
                "Punten alleen bij opbouw via keeper"
              ],
              equipment: ["1 bal", "2 doelen", "16 hesjes"],
              players: 16,
              field_size: "70x50m"
            },
            {
              name: "Wedstrijdvorm 2: Zones Voetbal 3-4-3",
              duration: 8,
              setup: "Veld in 3 zones, spelers mogen alleen in eigen zone",
              description: "Wedstrijdvorm met vaste zones om positioneel spel te versterken",
              objectives: [
                "Positioneel discipline",
                "Zonegebonden passing",
                "Connectie tussen linies"
              ],
              coaching_points: [
                "Verdediging: 'Breed staan!' voor optimale hoeken",
                "Middenveld: 'Connectie!' tussen linies houden", 
                "Aanval: 'Diepgang!' op juiste momenten",
                "Overgangen: 'Compact!' bij balverlies"
              ],
              progression: [
                "Strict zones bewaken",
                "1 speler mag zone verlaten",
                "Bij doelpunt mogen alle spelers 5 sec overal"
              ],
              equipment: ["1 bal", "2 doelen", "12 pionnen voor zones"],
              players: 16,
              field_size: "60x40m"
            },
            {
              name: "Wedstrijdvorm 3: Eindzones Voetbal",
              duration: 9,
              setup: "Veld met 2 eindzones, scoren door bal controlled te ontvangen in eindzone",
              description: "Focus op doorspelen naar eindzone via 3-4-3 opbouw",
              objectives: [
                "Doelgericht opbouwen",
                "Switching onder druk",
                "Eindproduct leveren"
              ],
              coaching_points: [
                "Zoek altijd 'Eindzone!' als doel van opbouw",
                "Bij vastlopen: 'Reset!' en opnieuw via andere kant",
                "Aanvallers: 'Timing!' voor binnenlopen eindzone",
                "Verdediging na verovering: 'Omschakeling!' - direct opbouwen"
              ],
              progression: [
                "Eindzone scoren = 1 punt",
                "Via alle 3 verdedigers = 2 punten",
                "Onder 8 seconden = 3 punten"
              ],
              equipment: ["1 bal", "16 pionnen voor eindzones"],
              players: 16,
              field_size: "50x30m + 2 eindzones 10x30m"
            }
          ]
        },
        
        // COOLING DOWN (5 minuten)
        {
          name: "COOLING DOWN",
          duration: 5,
          exercises: [
            {
              name: "Uitlopen en Stretching",
              duration: 5,
              setup: "Vrij rond het veld, individueel tempo",
              description: "Geleidelijk uitlopen met focus op teambespreking 3-4-3 systeem",
              objectives: [
                "Geleidelijk afbouwen intensiteit",
                "Reflectie op training",
                "Team building"
              ],
              coaching_points: [
                "Evalueer: 'Wat ging goed met opbouwen?'",
                "Bespreek: 'Welke coaching woorden hielpen?'",
                "Preview: 'Volgende keer meer druk tijdens opbouw'",
                "Positief afsluiten team prestatie"
              ],
              progression: ["Uitlopen", "Stretching", "Team circle evaluatie"],
              equipment: [],
              players: 16,
              field_size: "Volledig veld"
            }
          ]
        }
      ]
    };

    res.json({
      message: "Professionele 3-4-3 opbouw training gegenereerd",
      training: training
    });

  } catch (error) {
    console.error('Training generation error:', error);
    res.status(500).json({ message: 'Failed to generate training' });
  }
});

// PDF Export route for professional training using PDFKit
router.post('/export-training-pdf', async (req, res) => {
  try {
    const trainingData = {
      name: "Opbouwen van achteruit - 3-4-3 Formatie",
      description: "Professionele training voor het aanleren van opbouwen vanaf de keeper en verdediging in een 3-4-3 systeem met 16 speelsters. Deze training bevat alle coaching woorden, progressie stappen en materiaallijsten volgens EDT principes.",
      duration: 90,
      players: 16,
      intensity: "medium",
      phases: [
        {
          name: "OPWARMING",
          duration: 15,
          exercises: [
            {
              name: "Activerende Opwarming met Bal",
              duration: 8,
              setup: "16 speelsters in een 30x20m veld, elk met een bal",
              description: "Vrije beweging met bal, focus op eerste aanraking en oriëntatie",
              objectives: ["Activeren van spieren en gewrichten", "Balgevoel ontwikkelen", "Eerste aanraking verbeteren"],
              coaching_points: ["Hoofd omhoog, kijk rond je", "Zachte eerste aanraking", "Gebruik beide voeten", "Varieer in tempo en richting"],
              progression: ["Start met lopen en bal raken", "Voeg dribbels toe", "Combineer met kleine wendingen"],
              equipment: ["16 ballen", "4 pionnen"],
              field_size: "30x20m"
            },
            {
              name: "Passing in Beweging - Driehoekvorm",
              duration: 7,
              setup: "4 groepen van 4 speelsters, driehoekvorm 15m zijden",
              description: "Passing en bewegen in driehoeken, focus op aanbieden en oriëntatie",
              objectives: ["Passing techniek onder druk", "Aanbieden en vrijlopen", "Communicatie ontwikkelen"],
              coaching_points: ["Aanbieden met lichaam open naar spel", "Pass en ga - altijd bewegen", "Praat met je medespelers", "Juiste moment van aanbieden"],
              progression: ["2 aanrakingen", "1 aanraking", "Voeg druk toe met passieve verdediger"],
              equipment: ["4 ballen", "12 pionnen"],
              field_size: "15x15m per groep"
            }
          ]
        },
        {
          name: "TUSSENVORMEN",
          duration: 45,
          exercises: [
            {
              name: "Tussenvorm 1: 3v2 Opbouwen Centraal",
              duration: 15,
              setup: "3 verdedigers tegen 2 aanvallers in 30x20m zone",
              description: "3 verdedigers bouwen op tegen 2 verdedigers, focus op lijnbreking en switching",
              objectives: ["Opbouwen onder druk", "Lijnbreking door passing", "Switching van spel left-right"],
              coaching_points: [
                "Centrale verdediger dirigeert - 'Links!', 'Rechts!', 'Centraal!'",
                "Buitenverdedigers: 'Ik ben vrij!' als je aanspeelbaar bent",
                "Bij druk: 'Switch!' en verleg het spel",
                "Keeper: 'Tijd!' of 'Druk!' om situatie aan te geven"
              ],
              progression: ["Start zonder tijdsdruk", "Voeg 8-seconden regel toe", "Verdedigers mogen scoren op minitaken"],
              equipment: ["2 ballen", "8 pionnen", "2 minitaken"],
              field_size: "30x20m"
            },
            {
              name: "Tussenvorm 2: 4v3 Middenveld Connectie",
              duration: 15,
              setup: "4 middenvelders tegen 3 verdedigers in 40x30m zone",
              description: "Middenvelders ontvangen van achteren en spelen door naar aanval",
              objectives: ["Connectie verdediging-middenveld", "Onder druk spelen in box-vorm", "Doorspelen naar aanval"],
              coaching_points: [
                "Box middenvelders: 'Geef en ga!' na elke pass",
                "Centrale middenvelders: 'Draai!' bij ontvangen met rug naar doel",
                "Buitenmiddenvelders: 'Breed!' om veld groot te maken",
                "Bij verovering: 'Pressure!' - direct druk zetten"
              ],
              progression: ["Vrij spel met afronden op doel", "Maximaal 3 aanrakingen", "Tel aantal geslaagde doorspelingen"],
              equipment: ["2 ballen", "12 pionnen", "1 doel"],
              field_size: "40x30m"
            },
            {
              name: "Tussenvorm 3: 3v2+1 Aanval Afwerking",
              duration: 15,
              setup: "3 aanvallers tegen 2 verdedigers + keeper in 30x20m + 16m zone",
              description: "Aanvallers ontvangen van middenveld en werken af met numeriek voordeel",
              objectives: ["Afwerken onder druk", "Gebruik van diepte en breedte", "Timing van loopacties"],
              coaching_points: [
                "Spits: 'Kom!' voor aanspeelbaar zijn of 'Loop!' voor diepgang",
                "Vleugelaanvallers: 'Overlap!' bij steunmomenten",
                "Bij shooting moment: 'Schiet!' van medespelers",
                "Gebruik '1-2 combinatie' om verdediging te passeren"
              ],
              progression: ["Start met aanspelen vanuit rust", "Voeg loopacties toe", "Tijdslimiet van 6 seconden voor afwerking"],
              equipment: ["3 ballen", "8 pionnen", "1 doel"],
              field_size: "30x36m"
            }
          ]
        },
        {
          name: "WEDSTRIJDVORMEN",
          duration: 25,
          exercises: [
            {
              name: "Wedstrijdvorm 1: 8v8 Complete Opbouw",
              duration: 8,
              setup: "Volledig veld, beide teams 3-4-1 formatie",
              description: "Complete wedstrijdvorm met focus op opbouwen vanaf keeper",
              objectives: ["Toepassen 3-4-3 systeem", "Opbouwen onder wedstrijddruk", "Positioneel spel uitvoeren"],
              coaching_points: [
                "Keeper: 'Lijn!' om verdediging op lijn te krijgen",
                "Centrale verdediger: 'Ik heb tijd!' of 'Druk komt!'",
                "Middenvelders: 'Drop!' om bal op te halen",
                "Hele team: 'Hoog druk!' bij balverlies voor pressure"
              ],
              progression: ["Vrij spel", "Verplicht via alle 3 verdedigers", "Punten alleen bij opbouw via keeper"],
              equipment: ["1 bal", "2 doelen", "16 hesjes"],
              field_size: "70x50m"
            },
            {
              name: "Wedstrijdvorm 2: Zones Voetbal 3-4-3",
              duration: 8,
              setup: "Veld in 3 zones, spelers mogen alleen in eigen zone",
              description: "Wedstrijdvorm met vaste zones om positioneel spel te versterken",
              objectives: ["Positioneel discipline", "Zonegebonden passing", "Connectie tussen linies"],
              coaching_points: [
                "Verdediging: 'Breed staan!' voor optimale hoeken",
                "Middenveld: 'Connectie!' tussen linies houden",
                "Aanval: 'Diepgang!' op juiste momenten",
                "Overgangen: 'Compact!' bij balverlies"
              ],
              progression: ["Strict zones bewaken", "1 speler mag zone verlaten", "Bij doelpunt mogen alle spelers 5 sec overal"],
              equipment: ["1 bal", "2 doelen", "12 pionnen voor zones"],
              field_size: "60x40m"
            },
            {
              name: "Wedstrijdvorm 3: Eindzones Voetbal",
              duration: 9,
              setup: "Veld met 2 eindzones, scoren door bal controlled te ontvangen in eindzone",
              description: "Focus op doorspelen naar eindzone via 3-4-3 opbouw",
              objectives: ["Doelgericht opbouwen", "Switching onder druk", "Eindproduct leveren"],
              coaching_points: [
                "Zoek altijd 'Eindzone!' als doel van opbouw",
                "Bij vastlopen: 'Reset!' en opnieuw via andere kant",
                "Aanvallers: 'Timing!' voor binnenlopen eindzone",
                "Verdediging na verovering: 'Omschakeling!' - direct opbouwen"
              ],
              progression: ["Eindzone scoren = 1 punt", "Via alle 3 verdedigers = 2 punten", "Onder 8 seconden = 3 punten"],
              equipment: ["1 bal", "16 pionnen voor eindzones"],
              field_size: "50x30m + 2 eindzones 10x30m"
            }
          ]
        },
        {
          name: "COOLING DOWN",
          duration: 5,
          exercises: [
            {
              name: "Uitlopen en Stretching",
              duration: 5,
              setup: "Vrij rond het veld, individueel tempo",
              description: "Geleidelijk uitlopen met focus op teambespreking 3-4-3 systeem",
              objectives: ["Geleidelijk afbouwen intensiteit", "Reflectie op training", "Team building"],
              coaching_points: [
                "Evalueer: 'Wat ging goed met opbouwen?'",
                "Bespreek: 'Welke coaching woorden hielpen?'",
                "Preview: 'Volgende keer meer druk tijdens opbouw'",
                "Positief afsluiten team prestatie"
              ],
              progression: ["Uitlopen", "Stretching", "Team circle evaluatie"],
              equipment: [],
              field_size: "Volledig veld"
            }
          ]
        }
      ]
    };

    const doc = new PDFDocument({ margin: 50 });
    const buffers: Buffer[] = [];
    
    doc.on('data', buffers.push.bind(buffers));
    doc.on('end', () => {
      const pdfBuffer = Buffer.concat(buffers);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename="3-4-3_Opbouw_Training_Professioneel.pdf"');
      res.send(pdfBuffer);
    });

    // Title page
    doc.fontSize(24).font('Helvetica-Bold').text('PROFESSIONELE TRAINING', { align: 'center' });
    doc.moveDown(0.5);
    doc.fontSize(18).font('Helvetica').text(trainingData.name, { align: 'center' });
    doc.moveDown(1);
    
    // Training info
    doc.fontSize(12).font('Helvetica-Bold').text('TRAINING INFORMATIE:', 50);
    doc.font('Helvetica').text(`Duur: ${trainingData.duration} minuten`);
    doc.text(`Spelers: ${trainingData.players} speelsters`);
    doc.text(`Intensiteit: ${trainingData.intensity}`);
    doc.text(`Formatie: 3-4-3 systeem`);
    doc.moveDown(1);
    
    // Description
    doc.font('Helvetica-Bold').text('BESCHRIJVING:');
    doc.font('Helvetica').text(trainingData.description, { align: 'justify' });
    doc.moveDown(1);

    // Phases
    trainingData.phases.forEach((phase: any, phaseIndex: number) => {
      if (phaseIndex > 0) doc.addPage();
      
      // Phase header
      doc.fontSize(18).font('Helvetica-Bold').text(`${phase.name} (${phase.duration} minuten)`, { underline: true });
      doc.moveDown(0.5);
      
      // Exercises
      phase.exercises.forEach((exercise: any, exerciseIndex: number) => {
        if (exerciseIndex > 0) doc.moveDown(1);
        
        // Exercise header
        doc.fontSize(14).font('Helvetica-Bold')
           .text(`${exerciseIndex + 1}. ${exercise.name} (${exercise.duration} min)`);
        doc.moveDown(0.3);
        
        // Setup
        doc.fontSize(11).font('Helvetica-Bold').text('OPSTELLING:');
        doc.font('Helvetica').text(exercise.setup);
        doc.moveDown(0.2);
        
        // Description
        doc.font('Helvetica-Bold').text('UITVOERING:');
        doc.font('Helvetica').text(exercise.description);
        doc.moveDown(0.2);
        
        // Objectives
        if (exercise.objectives && exercise.objectives.length > 0) {
          doc.font('Helvetica-Bold').text('DOELSTELLINGEN:');
          exercise.objectives.forEach((objective: string) => {
            doc.font('Helvetica').text(`• ${objective}`, { indent: 20 });
          });
          doc.moveDown(0.2);
        }
        
        // Coaching points
        if (exercise.coaching_points && exercise.coaching_points.length > 0) {
          doc.font('Helvetica-Bold').text('COACHING WOORDEN:');
          exercise.coaching_points.forEach((point: string) => {
            doc.font('Helvetica').text(`• ${point}`, { indent: 20 });
          });
          doc.moveDown(0.2);
        }
        
        // Progression
        if (exercise.progression && exercise.progression.length > 0) {
          doc.font('Helvetica-Bold').text('PROGRESSIE:');
          exercise.progression.forEach((prog: string, progIndex: number) => {
            doc.font('Helvetica').text(`${progIndex + 1}. ${prog}`, { indent: 20 });
          });
          doc.moveDown(0.2);
        }
        
        // Equipment and field info
        doc.font('Helvetica-Bold').text(`MATERIAAL: `, { continued: true });
        doc.font('Helvetica').text(exercise.equipment.join(', '));
        
        doc.font('Helvetica-Bold').text(`VELDGROOTTE: `, { continued: true });
        doc.font('Helvetica').text(exercise.field_size);
        
        // Separator line
        if (exerciseIndex < phase.exercises.length - 1) {
          doc.moveDown(0.5);
          doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
          doc.moveDown(0.5);
        }
      });
    });
    
    // Footer
    const pages = doc.bufferedPageRange();
    for (let i = 0; i < pages.count; i++) {
      doc.switchToPage(i);
      doc.fontSize(8).font('Helvetica')
         .text('VVC Brasschaat - Professional Training System', 50, doc.page.height - 50, { align: 'center' });
      doc.text(`Pagina ${i + 1} van ${pages.count}`, 50, doc.page.height - 35, { align: 'right' });
    }
    
    doc.end();
    
  } catch (error) {
    console.error('PDF export error:', error);
    res.status(500).json({ message: 'PDF export failed' });
  }
});

export default router;