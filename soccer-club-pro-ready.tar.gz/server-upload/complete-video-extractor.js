import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

class CompleteVideoExtractor {
  constructor() {
    this.videoPath = 'uploads/match-videos/match-video-1750870860329-999699725.mp4';
    this.outputDir = 'uploads/extracted-frames/match-video-1750870860329-999699725';
    this.targetFrames = 3180;
    this.isExtracting = false;
  }

  getCurrentFrameCount() {
    try {
      if (!fs.existsSync(this.outputDir)) {
        fs.mkdirSync(this.outputDir, { recursive: true });
        return 0;
      }
      
      const files = fs.readdirSync(this.outputDir)
        .filter(file => file.startsWith('frame_') && file.endsWith('.jpg'));
      return files.length;
    } catch (error) {
      console.error('Error counting frames:', error);
      return 0;
    }
  }

  async extractAllFrames() {
    if (this.isExtracting) {
      console.log('Extraction already in progress...');
      return;
    }

    this.isExtracting = true;
    const currentFrames = this.getCurrentFrameCount();
    
    console.log(`Starting video extraction from frame ${currentFrames + 1}`);
    console.log(`Target: ${this.targetFrames} total frames`);
    
    // Create output directory
    if (!fs.existsSync(this.outputDir)) {
      fs.mkdirSync(this.outputDir, { recursive: true });
    }

    return new Promise((resolve, reject) => {
      // Extract from minute 9 to 115 (full match)
      const ffmpegArgs = [
        '-y',
        '-i', this.videoPath,
        '-ss', '00:09:00',
        '-t', '01:46:00',
        '-vf', 'fps=0.5',
        '-q:v', '2',
        '-threads', '8',
        path.join(this.outputDir, 'frame_%04d.jpg')
      ];

      console.log('FFmpeg command:', 'ffmpeg', ffmpegArgs.join(' '));

      const ffmpeg = spawn('ffmpeg', ffmpegArgs);

      ffmpeg.stdout.on('data', (data) => {
        console.log(`FFmpeg stdout: ${data}`);
      });

      ffmpeg.stderr.on('data', (data) => {
        const output = data.toString();
        // Log progress indicators
        if (output.includes('frame=')) {
          const frameMatch = output.match(/frame=\s*(\d+)/);
          if (frameMatch) {
            const currentFrame = parseInt(frameMatch[1]);
            const percentage = ((currentFrame / this.targetFrames) * 100).toFixed(1);
            console.log(`Extraction progress: ${currentFrame}/${this.targetFrames} frames (${percentage}%)`);
          }
        }
      });

      ffmpeg.on('close', (code) => {
        this.isExtracting = false;
        const finalCount = this.getCurrentFrameCount();
        const percentage = ((finalCount / this.targetFrames) * 100).toFixed(1);
        
        console.log(`Extraction completed with code ${code}`);
        console.log(`Final frame count: ${finalCount}/${this.targetFrames} (${percentage}%)`);
        
        if (code === 0) {
          resolve({
            success: true,
            frameCount: finalCount,
            percentage: parseFloat(percentage),
            message: `Successfully extracted ${finalCount} frames`
          });
        } else {
          reject(new Error(`FFmpeg exited with code ${code}`));
        }
      });

      ffmpeg.on('error', (error) => {
        this.isExtracting = false;
        console.error('FFmpeg error:', error);
        reject(error);
      });
    });
  }

  getProgress() {
    const currentFrames = this.getCurrentFrameCount();
    const percentage = ((currentFrames / this.targetFrames) * 100).toFixed(1);
    
    return {
      currentFrames,
      targetFrames: this.targetFrames,
      percentage: parseFloat(percentage),
      isExtracting: this.isExtracting,
      isComplete: currentFrames >= this.targetFrames
    };
  }
}

export default CompleteVideoExtractor;