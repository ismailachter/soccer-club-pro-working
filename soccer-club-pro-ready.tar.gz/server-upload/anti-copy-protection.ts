import { Request, Response, NextFunction } from 'express';

export class AntiCopyProtection {
  
  // Disable right-click, text selection, copy-paste for all clients
  static injectClientProtection = (req: Request, res: Response, next: NextFunction) => {
    // Add security headers
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'");
    
    // Disable caching of sensitive content
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    
    next();
  };

  // Block development tools and inspection
  static blockDevTools = `
    <script>
    (function() {
      'use strict';
      
      // Disable right-click context menu
      document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      });
      
      // Disable text selection
      document.addEventListener('selectstart', function(e) {
        e.preventDefault();
        return false;
      });
      
      // Disable drag and drop
      document.addEventListener('dragstart', function(e) {
        e.preventDefault();
        return false;
      });
      
      // Disable keyboard shortcuts
      document.addEventListener('keydown', function(e) {
        // F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, Ctrl+S, Ctrl+A, Ctrl+C, Ctrl+V
        if (e.keyCode === 123 || 
            (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) ||
            (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83 || e.keyCode === 65 || e.keyCode === 67 || e.keyCode === 86))) {
          e.preventDefault();
          e.stopPropagation();
          alert('Deze functie is uitgeschakeld voor beveiliging.');
          return false;
        }
      });
      
      // Detect developer tools
      let devtools = {open: false, orientation: null};
      const threshold = 160;
      
      setInterval(function() {
        if (window.outerHeight - window.innerHeight > threshold || 
            window.outerWidth - window.innerWidth > threshold) {
          if (!devtools.open) {
            devtools.open = true;
            alert('Developer tools gedetecteerd. Toegang wordt geblokkeerd.');
            window.location.href = '/access-denied';
          }
        } else {
          devtools.open = false;
        }
      }, 500);
      
      // Disable console
      if (typeof console !== 'undefined') {
        console.log = function() {};
        console.warn = function() {};
        console.error = function() {};
        console.info = function() {};
        console.debug = function() {};
        console.clear = function() {};
      }
      
      // Clear console periodically
      setInterval(function() {
        if (typeof console !== 'undefined' && console.clear) {
          console.clear();
        }
      }, 1000);
      
      // Disable view source
      if (document.location.href.includes('view-source:')) {
        window.location.href = '/access-denied';
      }
      
      // Block print
      window.addEventListener('beforeprint', function(e) {
        e.preventDefault();
        alert('Printen is niet toegestaan.');
        return false;
      });
      
      // Watermark overlay
      function addWatermark() {
        const watermark = document.createElement('div');
        watermark.style.cssText = \`
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 9999;
          background-image: repeating-linear-gradient(
            45deg,
            transparent,
            transparent 100px,
            rgba(0,0,0,0.02) 100px,
            rgba(0,0,0,0.02) 120px
          );
          font-family: Arial, sans-serif;
          font-size: 12px;
          color: rgba(0,0,0,0.1);
          overflow: hidden;
        \`;
        
        watermark.innerHTML = \`
          <div style="transform: rotate(-45deg); position: absolute; top: 50%; left: 50%; 
                      transform: translate(-50%, -50%) rotate(-45deg); white-space: nowrap;
                      font-size: 20px; font-weight: bold;">
            SOCCER CLUB PRO - GEEN KOPIE TOEGESTAAN - LICENTIE VEREIST
          </div>
        \`;
        
        document.body.appendChild(watermark);
      }
      
      // Add watermark when page loads
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', addWatermark);
      } else {
        addWatermark();
      }
      
    })();
    </script>
  `;

  // Block screenshot tools and screen recording
  static blockScreenCapture = `
    <script>
    (function() {
      // Detect screen recording/capture attempts
      if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
        const originalGetDisplayMedia = navigator.mediaDevices.getDisplayMedia;
        navigator.mediaDevices.getDisplayMedia = function() {
          alert('Schermopname is niet toegestaan voor deze applicatie.');
          throw new Error('Screen capture blocked by Soccer Club Pro');
        };
      }
      
      // Block screenshots via keyboard
      document.addEventListener('keydown', function(e) {
        // Print Screen, Alt+Print Screen
        if (e.keyCode === 44 || (e.altKey && e.keyCode === 44)) {
          e.preventDefault();
          alert('Screenshots zijn niet toegestaan.');
          return false;
        }
      });
      
      // Blur content when window loses focus (potential screenshot)
      let blurTimeout;
      window.addEventListener('blur', function() {
        document.body.style.filter = 'blur(10px)';
        clearTimeout(blurTimeout);
        blurTimeout = setTimeout(function() {
          document.body.style.filter = 'none';
        }, 2000);
      });
      
      window.addEventListener('focus', function() {
        clearTimeout(blurTimeout);
        document.body.style.filter = 'none';
      });
      
    })();
    </script>
  `;

  // Terms of Service content protection
  static getTermsOfService(): string {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;">
        <h1>Algemene Voorwaarden - Soccer Club Pro</h1>
        <p><strong>Laatst bijgewerkt: 24 juni 2025</strong></p>
        
        <h2>1. STRIKT VERBOD OP KOPIËREN</h2>
        <div style="background: #fee2e2; border-left: 4px solid #dc2626; padding: 15px; margin: 20px 0;">
          <p><strong>ABSOLUT VERBODEN:</strong></p>
          <ul>
            <li>Het kopiëren, dupliceren of reproduceren van enige content, data, code, ontwerp of functionaliteit</li>
            <li>Het maken van screenshots, schermopnames of prints van de applicatie</li>
            <li>Het downloaden, extraheren of exporteren van applicatiedata (behalve eigen spelersdata in Excel)</li>
            <li>Het reverse-engineeren, decompileren of analyseren van de software</li>
            <li>Het gebruik van geautomatiseerde tools (bots, scrapers, API calls) om data te extraheren</li>
            <li>Het delen van toegangsgegevens met derden</li>
            <li>Het creëren van backups of kopieën van het systeem</li>
          </ul>
        </div>
        
        <h2>2. EIGENDOMSRECHTEN</h2>
        <p>Alle intellectuele eigendomsrechten van Soccer Club Pro, inclusief maar niet beperkt tot:</p>
        <ul>
          <li>IADATABANK met 196+ trainingselementen</li>
          <li>Software code en architectuur</li>
          <li>Database structuren en schema's</li>
          <li>UI/UX ontwerp en layouts</li>
          <li>Algoritmes en business logic</li>
          <li>PDF, Excel en andere export functionaliteiten</li>
        </ul>
        <p>zijn eigendom van Soccer Club Pro en worden beschermd door auteursrecht.</p>
        
        <h2>3. TOEGESTANE GEBRUIKSRECHTEN</h2>
        <p>Als betalende klant krijgt u <strong>ALLEEN</strong> het recht om:</p>
        <ul>
          <li>De software te gebruiken voor uw eigen clubmanagement</li>
          <li>Uw eigen spelersdata te exporteren in Excel formaat</li>
          <li>Gebruik te maken van de functionaliteiten waarvoor u betaalt</li>
          <li>De virtuele assistant te raadplegen voor ondersteuning</li>
        </ul>
        
        <h2>4. BEVEILIGING EN MONITORING</h2>
        <p>Soccer Club Pro implementeert actieve beveiligingsmaatregelen:</p>
        <ul>
          <li>Real-time monitoring van verdachte activiteiten</li>
          <li>Automatische blokkering van kopieer- en downloadpogingen</li>
          <li>Logging van alle gebruikersacties</li>
          <li>Watermarks op alle gegenereerde content</li>
          <li>Rate limiting en toegangscontrole</li>
        </ul>
        
        <h2>5. SANCTIES BIJ OVERTREDING</h2>
        <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0;">
          <p><strong>Bij overtreding van deze voorwaarden:</strong></p>
          <ul>
            <li>Onmiddellijke beëindiging van toegang zonder terugbetaling</li>
            <li>Juridische stappen wegens inbreuk op intellectuele eigendomsrechten</li>
            <li>Schadevergoeding van minimaal €10.000 per incident</li>
            <li>Permanente blokkering van toekomstige toegang</li>
          </ul>
        </div>
        
        <h2>6. SPECIALE STATUS VVC BRASSCHAAT</h2>
        <p>VVC Brasschaat heeft als pilootproject speciale rechten en volledige gratis toegang tot alle functionaliteiten. Deze status is niet overdraagbaar.</p>
        
        <h2>7. TECHNISCHE BEPERKINGEN</h2>
        <p>Het systeem implementeert automatische beperkingen:</p>
        <ul>
          <li>Blokkering van developer tools en console toegang</li>
          <li>Uitschakeling van right-click, copy-paste en text selectie</li>
          <li>Preventie van screenshots en schermopnames</li>
          <li>Detectie van geautomatiseerde toegang</li>
        </ul>
        
        <h2>8. CONTACT EN ONDERSTEUNING</h2>
        <p>Voor vragen over deze voorwaarden:</p>
        <p>Email: <a href="mailto:info@soccerclubpro.com">info@soccerclubpro.com</a></p>
        <p>Website: <a href="https://soccerclubpro.com">www.soccerclubpro.com</a></p>
        
        <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 30px 0;">
          <p><strong>Door gebruik te maken van Soccer Club Pro accepteert u deze voorwaarden volledig.</strong></p>
        </div>
      </div>
    `;
  }

  // Inject protection into HTML responses
  static injectProtectionScripts(html: string): string {
    return html.replace(
      '</head>',
      `${this.blockDevTools}${this.blockScreenCapture}</head>`
    );
  }
}

// Middleware to inject protection
export const injectAntiCopyProtection = (req: Request, res: Response, next: NextFunction) => {
  const originalSend = res.send;
  
  res.send = function(data) {
    if (typeof data === 'string' && data.includes('<html>')) {
      data = AntiCopyProtection.injectProtectionScripts(data);
    }
    return originalSend.call(this, data);
  };
  
  AntiCopyProtection.injectClientProtection(req, res, next);
};