import { Express, Request, Response } from 'express';
import { Server } from 'http';
import { createServer } from 'vite';
import { db } from '../shared/database';
import { storage } from './storage';
import { sql } from 'drizzle-orm';

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = app;

  // IADATABANK - Elements Route (authentic data restored from user's backup)
  apiRouter.get('/api/iadatabank/elements', async (req, res) => {
    try {
      // Direct load from restored iadatabank_elements table
      const dbElements = await db.execute(sql`SELECT * FROM iadatabank_elements ORDER BY id`);
      
      const allElements = dbElements.rows.map((row: any) => ({
        id: row.key,
        key: row.key,
        name: row.name,
        topic: row.topic,
        subtopic: row.subtopic,
        theme: row.theme,
        progressions: typeof row.progressions === 'string' ? JSON.parse(row.progressions) : row.progressions
      }));

      console.log(`✅ Serving ${allElements.length} IADATABANK elements from database`);
      
      res.json({ 
        data: allElements,
        total: allElements.length,
        categories: {
          BASICS: allElements.filter(el => el.topic === 'BASICS').length,
          TEAMTACTISCH: allElements.filter(el => el.topic === 'TEAMTACTISCH').length,
          FYSIEK: allElements.filter(el => el.topic === 'FYSIEK').length,
          MENTAAL: allElements.filter(el => el.topic === 'MENTAAL').length
        }
      });
    } catch (error) {
      console.error('Error fetching all IADATABANK elements:', error);
      res.status(500).json({ message: 'Failed to load IADATABANK elements', error: (error as Error).message });
    }
  });

  // Keep the rest from the backup
  const httpServer = createServer(app);
  return httpServer;
}