import {
  users, teams, players, coaches, parents, pitches, coordinators, trainers, matches, trainingSessions, attendance, userTeams,
  feeCategories, userFees, payments, paymentPlans, paymentPlanInstallments, clubs,
  type User, type InsertUser,
  type Team, type InsertTeam,
  type Player, type InsertPlayer,
  type Coach, type InsertCoach,
  type Parent, type InsertParent,
  type Pitch, type InsertPitch,
  type Coordinator, type InsertCoordinator,
  type Trainer, type InsertTrainer,
  type Match, type InsertMatch,
  type TrainingSession, type InsertTrainingSession,
  type Attendance, type InsertAttendance,
  type UserTeam, type InsertUserTeam,
  type FeeCategory, type InsertFeeCategory,
  type UserFee, type InsertUserFee,
  type Payment, type InsertPayment,
  type PaymentPlan, type InsertPaymentPlan,
  type PaymentPlanInstallment, type InsertPaymentPlanInstallment,
  type Club, type InsertClub
} from "@shared/schema";
import { db } from "./db";
import { eq, and, isNull, desc } from "drizzle-orm";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsers(role?: string): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  // Authentication and invitation
  updateUserPassword(id: number, password: string): Promise<boolean>;
  updateUserResetToken(email: string, token: string, expires: Date): Promise<boolean>;
  updateStripeCustomerId(id: number, customerId: string): Promise<User>;
  verifyUserEmail(token: string): Promise<boolean>;
  getUserByResetToken(token: string): Promise<User | undefined>;
  
  // Club management
  getClub(id: number): Promise<Club | undefined>;
  getClubs(status?: string): Promise<Club[]>;
  createClub(club: InsertClub): Promise<Club>;
  updateClub(id: number, club: Partial<Club>): Promise<Club | undefined>;
  deleteClub(id: number): Promise<boolean>;
  
  // User-Team management
  getUserTeams(userId: number): Promise<UserTeam[]>;
  getTeamUsers(teamId: number, roleType?: string): Promise<UserTeam[]>;
  createUserTeam(userTeam: InsertUserTeam): Promise<UserTeam>;
  updateUserTeam(id: number, userTeam: Partial<UserTeam>): Promise<UserTeam | undefined>;
  deleteUserTeam(id: number): Promise<boolean>;

  // Team management
  getTeam(id: number): Promise<Team | undefined>;
  getTeams(): Promise<Team[]>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: number, team: Partial<Team>): Promise<Team | undefined>;
  deleteTeam(id: number): Promise<boolean>;

  // Player management
  getPlayer(id: number): Promise<Player | undefined>;
  getPlayerByUserId(userId: number): Promise<Player | undefined>;
  getPlayers(teamId?: number): Promise<Player[]>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  updatePlayer(id: number, player: Partial<Player>): Promise<Player | undefined>;
  deletePlayer(id: number): Promise<boolean>;

  // Coach management
  getCoach(id: number): Promise<Coach | undefined>;
  getCoachByUserId(userId: number): Promise<Coach | undefined>;
  getCoaches(): Promise<Coach[]>;
  createCoach(coach: InsertCoach): Promise<Coach>;
  updateCoach(id: number, coach: Partial<Coach>): Promise<Coach | undefined>;
  deleteCoach(id: number): Promise<boolean>;

  // Parent management
  getParent(id: number): Promise<Parent | undefined>;
  getParentByUserId(userId: number): Promise<Parent | undefined>;
  getParents(): Promise<Parent[]>;
  createParent(parent: InsertParent): Promise<Parent>;
  updateParent(id: number, parent: Partial<Parent>): Promise<Parent | undefined>;
  deleteParent(id: number): Promise<boolean>;

  // Pitch management
  getPitch(id: number): Promise<Pitch | undefined>;
  getPitches(): Promise<Pitch[]>;
  createPitch(pitch: InsertPitch): Promise<Pitch>;
  updatePitch(id: number, pitch: Partial<Pitch>): Promise<Pitch | undefined>;
  deletePitch(id: number): Promise<boolean>;

  // Coordinator management
  getCoordinator(id: number): Promise<Coordinator | undefined>;
  getCoordinatorByUserId(userId: number): Promise<Coordinator | undefined>;
  getCoordinators(): Promise<Coordinator[]>;
  createCoordinator(coordinator: InsertCoordinator): Promise<Coordinator>;
  updateCoordinator(id: number, coordinator: Partial<Coordinator>): Promise<Coordinator | undefined>;
  deleteCoordinator(id: number): Promise<boolean>;
  
  // Trainer management
  getTrainer(id: number): Promise<Trainer | undefined>;
  getTrainerByUserId(userId: number): Promise<Trainer | undefined>;
  getTrainers(): Promise<Trainer[]>;
  createTrainer(trainer: InsertTrainer): Promise<Trainer>;
  updateTrainer(id: number, trainer: Partial<Trainer>): Promise<Trainer | undefined>;
  deleteTrainer(id: number): Promise<boolean>;

  // Match management
  getMatch(id: number): Promise<Match | undefined>;
  getMatches(teamId?: number, status?: string): Promise<Match[]>;
  createMatch(match: InsertMatch): Promise<Match>;
  updateMatch(id: number, match: Partial<Match>): Promise<Match | undefined>;
  deleteMatch(id: number): Promise<boolean>;

  // Training session management
  getTrainingSession(id: number): Promise<TrainingSession | undefined>;
  getTrainingSessions(teamId?: number): Promise<TrainingSession[]>;
  createTrainingSession(session: InsertTrainingSession): Promise<TrainingSession>;
  updateTrainingSession(id: number, session: Partial<TrainingSession>): Promise<TrainingSession | undefined>;
  deleteTrainingSession(id: number): Promise<boolean>;

  // Attendance management
  getAttendance(id: number): Promise<Attendance | undefined>;
  getAttendanceBySession(sessionId: number, sessionType: string): Promise<Attendance[]>;
  getAttendanceByPlayer(playerId: number): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendance: Partial<Attendance>): Promise<Attendance | undefined>;
  deleteAttendance(id: number): Promise<boolean>;
  
  // Fee Category management
  getFeeCategory(id: number): Promise<FeeCategory | undefined>;
  getFeeCategories(feeType?: string, teamId?: number, seasonId?: number, isActive?: boolean): Promise<FeeCategory[]>;
  createFeeCategory(feeCategory: InsertFeeCategory): Promise<FeeCategory>;
  updateFeeCategory(id: number, feeCategory: Partial<FeeCategory>): Promise<FeeCategory | undefined>;
  deleteFeeCategory(id: number): Promise<boolean>;
  
  // User Fee management
  getUserFee(id: number): Promise<UserFee | undefined>;
  getUserFees(): Promise<UserFee[]>;
  getUserFeesByUser(userId: number, status?: string): Promise<UserFee[]>;
  getUserFeesByCategory(feeCategoryId: number, status?: string): Promise<UserFee[]>;
  getUserFeesByTeam(teamId: number, status?: string): Promise<UserFee[]>;
  createUserFee(userFee: InsertUserFee): Promise<UserFee>;
  updateUserFee(id: number, userFee: Partial<UserFee>): Promise<UserFee | undefined>;
  deleteUserFee(id: number): Promise<boolean>;
  
  // Payment management
  getPayment(id: number): Promise<Payment | undefined>;
  getPayments(): Promise<Payment[]>;
  getPaymentsByUser(userId: number): Promise<Payment[]>;
  getPaymentsByUserFee(userFeeId: number): Promise<Payment[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: number, payment: Partial<Payment>): Promise<Payment | undefined>;
  deletePayment(id: number): Promise<boolean>;
  
  // Payment Plan management
  getPaymentPlan(id: number): Promise<PaymentPlan | undefined>;
  getPaymentPlansByUser(userId: number): Promise<PaymentPlan[]>;
  getPaymentPlansByUserFee(userFeeId: number): Promise<PaymentPlan[]>;
  createPaymentPlan(paymentPlan: InsertPaymentPlan): Promise<PaymentPlan>;
  updatePaymentPlan(id: number, paymentPlan: Partial<PaymentPlan>): Promise<PaymentPlan | undefined>;
  deletePaymentPlan(id: number): Promise<boolean>;
  
  // Payment Plan Installment management
  getPaymentPlanInstallment(id: number): Promise<PaymentPlanInstallment | undefined>;
  getPaymentPlanInstallmentsByPlan(paymentPlanId: number): Promise<PaymentPlanInstallment[]>;
  getPaymentPlanInstallmentsByStatus(status: string): Promise<PaymentPlanInstallment[]>;
  createPaymentPlanInstallment(installment: InsertPaymentPlanInstallment): Promise<PaymentPlanInstallment>;
  updatePaymentPlanInstallment(id: number, installment: Partial<PaymentPlanInstallment>): Promise<PaymentPlanInstallment | undefined>;
  deletePaymentPlanInstallment(id: number): Promise<boolean>;

  // Training Sessions management
  getTrainingSessions(planId?: number): Promise<TrainingSession[]>;
  createTrainingSession(session: InsertTrainingSession): Promise<TrainingSession>;
  updateTrainingSession(id: number, session: Partial<TrainingSession>): Promise<TrainingSession | undefined>;
  deleteTrainingSession(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private teams: Map<number, Team>;
  private players: Map<number, Player>;
  private coaches: Map<number, Coach>;
  private parents: Map<number, Parent>;
  private pitches: Map<number, Pitch>;
  private coordinators: Map<number, Coordinator>;
  private trainers: Map<number, Trainer>;
  private matches: Map<number, Match>;
  private trainingSessions: Map<number, TrainingSession>;
  private attendances: Map<number, Attendance>;
  private userTeams: Map<number, UserTeam>;
  private feeCategories: Map<number, FeeCategory>;
  private userFees: Map<number, UserFee>;
  private payments: Map<number, Payment>;
  private paymentPlans: Map<number, PaymentPlan>;
  private paymentPlanInstallments: Map<number, PaymentPlanInstallment>;

  // Counter for IDs
  private userIdCounter: number;
  private teamIdCounter: number;
  private playerIdCounter: number;
  private coachIdCounter: number;
  private parentIdCounter: number;
  private pitchIdCounter: number;
  private coordinatorIdCounter: number;
  private trainerIdCounter: number;
  private matchIdCounter: number;
  private trainingSessionIdCounter: number;
  private attendanceIdCounter: number;
  private userTeamIdCounter: number;
  private feeCategoryIdCounter: number;
  private userFeeIdCounter: number;
  private paymentIdCounter: number;
  private paymentPlanIdCounter: number;
  private paymentPlanInstallmentIdCounter: number;

  constructor() {
    this.users = new Map();
    this.teams = new Map();
    this.players = new Map();
    this.coaches = new Map();
    this.parents = new Map();
    this.pitches = new Map();
    this.coordinators = new Map();
    this.trainers = new Map();
    this.matches = new Map();
    this.trainingSessions = new Map();
    this.attendances = new Map();
    this.userTeams = new Map();
    this.feeCategories = new Map();
    this.userFees = new Map();
    this.payments = new Map();
    this.paymentPlans = new Map();
    this.paymentPlanInstallments = new Map();

    this.userIdCounter = 1;
    this.teamIdCounter = 1;
    this.playerIdCounter = 1;
    this.coachIdCounter = 1;
    this.parentIdCounter = 1;
    this.pitchIdCounter = 1;
    this.coordinatorIdCounter = 1;
    this.trainerIdCounter = 1;
    this.matchIdCounter = 1;
    this.trainingSessionIdCounter = 1;
    this.attendanceIdCounter = 1;
    this.userTeamIdCounter = 1;
    this.feeCategoryIdCounter = 1;
    this.userFeeIdCounter = 1;
    this.paymentIdCounter = 1;
    this.paymentPlanIdCounter = 1;
    this.paymentPlanInstallmentIdCounter = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Add sample admin
    const admin: InsertUser = {
      username: 'admin',
      password: 'admin123',
      firstName: 'John',
      lastName: 'Doe',
      email: 'admin@soccerclub.com',
      phone: '555-123-4567',
      role: 'admin',
      address: '123 Main St',
      dateOfBirth: new Date('1985-01-15'),
    };
    this.createUser(admin);

    // Add sample coaches
    const coach1: InsertUser = {
      username: 'coach1',
      password: 'coach123',
      firstName: 'David',
      lastName: 'Miller',
      email: 'david@soccerclub.com',
      phone: '555-234-5678',
      role: 'coach',
      address: '456 Oak Ave',
      dateOfBirth: new Date('1980-05-20'),
    };
    const coachUser1 = this.createUser(coach1);
    
    const coach2: InsertUser = {
      username: 'coach2',
      password: 'coach123',
      firstName: 'Sarah',
      lastName: 'Williams',
      email: 'sarah@soccerclub.com',
      phone: '555-345-6789',
      role: 'coach',
      address: '789 Pine St',
      dateOfBirth: new Date('1982-08-12'),
    };
    const coachUser2 = this.createUser(coach2);

    const coach3: InsertUser = {
      username: 'coach3',
      password: 'coach123',
      firstName: 'James',
      lastName: 'Chen',
      email: 'james@soccerclub.com',
      phone: '555-456-7890',
      role: 'coach',
      address: '101 Maple Dr',
      dateOfBirth: new Date('1979-11-05'),
    };
    const coachUser3 = this.createUser(coach3);

    const coach4: InsertUser = {
      username: 'coach4',
      password: 'coach123',
      firstName: 'Lisa',
      lastName: 'Thompson',
      email: 'lisa@soccerclub.com',
      phone: '555-567-8901',
      role: 'coach',
      address: '202 Elm St',
      dateOfBirth: new Date('1983-04-17'),
    };
    const coachUser4 = this.createUser(coach4);

    // Create coach profiles
    this.createCoach({
      userId: coachUser1.id,
      qualifications: 'UEFA B License',
      experience: '10 years',
      specialization: 'Youth development',
      bio: 'Former professional player with a passion for youth development',
    });

    this.createCoach({
      userId: coachUser2.id,
      qualifications: 'UEFA A License',
      experience: '8 years',
      specialization: 'Tactical training',
      bio: 'Specializes in tactical training and team organization',
    });

    this.createCoach({
      userId: coachUser3.id,
      qualifications: 'USSF C License',
      experience: '12 years',
      specialization: 'Goalkeeping',
      bio: 'Former professional goalkeeper with experience in youth coaching',
    });

    this.createCoach({
      userId: coachUser4.id,
      qualifications: 'USSF D License',
      experience: '6 years',
      specialization: 'Skills development',
      bio: 'Focus on fundamental skills development for young players',
    });

    // Add sample teams
    const team1 = this.createTeam({
      name: 'U14 Lions',
      ageGroup: 'U14',
      description: 'Under 14 competitive team',
      foundedDate: new Date('2020-01-15'),
      primaryCoachId: coachUser1.id,
    });

    const team2 = this.createTeam({
      name: 'U16 Eagles',
      ageGroup: 'U16',
      description: 'Under 16 competitive team',
      foundedDate: new Date('2019-08-10'),
      primaryCoachId: coachUser2.id,
    });

    const team3 = this.createTeam({
      name: 'U12 Tigers',
      ageGroup: 'U12',
      description: 'Under 12 developmental team',
      foundedDate: new Date('2021-03-22'),
      primaryCoachId: coachUser3.id,
    });

    const team4 = this.createTeam({
      name: 'U10 Panthers',
      ageGroup: 'U10',
      description: 'Under 10 recreational team',
      foundedDate: new Date('2022-01-05'),
      primaryCoachId: coachUser4.id,
    });

    // Add sample pitches
    const pitch1 = this.createPitch({
      name: 'Main Field',
      location: '123 Sports Complex, Cityville',
      size: '100m x 64m',
      surface: 'Natural grass',
      status: 'available',
      lastMaintenance: new Date('2023-09-15'),
      nextMaintenance: new Date('2023-10-15'),
    });

    const pitch2 = this.createPitch({
      name: 'Training Field 1',
      location: '123 Sports Complex, Cityville',
      size: '90m x 60m',
      surface: 'Natural grass',
      status: 'in_use',
      lastMaintenance: new Date('2023-09-10'),
      nextMaintenance: new Date('2023-10-10'),
    });

    const pitch3 = this.createPitch({
      name: 'Training Field 2',
      location: '123 Sports Complex, Cityville',
      size: '90m x 60m',
      surface: 'Artificial turf',
      status: 'in_use',
      lastMaintenance: new Date('2023-09-05'),
      nextMaintenance: new Date('2023-10-05'),
    });

    const pitch4 = this.createPitch({
      name: 'Indoor Facility',
      location: '123 Sports Complex, Cityville',
      size: '80m x 50m',
      surface: 'Artificial turf',
      status: 'maintenance',
      maintenanceNotes: 'Replacing turf sections',
      lastMaintenance: new Date('2023-08-20'),
      nextMaintenance: new Date('2023-10-20'),
    });

    // Add sample parents
    const parent1: InsertUser = {
      username: 'parent1',
      password: 'parent123',
      firstName: 'Robert',
      lastName: 'Johnson',
      email: 'robert@example.com',
      phone: '555-987-6543',
      role: 'parent',
      address: '303 Cedar Ln',
      dateOfBirth: new Date('1975-06-22'),
    };
    const parentUser1 = this.createUser(parent1);

    this.createParent({
      userId: parentUser1.id,
      contactPreference: 'email',
      occupation: 'Engineer',
      alternatePhone: '555-111-2222',
    });

    // Add sample trainers
    const trainer1: InsertUser = {
      username: 'trainer1',
      password: 'trainer123',
      firstName: 'Thomas',
      lastName: 'Wilson',
      email: 'thomas@soccerclub.com',
      phone: '555-678-9012',
      role: 'trainer',
      address: '404 Birch St',
      dateOfBirth: new Date('1985-03-10'),
    };
    const trainerUser1 = this.createUser(trainer1);

    const trainer2: InsertUser = {
      username: 'trainer2',
      password: 'trainer123',
      firstName: 'Emily',
      lastName: 'Garcia',
      email: 'emily@soccerclub.com',
      phone: '555-789-0123',
      role: 'trainer',
      address: '505 Walnut Ave',
      dateOfBirth: new Date('1988-07-22'),
    };
    const trainerUser2 = this.createUser(trainer2);

    // Create trainer profiles
    this.createTrainer({
      userId: trainerUser1.id,
      specialization: 'Strength and conditioning',
      qualifications: 'Certified Strength and Conditioning Specialist',
      experience: '8 years',
      bio: 'Specializes in improving athletic performance through strength training',
    });

    this.createTrainer({
      userId: trainerUser2.id,
      specialization: 'Rehabilitation',
      qualifications: 'Sports Rehabilitation Therapist',
      experience: '6 years',
      bio: 'Focused on injury prevention and recovery programs for athletes',
    });

    // Add sample players
    // Create player user accounts first
    const player1: InsertUser = {
      username: 'player1',
      password: 'player123',
      firstName: 'Michael',
      lastName: 'Torres',
      email: 'michael@example.com',
      role: 'player',
      dateOfBirth: new Date('2009-03-15'),
    };
    const playerUser1 = this.createUser(player1);

    const player2: InsertUser = {
      username: 'player2',
      password: 'player123',
      firstName: 'Emma',
      lastName: 'Rodriguez',
      email: 'emma@example.com',
      role: 'player',
      dateOfBirth: new Date('2007-08-20'),
    };
    const playerUser2 = this.createUser(player2);

    const player3: InsertUser = {
      username: 'player3',
      password: 'player123',
      firstName: 'Jack',
      lastName: 'Williams',
      email: 'jack@example.com',
      role: 'player',
      dateOfBirth: new Date('2009-05-10'),
    };
    const playerUser3 = this.createUser(player3);

    const player4: InsertUser = {
      username: 'player4',
      password: 'player123',
      firstName: 'Sophia',
      lastName: 'Chen',
      email: 'sophia@example.com',
      role: 'player',
      dateOfBirth: new Date('2011-11-28'),
    };
    const playerUser4 = this.createUser(player4);

    const player5: InsertUser = {
      username: 'player5',
      password: 'player123',
      firstName: 'Alex',
      lastName: 'Johnson',
      email: 'alex@example.com',
      role: 'player',
      dateOfBirth: new Date('2010-07-05'),
    };
    const playerUser5 = this.createUser(player5);

    // Create player profiles
    this.createPlayer({
      userId: playerUser1.id,
      teamId: team1.id,
      jerseyNumber: 10,
      position: 'forward',
      height: 165,
      weight: 55,
      status: 'active',
      parentId: parentUser1.id,
      statistics: {
        goals: 8,
        assists: 4,
        appearances: 15,
        yellowCards: 2,
        redCards: 0,
        minutesPlayed: 1200
      }
    });

    this.createPlayer({
      userId: playerUser2.id,
      teamId: team2.id,
      jerseyNumber: 7,
      position: 'midfielder',
      height: 170,
      weight: 60,
      status: 'active',
      statistics: {
        goals: 5,
        assists: 9,
        appearances: 16,
        yellowCards: 1,
        redCards: 0,
        minutesPlayed: 1350
      }
    });

    this.createPlayer({
      userId: playerUser3.id,
      teamId: team1.id,
      jerseyNumber: 4,
      position: 'defender',
      height: 168,
      weight: 58,
      status: 'injured',
      statistics: {
        goals: 1,
        assists: 2,
        appearances: 14,
        yellowCards: 3,
        redCards: 0,
        minutesPlayed: 1150
      }
    });

    this.createPlayer({
      userId: playerUser4.id,
      teamId: team3.id,
      jerseyNumber: 1,
      position: 'goalkeeper',
      height: 155,
      weight: 50,
      status: 'active',
      statistics: {
        goals: 0,
        assists: 0,
        appearances: 12,
        yellowCards: 0,
        redCards: 0,
        minutesPlayed: 1080
      }
    });

    this.createPlayer({
      userId: playerUser5.id,
      teamId: team1.id,
      jerseyNumber: 8,
      position: 'midfielder',
      height: 162,
      weight: 53,
      status: 'active',
      statistics: {
        goals: 3,
        assists: 6,
        appearances: 15,
        yellowCards: 1,
        redCards: 0,
        minutesPlayed: 1250
      }
    });

    // Add sample matches
    this.createMatch({
      teamId: team1.id,
      opponentName: 'Westside FC',
      date: new Date('2023-10-12T10:00:00'),
      location: 'home',
      pitchId: pitch1.id,
      status: 'scheduled',
      matchType: 'league',
    });

    this.createMatch({
      teamId: team2.id,
      opponentName: 'East City United',
      date: new Date('2023-10-13T14:30:00'),
      location: 'away',
      status: 'scheduled',
      matchType: 'tournament',
    });

    this.createMatch({
      teamId: team3.id,
      opponentName: 'North FC',
      date: new Date('2023-10-08T11:00:00'),
      location: 'home',
      pitchId: pitch1.id,
      status: 'completed',
      homeScore: 2,
      awayScore: 1,
      matchType: 'league',
    });

    this.createMatch({
      teamId: team4.id,
      opponentName: 'South City Juniors',
      date: new Date('2023-10-07T15:00:00'),
      location: 'away',
      status: 'completed',
      homeScore: 1,
      awayScore: 3,
      matchType: 'friendly',
    });

    // Add sample training sessions
    this.createTrainingSession({
      teamId: team1.id,
      coachId: coachUser1.id,
      pitchId: pitch1.id,
      date: new Date('2023-10-10'),
      startTime: new Date('2023-10-10T17:00:00'),
      endTime: new Date('2023-10-10T18:30:00'),
      focus: 'Passing drills, shooting practice, 5v5 mini-games',
    });

    this.createTrainingSession({
      teamId: team3.id,
      coachId: coachUser3.id,
      pitchId: pitch2.id,
      date: new Date('2023-10-10'),
      startTime: new Date('2023-10-10T16:00:00'),
      endTime: new Date('2023-10-10T17:30:00'),
      focus: 'Dribbling skills, defensive positioning, fast breaks',
    });

    this.createTrainingSession({
      teamId: team2.id,
      coachId: coachUser2.id,
      pitchId: pitch1.id,
      date: new Date('2023-10-11'),
      startTime: new Date('2023-10-11T17:00:00'),
      endTime: new Date('2023-10-11T18:30:00'),
      focus: 'Defensive formation, set pieces',
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async getUsers(role?: string): Promise<User[]> {
    if (role) {
      return Array.from(this.users.values()).filter(user => user.role === role);
    }
    return Array.from(this.users.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  // User-Team management
  async getUserTeams(userId: number): Promise<UserTeam[]> {
    return Array.from(this.userTeams.values()).filter(
      (userTeam) => userTeam.userId === userId
    );
  }
  
  async getTeamUsers(teamId: number, roleType?: string): Promise<UserTeam[]> {
    if (roleType) {
      return Array.from(this.userTeams.values()).filter(
        (userTeam) => userTeam.teamId === teamId && userTeam.roleType === roleType
      );
    }
    return Array.from(this.userTeams.values()).filter(
      (userTeam) => userTeam.teamId === teamId
    );
  }
  
  async createUserTeam(insertUserTeam: InsertUserTeam): Promise<UserTeam> {
    const id = this.userTeamIdCounter++;
    const now = new Date();
    const userTeam: UserTeam = { ...insertUserTeam, id, createdAt: now };
    this.userTeams.set(id, userTeam);
    return userTeam;
  }
  
  async updateUserTeam(id: number, userTeamData: Partial<UserTeam>): Promise<UserTeam | undefined> {
    const userTeam = this.userTeams.get(id);
    if (!userTeam) return undefined;
    
    const updatedUserTeam = { ...userTeam, ...userTeamData };
    this.userTeams.set(id, updatedUserTeam);
    return updatedUserTeam;
  }
  
  async deleteUserTeam(id: number): Promise<boolean> {
    return this.userTeams.delete(id);
  }

  // Team methods
  async getTeam(id: number): Promise<Team | undefined> {
    return this.teams.get(id);
  }

  async getTeams(): Promise<Team[]> {
    return Array.from(this.teams.values());
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const id = this.teamIdCounter++;
    const now = new Date();
    const team: Team = { ...insertTeam, id, createdAt: now };
    this.teams.set(id, team);
    return team;
  }

  async updateTeam(id: number, teamData: Partial<Team>): Promise<Team | undefined> {
    const team = this.teams.get(id);
    if (!team) return undefined;
    
    const updatedTeam = { ...team, ...teamData };
    this.teams.set(id, updatedTeam);
    return updatedTeam;
  }

  async deleteTeam(id: number): Promise<boolean> {
    return this.teams.delete(id);
  }

  // Player methods
  async getPlayer(id: number): Promise<Player | undefined> {
    return this.players.get(id);
  }

  async getPlayerByUserId(userId: number): Promise<Player | undefined> {
    return Array.from(this.players.values()).find(player => player.userId === userId);
  }

  async getPlayers(teamId?: number): Promise<Player[]> {
    if (teamId) {
      return Array.from(this.players.values()).filter(player => player.teamId === teamId);
    }
    return Array.from(this.players.values());
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = this.playerIdCounter++;
    const now = new Date();
    const player: Player = { ...insertPlayer, id, createdAt: now };
    this.players.set(id, player);
    return player;
  }

  async updatePlayer(id: number, playerData: Partial<Player>): Promise<Player | undefined> {
    const player = this.players.get(id);
    if (!player) return undefined;
    
    const updatedPlayer = { ...player, ...playerData };
    this.players.set(id, updatedPlayer);
    return updatedPlayer;
  }

  async deletePlayer(id: number): Promise<boolean> {
    return this.players.delete(id);
  }

  // Coach methods
  async getCoach(id: number): Promise<Coach | undefined> {
    return this.coaches.get(id);
  }

  async getCoachByUserId(userId: number): Promise<Coach | undefined> {
    return Array.from(this.coaches.values()).find(coach => coach.userId === userId);
  }

  async getCoaches(): Promise<Coach[]> {
    return Array.from(this.coaches.values());
  }

  async createCoach(insertCoach: InsertCoach): Promise<Coach> {
    const id = this.coachIdCounter++;
    const now = new Date();
    const coach: Coach = { ...insertCoach, id, createdAt: now };
    this.coaches.set(id, coach);
    return coach;
  }

  async updateCoach(id: number, coachData: Partial<Coach>): Promise<Coach | undefined> {
    const coach = this.coaches.get(id);
    if (!coach) return undefined;
    
    const updatedCoach = { ...coach, ...coachData };
    this.coaches.set(id, updatedCoach);
    return updatedCoach;
  }

  async deleteCoach(id: number): Promise<boolean> {
    return this.coaches.delete(id);
  }

  // Trainer methods
  async getTrainer(id: number): Promise<Trainer | undefined> {
    return this.trainers.get(id);
  }

  async getTrainerByUserId(userId: number): Promise<Trainer | undefined> {
    return Array.from(this.trainers.values()).find(trainer => trainer.userId === userId);
  }

  async getTrainers(): Promise<Trainer[]> {
    return Array.from(this.trainers.values());
  }

  async createTrainer(insertTrainer: InsertTrainer): Promise<Trainer> {
    const id = this.trainerIdCounter++;
    const now = new Date();
    const trainer: Trainer = { ...insertTrainer, id, createdAt: now };
    this.trainers.set(id, trainer);
    return trainer;
  }

  async updateTrainer(id: number, trainerData: Partial<Trainer>): Promise<Trainer | undefined> {
    const trainer = this.trainers.get(id);
    if (!trainer) return undefined;
    
    const updatedTrainer = { ...trainer, ...trainerData };
    this.trainers.set(id, updatedTrainer);
    return updatedTrainer;
  }

  async deleteTrainer(id: number): Promise<boolean> {
    return this.trainers.delete(id);
  }

  // Parent methods
  async getParent(id: number): Promise<Parent | undefined> {
    return this.parents.get(id);
  }

  async getParentByUserId(userId: number): Promise<Parent | undefined> {
    return Array.from(this.parents.values()).find(parent => parent.userId === userId);
  }

  async getParents(): Promise<Parent[]> {
    return Array.from(this.parents.values());
  }

  async createParent(insertParent: InsertParent): Promise<Parent> {
    const id = this.parentIdCounter++;
    const now = new Date();
    const parent: Parent = { ...insertParent, id, createdAt: now };
    this.parents.set(id, parent);
    return parent;
  }

  async updateParent(id: number, parentData: Partial<Parent>): Promise<Parent | undefined> {
    const parent = this.parents.get(id);
    if (!parent) return undefined;
    
    const updatedParent = { ...parent, ...parentData };
    this.parents.set(id, updatedParent);
    return updatedParent;
  }

  async deleteParent(id: number): Promise<boolean> {
    return this.parents.delete(id);
  }

  // Pitch methods
  async getPitch(id: number): Promise<Pitch | undefined> {
    return this.pitches.get(id);
  }

  async getPitches(): Promise<Pitch[]> {
    return Array.from(this.pitches.values());
  }

  async createPitch(insertPitch: InsertPitch): Promise<Pitch> {
    const id = this.pitchIdCounter++;
    const now = new Date();
    const pitch: Pitch = { ...insertPitch, id, createdAt: now };
    this.pitches.set(id, pitch);
    return pitch;
  }

  async updatePitch(id: number, pitchData: Partial<Pitch>): Promise<Pitch | undefined> {
    const pitch = this.pitches.get(id);
    if (!pitch) return undefined;
    
    const updatedPitch = { ...pitch, ...pitchData };
    this.pitches.set(id, updatedPitch);
    return updatedPitch;
  }

  async deletePitch(id: number): Promise<boolean> {
    return this.pitches.delete(id);
  }

  // Coordinator methods
  async getCoordinator(id: number): Promise<Coordinator | undefined> {
    return this.coordinators.get(id);
  }

  async getCoordinatorByUserId(userId: number): Promise<Coordinator | undefined> {
    return Array.from(this.coordinators.values()).find(coord => coord.userId === userId);
  }

  async getCoordinators(): Promise<Coordinator[]> {
    return Array.from(this.coordinators.values());
  }

  async createCoordinator(insertCoordinator: InsertCoordinator): Promise<Coordinator> {
    const id = this.coordinatorIdCounter++;
    const now = new Date();
    const coordinator: Coordinator = { ...insertCoordinator, id, createdAt: now };
    this.coordinators.set(id, coordinator);
    return coordinator;
  }

  async updateCoordinator(id: number, coordData: Partial<Coordinator>): Promise<Coordinator | undefined> {
    const coordinator = this.coordinators.get(id);
    if (!coordinator) return undefined;
    
    const updatedCoordinator = { ...coordinator, ...coordData };
    this.coordinators.set(id, updatedCoordinator);
    return updatedCoordinator;
  }

  async deleteCoordinator(id: number): Promise<boolean> {
    return this.coordinators.delete(id);
  }

  // Match methods
  async getMatch(id: number): Promise<Match | undefined> {
    return this.matches.get(id);
  }

  async getMatches(teamId?: number, status?: string): Promise<Match[]> {
    let filtered = Array.from(this.matches.values());
    
    if (teamId) {
      filtered = filtered.filter(match => match.teamId === teamId);
    }
    
    if (status) {
      filtered = filtered.filter(match => match.status === status);
    }
    
    return filtered;
  }

  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = this.matchIdCounter++;
    const now = new Date();
    const match: Match = { ...insertMatch, id, createdAt: now };
    this.matches.set(id, match);
    return match;
  }

  async updateMatch(id: number, matchData: Partial<Match>): Promise<Match | undefined> {
    const match = this.matches.get(id);
    if (!match) return undefined;
    
    const updatedMatch = { ...match, ...matchData };
    this.matches.set(id, updatedMatch);
    return updatedMatch;
  }

  async deleteMatch(id: number): Promise<boolean> {
    return this.matches.delete(id);
  }

  // Training session methods
  async getTrainingSession(id: number): Promise<TrainingSession | undefined> {
    return this.trainingSessions.get(id);
  }

  async getTrainingSessions(teamId?: number): Promise<TrainingSession[]> {
    if (teamId) {
      return Array.from(this.trainingSessions.values()).filter(session => session.teamId === teamId);
    }
    return Array.from(this.trainingSessions.values());
  }

  async createTrainingSession(insertSession: InsertTrainingSession): Promise<TrainingSession> {
    const id = this.trainingSessionIdCounter++;
    const now = new Date();
    const session: TrainingSession = { ...insertSession, id, createdAt: now };
    this.trainingSessions.set(id, session);
    return session;
  }

  async updateTrainingSession(id: number, sessionData: Partial<TrainingSession>): Promise<TrainingSession | undefined> {
    const session = this.trainingSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...sessionData };
    this.trainingSessions.set(id, updatedSession);
    return updatedSession;
  }

  async deleteTrainingSession(id: number): Promise<boolean> {
    return this.trainingSessions.delete(id);
  }

  // Attendance methods
  async getAttendance(id: number): Promise<Attendance | undefined> {
    return this.attendances.get(id);
  }

  async getAttendanceBySession(sessionId: number, sessionType: string): Promise<Attendance[]> {
    return Array.from(this.attendances.values()).filter(
      attendance => attendance.sessionId === sessionId && attendance.sessionType === sessionType
    );
  }

  async getAttendanceByPlayer(playerId: number): Promise<Attendance[]> {
    return Array.from(this.attendances.values()).filter(
      attendance => attendance.playerId === playerId
    );
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = this.attendanceIdCounter++;
    const now = new Date();
    const attendance: Attendance = { ...insertAttendance, id, createdAt: now };
    this.attendances.set(id, attendance);
    return attendance;
  }

  async updateAttendance(id: number, attendanceData: Partial<Attendance>): Promise<Attendance | undefined> {
    const attendance = this.attendances.get(id);
    if (!attendance) return undefined;
    
    const updatedAttendance = { ...attendance, ...attendanceData };
    this.attendances.set(id, updatedAttendance);
    return updatedAttendance;
  }

  async deleteAttendance(id: number): Promise<boolean> {
    return this.attendances.delete(id);
  }

  // Fee Category Management
  async getFeeCategory(id: number): Promise<FeeCategory | undefined> {
    return this.feeCategories.get(id);
  }

  async getFeeCategories(feeType?: string, teamId?: number, seasonId?: number, isActive?: boolean): Promise<FeeCategory[]> {
    const categories = Array.from(this.feeCategories.values());
    
    return categories.filter(cat => {
      if (feeType && cat.feeType !== feeType) return false;
      if (teamId && cat.teamId !== teamId) return false;
      if (seasonId && cat.seasonId !== seasonId) return false;
      if (isActive !== undefined && cat.isActive !== isActive) return false;
      return true;
    });
  }

  async createFeeCategory(feeCategory: InsertFeeCategory): Promise<FeeCategory> {
    const id = this.feeCategoryIdCounter++;
    const newFeeCategory: FeeCategory = {
      id,
      createdAt: new Date(),
      ...feeCategory
    };
    this.feeCategories.set(id, newFeeCategory);
    return newFeeCategory;
  }

  async updateFeeCategory(id: number, feeCategory: Partial<FeeCategory>): Promise<FeeCategory | undefined> {
    const existingFeeCategory = this.feeCategories.get(id);
    if (!existingFeeCategory) {
      return undefined;
    }
    
    const updatedFeeCategory = {
      ...existingFeeCategory,
      ...feeCategory
    };
    this.feeCategories.set(id, updatedFeeCategory);
    return updatedFeeCategory;
  }

  async deleteFeeCategory(id: number): Promise<boolean> {
    if (!this.feeCategories.has(id)) {
      return false;
    }
    this.feeCategories.delete(id);
    return true;
  }

  // User Fee Management
  async getUserFee(id: number): Promise<UserFee | undefined> {
    return this.userFees.get(id);
  }

  async getUserFees(): Promise<UserFee[]> {
    return Array.from(this.userFees.values());
  }

  async getUserFeesByUser(userId: number, status?: string): Promise<UserFee[]> {
    const fees = Array.from(this.userFees.values());
    
    return fees.filter(fee => {
      if (fee.userId !== userId) return false;
      if (status && fee.status !== status) return false;
      return true;
    });
  }

  async getUserFeesByCategory(feeCategoryId: number, status?: string): Promise<UserFee[]> {
    const fees = Array.from(this.userFees.values());
    
    return fees.filter(fee => {
      if (fee.feeCategoryId !== feeCategoryId) return false;
      if (status && fee.status !== status) return false;
      return true;
    });
  }

  async getUserFeesByTeam(teamId: number, status?: string): Promise<UserFee[]> {
    const fees = Array.from(this.userFees.values());
    const feeCategories = await this.getFeeCategories(undefined, teamId);
    const categoryIds = feeCategories.map(cat => cat.id);
    
    return fees.filter(fee => {
      if (!categoryIds.includes(fee.feeCategoryId)) return false;
      if (status && fee.status !== status) return false;
      return true;
    });
  }

  async createUserFee(userFee: InsertUserFee): Promise<UserFee> {
    const id = this.userFeeIdCounter++;
    const newUserFee: UserFee = {
      id,
      createdAt: new Date(),
      ...userFee
    };
    this.userFees.set(id, newUserFee);
    return newUserFee;
  }

  async updateUserFee(id: number, userFee: Partial<UserFee>): Promise<UserFee | undefined> {
    const existingUserFee = this.userFees.get(id);
    if (!existingUserFee) {
      return undefined;
    }
    
    const updatedUserFee = {
      ...existingUserFee,
      ...userFee
    };
    this.userFees.set(id, updatedUserFee);
    return updatedUserFee;
  }

  async deleteUserFee(id: number): Promise<boolean> {
    if (!this.userFees.has(id)) {
      return false;
    }
    this.userFees.delete(id);
    return true;
  }

  // Payment Management
  async getPayment(id: number): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async getPayments(): Promise<Payment[]> {
    return Array.from(this.payments.values());
  }

  async getPaymentsByUser(userId: number): Promise<Payment[]> {
    const payments = Array.from(this.payments.values());
    
    return payments.filter(payment => {
      return payment.userId === userId;
    });
  }

  async getPaymentsByUserFee(userFeeId: number): Promise<Payment[]> {
    const payments = Array.from(this.payments.values());
    
    return payments.filter(payment => {
      return payment.userFeeId === userFeeId;
    });
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const id = this.paymentIdCounter++;
    const newPayment: Payment = {
      id,
      createdAt: new Date(),
      ...payment
    };
    this.payments.set(id, newPayment);
    return newPayment;
  }

  async updatePayment(id: number, payment: Partial<Payment>): Promise<Payment | undefined> {
    const existingPayment = this.payments.get(id);
    if (!existingPayment) {
      return undefined;
    }
    
    const updatedPayment = {
      ...existingPayment,
      ...payment
    };
    this.payments.set(id, updatedPayment);
    return updatedPayment;
  }

  async deletePayment(id: number): Promise<boolean> {
    if (!this.payments.has(id)) {
      return false;
    }
    this.payments.delete(id);
    return true;
  }

  // Payment Plan Management
  async getPaymentPlan(id: number): Promise<PaymentPlan | undefined> {
    return this.paymentPlans.get(id);
  }

  async getPaymentPlansByUser(userId: number): Promise<PaymentPlan[]> {
    const plans = Array.from(this.paymentPlans.values());
    
    return plans.filter(plan => {
      return plan.userId === userId;
    });
  }

  async getPaymentPlansByUserFee(userFeeId: number): Promise<PaymentPlan[]> {
    const plans = Array.from(this.paymentPlans.values());
    
    return plans.filter(plan => {
      return plan.userFeeId === userFeeId;
    });
  }

  async createPaymentPlan(paymentPlan: InsertPaymentPlan): Promise<PaymentPlan> {
    const id = this.paymentPlanIdCounter++;
    const newPaymentPlan: PaymentPlan = {
      id,
      createdAt: new Date(),
      ...paymentPlan
    };
    this.paymentPlans.set(id, newPaymentPlan);
    return newPaymentPlan;
  }

  async updatePaymentPlan(id: number, paymentPlan: Partial<PaymentPlan>): Promise<PaymentPlan | undefined> {
    const existingPaymentPlan = this.paymentPlans.get(id);
    if (!existingPaymentPlan) {
      return undefined;
    }
    
    const updatedPaymentPlan = {
      ...existingPaymentPlan,
      ...paymentPlan
    };
    this.paymentPlans.set(id, updatedPaymentPlan);
    return updatedPaymentPlan;
  }

  async deletePaymentPlan(id: number): Promise<boolean> {
    if (!this.paymentPlans.has(id)) {
      return false;
    }
    this.paymentPlans.delete(id);
    return true;
  }

  // Payment Plan Installment Management
  async getPaymentPlanInstallment(id: number): Promise<PaymentPlanInstallment | undefined> {
    return this.paymentPlanInstallments.get(id);
  }

  async getPaymentPlanInstallmentsByPlan(paymentPlanId: number): Promise<PaymentPlanInstallment[]> {
    const installments = Array.from(this.paymentPlanInstallments.values());
    
    return installments.filter(installment => {
      return installment.paymentPlanId === paymentPlanId;
    });
  }

  async getPaymentPlanInstallmentsByStatus(status: string): Promise<PaymentPlanInstallment[]> {
    const installments = Array.from(this.paymentPlanInstallments.values());
    
    return installments.filter(installment => {
      return installment.status === status;
    });
  }

  async createPaymentPlanInstallment(installment: InsertPaymentPlanInstallment): Promise<PaymentPlanInstallment> {
    const id = this.paymentPlanInstallmentIdCounter++;
    const newInstallment: PaymentPlanInstallment = {
      id,
      createdAt: new Date(),
      ...installment
    };
    this.paymentPlanInstallments.set(id, newInstallment);
    return newInstallment;
  }

  async updatePaymentPlanInstallment(id: number, installment: Partial<PaymentPlanInstallment>): Promise<PaymentPlanInstallment | undefined> {
    const existingInstallment = this.paymentPlanInstallments.get(id);
    if (!existingInstallment) {
      return undefined;
    }
    
    const updatedInstallment = {
      ...existingInstallment,
      ...installment
    };
    this.paymentPlanInstallments.set(id, updatedInstallment);
    return updatedInstallment;
  }

  async deletePaymentPlanInstallment(id: number): Promise<boolean> {
    if (!this.paymentPlanInstallments.has(id)) {
      return false;
    }
    this.paymentPlanInstallments.delete(id);
    return true;
  }
}

export class DatabaseStorage implements IStorage {
  // User management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  // User-Team management
  async getUserTeams(userId: number): Promise<UserTeam[]> {
    return db.select().from(userTeams).where(eq(userTeams.userId, userId));
  }
  
  async getTeamUsers(teamId: number, roleType?: string): Promise<UserTeam[]> {
    if (roleType) {
      return db.select().from(userTeams).where(
        and(
          eq(userTeams.teamId, teamId),
          eq(userTeams.roleType, roleType)
        )
      );
    }
    return db.select().from(userTeams).where(eq(userTeams.teamId, teamId));
  }
  
  async createUserTeam(userTeam: InsertUserTeam): Promise<UserTeam> {
    const [insertedUserTeam] = await db.insert(userTeams).values(userTeam).returning();
    return insertedUserTeam;
  }
  
  async updateUserTeam(id: number, userTeam: Partial<UserTeam>): Promise<UserTeam | undefined> {
    const [updatedUserTeam] = await db
      .update(userTeams)
      .set(userTeam)
      .where(eq(userTeams.id, id))
      .returning();
    return updatedUserTeam || undefined;
  }
  
  async deleteUserTeam(id: number): Promise<boolean> {
    const result = await db.delete(userTeams).where(eq(userTeams.id, id));
    return result.rowCount > 0;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUsers(role?: string): Promise<User[]> {
    if (role) {
      return db.select().from(users).where(eq(users.role, role as any));
    }
    return db.select().from(users);
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values({
      ...user,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set({
        ...userData,
        lastModifiedDate: new Date()
      })
      .where(eq(users.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return true;
  }

  // Team management
  async getTeam(id: number): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team || undefined;
  }

  async getTeams(): Promise<Team[]> {
    return db.select().from(teams);
  }

  async createTeam(team: InsertTeam): Promise<Team> {
    const [created] = await db.insert(teams).values({
      ...team,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateTeam(id: number, teamData: Partial<Team>): Promise<Team | undefined> {
    const [updated] = await db.update(teams)
      .set(teamData)
      .where(eq(teams.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteTeam(id: number): Promise<boolean> {
    const result = await db.delete(teams).where(eq(teams.id, id));
    return true;
  }

  // Player management
  async getPlayer(id: number): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.id, id));
    return player || undefined;
  }

  async getPlayerByUserId(userId: number): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.userId, userId));
    return player || undefined;
  }

  async getPlayers(teamId?: number): Promise<Player[]> {
    if (teamId) {
      return db.select().from(players).where(eq(players.teamId, teamId));
    }
    return db.select().from(players);
  }

  async createPlayer(player: InsertPlayer): Promise<Player> {
    const [created] = await db.insert(players).values({
      ...player,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updatePlayer(id: number, playerData: Partial<Player>): Promise<Player | undefined> {
    const [updated] = await db.update(players)
      .set(playerData)
      .where(eq(players.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePlayer(id: number): Promise<boolean> {
    const result = await db.delete(players).where(eq(players.id, id));
    return true;
  }

  // Coach management
  async getCoach(id: number): Promise<Coach | undefined> {
    const [coach] = await db.select().from(coaches).where(eq(coaches.id, id));
    return coach || undefined;
  }

  async getCoachByUserId(userId: number): Promise<Coach | undefined> {
    const [coach] = await db.select().from(coaches).where(eq(coaches.userId, userId));
    return coach || undefined;
  }

  async getCoaches(): Promise<Coach[]> {
    return db.select().from(coaches);
  }

  async createCoach(coach: InsertCoach): Promise<Coach> {
    const [created] = await db.insert(coaches).values({
      ...coach,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateCoach(id: number, coachData: Partial<Coach>): Promise<Coach | undefined> {
    const [updated] = await db.update(coaches)
      .set(coachData)
      .where(eq(coaches.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteCoach(id: number): Promise<boolean> {
    const result = await db.delete(coaches).where(eq(coaches.id, id));
    return true;
  }

  // Trainer management
  async getTrainer(id: number): Promise<Trainer | undefined> {
    const [trainer] = await db.select().from(trainers).where(eq(trainers.id, id));
    return trainer || undefined;
  }

  async getTrainerByUserId(userId: number): Promise<Trainer | undefined> {
    const [trainer] = await db.select().from(trainers).where(eq(trainers.userId, userId));
    return trainer || undefined;
  }

  async getTrainers(): Promise<Trainer[]> {
    return db.select().from(trainers);
  }

  async createTrainer(trainer: InsertTrainer): Promise<Trainer> {
    const [created] = await db.insert(trainers).values({
      ...trainer,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateTrainer(id: number, trainerData: Partial<Trainer>): Promise<Trainer | undefined> {
    const [updated] = await db.update(trainers)
      .set(trainerData)
      .where(eq(trainers.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteTrainer(id: number): Promise<boolean> {
    const result = await db.delete(trainers).where(eq(trainers.id, id));
    return true;
  }

  // Parent management
  async getParent(id: number): Promise<Parent | undefined> {
    const [parent] = await db.select().from(parents).where(eq(parents.id, id));
    return parent || undefined;
  }

  async getParentByUserId(userId: number): Promise<Parent | undefined> {
    const [parent] = await db.select().from(parents).where(eq(parents.userId, userId));
    return parent || undefined;
  }

  async getParents(): Promise<Parent[]> {
    return db.select().from(parents);
  }

  async createParent(parent: InsertParent): Promise<Parent> {
    const [created] = await db.insert(parents).values({
      ...parent,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateParent(id: number, parentData: Partial<Parent>): Promise<Parent | undefined> {
    const [updated] = await db.update(parents)
      .set(parentData)
      .where(eq(parents.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteParent(id: number): Promise<boolean> {
    const result = await db.delete(parents).where(eq(parents.id, id));
    return true;
  }

  // Pitch management
  async getPitch(id: number): Promise<Pitch | undefined> {
    const [pitch] = await db.select().from(pitches).where(eq(pitches.id, id));
    return pitch || undefined;
  }

  async getPitches(): Promise<Pitch[]> {
    return db.select().from(pitches);
  }

  async createPitch(pitch: InsertPitch): Promise<Pitch> {
    const [created] = await db.insert(pitches).values({
      ...pitch,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updatePitch(id: number, pitchData: Partial<Pitch>): Promise<Pitch | undefined> {
    const [updated] = await db.update(pitches)
      .set(pitchData)
      .where(eq(pitches.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePitch(id: number): Promise<boolean> {
    const result = await db.delete(pitches).where(eq(pitches.id, id));
    return true;
  }

  // Coordinator management
  async getCoordinator(id: number): Promise<Coordinator | undefined> {
    const [coordinator] = await db.select().from(coordinators).where(eq(coordinators.id, id));
    return coordinator || undefined;
  }

  async getCoordinatorByUserId(userId: number): Promise<Coordinator | undefined> {
    const [coordinator] = await db.select().from(coordinators).where(eq(coordinators.userId, userId));
    return coordinator || undefined;
  }

  async getCoordinators(): Promise<Coordinator[]> {
    return db.select().from(coordinators);
  }

  async createCoordinator(coordinator: InsertCoordinator): Promise<Coordinator> {
    const [created] = await db.insert(coordinators).values({
      ...coordinator,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateCoordinator(id: number, coordData: Partial<Coordinator>): Promise<Coordinator | undefined> {
    const [updated] = await db.update(coordinators)
      .set(coordData)
      .where(eq(coordinators.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteCoordinator(id: number): Promise<boolean> {
    const result = await db.delete(coordinators).where(eq(coordinators.id, id));
    return true;
  }

  // Match management
  async getMatch(id: number): Promise<Match | undefined> {
    const [match] = await db.select().from(matches).where(eq(matches.id, id));
    return match || undefined;
  }

  async getMatches(teamId?: number, status?: string): Promise<Match[]> {
    if (teamId && status) {
      return db.select().from(matches)
        .where(and(
          eq(matches.teamId, teamId),
          eq(matches.status, status as any)
        ));
    } else if (teamId) {
      return db.select().from(matches).where(eq(matches.teamId, teamId));
    } else if (status) {
      return db.select().from(matches).where(eq(matches.status, status as any));
    }
    return db.select().from(matches);
  }

  async createMatch(match: InsertMatch): Promise<Match> {
    const [created] = await db.insert(matches).values({
      ...match,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateMatch(id: number, matchData: Partial<Match>): Promise<Match | undefined> {
    const [updated] = await db.update(matches)
      .set(matchData)
      .where(eq(matches.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteMatch(id: number): Promise<boolean> {
    const result = await db.delete(matches).where(eq(matches.id, id));
    return true;
  }

  // Training session management
  async getTrainingSession(id: number): Promise<TrainingSession | undefined> {
    const [session] = await db.select().from(trainingSessions).where(eq(trainingSessions.id, id));
    return session || undefined;
  }

  async getTrainingSessions(teamId?: number): Promise<TrainingSession[]> {
    if (teamId) {
      return db.select().from(trainingSessions).where(eq(trainingSessions.teamId, teamId));
    }
    return db.select().from(trainingSessions);
  }

  async createTrainingSession(session: InsertTrainingSession): Promise<TrainingSession> {
    const [created] = await db.insert(trainingSessions).values({
      ...session,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateTrainingSession(id: number, sessionData: Partial<TrainingSession>): Promise<TrainingSession | undefined> {
    const [updated] = await db.update(trainingSessions)
      .set(sessionData)
      .where(eq(trainingSessions.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteTrainingSession(id: number): Promise<boolean> {
    const result = await db.delete(trainingSessions).where(eq(trainingSessions.id, id));
    return true;
  }

  // Attendance management
  async getAttendance(id: number): Promise<Attendance | undefined> {
    const [attendanceRecord] = await db.select().from(attendance).where(eq(attendance.id, id));
    return attendanceRecord || undefined;
  }

  async getAttendanceBySession(sessionId: number, sessionType: string): Promise<Attendance[]> {
    return db.select().from(attendance)
      .where(and(
        eq(attendance.sessionId, sessionId),
        eq(attendance.sessionType, sessionType as any)
      ));
  }

  async getAttendanceByPlayer(playerId: number): Promise<Attendance[]> {
    return db.select().from(attendance).where(eq(attendance.playerId, playerId));
  }

  async createAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const [created] = await db.insert(attendance).values({
      ...attendanceData,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateAttendance(id: number, attendanceData: Partial<Attendance>): Promise<Attendance | undefined> {
    const [updated] = await db.update(attendance)
      .set(attendanceData)
      .where(eq(attendance.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteAttendance(id: number): Promise<boolean> {
    const result = await db.delete(attendance).where(eq(attendance.id, id));
    return true;
  }

  // Fee Category Management
  async getFeeCategory(id: number): Promise<FeeCategory | undefined> {
    const [category] = await db.select().from(feeCategories).where(eq(feeCategories.id, id));
    return category || undefined;
  }

  async getFeeCategories(feeType?: string, teamId?: number, seasonId?: number, isActive?: boolean): Promise<FeeCategory[]> {
    let query = db.select().from(feeCategories);
    
    if (feeType) {
      query = query.where(eq(feeCategories.feeType, feeType as any));
    }
    
    if (teamId) {
      query = query.where(eq(feeCategories.teamId, teamId));
    }
    
    if (seasonId) {
      query = query.where(eq(feeCategories.seasonId, seasonId));
    }
    
    if (isActive !== undefined) {
      query = query.where(eq(feeCategories.isActive, isActive));
    }
    
    return query;
  }

  async createFeeCategory(feeCategory: InsertFeeCategory): Promise<FeeCategory> {
    const [created] = await db.insert(feeCategories).values({
      ...feeCategory,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateFeeCategory(id: number, feeCategory: Partial<FeeCategory>): Promise<FeeCategory | undefined> {
    const [updated] = await db.update(feeCategories)
      .set(feeCategory)
      .where(eq(feeCategories.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteFeeCategory(id: number): Promise<boolean> {
    const result = await db.delete(feeCategories).where(eq(feeCategories.id, id));
    return result.rowCount > 0;
  }

  // User Fee Management
  async getUserFee(id: number): Promise<UserFee | undefined> {
    const [fee] = await db.select().from(userFees).where(eq(userFees.id, id));
    return fee || undefined;
  }

  async getUserFees(): Promise<UserFee[]> {
    return db.select().from(userFees);
  }

  async getUserFeesByUser(userId: number, status?: string): Promise<UserFee[]> {
    let query = db.select().from(userFees).where(eq(userFees.userId, userId));
    
    if (status) {
      query = query.where(eq(userFees.status, status as any));
    }
    
    return query;
  }

  async getUserFeesByCategory(feeCategoryId: number, status?: string): Promise<UserFee[]> {
    let query = db.select().from(userFees).where(eq(userFees.feeCategoryId, feeCategoryId));
    
    if (status) {
      query = query.where(eq(userFees.status, status as any));
    }
    
    return query;
  }

  async getUserFeesByTeam(teamId: number, status?: string): Promise<UserFee[]> {
    // First get the fee categories for the team
    const categories = await this.getFeeCategories(undefined, teamId);
    const categoryIds = categories.map(cat => cat.id);
    
    if (categoryIds.length === 0) {
      return [];
    }
    
    let query = db.select().from(userFees);
    
    // Using the "in" operator for multiple categoryIds
    if (status) {
      return db.select().from(userFees).where(
        and(
          inArray(userFees.feeCategoryId, categoryIds),
          eq(userFees.status, status as any)
        )
      );
    } else {
      return db.select().from(userFees).where(
        inArray(userFees.feeCategoryId, categoryIds)
      );
    }
  }

  async createUserFee(userFee: InsertUserFee): Promise<UserFee> {
    const [created] = await db.insert(userFees).values({
      ...userFee,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updateUserFee(id: number, userFee: Partial<UserFee>): Promise<UserFee | undefined> {
    const [updated] = await db.update(userFees)
      .set(userFee)
      .where(eq(userFees.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteUserFee(id: number): Promise<boolean> {
    const result = await db.delete(userFees).where(eq(userFees.id, id));
    return result.rowCount > 0;
  }

  // Payment Management
  async getPayment(id: number): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    return payment || undefined;
  }

  async getPayments(): Promise<Payment[]> {
    return db.select().from(payments);
  }

  async getPaymentsByUser(userId: number): Promise<Payment[]> {
    return db.select().from(payments).where(eq(payments.userId, userId));
  }

  async getPaymentsByUserFee(userFeeId: number): Promise<Payment[]> {
    return db.select().from(payments).where(eq(payments.userFeeId, userFeeId));
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [created] = await db.insert(payments).values({
      ...payment,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updatePayment(id: number, payment: Partial<Payment>): Promise<Payment | undefined> {
    const [updated] = await db.update(payments)
      .set(payment)
      .where(eq(payments.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePayment(id: number): Promise<boolean> {
    const result = await db.delete(payments).where(eq(payments.id, id));
    return result.rowCount > 0;
  }

  // Payment Plan Management
  async getPaymentPlan(id: number): Promise<PaymentPlan | undefined> {
    const [plan] = await db.select().from(paymentPlans).where(eq(paymentPlans.id, id));
    return plan || undefined;
  }

  async getPaymentPlansByUser(userId: number): Promise<PaymentPlan[]> {
    return db.select().from(paymentPlans).where(eq(paymentPlans.userId, userId));
  }

  async getPaymentPlansByUserFee(userFeeId: number): Promise<PaymentPlan[]> {
    return db.select().from(paymentPlans).where(eq(paymentPlans.userFeeId, userFeeId));
  }

  async createPaymentPlan(paymentPlan: InsertPaymentPlan): Promise<PaymentPlan> {
    const [created] = await db.insert(paymentPlans).values({
      ...paymentPlan,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updatePaymentPlan(id: number, paymentPlan: Partial<PaymentPlan>): Promise<PaymentPlan | undefined> {
    const [updated] = await db.update(paymentPlans)
      .set(paymentPlan)
      .where(eq(paymentPlans.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePaymentPlan(id: number): Promise<boolean> {
    const result = await db.delete(paymentPlans).where(eq(paymentPlans.id, id));
    return result.rowCount > 0;
  }

  // Exercise methods for IADATABANK
  async getExercises(): Promise<Exercise[]> {
    return await db.select().from(exercises);
  }

  async createExercise(insertExercise: InsertExercise): Promise<Exercise> {
    const [exercise] = await db.insert(exercises).values(insertExercise).returning();
    return exercise;
  }

  async updateExercise(id: number, data: Partial<InsertExercise>): Promise<Exercise> {
    const [exercise] = await db.update(exercises).set(data).where(eq(exercises.id, id)).returning();
    return exercise;
  }

  async deleteExercise(id: number): Promise<void> {
    await db.delete(exercises).where(eq(exercises.id, id));
  }

  async getExerciseCategories(): Promise<ExerciseCategory[]> {
    return await db.select().from(exerciseCategories);
  }

  async createExerciseCategory(data: InsertExerciseCategory): Promise<ExerciseCategory> {
    const [category] = await db.insert(exerciseCategories).values(data).returning();
    return category;
  }

  async getTrainingPrograms(): Promise<any[]> {
    return [];
  }

  // Training Sessions methods
  async getTrainingSessions(planId?: number): Promise<TrainingSession[]> {
    let query = db.select().from(trainingSessions);
    if (planId) {
      query = query.where(eq(trainingSessions.planId, planId));
    }
    return await query;
  }

  async createTrainingSession(session: InsertTrainingSession): Promise<TrainingSession> {
    const [newSession] = await db.insert(trainingSessions).values(session).returning();
    return newSession;
  }

  async updateTrainingSession(id: number, session: Partial<TrainingSession>): Promise<TrainingSession | undefined> {
    const [updated] = await db
      .update(trainingSessions)
      .set(session)
      .where(eq(trainingSessions.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteTrainingSession(id: number): Promise<boolean> {
    const result = await db.delete(trainingSessions).where(eq(trainingSessions.id, id));
    return (result.rowCount || 0) > 0;
  }

  async createTrainingProgram(data: any): Promise<any> {
    return { id: Date.now(), ...data };
  }

  // Payment Plan Installment Management
  async getPaymentPlanInstallment(id: number): Promise<PaymentPlanInstallment | undefined> {
    const [installment] = await db.select().from(paymentPlanInstallments).where(eq(paymentPlanInstallments.id, id));
    return installment || undefined;
  }

  async getPaymentPlanInstallmentsByPlan(paymentPlanId: number): Promise<PaymentPlanInstallment[]> {
    return db.select().from(paymentPlanInstallments).where(eq(paymentPlanInstallments.paymentPlanId, paymentPlanId));
  }

  async getPaymentPlanInstallmentsByStatus(status: string): Promise<PaymentPlanInstallment[]> {
    return db.select().from(paymentPlanInstallments).where(eq(paymentPlanInstallments.status, status as any));
  }

  async createPaymentPlanInstallment(installment: InsertPaymentPlanInstallment): Promise<PaymentPlanInstallment> {
    const [created] = await db.insert(paymentPlanInstallments).values({
      ...installment,
      createdAt: new Date()
    }).returning();
    return created;
  }

  async updatePaymentPlanInstallment(id: number, installment: Partial<PaymentPlanInstallment>): Promise<PaymentPlanInstallment | undefined> {
    const [updated] = await db.update(paymentPlanInstallments)
      .set(installment)
      .where(eq(paymentPlanInstallments.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePaymentPlanInstallment(id: number): Promise<boolean> {
    const result = await db.delete(paymentPlanInstallments).where(eq(paymentPlanInstallments.id, id));
    return result.rowCount > 0;
  }
}

// Use DatabaseStorage instead of MemStorage for real database connection
export const storage = new DatabaseStorage();
